"""Minimal SSAP websocket client for LG webOS TVs.

Design constraints (security baseline):
  * Only URIs from the protocol allowlist can be requested -- attempts to
    send anything else raise before a byte leaves the machine.
  * The pairing key is passed in and returned; it is never logged and the
    client keeps no copy after registration.
  * Navigation buttons go through the TV's pointer-input socket, restricted
    to the allowlisted button names.
  * The websocket factory is injectable so tests exercise the full protocol
    against fakes -- no real network in the suite.

TVs answer on ws://<tv>:3000 and (2022+ firmware, self-signed certificate)
wss://<tv>:3001.  We try TLS first and fall back; the certificate cannot be
verified (LG ships self-signed) which is acceptable for LAN remote control
-- the pairing prompt on the TV screen is the trust anchor.
"""

from __future__ import annotations

import asyncio
import json
import logging
import ssl
from typing import Any, Awaitable, Callable
from urllib.parse import urlsplit

from .protocol import ALLOWED_URIS, BUTTONS, SUBSCRIBABLE_URIS, URI_POINTER_SOCKET, build_register_payload

log = logging.getLogger("lg_webos")

PORT_PLAIN = 3000
PORT_TLS = 3001
CONNECT_TIMEOUT = 6.0
REQUEST_TIMEOUT = 10.0
PAIRING_TIMEOUT = 75.0  # the on-screen prompt needs a human


class SSAPError(Exception):
    """TV protocol/transport failure (message safe to show the user)."""


class SSAPPairingRejected(SSAPError):
    """The TV (or its owner) declined the pairing request."""


class SSAPNotSupported(SSAPError):
    """The TV firmware does not offer this service (404)."""


ConnectFactory = Callable[[str], Awaitable[Any]]


def _tv_ssl_context() -> ssl.SSLContext:
    # LG TVs present a self-signed certificate on :3001. Verification is
    # impossible by design; trust is established by the on-TV pairing prompt.
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


async def default_connect(url: str) -> Any:
    from websockets.asyncio.client import connect

    kwargs: dict = {
        "open_timeout": CONNECT_TIMEOUT,
        "close_timeout": 3,
        "ping_interval": 20,
        "ping_timeout": 10,
        "max_size": 4 * 1024 * 1024,  # app lists can be large; still bounded
    }
    if url.startswith("wss://"):
        kwargs["ssl"] = _tv_ssl_context()
    return await connect(url, **kwargs)


def _safe_pointer_url(url: str, expected_host: str) -> bool:
    """The pointer socketPath is TV-supplied input.  Trust it only when it is
    a ws/wss URL, credential-free, on the TV's own SSAP ports, and pointing
    at exactly the host this client was configured for -- a compromised
    answer must never steer a button press at some other service."""
    if not url or len(url) > 512:
        return False
    try:
        parts = urlsplit(url)
        port = parts.port  # raises ValueError on junk like :99999
    except ValueError:
        return False
    if parts.scheme not in ("ws", "wss"):
        return False
    if "@" in parts.netloc:  # no user:pass@host tricks
        return False
    if port not in (PORT_PLAIN, PORT_TLS):
        return False
    host = (parts.hostname or "").lower()
    return bool(host) and host == expected_host.strip().lower()


class SSAPClient:
    """One connection to one TV.  Create, connect(), register(), request()."""

    def __init__(self, host: str, connect_factory: ConnectFactory | None = None) -> None:
        self.host = host
        self._connect_factory = connect_factory or default_connect
        self._ws: Any = None
        self._pointer_ws: Any = None
        self._reader: asyncio.Task | None = None
        self._next_id = 0
        self._routes: dict[str, asyncio.Queue] = {}
        self._subs: dict[str, Callable[[dict], None]] = {}
        self.used_tls: bool | None = None
        self.closed = asyncio.Event()

    # -- lifecycle -------------------------------------------------------
    async def connect(self, prefer_tls: bool | None = None) -> None:
        """Open the control socket, trying wss:3001 then ws:3000 (or the
        remembered order).  Raises SSAPError when the TV is unreachable."""
        candidates = [f"wss://{self.host}:{PORT_TLS}", f"ws://{self.host}:{PORT_PLAIN}"]
        if prefer_tls is False:
            candidates.reverse()
        last_exc: Exception | None = None
        for url in candidates:
            try:
                self._ws = await self._connect_factory(url)
                self.used_tls = url.startswith("wss://")
                break
            except Exception as exc:  # noqa: BLE001 - each transport failure tried in turn
                last_exc = exc
        if self._ws is None:
            raise SSAPError(f"could not reach the TV at {self.host} (is it on and on this network?)") from last_exc
        self.closed.clear()
        self._reader = asyncio.create_task(self._read_loop(), name="lg-ssap-read")

    async def close(self) -> None:
        reader, self._reader = self._reader, None
        for ws in (self._pointer_ws, self._ws):
            if ws is not None:
                try:
                    await ws.close()
                except Exception:  # noqa: BLE001 - closing best-effort
                    pass
        self._pointer_ws = None
        self._ws = None
        if reader is not None:
            reader.cancel()
            await asyncio.gather(reader, return_exceptions=True)
        self._fail_pending("connection closed")
        self.closed.set()

    @property
    def connected(self) -> bool:
        return self._ws is not None and not self.closed.is_set()

    # -- registration (pairing) -------------------------------------------
    async def register(
        self,
        client_key: str | None,
        on_prompt: Callable[[], None] | None = None,
        timeout: float = PAIRING_TIMEOUT,
    ) -> str:
        """Register with the TV.  Returns the (possibly new) client key.

        With a stored key this is silent; without one the TV shows its
        pairing prompt and we wait for the user's on-screen approval.
        """
        if self._ws is None:
            raise SSAPError("not connected")
        msg_id = self._new_id("register")
        queue: asyncio.Queue = asyncio.Queue()
        self._routes[msg_id] = queue
        try:
            await self._send({"type": "register", "id": msg_id, "payload": build_register_payload(client_key)})
            deadline = asyncio.get_running_loop().time() + timeout
            while True:
                remaining = deadline - asyncio.get_running_loop().time()
                if remaining <= 0:
                    raise SSAPError("no pairing approval received from the TV in time")
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=remaining)
                except asyncio.TimeoutError:
                    raise SSAPError("no pairing approval received from the TV in time") from None
                if msg is _EOF:
                    raise SSAPError("the TV closed the connection during pairing")
                mtype = msg.get("type")
                payload = msg.get("payload") or {}
                if mtype == "registered":
                    key = str(payload.get("client-key") or "")
                    if not key:
                        raise SSAPError("the TV did not return a pairing key")
                    return key
                if mtype == "response" and payload.get("pairingType") == "PROMPT":
                    if on_prompt is not None:
                        on_prompt()
                    continue  # now waiting for the human on the TV
                if mtype == "error":
                    err = str(msg.get("error") or "pairing failed")
                    if "denied" in err.lower() or "cancelled" in err.lower() or "canceled" in err.lower():
                        raise SSAPPairingRejected("pairing was declined on the TV")
                    if "pairing" in err.lower() and "time" in err.lower():
                        raise SSAPError("the pairing prompt on the TV timed out")
                    raise SSAPPairingRejected(f"the TV rejected registration: {err[:120]}")
        finally:
            self._routes.pop(msg_id, None)

    # -- requests ----------------------------------------------------------
    async def request(self, uri: str, payload: dict | None = None, timeout: float = REQUEST_TIMEOUT) -> dict:
        """Send one allowlisted request and return the TV's payload."""
        if uri not in ALLOWED_URIS:
            raise SSAPError("blocked: command is not on the TV allowlist")
        if self._ws is None:
            raise SSAPError("not connected")
        msg_id = self._new_id("req")
        queue: asyncio.Queue = asyncio.Queue()
        self._routes[msg_id] = queue
        try:
            await self._send({"id": msg_id, "type": "request", "uri": uri, "payload": payload or {}})
            try:
                msg = await asyncio.wait_for(queue.get(), timeout=timeout)
            except asyncio.TimeoutError:
                raise SSAPError("the TV did not answer in time") from None
            if msg is _EOF:
                raise SSAPError("connection to the TV was lost")
            return self._unwrap(msg)
        finally:
            self._routes.pop(msg_id, None)

    async def subscribe(self, uri: str, callback: Callable[[dict], None]) -> str:
        """Subscribe to TV-pushed updates for an allowlisted, subscribable URI.
        The first response and every later push go to *callback* (payload)."""
        if uri not in SUBSCRIBABLE_URIS:
            raise SSAPError("blocked: subscription is not on the TV allowlist")
        if self._ws is None:
            raise SSAPError("not connected")
        msg_id = self._new_id("sub")
        self._subs[msg_id] = callback
        await self._send({"id": msg_id, "type": "subscribe", "uri": uri, "payload": {}})
        return msg_id

    # -- pointer-input socket (navigation buttons) --------------------------
    async def button(self, name: str) -> None:
        """Press one allowlisted remote button via the pointer-input socket."""
        button = BUTTONS.get(str(name or "").strip().lower())
        if button is None:
            raise SSAPError(f"'{name}' is not an allowed TV button")
        frame = f"type:button\nname:{button}\n\n"
        ws = await self._ensure_pointer_socket()
        try:
            await ws.send(frame)
        except Exception:  # noqa: BLE001 - one reconnect attempt on stale socket
            self._pointer_ws = None
            ws = await self._ensure_pointer_socket()
            try:
                await ws.send(frame)
            except Exception as exc:  # noqa: BLE001
                raise SSAPError("could not send the button press to the TV") from exc

    async def _ensure_pointer_socket(self) -> Any:
        if self._pointer_ws is not None:
            return self._pointer_ws
        payload = await self.request(URI_POINTER_SOCKET)
        path = str(payload.get("socketPath") or "")
        if not path:
            raise SSAPError("the TV did not provide a pointer socket")
        if not _safe_pointer_url(path, self.host):
            raise SSAPError("the TV offered an unusable pointer socket address")
        try:
            self._pointer_ws = await self._connect_factory(path)
        except Exception as exc:  # noqa: BLE001
            raise SSAPError("could not open the TV's pointer socket") from exc
        return self._pointer_ws

    # -- internals -----------------------------------------------------------
    def _new_id(self, prefix: str) -> str:
        self._next_id += 1
        return f"{prefix}_{self._next_id}"

    async def _send(self, message: dict) -> None:
        try:
            await self._ws.send(json.dumps(message))
        except Exception as exc:  # noqa: BLE001
            raise SSAPError("connection to the TV was lost") from exc

    @staticmethod
    def _unwrap(msg: dict) -> dict:
        if msg.get("type") == "error":
            err = str(msg.get("error") or "TV error")
            if err.strip().startswith("404"):
                raise SSAPNotSupported("this TV does not support that command")
            raise SSAPError(f"the TV rejected the request: {err[:120]}")
        payload = msg.get("payload") or {}
        if payload.get("returnValue") is False:
            text = str(payload.get("errorText") or payload.get("errorCode") or "request failed")
            raise SSAPError(f"the TV reported: {text[:120]}")
        return payload

    async def _read_loop(self) -> None:
        try:
            while True:
                raw = await self._ws.recv()
                try:
                    msg = json.loads(raw)
                except (TypeError, ValueError):
                    continue
                if not isinstance(msg, dict):
                    continue
                msg_id = str(msg.get("id") or "")
                callback = self._subs.get(msg_id)
                if callback is not None:
                    try:
                        callback(self._unwrap(msg))
                    except SSAPError:
                        pass  # error frames on subscriptions are dropped
                    except Exception:  # noqa: BLE001 - subscriber bugs must not kill the reader
                        log.debug("subscription callback failed", exc_info=True)
                    continue
                queue = self._routes.get(msg_id)
                if queue is not None:
                    queue.put_nowait(msg)
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - any transport error means disconnected
            pass
        finally:
            self._fail_pending("connection to the TV was lost")
            self.closed.set()

    def _fail_pending(self, _reason: str) -> None:
        for queue in self._routes.values():
            queue.put_nowait(_EOF)
        self._routes.clear()
        self._subs.clear()


class _Eof:
    __slots__ = ()


_EOF = _Eof()
