#!/usr/bin/env node
// Executes the real background.js module with a minimal Chrome MV3 mock.
// This specifically guards the options-page Pair now path that previously
// returned no response when Chrome's MessageSender metadata varied.

import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";

let messageListener = null;
const sockets = [];
const storageData = {};
let deferSecretWrite = false;
let releaseSecretWrite = null;

class StubWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;

  constructor(url) {
    this.url = url;
    this.readyState = StubWebSocket.CONNECTING;
    this.listeners = new Map();
    sockets.push(this);
  }

  addEventListener(type, callback) {
    this.listeners.set(type, callback);
  }

  close() {
    this.readyState = 3;
  }

  send() {}
}

globalThis.WebSocket = StubWebSocket;
globalThis.chrome = {
  runtime: {
    id: "test-extension-id",
    getURL: (path = "") => "chrome-extension://test-extension-id/" + path,
    onMessage: {
      addListener(callback) {
        messageListener = callback;
      },
    },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} },
    sendMessage() {},
  },
  storage: {
    local: {
      async get(keys) {
        const selected = {};
        for (const key of keys || []) {
          if (Object.hasOwn(storageData, key)) selected[key] = storageData[key];
        }
        return selected;
      },
      async set(values) {
        if (deferSecretWrite && Object.hasOwn(values, "bridge_secret")) {
          await new Promise((resolve) => { releaseSecretWrite = resolve; });
        }
        Object.assign(storageData, values);
      },
      async remove(keys) {
        for (const key of keys || []) delete storageData[key];
      },
    },
  },
  alarms: {
    create() {},
    onAlarm: { addListener() {} },
  },
  tabs: {
    async query() { return []; },
    async update() {},
    async create() {},
    async sendMessage() { return {}; },
  },
};

const backgroundUrl = new URL("../background.js", import.meta.url);
await import(pathToFileURL(backgroundUrl.pathname).href + "?message-test=1");

assert.equal(typeof messageListener, "function", "background listener was not registered");

let pairResponse;
const pairReturn = messageListener({
  type: "pair",
  token: "test-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {
  // Deliberately reproduce a tabbed options page while omitting optional
  // sender.id/url/origin metadata. UI routing must not depend on these fields.
  tab: { id: 42 },
}, (response) => {
  pairResponse = response;
});

assert.deepEqual(pairResponse, { ok: true }, "Pair now did not receive an immediate acceptance");
assert.equal(pairReturn, false, "synchronously answered Pair now must not hold the message port open");

// Reproduce the real pairing race: the bridge sends paired and auth_ok
// back-to-back while chrome.storage.local.set is still persisting the secret.
// The older paired handler must not overwrite the final ready status.
const pairingSocket = sockets.at(-1);
assert.ok(pairingSocket, "Pair now did not create a WebSocket");
pairingSocket.readyState = StubWebSocket.OPEN;
pairingSocket.listeners.get("open")();
deferSecretWrite = true;
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "bridge-secret-1234567890" }),
});
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 7 }),
});
assert.equal(typeof releaseSecretWrite, "function", "secret write was not deferred");
releaseSecretWrite();
await new Promise((resolve) => setImmediate(resolve));

const statusResponse = await new Promise((resolve) => {
  const keepPortOpen = messageListener({ type: "get_status" }, {}, resolve);
  assert.equal(keepPortOpen, true);
});
assert.equal(statusResponse.status.authenticated, true);
assert.equal(statusResponse.status.detail, "ready",
  "paired storage completion regressed ready status to awaiting auth_ok");

let contentResponse;
const contentReturn = messageListener({
  type: "content_hello",
}, {
  tab: { id: 7 },
  origin: "https://www.youtube.com",
  url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
}, (response) => {
  contentResponse = response;
});

assert.deepEqual(contentResponse, { ok: true, connected: true });
assert.equal(contentReturn, true);

console.log("Real background message test passed: Pair routing and auth status race are safe.");