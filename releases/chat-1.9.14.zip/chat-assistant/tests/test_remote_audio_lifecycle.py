"""Remote microphone ownership and voice-lease lifecycle regressions.

Updated for wake-first flow:
  * /ws/remote-audio accept does NOT call request_session.
  * Session starts when a wake hit fires (simulated by calling
    gateway.request_session() directly in tests).
  * Goodbye / inactivity end the provider session but keep the socket open
    and return to wake-listening mode.
  * The socket is only closed on: auth loss (4401), owner conflict (4409),
    transport disconnect, or app stop.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


async def _dummy_tools(call_id, name, args):
    return {}


class FakeWebSocket:
    """Small ASGI-WebSocket double that exercises the real route coroutine."""

    def __init__(self, token: str) -> None:
        self.cookies = {COOKIE: token}
        self.incoming: asyncio.Queue[dict] = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code: int | None = None
        self.close_reason = ""
        self.sent_bytes: list[bytes] = []
        self.sent_text: list[str] = []

    async def accept(self) -> None:
        self.accepted.set()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        self.close_code = code
        self.close_reason = reason or ""
        self.closed.set()

    async def receive(self) -> dict:
        return await self.incoming.get()

    async def send_bytes(self, payload: bytes) -> None:
        self.sent_bytes.append(payload)

    async def send_text(self, payload: str) -> None:
        self.sent_text.append(payload)

    def feed_audio(self, payload: bytes) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": payload})

    def disconnect(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})


@pytest.fixture
def remote_app(settings, db, store, bus):
    state = StateMachine(bus)
    gateway = LiveGateway(settings, db, store, bus, state, [], _dummy_tools)
    runtime = SimpleNamespace(
        settings=settings,
        db=db,
        state=state,
        gateway=gateway,
        broadcast=AudioBroadcast(),
        audio=None,
        media_playing=False,
        stop_calls=0,
    )

    def stop_output() -> None:
        runtime.stop_calls += 1
        gateway.interrupt()
        runtime.broadcast.clear()

    runtime.stop_output = stop_output
    app = create_app(runtime)
    sessions = SessionManager("remote-audio-test-secret", 3600)
    app.state.sessions = sessions
    token = sessions.issue()
    endpoint = next(
        route.endpoint for route in app.routes if route.path == "/ws/remote-audio"
    )
    return app, runtime, token, endpoint


async def _open_socket(app, token, endpoint) -> tuple[FakeWebSocket, asyncio.Task]:
    ws = FakeWebSocket(token)
    task = asyncio.create_task(endpoint(ws))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    # Accepted happens just before the synchronous ownership claim.
    for _ in range(20):
        owner = app.state.remote_mic_owner
        if owner is not None and owner.socket is ws:
            break
        if ws.closed.is_set():
            break
        await asyncio.sleep(0)
    return ws, task


async def test_connect_does_not_start_session(remote_app):
    """Connecting the socket must NOT start a provider session.
    The socket enters wake-listening mode; request_session is called on wake hit."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)

    # No session should have started.
    assert rt.gateway.voice_session_generation == 0
    assert not rt.gateway._session_intent_active
    assert app.state.remote_mic_owner is not None
    assert app.state.remote_mic_owner.socket is ws

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
    assert app.state.remote_mic_owner is None


async def test_explicit_voice_stop_keeps_socket_open(remote_app):
    """An explicit session end (goodbye/mute/inactivity) keeps the WebSocket
    open and returns to wake-listening mode.  The socket is NOT closed."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)

    # Simulate a wake hit: call request_session as the wake handler would.
    first_generation = rt.gateway.request_session()
    assert first_generation > 0

    # Now end the session (as goodbye/inactivity would do).
    rt.gateway.request_end_session("voice stop command")
    rt.state.set(ChatState.SLEEPING, "explicit stop")
    # Give the handler time to process the end.
    await asyncio.sleep(0.15)

    # Socket must remain open: the user can say Hey Jarvis again.
    assert not ws.closed.is_set(), "Socket must stay open after session end"
    assert app.state.remote_mic_owner is not None
    assert app.state.remote_mic_owner.socket is ws

    # A subsequent wake hit starts a fresh generation without a new Start click.
    second_generation = rt.gateway.request_session()
    assert second_generation > first_generation

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
    assert app.state.remote_mic_owner is None


async def test_natural_timeout_keeps_socket_open_and_gates_audio(remote_app):
    """Natural inactivity ends the provider session but keeps the socket open.
    Ordinary speech after inactivity does not reach audio_in (re-wake required)."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    pre_end_generation = rt.gateway.voice_end_generation

    # Simulate a wake + natural inactivity completion.
    rt.gateway.request_session()
    rt.gateway._session_intent_active = False
    rt.gateway._keep_listening = False
    rt.gateway._wanted.clear()
    rt.state.set(ChatState.SLEEPING, "provider inactivity")

    # Send loud audio that used to silently reopen a session.
    loud = (2400).to_bytes(2, "little", signed=True) * 1600
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.15)

    # Socket must remain open.
    assert not ws.closed.is_set(), "Socket must stay open after natural inactivity"
    # Explicit-end generation is unchanged (this was not an explicit stop).
    assert rt.gateway.voice_end_generation == pre_end_generation
    # Audio must not have been forwarded to the provider.
    assert rt.gateway.audio_in.empty()

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
    assert app.state.remote_mic_owner is None


async def test_disconnect_cleanup_serializes_owner_claims(remote_app, monkeypatch):
    app, rt, token, endpoint = remote_app
    first, first_task = await _open_socket(app, token, endpoint)
    # Simulate a wake so there is a session to clean up on disconnect.
    first_generation = rt.gateway.request_session()
    cleanup_entered = asyncio.Event()
    release_cleanup = asyncio.Event()
    real_end = rt.gateway.end_session

    async def delayed_end(reason="requested", *, expected_generation=None):
        cleanup_entered.set()
        await release_cleanup.wait()
        return await real_end(reason, expected_generation=expected_generation)

    monkeypatch.setattr(rt.gateway, "end_session", delayed_end)
    first.disconnect()
    await asyncio.wait_for(cleanup_entered.wait(), timeout=0.5)

    # Ownership is deliberately retained across the await above. A competing
    # device receives a bounded busy response instead of being claimed and
    # then killed by the first socket's stale finally block.
    competing, competing_task = await _open_socket(app, token, endpoint)
    await asyncio.wait_for(competing.closed.wait(), timeout=0.5)
    await asyncio.wait_for(competing_task, timeout=0.5)
    assert competing.close_code == 4409
    assert app.state.remote_mic_owner.socket is first

    release_cleanup.set()
    await asyncio.wait_for(first_task, timeout=0.5)
    assert app.state.remote_mic_owner is None

    # After the first socket fully disconnects a replacement can connect.
    replacement, replacement_task = await _open_socket(app, token, endpoint)
    assert app.state.remote_mic_owner.socket is replacement
    # The replacement starts in wake-listening mode (no session yet).
    assert rt.gateway.voice_session_generation == first_generation
    replacement.disconnect()
    await asyncio.wait_for(replacement_task, timeout=0.5)


async def test_api_wake_fallback_binds_session_and_pcm_reaches_gateway(remote_app):
    """/api/wake starts a gateway session when the wake model is unavailable.

    Flow:
      1. Browser connects; no wake model on rt.audio (None).
      2. Fallback: browser calls /api/wake → gateway.request_session() fires.
      3. Next PCM chunk arrives; the socket must detect the externally started
         session, bind to it (update session_active_flag and lease), and forward
         audio to gateway.audio_in.
      4. Goodbye (request_end_session) returns the socket to wake-listening
         mode without closing it.  A second /api/wake + PCM cycle must work
         identically.
      5. Stale-socket guard: a replaced socket must NOT bind to the current
         owner's session when it is no longer the owner.
    """
    app, rt, token, endpoint = remote_app
    # rt.audio is None in the fixture — wake model unavailable.
    assert rt.audio is None

    ws, task = await _open_socket(app, token, endpoint)
    assert not rt.gateway.session_intent_active, "must start in wake-listening mode"

    # --- Step 1: /api/wake equivalent ------------------------------------------
    first_gen = rt.gateway.request_session()
    assert first_gen > 0
    assert rt.gateway.session_intent_active

    # Give the receive loop a tick to notice the new session state.
    await asyncio.sleep(0)

    # --- Step 2: PCM arrives after external wake --------------------------------
    # Use a loud chunk so the mic-gate passes it without needing 2 chunks.
    loud = (3000).to_bytes(2, "little", signed=True) * 800  # 1600 bytes
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)

    # audio_in must have received frames.
    assert not rt.gateway.audio_in.empty(), (
        "PCM must reach gateway.audio_in after /api/wake fallback"
    )
    # Lease must now be bound to the active generation.
    assert app.state.remote_mic_owner.voice_session_generation == first_gen

    # Drain queue for the next phase.
    while not rt.gateway.audio_in.empty():
        rt.gateway.audio_in.get_nowait()

    # --- Step 3: Goodbye returns to wake-listening mode -------------------------
    rt.gateway.request_end_session("goodbye")
    rt.state.set(ChatState.SLEEPING, "goodbye")
    await asyncio.sleep(0.1)

    assert not ws.closed.is_set(), "Socket must stay open after goodbye"
    # Post-goodbye PCM must NOT reach audio_in.
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)
    assert rt.gateway.audio_in.empty(), (
        "PCM after goodbye must be gated until the next wake/api_wake"
    )

    # --- Step 4: Second /api/wake + PCM cycle -----------------------------------
    second_gen = rt.gateway.request_session()
    assert second_gen > first_gen
    await asyncio.sleep(0)

    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)

    assert not rt.gateway.audio_in.empty(), (
        "PCM must reach gateway.audio_in after second /api/wake"
    )
    assert app.state.remote_mic_owner.voice_session_generation == second_gen

    # Drain for cleanliness.
    while not rt.gateway.audio_in.empty():
        rt.gateway.audio_in.get_nowait()

    # --- Step 5: Stale-socket guard --------------------------------------------
    # Simulate the current socket becoming "replaced": clear the owner without
    # fully disconnecting so we can inspect behavior on the next PCM chunk.
    # We do this by setting the owner to None (as a new browser would do after
    # taking over), then calling request_session() again.
    rt.gateway.request_end_session("replaced")
    app.state.remote_mic_owner = None  # simulate a replacement socket taking over

    third_gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)

    # The old (now-detached) socket must NOT have forwarded PCM.
    assert rt.gateway.audio_in.empty(), (
        "Stale/replaced socket must not bind to the new owner's session"
    )

    # Clean up: restore owner so the finally block doesn't assert errors.
    app.state.remote_mic_owner = app.state.remote_mic_owner  # no-op; stays None
    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_speaking_remote_pcm_is_local_barge_in_until_listening(
    remote_app, monkeypatch
):
    """Browser echo during TTS must only interrupt locally, never reach Gemini."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    try:
        rt.gateway.request_session()
        rt.state.set(ChatState.SPEAKING, "model audio")
        real_interrupt = rt.gateway.interrupt
        interrupt = MagicMock(side_effect=real_interrupt)
        monkeypatch.setattr(rt.gateway, "interrupt", interrupt)
        loud = (4_000).to_bytes(2, "little", signed=True) * 800

        # Three sustained loud frames are required to barge in. None of their
        # PCM may cross into the provider queue while the assistant speaks.
        for _ in range(3):
            ws.feed_audio(loud)
        for _ in range(50):
            if interrupt.call_count:
                break
            await asyncio.sleep(0.01)

        interrupt.assert_called_once_with()
        assert rt.state.raw_state == ChatState.LISTENING
        assert rt.gateway.audio_in.empty()

        # The real interrupt handoff above changes SPEAKING → LISTENING; later
        # microphone PCM is then eligible for normal provider forwarding.
        ws.feed_audio(loud)
        assert await asyncio.wait_for(rt.gateway.audio_in.get(), timeout=0.5) == loud
    finally:
        ws.disconnect()
        await asyncio.wait_for(task, timeout=0.5)
