"""Audio engine: wake word, microphone streaming, playback, interruption.

Heavy dependencies (sounddevice, numpy, openwakeword) are OPTIONAL. When
they're missing -- e.g. running on a machine without audio or before
`pip install -r requirements-voice.txt` -- the engine reports
voice_available=False and the rest of Chat (dashboard, timers, lights,
rotation) runs normally. This keeps the default install tiny and the
process light, per the user's requirement.

Design rules honored here:
  * No network, database, logging, or health work inside audio callbacks.
  * Bounded buffers everywhere.
  * Local VAD stays active while Chat speaks; crossing the threshold
    clears queued playback and signals interruption.
  * Wake-word detection keeps running after the cloud session closes.
"""

from __future__ import annotations

import asyncio
import logging
import queue as thread_queue
from typing import Callable

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.state import ChatState, StateMachine

log = logging.getLogger("audio")

try:  # optional voice stack
    import numpy as np  # type: ignore
    import sounddevice as sd  # type: ignore

    _AUDIO_OK = True
except Exception:  # pragma: no cover - environment dependent
    _AUDIO_OK = False

try:  # optional wake word
    from openwakeword.model import Model as WakeModel  # type: ignore

    _WAKE_OK = True
except Exception:  # pragma: no cover
    _WAKE_OK = False

IN_RATE = 16000
OUT_RATE = 24000
CHUNK = 1280  # 80 ms at 16 kHz


def _short(exc: Exception) -> str:
    s = str(exc).strip() or type(exc).__name__
    return s.splitlines()[0][:200]


def _download_wake_models() -> None:  # pragma: no cover - network download
    """openwakeword ships its CODE on pip but not its MODEL FILES; this
    fetches them once (a few small .onnx files) into the package folder."""
    import openwakeword.utils  # type: ignore

    openwakeword.utils.download_models()


def _load_wake_model_blocking(model_ref: str | None) -> tuple[object | None, str]:
    """Load the wake model (runs in a worker thread). Returns (model, "")
    on success or (None, plain-language reason) on failure -- never raises.

    A fresh laptop install fails the first construction with ValueError
    because the model files were never downloaded (install.bat used to skip
    that step entirely); we download them and retry once.
    """
    from pathlib import Path

    custom = bool(model_ref) and (
        "/" in model_ref or "\\" in model_ref or model_ref.endswith((".onnx", ".tflite"))
    )
    if custom:
        if not Path(model_ref).exists():
            return None, f"custom wake word model file not found: {model_ref}"
        try:
            return WakeModel(wakeword_models=[model_ref]), ""
        except Exception as exc:
            return None, f"could not load the custom wake word model: {_short(exc)}"

    kwargs = {"wakeword_models": [model_ref] if model_ref else None}
    try:
        return WakeModel(**kwargs), ""
    except Exception:
        pass  # most likely: model files not downloaded yet -- fix and retry
    try:
        _download_wake_models()
    except Exception as exc:
        return None, (
            "the wake word model files are missing and could not be downloaded "
            f"({type(exc).__name__}) -- connect to the internet and restart "
            "Chat, or re-run deployment\\windows\\install.bat"
        )
    try:
        return WakeModel(**kwargs), ""
    except Exception as exc:
        return None, (
            f"wake word model failed to load even after downloading its files: {_short(exc)}"
        )


class AudioEngine:
    def __init__(
        self,
        settings: Settings,
        bus: EventBus,
        state: StateMachine,
        audio_in: asyncio.Queue[bytes],
        audio_out: asyncio.Queue[bytes],
        on_wake: Callable[[], None],
        on_interrupt: Callable[[], None],
        broadcast=None,          # AudioBroadcast: dashboard/phone listeners
        transcriber=None,        # LocalTranscriber for offline commands
        on_local_command=None,   # async callable(text) in LOCAL_ONLY mode
    ) -> None:
        self.settings = settings
        self.bus = bus
        self.state = state
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.on_wake = on_wake
        self.on_interrupt = on_interrupt
        self.broadcast = broadcast
        self.transcriber = transcriber
        self.on_local_command = on_local_command

        self.voice_available = False
        self.unavailable_reason = ""
        self._stop = asyncio.Event()
        self._mic_q: "thread_queue.Queue[bytes]" = thread_queue.Queue(maxsize=64)
        self._spk_q: "thread_queue.Queue[bytes]" = thread_queue.Queue(maxsize=256)
        self._wake_model = None
        self._in_stream = None
        self._out_stream = None
        self._capture: list[bytes] | None = None   # local-utterance recording
        self._capture_silent = 0

    # ------------------------------------------------------------------
    def probe(self) -> None:
        if not self.settings.voice_enabled:
            self.unavailable_reason = "voice disabled in settings"
            return
        if not _AUDIO_OK:
            self.unavailable_reason = (
                "audio packages not installed (pip install -r requirements-voice.txt)"
            )
            return
        try:
            devices = sd.query_devices()
        except Exception as exc:
            self.unavailable_reason = f"no audio backend: {type(exc).__name__}"
            return
        has_input = any(d.get("max_input_channels", 0) > 0 for d in devices)
        has_output = any(d.get("max_output_channels", 0) > 0 for d in devices)
        if not has_input or not has_output:
            self.unavailable_reason = "no microphone/speaker detected"
            return
        if not _WAKE_OK:
            self.unavailable_reason = "openwakeword not installed"
            return
        self.voice_available = True

    def list_devices(self) -> list[dict]:
        if not _AUDIO_OK:
            return []
        try:
            return [
                {
                    "index": i,
                    "name": d.get("name"),
                    "inputs": d.get("max_input_channels", 0),
                    "outputs": d.get("max_output_channels", 0),
                }
                for i, d in enumerate(sd.query_devices())
            ]
        except Exception:
            return []

    # ------------------------------------------------------------------
    async def run(self) -> None:
        self.probe()
        if not self.voice_available:
            log.warning("voice pipeline disabled: %s", self.unavailable_reason)
            self.bus.publish("audio_status", available=False, reason=self.unavailable_reason)
            # No sound card is needed for phone listening: keep draining
            # Gemini audio into the dashboard stream; otherwise stay dormant.
            while not self._stop.is_set():
                try:
                    pcm = await asyncio.wait_for(self.audio_out.get(), timeout=0.5)
                except asyncio.TimeoutError:
                    continue
                if self.broadcast is not None:
                    self.broadcast.publish(pcm)
            return

        self.bus.publish("audio_status", available=True, reason="")
        model_ref = self.settings.wake_word_model
        # Model load takes seconds -- keep it off the event loop so the
        # dashboard (same process) stays responsive during startup. The
        # helper also downloads the model FILES on first use: this is what
        # the old "wake model load failed (ValueError)" actually was.
        self._wake_model, load_error = await asyncio.to_thread(
            _load_wake_model_blocking, model_ref
        )
        if self._wake_model is None:
            log.error("wake word unavailable: %s; voice disabled", load_error)
            self.bus.publish("audio_status", available=False, reason=load_error)
            await self._stop.wait()
            return

        def mic_callback(indata, frames, t, status) -> None:
            # Audio callback: copy bytes into a bounded thread queue. Nothing else.
            try:
                self._mic_q.put_nowait(bytes(indata))
            except thread_queue.Full:
                pass

        def spk_callback(outdata, frames, t, status) -> None:
            needed = len(outdata)
            buf = b""
            while len(buf) < needed:
                try:
                    buf += self._spk_q.get_nowait()
                except thread_queue.Empty:
                    break
            if len(buf) < needed:
                buf += b"\x00" * (needed - len(buf))
            elif len(buf) > needed:
                # push the remainder back (front of queue order is close enough here)
                try:
                    self._spk_q.put_nowait(buf[needed:])
                except thread_queue.Full:
                    pass
                buf = buf[:needed]
            outdata[:] = buf

        in_kwargs: dict = dict(samplerate=IN_RATE, channels=1, dtype="int16", blocksize=CHUNK, callback=mic_callback)
        out_kwargs: dict = dict(samplerate=OUT_RATE, channels=1, dtype="int16", blocksize=0, callback=spk_callback)
        if self.settings.mic_device:
            in_kwargs["device"] = self.settings.mic_device
        if self.settings.speaker_device:
            out_kwargs["device"] = self.settings.speaker_device

        try:
            self._in_stream = sd.RawInputStream(**in_kwargs)
            self._out_stream = sd.RawOutputStream(**out_kwargs)
            self._in_stream.start()
            self._out_stream.start()
        except Exception as exc:
            log.error("audio streams failed: %s", type(exc).__name__)
            self.bus.publish("audio_status", available=False, reason="audio device error")
            await self._stop.wait()
            return

        pump = asyncio.create_task(self._playback_pump(), name="audio-playback-pump")
        try:
            await self._mic_loop()
        finally:
            pump.cancel()
            await asyncio.gather(pump, return_exceptions=True)
            for stream in (self._in_stream, self._out_stream):
                try:
                    stream.stop(); stream.close()
                except Exception:
                    pass

    async def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------------
    async def _playback_pump(self) -> None:
        """Move Gemini PCM from the asyncio queue into the speaker's thread
        queue and the dashboard/phone stream, honoring the output route."""
        while not self._stop.is_set():
            try:
                pcm = await asyncio.wait_for(self.audio_out.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            if self.broadcast is not None:
                self.broadcast.publish(pcm)
            if self.settings.audio_output_route == "phone":
                continue  # this computer stays silent by choice
            try:
                self._spk_q.put_nowait(pcm)
            except thread_queue.Full:
                pass

    def clear_playback(self) -> None:
        while True:
            try:
                self._spk_q.get_nowait()
            except thread_queue.Empty:
                break
        if self.broadcast is not None:
            self.broadcast.clear()

    def play_wav_bytes(self, pcm: bytes, rate: int, force_speaker: bool = False) -> None:
        """Used by the announcer for canned local messages. force_speaker
        makes alarms audible even when output is routed to the phone."""
        # normalize to OUT_RATE
        if rate != OUT_RATE:
            if _AUDIO_OK:
                arr = np.frombuffer(pcm, dtype=np.int16)
                idx = np.linspace(0, len(arr) - 1, int(len(arr) * OUT_RATE / max(rate, 1))).astype(np.int64)
                pcm = arr[idx].tobytes()
            else:
                from apps.audio.broadcast import resample_pcm16

                pcm = resample_pcm16(pcm, rate, OUT_RATE)
        if self.broadcast is not None:
            self.broadcast.publish(pcm)
        if not self.voice_available:
            return
        if self.settings.audio_output_route == "phone" and not force_speaker:
            return
        for i in range(0, len(pcm), 4800):
            try:
                self._spk_q.put_nowait(pcm[i : i + 4800])
            except thread_queue.Full:
                return

    async def _mic_loop(self) -> None:
        """Wake-word detection + streaming + interruption VAD."""
        wake_scores_needed = 1
        while not self._stop.is_set():
            try:
                chunk = await asyncio.to_thread(self._mic_q.get, True, 0.5)
            except thread_queue.Empty:
                continue

            if self.state.muted:
                self._capture = None  # muting aborts any local recording
                continue  # capture blocked by the emergency control

            st = self.state.raw_state

            # Recording a local-only utterance for offline transcription?
            if self._capture is not None:
                finished = self._capture_step(chunk)
                if finished is not None:
                    asyncio.create_task(self._finish_local_capture(b"".join(finished)))
                continue

            session_active = st in (ChatState.LISTENING, ChatState.SPEAKING, ChatState.CONNECTING)

            if session_active:
                if st == ChatState.SPEAKING and self._rms(chunk) > self.settings.interrupt_rms_threshold:
                    self.clear_playback()
                    self.on_interrupt()
                if st != ChatState.CONNECTING:
                    self._offer(self.audio_in, chunk)
                continue

            # Sleeping / local-only: run the wake detector.
            if self._wake_model is not None and _AUDIO_OK:
                arr = np.frombuffer(chunk, dtype=np.int16)
                try:
                    # Inference runs OFF the event loop: the dashboard shares
                    # this process, and a busy loop makes its pages hang.
                    scores = await asyncio.to_thread(self._wake_model.predict, arr)
                except Exception:
                    continue
                if scores and max(scores.values()) >= self.settings.wake_threshold:
                    if not self._wake_gate_open():
                        continue
                    st = self.state.raw_state  # refresh: may have changed during inference
                    wake_scores_needed -= 1
                    if wake_scores_needed <= 0:
                        wake_scores_needed = 1
                        self._wake_model.reset()
                        local_capture = (
                            st == ChatState.LOCAL_ONLY
                            and self.transcriber is not None
                            and getattr(self.transcriber, "available", False)
                            and self.on_local_command is not None
                        )
                        self.bus.publish(
                            "wake_word", mode="capture" if local_capture else "cloud"
                        )
                        if local_capture:
                            # offline: record the utterance, transcribe locally
                            self._capture = []
                            self._capture_silent = 0
                        else:
                            self.on_wake()

    def _wake_gate_open(self) -> bool:
        """May a wake hit act RIGHT NOW? Re-checked after inference: predict
        runs off-loop, so a mute click or a session start can land while it
        computes. The emergency mute must win that race."""
        if self._stop.is_set() or self.state.muted:
            return False
        return self.state.raw_state not in (
            ChatState.LISTENING,
            ChatState.SPEAKING,
            ChatState.CONNECTING,
        )

    def _capture_step(self, chunk: bytes) -> list[bytes] | None:
        """Accumulate one 80 ms chunk; returns the recording when done."""
        assert self._capture is not None
        self._capture.append(chunk)
        silence_floor = max(250, self.settings.interrupt_rms_threshold // 3)
        if self._rms(chunk) < silence_floor:
            self._capture_silent += 1
        else:
            self._capture_silent = 0
        long_enough = len(self._capture) >= 10            # ~0.8 s recorded
        ended = long_enough and self._capture_silent >= 10  # ~0.8 s of silence
        timed_out = len(self._capture) >= 100             # 8 s hard cap
        if ended or timed_out:
            captured = self._capture
            self._capture = None
            self._capture_silent = 0
            return captured
        return None

    async def _finish_local_capture(self, pcm: bytes) -> None:
        text = ""
        if self.transcriber is not None:
            try:
                text = await asyncio.to_thread(self.transcriber.transcribe, pcm, IN_RATE)
            except Exception as exc:
                log.warning("local transcription failed: %s", type(exc).__name__)
        if self.on_local_command is not None:
            try:
                await self.on_local_command(text)
            except Exception as exc:
                log.warning("local command handling failed: %s", type(exc).__name__)

    @staticmethod
    def _rms(chunk: bytes) -> float:
        if not _AUDIO_OK:
            return 0.0
        arr = np.frombuffer(chunk, dtype=np.int16)
        if arr.size == 0:
            return 0.0
        return float(np.sqrt(np.mean(arr.astype(np.float64) ** 2)))

    @staticmethod
    def _offer(q: asyncio.Queue, item: bytes) -> None:
        if q.full():
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            q.put_nowait(item)
        except asyncio.QueueFull:
            pass
