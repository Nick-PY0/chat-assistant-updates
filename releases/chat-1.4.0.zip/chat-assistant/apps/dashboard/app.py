"""Dashboard + authenticated management API (FastAPI).

Security baseline honored:
  * LAN/local binding only (configurable), optional HTTPS via local cert
  * Argon2id password, signed HttpOnly SameSite cookies, CSRF, login rate limit
  * No plaintext secret ever leaves the server; adds are validated then
    encrypted; UI shows only masked suffixes
  * Live status over Server-Sent Events
"""

from __future__ import annotations

import asyncio
import json
import secrets
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, Form, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from chat_core.net import lan_ip
from chat_core.runtime import Runtime
from chat_core.version import APP_VERSION
from chat_core.security.auth import (
    LoginRateLimiter,
    SessionManager,
    hash_password,
    verify_password,
)
from apps.tool_service.local_grammar import parse as parse_command
from integrations.gemini.errors import GeminiFailure
from integrations.gemini.validator import validate_key
from integrations.govee.client import GoveeClient, GoveeError
from integrations.openai_rt.validator import validate_openai_key
from integrations.relay.client import RelayClient, RelayError
from integrations.weather import WeatherError

BASE_DIR = Path(__file__).resolve().parent
COOKIE = "chat_session"


def create_app(rt: Runtime) -> FastAPI:
    app = FastAPI(title="Chat", docs_url=None, redoc_url=None, openapi_url=None)
    templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    limiter = LoginRateLimiter(rt.settings.login_max_attempts, rt.settings.login_window_seconds)
    https_on = bool(rt.settings.ssl_certfile and rt.settings.ssl_keyfile)

    # session secret: env wins, else generated once and stored
    async def session_mgr() -> SessionManager:
        if not hasattr(app.state, "sessions"):
            import os
            secret = os.environ.get("SESSION_SECRET") or await rt.db.get_setting("session_secret")
            if not secret:
                secret = secrets.token_hex(32)
                await rt.db.set_setting("session_secret", secret)
            app.state.sessions = SessionManager(secret, rt.settings.session_max_age_days * 86400)
        return app.state.sessions

    # -- auth plumbing ---------------------------------------------------
    async def current_session(request: Request) -> dict | None:
        sm = await session_mgr()
        return sm.validate(request.cookies.get(COOKIE))

    async def require_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        if await current_session(request) is None:
            return RedirectResponse("/login", status_code=303)
        return None

    async def require_api(request: Request) -> JSONResponse | None:
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        if request.method in ("POST", "PUT", "DELETE"):
            sm = await session_mgr()
            token = request.cookies.get(COOKIE)
            csrf = request.headers.get("x-csrf") or (await _form_csrf(request))
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
        return None

    async def _form_csrf(request: Request) -> str | None:
        if request.headers.get("content-type", "").startswith("application/x-www-form-urlencoded"):
            form = await request.form()
            value = form.get("_csrf")
            return value if isinstance(value, str) else None
        return None

    def same_site_ok(request: Request) -> bool:
        """Cross-site protection for the pre-auth forms (/setup, /login),
        which cannot rely on session-bound CSRF tokens. A hostile web page
        form-posting to this dashboard sends Origin and/or Sec-Fetch-Site
        headers that give it away; same-origin posts and non-browser tools
        pass."""
        origin = request.headers.get("origin")
        if origin and origin != "null":
            if urlparse(origin).netloc != request.headers.get("host", ""):
                return False
        elif origin == "null":
            return False
        fetch_site = request.headers.get("sec-fetch-site")
        if fetch_site and fetch_site.lower() == "cross-site":
            return False
        return True

    def is_loopback(request: Request) -> bool:
        """True when the request comes from this computer itself. First-time
        setup is restricted to loopback so a LAN device can never claim the
        admin password before the owner does."""
        host = request.client.host if request.client else ""
        return host.startswith("127.") or host in ("::1", "localhost")

    _lan_cache = {"ts": 0.0, "ip": ""}

    def dashboard_urls() -> dict:
        """Local + LAN URLs for 'open this on your phone' hints (cached)."""
        now = time.monotonic()
        if now - _lan_cache["ts"] > 60:
            _lan_cache["ip"] = lan_ip()
            _lan_cache["ts"] = now
        scheme = "https" if https_on else "http"
        port = rt.settings.dashboard_port
        urls = {"local": f"{scheme}://127.0.0.1:{port}"}
        if rt.settings.dashboard_host in ("0.0.0.0", "::") and _lan_cache["ip"]:
            urls["lan"] = f"{scheme}://{_lan_cache['ip']}:{port}"
        return urls

    async def page_ctx(request: Request, active: str) -> dict:
        sm = await session_mgr()
        token = request.cookies.get(COOKIE) or ""
        from dataclasses import asdict

        settings_public = asdict(rt.settings)
        settings_public.pop("extra", None)
        return {
            "request": request,
            "active": active,
            "csrf": sm.csrf_for(token) if token else "",
            "state": rt.state.snapshot(),
            "voice_ok": bool(rt.audio and rt.audio.voice_available),
            "voice_reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            "keychain_source": rt.master.source,
            "settings_json": json.dumps(settings_public),
            "app_version": APP_VERSION,
            "quiet": rt.quiet,
            "ringing": rt.ringing,
        }

    # -- setup & login -----------------------------------------------------
    @app.get("/setup", response_class=HTMLResponse)
    async def setup_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if not is_loopback(request):
            return HTMLResponse(
                "<p>First-time setup happens on the computer running Chat itself. "
                "Open the dashboard there (the console window shows the address), "
                "create the password, then sign in from this device.</p>",
                status_code=403,
            )
        return templates.TemplateResponse(request, "setup.html", {"request": request, "error": ""})

    @app.post("/setup")
    async def setup_submit(request: Request, password: str = Form(...), confirm: str = Form(...)):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        if not is_loopback(request):
            return JSONResponse(
                {"error": "first-time setup is only allowed on the computer running Chat"},
                status_code=403,
            )
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if len(password) < 8:
            return templates.TemplateResponse(
                request, "setup.html",
                {"request": request, "error": "Password must be at least 8 characters."},
            )
        if password != confirm:
            return templates.TemplateResponse(
                request, "setup.html", {"request": request, "error": "Passwords do not match."}
            )
        await rt.db.set_setting("admin_password_hash", hash_password(password))
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(
            COOKIE, sm.issue(), max_age=sm.max_age, httponly=True,
            samesite="strict", secure=https_on,
        )
        await rt.db.log("INFO", "dashboard", "admin password set")
        return resp

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        return templates.TemplateResponse(request, "login.html", {"request": request, "error": ""})

    @app.post("/login")
    async def login_submit(request: Request, password: str = Form(...)):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        ip = request.client.host if request.client else "unknown"
        if not limiter.check(ip):
            return templates.TemplateResponse(
                request, "login.html",
                {"request": request, "error": f"Too many attempts. Try again in {limiter.retry_in(ip) // 60 + 1} min."},
                status_code=429,
            )
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, password):
            limiter.record_failure(ip)
            await rt.db.log("WARNING", "dashboard", f"failed login from {ip}")
            return templates.TemplateResponse(
                request, "login.html", {"request": request, "error": "Wrong password."}, status_code=401
            )
        limiter.reset(ip)
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(
            COOKIE, sm.issue(), max_age=sm.max_age, httponly=True,
            samesite="strict", secure=https_on,
        )
        return resp

    @app.post("/logout")
    async def logout(request: Request):
        sm = await session_mgr()
        token = request.cookies.get(COOKIE)
        if sm.validate(token) is not None:
            csrf = await _form_csrf(request)
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
        resp = RedirectResponse("/login", status_code=303)
        resp.delete_cookie(COOKIE)
        return resp

    # -- pages ------------------------------------------------------------
    def page(route: str, template: str, name: str):
        @app.get(route, response_class=HTMLResponse, name=f"page_{name}")
        async def _page(request: Request):
            redirect = await require_page(request)
            if redirect:
                return redirect
            return templates.TemplateResponse(request, template, await page_ctx(request, name))
        return _page

    page("/", "status.html", "status")
    page("/credentials", "credentials.html", "credentials")
    page("/providers", "providers.html", "providers")
    page("/usage", "usage.html", "usage")
    page("/devices", "devices.html", "devices")
    page("/timers", "timers.html", "timers")
    page("/reminders", "reminders.html", "reminders")
    page("/memory", "memory.html", "memory")
    page("/logs", "logs.html", "logs")
    page("/settings", "settings.html", "settings")

    # -- live events (SSE) ---------------------------------------------------
    @app.get("/events")
    async def sse(request: Request):
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)

        async def stream():
            q = rt.bus.subscribe("*", maxsize=64)
            try:
                yield f"data: {json.dumps({'topic': 'state', **rt.state.snapshot()})}\n\n"
                while True:
                    try:
                        ev = await asyncio.wait_for(q.get(), timeout=25)
                        yield f"data: {json.dumps({'topic': ev.topic, **_jsonsafe(ev.data)})}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                rt.bus.unsubscribe(q)

        return StreamingResponse(stream(), media_type="text/event-stream")

    # -- state & health APIs ---------------------------------------------
    @app.get("/api/state")
    async def api_state(request: Request):
        err = await require_api(request)
        if err:
            return err
        health = await rt.db.fetchall("SELECT * FROM health ORDER BY component")
        eligible = 0
        if rt.gateway:
            eligible = await rt.gateway.rotation.eligible_count()
        retry_at = await rt.db.get_setting("quota_retry_at")
        return {
            "state": rt.state.snapshot(),
            "health": [dict(h) for h in health],
            "eligible_keys": eligible,
            "quota_retry_at": retry_at,
            "voice": {
                "available": bool(rt.audio and rt.audio.voice_available),
                "reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            },
            "keychain": rt.master.source,
            "uptime_seconds": int(time.time() - rt.started_at),
            "quiet": rt.quiet,
            "ringing": rt.ringing,
            "urls": dashboard_urls(),
        }

    # -- credentials -------------------------------------------------------
    @app.get("/api/credentials")
    async def api_credentials(request: Request):
        err = await require_api(request)
        if err:
            return err
        creds = await rt.store.list()
        groups: dict[str, dict] = {}
        for c in creds:
            if c.provider != "gemini":
                continue
            g = groups.setdefault(
                c.project_fingerprint,
                {"fingerprint": c.project_fingerprint, "label": c.project_label or "Ungrouped key", "keys": [], "exhausted_until": None},
            )
            g["keys"].append(c.public())
            if c.status == "exhausted" and c.retry_after:
                cur = g["exhausted_until"]
                iso_ra = c.retry_after.isoformat()
                g["exhausted_until"] = max(cur, iso_ra) if cur else iso_ra
        govee = [c.public() for c in creds if c.provider == "govee"]
        openai_keys = [c.public() for c in creds if c.provider == "openai"]
        relay_keys = [c.public() for c in creds if c.provider == "relay"]
        return {"projects": list(groups.values()), "govee": govee,
                "openai": openai_keys, "relay": relay_keys}

    @app.post("/api/credentials")
    async def api_add_credential(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        provider = str(body.get("provider", "gemini")).lower()
        secret = str(body.get("secret", "")).strip()
        label = str(body.get("project_label", "")).strip()[:60]
        if provider not in ("gemini", "govee", "openai", "relay"):
            return JSONResponse({"error": "provider must be gemini, govee, openai or relay"}, status_code=400)
        if len(secret) < 8 or len(secret) > 300 or any(ch.isspace() for ch in secret):
            return JSONResponse({"error": "that doesn't look like a valid key"}, status_code=400)

        warning = ""
        if provider == "gemini":
            try:
                await validate_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "Google rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "govee":
            try:
                await GoveeClient(secret).list_devices()
            except GoveeError as exc:
                if "rejected" in str(exc):
                    return JSONResponse({"error": "Govee rejected this key."}, status_code=400)
                warning = "saved without live validation (Govee unreachable)"
        elif provider == "openai":
            try:
                await validate_openai_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "OpenAI rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if relay_url:
                try:
                    await RelayClient(relay_url, secret).health()
                except RelayError as exc:
                    if "password" in str(exc):
                        return JSONResponse({"error": str(exc)}, status_code=400)
                    warning = f"saved without live validation ({exc})"
            else:
                warning = ("saved; set the relay address in Settings -> Brain "
                           "so it can be checked")

        cred = await rt.store.add(provider, secret, project_label=label)
        if provider == "gemini" and not warning:
            await rt.store.mark_validated(cred.id)
        rt.bus.publish("credentials_changed", added=cred.id)
        await rt.db.log("INFO", "credentials", f"added {provider} key {cred.masked_suffix}")
        # NOTE: the active connection is deliberately left untouched.
        return {"ok": True, "credential": cred.public(), "warning": warning}

    @app.post("/api/credentials/{cred_id}/action")
    async def api_credential_action(cred_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", ""))
        cred = await rt.store.get(cred_id)
        if cred is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        if action == "disable":
            await rt.store.set_status(cred_id, "disabled")
        elif action == "enable":
            await rt.store.set_status(cred_id, "standby")
        elif action == "make_active":
            if rt.gateway:
                await rt.gateway.rotation.promote(cred_id)
                rt.gateway.set_preferred(cred_id)
            else:
                await rt.store.set_status(cred_id, "active")
        elif action == "delete":
            await rt.store.remove(cred_id)
        elif action == "validate" and cred.provider == "gemini":
            try:
                await validate_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "openai":
            try:
                await validate_openai_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if not relay_url:
                return {"ok": False, "result": "set the relay address in Settings -> Brain first"}
            try:
                await RelayClient(relay_url, await rt.store.get_secret(cred_id)).health()
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except RelayError as exc:
                if "password" in str(exc):
                    await rt.store.set_status(cred_id, "invalid", "invalid")
                return {"ok": False, "result": str(exc)}
        else:
            return JSONResponse({"error": "unknown action"}, status_code=400)
        rt.bus.publish("credentials_changed", id=cred_id, action=action)
        await rt.db.log("INFO", "credentials", f"{action} on {cred.masked_suffix}")
        return {"ok": True}

    # -- timers ---------------------------------------------------------
    @app.get("/api/timers")
    async def api_timers(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {"timers": await rt.timers.list_timers()}

    @app.post("/api/timers")
    async def api_add_timer(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "start_timer",
            {"duration_seconds": body.get("duration_seconds"), "label": body.get("label", ""), "confirmed": True},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/timers/{timer_id}/{action}")
    async def api_timer_action(timer_id: str, action: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if action not in ("cancel", "pause", "resume"):
            return JSONResponse({"error": "unknown action"}, status_code=400)
        result = await rt.tools.dispatch("", f"{action}_timer", {"timer_id": timer_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- reminders & alarms -------------------------------------------------
    @app.get("/api/reminders")
    async def api_reminders(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {
            "reminders": await rt.reminders.list_reminders(include_recent=True),
            "ringing": rt.ringing,
        }

    @app.post("/api/reminders")
    async def api_add_reminder(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        time_str = str(body.get("time", "")).strip()   # "HH:MM", 24h
        date_str = str(body.get("date", "")).strip()   # optional "YYYY-MM-DD"
        try:
            hh, mm = (int(x) for x in time_str.split(":")[:2])
            if not (0 <= hh <= 23 and 0 <= mm <= 59):
                raise ValueError
        except ValueError:
            return JSONResponse({"error": "pick a time first"}, status_code=400)
        if date_str:
            at_local = f"{date_str}T{hh:02d}:{mm:02d}"
        else:
            now = datetime.now().astimezone()
            local = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if local <= now:
                local += timedelta(days=1)  # next time the clock shows it
            at_local = local.strftime("%Y-%m-%dT%H:%M")
        result = await rt.tools.dispatch(
            "", "set_reminder",
            {"message": str(body.get("message", "")),
             "kind": str(body.get("kind", "reminder")), "at_local": at_local},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/reminders/dismiss")
    async def api_dismiss_ring(request: Request):
        """Stop a ringing alarm/reminder (same as saying 'stop')."""
        err = await require_api(request)
        if err:
            return err
        rt.stop_output()
        return {"ok": True}

    @app.post("/api/reminders/{reminder_id}/cancel")
    async def api_cancel_reminder(reminder_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        result = await rt.tools.dispatch("", "cancel_reminder", {"ref": reminder_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- weather & quiet mode -------------------------------------------------
    @app.get("/api/weather")
    async def api_weather(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            return await rt.weather_tool.get(str(request.query_params.get("day", "today")))
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.get("/api/location/search")
    async def api_location_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            results = await rt.weather_tool.client.geocode(str(request.query_params.get("q", "")))
            return {"results": results}
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/quiet")
    async def api_quiet(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_quiet(bool(body.get("quiet")))
        return {"ok": True, "quiet": rt.quiet}

    # -- devices -----------------------------------------------------------
    @app.get("/api/devices")
    async def api_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            devices = await rt.tools.devices(refresh=bool(request.query_params.get("refresh")))
            return {"devices": devices}
        except GoveeError as exc:
            return {"devices": [], "error": str(exc)}

    # -- local command box -------------------------------------------------
    @app.post("/api/command")
    async def api_command(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        text = str(body.get("text", ""))[:200]
        cmd = parse_command(text)
        if cmd is None:
            return JSONResponse(
                {"error": "Not in the local grammar. Try: 'set a timer for ten minutes'."},
                status_code=400,
            )
        result = await rt.tools.dispatch("", cmd["tool"], cmd["args"])
        return {"command": cmd, "result": result}

    # -- usage & logs ---------------------------------------------------------
    @app.get("/api/usage")
    async def api_usage(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT u.ts, u.event, u.detail, c.masked_suffix, c.project_label "
            "FROM usage_log u LEFT JOIN credentials c ON c.id = u.credential_id "
            "ORDER BY u.id DESC LIMIT 200"
        )
        return {"usage": [dict(r) for r in rows]}

    @app.get("/api/logs")
    async def api_logs(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall("SELECT * FROM events_log ORDER BY id DESC LIMIT 300")
        return {"logs": [dict(r) for r in rows]}

    # -- settings & controls -----------------------------------------------
    @app.post("/api/mute")
    async def api_mute(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_muted(bool(body.get("muted")))
        return {"ok": True, "muted": rt.state.muted}

    @app.post("/api/settings")
    async def api_settings(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        editable = {
            "low_power": bool, "voice_enabled": bool, "wake_word_model": str,
            "wake_threshold": float, "inactivity_timeout_seconds": int,
            "gemini_model": str, "gemini_voice": str, "system_prompt": str,
            # brains
            "voice_brain": str, "openai_live_model": str, "openai_voice": str,
            "relay_url": str, "relay_chat_model": str, "relay_command_model": str,
            "relay_voice": str, "relay_daily_request_cap": int,
            "dashboard_host": str, "dashboard_port": int,
            "interrupt_rms_threshold": int,
            # audio routing, devices, offline voice
            "audio_output_route": str, "mic_device": str, "speaker_device": str,
            "vosk_model_path": str,
            # updates
            "update_url": str, "auto_update": bool,
            "update_require_signature": bool,
            # reminders, weather, quiet mode
            "alarm_ring_seconds": int, "alarm_volume": float,
            "quiet_override_alarms": bool, "weather_units": str,
            "location_name": str, "location_lat": float, "location_lon": float,
            # key rotation & quota behavior
            "rotation_enabled": bool, "rate_limit_rotate_after_failures": int,
            "unavailable_retry_seconds": int, "quota_reset_timezone": str,
            "quota_reset_jitter_seconds": int, "retry_window_backoff_seconds": int,
            # health checks
            "pulse_internet_interval": int, "pulse_govee_interval": int,
            "pulse_credential_interval": int, "pulse_timer_interval": int,
            "pulse_audio_idle_interval": int,
            # dashboard access
            "session_max_age_days": int, "login_max_attempts": int,
            "login_window_seconds": int, "log_level": str,
        }
        # 1) cast everything into a candidate dict — live settings untouched
        candidate: dict = {}
        for key, caster in editable.items():
            if key in body:
                try:
                    candidate[key] = caster(body[key])
                except (TypeError, ValueError):
                    return JSONResponse({"error": f"bad value for {key}"}, status_code=400)

        # 2) validate the candidate; a rejected save must change NOTHING
        if candidate.get("audio_output_route") not in (None, "speaker", "phone", "both"):
            candidate["audio_output_route"] = "speaker"
        if candidate.get("voice_brain") not in (None, "gemini", "openai_live", "relay"):
            candidate["voice_brain"] = "gemini"
        if "relay_daily_request_cap" in candidate:
            candidate["relay_daily_request_cap"] = max(0, int(candidate["relay_daily_request_cap"]))
        if candidate.get("relay_url"):
            fixed = str(candidate["relay_url"]).strip()
            if not fixed.startswith(("http://", "https://")):
                fixed = "https://" + fixed
            if fixed.startswith("http://"):
                return JSONResponse(
                    {"error": "the relay address must start with https:// "
                              "(plain http would expose the relay password)"},
                    status_code=400)
            candidate["relay_url"] = fixed
        if "quota_reset_timezone" in candidate:
            from zoneinfo import ZoneInfo
            try:
                ZoneInfo(candidate["quota_reset_timezone"])
            except Exception:
                return JSONResponse(
                    {"error": "unknown timezone (try America/Los_Angeles)"}, status_code=400
                )
        if "dashboard_port" in candidate and not (1 <= candidate["dashboard_port"] <= 65535):
            return JSONResponse({"error": "port must be 1-65535"}, status_code=400)
        if "wake_threshold" in candidate:
            candidate["wake_threshold"] = min(0.99, max(0.05, candidate["wake_threshold"]))
        if "log_level" in candidate:
            candidate["log_level"] = candidate["log_level"].upper()
            if candidate["log_level"] not in ("DEBUG", "INFO", "WARNING", "ERROR"):
                return JSONResponse({"error": "log level must be DEBUG/INFO/WARNING/ERROR"}, status_code=400)
        if "alarm_volume" in candidate:
            candidate["alarm_volume"] = min(1.0, max(0.2, candidate["alarm_volume"]))
        if "alarm_ring_seconds" in candidate:
            candidate["alarm_ring_seconds"] = min(600, candidate["alarm_ring_seconds"])
        if "weather_units" in candidate and candidate["weather_units"] not in ("celsius", "fahrenheit"):
            return JSONResponse({"error": "units must be celsius or fahrenheit"}, status_code=400)
        if "location_lat" in candidate and not -90 <= candidate["location_lat"] <= 90:
            return JSONResponse({"error": "latitude must be -90..90"}, status_code=400)
        if "location_lon" in candidate and not -180 <= candidate["location_lon"] <= 180:
            return JSONResponse({"error": "longitude must be -180..180"}, status_code=400)
        minimums = {
            "inactivity_timeout_seconds": 5, "interrupt_rms_threshold": 50,
            "rate_limit_rotate_after_failures": 1, "unavailable_retry_seconds": 0,
            "quota_reset_jitter_seconds": 0, "retry_window_backoff_seconds": 0,
            "pulse_internet_interval": 5, "pulse_govee_interval": 5,
            "pulse_credential_interval": 5, "pulse_timer_interval": 1,
            "pulse_audio_idle_interval": 5, "session_max_age_days": 1,
            "login_max_attempts": 1, "login_window_seconds": 10,
            "alarm_ring_seconds": 5,
        }
        for key, lo in minimums.items():
            if key in candidate and candidate[key] < lo:
                return JSONResponse({"error": f"{key} must be at least {lo}"}, status_code=400)

        # 3) apply atomically, then persist
        for key, value in candidate.items():
            setattr(rt.settings, key, value)
        changed = list(candidate)
        rt.settings.save()
        await rt.db.log("INFO", "settings", f"updated: {', '.join(changed) or 'nothing'}")

        # apply live where possible
        note = ""
        engine_keys = {"wake_word_model", "voice_enabled", "mic_device", "speaker_device", "vosk_model_path"}
        if engine_keys & set(changed):
            rt.schedule_audio_reload()
            note = "voice settings applied live"
        if {"dashboard_host", "dashboard_port"} & set(changed):
            note = "host/port change needs a restart"
        return {"ok": True, "changed": changed, "note": note}

    @app.post("/api/password")
    async def api_password(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        current, new = str(body.get("current", "")), str(body.get("new", ""))
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, current):
            return JSONResponse({"error": "current password is wrong"}, status_code=403)
        if len(new) < 8:
            return JSONResponse({"error": "new password must be at least 8 characters"}, status_code=400)
        await rt.db.set_setting("admin_password_hash", hash_password(new))
        return {"ok": True}

    @app.post("/api/wake")
    async def api_wake(request: Request):
        """Manual session trigger (useful before a wake-word model is set up)."""
        err = await require_api(request)
        if err:
            return err
        if rt.gateway is None:
            return JSONResponse({"error": "cloud gateway disabled"}, status_code=400)
        rt.gateway.request_session()
        return {"ok": True}

    @app.post("/api/stop")
    async def api_stop(request: Request):
        """Immediately silence all speech output."""
        err = await require_api(request)
        if err:
            return err
        rt.stop_output()
        return {"ok": True}

    # -- memory ------------------------------------------------------------
    @app.get("/api/memories")
    async def api_memories(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT id, content, source, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT 500"
        )
        return {"memories": [dict(r) for r in rows]}

    @app.post("/api/memories")
    async def api_add_memory(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "remember_fact", {"content": str(body.get("content", ""))[:600], "source": "dashboard"}
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/memories/{mem_id}/delete")
    async def api_delete_memory(mem_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        rt.bus.publish("memories_changed", action="deleted")
        return {"ok": True}

    # -- updates & restart ---------------------------------------------------
    @app.get("/api/update/status")
    async def api_update_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        return rt.updater.status() if rt.updater else {"error": "updater not running"}

    @app.post("/api/update/check")
    async def api_update_check(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.updater is None:
            return JSONResponse({"error": "updater not running"}, status_code=400)
        return await rt.updater.check_now()

    @app.post("/api/restart")
    async def api_restart(request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.log("INFO", "dashboard", "restart requested")
        rt.request_restart()
        return {"ok": True, "note": "Chat is restarting; this page will reconnect."}

    # -- audio devices & phone listening -------------------------------------
    @app.get("/api/audio/devices")
    async def api_audio_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        devices = {"inputs": [], "outputs": []}
        try:
            import sounddevice as sd

            for i, d in enumerate(sd.query_devices()):
                entry = {"index": i, "name": d["name"]}
                if d.get("max_input_channels", 0) > 0:
                    devices["inputs"].append(entry)
                if d.get("max_output_channels", 0) > 0:
                    devices["outputs"].append(entry)
        except Exception:
            pass  # no sound stack on this machine; lists stay empty
        return devices

    @app.websocket("/ws/audio")
    async def ws_audio(ws: WebSocket):
        """Streams Chat's output audio (PCM16 mono 24 kHz) to the browser."""
        sm = await session_mgr()
        if sm.validate(ws.cookies.get(COOKIE)) is None:
            await ws.close(code=4401)
            return
        await ws.accept()
        q = rt.broadcast.subscribe()

        async def sink_incoming():
            try:
                while True:
                    await ws.receive_text()  # keepalives from the browser
            except Exception:
                pass

        recv_task = asyncio.create_task(sink_incoming())
        try:
            while True:
                kind, payload = await q.get()
                if kind == "pcm":
                    await ws.send_bytes(payload)
                else:
                    await ws.send_text('{"type":"clear"}')
        except (WebSocketDisconnect, RuntimeError, ConnectionError):
            pass
        finally:
            rt.broadcast.unsubscribe(q)
            recv_task.cancel()

    return app


def _jsonsafe(data: dict) -> dict:
    out = {}
    for k, v in data.items():
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, (set, frozenset)):
            out[k] = sorted(v)
        else:
            out[k] = v
    return out
