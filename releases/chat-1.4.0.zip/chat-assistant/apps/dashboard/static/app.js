// Loaded from <head> (see base.html): api() and the helpers below must exist
// BEFORE the per-page inline scripts run, because those execute while the
// page is still being parsed. Anything that touches page elements is wired
// in wirePageChrome(), which waits for the DOM to be ready.
const csrf = document.querySelector('meta[name="csrf"]')?.content || "";

async function api(path, method = "GET", body = null) {
  const opts = { method, headers: { "x-csrf": csrf } };
  if (typeof AbortSignal !== "undefined" && AbortSignal.timeout)
    opts.signal = AbortSignal.timeout(20000); // never leave a button hanging forever
  if (body !== null) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  let resp;
  try {
    resp = await fetch(path, opts);
  } catch (e) {
    if (e && (e.name === "TimeoutError" || e.name === "AbortError"))
      throw new Error("No reply after 20 seconds -- Chat may be busy. Try again.");
    throw new Error("Could not reach Chat -- is it still running?");
  }
  let data = {};
  try { data = await resp.json(); } catch (e) { /* empty */ }
  if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
  return data;
}

function fmtSeconds(s) {
  s = Math.max(0, Math.floor(s));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return `${h}h ${m}m ${sec}s`;
  if (m) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function wirePageChrome() {
  // ---- phone navigation drawer ----
  const navToggle = document.getElementById("nav-toggle");
  const scrim = document.getElementById("scrim");
  if (navToggle) {
    navToggle.addEventListener("click", () => document.body.classList.toggle("nav-open"));
  }
  if (scrim) {
    scrim.addEventListener("click", () => document.body.classList.remove("nav-open"));
  }
  document.querySelectorAll(".nav nav a").forEach((a) =>
    a.addEventListener("click", () => document.body.classList.remove("nav-open")));

  // ---- quiet mode toggle ----
  const quietBtn = document.getElementById("quiet-btn");
  function setQuietUI(on) {
    if (quietBtn) {
      quietBtn.classList.toggle("on", on);
      quietBtn.textContent = on ? "Quiet mode ON" : "Quiet mode";
    }
    document.dispatchEvent(new CustomEvent("chat-quiet", { detail: { quiet: on } }));
  }
  if (quietBtn) {
    quietBtn.addEventListener("click", async () => {
      try {
        const r = await api("/api/quiet", "POST", { quiet: !quietBtn.classList.contains("on") });
        setQuietUI(r.quiet);
      } catch (e) { alert(e.message); }
    });
  }

  // ---- ringing banner (shown on every page while an alarm rings) ----
  const ringBanner = document.getElementById("ring-banner");
  const ringText = document.getElementById("ring-text");
  function showRing(data) {
    if (!ringBanner) return;
    const kind = data.kind === "alarm" ? "ALARM" : "Reminder";
    ringText.textContent = data.message ? `${kind}: ${data.message}` : `${kind} is ringing`;
    ringBanner.hidden = false;
  }
  async function syncRing() {
    if (!ringBanner || ringBanner.hidden) return;
    try {
      const s = await api("/api/state");
      if (s.ringing) showRing(s.ringing);
      else ringBanner.hidden = true;
    } catch (e) { /* signed out */ }
  }
  const ringDismiss = document.getElementById("ring-dismiss");
  if (ringDismiss) {
    ringDismiss.addEventListener("click", async () => {
      try { await api("/api/reminders/dismiss", "POST", {}); } catch (e) { /* signed out */ }
      ringBanner.hidden = true;
    });
  }

  // ---- mute button ----
  const muteBtn = document.getElementById("mute-btn");
  if (muteBtn) {
    muteBtn.addEventListener("click", async () => {
      const muted = !muteBtn.classList.contains("muted");
      try {
        await api("/api/mute", "POST", { muted });
        location.reload();
      } catch (e) { alert(e.message); }
    });
  }

  // ---- stop buttons (sidebar + phone topbar): silence Chat immediately ----
  for (const id of ["stop-btn", "stop-btn-top"]) {
    const btn = document.getElementById(id);
    if (!btn) continue;
    btn.addEventListener("click", async () => {
      try {
        btn.disabled = true;
        await api("/api/stop", "POST", {});
      } catch (e) { /* signed out */ }
      setTimeout(() => { btn.disabled = false; }, 400);
    });
  }

  // ---- live state via SSE ----
  const dots = [document.getElementById("state-dot"), document.getElementById("state-dot-top")].filter(Boolean);
  const label = document.getElementById("state-label");
  function startLiveEvents() {
    let es;
    try {
      es = new EventSource("/events");
    } catch (e) { return; /* SSE optional */ }
    es.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      if (msg.topic === "state") {
        dots.forEach((d) => { d.className = "brand-dot " + msg.state; });
        if (label) label.textContent = msg.state + (msg.degraded && msg.degraded.length ? " (degraded)" : "");
        document.dispatchEvent(new CustomEvent("chat-state", { detail: msg }));
      } else {
        if (msg.topic === "reminder_fired") showRing(msg);
        if (msg.topic === "reminders_changed") syncRing();
        if (msg.topic === "quiet_changed") setQuietUI(!!msg.quiet);
        document.dispatchEvent(new CustomEvent("chat-event", { detail: msg }));
      }
    };
  }
  // Connect only AFTER the page has fully loaded: a live stream opened during
  // load keeps some browsers showing "loading" forever (Esc seemed to fix it).
  if (dots.length) {
    if (document.readyState === "complete") setTimeout(startLiveEvents, 0);
    else window.addEventListener("load", () => setTimeout(startLiveEvents, 50));
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", wirePageChrome);
} else {
  wirePageChrome();
}
