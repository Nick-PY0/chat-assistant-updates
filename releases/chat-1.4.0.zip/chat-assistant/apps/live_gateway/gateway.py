"""Gemini Live gateway: session lifecycle + failover driver.

Owns the audio_in/audio_out queues shared with the audio engine and runs
the user's automatic cross-project rotation policy on every failure.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timedelta

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore, utcnow
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from apps.live_gateway.rotation import NoEligibleKey, RotationPolicy
from integrations.gemini.errors import (
    GeminiFailure,
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
    next_quota_reset,
)
from integrations.gemini.live_client import LiveSession
from integrations.openai_rt.live_client import RealtimeSession
from integrations.relay.client import RelayClient, RelayError
from apps.live_gateway.relay_session import RelayVoiceSession

log = logging.getLogger("gateway")

AUDIO_IN_MAX = 50    # ~4s of 80ms chunks; bounded so delays can't eat memory
AUDIO_OUT_MAX = 120

# Appended to the user's personality prompt so tool behavior survives edits.
PROMPT_TOOLS_SUFFIX = (
    " You have persistent memory tools: when the user asks you to remember something, call "
    "remember_fact with a short self-contained sentence; when they ask what you remember or "
    "about something they told you, call recall_memories and answer from the results; use "
    "forget_memory when asked to forget. If the user says stop, be quiet, or similar, call "
    "stop_speaking immediately and end your reply."
    " For times of day use set_reminder ('remind me at 5', 'wake me at 7 am' -> kind alarm); "
    "for durations use start_timer ('in ten minutes'). You may not know the current clock "
    "time, so pass the time parts exactly as the user said them and include am or pm ONLY "
    "if they said it -- the system picks the next matching time itself. After scheduling, "
    "confirm using the 'when' field of the result."
    " For weather questions call get_weather and answer briefly from its summary."
    " Call set_quiet_mode only when the user explicitly asks for quiet mode or do not "
    "disturb; quiet mode silences announcements but alarms still ring."
)


@dataclass
class FailureAction:
    """What _apply_failure decided for the rest of this conversation."""

    exclude_key: bool       # stop trying this key in this conversation
    avoid_project: bool     # skip the whole project group too


class LiveGateway:
    def __init__(
        self,
        settings: Settings,
        db: Database,
        store: CredentialStore,
        bus: EventBus,
        state: StateMachine,
        tool_declarations: list[dict],
        tool_handler,
    ) -> None:
        self.settings = settings
        self.db = db
        self.store = store
        self.bus = bus
        self.state = state
        self.rotation = RotationPolicy(store)
        self.tool_declarations = tool_declarations
        self.tool_handler = tool_handler

        self.audio_in: asyncio.Queue[bytes] = asyncio.Queue(maxsize=AUDIO_IN_MAX)
        self.audio_out: asyncio.Queue[bytes] = asyncio.Queue(maxsize=AUDIO_OUT_MAX)

        self._session: LiveSession | None = None
        self._session_task: asyncio.Task | None = None
        self._wanted = asyncio.Event()          # a wake word wants a session
        self._stop = asyncio.Event()
        self._preferred_id: str | None = None
        self._rate_limit_strikes: dict[str, int] = {}
        self._last_window_retry: datetime | None = None
        self.current_credential_id: str | None = None

    # -- public controls -------------------------------------------------
    def request_session(self) -> None:
        """Called by the audio engine when the wake word fires."""
        self._wanted.set()

    async def end_session(self, reason: str = "requested") -> None:
        if self._session:
            await self._session.close()
        self._wanted.clear()

    def set_preferred(self, cred_id: str | None) -> None:
        """Dashboard 'Make active': applies to the NEXT session; the
        current healthy connection is never interrupted."""
        self._preferred_id = cred_id

    def interrupt(self) -> None:
        """Local VAD says the user is talking over playback."""
        if self._session:
            self._session._drain_output()

    # -- main loop ---------------------------------------------------------
    async def run(self) -> None:
        credentials_changed = self.bus.subscribe("credentials_changed")
        retry_eligible = self.bus.subscribe("quota_retry_window")
        while not self._stop.is_set():
            # drain control topics without blocking
            for q in (credentials_changed, retry_eligible):
                while not q.empty():
                    ev = q.get_nowait()
                    if ev.topic == "quota_retry_window":
                        # one retry attempt per window, driven by the pulse
                        if self.state.raw_state == ChatState.LOCAL_ONLY:
                            self._wanted.set()
            try:
                await asyncio.wait_for(self._wanted.wait(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            self._wanted.clear()
            await self._run_conversation()

    async def stop(self) -> None:
        self._stop.set()
        await self.end_session("shutdown")

    # ----------------------------------------------------------------------
    async def _run_conversation(self) -> None:
        """One conversation: pick key, connect, converse, classify failures,
        rotate until success or nothing is eligible."""
        # The owner picks the brain in Settings. Google is the default; the
        # others fall back to Google for this conversation if they cannot
        # start, with the reason spelled out in the log.
        brain = getattr(self.settings, "voice_brain", "gemini")
        if brain == "openai_live":
            if await self._run_openai_live():
                return
        elif brain == "relay":
            if await self._run_relay():
                return

        tried: set[str] = set()
        avoid_projects: set[str] = set()

        while not self._stop.is_set():
            self.state.set(ChatState.CONNECTING, "selecting credential")
            try:
                cred = await self.rotation.pick(
                    exclude_ids=tried,
                    prefer_id=self._preferred_id,
                    avoid_fingerprints=avoid_projects,
                )
            except NoEligibleKey as exc:
                await self._enter_local_only(exc.earliest_retry)
                return

            try:
                secret = await self.store.get_secret(cred.id)
            except KeyError:
                tried.add(cred.id)
                continue

            self.current_credential_id = cred.id
            session = LiveSession(
                api_key=secret,
                model=self.settings.gemini_model,
                system_prompt=self.settings.system_prompt + PROMPT_TOOLS_SUFFIX,
                tool_declarations=self.tool_declarations,
                tool_handler=self.tool_handler,
                audio_in=self.audio_in,
                audio_out=self.audio_out,
                voice=self.settings.gemini_voice,
                inactivity_timeout=self.settings.inactivity_timeout_seconds,
            )
            session.on_speaking_change = self._on_speaking_change
            session.on_interrupted = lambda: self.bus.publish("interrupted")
            self._session = session
            del secret  # keep plaintext lifetime minimal

            try:
                self.state.set(ChatState.LISTENING, f"session on \u2022\u2022\u2022\u2022{cred.masked_suffix[-4:]}")
                await self.store.mark_success(cred.id)
                if cred.status != "active":
                    await self.rotation.promote(cred.id)
                await self.db.usage(cred.id, "session_start")
                self.bus.publish("session", status="open", credential=cred.masked_suffix)
                reason = await session.run()
                await self.db.usage(cred.id, "session_end", reason)
                self.bus.publish("session", status="closed", reason=reason)
                self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
                self._rate_limit_strikes.pop(cred.id, None)
                return
            except GeminiFailure as failure:
                await self.db.usage(cred.id, "session_failure", f"{failure.code}")
                await self.db.log("WARNING", "gateway", f"{cred.masked_suffix}: {failure.code}")
                action = await self._apply_failure(cred, failure)
                if action.exclude_key:
                    tried.add(cred.id)
                if action.avoid_project:
                    avoid_projects.add(cred.project_fingerprint)
                continue
            finally:
                self._session = None
                self.current_credential_id = None

    async def _apply_failure(self, cred, failure: GeminiFailure) -> FailureAction:
        """Update credential state per the rotation policy and decide how the
        conversation loop should proceed."""
        if failure.code == INVALID:
            await self.store.set_status(cred.id, "invalid", INVALID, None)
            self.bus.publish("credential_alert", id=cred.id, code=INVALID)
            return FailureAction(exclude_key=True, avoid_project=False)

        if failure.code == QUOTA_EXHAUSTED:
            # Policy: a spent project is ALWAYS blocked until the documented
            # reset (midnight in the configured quota timezone + jitter),
            # regardless of any provider-supplied retry timestamp.
            retry = next_quota_reset(
                self.settings.quota_reset_timezone,
                self.settings.quota_reset_jitter_seconds,
            )
            n = await self.store.mark_project_exhausted(cred.project_fingerprint, retry)
            self.bus.publish(
                "credential_alert", id=cred.id, code=QUOTA_EXHAUSTED, keys_blocked=n,
                retry_after=retry.isoformat(),
            )
            return FailureAction(exclude_key=True, avoid_project=True)

        if failure.code == RATE_LIMITED:
            strikes = self._rate_limit_strikes.get(cred.id, 0) + 1
            self._rate_limit_strikes[cred.id] = strikes
            if strikes < self.settings.rate_limit_rotate_after_failures:
                # brief same-key backoff, then RETRY THE SAME KEY
                delay = 5.0
                if failure.retry_after:
                    delay = max(1.0, min((failure.retry_after - utcnow()).total_seconds(), 60.0))
                await asyncio.sleep(delay)
                return FailureAction(exclude_key=False, avoid_project=False)
            self._rate_limit_strikes.pop(cred.id, None)
            retry = failure.retry_after or (utcnow() + timedelta(seconds=60))
            await self.store.set_status(cred.id, "unavailable", RATE_LIMITED, retry)
            return FailureAction(exclude_key=True, avoid_project=False)

        # UNAVAILABLE: brief backoff so the next key isn't hammered instantly,
        # block this key for a bounded window, then move on.
        await asyncio.sleep(min(self.settings.unavailable_retry_seconds, 30))
        await self.store.set_status(
            cred.id, "unavailable", UNAVAILABLE,
            utcnow() + timedelta(seconds=max(self.settings.unavailable_retry_seconds, 15) * 4),
        )
        return FailureAction(exclude_key=True, avoid_project=False)

    # -- the other brains ---------------------------------------------------
    @staticmethod
    def _brain_key_usable(cred, now) -> bool:
        """A key is worth trying if it isn't dead and isn't inside a backoff
        window. An expired window means: try again, re-mark if still broken."""
        if cred.status in ("invalid", "disabled"):
            return False
        if cred.retry_after and cred.retry_after > now:
            return False
        return True

    async def _run_openai_live(self) -> bool:
        """One conversation on the OpenAI live line. False means Google
        should take this conversation (the reason is already logged)."""
        now = utcnow()
        creds = [c for c in await self.store.list(provider="openai")
                 if self._brain_key_usable(c, now)]
        if not creds:
            await self.db.log(
                "WARNING", "gateway",
                "OpenAI brain is selected but no usable OpenAI key is saved "
                "(Providers page); using Google for this conversation")
            return False
        cred = creds[0]
        try:
            secret = await self.store.get_secret(cred.id)
        except KeyError:
            await self.db.log("WARNING", "gateway",
                              "the OpenAI key could not be unlocked; using Google instead")
            return False
        self.state.set(ChatState.CONNECTING, "openai live")
        session = RealtimeSession(
            api_key=secret,
            model=getattr(self.settings, "openai_live_model", "gpt-realtime"),
            system_prompt=self.settings.system_prompt + PROMPT_TOOLS_SUFFIX,
            tool_declarations=self.tool_declarations,
            tool_handler=self.tool_handler,
            audio_in=self.audio_in,
            audio_out=self.audio_out,
            voice=getattr(self.settings, "openai_voice", "alloy"),
            inactivity_timeout=self.settings.inactivity_timeout_seconds,
        )
        del secret
        session.on_speaking_change = self._on_speaking_change
        session.on_interrupted = lambda: self.bus.publish("interrupted")
        self._session = session
        self.current_credential_id = cred.id
        try:
            self.state.set(ChatState.LISTENING, "openai live session")
            await self.db.usage(cred.id, "session_start", "openai_live")
            reason = await session.run()
            await self.db.usage(cred.id, "session_end", reason)
            self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
            return True
        except GeminiFailure as failure:
            await self.db.usage(cred.id, "session_failure", failure.code)
            await self.db.log(
                "WARNING", "gateway",
                f"openai key {cred.masked_suffix}: {failure.code} -- {failure}; "
                "using Google for this conversation")
            await self._note_openai_failure(cred, failure)
            return False
        finally:
            self._session = None
            self.current_credential_id = None

    async def _note_openai_failure(self, cred, failure: GeminiFailure) -> None:
        """Reflect an OpenAI failure in the credential pill on the dashboard."""
        if failure.code == INVALID:
            await self.store.set_status(cred.id, "invalid", INVALID, None)
            self.bus.publish("credential_alert", id=cred.id, code=INVALID)
        elif failure.code == QUOTA_EXHAUSTED:
            await self.store.set_status(
                cred.id, "exhausted", QUOTA_EXHAUSTED, utcnow() + timedelta(hours=1))
        elif failure.code == RATE_LIMITED:
            await self.store.set_status(
                cred.id, "unavailable", RATE_LIMITED,
                failure.retry_after or (utcnow() + timedelta(seconds=60)))
        else:
            await self.store.set_status(
                cred.id, "unavailable", UNAVAILABLE,
                utcnow() + timedelta(seconds=max(self.settings.unavailable_retry_seconds, 15) * 4))

    async def _run_relay(self) -> bool:
        """One conversation through the relay. False = Google takes over."""
        url = (getattr(self.settings, "relay_url", "") or "").strip()
        if not url:
            await self.db.log(
                "WARNING", "gateway",
                "Relay brain is selected but no relay address is set "
                "(Settings page, Brain section); using Google for this conversation")
            return False
        secrets = [c for c in await self.store.list(provider="relay")
                   if self._brain_key_usable(c, utcnow())]
        if not secrets:
            await self.db.log(
                "WARNING", "gateway",
                "Relay brain is selected but no relay password is saved "
                "(Providers page); using Google for this conversation")
            return False
        try:
            password = await self.store.get_secret(secrets[0].id)
        except KeyError:
            await self.db.log("WARNING", "gateway",
                              "the relay password could not be unlocked; using Google instead")
            return False
        self.state.set(ChatState.CONNECTING, "relay")
        try:
            # Construction can refuse bad addresses (e.g. plain http), so it
            # lives inside the same net as the session itself.
            session = RelayVoiceSession(
                RelayClient(url, password), self.settings, self.db, self.bus, self.state,
                self.tool_declarations, self.tool_handler,
                self.audio_in, self.audio_out,
                on_speaking_change=self._on_speaking_change,
            )
            del password
            self._session = session
            reason = await session.run()
            self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
            return True
        except RelayError as exc:
            await self.db.usage(None, "session_failure", f"relay: {exc}")
            await self.db.log("WARNING", "gateway",
                              f"relay: {exc} Using Google for this conversation.")
            return False
        finally:
            self._session = None

    async def _enter_local_only(self, earliest_retry: datetime | None) -> None:
        self.state.set(ChatState.LOCAL_ONLY, "no eligible credential")
        quota_related = False
        for c in await self.store.list(provider="gemini"):
            if c.status == "exhausted":
                quota_related = True
                break
        self.bus.publish(
            "local_only",
            quota=quota_related,
            retry_at=earliest_retry.isoformat() if earliest_retry else None,
        )
        if earliest_retry:
            await self.db.set_setting("quota_retry_at", earliest_retry.isoformat())
        await self.db.log(
            "WARNING",
            "gateway",
            "entering local-only mode"
            + (f"; retry at {earliest_retry.isoformat()}" if earliest_retry else ""),
        )

    def _on_speaking_change(self, speaking: bool) -> None:
        if speaking:
            self.state.set(ChatState.SPEAKING, "model audio")
        else:
            self.state.set(ChatState.LISTENING, "turn complete")
