"""Walkie-talkie voice sessions through the owner's relay.

One turn = record the sentence, write it down, ask the chosen model (running
any tools it requests), and speak the answer back. Slower and less fluid than
the live lines, but it rides Replit credits instead of a Google or OpenAI
account, and it can switch models per task.

The conversation lives entirely on the laptop: the relay sees one turn at a
time and keeps nothing.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import time

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from chat_core.pcm import resample_linear, rms16
from integrations.relay.client import RelayClient, RelayError

log = logging.getLogger("relay.session")

MIC_RATE = 16000
OUT_RATE = 24000
CHUNK_SECONDS = 0.08           # what the mic loop delivers
MAX_TOOL_HOPS = 4              # tool-call round trips per turn
HISTORY_LIMIT = 16             # messages kept between turns (cost control)

# Short household commands go to the cheap model; everything else gets the
# smarter one. Deliberately simple and inspectable.
_COMMAND_RE = re.compile(
    r"\b(timer|timers|remind|reminder|alarm|light|lights|lamp|quiet|mute|"
    r"stop|cancel|pause|resume|weather|temperature|forecast|time|date)\b",
    re.IGNORECASE,
)


def to_chat_tools(declarations: list[dict]) -> list[dict]:
    """Gemini-style tool schemas -> chat-completions `tools` array."""

    def fix_types(node):
        if isinstance(node, dict):
            return {
                key: (value.lower() if key == "type" and isinstance(value, str)
                      else fix_types(value))
                for key, value in node.items()
            }
        if isinstance(node, list):
            return [fix_types(item) for item in node]
        return node

    return [{
        "type": "function",
        "function": {
            "name": decl.get("name", ""),
            "description": decl.get("description", ""),
            "parameters": fix_types(decl.get("parameters") or {"type": "object", "properties": {}}),
        },
    } for decl in declarations]


class _CapReached(Exception):
    """Raised the moment the daily spend guard trips, even mid-turn."""


class RelayVoiceSession:
    """One conversation (possibly several back-and-forth turns)."""

    def __init__(
        self,
        client: RelayClient,
        settings: Settings,
        db: Database,
        bus: EventBus,
        state: StateMachine,
        tool_declarations: list[dict],
        tool_handler,
        audio_in: asyncio.Queue,
        audio_out: asyncio.Queue,
        on_speaking_change=None,
    ) -> None:
        self.client = client
        self.settings = settings
        self.db = db
        self.bus = bus
        self.state = state
        self.tools = to_chat_tools(tool_declarations)
        self.tool_handler = tool_handler
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.on_speaking_change = on_speaking_change

        self._closing = asyncio.Event()
        self._interrupted = asyncio.Event()
        self._history: list[dict] = []

    # -- the interface the gateway expects ------------------------------
    async def close(self, reason: str = "stopped") -> None:
        self._closing.set()

    def _drain_output(self) -> None:
        """Called when the user talks over playback."""
        self._interrupted.set()
        try:
            while True:
                self.audio_out.get_nowait()
        except asyncio.QueueEmpty:
            pass
        # Also drop the mic audio that piled up behind the playback, so the
        # next capture starts from silence instead of stale sound.
        self._drain_input()

    def _drain_input(self) -> None:
        try:
            while True:
                self.audio_in.get_nowait()
        except asyncio.QueueEmpty:
            pass

    # -- helpers ---------------------------------------------------------
    def _silence_floor(self) -> float:
        return max(250.0, self.settings.interrupt_rms_threshold / 3)

    async def _over_daily_cap(self) -> bool:
        cap = int(getattr(self.settings, "relay_daily_request_cap", 0) or 0)
        if cap <= 0:
            return False
        row = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM usage_log "
            "WHERE event LIKE 'relay:%' AND ts >= date('now')",
        )
        return bool(row and row["n"] >= cap)

    async def _require_spend(self) -> None:
        """Checked before EVERY paid relay call, not just at turn start --
        a single turn can be transcribe + several asks + speak."""
        if await self._over_daily_cap():
            raise _CapReached()

    async def _capture_utterance(self) -> bytes | None:
        """Record one sentence from the mic queue. None = nobody spoke."""
        floor = self._silence_floor()
        chunks: list[bytes] = []
        silent = 0
        heard_any = False
        started = time.monotonic()
        last_chunk = started
        timeout = float(self.settings.inactivity_timeout_seconds)
        while not self._closing.is_set():
            try:
                chunk = await asyncio.wait_for(self.audio_in.get(), timeout=0.5)
            except asyncio.TimeoutError:
                if not heard_any and time.monotonic() - started > timeout:
                    return None
                if heard_any and time.monotonic() - last_chunk > 2.0:
                    break  # mic feed hiccup mid-sentence; use what we have
                continue
            last_chunk = time.monotonic()
            loud = rms16(chunk) >= floor
            if not heard_any:
                if time.monotonic() - started > timeout:
                    return None
                if not loud:
                    continue  # still waiting for the first word
                heard_any = True
            chunks.append(chunk)
            silent = silent + 1 if not loud else 0
            long_enough = len(chunks) >= 10               # ~0.8 s of speech
            if long_enough and silent >= 10:              # ~0.8 s of quiet
                break
            if len(chunks) >= int(20 / CHUNK_SECONDS):    # 20 s hard cap
                break
        if self._closing.is_set() or not chunks:
            return None
        return b"".join(chunks)

    def _pick_model(self, text: str) -> str:
        if _COMMAND_RE.search(text):
            return self.settings.relay_command_model
        return self.settings.relay_chat_model

    async def _think(self, text: str) -> str:
        """One ask() exchange, running tools until the model settles."""
        model = self._pick_model(text)
        self._history.append({"role": "user", "content": text})
        messages = [{"role": "system", "content": self.settings.system_prompt
                     + " Reply in one or two short spoken sentences."}]
        messages += self._history[-HISTORY_LIMIT:]

        for _hop in range(MAX_TOOL_HOPS):
            await self._require_spend()
            data = await self.client.ask(messages, self.tools, model)
            usage = data.get("usage") or {}
            await self.db.usage(None, "relay:ask", f"{data.get('model', model)} "
                                f"in={usage.get('prompt_tokens', '?')} out={usage.get('completion_tokens', '?')}")
            calls = data.get("tool_calls") or []
            reply = str(data.get("reply") or "").strip()
            if not calls:
                if not reply:  # e.g. a reasoning model spent its whole budget thinking
                    reply = "Sorry, I came up empty on that one. Try asking again."
                self._history.append({"role": "assistant", "content": reply})
                return reply
            # The model wants tools: run them, then let it finish the thought.
            messages.append({"role": "assistant", "content": reply or None,
                             "tool_calls": calls})
            for call in calls:
                fn = call.get("function") or {}
                name = str(fn.get("name", ""))
                call_id = str(call.get("id", ""))
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except ValueError:
                    args = {}
                try:
                    result = await self.tool_handler(call_id, name, args)
                except Exception as exc:  # sanitized, like the live brains
                    result = {"error": type(exc).__name__}
                messages.append({"role": "tool", "tool_call_id": call_id,
                                 "content": json.dumps(result)})
        self._history.append({"role": "assistant", "content": "(tool loop cut short)"})
        return "I got stuck using my tools on that one."

    async def _speak(self, text: str) -> None:
        if not text:
            return
        await self._require_spend()
        pcm, rate = await self.client.speak(text, getattr(self.settings, "relay_voice", "alloy"))
        await self.db.usage(None, "relay:speak", f"{len(text)} chars")
        if rate != OUT_RATE:
            pcm = resample_linear(pcm, rate, OUT_RATE)
        self._interrupted.clear()
        if self.on_speaking_change:
            self.on_speaking_change(True)
        try:
            step = OUT_RATE * 2 // 5  # 200 ms slices keep interruption snappy
            for i in range(0, len(pcm), step):
                if self._interrupted.is_set() or self._closing.is_set():
                    break
                try:
                    self.audio_out.put_nowait(pcm[i:i + step])
                except asyncio.QueueFull:
                    await asyncio.sleep(0.2)
            # wait roughly until playback finishes (or the user cuts in)
            seconds = len(pcm) / 2 / OUT_RATE
            waited = 0.0
            while waited < seconds and not self._interrupted.is_set() and not self._closing.is_set():
                await asyncio.sleep(0.1)
                waited += 0.1
        finally:
            if self.on_speaking_change:
                self.on_speaking_change(False)

    # -- main ------------------------------------------------------------
    async def run(self) -> str:
        """Converse until silence or shutdown. Raises RelayError on trouble."""
        await self.client.health()  # fail fast with a clear sentence
        try:
            while not self._closing.is_set():
                await self._require_spend()
                self.state.set(ChatState.LISTENING, "relay: listening")
                pcm = await self._capture_utterance()
                if pcm is None:
                    return "inactivity"
                self.state.set(ChatState.LISTENING, "relay: writing it down")
                await self._require_spend()
                text = await self.client.transcribe(pcm)
                await self.db.usage(None, "relay:transcribe", f"{len(pcm) // 2 // MIC_RATE}s")
                if not text:
                    continue  # heard noise, not words; keep listening
                self.state.set(ChatState.LISTENING, "relay: thinking")
                reply = await self._think(text)
                self.state.set(ChatState.SPEAKING, "relay: speaking")
                await self._speak(reply)
                # Playback is done: whatever the mic queued up meanwhile is
                # echo and room noise, not the next question.
                self._drain_input()
            return "stopped"
        except _CapReached:
            await self.db.log(
                "WARNING", "relay",
                "daily relay limit reached; staying quiet until tomorrow "
                "(raise it in Settings -> Brain if this is too strict)")
            return "daily relay limit reached"
