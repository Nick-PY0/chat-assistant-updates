"""Tool allowlist: typed schemas shared by Gemini function calling and the
local dispatcher. Gemini supplies structured arguments only -- there is no
shell tool and no URL-fetch tool, by design."""

from __future__ import annotations

MAX_TIMER_SECONDS = 12 * 3600          # confirm anything longer
CONFIRM_TIMER_SECONDS = 4 * 3600

TOOL_DECLARATIONS: list[dict] = [
    {
        "name": "start_timer",
        "description": "Start a countdown timer.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "duration_seconds": {"type": "INTEGER", "description": "Duration in seconds (1..43200)"},
                "label": {"type": "STRING", "description": "Short label like 'kitchen' or 'laundry'"},
            },
            "required": ["duration_seconds"],
        },
    },
    {
        "name": "list_timers",
        "description": "List active and paused timers.",
        "parameters": {"type": "OBJECT", "properties": {}},
    },
    {
        "name": "cancel_timer",
        "description": "Cancel a timer by id or label.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"timer_id": {"type": "STRING", "description": "Timer id or label"}},
            "required": ["timer_id"],
        },
    },
    {
        "name": "pause_timer",
        "description": "Pause a running timer by id or label.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"timer_id": {"type": "STRING"}},
            "required": ["timer_id"],
        },
    },
    {
        "name": "resume_timer",
        "description": "Resume a paused timer by id or label.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"timer_id": {"type": "STRING"}},
            "required": ["timer_id"],
        },
    },
    {
        "name": "set_govee_power",
        "description": "Turn a light on or off.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "device": {"type": "STRING", "description": "Device name as shown in the device list"},
                "state": {"type": "STRING", "description": "'on' or 'off'"},
            },
            "required": ["device", "state"],
        },
    },
    {
        "name": "set_govee_brightness",
        "description": "Set light brightness 0-100.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "device": {"type": "STRING"},
                "percentage": {"type": "INTEGER"},
            },
            "required": ["device", "percentage"],
        },
    },
    {
        "name": "set_govee_color",
        "description": "Set light color by name or #RRGGBB.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "device": {"type": "STRING"},
                "color": {"type": "STRING"},
            },
            "required": ["device", "color"],
        },
    },
    {
        "name": "activate_govee_scene",
        "description": "Activate a light scene by name.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "device": {"type": "STRING"},
                "scene": {"type": "STRING"},
            },
            "required": ["device", "scene"],
        },
    },
    {
        "name": "get_govee_status",
        "description": "Get the current state of a light.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"device": {"type": "STRING"}},
            "required": ["device"],
        },
    },
    {
        "name": "remember_fact",
        "description": (
            "Save a fact to persistent long-term memory. Use when the user asks you to "
            "remember something. Store one short, self-contained sentence."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "content": {"type": "STRING", "description": "The fact to remember, e.g. 'The wifi password is on the fridge'"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "recall_memories",
        "description": (
            "Search persistent memory. Use when the user asks what you remember or about "
            "something they previously told you. Empty query returns the most recent facts."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {"type": "STRING", "description": "Words to search for; empty for the latest facts"},
            },
        },
    },
    {
        "name": "forget_memory",
        "description": "Delete matching facts from persistent memory when the user asks you to forget something.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query": {"type": "STRING", "description": "Words identifying the fact(s) to delete"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "stop_speaking",
        "description": (
            "Immediately stop all speech output. Call this the moment the user says stop, "
            "be quiet, shut up, or similar. Do not continue the previous answer afterwards."
        ),
        "parameters": {"type": "OBJECT", "properties": {}},
    },
    {
        "name": "set_reminder",
        "description": (
            "Schedule a reminder or alarm at a CLOCK TIME ('at 5', 'at 7:30 pm', 'tomorrow "
            "at 8'). Not for countdowns -- use start_timer for 'in ten minutes'. Pass the "
            "time exactly as the user said it; only include am/pm if they said it (the "
            "system resolves ambiguity deterministically)."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "hour": {"type": "INTEGER", "description": "Hour as spoken: 1-12, or 0-23"},
                "minute": {"type": "INTEGER", "description": "Minutes; 0 if not said"},
                "ampm": {"type": "STRING", "description": "'am', 'pm', or '' if the user didn't say"},
                "day": {"type": "STRING", "description": "'', 'today', 'tonight', 'tomorrow', or YYYY-MM-DD"},
                "message": {"type": "STRING", "description": "What to announce, e.g. 'take the chicken out'"},
                "kind": {"type": "STRING", "description": "'alarm' for wake-up ringing, otherwise 'reminder'"},
            },
            "required": ["hour"],
        },
    },
    {
        "name": "list_reminders",
        "description": "List scheduled reminders and alarms with their times.",
        "parameters": {"type": "OBJECT", "properties": {}},
    },
    {
        "name": "cancel_reminder",
        "description": "Cancel a scheduled reminder or alarm by its message words, or 'alarm'/'reminder'.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"ref": {"type": "STRING", "description": "Message words, id, 'alarm', or 'reminder'"}},
        },
    },
    {
        "name": "get_weather",
        "description": (
            "Current conditions and forecast for the user's saved home town. "
            "Use day='tomorrow' for tomorrow, otherwise 'today'. Answer briefly and naturally."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {"day": {"type": "STRING", "description": "'today' or 'tomorrow'"}},
        },
    },
    {
        "name": "set_quiet_mode",
        "description": (
            "Turn quiet mode on or off, ONLY when the user explicitly asks (e.g. 'quiet mode "
            "on', 'do not disturb', 'you can talk again'). Quiet mode silences Chat's "
            "spontaneous announcements; alarms and timers still ring by default."
        ),
        "parameters": {
            "type": "OBJECT",
            "properties": {"enabled": {"type": "BOOLEAN"}},
            "required": ["enabled"],
        },
    },
]
