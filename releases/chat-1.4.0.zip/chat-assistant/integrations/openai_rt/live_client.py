"""OpenAI Realtime WebSocket session: the interrupt-anytime live voice line.

Mirrors integrations/gemini/live_client.py on purpose -- same constructor
shape, same queues, same callbacks -- so the gateway can drive either brain
without caring which company is on the other end.

Audio: the mic feeds 16 kHz PCM16 chunks; OpenAI expects 24 kHz, so chunks
are upsampled on the way out. Replies arrive as 24 kHz PCM16, which is
exactly what the speaker path already plays.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
from typing import Any, Awaitable, Callable

import websockets

from chat_core.pcm import resample_linear
from integrations.openai_rt.errors import (
    ProviderFailure,
    classify_error_event,
    classify_openai,
)

log = logging.getLogger("openai.live")

HOST = "api.openai.com"
IN_RATE = 16000       # what the mic path delivers
WIRE_RATE = 24000     # what the realtime API speaks, both directions

# Error codes inside `error` events that are chatter, not failures.
_BENIGN_ERROR_MARKERS = (
    "cancellation failed",          # we cancelled a response that already ended
    "no active response",
    "already has an active response",
    "buffer too small",             # commit raced VAD; harmless
)

ToolHandler = Callable[[str, str, dict], Awaitable[dict]]


def resample_16k_to_24k(pcm: bytes) -> bytes:
    """Mic-rate chunks -> wire-rate chunks."""
    return resample_linear(pcm, IN_RATE, WIRE_RATE)


def to_openai_tools(declarations: list[dict]) -> list[dict]:
    """Convert Chat's Gemini-style tool schemas to realtime `session.tools`."""

    def fix_types(node: Any) -> Any:
        if isinstance(node, dict):
            fixed = {}
            for key, value in node.items():
                if key == "type" and isinstance(value, str):
                    fixed[key] = value.lower()
                else:
                    fixed[key] = fix_types(value)
            return fixed
        if isinstance(node, list):
            return [fix_types(item) for item in node]
        return node

    tools = []
    for decl in declarations:
        tools.append({
            "type": "function",
            "name": decl.get("name", ""),
            "description": decl.get("description", ""),
            "parameters": fix_types(decl.get("parameters") or {"type": "object", "properties": {}}),
        })
    return tools


class RealtimeSession:
    """One live voice conversation over the OpenAI Realtime API."""

    def __init__(
        self,
        api_key: str,
        model: str,
        system_prompt: str,
        tool_declarations: list[dict],
        tool_handler: ToolHandler,
        audio_in: asyncio.Queue[bytes],
        audio_out: asyncio.Queue[bytes],
        voice: str = "alloy",
        inactivity_timeout: float = 75.0,
        url: str | None = None,
    ) -> None:
        self._key = api_key
        self.model = model
        self.system_prompt = system_prompt
        self.tools = to_openai_tools(tool_declarations)
        self.tool_handler = tool_handler
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.voice = voice
        self.inactivity_timeout = inactivity_timeout
        self._url = url or f"wss://{HOST}/v1/realtime?model={model}"

        self.on_speaking_change: Callable[[bool], None] | None = None
        self.on_interrupted: Callable[[], None] | None = None

        self._closing = asyncio.Event()
        self._last_activity = time.monotonic()
        self._response_active = False

    # ------------------------------------------------------------------
    async def run(self) -> str:
        """Run until closed. Returns a close reason. Raises ProviderFailure."""
        headers = {
            "Authorization": f"Bearer {self._key}",
            "OpenAI-Beta": "realtime=v1",
        }
        try:
            async with websockets.connect(
                self._url,
                additional_headers=headers,
                max_size=2**22,
                close_timeout=3,
            ) as ws:
                await self._send(ws, self._session_update())
                sender = asyncio.create_task(self._sender(ws), name="rt-sender")
                watchdog = asyncio.create_task(self._watchdog(ws), name="rt-watchdog")
                try:
                    return await self._receiver(ws)
                finally:
                    for task in (sender, watchdog):
                        task.cancel()
                    await asyncio.gather(sender, watchdog, return_exceptions=True)
        except ProviderFailure:
            raise
        except websockets.exceptions.InvalidStatus as exc:  # HTTP-level rejection
            resp = getattr(exc, "response", None)
            status = getattr(resp, "status_code", None)
            raw = getattr(resp, "body", b"") or b""
            body = raw.decode("utf-8", "replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
            raise classify_openai(status, body) from exc
        except websockets.exceptions.ConnectionClosedOK:
            return "closed"
        except websockets.exceptions.ConnectionClosedError as exc:
            reason = getattr(exc, "reason", "") or str(exc)
            raise classify_openai(None, reason) from exc
        except OSError as exc:
            raise classify_openai(None, f"connection failure: {exc}") from exc

    async def close(self, reason: str = "stopped") -> None:
        self._closing.set()

    # ------------------------------------------------------------------
    def _session_update(self) -> dict:
        return {
            "type": "session.update",
            "session": {
                "modalities": ["text", "audio"],
                "instructions": self.system_prompt,
                "voice": self.voice,
                "input_audio_format": "pcm16",
                "output_audio_format": "pcm16",
                "turn_detection": {"type": "server_vad"},
                "tools": self.tools,
                "tool_choice": "auto",
            },
        }

    @staticmethod
    async def _send(ws: Any, message: dict) -> None:
        await ws.send(json.dumps(message))

    @staticmethod
    def _parse(raw: Any) -> dict | None:
        try:
            msg = json.loads(raw)
            return msg if isinstance(msg, dict) else None
        except (ValueError, TypeError):
            return None

    async def _sender(self, ws: Any) -> None:
        """Mic chunks -> upsample -> base64 append events."""
        while not self._closing.is_set():
            try:
                chunk = await asyncio.wait_for(self.audio_in.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            payload = base64.b64encode(resample_16k_to_24k(chunk)).decode()
            await self._send(ws, {"type": "input_audio_buffer.append", "audio": payload})

    async def _watchdog(self, ws: Any) -> None:
        """Close the session after a stretch of silence, like Gemini's."""
        while True:
            await asyncio.sleep(2)
            if self._closing.is_set():
                await ws.close()
                return
            idle = time.monotonic() - self._last_activity
            if idle >= self.inactivity_timeout and not self._response_active:
                log.info("closing after %.0fs of inactivity", idle)
                await ws.close()
                return

    def _offer_output(self, data: bytes) -> None:
        try:
            self.audio_out.put_nowait(data)
        except asyncio.QueueFull:
            pass  # speaker is behind; dropping is better than stalling the socket

    def _drain_output(self) -> None:
        try:
            while True:
                self.audio_out.get_nowait()
        except asyncio.QueueEmpty:
            pass

    async def _receiver(self, ws: Any) -> str:
        speaking = False

        def set_speaking(value: bool) -> None:
            nonlocal speaking
            if speaking != value and self.on_speaking_change:
                self.on_speaking_change(value)
            speaking = value

        async for raw in ws:
            if self._closing.is_set():
                return "stopped"
            msg = self._parse(raw)
            if msg is None:
                continue
            kind = str(msg.get("type", ""))
            self._last_activity = time.monotonic()

            # --- audio out (event was renamed between API revisions) ---
            if kind in ("response.audio.delta", "response.output_audio.delta"):
                data = msg.get("delta") or ""
                if data:
                    set_speaking(True)
                    self._offer_output(base64.b64decode(data))

            elif kind == "input_audio_buffer.speech_started":
                # The user started talking: stop playing, tell the model.
                self._drain_output()
                if self.on_interrupted:
                    self.on_interrupted()
                set_speaking(False)
                if self._response_active:
                    await self._send(ws, {"type": "response.cancel"})

            elif kind == "response.created":
                self._response_active = True

            elif kind == "response.done":
                self._response_active = False
                set_speaking(False)

            elif kind in ("response.function_call_arguments.done",):
                call_id = str(msg.get("call_id", ""))
                name = str(msg.get("name", ""))
                try:
                    args = json.loads(msg.get("arguments") or "{}")
                except ValueError:
                    args = {}
                try:
                    result = await self.tool_handler(call_id, name, args)
                except Exception as exc:  # tool errors go back to the model, sanitized
                    result = {"error": type(exc).__name__}
                await self._send(ws, {
                    "type": "conversation.item.create",
                    "item": {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": json.dumps(result),
                    },
                })
                await self._send(ws, {"type": "response.create"})

            elif kind == "error":
                err = msg.get("error") or {}
                text = " ".join(str(err.get(k, "")) for k in ("code", "message")).strip().lower()
                if any(marker in text for marker in _BENIGN_ERROR_MARKERS):
                    log.debug("benign realtime error: %s", text)
                    continue
                raise classify_error_event(msg)

        return "closed"
