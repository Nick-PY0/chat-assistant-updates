"""Gemini Live WebSocket session.

Streams 16 kHz 16-bit PCM up, receives 24 kHz 16-bit PCM down, handles
tool calls and interruption events. Audio bytes move through dedicated
bounded asyncio queues -- never through the event bus.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
from typing import Any, Awaitable, Callable

import websockets

from integrations.gemini.errors import GeminiFailure, classify

log = logging.getLogger("gemini.live")

HOST = "generativelanguage.googleapis.com"
PATH = "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

ToolHandler = Callable[[str, str, dict], Awaitable[dict]]


class LiveSession:
    """One WebSocket conversation session."""

    def __init__(
        self,
        api_key: str,
        model: str,
        system_prompt: str,
        tool_declarations: list[dict],
        tool_handler: ToolHandler,
        audio_in: asyncio.Queue[bytes],
        audio_out: asyncio.Queue[bytes],
        voice: str = "Puck",
        inactivity_timeout: float = 75.0,
    ) -> None:
        self._key = api_key
        self.model = model
        self.system_prompt = system_prompt
        self.tools = tool_declarations
        self.tool_handler = tool_handler
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.voice = voice
        self.inactivity_timeout = inactivity_timeout

        self.on_speaking_change: Callable[[bool], None] | None = None
        self.on_interrupted: Callable[[], None] | None = None

        self._ws: Any = None
        self._closing = asyncio.Event()
        self._last_activity = time.monotonic()

    # ------------------------------------------------------------------
    async def run(self) -> str:
        """Run until closed. Returns a close reason. Raises GeminiFailure."""
        url = f"wss://{HOST}{PATH}?key={self._key}"
        try:
            async with websockets.connect(url, max_size=2**22, close_timeout=3) as ws:
                self._ws = ws
                await self._send(ws, self._setup_message())
                # Wait for setupComplete before streaming audio.
                first = await asyncio.wait_for(ws.recv(), timeout=15)
                msg = self._parse(first)
                if msg is None or "setupComplete" not in msg:
                    if msg and "error" in json.dumps(msg).lower():
                        raise classify(None, json.dumps(msg))
                sender = asyncio.create_task(self._sender(ws), name="live-sender")
                try:
                    reason = await self._receiver(ws)
                finally:
                    sender.cancel()
                    await asyncio.gather(sender, return_exceptions=True)
                return reason
        except GeminiFailure:
            raise
        except websockets.exceptions.InvalidStatus as exc:  # HTTP-level rejection
            status = getattr(getattr(exc, "response", None), "status_code", None)
            body = ""
            resp = getattr(exc, "response", None)
            if resp is not None:
                raw = getattr(resp, "body", b"") or b""
                body = raw.decode("utf-8", "replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
            raise classify(status, body) from exc
        except websockets.exceptions.ConnectionClosedError as exc:
            reason = getattr(exc, "reason", "") or str(exc)
            if "quota" in reason.lower() or getattr(exc, "code", None) == 1011:
                raise classify(429 if "quota" in reason.lower() else None, reason) from exc
            raise GeminiFailure("unavailable", f"connection closed: {reason}") from exc
        except OSError as exc:
            raise GeminiFailure("unavailable", f"network: {exc}") from exc

    async def close(self) -> None:
        self._closing.set()
        ws = self._ws
        if ws is not None:
            await ws.close()

    # ------------------------------------------------------------------
    def _setup_message(self) -> dict:
        setup: dict[str, Any] = {
            "model": self.model,
            "generationConfig": {
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": self.voice}}
                },
            },
            "systemInstruction": {"parts": [{"text": self.system_prompt}]},
        }
        if self.tools:
            setup["tools"] = [{"functionDeclarations": self.tools}]
        return {"setup": setup}

    @staticmethod
    async def _send(ws: Any, payload: dict) -> None:
        await ws.send(json.dumps(payload))

    @staticmethod
    def _parse(raw: str | bytes) -> dict | None:
        try:
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8", "replace")
            return json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

    async def _sender(self, ws: Any) -> None:
        """Forward microphone chunks; enforce inactivity timeout."""
        while not self._closing.is_set():
            try:
                chunk = await asyncio.wait_for(self.audio_in.get(), timeout=1.0)
            except asyncio.TimeoutError:
                if time.monotonic() - self._last_activity > self.inactivity_timeout:
                    log.info("inactivity timeout; closing session")
                    await ws.close(code=1000, reason="inactivity")
                    return
                continue
            if chunk is None:
                continue
            msg = {
                "realtimeInput": {
                    "mediaChunks": [
                        {"mimeType": "audio/pcm;rate=16000", "data": base64.b64encode(chunk).decode()}
                    ]
                }
            }
            await self._send(ws, msg)

    async def _receiver(self, ws: Any) -> str:
        speaking = False
        async for raw in ws:
            msg = self._parse(raw)
            if msg is None:
                continue
            self._last_activity = time.monotonic()

            if "serverContent" in msg:
                sc = msg["serverContent"] or {}
                if sc.get("interrupted"):
                    self._drain_output()
                    if self.on_interrupted:
                        self.on_interrupted()
                    if speaking and self.on_speaking_change:
                        speaking = False
                        self.on_speaking_change(False)
                    continue
                turn = sc.get("modelTurn") or {}
                for part in turn.get("parts", []) or []:
                    inline = part.get("inlineData") or {}
                    data = inline.get("data")
                    if data and str(inline.get("mimeType", "")).startswith("audio/pcm"):
                        if not speaking and self.on_speaking_change:
                            speaking = True
                            self.on_speaking_change(True)
                        self._offer_output(base64.b64decode(data))
                if sc.get("turnComplete") and speaking:
                    speaking = False
                    if self.on_speaking_change:
                        self.on_speaking_change(False)

            elif "toolCall" in msg:
                calls = (msg["toolCall"] or {}).get("functionCalls", []) or []
                responses = []
                for call in calls:
                    name = call.get("name", "")
                    call_id = call.get("id", "")
                    args = call.get("args", {}) or {}
                    try:
                        result = await self.tool_handler(call_id, name, args)
                    except Exception as exc:  # tool errors go back to the model, sanitized
                        result = {"error": type(exc).__name__}
                    responses.append({"id": call_id, "name": name, "response": {"result": result}})
                await self._send(ws, {"toolResponse": {"functionResponses": responses}})

            elif "goAway" in msg:
                return "server_go_away"

        return "closed"

    # -- audio out helpers (bounded, drop-oldest) -----------------------
    def _offer_output(self, pcm: bytes) -> None:
        q = self.audio_out
        if q.full():
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            q.put_nowait(pcm)
        except asyncio.QueueFull:
            pass

    def _drain_output(self) -> None:
        q = self.audio_out
        while True:
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                return
