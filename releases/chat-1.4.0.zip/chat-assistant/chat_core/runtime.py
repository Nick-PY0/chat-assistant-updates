"""Runtime wiring: builds every service and connects them.

Everything runs inside ONE low-priority asyncio process by default, which
keeps the footprint tiny (the "as light as possible" requirement). The
architecture still keeps audio isolated: audio bytes move only through
dedicated bounded queues and the audio callbacks never touch the DB, the
network, or the event bus.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.logging_setup import setup_logging
from chat_core.models.credentials import CredentialStore
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.keychain import MasterSecret
from chat_core.security.vault import Vault
from apps.audio.announcements import Announcer
from apps.audio.broadcast import RATE as BROADCAST_RATE, AudioBroadcast, resample_pcm16
from apps.audio.engine import AudioEngine
from apps.audio.stt import build_transcriber
from apps.live_gateway.gateway import LiveGateway
from apps.pulse.pulse import Pulse
from apps.tool_service.local_grammar import parse as parse_local
from apps.tool_service.reminders import ReminderManager
from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from apps.tool_service.weather_tool import WeatherTool
from apps.updater.updater import Updater

log = logging.getLogger("runtime")

RESTART_EXIT_CODE = 42  # run_chat.bat relaunches on this code


class Runtime:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.bus = EventBus()
        self.db = Database(settings.db_path)
        self.state = StateMachine(self.bus)
        self.master = MasterSecret(settings.data_path)
        self.vault: Vault | None = None
        self.store: CredentialStore | None = None
        self.timers: TimerManager | None = None
        self.reminders: ReminderManager | None = None
        self.weather_tool: WeatherTool | None = None
        self.tools: ToolService | None = None
        self.gateway: LiveGateway | None = None
        self.audio: AudioEngine | None = None
        self.pulse: Pulse | None = None
        self.updater: Updater | None = None
        self.announcer = Announcer()
        self.broadcast = AudioBroadcast()  # dashboard/phone audio listeners
        self.transcriber = None
        self.started_at = time.time()
        self.restart_exit_code = 0
        self.on_uvicorn_exit = None  # set by run_chat: asks the server to stop
        self._voice_flag = False
        self._audio_task: asyncio.Task | None = None
        self._pump_task: asyncio.Task | None = None
        self._reload_lock = asyncio.Lock()
        self._reload_task: asyncio.Task | None = None
        self._tasks: list[asyncio.Task] = []
        self._announce_cooldowns: dict[str, float] = {}
        self.quiet = False
        self.ringing: dict | None = None  # reminder currently ringing (dashboard)
        self._ring_task: asyncio.Task | None = None
        self._ring_stop = asyncio.Event()
        self._ring_pending: list[dict] = []  # reminders that came due mid-ring

    # ------------------------------------------------------------------
    async def start(self, voice: bool = True, cloud: bool = True, monitoring: bool = True) -> None:
        setup_logging(self.settings.log_level if self.settings.low_power else "INFO")
        await self.db.open()
        self.vault = Vault(self.master.load_or_create())
        self.store = CredentialStore(self.db, self.vault)

        self.timers = TimerManager(self.db, self.bus)
        self.reminders = ReminderManager(self.db, self.bus)
        self.weather_tool = WeatherTool(self.settings)
        self.tools = ToolService(
            self.db, self.bus, self.timers, self.store, on_stop=self.stop_output,
            reminders=self.reminders, weather=self.weather_tool, on_quiet=self.set_quiet,
        )
        await self.timers.start()
        await self.reminders.start()

        muted = (await self.db.get_setting("muted", "0")) == "1"
        self.state.set_muted(muted)
        self.quiet = (await self.db.get_setting("quiet_mode", "0")) == "1"

        if cloud:
            self.gateway = LiveGateway(
                self.settings, self.db, self.store, self.bus, self.state,
                TOOL_DECLARATIONS, self.tools.dispatch,
            )
            self._tasks.append(asyncio.create_task(self.gateway.run(), name="gateway"))

        self._voice_flag = voice
        self._wire_audio(voice)

        if monitoring:
            self.pulse = Pulse(self.settings, self.db, self.store, self.bus, self.state)
            self._tasks.append(asyncio.create_task(self.pulse.run(), name="pulse"))

        self.updater = Updater(self.settings, self.db, self.bus)
        self._tasks.append(asyncio.create_task(self.updater.run(), name="updater"))

        self._tasks.append(asyncio.create_task(self._event_pump(), name="event-pump"))
        await self.db.log("INFO", "runtime", "Chat started")

    async def stop(self) -> None:
        if self.gateway:
            await self.gateway.stop()
        if self.audio:
            await self.audio.stop()
        if self.pulse:
            await self.pulse.stop()
        if self.updater:
            await self.updater.stop()
        if self.timers:
            await self.timers.stop()
        if self.reminders:
            await self.reminders.stop()
        self._ring_stop.set()
        if self._ring_task is not None:
            self._ring_task.cancel()
            await asyncio.gather(self._ring_task, return_exceptions=True)
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        await self.db.log("INFO", "runtime", "Chat stopped")
        await self.db.close()

    # -- audio wiring ----------------------------------------------------
    def _wire_audio(self, voice: bool) -> None:
        """Attach the consumer of Gemini's audio output. With voice, that is
        the audio engine (which also feeds phone listeners); without it, a
        tiny pump keeps phone listening working anyway."""
        if self.gateway is None:
            return
        if voice:
            self.transcriber = build_transcriber(self.settings)
            self.audio = AudioEngine(
                self.settings, self.bus, self.state,
                self.gateway.audio_in, self.gateway.audio_out,
                on_wake=self.gateway.request_session,
                on_interrupt=self.gateway.interrupt,
                broadcast=self.broadcast,
                transcriber=self.transcriber,
                on_local_command=self.handle_local_utterance,
            )
            self.announcer.play_wav_bytes = self.audio.play_wav_bytes
            self._audio_task = asyncio.create_task(self.audio.run(), name="audio")
            self._tasks.append(self._audio_task)
        else:
            self.announcer.play_wav_bytes = self._broadcast_wav
            self._pump_task = asyncio.create_task(self._audio_out_pump(), name="audio-pump")
            self._tasks.append(self._pump_task)

    def schedule_audio_reload(self) -> None:
        """Fire-and-forget reload for the dashboard. The task reference is
        kept (an untracked task can be garbage-collected mid-flight) and the
        lock inside reload_audio serializes rapid repeated saves."""
        self._reload_task = asyncio.create_task(self.reload_audio())

    async def reload_audio(self) -> None:
        """Rebuild the audio engine so wake word / device / offline-voice
        setting changes apply without restarting Chat. Serialized: two
        overlapping reloads must not each wire an engine (double audio)."""
        async with self._reload_lock:
            if self.gateway is None:
                return
            if self.audio is not None:
                await self.audio.stop()
            for task in (self._audio_task, self._pump_task):
                if task is not None:
                    task.cancel()
                    await asyncio.gather(task, return_exceptions=True)
                    if task in self._tasks:
                        self._tasks.remove(task)
            self._audio_task = None
            self._pump_task = None
            self.audio = None
            self._wire_audio(self._voice_flag)
            await self.db.log("INFO", "audio", "audio settings applied; engine reloaded")

    async def _audio_out_pump(self) -> None:
        """No audio engine: still drain Gemini audio into the phone stream."""
        assert self.gateway is not None
        while True:
            pcm = await self.gateway.audio_out.get()
            self.broadcast.publish(pcm)

    def _broadcast_wav(self, pcm: bytes, rate: int) -> None:
        """Announcer output when no speaker exists: phone listeners only."""
        if not self.broadcast.has_listeners:
            raise RuntimeError("no listeners")  # announcer falls back to console
        self.broadcast.publish(resample_pcm16(pcm, rate, BROADCAST_RATE))

    # -- actions ---------------------------------------------------------
    def stop_output(self) -> None:
        """User said stop / pressed the Stop button: silence output NOW."""
        self._ring_stop.set()  # dismisses a ringing alarm/reminder too
        if self.gateway is not None:
            self.gateway.interrupt()
            while not self.gateway.audio_out.empty():
                try:
                    self.gateway.audio_out.get_nowait()
                except asyncio.QueueEmpty:
                    break
        if self.audio is not None:
            self.audio.clear_playback()  # also clears phone listeners
        else:
            self.broadcast.clear()

    # -- alarm/reminder ringing ------------------------------------------
    async def _begin_ring(self, data: dict) -> None:
        """A reminder/alarm is due: ring loudly until dismissed or timeout."""
        if self.quiet and not self.settings.quiet_override_alarms:
            await self.db.log("INFO", "reminders", "quiet mode: ring suppressed")
            return
        if self._ring_task is not None and not self._ring_task.done():
            # One ring at a time. This one rings as soon as the current one
            # is dismissed -- like an alarm clock, each needs its own stop.
            self._ring_pending.append(dict(data))
            await self.db.log("INFO", "reminders", "another ring is active; queued")
            return
        self._ring_stop.clear()
        self.ringing = dict(data)  # banner appears immediately
        self._ring_task = asyncio.create_task(self._ring_runner(dict(data)), name="ring")

    async def _ring_runner(self, first: dict) -> None:
        """Ring each due reminder in turn; each needs its own dismissal."""
        data: dict | None = first
        while data is not None:
            try:
                await self._ring_loop(data)
            finally:
                self.ringing = None
                self.bus.publish("reminders_changed")
            data = self._ring_pending.pop(0) if self._ring_pending else None
            if data is not None:
                self._ring_stop.clear()
                self.ringing = dict(data)
                self.bus.publish("reminders_changed")  # banner shows next ring

    async def _ring_loop(self, data: dict) -> None:
        from apps.audio.ring import RING_RATE, build_ring_cycle
        from apps.audio.speak import synth_text

        kind = str(data.get("kind") or "reminder")
        message = str(data.get("message") or "").strip()
        pcm = build_ring_cycle(self.settings.alarm_volume)
        say = message or ("This is your alarm." if kind == "alarm" else "")
        if say and kind != "alarm":
            say = f"Reminder: {say}"
        spoken = await asyncio.to_thread(synth_text, say) if say else None
        deadline = time.monotonic() + max(5, int(self.settings.alarm_ring_seconds))
        cycles = 0
        try:
            while not self._ring_stop.is_set() and time.monotonic() < deadline:
                self._play_alert(pcm, RING_RATE)
                await self._ring_wait(2.05)
                cycles += 1
                if cycles == 2 and not self._ring_stop.is_set():
                    if spoken is not None:
                        self._play_alert(spoken[0], spoken[1])
                        await self._ring_wait(len(spoken[0]) / 2 / max(spoken[1], 1) + 0.4)
                    elif message:
                        # no offline voice; a canned pointer at the dashboard
                        self._announce("reminder_fallback", cooldown=0)
                        await self._ring_wait(4.0)
        finally:
            await self.db.log("INFO", "reminders", f"ring ended: {message or kind}")

    async def _ring_wait(self, seconds: float) -> None:
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(self._ring_stop.wait(), timeout=seconds)

    def _play_alert(self, pcm: bytes, rate: int) -> None:
        """Alarms ring on the speaker AND phone listeners, whatever the
        configured audio route -- they must be heard."""
        if self.audio is not None:
            self.audio.play_wav_bytes(pcm, rate, force_speaker=True)
        else:
            try:
                self._broadcast_wav(pcm, rate)
            except RuntimeError:
                print("\a[Chat] An alarm or reminder is due -- see the dashboard.")

    async def _speak_dynamic(self, text: str) -> bool:
        """Speak an arbitrary sentence with the offline voice (pyttsx3).
        Returns False when no offline TTS is available."""
        from apps.audio.speak import synth_text

        text = str(text or "").strip()
        if not text:
            return False
        spoken = await asyncio.to_thread(synth_text, text)
        if spoken is None:
            return False
        try:
            self.announcer.play_wav_bytes(spoken[0], spoken[1])
        except Exception:
            return False
        return True

    async def handle_local_utterance(self, text: str) -> dict | None:
        """A spoken command transcribed offline (vosk) while in local mode."""
        text = (text or "").strip()
        await self.db.log("INFO", "voice", f"offline command: {text or '(nothing recognized)'}")
        cmd = parse_local(text) if text else None
        if cmd is None:
            self._announce("not_understood", cooldown=0)
            return None
        if cmd["tool"] == "stop_output":
            self.stop_output()
            return {"stopped": True}
        assert self.tools is not None
        result = await self.tools.dispatch("local", cmd["tool"], cmd["args"])
        if "error" in result:
            self._announce("not_understood", cooldown=0)
        elif cmd["tool"] == "set_quiet_mode":
            pass  # set_quiet speaks its own confirmation
        elif cmd["tool"] == "get_weather":
            if not await self._speak_dynamic(str(result.get("summary", ""))):
                self._announce("see_dashboard", cooldown=0)
        elif cmd["tool"] in ("recall_memories", "list_reminders"):
            # dynamic answers; without TTS, point at the dashboard instead
            self._announce("see_dashboard", cooldown=0)
        else:
            self._announce("ok", cooldown=0)
        return result

    def request_restart(self) -> None:
        """Dashboard asked for a restart (e.g. to apply a staged update)."""
        self.restart_exit_code = RESTART_EXIT_CODE
        cb = self.on_uvicorn_exit
        if cb is not None:
            asyncio.get_running_loop().call_later(0.3, cb)

    async def set_muted(self, muted: bool) -> None:
        self.state.set_muted(muted)
        await self.db.set_setting("muted", "1" if muted else "0")
        self._announce("muted" if muted else "unmuted", cooldown=0)

    async def set_quiet(self, enabled: bool) -> None:
        """Quiet mode: no unprompted speech (status notices, missed alerts).
        Replies to things the user asks still play, and timers/alarms still
        ring unless quiet_override_alarms is turned off. Manual only."""
        enabled = bool(enabled)
        changed = enabled != self.quiet
        if enabled and changed:
            self._announce("quiet_on", cooldown=0)  # confirm BEFORE going quiet
        self.quiet = enabled
        await self.db.set_setting("quiet_mode", "1" if enabled else "0")
        if not enabled and changed:
            self._announce("quiet_off", cooldown=0)
        if changed:
            self.bus.publish("quiet_changed", quiet=enabled)
            await self.db.log("INFO", "runtime", f"quiet mode {'on' if enabled else 'off'}")

    # Direct responses to something the user just did -- always audible.
    _QUIET_EXEMPT = {"quiet_on", "quiet_off", "ok", "not_understood", "see_dashboard",
                     "muted", "unmuted"}
    # Things the user explicitly scheduled -- ring through quiet mode when
    # quiet_override_alarms is on (reminder/alarm rings are gated separately).
    _QUIET_RINGERS = {"timer_done", "reminder_fallback"}

    def _announce(self, key: str, cooldown: float = 60.0) -> None:
        if self.quiet and key not in self._QUIET_EXEMPT:
            if not (key in self._QUIET_RINGERS and self.settings.quiet_override_alarms):
                return  # quiet mode: swallow unprompted announcements
        now = time.monotonic()
        if cooldown and now - self._announce_cooldowns.get(key, 0) < cooldown:
            return
        self._announce_cooldowns[key] = now
        self.announcer.announce(key)

    async def _event_pump(self) -> None:
        """Central place that reacts to events with announcements/logs.
        Audio playback of announcements happens via the speaker queue only."""
        q = self.bus.subscribe(
            "local_only", "timer_fired", "timer_missed", "credential_alert", "wake_word",
            "reminder_fired", "reminder_missed",
        )
        while True:
            ev = await q.get()
            if ev.topic == "local_only":
                self._announce("quota_exhausted" if ev.data.get("quota") else "service_unavailable")
            elif ev.topic == "timer_fired":
                self._announce("timer_done", cooldown=0)
                await self.db.log("INFO", "timers", f"finished: {ev.data.get('label') or ev.data.get('id')}")
            elif ev.topic == "timer_missed":
                self._announce("timer_missed")
            elif ev.topic == "reminder_fired":
                await self._begin_ring(dict(ev.data))
            elif ev.topic == "reminder_missed":
                self._announce("reminder_missed")
            elif ev.topic == "credential_alert":
                await self.db.log(
                    "WARNING", "credentials",
                    f"{ev.data.get('code')} on credential {ev.data.get('id')}"
                    + (f", {ev.data.get('keys_blocked')} key(s) blocked until {ev.data.get('retry_after')}"
                       if ev.data.get("keys_blocked") else ""),
                )
            elif ev.topic == "wake_word":
                # in capture mode the user is mid-sentence; don't talk over them
                if self.state.raw_state == ChatState.LOCAL_ONLY and ev.data.get("mode") != "capture":
                    self._announce("local_mode", cooldown=30)
