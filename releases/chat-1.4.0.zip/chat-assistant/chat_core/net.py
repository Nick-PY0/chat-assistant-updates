"""Small network helpers."""

from __future__ import annotations

import socket


def lan_ip() -> str:
    """This machine's LAN address (what to type on a phone). No traffic is
    actually sent; connecting a UDP socket just selects the outbound
    interface. Empty string when offline."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()
