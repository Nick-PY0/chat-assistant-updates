"""Operating state machine for Chat."""

from __future__ import annotations

from enum import Enum

from chat_core.events import EventBus


class ChatState(str, Enum):
    SLEEPING = "SLEEPING"
    CONNECTING = "CONNECTING"
    LISTENING = "LISTENING"
    SPEAKING = "SPEAKING"
    LOCAL_ONLY = "LOCAL_ONLY"
    MUTED = "MUTED"


class StateMachine:
    """Primary state + overlay flags (muted / degraded components)."""

    def __init__(self, bus: EventBus) -> None:
        self._bus = bus
        self._state = ChatState.SLEEPING
        self._muted = False
        self._degraded: set[str] = set()
        self.last_reason = "startup"

    # ------------------------------------------------------------------
    @property
    def state(self) -> ChatState:
        if self._muted:
            return ChatState.MUTED
        return self._state

    @property
    def raw_state(self) -> ChatState:
        return self._state

    @property
    def muted(self) -> bool:
        return self._muted

    @property
    def degraded(self) -> set[str]:
        return set(self._degraded)

    # ------------------------------------------------------------------
    def set(self, state: ChatState, reason: str = "") -> None:
        if state == self._state:
            return
        self._state = state
        self.last_reason = reason
        self._emit()

    def set_muted(self, muted: bool) -> None:
        if muted == self._muted:
            return
        self._muted = muted
        self._emit()

    def mark_degraded(self, component: str, degraded: bool) -> None:
        before = component in self._degraded
        if degraded:
            self._degraded.add(component)
        else:
            self._degraded.discard(component)
        if before != (component in self._degraded):
            self._emit()

    def snapshot(self) -> dict:
        return {
            "state": self.state.value,
            "muted": self._muted,
            "degraded": sorted(self._degraded),
            "reason": self.last_reason,
        }

    def _emit(self) -> None:
        self._bus.publish("state", **self.snapshot())
