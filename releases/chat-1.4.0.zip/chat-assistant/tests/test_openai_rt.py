"""OpenAI live brain: failure classification, tool conversion, and a full
session against a scripted fake Realtime server."""

from __future__ import annotations

import asyncio
import base64
import json

import pytest
import websockets

from integrations.gemini.errors import INVALID, QUOTA_EXHAUSTED, RATE_LIMITED, UNAVAILABLE
from integrations.openai_rt.errors import ProviderFailure, classify_openai
from integrations.openai_rt.live_client import RealtimeSession, to_openai_tools


# -- classification ------------------------------------------------------

def test_classify_auth_errors():
    assert classify_openai(401, "").code == INVALID
    assert classify_openai(403, "nope").code == INVALID
    assert classify_openai(None, '{"code": "invalid_api_key", "message": "Incorrect API key"}').code == INVALID


def test_classify_quota_beats_status():
    # OpenAI reports spent quota as HTTP 429; that is not a speed limit.
    assert classify_openai(429, '{"code": "insufficient_quota"}').code == QUOTA_EXHAUSTED
    assert classify_openai(None, "You exceeded your current quota").code == QUOTA_EXHAUSTED


def test_classify_rate_and_unavailable():
    assert classify_openai(429, "slow down").code == RATE_LIMITED
    assert classify_openai(500, "").code == UNAVAILABLE
    assert classify_openai(None, "rate limit reached").code == RATE_LIMITED
    assert classify_openai(None, "connection refused").code == UNAVAILABLE


# -- tool schema conversion ----------------------------------------------

def test_to_openai_tools_lowercases_types():
    decls = [{
        "name": "start_timer",
        "description": "Start a countdown timer.",
        "parameters": {
            "type": "OBJECT",
            "properties": {"duration_seconds": {"type": "INTEGER", "description": "d"}},
            "required": ["duration_seconds"],
        },
    }]
    tools = to_openai_tools(decls)
    assert tools[0]["type"] == "function"
    assert tools[0]["name"] == "start_timer"
    params = tools[0]["parameters"]
    assert params["type"] == "object"
    assert params["properties"]["duration_seconds"]["type"] == "integer"
    assert params["required"] == ["duration_seconds"]


def test_to_openai_tools_handles_empty_parameters():
    tools = to_openai_tools([{"name": "list_timers", "description": "x"}])
    assert tools[0]["parameters"]["type"] == "object"


# -- live session against a fake server -----------------------------------

DECLS = [{"name": "start_timer", "description": "t",
          "parameters": {"type": "OBJECT", "properties": {"duration_seconds": {"type": "INTEGER"}}}}]


async def start_fake(handler):
    server = await websockets.serve(handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    return server, f"ws://127.0.0.1:{port}/v1/realtime"


def make_session(url, tool_handler=None, **kwargs):
    async def default_handler(call_id, name, args):
        return {"ok": True}

    audio_in: asyncio.Queue = asyncio.Queue()
    audio_out: asyncio.Queue = asyncio.Queue()
    session = RealtimeSession(
        api_key="sk-test",
        model="gpt-realtime",
        system_prompt="be brief",
        tool_declarations=DECLS,
        tool_handler=tool_handler or default_handler,
        audio_in=audio_in,
        audio_out=audio_out,
        voice="alloy",
        inactivity_timeout=kwargs.pop("inactivity_timeout", 30.0),
        url=url,
    )
    return session, audio_in, audio_out


async def test_full_session_audio_tools_and_close():
    seen = {"update": None, "outputs": [], "tool_calls": []}

    async def handler(ws):
        try:
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] == "session.update":
                    seen["update"] = msg
                    break
            await ws.send(json.dumps({"type": "session.created"}))
            await ws.send(json.dumps({"type": "response.created"}))
            await ws.send(json.dumps({
                "type": "response.audio.delta",
                "delta": base64.b64encode(b"\x01\x00" * 480).decode(),
            }))
            await ws.send(json.dumps({
                "type": "response.function_call_arguments.done",
                "call_id": "c1", "name": "start_timer",
                "arguments": json.dumps({"duration_seconds": 300}),
            }))
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] in ("conversation.item.create", "response.create"):
                    seen["outputs"].append(msg)
                    if msg["type"] == "response.create":
                        break
            await ws.send(json.dumps({"type": "response.done"}))
            await ws.close()
        except websockets.exceptions.ConnectionClosed:
            pass

    async def tool_handler(call_id, name, args):
        seen["tool_calls"].append((call_id, name, args))
        return {"status": "started"}

    server, url = await start_fake(handler)
    try:
        session, audio_in, audio_out = make_session(url, tool_handler)
        speaking_flips = []
        session.on_speaking_change = speaking_flips.append
        await audio_in.put(b"\x02\x00" * 1280)  # exercise the mic sender too
        reason = await asyncio.wait_for(session.run(), timeout=10)
    finally:
        server.close()
        await server.wait_closed()

    assert reason == "closed"
    sess = seen["update"]["session"]
    assert sess["instructions"] == "be brief"
    assert sess["voice"] == "alloy"
    assert sess["input_audio_format"] == "pcm16"
    assert sess["tools"][0]["name"] == "start_timer"
    assert seen["tool_calls"] == [("c1", "start_timer", {"duration_seconds": 300})]
    item = seen["outputs"][0]["item"]
    assert item["type"] == "function_call_output"
    assert item["call_id"] == "c1"
    assert json.loads(item["output"]) == {"status": "started"}
    assert not audio_out.empty()
    assert speaking_flips and speaking_flips[0] is True and speaking_flips[-1] is False


async def test_interruption_cancels_active_response():
    got_cancel = asyncio.Event()

    async def handler(ws):
        try:
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] == "session.update":
                    break
            await ws.send(json.dumps({"type": "response.created"}))
            await ws.send(json.dumps({
                "type": "response.audio.delta",
                "delta": base64.b64encode(b"\x05\x00" * 480).decode(),
            }))
            await ws.send(json.dumps({"type": "input_audio_buffer.speech_started"}))
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] == "response.cancel":
                    got_cancel.set()
                    await ws.close()
                    return
        except websockets.exceptions.ConnectionClosed:
            pass

    server, url = await start_fake(handler)
    try:
        session, _in, audio_out = make_session(url)
        interrupted = []
        session.on_interrupted = lambda: interrupted.append(True)
        reason = await asyncio.wait_for(session.run(), timeout=10)
        assert reason == "closed"
        await asyncio.wait_for(got_cancel.wait(), timeout=2)
    finally:
        server.close()
        await server.wait_closed()

    assert interrupted == [True]
    assert audio_out.empty()  # playback was flushed on interruption


async def test_error_event_raises_classified_failure():
    async def handler(ws):
        try:
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] == "session.update":
                    break
            await ws.send(json.dumps({
                "type": "error",
                "error": {"code": "insufficient_quota", "message": "You exceeded your current quota"},
            }))
            await asyncio.sleep(1)
        except websockets.exceptions.ConnectionClosed:
            pass

    server, url = await start_fake(handler)
    try:
        session, _in, _out = make_session(url)
        with pytest.raises(ProviderFailure) as info:
            await asyncio.wait_for(session.run(), timeout=10)
        assert info.value.code == QUOTA_EXHAUSTED
    finally:
        server.close()
        await server.wait_closed()


async def test_benign_error_events_are_ignored():
    async def handler(ws):
        try:
            while True:
                msg = json.loads(await ws.recv())
                if msg["type"] == "session.update":
                    break
            await ws.send(json.dumps({
                "type": "error",
                "error": {"code": "response_cancel_not_active", "message": "Cancellation failed: no active response"},
            }))
            await ws.send(json.dumps({"type": "response.done"}))
            await ws.close()
        except websockets.exceptions.ConnectionClosed:
            pass

    server, url = await start_fake(handler)
    try:
        session, _in, _out = make_session(url)
        reason = await asyncio.wait_for(session.run(), timeout=10)
        assert reason == "closed"
    finally:
        server.close()
        await server.wait_closed()
