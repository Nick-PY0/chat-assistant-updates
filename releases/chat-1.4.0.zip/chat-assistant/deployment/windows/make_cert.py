"""Create a self-signed HTTPS certificate for LAN dashboard access.

Run from the chat-assistant folder:
    python deployment/windows/make_cert.py

Writes cert.pem / key.pem into the Chat data folder and prints the two
config values to set. Your browser will warn once about the self-signed
certificate; you can trust it permanently (it never leaves your LAN).
"""

from __future__ import annotations

import datetime
import ipaddress
import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from cryptography import x509  # noqa: E402
from cryptography.hazmat.primitives import hashes, serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import rsa  # noqa: E402
from cryptography.x509.oid import NameOID  # noqa: E402

from chat_core.config import load_settings  # noqa: E402


def main() -> int:
    settings = load_settings()
    data = settings.data_path
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    hostname = socket.gethostname()
    names: list[x509.GeneralName] = [
        x509.DNSName("localhost"),
        x509.DNSName(hostname),
        x509.DNSName(f"{hostname}.local"),
        x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
    ]
    try:
        lan_ip = socket.gethostbyname(hostname)
        names.append(x509.IPAddress(ipaddress.ip_address(lan_ip)))
    except OSError:
        pass
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "chat-assistant.local")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=1))
        .not_valid_after(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=1095))
        .add_extension(x509.SubjectAlternativeName(names), critical=False)
        .sign(key, hashes.SHA256())
    )
    cert_path = data / "cert.pem"
    key_path = data / "key.pem"
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(
        key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
    )
    settings.ssl_certfile = str(cert_path)
    settings.ssl_keyfile = str(key_path)
    settings.save()
    print(f"Certificate written to {cert_path}")
    print(f"Key written to        {key_path}")
    print("config.json updated -- restart Chat and use https://")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
