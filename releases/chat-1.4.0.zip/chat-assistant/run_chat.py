"""Chat — single-process launcher.

Runs every service (audio, Gemini gateway, tools, pulse, dashboard) as
asyncio tasks in ONE quiet process. Designed to sit in a minimal console
window and use as close to zero resources as possible while idle.

Usage:
  python run_chat.py                  # everything (voice auto-disables if
                                      # audio packages/hardware are missing)
  python run_chat.py --dashboard-only # no voice, no cloud, no pulse
  python run_chat.py --no-voice       # cloud + dashboard, no microphone
  python run_chat.py --verbose        # more console output
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import os
import sys

RESTART_CODE = 42  # run_chat.bat relaunches when Chat exits with this code


def _peek_data_dir():
    """Resolve the data dir WITHOUT importing chat_core — the update swap
    below must happen before any app module is loaded."""
    from pathlib import Path

    for i, arg in enumerate(sys.argv):
        if arg == "--data-dir" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1]).expanduser()
        if arg.startswith("--data-dir="):
            return Path(arg.split("=", 1)[1]).expanduser()
    override = os.environ.get("CHAT_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "ChatAssistant"
    return Path.home() / ".chat-assistant"


def apply_pending_update() -> None:
    """If the in-app updater staged a new version (data/updates/pending),
    swap it in now. Source installs copy the files over this folder and boot
    straight into the new code; exe installs hand off to a tiny helper
    script (files are locked while the exe runs) and exit."""
    import shutil
    from pathlib import Path

    pending = _peek_data_dir() / "updates" / "pending"
    if not pending.is_dir():
        return
    if not ((pending / "run_chat.py").exists() or (pending / "Chat.exe").exists()):
        return  # not a Chat build; ignore
    if getattr(sys, "frozen", False):
        _apply_update_frozen(pending)
        return
    target = Path(__file__).resolve().parent
    try:
        shutil.copytree(pending, target, dirs_exist_ok=True)
        shutil.rmtree(pending, ignore_errors=True)
        (pending.parent / "pending.json").unlink(missing_ok=True)
        print("Update applied.")
    except Exception as exc:
        print(f"Update could not be applied ({type(exc).__name__}); starting the current version.")


def _apply_update_frozen(pending) -> None:
    """Chat.exe cannot overwrite itself while running: a helper bat waits
    for this process to exit, copies the new files in, and starts Chat."""
    import subprocess
    import tempfile
    from pathlib import Path

    exe = Path(sys.executable).resolve()
    bat = Path(tempfile.gettempdir()) / "chat_apply_update.bat"
    bat.write_text(
        "@echo off\r\n"
        "timeout /t 2 /nobreak >nul\r\n"
        f'xcopy /e /y /q "{pending}\\*" "{exe.parent}\\" >nul\r\n'
        f'rmdir /s /q "{pending}"\r\n'
        f'del "{pending.parent}\\pending.json" >nul 2>&1\r\n'
        f'start "" "{exe}"\r\n'
        'del "%~f0"\r\n'
    )
    subprocess.Popen(
        ["cmd", "/c", str(bat)],
        creationflags=0x00000008 | 0x00000200,  # DETACHED | NEW_PROCESS_GROUP
        close_fds=True,
    )
    print("Applying the downloaded update... Chat restarts itself in a few seconds.")
    raise SystemExit(0)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Chat voice assistant")
    p.add_argument("--dashboard-only", action="store_true", help="dashboard + timers only")
    p.add_argument("--no-voice", action="store_true", help="disable microphone/wake word")
    p.add_argument("--verbose", action="store_true", help="chatty console logging")
    p.add_argument("--host", default=None, help="dashboard bind address")
    p.add_argument("--port", type=int, default=None, help="dashboard port")
    p.add_argument("--data-dir", default=None, help="data directory override")
    return p.parse_args()


async def main() -> int:
    args = parse_args()
    if args.data_dir:
        os.environ["CHAT_DATA_DIR"] = args.data_dir

    from chat_core.config import load_settings

    settings = load_settings()
    if args.host:
        settings.dashboard_host = args.host
    if args.port:
        settings.dashboard_port = args.port
    if args.verbose:
        settings.log_level = "INFO"
        settings.low_power = False

    from chat_core.runtime import Runtime
    from apps.dashboard.app import create_app
    import uvicorn

    rt = Runtime(settings)
    await rt.start(
        voice=not (args.no_voice or args.dashboard_only),
        cloud=not args.dashboard_only,
        monitoring=not args.dashboard_only,
    )

    app = create_app(rt)
    uv_kwargs: dict = dict(
        host=settings.dashboard_host,
        port=settings.dashboard_port,
        log_level="warning" if settings.low_power else "info",
        access_log=not settings.low_power,
    )
    if settings.ssl_certfile and settings.ssl_keyfile:
        uv_kwargs.update(ssl_certfile=settings.ssl_certfile, ssl_keyfile=settings.ssl_keyfile)
    config = uvicorn.Config(app, **uv_kwargs)
    server = uvicorn.Server(config)
    # lets the dashboard's Restart button stop the server loop cleanly
    rt.on_uvicorn_exit = lambda: setattr(server, "should_exit", True)

    from chat_core.version import APP_VERSION

    scheme = "https" if settings.ssl_certfile else "http"
    print(f"Chat {APP_VERSION} is running.")
    if settings.dashboard_host in ("0.0.0.0", "::"):
        from chat_core.net import lan_ip

        print(f"  This computer:   {scheme}://127.0.0.1:{settings.dashboard_port}")
        ip = lan_ip()
        if ip:
            print(f"  Phone on Wi-Fi:  {scheme}://{ip}:{settings.dashboard_port}")
    else:
        print(f"  Control panel: {scheme}://{settings.dashboard_host}:{settings.dashboard_port}")
    print(f"  Data folder:   {settings.data_dir}")
    print("  Press Ctrl+C to stop.")

    try:
        await server.serve()
    finally:
        with contextlib.suppress(Exception):
            await rt.stop()

    code = rt.restart_exit_code or 0
    if code == RESTART_CODE and getattr(sys, "frozen", False):
        # exe has no .bat loop around it: relaunch ourselves after a beat
        import subprocess

        subprocess.Popen(
            ["cmd", "/c", f'timeout /t 2 /nobreak >nul & start "" "{sys.executable}"'],
            creationflags=0x00000008,
            close_fds=True,
        )
        return 0
    return code


if __name__ == "__main__":
    apply_pending_update()  # must run before chat_core/apps are imported
    if sys.platform == "win32":
        # Proactor is the default on 3.8+; keep it explicit for sounddevice compat.
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        # run as a background-priority process so audio apps/games are unaffected
        try:
            import ctypes

            ctypes.windll.kernel32.SetPriorityClass(
                ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000  # BELOW_NORMAL
            )
        except Exception:
            pass
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        print("\nChat stopped.")
