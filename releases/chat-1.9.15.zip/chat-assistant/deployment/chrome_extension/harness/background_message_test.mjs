#!/usr/bin/env node
// Executes the real background.js module with a minimal Chrome MV3 mock.
// This specifically guards the options-page Pair now path that previously
// returned no response when Chrome's MessageSender metadata varied.

import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";

let messageListener = null;
const sockets = [];
const storageData = {};
let deferSecretWrite = false;
let releaseSecretWrite = null;

class StubWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;

  constructor(url) {
    this.url = url;
    this.readyState = StubWebSocket.CONNECTING;
    this.listeners = new Map();
    this.sent = [];
    sockets.push(this);
  }

  addEventListener(type, callback) {
    this.listeners.set(type, callback);
  }

  close() {
    this.readyState = 3;
  }

  send(data) { this.sent.push(data); }
}

globalThis.WebSocket = StubWebSocket;
globalThis.chrome = {
  runtime: {
    id: "test-extension-id",
    getURL: (path = "") => "chrome-extension://test-extension-id/" + path,
    onMessage: {
      addListener(callback) {
        messageListener = callback;
      },
    },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} },
    sendMessage() {},
  },
  storage: {
    local: {
      async get(keys) {
        const selected = {};
        for (const key of keys || []) {
          if (Object.hasOwn(storageData, key)) selected[key] = storageData[key];
        }
        return selected;
      },
      async set(values) {
        if (deferSecretWrite && Object.hasOwn(values, "bridge_secret")) {
          await new Promise((resolve) => { releaseSecretWrite = resolve; });
        }
        Object.assign(storageData, values);
      },
      async remove(keys) {
        for (const key of keys || []) delete storageData[key];
      },
    },
  },
  alarms: {
    create() {},
    clear() {},
    onAlarm: { addListener() {} },
  },
  tabs: {
    async query(q) { return tabsQueryImpl(q); },
    async update() {},
    async create() {},
    async sendMessage(id, msg) { return tabsSendMessageImpl(id, msg); },
  },
};

// Mutable tab behaviors so individual scenarios below can simulate a missing
// YouTube tab, an unreachable content script, or a throwing tabs API.
let tabsQueryImpl = async () => [];
let tabsSendMessageImpl = async () => ({});

const backgroundUrl = new URL("../background.js", import.meta.url);
await import(pathToFileURL(backgroundUrl.pathname).href + "?message-test=1");

assert.equal(typeof messageListener, "function", "background listener was not registered");

let pairResponse;
const pairReturn = messageListener({
  type: "pair",
  token: "test-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {
  // Deliberately reproduce a tabbed options page while omitting optional
  // sender.id/url/origin metadata. UI routing must not depend on these fields.
  tab: { id: 42 },
}, (response) => {
  pairResponse = response;
});

assert.deepEqual(pairResponse, { ok: true }, "Pair now did not receive an immediate acceptance");
assert.equal(pairReturn, false, "synchronously answered Pair now must not hold the message port open");

// Reproduce the real pairing race: the bridge sends paired and auth_ok
// back-to-back while chrome.storage.local.set is still persisting the secret.
// The older paired handler must not overwrite the final ready status.
const pairingSocket = sockets.at(-1);
assert.ok(pairingSocket, "Pair now did not create a WebSocket");
pairingSocket.readyState = StubWebSocket.OPEN;
pairingSocket.listeners.get("open")();
deferSecretWrite = true;
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "bridge-secret-1234567890" }),
});
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 7 }),
});
assert.equal(typeof releaseSecretWrite, "function", "secret write was not deferred");
releaseSecretWrite();
await new Promise((resolve) => setImmediate(resolve));

const statusResponse = await new Promise((resolve) => {
  const keepPortOpen = messageListener({ type: "get_status" }, {}, resolve);
  assert.equal(keepPortOpen, true);
});
assert.equal(statusResponse.status.authenticated, true);
assert.equal(statusResponse.status.detail, "ready",
  "paired storage completion regressed ready status to awaiting auth_ok");

let contentResponse;
const contentReturn = messageListener({
  type: "content_hello",
}, {
  tab: { id: 7 },
  origin: "https://www.youtube.com",
  url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
}, (response) => {
  contentResponse = response;
});

assert.deepEqual(contentResponse, { ok: true, connected: true });
assert.equal(contentReturn, true);

console.log("Real background message test passed: Pair routing and auth status race are safe.");
// ---------------------------------------------------------------------------
// Command routing through the REAL background.js: every command id must get
// exactly ONE ack carrying a real cause — even when the browser API throws.
// ---------------------------------------------------------------------------
const flush = async (rounds = 8) => {
  for (let i = 0; i < rounds; i++) await new Promise((r) => setImmediate(r));
};
const sendCommand = (frame) =>
  pairingSocket.listeners.get("message")({ data: JSON.stringify(frame) });
const acksFor = (id) =>
  pairingSocket.sent
    .map((raw) => JSON.parse(raw))
    .filter((f) => f.type === "ack" && f.id === id);

// No YouTube tab anywhere → exactly one no_youtube_tab NACK.
sendCommand({ type: "command", id: 101, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(101), [{ type: "ack", id: 101, ok: false, error: "no_youtube_tab" }]);

// Content script unreachable → exactly one content_unreachable NACK.
tabsQueryImpl = async () => [{ id: 5, active: true }];
tabsSendMessageImpl = async () => { throw new Error("Could not establish connection"); };
sendCommand({ type: "command", id: 102, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(102), [{ type: "ack", id: 102, ok: false, error: "content_unreachable" }]);

// Unexpected exception inside routing → exactly one internal_error NACK.
tabsQueryImpl = async () => { throw new Error("tabs API exploded"); };
sendCommand({ type: "command", id: 103, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(103), [{ type: "ack", id: 103, ok: false, error: "internal_error" }]);

// Healthy path → exactly one OK ack (and no error field on success).
tabsQueryImpl = async () => [{ id: 5, active: true }];
tabsSendMessageImpl = async () => ({ accepted: true });
sendCommand({ type: "command", id: 104, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(104), [{ type: "ack", id: 104, ok: true }]);

console.log("Command ack-once + failure-cause tests passed.");
