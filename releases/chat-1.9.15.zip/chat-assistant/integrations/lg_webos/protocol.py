"""SSAP protocol constants for LG webOS TVs: a strict allowlist.

Everything Chat may ever ask a TV is enumerated here.  The client refuses any
URI or button outside these tables, so no caller -- voice, cloud model, or
dashboard -- can smuggle an arbitrary webOS command through this integration.

The registration manifest requests only the permissions the allowlisted
commands need (the TV shows a pairing prompt the user must approve on
screen).  There is no LG account and nothing leaves the local network.
"""

from __future__ import annotations

import re

# -- allowlisted SSAP request URIs ------------------------------------------
URI_TURN_OFF = "ssap://system/turnOff"
URI_GET_VOLUME = "ssap://audio/getVolume"
URI_SET_VOLUME = "ssap://audio/setVolume"
URI_VOLUME_UP = "ssap://audio/volumeUp"
URI_VOLUME_DOWN = "ssap://audio/volumeDown"
URI_SET_MUTE = "ssap://audio/setMute"
URI_MEDIA_PLAY = "ssap://media.controls/play"
URI_MEDIA_PAUSE = "ssap://media.controls/pause"
URI_MEDIA_STOP = "ssap://media.controls/stop"
URI_MEDIA_REWIND = "ssap://media.controls/rewind"
URI_MEDIA_FAST_FORWARD = "ssap://media.controls/fastForward"
URI_LIST_APPS = "ssap://com.webos.applicationManager/listApps"
URI_FOREGROUND_APP = "ssap://com.webos.applicationManager/getForegroundAppInfo"
URI_LAUNCH_APP = "ssap://system.launcher/launch"
URI_INPUT_LIST = "ssap://tv/getExternalInputList"
URI_SWITCH_INPUT = "ssap://tv/switchInput"
URI_POWER_STATE = "ssap://com.webos.service.tvpower/power/getPowerState"
URI_SYSTEM_INFO = "ssap://system/getSystemInfo"
URI_POINTER_SOCKET = "ssap://com.webos.service.networkinput/getPointerInputSocket"
# On-screen keyboard (IME). insertText only reaches a focused text field on the
# TV; there is no way to type into anything else through this service.
URI_INSERT_TEXT = "ssap://com.webos.service.ime/insertText"
URI_SEND_ENTER = "ssap://com.webos.service.ime/sendEnterKey"

ALLOWED_URIS: frozenset[str] = frozenset({
    URI_TURN_OFF,
    URI_GET_VOLUME,
    URI_SET_VOLUME,
    URI_VOLUME_UP,
    URI_VOLUME_DOWN,
    URI_SET_MUTE,
    URI_MEDIA_PLAY,
    URI_MEDIA_PAUSE,
    URI_MEDIA_STOP,
    URI_MEDIA_REWIND,
    URI_MEDIA_FAST_FORWARD,
    URI_LIST_APPS,
    URI_FOREGROUND_APP,
    URI_LAUNCH_APP,
    URI_INPUT_LIST,
    URI_SWITCH_INPUT,
    URI_POWER_STATE,
    URI_SYSTEM_INFO,
    URI_POINTER_SOCKET,
    URI_INSERT_TEXT,
    URI_SEND_ENTER,
})

# URIs that may also be subscribed to (TV pushes updates).
SUBSCRIBABLE_URIS: frozenset[str] = frozenset({
    URI_GET_VOLUME,
    URI_FOREGROUND_APP,
    URI_POWER_STATE,
})

# -- allowlisted remote buttons (pointer-input socket) ------------------------
# Spoken/dashboard names (left) map to the webOS button identifiers (right).
BUTTONS: dict[str, str] = {
    "up": "UP",
    "down": "DOWN",
    "left": "LEFT",
    "right": "RIGHT",
    "ok": "ENTER",
    "enter": "ENTER",
    "select": "ENTER",
    "back": "BACK",
    "exit": "EXIT",
    "home": "HOME",
    "menu": "MENU",
    "info": "INFO",
    "play": "PLAY",
    "pause": "PAUSE",
    "stop": "STOP",
    "rewind": "REWIND",
    "fast_forward": "FASTFORWARD",
    "channel_up": "CHANNELUP",
    "channel_down": "CHANNELDOWN",
}

MEDIA_ACTIONS: dict[str, str] = {
    "play": URI_MEDIA_PLAY,
    "pause": URI_MEDIA_PAUSE,
    "stop": URI_MEDIA_STOP,
    "rewind": URI_MEDIA_REWIND,
    "fast_forward": URI_MEDIA_FAST_FORWARD,
}

# -- pairing manifest ---------------------------------------------------------
# Permissions cover exactly the allowlisted commands above; the user approves
# this set on the TV screen.  (Same shape Home Assistant's webOS client uses;
# modern firmware needs no signed blob for PROMPT pairing.)
REGISTER_PERMISSIONS: tuple[str, ...] = (
    "CONTROL_AUDIO",
    "CONTROL_INPUT_JOYSTICK",
    "CONTROL_INPUT_MEDIA_PLAYBACK",
    "CONTROL_INPUT_TEXT",
    "CONTROL_INPUT_TV",
    "CONTROL_MOUSE_AND_KEYBOARD",
    "CONTROL_POWER",
    "LAUNCH",
    "READ_APP_STATUS",
    "READ_INPUT_DEVICE_LIST",
    "READ_INSTALLED_APPS",
    "READ_POWER_STATE",
    "READ_RUNNING_APPS",
)


def build_register_payload(client_key: str | None) -> dict:
    """Fresh registration payload; includes the stored key when re-pairing."""
    payload: dict = {
        "forcePairing": False,
        "pairingType": "PROMPT",
        "manifest": {
            "appVersion": "1.1",
            "manifestVersion": 1,
            "permissions": list(REGISTER_PERMISSIONS),
        },
    }
    if client_key:
        payload["client-key"] = client_key
    return payload


# -- input validation ---------------------------------------------------------
_APP_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,120}$", re.IGNORECASE)
_INPUT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._ -]{0,60}$", re.IGNORECASE)
_HOST_RE = re.compile(r"^[a-z0-9]([a-z0-9._-]{0,251}[a-z0-9])?$", re.IGNORECASE)
_MAC_RE = re.compile(r"^[0-9a-f]{2}([:-]?[0-9a-f]{2}){5}$", re.IGNORECASE)


def valid_app_id(value: str) -> bool:
    return bool(_APP_ID_RE.fullmatch(str(value or "")))


def valid_input_id(value: str) -> bool:
    return bool(_INPUT_ID_RE.fullmatch(str(value or "")))


def valid_host(value: str) -> bool:
    """Bounded hostname / IPv4 charset; no schemes, ports, or spaces."""
    return bool(_HOST_RE.fullmatch(str(value or "")))


def normalize_mac(value: str) -> str | None:
    """Return AA:BB:CC:DD:EE:FF, or None when the input is not a MAC."""
    raw = str(value or "").strip()
    if not _MAC_RE.fullmatch(raw):
        return None
    digits = re.sub(r"[^0-9a-fA-F]", "", raw)
    if len(digits) != 12:
        return None
    return ":".join(digits[i : i + 2] for i in range(0, 12, 2)).upper()


def clamp_volume(value) -> int:
    try:
        vol = int(value)
    except (TypeError, ValueError):
        raise ValueError("volume must be a number 0-100") from None
    return max(0, min(100, vol))
