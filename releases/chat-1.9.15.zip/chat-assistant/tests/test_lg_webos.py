"""LG webOS TV integration: protocol fakes and full-behavior tests.

No real network anywhere: FakeTV speaks SSAP over in-memory websockets, and
Wake-on-LAN / SSDP discovery are injected callables.  Protocol tests are
exact -- no tolerated failures.
"""

from __future__ import annotations

import asyncio
import json
from urllib.parse import urlsplit

import pytest

from integrations.lg_webos import protocol
from integrations.lg_webos.client import (
    SSAPClient,
    SSAPError,
    SSAPNotSupported,
    SSAPPairingRejected,
)
from integrations.lg_webos.discovery import parse_ssdp_response
from integrations.lg_webos.manager import (
    KEY_CONTEXT,
    KEY_SETTING,
    WebOSManager,
    WebOSTVError,
)
from integrations.lg_webos.wol import WoLError, build_magic_packet

MAC_INPUT = "aa-bb-cc-dd-ee-ff"
MAC_NORM = "AA:BB:CC:DD:EE:FF"


async def eventually(predicate, timeout=4.0, interval=0.02):
    """Poll until predicate() is true (returns its final value)."""
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while loop.time() < deadline:
        if predicate():
            return True
        await asyncio.sleep(interval)
    return bool(predicate())


class _Close:
    __slots__ = ()


_CLOSE = _Close()


class FakeWS:
    """Websocket double.  Sent frames go to an async responder task; frames
    the TV pushes land in .incoming for the client's read loop."""

    def __init__(self, responder=None):
        self.sent: list[str] = []
        self.incoming: asyncio.Queue = asyncio.Queue()
        self.closed = False
        self._responder = responder

    async def send(self, data) -> None:
        if self.closed:
            raise ConnectionError("socket closed")
        self.sent.append(data)
        if self._responder is not None:
            asyncio.get_running_loop().create_task(self._responder(self, data))

    async def recv(self) -> str:
        item = await self.incoming.get()
        if item is _CLOSE:
            raise ConnectionError("socket closed")
        return item

    async def close(self) -> None:
        if not self.closed:
            self.closed = True
            self.incoming.put_nowait(_CLOSE)

    def push(self, message: dict) -> None:
        self.incoming.put_nowait(json.dumps(message))


class FakeTV:
    """Scripted webOS TV that speaks real SSAP message shapes."""

    def __init__(self):
        self.client_key = "fake-client-key-8f3a51"
        self.known_keys: set[str] = set()
        self.approve = True                # the human approves the prompt
        self.approval_gate: asyncio.Event | None = None  # hold the prompt open
        self.refuse_connect = False
        self.refuse_tls = False
        self.silent_register = False       # never answer registration
        self.hang_requests = False         # accept but never answer requests
        self.error_requests = False        # answer every request with an SSAP error
        self.drop_on_request = False       # close the socket instead of answering
        self.not_supported_uris: set[str] = set()  # URIs answered with a 404
        self.power_404 = False             # firmware without getPowerState
        self.legacy_volume = False         # flat (old) volume payload shape
        self.pointer_socket_path: str | None = None  # override (hostile) socketPath
        self.seen_host = "fake-tv"         # host of the last control connection
        self.strict_keys = False           # reject unknown keys outright (real TVs)
        self.apps = [
            {"id": "netflix", "title": "Netflix"},
            {"id": "youtube.leanback.v4", "title": "YouTube"},
            {"id": "com.disney.disneyplus-prod", "title": "Disney+"},
        ]
        self.inputs = [
            {"id": "HDMI_1", "label": "HDMI 1"},
            {"id": "HDMI_2", "label": "Gaming PC"},
        ]
        self.volume = 20
        self.muted = False
        self.foreground = "netflix"
        self.launched: list[str] = []
        self.switched: list[str] = []
        self.buttons: list[str] = []
        self.typed: list[tuple[str, int]] = []   # (text, replace) via IME
        self.enter_presses = 0
        self.refuse_text = False           # TV paired without keyboard permission
        self.turned_off = 0
        self.connections: list[FakeWS] = []
        self.pointer_sockets: list[FakeWS] = []
        self.sub_ids: dict[str, tuple[FakeWS, str]] = {}
        self.requests: list[str] = []

    # -- factory given to SSAPClient/WebOSManager -------------------------
    async def connect(self, url: str):
        if self.refuse_connect:
            raise ConnectionError("connection refused")
        if self.refuse_tls and url.startswith("wss://"):
            raise ConnectionError("TLS port closed")
        if "/pointer/" in url:
            ws = FakeWS(responder=self._on_pointer)
            self.pointer_sockets.append(ws)
            return ws
        self.seen_host = urlsplit(url).hostname or "fake-tv"  # mirror a real TV
        ws = FakeWS(responder=self._on_message)
        self.connections.append(ws)
        return ws

    async def drop_connections(self) -> None:
        for ws in list(self.connections):
            await ws.close()

    def push_volume_update(self, volume: int, ws: FakeWS | None = None, sub_id: str | None = None) -> None:
        if ws is None or sub_id is None:
            ws, sub_id = self.sub_ids[protocol.URI_GET_VOLUME]
        self.volume = volume
        ws.push({"type": "response", "id": sub_id, "payload": self._volume_payload()})

    # -- responders ---------------------------------------------------------
    async def _on_pointer(self, ws: FakeWS, raw: str) -> None:
        self.buttons.append(raw)

    async def _on_message(self, ws: FakeWS, raw: str) -> None:
        msg = json.loads(raw)
        mid = msg.get("id")
        mtype = msg.get("type")
        if mtype == "register":
            if self.silent_register:
                return
            supplied = (msg.get("payload") or {}).get("client-key")
            if supplied and supplied in self.known_keys:
                ws.push({"type": "registered", "id": mid, "payload": {"client-key": supplied}})
                return
            if supplied and self.strict_keys:
                ws.push({"type": "error", "id": mid, "error": "403 pairing denied"})
                return
            ws.push({"type": "response", "id": mid, "payload": {"pairingType": "PROMPT"}})
            if self.approval_gate is not None:
                await self.approval_gate.wait()
            if not self.approve:
                ws.push({"type": "error", "id": mid, "error": "403 pairing denied"})
                return
            self.known_keys.add(self.client_key)
            ws.push({"type": "registered", "id": mid, "payload": {"client-key": self.client_key}})
            return
        if mtype not in ("request", "subscribe"):
            return
        uri = str(msg.get("uri") or "")
        self.requests.append(uri)
        if self.hang_requests:
            return
        if self.drop_on_request:
            await ws.close()
            return
        if self.error_requests:
            ws.push({"type": "error", "id": mid, "error": "500 Application error"})
            return
        if mtype == "subscribe":
            self.sub_ids[uri] = (ws, str(mid))
        reply = self._reply(uri, msg.get("payload") or {})
        if reply is None:
            ws.push({"type": "error", "id": mid, "error": "404 no such service or method"})
        else:
            ws.push({"type": "response", "id": mid, "payload": reply})

    def _volume_payload(self) -> dict:
        if self.legacy_volume:
            return {"returnValue": True, "volume": self.volume, "muted": self.muted}
        return {"returnValue": True, "volumeStatus": {"volume": self.volume, "muteStatus": self.muted}}

    def _reply(self, uri: str, payload: dict) -> dict | None:
        if uri in self.not_supported_uris:
            return None
        if uri == protocol.URI_SYSTEM_INFO:
            return {"returnValue": True, "modelName": "UA8000"}
        if uri == protocol.URI_GET_VOLUME:
            return self._volume_payload()
        if uri == protocol.URI_SET_VOLUME:
            self.volume = int(payload.get("volume", self.volume))
            return {"returnValue": True}
        if uri == protocol.URI_SET_MUTE:
            self.muted = bool(payload.get("mute"))
            return {"returnValue": True}
        if uri in (
            protocol.URI_MEDIA_PLAY,
            protocol.URI_MEDIA_PAUSE,
            protocol.URI_MEDIA_STOP,
            protocol.URI_MEDIA_REWIND,
            protocol.URI_MEDIA_FAST_FORWARD,
            protocol.URI_VOLUME_UP,
            protocol.URI_VOLUME_DOWN,
        ):
            return {"returnValue": True}
        if uri == protocol.URI_LIST_APPS:
            return {"returnValue": True, "apps": [dict(a) for a in self.apps]}
        if uri == protocol.URI_FOREGROUND_APP:
            return {"returnValue": True, "appId": self.foreground}
        if uri == protocol.URI_LAUNCH_APP:
            app_id = str(payload.get("id") or "")
            if app_id not in {a["id"] for a in self.apps}:
                return {"returnValue": False, "errorText": "no such app"}
            self.launched.append(app_id)
            return {"returnValue": True}
        if uri == protocol.URI_INPUT_LIST:
            return {"returnValue": True, "devices": [dict(i) for i in self.inputs]}
        if uri == protocol.URI_SWITCH_INPUT:
            self.switched.append(str(payload.get("inputId") or ""))
            return {"returnValue": True}
        if uri == protocol.URI_POWER_STATE:
            if self.power_404:
                return None
            return {"returnValue": True, "state": "Active"}
        if uri == protocol.URI_TURN_OFF:
            self.turned_off += 1
            return {"returnValue": True}
        if uri == protocol.URI_POINTER_SOCKET:
            path = self.pointer_socket_path or f"wss://{self.seen_host}:3001/pointer/abc"
            return {"returnValue": True, "socketPath": path}
        if uri == protocol.URI_INSERT_TEXT:
            if self.refuse_text:
                return {"returnValue": False, "errorText": "401 insufficient permissions"}
            self.typed.append((str(payload.get("text") or ""), int(payload.get("replace") or 0)))
            return {"returnValue": True}
        if uri == protocol.URI_SEND_ENTER:
            if self.refuse_text:
                return {"returnValue": False, "errorText": "401 insufficient permissions"}
            self.enter_presses += 1
            return {"returnValue": True}
        return None


class FakeWoLSender:
    def __init__(self):
        self.calls: list[tuple[str, str]] = []
        self.fail = False
        self.oserror = False               # raw socket failure, not WoLError

    async def __call__(self, mac: str, host: str = "") -> None:
        if self.oserror:
            raise OSError(101, "Network is unreachable")
        if self.fail:
            raise WoLError("could not send the wake signal on this network")
        self.calls.append((mac, host))


async def _fixture_discover():
    return [
        {"host": "192.168.1.50", "name": "LG UA8000 Bedroom"},
        {"host": "bad host!", "name": "junk that must be filtered"},
    ]


@pytest.fixture
async def tv(db, bus, vault):
    fake = FakeTV()
    wol = FakeWoLSender()
    mgr = WebOSManager(
        db,
        bus,
        vault,
        connect_factory=fake.connect,
        wol_sender=wol,
        discover_fn=_fixture_discover,
        reconnect_delays=(0.05, 0.05),
    )
    await mgr.start()
    yield mgr, fake, wol
    await mgr.stop()


async def _pair_and_connect(mgr, host="192.168.1.50"):
    await mgr.configure(host=host, enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)


# ---------------------------------------------------------------------------
# protocol: allowlist, register payload, validators
# ---------------------------------------------------------------------------

def test_allowlist_is_closed():
    assert protocol.URI_LAUNCH_APP in protocol.ALLOWED_URIS
    assert "ssap://system/reboot" not in protocol.ALLOWED_URIS
    assert "ssap://com.webos.service.secondscreen.gateway/test" not in protocol.ALLOWED_URIS
    assert protocol.SUBSCRIBABLE_URIS <= protocol.ALLOWED_URIS
    # IME typing is allowlisted, but only insert/enter -- nothing else from
    # the ime service (no deleteCharacters, no registerRemoteKeyboard).
    assert protocol.URI_INSERT_TEXT in protocol.ALLOWED_URIS
    assert protocol.URI_SEND_ENTER in protocol.ALLOWED_URIS
    assert "ssap://com.webos.service.ime/deleteCharacters" not in protocol.ALLOWED_URIS
    assert "ssap://com.webos.service.ime/registerRemoteKeyboard" not in protocol.ALLOWED_URIS
    assert "CONTROL_INPUT_TEXT" in protocol.REGISTER_PERMISSIONS
    for name in ("up", "down", "left", "right", "ok", "back", "home", "menu"):
        assert name in protocol.BUTTONS
    assert "power" not in protocol.BUTTONS  # power goes through turnOff/WoL only


def test_register_payload_key_handling():
    fresh = protocol.build_register_payload(None)
    assert "client-key" not in fresh
    assert fresh["pairingType"] == "PROMPT"
    assert "READ_INSTALLED_APPS" in fresh["manifest"]["permissions"]
    again = protocol.build_register_payload("stored-key")
    assert again["client-key"] == "stored-key"


def test_validators():
    assert protocol.valid_host("192.168.1.50")
    assert protocol.valid_host("lg-tv.lan")
    assert not protocol.valid_host("192.168.1.50:3000")
    assert not protocol.valid_host("http://tv")
    assert not protocol.valid_host("two words")
    assert not protocol.valid_host("")
    assert protocol.normalize_mac(MAC_INPUT) == MAC_NORM
    assert protocol.normalize_mac("AABBCCDDEEFF") == MAC_NORM
    assert protocol.normalize_mac("aa:bb:cc:dd:ee:ff") == MAC_NORM
    assert protocol.normalize_mac("not-a-mac") is None
    assert protocol.normalize_mac("aa:bb:cc:dd:ee") is None
    assert protocol.clamp_volume(150) == 100
    assert protocol.clamp_volume(-5) == 0
    assert protocol.clamp_volume("42") == 42
    with pytest.raises(ValueError):
        protocol.clamp_volume("loud")


# ---------------------------------------------------------------------------
# Wake-on-LAN + SSDP parsing
# ---------------------------------------------------------------------------

def test_magic_packet_layout():
    pkt = build_magic_packet(MAC_INPUT)
    assert len(pkt) == 102
    assert pkt[:6] == b"\xff" * 6
    assert pkt[6:] == bytes.fromhex("aabbccddeeff") * 16


def test_magic_packet_rejects_bad_mac():
    with pytest.raises(WoLError):
        build_magic_packet("nope")


def test_parse_ssdp_response():
    good = (
        b"HTTP/1.1 200 OK\r\n"
        b"ST: urn:lge-com:service:webos-second-screen:1\r\n"
        b"LOCATION: http://192.168.1.50:1837/desc.xml\r\n\r\n"
    )
    hit = parse_ssdp_response(good, "192.168.1.50")
    assert hit == {"host": "192.168.1.50", "location": "http://192.168.1.50:1837/desc.xml"}
    other = parse_ssdp_response(b"HTTP/1.1 200 OK\r\nST: upnp:rootdevice\r\n\r\n", "192.168.1.9")
    assert other is None
    assert parse_ssdp_response(b"garbage", "192.168.1.9") is None


def test_ssdp_hostile_locations_are_dropped():
    """LOCATION is attacker-controllable UDP input: anything that is not a
    plain http URL pointing at exactly the responding TV is blanked at parse
    time, so it can never be fetched (SSRF)."""
    def reply(location: str) -> bytes:
        return (
            b"HTTP/1.1 200 OK\r\n"
            b"ST: urn:lge-com:service:webos-second-screen:1\r\n"
            b"LOCATION: " + location.encode() + b"\r\n\r\n"
        )

    hostile = [
        "http://evil.example.com/desc.xml",        # hostname, never trusted
        "http://93.184.216.34/desc.xml",           # external, mismatched IP
        "http://192.168.1.99:1837/desc.xml",       # a different LAN device
        "http://127.0.0.1:8756/api/state",         # loopback
        "http://169.254.7.7/desc.xml",             # link-local
        "https://192.168.1.50/desc.xml",           # wrong scheme
        "file:///etc/passwd",                      # not http at all
        "http://user:pass@192.168.1.50/desc.xml",  # embedded credentials
        "http://192.168.1.50:99999/desc.xml",      # impossible port
        "http://192.168.1.50:x/desc.xml",          # junk port
        "http://" + "a" * 600 + "/x",              # oversized
    ]
    for loc in hostile:
        parsed = parse_ssdp_response(reply(loc), "192.168.1.50")
        assert parsed is not None and parsed["location"] == "", loc


async def test_friendly_name_never_requests_unsafe_locations(monkeypatch):
    """Defense in depth at fetch time: unsafe URLs never even construct an
    HTTP client, and a redirect answer from the TV is dropped, not chased."""
    import httpx

    from integrations.lg_webos import discovery

    constructed: list[dict] = []
    fetched: list[str] = []

    class FakeResp:
        status_code = 302
        text = "<friendlyName>redirected-name</friendlyName>"

    class FakeClient:
        def __init__(self, *args, **kwargs):
            constructed.append(kwargs)

        async def __aenter__(self):
            return self

        async def __aexit__(self, *exc):
            return False

        async def get(self, url):
            fetched.append(url)
            return FakeResp()

    monkeypatch.setattr(httpx, "AsyncClient", FakeClient)

    for loc in (
        "http://evil.example.com/desc.xml",
        "http://127.0.0.1:8756/api/state",
        "http://169.254.7.7/desc.xml",
        "http://192.168.1.99:1837/desc.xml",
        "https://192.168.1.50/desc.xml",
    ):
        assert await discovery._friendly_name(loc, "192.168.1.50") == ""
    assert constructed == [] and fetched == []  # not even a client was built

    # a valid TV location that answers with a redirect: exactly one request,
    # redirects disabled, and the 3xx answer is dropped rather than followed
    assert await discovery._friendly_name("http://192.168.1.50:1837/desc.xml", "192.168.1.50") == ""
    assert fetched == ["http://192.168.1.50:1837/desc.xml"]
    assert all(kw.get("follow_redirects") is False for kw in constructed)


# ---------------------------------------------------------------------------
# SSAP client against the fake TV
# ---------------------------------------------------------------------------

async def test_client_blocks_non_allowlisted_uri():
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        with pytest.raises(SSAPError, match="allowlist"):
            await c.request("ssap://system/reboot")
        with pytest.raises(SSAPError, match="allowlist"):
            await c.subscribe("ssap://evil/spy", lambda p: None)
        with pytest.raises(SSAPError, match="allowlist"):
            # allowlisted for requests but NOT subscribable
            await c.subscribe(protocol.URI_SYSTEM_INFO, lambda p: None)
        assert fake.requests == []  # nothing ever reached the TV
    finally:
        await c.close()


async def test_client_register_prompt_flow():
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        prompts: list[int] = []
        key = await c.register(None, on_prompt=lambda: prompts.append(1), timeout=2.0)
        assert key == fake.client_key
        assert prompts == [1]
        first = json.loads(fake.connections[0].sent[0])
        assert first["type"] == "register"
        assert "client-key" not in first["payload"]
        assert first["payload"]["pairingType"] == "PROMPT"
    finally:
        await c.close()


async def test_client_register_with_stored_key_is_silent():
    fake = FakeTV()
    fake.known_keys.add("old-key")
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        prompts: list[int] = []
        key = await c.register("old-key", on_prompt=lambda: prompts.append(1), timeout=2.0)
        assert key == "old-key"
        assert prompts == []
        first = json.loads(fake.connections[0].sent[0])
        assert first["payload"]["client-key"] == "old-key"
    finally:
        await c.close()


async def test_client_register_declined_and_timeout():
    fake = FakeTV()
    fake.approve = False
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    with pytest.raises(SSAPPairingRejected, match="declined"):
        await c.register(None, timeout=2.0)
    await c.close()

    fake2 = FakeTV()
    fake2.silent_register = True
    c2 = SSAPClient("tv.local", connect_factory=fake2.connect)
    await c2.connect()
    with pytest.raises(SSAPError, match="in time"):
        await c2.register(None, timeout=0.15)
    await c2.close()


async def test_client_tls_fallback():
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    assert c.used_tls is True
    await c.close()

    fake2 = FakeTV()
    fake2.refuse_tls = True
    c2 = SSAPClient("tv.local", connect_factory=fake2.connect)
    await c2.connect()
    assert c2.used_tls is False
    await c2.close()

    fake3 = FakeTV()
    fake3.refuse_connect = True
    c3 = SSAPClient("tv.local", connect_factory=fake3.connect)
    with pytest.raises(SSAPError, match="could not reach"):
        await c3.connect()


async def test_client_error_and_capability_paths():
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        with pytest.raises(SSAPError, match="no such app"):
            await c.request(protocol.URI_LAUNCH_APP, {"id": "not.installed"})
        fake.power_404 = True
        with pytest.raises(SSAPNotSupported):
            await c.request(protocol.URI_POWER_STATE)
    finally:
        await c.close()


async def test_client_button_pointer_socket():
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        with pytest.raises(SSAPError, match="not an allowed"):
            await c.button("power")
        assert fake.pointer_sockets == []  # invalid name opened nothing

        await c.button("ok")
        assert fake.pointer_sockets[0].sent == ["type:button\nname:ENTER\n\n"]
        await c.button("up")
        assert fake.pointer_sockets[0].sent[-1] == "type:button\nname:UP\n\n"
        assert len(fake.pointer_sockets) == 1  # socket is reused
    finally:
        await c.close()


async def test_client_rejects_hostile_pointer_sockets():
    """socketPath is TV-supplied input: a spoofed answer must never steer a
    button press at another host, port, scheme, or credentialed URL."""
    fake = FakeTV()
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    try:
        hostile = [
            "wss://evil.example.com:3001/pointer/abc",   # another host
            "wss://192.168.1.99:3001/pointer/abc",       # another device
            "wss://127.0.0.1:3001/pointer/abc",          # loopback
            "wss://tv.local:8080/pointer/abc",           # non-SSAP port
            "wss://tv.local:99999/pointer/abc",          # junk port
            "wss://tv.local/pointer/abc",                # missing port
            "ws://user:pass@tv.local:3000/pointer/abc",  # credentials
            "https://tv.local:3001/pointer/abc",         # not a websocket URL
        ]
        for path in hostile:
            fake.pointer_socket_path = path
            with pytest.raises(SSAPError, match="pointer socket"):
                await c.button("ok")
            assert fake.pointer_sockets == [], path  # nothing was ever opened
        fake.pointer_socket_path = None  # an honest answer works again
        await c.button("ok")
        assert len(fake.pointer_sockets) == 1
    finally:
        await c.close()


async def test_client_pending_requests_fail_on_disconnect():
    fake = FakeTV()
    fake.hang_requests = True
    c = SSAPClient("tv.local", connect_factory=fake.connect)
    await c.connect()
    task = asyncio.create_task(c.request(protocol.URI_GET_VOLUME, timeout=5.0))
    await asyncio.sleep(0.05)
    await fake.drop_connections()
    with pytest.raises(SSAPError, match="lost"):
        await task
    await c.close()


# ---------------------------------------------------------------------------
# manager: configuration
# ---------------------------------------------------------------------------

async def test_manager_configure_validation(tv):
    mgr, fake, wol = tv
    with pytest.raises(WebOSTVError, match="address"):
        await mgr.configure(host="not a host!")
    with pytest.raises(WebOSTVError, match="MAC"):
        await mgr.configure(mac="xyz")
    with pytest.raises(WebOSTVError, match="IP address"):
        await mgr.configure(enabled=True)  # no host yet
    assert mgr.enabled is False

    snap = await mgr.configure(host="192.168.1.50", name="Bedroom TV", mac=MAC_INPUT)
    assert snap["host"] == "192.168.1.50"
    assert snap["name"] == "Bedroom TV"
    assert snap["wol_ready"] is True
    assert "mac" not in snap and "mac_address" not in snap

    snap = await mgr.configure(mac="")
    assert snap["wol_ready"] is False


async def test_manager_discover(tv):
    mgr, fake, wol = tv
    found = await mgr.discover()
    assert found == [{"host": "192.168.1.50", "name": "LG UA8000 Bedroom"}]

    async def broken():
        raise RuntimeError("socket exploded")

    mgr._discover_fn = broken
    with pytest.raises(WebOSTVError, match="manually"):
        await mgr.discover()


# ---------------------------------------------------------------------------
# manager: pairing
# ---------------------------------------------------------------------------

async def test_manager_pairing_prompt_then_key_encrypted_at_rest(tv, db, vault):
    mgr, fake, wol = tv
    fake.approval_gate = asyncio.Event()
    await mgr.configure(host="192.168.1.50", enabled=True)

    res = await mgr.start_pairing()
    assert res == {"status": "connecting"}
    assert await eventually(lambda: mgr.snapshot()["pairing"]["status"] == "prompt")

    # a second click while waiting must not start a second attempt
    again = await mgr.start_pairing()
    assert again == {"status": "prompt"}
    assert len(fake.connections) == 1

    fake.approval_gate.set()
    assert await eventually(lambda: mgr.snapshot()["pairing"]["status"] == "paired")
    assert mgr.paired is True

    stored = await db.get_setting(KEY_SETTING)
    assert stored, "pairing key must be persisted"
    assert fake.client_key not in stored  # ciphertext, not plaintext
    assert vault.decrypt(bytes.fromhex(stored), KEY_CONTEXT) == fake.client_key

    # after pairing the manager connects by itself and fills its caches
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)
    snap = mgr.snapshot()
    assert snap["model"] == "UA8000"
    assert snap["volume"] == 20
    assert snap["muted"] is False
    assert snap["power"] == "active"
    assert snap["app_count"] == 3
    assert snap["apps_stale"] is False
    assert snap["app"] == "Netflix"
    assert {i["label"] for i in snap["inputs"]} == {"HDMI 1", "Gaming PC"}


async def test_manager_pairing_declined(tv, db):
    mgr, fake, wol = tv
    fake.approve = False
    await mgr.configure(host="192.168.1.50", enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["pairing"]["status"] == "failed")
    assert "declined" in mgr.snapshot()["pairing"]["error"]
    assert mgr.paired is False
    assert await db.get_setting(KEY_SETTING) is None


async def test_manager_unpair_forgets_key(tv, db):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    snap = await mgr.unpair()
    assert snap["paired"] is False
    assert snap["connected"] is False
    assert snap["pairing"]["status"] == "idle"
    assert await db.get_setting(KEY_SETTING) is None
    with pytest.raises(WebOSTVError, match="isn't paired"):
        await mgr.power_off()


async def test_manager_stored_key_rejected_means_repair(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    # the TV forgets us (user revoked the permission on the TV)
    fake.known_keys.clear()
    fake.approve = False
    await fake.drop_connections()
    assert await eventually(lambda: mgr.snapshot()["paired"] is False, timeout=5.0)
    assert "re-pair" in mgr.snapshot()["last_error"]
    with pytest.raises(WebOSTVError, match="isn't paired"):
        await mgr.set_volume(percentage=10)


async def test_manager_full_repair_after_tv_forgets_key(tv, db):
    """End-to-end recovery: pair, the TV revokes the key, the stale key is
    dropped automatically, and Pair works again with a fresh prompt."""
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    assert await db.get_setting(KEY_SETTING) is not None

    # the TV forgets us and the user hasn't re-approved anything yet
    fake.known_keys.clear()
    fake.approve = False
    await fake.drop_connections()
    assert await eventually(lambda: mgr.snapshot()["paired"] is False, timeout=5.0)
    assert await db.get_setting(KEY_SETTING) is None  # the stale key is gone

    # the user clicks Pair and approves the fresh on-screen prompt
    fake.approve = True
    await mgr.start_pairing()
    assert await eventually(
        lambda: mgr.snapshot()["pairing"]["status"] == "paired" and mgr.snapshot()["connected"],
        timeout=5.0,
    )
    assert await db.get_setting(KEY_SETTING) is not None  # a fresh key is stored
    await mgr.set_volume(percentage=25)  # and commands work again


async def test_manager_pair_retries_fresh_when_stored_key_is_stale(tv, db):
    """Pair pressed while a revoked key is still stored: pairing drops the
    stale key mid-flight and completes with a fresh prompt (real TVs reject
    unknown keys outright instead of re-prompting)."""
    mgr, fake, wol = tv
    fake.strict_keys = True
    await mgr.configure(host="192.168.1.50", enabled=True)  # not paired: no loop
    await db.set_setting(KEY_SETTING, mgr.vault.encrypt("stale-key", KEY_CONTEXT).hex())

    await mgr.start_pairing()
    assert await eventually(
        lambda: mgr.snapshot()["pairing"]["status"] == "paired" and mgr.snapshot()["connected"],
        timeout=5.0,
    )
    stored = await db.get_setting(KEY_SETTING)
    assert stored is not None
    assert mgr.vault.decrypt(bytes.fromhex(stored), KEY_CONTEXT) != "stale-key"


# ---------------------------------------------------------------------------
# manager: reconnect, offline behavior, fencing
# ---------------------------------------------------------------------------

async def test_manager_reconnects_after_drop(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    seen = len(fake.connections)
    await fake.drop_connections()
    assert await eventually(
        lambda: len(fake.connections) > seen and mgr.snapshot()["connected"], timeout=5.0
    )
    assert mgr.snapshot()["apps_stale"] is False  # refreshed on reconnect


async def test_manager_offline_commands_fail_clearly(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    fake.refuse_connect = True
    await fake.drop_connections()
    assert await eventually(lambda: not mgr.snapshot()["connected"])

    with pytest.raises(WebOSTVError, match="offline"):
        await mgr.set_volume(percentage=10)
    with pytest.raises(WebOSTVError, match="offline"):
        await mgr.launch_app("netflix")
    assert mgr.snapshot()["last_error"] != ""

    # the cached app list still answers searches, marked stale
    res = mgr.search_apps("netflix")
    assert res["stale"] is True
    assert res["apps"][0]["title"] == "Netflix"

    st = mgr.status()
    assert st["connected"] is False
    assert "offline" in st["message"]


async def test_manager_live_updates_and_stale_connection_fencing(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)

    fake.push_volume_update(55)
    assert await eventually(lambda: mgr.snapshot()["volume"] == 55)

    old_ws, old_sub = fake.sub_ids[protocol.URI_GET_VOLUME]
    # reconfigure -> new generation + new connection to the "new" host
    await mgr.configure(host="192.168.1.60")
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)
    volume_now = mgr.snapshot()["volume"]

    # a late event from the dead connection must be a no-op
    fake.push_volume_update(99, ws=old_ws, sub_id=old_sub)
    await asyncio.sleep(0.15)
    assert mgr.snapshot()["volume"] == volume_now
    assert mgr.snapshot()["volume"] != 99


async def test_manager_power_state_not_supported(tv):
    mgr, fake, wol = tv
    fake.power_404 = True
    await _pair_and_connect(mgr)
    snap = mgr.snapshot()
    assert snap["power"] == "on"  # it answered the socket; sane fallback
    assert protocol.URI_POWER_STATE not in fake.sub_ids  # no doomed subscription


async def test_manager_legacy_volume_payload(tv):
    mgr, fake, wol = tv
    fake.legacy_volume = True
    fake.volume = 7
    await _pair_and_connect(mgr)
    assert mgr.snapshot()["volume"] == 7


async def test_manager_persisted_cache_survives_restart(tv, db, bus, vault):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    await mgr.stop()

    offline = FakeTV()
    offline.refuse_connect = True
    mgr2 = WebOSManager(
        db, bus, vault,
        connect_factory=offline.connect,
        wol_sender=FakeWoLSender(),
        discover_fn=_fixture_discover,
        reconnect_delays=(0.05, 0.05),
    )
    await mgr2.start()
    try:
        assert mgr2.enabled is True
        assert mgr2.paired is True
        res = mgr2.search_apps("netflix")
        assert res["stale"] is True  # persisted lists are never trusted fresh
        assert res["apps"][0]["title"] == "Netflix"
    finally:
        await mgr2.stop()


# ---------------------------------------------------------------------------
# manager: command surface
# ---------------------------------------------------------------------------

async def test_manager_commands_roundtrip(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)

    assert await mgr.set_volume(percentage=33) == {"volume": 33}
    assert fake.volume == 33
    assert await mgr.set_volume(delta=-3) == {"volume": 30}
    assert await mgr.set_volume(percentage=999) == {"volume": 100}
    with pytest.raises(WebOSTVError):
        await mgr.set_volume()

    assert await mgr.set_mute(True) == {"muted": True}
    assert fake.muted is True

    await mgr.media("pause")
    assert protocol.URI_MEDIA_PAUSE in fake.requests
    with pytest.raises(WebOSTVError, match="media action"):
        await mgr.media("eject")

    assert await mgr.button("ok") == {"pressed": "ok"}
    assert fake.pointer_sockets[0].sent[-1] == "type:button\nname:ENTER\n\n"
    assert await mgr.button("Channel Up") == {"pressed": "channel_up"}
    assert fake.pointer_sockets[0].sent[-1] == "type:button\nname:CHANNELUP\n\n"
    with pytest.raises(WebOSTVError, match="button must be one of"):
        await mgr.button("factory_reset")

    inputs = await mgr.list_inputs()
    assert {i["label"] for i in inputs["inputs"]} == {"HDMI 1", "Gaming PC"}
    assert await mgr.set_input("gaming") == {"input": "Gaming PC"}
    assert fake.switched == ["HDMI_2"]
    with pytest.raises(WebOSTVError, match="matches several"):
        await mgr.set_input("h")
    with pytest.raises(WebOSTVError, match="no input matches"):
        await mgr.set_input("component")

    assert (await mgr.power_off())["message"]
    assert fake.turned_off == 1


async def test_manager_app_search_and_launch(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)

    # search: exact, substring, empty query lists alphabetically
    res = mgr.search_apps("netflix")
    assert res["apps"][0] == {"id": "netflix", "title": "Netflix"}
    assert res["stale"] is False
    assert res["installed_count"] == 3
    assert [a["title"] for a in mgr.search_apps("")["apps"]] == ["Disney+", "Netflix", "YouTube"]
    assert mgr.search_apps("zzz-nothing")["apps"] == []

    # launch by title (case-insensitive), by id, by unique substring, fuzzy
    assert await mgr.launch_app("NETFLIX") == {"launched": "Netflix"}
    assert await mgr.launch_app("youtube.leanback.v4") == {"launched": "YouTube"}
    assert await mgr.launch_app("disney") == {"launched": "Disney+"}
    assert await mgr.launch_app("netflx") == {"launched": "Netflix"}  # fuzzy
    assert fake.launched == ["netflix", "youtube.leanback.v4", "com.disney.disneyplus-prod", "netflix"]

    # ambiguous and missing apps are reported, never guessed
    fake.apps.append({"id": "netflix.kids", "title": "Netflix Kids"})
    await mgr.refresh_apps()
    with pytest.raises(WebOSTVError, match="matches several"):
        await mgr.launch_app("netfl")
    launched_before = list(fake.launched)
    with pytest.raises(WebOSTVError, match="isn't installed"):
        await mgr.launch_app("hulu")
    assert fake.launched == launched_before


async def test_manager_wol_power_on(tv):
    mgr, fake, wol = tv
    with pytest.raises(WebOSTVError, match="turned off"):
        await mgr.power_on()

    await mgr.configure(host="192.168.1.50", enabled=True)  # not paired: no loop
    with pytest.raises(WebOSTVError, match="MAC"):
        await mgr.power_on()

    await mgr.configure(mac=MAC_INPUT)
    res = await mgr.power_on()
    assert "Wake signal sent" in res["message"]
    assert wol.calls == [(MAC_NORM, "192.168.1.50")]

    wol.fail = True
    with pytest.raises(WebOSTVError, match="wake signal"):
        await mgr.power_on()


async def test_manager_power_on_wakes_connected_tv_marked_off(tv):
    """turnOff may leave SSAP connected while the panel is already off."""
    mgr, fake, wol = tv
    await mgr.configure(host="192.168.1.50", mac=MAC_INPUT, enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)

    await mgr.power_off()
    assert mgr.snapshot()["connected"] is True
    assert mgr.snapshot()["power"] == "off"

    result = await mgr.power_on()
    assert "Wake signal sent" in result["message"]
    assert "already on" not in result["message"].lower()
    assert wol.calls == [(MAC_NORM, "192.168.1.50")]


async def test_manager_power_on_skips_wol_when_connected_and_active(tv):
    mgr, fake, wol = tv
    await mgr.configure(host="192.168.1.50", mac=MAC_INPUT, enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)
    assert mgr.snapshot()["power"] == "active"

    assert await mgr.power_on() == {"message": "The TV is already on."}
    assert wol.calls == []


async def test_manager_power_on_wakes_disconnected_tv_with_stale_on_cache(tv):
    mgr, fake, wol = tv
    await mgr.configure(host="192.168.1.50", mac=MAC_INPUT, enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)
    assert mgr.snapshot()["power"] == "active"

    fake.refuse_connect = True
    await fake.drop_connections()
    assert await eventually(lambda: not mgr.snapshot()["connected"], timeout=5.0)
    assert mgr.snapshot()["power"] == "active"  # cached state from the old connection

    result = await mgr.power_on()
    assert "Wake signal sent" in result["message"]
    assert wol.calls == [(MAC_NORM, "192.168.1.50")]


async def test_manager_power_on_translates_raw_socket_errors(tv):
    mgr, fake, wol = tv
    await mgr.configure(host="192.168.1.50", enabled=True, mac=MAC_INPUT)  # not paired: no loop
    wol.oserror = True
    with pytest.raises(WebOSTVError, match="wake signal") as excinfo:
        await mgr.power_on()
    assert "unreachable" not in str(excinfo.value).lower()  # raw OS detail never leaks


async def test_send_wol_socket_creation_failure_is_wol_error(monkeypatch):
    import socket as socket_mod

    from integrations.lg_webos.wol import send_wol

    def boom(*args, **kwargs):
        raise OSError(105, "No buffer space available")

    monkeypatch.setattr(socket_mod, "socket", boom)
    with pytest.raises(WoLError, match="wake signal"):
        await send_wol(MAC_INPUT, "192.168.1.50")


async def test_manager_button_rejects_hijacked_pointer_socket(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    fake.pointer_socket_path = "wss://evil.example.com:3001/pointer/abc"
    with pytest.raises(WebOSTVError, match="pointer socket"):
        await mgr.button("ok")
    assert fake.pointer_sockets == []


async def test_manager_disabled_and_status_shapes(tv):
    mgr, fake, wol = tv
    assert mgr.status() == {"enabled": False, "message": "TV control is turned off."}
    with pytest.raises(WebOSTVError, match="turned off"):
        mgr.search_apps("netflix")

    await mgr.configure(host="192.168.1.50", enabled=True)
    st = mgr.status()
    assert st["paired"] is False and "isn't paired" in st["message"]

    await _pair_and_connect(mgr)
    st = mgr.status()
    assert st["connected"] is True
    assert st["volume"] == 20
    assert st["app"] == "Netflix"
    assert st["model"] == "UA8000"


# ---------------------------------------------------------------------------
# secrecy: pairing key and MAC never leak
# ---------------------------------------------------------------------------

async def test_no_secrets_in_logs_events_or_views(tv, db, bus):
    mgr, fake, wol = tv
    captured: list[dict] = []
    bus.subscribe("tv", lambda **kw: captured.append(kw))

    await mgr.configure(host="192.168.1.50", mac=MAC_INPUT, enabled=True)
    await mgr.start_pairing()
    assert await eventually(lambda: mgr.snapshot()["connected"], timeout=5.0)
    await mgr.power_off()
    await mgr.unpair()

    rows = await db.fetchall("SELECT message FROM events_log")
    logged = " ".join(str(r["message"]) for r in rows).lower()
    assert fake.client_key.lower() not in logged
    assert MAC_NORM.lower() not in logged
    assert "aabbccddeeff" not in logged.replace(":", "").replace("-", "")

    views = json.dumps([mgr.snapshot(), mgr.status()]).lower()
    assert fake.client_key.lower() not in views
    assert MAC_NORM.lower() not in views

    events = json.dumps(captured, default=str).lower()
    assert fake.client_key.lower() not in events
    assert MAC_NORM.lower() not in events


# ---------------------------------------------------------------------------
# error boundary: transport failures never escape as raw exceptions
# ---------------------------------------------------------------------------

async def test_manager_commands_translate_tv_errors(tv):
    """A TV-side failure during any command must surface as WebOSTVError --
    the one public error type -- never as a raw SSAPError."""
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    fake.error_requests = True
    for attempt in (
        mgr.power_off,
        lambda: mgr.set_volume(percentage=30),
        lambda: mgr.set_volume(delta=5),
        lambda: mgr.set_mute(True),
        lambda: mgr.media("pause"),
        lambda: mgr.set_input("hdmi 1"),
        mgr.refresh_apps,
        lambda: mgr.launch_app("netflix"),
    ):
        with pytest.raises(WebOSTVError):
            await attempt()


async def test_manager_command_when_connection_drops_mid_call(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    fake.drop_on_request = True
    with pytest.raises(WebOSTVError) as ei:
        await mgr.set_mute(True)
    msg = str(ei.value)
    assert "lost" in msg or "not connected" in msg or "offline" in msg


async def test_manager_translates_not_supported_commands(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    fake.not_supported_uris.add(protocol.URI_TURN_OFF)
    with pytest.raises(WebOSTVError) as ei:
        await mgr.power_off()
    assert "doesn't support" in str(ei.value)


async def test_manager_invalid_volume_values_are_safe_errors(tv):
    mgr, fake, wol = tv
    await _pair_and_connect(mgr)
    with pytest.raises(WebOSTVError):
        await mgr.set_volume(percentage="loud")
    with pytest.raises(WebOSTVError):
        await mgr.set_volume(delta="much")
    # the connection stays healthy afterwards
    assert await mgr.set_volume(percentage=30) == {"volume": 30}


# ---------------------------------------------------------------------------
# tool service: the tv_* dispatch surface
# ---------------------------------------------------------------------------

async def test_tool_service_tv_dispatch(tv, db, bus, store):
    from apps.tool_service.service import ToolService
    from apps.tool_service.timers import TimerManager

    mgr, fake, wol = tv
    tools = ToolService(db, bus, TimerManager(db, bus), store, tv=mgr)

    # disabled TV: status still answers; commands become clear errors
    res = await tools.dispatch("", "tv_status", {})
    assert res == {"enabled": False, "message": "TV control is turned off."}
    res = await tools.dispatch("", "tv_set_volume", {"percentage": 40})
    assert "turned off" in res["error"]

    await _pair_and_connect(mgr)
    assert await tools.dispatch("", "tv_set_volume", {"percentage": 40}) == {"volume": 40}
    assert await tools.dispatch("", "tv_mute", {"muted": True}) == {"muted": True}
    assert (await tools.dispatch("", "tv_mute", {"muted": "yes"}))["error"] == "muted must be true or false"
    assert (await tools.dispatch("", "tv_power", {"state": "sideways"}))["error"] == "state must be 'on' or 'off'"
    assert (await tools.dispatch("", "tv_button", {"button": "up"}))["pressed"] == "up"
    assert "isn't installed" in (await tools.dispatch("", "tv_launch_app", {"app": "hulu"}))["error"]
    res = await tools.dispatch("", "tv_search_apps", {"query": "you"})
    assert [a["title"] for a in res["apps"]] == ["YouTube"]
    assert (await tools.dispatch("", "tv_status", {}))["connected"] is True
    assert (await tools.dispatch("", "tv_media", {"action": "pause"})) == {"action": "pause"}

    # no TV manager wired at all -> a clear, sanitized error
    none_tools = ToolService(db, bus, TimerManager(db, bus), store, tv=None)
    assert (await none_tools.dispatch("", "tv_status", {}))["error"] == "TV control is not available"


async def test_tool_service_tv_failures_stay_bounded(tv, db, bus, store):
    """Transport failures and bad values come back as clean {'error': ...}
    results -- never the generic 'tool execution failed' crash path."""
    from apps.tool_service.service import ToolService
    from apps.tool_service.timers import TimerManager

    mgr, fake, wol = tv
    tools = ToolService(db, bus, TimerManager(db, bus), store, tv=mgr)
    await _pair_and_connect(mgr)

    res = await tools.dispatch("", "tv_set_volume", {"percentage": "loud"})
    assert "between 0 and 100" in res["error"]

    fake.error_requests = True
    for name, args in (
        ("tv_power", {"state": "off"}),
        ("tv_set_volume", {"percentage": 30}),
        ("tv_mute", {"muted": True}),
        ("tv_media", {"action": "pause"}),
        ("tv_set_input", {"input": "hdmi 1"}),
        ("tv_launch_app", {"app": "netflix"}),
    ):
        res = await tools.dispatch("", name, args)
        assert "error" in res, name
        assert res["error"] != "tool execution failed", name


def test_tv_tool_declarations_present():
    from apps.tool_service.schemas import TOOL_DECLARATIONS

    names = {d["name"] for d in TOOL_DECLARATIONS}
    for tool in (
        "tv_power", "tv_set_volume", "tv_mute", "tv_media", "tv_button",
        "tv_set_input", "tv_launch_app", "tv_search_apps", "tv_status",
        "tv_type_text",
    ):
        assert tool in names, tool


async def test_tool_service_power_on_socket_failure_bounded(tv, db, bus, store):
    """A raw socket failure during Wake-on-LAN surfaces as a clean tool
    error through dispatch -- never the generic crash path."""
    from apps.tool_service.service import ToolService
    from apps.tool_service.timers import TimerManager

    mgr, fake, wol = tv
    tools = ToolService(db, bus, TimerManager(db, bus), store, tv=mgr)
    await mgr.configure(host="192.168.1.50", enabled=True, mac=MAC_INPUT)  # not paired: no loop
    wol.oserror = True
    res = await tools.dispatch("", "tv_power", {"state": "on"})
    assert res["error"] == "could not send the wake signal on this network"


# ---------------------------------------------------------------------------
# manager: type_text (IME keyboard entry)
# ---------------------------------------------------------------------------

async def test_type_text_inserts_via_ime(tv):
    mgr, fake, _ = tv
    await _pair_and_connect(mgr)
    res = await mgr.type_text("stranger things")
    assert res == {"typed": len("stranger things"), "submitted": False}
    assert fake.typed == [("stranger things", 0)]
    assert fake.enter_presses == 0


async def test_type_text_submit_presses_enter(tv):
    mgr, fake, _ = tv
    await _pair_and_connect(mgr)
    res = await mgr.type_text("  weather tomorrow  ", submit=True)
    assert res == {"typed": len("weather tomorrow"), "submitted": True}
    assert fake.typed == [("weather tomorrow", 0)]
    assert fake.enter_presses == 1


async def test_type_text_validation(tv):
    mgr, fake, _ = tv
    await _pair_and_connect(mgr)
    with pytest.raises(WebOSTVError, match="no text"):
        await mgr.type_text("   ")
    with pytest.raises(WebOSTVError, match="120 characters"):
        await mgr.type_text("x" * 121)
    with pytest.raises(WebOSTVError, match="control characters"):
        await mgr.type_text("line one\nline two")
    with pytest.raises(WebOSTVError, match="control characters"):
        await mgr.type_text("tab\there")
    assert fake.typed == []  # nothing invalid ever reached the TV
    # exactly at the cap is fine
    res = await mgr.type_text("y" * 120)
    assert res["typed"] == 120


async def test_type_text_requires_connection(tv):
    mgr, fake, _ = tv
    await mgr.configure(host="192.168.1.50", enabled=True)
    with pytest.raises(WebOSTVError, match="paired"):
        await mgr.type_text("hello")
    assert fake.typed == []


async def test_type_text_permission_refusal_hints_repair(tv):
    """A TV paired before CONTROL_INPUT_TEXT was requested refuses IME writes;
    the error must tell the user to re-pair, not show a raw 401."""
    mgr, fake, _ = tv
    await _pair_and_connect(mgr)
    fake.refuse_text = True
    with pytest.raises(WebOSTVError, match="pair again"):
        await mgr.type_text("hello")


async def test_type_text_never_logged(tv, caplog):
    """The typed text must not appear in any log record."""
    import logging

    mgr, fake, _ = tv
    await _pair_and_connect(mgr)
    secret_text = "myS3cretSearch"
    with caplog.at_level(logging.DEBUG):
        await mgr.type_text(secret_text, submit=True)
        fake.refuse_text = True
        with pytest.raises(WebOSTVError):
            await mgr.type_text(secret_text)
    assert secret_text not in caplog.text


async def test_tool_dispatch_type_text(tv, db, bus, store):
    from apps.tool_service.service import ToolService
    from apps.tool_service.timers import TimerManager

    mgr, fake, _ = tv
    tools = ToolService(db, bus, TimerManager(db, bus), store, tv=mgr)
    await _pair_and_connect(mgr)

    res = await tools.dispatch("", "tv_type_text", {"text": "dune part two", "submit": True})
    assert res == {"typed": len("dune part two"), "submitted": True}
    assert fake.typed == [("dune part two", 0)]
    assert fake.enter_presses == 1

    res = await tools.dispatch("", "tv_type_text", {"text": ""})
    assert res["error"] == "text is required"
    res = await tools.dispatch("", "tv_type_text", {"text": 42})
    assert res["error"] == "text is required"
