// TV remote browser-level test: loads the real /devices page in jsdom with
// scripts enabled, intercepts only the /api/tv endpoints, and drives the
// remote through offline → connected → typing → mute flows. Guards:
//   * remote visible while paired-but-offline (power key can wake the TV)
//   * one state-aware power key (wake vs power off) + best-effort labelling
//   * non-power controls disabled while offline
//   * polling must NOT clobber the text composer's value or focus
//   * Type / Type + Enter post the bounded type_text command and clear only
//     on success
import assert from "node:assert/strict";
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = "http://127.0.0.1:8756";
let cookie = "";

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}
async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// ---- session: harness.mjs already ran /setup with this password ----
{
  const form = new URLSearchParams();
  form.set("password", "Testpass123");
  const r = await req("/login", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", origin: BASE, referer: BASE + "/login" },
    body: form.toString(),
  });
  if (![200, 302, 303].includes(r.status)) { console.log("FATAL: login failed:", r.status); process.exit(2); }
}

const resp = await req("/devices");
if (resp.status !== 200) { console.log("FATAL: /devices HTTP", resp.status); process.exit(2); }
const html = await resp.text();

// ---- fake TV state, mutated per scenario ----
let tv = {
  enabled: true, configured: true, host: "192.168.1.50", name: "Living room TV",
  paired: true, connected: false, pairing: { status: "paired", error: "" },
  power: "off", volume: 20, muted: false, app: "", model: "LG C3",
  app_count: 0, apps_stale: false, inputs: [], wol_ready: true,
  last_error: "the TV did not answer", last_seen_at: null,
};
const commands = [];

const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(html, {
  url: BASE + "/devices",
  runScripts: "dangerously",
  resources: "usable",
  pretendToBeVisual: true,
  virtualConsole: vc,
  beforeParse(window) {
    window.alert = () => {};
    window.confirm = () => true;
    window.fetch = (p, o = {}) => {
      const path = new URL(p, BASE + "/devices").pathname;
      // Node's global Response (jsdom has none); the page's api() helper
      // already consumes node-fetch responses via the passthrough below.
      if (path === "/api/tv" && (!o.method || o.method === "GET")) {
        return Promise.resolve(new Response(JSON.stringify(tv), {
          status: 200, headers: { "content-type": "application/json" },
        }));
      }
      if (path === "/api/tv/command") {
        const body = JSON.parse(o.body || "{}");
        commands.push(body);
        return Promise.resolve(new Response(
          JSON.stringify({ ok: true, message: "done" }),
          { status: 200, headers: { "content-type": "application/json" } },
        ));
      }
      const { signal, ...rest } = o;
      rest.headers = { ...(rest.headers || {}), cookie };
      return fetch(new URL(p, BASE + "/devices").href, rest);
    };
  },
});

await new Promise((res) => {
  let done = false;
  const finish = () => { if (!done) { done = true; setTimeout(res, 900); } };
  dom.window.addEventListener("load", finish);
  setTimeout(finish, 3000);
});

const doc = dom.window.document;
const el = (id) => doc.getElementById(id);
const poll = async () => { await dom.window.loadTv(); await new Promise((r) => setTimeout(r, 50)); };

let failures = 0;
const check = (name, fn) => {
  try { fn(); console.log("  ok  " + name); }
  catch (e) { console.log("FAIL  " + name + ": " + e.message); failures++; }
};

// ---- 1. paired but OFFLINE: remote shows, only power usable ----
check("offline: remote body is visible so the TV can be woken", () => {
  assert.notEqual(el("tv-remote").style.display, "none");
  assert.ok(el("tv-remote").classList.contains("tvr-offline"));
});
check("offline: Wake-on-LAN note is shown and labelled best effort", () => {
  assert.notEqual(el("tv-offline-note").style.display, "none");
  assert.match(el("tv-offline-note").textContent, /best\s*effort/i);
  assert.match(el("tv-power-note").textContent, /best effort/i);
});
check("offline: power key enabled (wake), other keys disabled", () => {
  assert.equal(el("tv-power").disabled, false);
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, true);
  assert.equal(el("tv-type-text").disabled, true);
  assert.equal(el("tv-vol-set").disabled, true);
});
check("offline: power click sends power_on (wake attempt)", () => {
  el("tv-power").click();
  assert.equal(commands.at(-1).action, "power_on");
});

// ---- 2. no MAC saved: power key disabled with guidance ----
tv = { ...tv, wol_ready: false };
await poll();
check("offline without MAC: power key disabled with hint", () => {
  assert.equal(el("tv-power").disabled, true);
  assert.match(el("tv-power-note").textContent, /MAC address/i);
});

// ---- 3. CONNECTED: keys enable, power becomes power-off ----
tv = {
  ...tv, connected: true, power: "on", wol_ready: true, app: "Netflix",
  inputs: [{ label: "HDMI 1" }, { label: "HDMI 2" }], last_error: "",
};
await poll();
check("connected: controls enabled, offline chrome gone", () => {
  assert.ok(!el("tv-remote").classList.contains("tvr-offline"));
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.equal(el("tv-offline-note").style.display, "none");
});
check("connected: power key is ON-state and sends power_off", () => {
  assert.ok(el("tv-power").classList.contains("on"));
  assert.match(el("tv-power-label").textContent, /^On/);
  el("tv-power").click();
  assert.equal(commands.at(-1).action, "power_off");
});
check("connected: D-pad OK sends button ok", () => {
  doc.querySelector(".tvr-ok").click();
  assert.deepEqual(commands.at(-1), { action: "button", value: "ok" });
});
check("connected: input selector populated", () => {
  assert.equal(el("tv-input").options.length, 2);
  assert.notEqual(el("tv-input-row").style.display, "none");
});

// ---- 4. polling must not clobber the composer ----
const composer = el("tv-type-text");
composer.value = "stranger things";
composer.focus();
await poll();
await poll();
check("polling preserves composer text and focus", () => {
  assert.equal(composer.value, "stranger things");
  assert.equal(doc.activeElement, composer);
});

// ---- 5. typing commands ----
el("tv-type-send").click();
await new Promise((r) => setTimeout(r, 50));
check("Type sends type_text without submit and clears on success", () => {
  const cmd = commands.at(-1);
  assert.equal(cmd.action, "type_text");
  assert.equal(cmd.text, "stranger things");
  assert.equal(cmd.submit, false);
  assert.equal(composer.value, "");
  assert.equal(doc.activeElement, composer);
});
composer.value = "dark";
el("tv-type-go").click();
await new Promise((r) => setTimeout(r, 50));
check("Type + Enter sends submit=true", () => {
  const cmd = commands.at(-1);
  assert.equal(cmd.action, "type_text");
  assert.equal(cmd.text, "dark");
  assert.equal(cmd.submit, true);
});
check("empty composer is rejected locally without an API call", () => {
  const before = commands.length;
  el("tv-type-send").click();
  assert.equal(commands.length, before);
  assert.match(el("tv-error").textContent, /text first/i);
});

// ---- 6. mute is state-aware ----
tv = { ...tv, muted: true };
await poll();
check("muted snapshot flips the key to Unmute and sends unmute", () => {
  assert.equal(el("tv-mute").textContent, "Unmute");
  el("tv-mute").click();
  assert.equal(commands.at(-1).action, "unmute");
});

// ---- page JS errors collected along the way ----
check("no page JavaScript errors", () => {
  assert.deepEqual(errors, []);
});

dom.window.close();
console.log(failures === 0 ? "TV REMOTE CHECKS PASSED" : `${failures} TV REMOTE FAILURES`);
process.exit(failures === 0 ? 0 : 1);
