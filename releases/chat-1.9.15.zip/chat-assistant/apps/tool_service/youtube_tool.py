"""Lightweight YouTube search and dashboard-player command controller.

The server never decodes or downloads media.  It keeps a tiny in-memory
candidate list and broadcasts control events to exactly one leased Media page,
where the official YouTube IFrame Player performs playback.

When no embedded Media page is leased the server falls back to opening the
selected canonical https://www.youtube.com/watch?v=<id> URL in the Chat host
computer's default browser via webbrowser.open_new_tab, run off the asyncio
event loop in a thread pool (asyncio.to_thread) so the blocking OS call never
stalls the event loop.  The same async path is used for the 101/150 embed-error
fallback endpoint.  The injectable ``open_browser`` parameter lets tests swap in
a synchronous stub that records calls without launching a real browser.

Cross-transition safety
-----------------------
Between the first ``await`` of the host-browser open and its completion, the
server is in the ``"host_browser_pending"`` sub-state (tracked by
``_host_open_pending``, the validated video id).  While pending:

* ``claim()`` with ``force=False`` grants ownership but preserves the pending
  state and suppresses command rebound so no iframe is created.
* ``claim()`` with ``force=True`` records the new owner id in
  ``_force_claim_during_pending``; when the in-flight task finishes it detects
  the superseded context, leaves the mode as ``"embedded"``, and the owner's
  normal play command drives the iframe.
* ``report()`` and ``_emit_sync()`` skip ``_reset_host_browser_state()`` while
  pending so the in-flight task is not orphaned and cannot later mutate an
  embedded state.
* On successful open: if a force-claim arrived during pending the host-browser
  result is discarded (the new embedded owner takes over); otherwise
  ``playback_mode`` is set to ``"host_browser"``.
* On failure: ``_host_open_pending`` is cleared; if an owner appeared during
  pending the mode stays ``"embedded"``; the snapshot carries a safe explicit
  watch-link message.
* ``stop()`` fully cancels the pending state (the user said stop).
"""

from __future__ import annotations

import asyncio
import re
import secrets
import time
from datetime import datetime, timezone
from typing import Awaitable, Callable

from apps.tool_service.companion_bridge import CompanionError
from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore
from integrations.youtube import (
    YouTubeAPIError,
    YouTubeClient,
    canonical_playlist_url,
    canonical_video_url,
    canonical_watch_url,
    extract_playlist_id,
    extract_video_id,
)


def _default_open_in_host_browser(url: str) -> None:
    """Open *url* in the Chat host computer's normal/default browser.

    This is an intentional, user-requested external action: when no embedded
    Media player owner is available (or the official embed reports 101/150),
    the selected canonical https YouTube watch URL is opened in a new browser
    tab on the machine running Chat.  Uses ``webbrowser.open_new_tab`` and
    never shells out.  Always invoked through ``asyncio.to_thread`` so the
    blocking OS call does not stall the event loop.  Injected/overridden in
    tests so no browser ever launches during the test run.
    """
    import webbrowser

    webbrowser.open_new_tab(url)


MAX_QUEUE = 25
MAX_SEEK_SECONDS = 6 * 3600
OWNER_LEASE_SECONDS = 45.0
_CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,80}$")
_SEARCH_WORD_RE = re.compile(r"[a-z0-9]+")
_SEARCH_FILLER = {
    "a", "an", "and", "audio", "by", "for", "from", "live", "lyrics",
    "music", "official", "of", "on", "song", "the", "to", "version", "video",
}

# Terms that indicate a non-canonical result (degraded version) unless the
# original query explicitly contains them.  Each entry is a set of synonyms;
# any match in the result title incurs a penalty.
_DEGRADED_TITLE_TERMS: tuple[frozenset[str], ...] = (
    frozenset({"lyrics", "lyric", "lyric video"}),
    frozenset({"slowed", "slowed down", "slowed reverb", "slowed + reverb"}),
    frozenset({"reverb", "reverbed"}),
    frozenset({"cover", "covered by", "covered"}),
    frozenset({"remix", "remixed"}),
    frozenset({"sped up", "nightcore", "speed up"}),
    frozenset({"karaoke", "instrumental"}),
    frozenset({"tribute", "tribute to"}),
)

# Positive signals: official channels or title markers that indicate the
# canonical release.  Used to rank identical-scoring items.
_CANONICAL_TITLE_SIGNALS: frozenset[str] = frozenset({
    "official", "official video", "official audio", "official music video",
    "official lyric video", "official visualizer", "vevo",
})


class YouTubeError(Exception):
    """Safe local media-control validation error."""


def _text(value: object, limit: int) -> str:
    return " ".join(str(value or "").split()).strip()[:limit]


def _plausible_index_match(query: str, title: object) -> bool:
    """Reject obviously unrelated results from the key-free web index.

    A YouTube Data API result is authoritative enough to show as-is.  Generic
    web indexes can rank pages that match only one common word, so their title
    must contain at least half of the meaningful query terms (and at least two
    when the query supplied three or more).
    """
    wanted = {
        word for word in _SEARCH_WORD_RE.findall(query.lower())
        if word not in _SEARCH_FILLER
    }
    if not wanted:
        return False
    present = set(_SEARCH_WORD_RE.findall(_text(title, 240).lower()))
    minimum = 1 if len(wanted) <= 2 else max(2, (len(wanted) + 1) // 2)
    return len(wanted & present) >= minimum


def _query_words(query: str) -> frozenset[str]:
    """Return the meaningful lowercase words present in the query."""
    return frozenset(
        word for word in _SEARCH_WORD_RE.findall(query.lower())
        if word not in _SEARCH_FILLER
    )


def _pick_best_result(results: list[dict], query: str) -> dict | None:
    """Return the most canonical result from *results* for *query*.

    Scoring rules (higher is better):
    - Start at 0.
    - +2  if the channel or title contains any canonical signal (official/vevo).
    - -3  for each degraded-version term group present in the title *unless*
           that group's terms also appear in the query (user asked for it).

    Ties are broken by original list order (API result ranking).
    Returns None if *results* is empty.
    """
    if not results:
        return None

    query_lower = query.lower()

    def _score(item: dict) -> int:
        title = _text(item.get("title", ""), 240).lower()
        channel = _text(item.get("channel", ""), 160).lower()
        combined = f"{title} {channel}"

        score = 0
        # Canonical positive signal
        if any(sig in combined for sig in _CANONICAL_TITLE_SIGNALS):
            score += 2

        # Penalise degraded versions unless the query asked for them
        for group in _DEGRADED_TITLE_TERMS:
            if any(term in title for term in group):
                if not any(term in query_lower for term in group):
                    score -= 3

        return score

    # stable sort: highest score first, original order preserved for ties
    ranked = sorted(enumerate(results), key=lambda t: -_score(t[1]))
    return ranked[0][1]


class YouTubeTool:
    def __init__(
        self,
        bus: EventBus,
        credentials: CredentialStore,
        *,
        client_factory=YouTubeClient,
        on_playing: Callable[[bool], None] | None = None,
        web_search: Callable[[object, object], Awaitable[dict]] | None = None,
        open_browser: Callable[[str], None] | None = None,
    ) -> None:
        self.bus = bus
        self.credentials = credentials
        self.client_factory = client_factory
        self.on_playing = on_playing
        self.web_search = web_search
        # Injectable host-browser opener.  Production code uses the default
        # (webbrowser.open_new_tab via asyncio.to_thread).  Tests pass a
        # synchronous stub so no real browser ever launches.
        self._open_browser = open_browser or _default_open_in_host_browser
        self.queue: list[dict[str, str]] = []
        self.queue_index = -1
        self.video_id = ""
        self.title = ""
        self.status = "stopped"
        self.position_seconds = 0.0
        self.duration_seconds = 0.0
        self.revision = 0
        self.command: dict | None = None
        self.updated_at = self._now()

        # ── playlist + continuous playback state ────────────────────────────
        #
        # media_kind is "video" (ordinary search-result queue) or "playlist"
        # (an official YouTube playlist played by the embedded videoseries
        # iframe or opened as a canonical playlist URL in the host browser).
        #
        # continuous marks a bounded search-result queue that should keep
        # advancing to the next item automatically when the authoritative
        # embedded player reports the current media has ended; it loops back to
        # the start of the queue while continuous remains true.  Playlist mode
        # relies on YouTube's own continuation and never uses this server-side
        # advance.
        #
        # media_session is a monotonic generation counter.  Every play, stop,
        # or mode transition increments it.  Authoritative ended reports carry
        # (or are matched against) the session/video/revision they observed; a
        # stale/duplicate ended report after stop, a new play, a lease loss, a
        # generation mismatch, or a host_browser transition is ignored.
        self.media_kind = "video"
        self.playlist_id = ""
        self.playlist_title = ""
        self.continuous = False
        self.auto_advance = False
        self.media_session = 0
        # Bounds a single in-flight auto-advance so duplicate ended reports
        # cannot double-advance while the advance coroutine is running.
        self._advancing = False
        self._advance_task: asyncio.Task | None = None
        self.owner_id = ""
        self.owner_label = ""
        self._owner_seen = 0.0
        self._watchdog_task: asyncio.Task | None = None

        # ── host-browser state ───────────────────────────────────────────────
        #
        # playback_mode is the *committed* mode:
        #   "embedded"     -> official iframe player on a leased Media page
        #   "host_browser" -> canonical watch URL confirmed open in host browser
        #
        # _host_open_pending is the video id for which a host-browser open is
        # actively in-flight (set synchronously before the first await, cleared
        # when the operation concludes).  While non-empty the effective mode for
        # claim/report/control purposes is treated as "host_browser_pending" —
        # equivalent to host_browser for the purpose of suppressing iframe
        # creation and command rebound, but not yet committed as host_browser.
        #
        # _host_browser_video_id is the id confirmed open in the host browser
        # (fast dedup: skip a re-open for the same already-open video).
        #
        # _force_claim_during_pending records the owner id of any force=True
        # claim that arrived while a host-browser open was in-flight.  The
        # in-flight task reads this on completion: if set, the open succeeded
        # but an embedded owner has now taken over, so host_browser mode must
        # NOT be committed — the embedded owner's play command drives playback.
        #
        # _host_open_inflight: single-flight map (video id -> Task).  Concurrent
        # calls for the same id await the SAME task.  Race-free without a lock
        # because all dict operations happen in synchronous regions (no await
        # between check and insert).
        self.playback_mode = "embedded"
        self._host_open_pending: str = ""
        self._host_browser_video_id: str = ""
        self._force_claim_during_pending: str = ""
        self._host_open_inflight: dict[str, asyncio.Task[bool]] = {}

        # ── companion extension state ───────────────────────────────────────
        #
        # When an authenticated companion extension is attached (see
        # register_companion) it becomes the PRIMARY media owner and playback
        # runs in "browser_companion" mode: validated official video/playlist
        # navigation commands are forwarded to the extension via canonical
        # protocol actions (navigate_video / navigate_playlist), and the
        # browser tab reports authoritative player/video state back into this
        # tool's state via _ingest_companion_state.
        # The embedded iframe fallback is preserved and is only used when NO
        # companion is connected.
        #
        # self._companion is a duck-typed object exposing:
        #   .connected            -> bool
        #   .ad_playing           -> bool   (True during a YouTube ad)
        #   async send_command(action, **args) -> {"ok": bool, "error": str}
        #   bump_session()        -> int
        # It is set by register_companion() from the Runtime.
        self._companion = None
        # Last companion-reported volume / mute so the dashboard can display
        # and relative-volume commands can compute a target.
        self.volume = 100
        self.muted = False
        # ad_playing mirrors the companion's own ad flag.  While true the tool
        # surfaces a "YouTube ad is playing" message rather than silently failing.
        self.ad_playing = False
        # Voice-focus duck tracking: True while the companion has been sent a
        # duck command by the voice-focus gate (not by an explicit user command).
        # Restore is only sent if we initiated the duck.
        self._voice_ducked = False

        # ── voice-focus ownership generation + command serialization ─────────
        #
        # _voice_owner_gen is a monotonic generation counter that is
        # incremented SYNCHRONOUSLY (before any await) at the start of EVERY
        # explicit media command (play/navigate/pause/stop/seek/restart/
        # next/previous/set_volume/adjust_volume/mute/unmute).  Voice-focus
        # operations (duck/pause/restore) capture this generation before their
        # first await and re-check it *under the command lock* immediately
        # before dispatch and commit.  If the generation has advanced, an
        # explicit command has superseded the voice op, so it aborts without
        # sending anything or mutating volume/mute/pause state.  This makes an
        # explicit command ALWAYS win a race against a delayed voice restore:
        # a session-end restore after any explicit command is a guaranteed
        # no-op that never unmutes or changes volume.
        self._voice_owner_gen = 0
        # _companion_cmd_lock serializes ALL companion command dispatch so the
        # generation check and the send/commit happen atomically with respect
        # to other commands.  Without it, an explicit command could bump the
        # generation *between* a voice op's re-check and its dispatch.
        self._companion_cmd_lock = asyncio.Lock()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _set_playing(self, playing: bool) -> None:
        if self.on_playing is not None:
            self.on_playing(playing)

    def _media_audible(self) -> bool:
        """True only when media is actually making sound in the room.

        This is what the microphone gate needs to know — not "is a video
        loaded".  A muted player, a zero-volume player, and a paused player all
        put no sound into the room, so gating the microphone for them would
        only make Chat deaf while the user is talking.
        """
        if self.status not in ("playing", "buffering"):
            return False
        if self.muted:
            return False
        return int(self.volume) > 0

    def _refresh_audible(self) -> None:
        """Re-publish microphone-gate audibility from current media state."""
        self._set_playing(self._media_audible())

    def _host_browser_active(self) -> bool:
        """True when the effective mode is host_browser or host_browser_pending.

        Used by claim/report/_emit_sync to decide whether to suppress iframe
        creation, command rebound, and in-flight map clearing.
        """
        return self.playback_mode == "host_browser" or bool(self._host_open_pending)

    # -- companion extension (browser_companion mode) -----------------------

    def register_companion(self, companion) -> None:
        """Attach the authenticated companion bridge.

        Once attached AND connected, the companion becomes the primary media
        owner: play/pause/stop/seek/volume/mute route to it and playback_mode
        reports "browser_companion".  The embedded iframe fallback is untouched
        and resumes automatically whenever the companion is not connected.
        """
        self._companion = companion

    def _companion_active(self) -> bool:
        """True when a companion extension is connected and owns playback."""
        return self._companion is not None and bool(
            getattr(self._companion, "connected", False)
        )

    def _ad_active(self) -> bool:
        """True when the companion has reported an active YouTube ad."""
        if self._companion is None:
            return False
        return bool(getattr(self._companion, "ad_playing", False))

    def _ingest_companion_state(self, state: dict) -> None:
        """Feed a fenced companion state event back into tool/dashboard state.

        Called by CompanionBridge for state frames that have already passed
        session + target fencing.

        Media fencing (checked before any mutation)
        -------------------------------------------
        State frames must refer to the *current* media tracked by this tool:

        * **Direct video mode** (``media_kind == "video"``):  the companion's
          ``video_id`` must exactly match ``self.video_id`` (after re-validation
          via ``extract_video_id``).  Missing or wrong → full no-op.

        * **Playlist mode** (``media_kind == "playlist"``): the companion's
          ``playlist_id`` must exactly match ``self.playlist_id`` (after
          re-validation via ``extract_playlist_id``).  Missing or wrong → full
          no-op.  The current video within the playlist may vary.

        * **Browser-companion mode without a tracked id** (e.g. mode is
          ``browser_companion`` but no server-side id is yet known):  the frame
          is accepted so early state can flow in.

        Ad state is extracted *first* — it is authoritative and does NOT
        require a matching id, because an ad on a previously-matched session
        must still block commands even if the video id temporarily changes.
        """
        # ── 1. Extract ad_playing unconditionally (safety signal). ──────────
        if isinstance(state.get("ad_playing"), bool):
            self.ad_playing = state["ad_playing"]
        else:
            self.ad_playing = False

        # ── 2. Media fencing — drop the rest if the id doesn't match. ───────
        if self.playback_mode == "browser_companion":
            if self.media_kind == "video" and self.video_id:
                try:
                    expected_vid = extract_video_id(self.video_id)
                except Exception:
                    expected_vid = ""
                reported_vid = str(state.get("video_id") or "").strip()
                try:
                    reported_vid = extract_video_id(reported_vid) if reported_vid else ""
                except Exception:
                    reported_vid = ""
                if reported_vid != expected_vid:
                    # Wrong or missing video id — apply ad state then no-op.
                    self._publish_media_state()
                    return

            elif self.media_kind == "playlist" and self.playlist_id:
                try:
                    expected_pid = extract_playlist_id(self.playlist_id)
                except Exception:
                    expected_pid = ""
                reported_pid = str(state.get("playlist_id") or "").strip()
                try:
                    reported_pid = extract_playlist_id(reported_pid) if reported_pid else ""
                except Exception:
                    reported_pid = ""
                if reported_pid != expected_pid:
                    # Wrong or missing playlist id — apply ad state then no-op.
                    self._publish_media_state()
                    return

        # ── 3. Apply status. ─────────────────────────────────────────────────
        status = str(state.get("status", "")).strip().lower()
        if status and status in {
            "playing", "paused", "ended", "buffering", "stopped", "error",
        }:
            # A companion "ended" for the current continuous video queue auto-
            # advances exactly like the embedded path, guarded by media_session.
            if (
                status == "ended"
                and self.continuous
                and self.auto_advance
                and self.media_kind == "video"
                and self.playback_mode == "browser_companion"
                and bool(self.queue)
                and not self._advancing
                and not self.ad_playing
            ):
                self._advancing = True
                self.media_session += 1
                self._advance_task = asyncio.ensure_future(
                    self._auto_advance(self.media_session)
                )
            else:
                self.status = status

        # ── 4. Apply numeric / boolean fields. ───────────────────────────────
        for field_name, maximum in (
            ("position_seconds", 86400.0),
            ("duration_seconds", 86400.0),
        ):
            if field_name in state:
                try:
                    setattr(
                        self, field_name,
                        max(0.0, min(maximum, float(state[field_name]))),
                    )
                except (TypeError, ValueError):
                    pass
        if "volume" in state:
            try:
                self.volume = max(0, min(100, int(state["volume"])))
            except (TypeError, ValueError):
                pass
        if isinstance(state.get("muted"), bool):
            self.muted = state["muted"]
        # Audibility is published only after status, volume and mute from this
        # same report are applied, so a muted or zero-volume player never
        # leaves the microphone gated.
        self._refresh_audible()
        self.updated_at = self._now()
        self._publish_media_state()

    # Transport-level failure guidance, keyed by CompanionError.code.  The
    # ack_timeout wording is deliberate: the command MAY have been applied, so
    # nothing here (or anywhere) retries it automatically.
    _TRANSPORT_MESSAGES: dict[str, str] = {
        "not_connected": (
            "The browser companion isn't connected. Open the paired browser "
            "and check the Chat Companion extension, or re-pair it from "
            "Settings."
        ),
        "connection_lost": (
            "The browser companion disconnected while the command was being "
            "sent. Reopen the paired browser, then try again."
        ),
        "ack_timeout": (
            "The browser companion didn't confirm that command in time — it "
            "may or may not have been applied, so Chat won't retry it "
            "automatically. Check the YouTube tab, then ask again if needed."
        ),
        "busy": (
            "The browser companion is still working through earlier commands. "
            "Give it a moment and try again."
        ),
    }

    # Negative-ack guidance, keyed by the extension's error codes.  Codes not
    # listed fall back to a message that still shows the code.
    _ACK_MESSAGES: dict[str, str] = {
        "no_youtube_tab": (
            "There's no YouTube tab for Chat to control. Start something "
            "first (for example: play lofi beats on youtube), or open "
            "youtube.com in the paired browser."
        ),
        "content_unreachable": (
            "The YouTube tab isn't responding — it may still be loading, or "
            "it needs a reload after an extension update. Reload the YouTube "
            "tab in the paired browser and try again."
        ),
        "navigation_failed": (
            "The paired browser couldn't open that YouTube page. Check the "
            "browser window and try again."
        ),
        "busy_ad_unconfirmed": (
            "Chat couldn't confirm whether a YouTube ad is playing, so it "
            "left the player untouched. Try again in a few seconds."
        ),
        "no_player": (
            "The YouTube tab doesn't have an active video player. Open a "
            "video first, or ask Chat to play something."
        ),
    }

    async def _send_companion(self, action: str, **args) -> dict:
        """Low-level: send a server-derived command to the companion.

        Raises :class:`YouTubeError` on transport failure or negative ack,
        with the failure cause preserved (which tab/content/extension layer
        failed) instead of one generic message.  Uncertain outcomes
        (ack_timeout) are surfaced as uncertain and are never retried here.
        """
        try:
            ack = await self._companion.send_command(action, **args)
        except CompanionError as exc:
            code = getattr(exc, "code", "")
            message = self._TRANSPORT_MESSAGES.get(code)
            if message is None:
                message = (
                    "The YouTube companion did not carry out that command "
                    f"({exc}). Check that the companion extension is still "
                    "connected."
                )
            raise YouTubeError(message) from exc
        except Exception as exc:
            raise YouTubeError(
                "The YouTube companion did not carry out that command. "
                "Check that the companion extension is still connected."
            ) from exc
        if not ack.get("ok", False):
            error_code = str(ack.get("error", "")).strip()
            if error_code == "busy_ad":
                raise YouTubeError(
                    "A YouTube ad is playing — this command will be available "
                    "once the ad finishes."
                )
            message = self._ACK_MESSAGES.get(error_code)
            if message is None:
                message = (
                    "The YouTube companion could not complete that command"
                    + (f" (reason: {error_code})." if error_code else ".")
                )
            raise YouTubeError(message)
        return ack

    # -- explicit-command ownership + serialized dispatch -------------------

    def _claim_explicit_command(self) -> int:
        """Synchronously take ownership for an explicit media command.

        Called at the very start of every explicit command (play/navigate/
        pause/stop/seek/restart/next/previous/set_volume/adjust_volume/
        mute/unmute), BEFORE the first await.  It:

          * increments ``_voice_owner_gen`` so any in-flight voice-focus
            operation (duck/pause/restore) that captured an earlier generation
            will fail its re-check and abort; and
          * clears ``_voice_ducked`` because the user has explicitly taken
            control of media, so a later voice restore must NOT run.

        Returns the new generation (the explicit command's own token) so the
        caller may re-check ``_command_still_current`` before commit if desired.

        Because this runs in a synchronous region (no await between the
        increment and the caller's first await) it is race-free with respect
        to other explicit commands and voice ops on the single event loop.
        """
        self._voice_owner_gen += 1
        self._voice_ducked = False
        return self._voice_owner_gen

    def _command_still_current(self, gen: int) -> bool:
        """True if ``gen`` is still the live ownership generation.

        A voice-focus op captures the generation before awaiting and calls
        this under ``_companion_cmd_lock`` right before dispatch/commit.  If a
        newer explicit command (or another voice op) has advanced the counter,
        this returns False and the caller must abort without sending or
        mutating state.
        """
        return gen == self._voice_owner_gen

    async def _maybe_emit_play_companion(self, **data) -> dict | None:
        """Route a video navigation to the companion when one is connected.

        Uses the canonical ``navigate_video`` action (common.js COMPANION_ACTIONS)
        so the extension builds the canonical watch URL from the validated id and
        navigates the YouTube tab.  Returns None and falls through to
        embedded/host-browser if no companion is active.
        """
        if not self._companion_active():
            return None
        video_id = extract_video_id(data.get("video_id") or self.video_id)
        # Explicit navigation: synchronously claim ownership (invalidating any
        # in-flight voice op) and advance both the tool and bridge session so
        # any stale state is fenced.  Both happen before the first await.
        self._claim_explicit_command()
        self.media_session = self._companion.bump_session()
        async with self._companion_cmd_lock:
            await self._send_companion(
                "navigate_video",
                video_id=video_id,
                start_seconds=float(data.get("start_seconds") or 0.0),
            )
        self.playback_mode = "browser_companion"
        self.status = "playing"
        self._refresh_audible()
        self.updated_at = self._now()
        self._publish_media_state()
        return {
            "queued": False,
            "started": True,
            "action": "navigate_video",
            "player_needed": False,
            "playback_mode": "browser_companion",
            "message": (
                "Playing on YouTube through the companion extension in your browser."
            ),
            **self.snapshot(),
        }

    async def _maybe_emit_playlist_companion(self) -> dict | None:
        """Route a playlist navigation to the companion when one is connected.

        Uses the canonical ``navigate_playlist`` action (common.js COMPANION_ACTIONS)
        so the extension builds the canonical playlist URL from the validated id.
        """
        if not self._companion_active():
            return None
        playlist_id = extract_playlist_id(self.playlist_id)
        self._claim_explicit_command()
        self.media_session = self._companion.bump_session()
        async with self._companion_cmd_lock:
            await self._send_companion("navigate_playlist", playlist_id=playlist_id)
        self.playback_mode = "browser_companion"
        self.status = "playing"
        self._refresh_audible()
        self.updated_at = self._now()
        self._publish_media_state()
        return {
            "queued": False,
            "started": True,
            "action": "navigate_playlist",
            "player_needed": False,
            "playback_mode": "browser_companion",
            "media_kind": "playlist",
            "playlist_id": self.playlist_id,
            "message": (
                "Playing this playlist on YouTube through the companion extension."
            ),
            **self.snapshot(),
        }

    async def _maybe_emit_sync_companion(self, action: str, **args) -> dict | None:
        """Route an EXPLICIT transport command (pause/stop/seek/restart/
        set_volume/mute/unmute) to the companion.  Returns None if no companion
        is active so the caller falls through to the embedded/host-browser path.

        Every call synchronously claims ownership (``_claim_explicit_command``)
        before its first await, so any in-flight voice-focus op is invalidated
        and cannot clobber this command's effect.  Dispatch is serialized under
        ``_companion_cmd_lock``.  This is the transport path only — voice-focus
        duck/pause/restore intentionally do NOT go through here; they use the
        generation-checked helpers so they lose every race with an explicit
        command.
        """
        if not self._companion_active():
            return None
        # Synchronous ownership claim: invalidate any in-flight voice op.
        self._claim_explicit_command()
        async with self._companion_cmd_lock:
            await self._send_companion(action, **args)
        self.updated_at = self._now()
        self._publish_media_state()
        return {
            "queued": False,
            "started": True,
            "action": action,
            "player_needed": False,
            "playback_mode": "browser_companion",
            "message": "Sent to the YouTube companion extension.",
            **self.snapshot(),
        }

    # -- owner lease watchdog -----------------------------------------------
    def start_watchdog(self, interval: float = 5.0) -> None:
        """Start a background task that proactively expires dead owners.

        Without this, expiry only happens on the next API call, meaning the
        mic gate stays suppressed and media state stays "playing" indefinitely
        after a tab closes or the player crashes without sending pagehide.
        """
        if self._watchdog_task is not None:
            return  # already running

        async def _run() -> None:
            while True:
                await asyncio.sleep(interval)
                self._expire_owner()

        self._watchdog_task = asyncio.create_task(_run(), name="youtube-owner-watchdog")

    async def stop_watchdog(self) -> None:
        """Stop the watchdog task (called from Runtime.stop)."""
        task = self._watchdog_task
        if task is not None:
            self._watchdog_task = None
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    def _expire_owner(self) -> None:
        if self.owner_id and time.monotonic() - self._owner_seen > OWNER_LEASE_SECONDS:
            expired_id = self.owner_id
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=expired_id,
                reason="player_lease_expired",
            )
            self.owner_id = ""
            self.owner_label = ""
            self.status = "paused" if self.video_id else "stopped"
            self.updated_at = self._now()
            self._set_playing(False)

    def _owner_active(self) -> bool:
        self._expire_owner()
        return bool(self.owner_id)

    def snapshot(self) -> dict:
        active = self._owner_active()
        companion_active = self._companion_active()
        # A connected companion is the authoritative primary media owner and
        # takes precedence in the reported mode.  Otherwise report
        # host_browser_pending as "host_browser" so the dashboard shows the
        # honest "opening in your browser…" banner while the OS call is
        # in-flight; committed host_browser is reported the same way.
        if companion_active:
            mode = "browser_companion"
        elif self.playback_mode == "host_browser" or self._host_open_pending:
            mode = "host_browser"
        else:
            mode = "embedded"
        return {
            "revision": self.revision,
            "status": self.status,
            "video_id": self.video_id,
            "title": self.title,
            "url": canonical_video_url(self.video_id) if self.video_id else "",
            "position_seconds": round(self.position_seconds, 3),
            "duration_seconds": round(self.duration_seconds, 3),
            "queue": [dict(item) for item in self.queue],
            "queue_index": self.queue_index,
            "command": dict(self.command) if self.command else None,
            "target_id": self.owner_id if active else "",
            "target_label": self.owner_label if active else "",
            "player_connected": active,
            "companion_connected": companion_active,
            "volume": int(self.volume),
            "muted": bool(self.muted),
            "ad_playing": bool(self.ad_playing),
            "playback_mode": mode,
            "media_kind": self.media_kind,
            "playlist_id": self.playlist_id,
            "playlist_title": self.playlist_title,
            "playlist_url": canonical_playlist_url(self.playlist_id) if self.playlist_id else "",
            "continuous": bool(self.continuous),
            "auto_advance": bool(self.auto_advance),
            "media_session": self.media_session,
            "updated_at": self.updated_at,
        }

    @staticmethod
    def _client_id(value: object) -> str:
        client_id = str(value or "").strip()
        if not _CLIENT_ID_RE.fullmatch(client_id):
            raise YouTubeError("invalid media player identity")
        return client_id

    def claim(self, client_id: object, label: object = "", *, force: bool = False) -> dict:
        """Lease playback to one dashboard, preventing multi-device autoplay.

        While a host-browser open is in-flight (pending) or already committed:

        * ``force=False`` (passive) — grants ownership, preserves the pending/
          host_browser mode so the incoming page knows not to build an iframe.
          No play-command rebound is emitted.

        * ``force=True`` (intentional takeover) — if a launch is already in
          flight, records the new owner in ``_force_claim_during_pending`` so the
          in-flight task can detect the superseded context on completion and
          refrain from committing host_browser mode.  The mode is left as
          host_browser_pending until the task concludes; after that the embedded
          play command drives the iframe.  This prevents duplicate playback.
        """
        clean_id = self._client_id(client_id)
        self._expire_owner()
        if self.owner_id and self.owner_id != clean_id and not force:
            return {"owner": False, **self.snapshot()}
        if self.owner_id and self.owner_id != clean_id:
            previous_id = self.owner_id
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=previous_id,
                reason="player_reassigned",
            )
            self._set_playing(False)
        self.owner_id = clean_id
        self.owner_label = _text(label, 80) or "Media page"
        self._owner_seen = time.monotonic()

        if force:
            if self._host_open_pending:
                # A host-browser launch is in-flight.  Record the new owner so
                # the task can detect the superseded context when it completes.
                # Do NOT call _reset_host_browser_state() yet — that would orphan
                # the in-flight task and let it mutate state after the reset.
                self._force_claim_during_pending = clean_id
                # Leave playback_mode as-is (still pending); the task will
                # finalize the transition when done.
                # Do NOT rebound the play command yet either — the task callback
                # will do so if appropriate.
            else:
                # No pending launch: safe to reset immediately.
                self.playback_mode = "embedded"
                self._reset_host_browser_state()
        # Rebound the play command only when we are *committed* to embedded mode
        # and no pending launch could trigger a double iframe.
        if (
            self.playback_mode == "embedded"
            and not self._host_open_pending
            and self.command
            and self.command.get("target_id") != clean_id
        ):
            self.revision += 1
            self.command = {
                **self.command,
                "command_id": secrets.token_hex(8),
                "revision": self.revision,
                "target_id": clean_id,
            }
            self.updated_at = self._now()
            self.bus.publish("media_control", **self.command)
        return {"owner": True, **self.snapshot()}

    def release(self, client_id: object) -> dict:
        clean_id = self._client_id(client_id)
        if self.owner_id == clean_id:
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=clean_id,
                reason="player_released",
            )
            self.owner_id = ""
            self.owner_label = ""
            self._owner_seen = 0.0
            self.status = "paused" if self.video_id else "stopped"
            self.updated_at = self._now()
            self._set_playing(False)
        return self.snapshot()

    def heartbeat(self, client_id: object) -> bool:
        clean_id = self._client_id(client_id)
        self._expire_owner()
        if self.owner_id != clean_id:
            return False
        self._owner_seen = time.monotonic()
        return True

    # -- host-browser open (async, off event loop, single-flight) -----------

    def _reset_host_browser_state(self) -> None:
        """Clear the host-browser dedup marker AND the single-flight map.

        Only called when there is NO in-flight launch (i.e. _host_open_pending
        is empty).  Callers that might fire during a pending launch must check
        _host_browser_active() and skip this call, or handle pending specially.
        stop() always clears everything including a pending launch.
        """
        self._host_browser_video_id = ""
        self._host_open_inflight.clear()

    def _full_reset_host_browser_state(self) -> None:
        """Unconditionally clear ALL host-browser state including pending.

        Called only by stop() where the user has explicitly said to stop
        playback, superseding any in-flight open.
        """
        self._host_open_pending = ""
        self._force_claim_during_pending = ""
        self._host_browser_video_id = ""
        self._host_open_inflight.clear()

    async def _run_host_open(
        self, clean_id: str, url: str, session_at_dispatch: int
    ) -> bool:
        """Perform the actual (blocking) browser open off the event loop.

        Dispatches ``self._open_browser`` to ``asyncio.to_thread`` so it never
        stalls the loop.

        ``session_at_dispatch`` is the ``media_session`` value captured
        synchronously before the first ``await``.  On completion, if the current
        ``media_session`` no longer matches, a stop or new play superseded this
        operation: we do NOT commit ``host_browser`` mode, publish state, or
        rebind any command.  This prevents a late OS-thread completion from
        mutating playback state that has already moved on.

        On **success** (and session still matches):
          - If a force-claim arrived during the open (_force_claim_during_pending
            is set), the new embedded owner supersedes host_browser: we clear
            pending state and rebound the play command to the owner so the embed
            picks up.  playback_mode stays "embedded".
          - Otherwise: commit host_browser mode; set the dedup marker.

        On **failure**:
          - Clear pending state so a retry can run.
          - If an owner appeared during pending (passive claim, force-claim, or
            any owner): leave playback_mode as "embedded" — the owner can drive
            the iframe.  If no owner: clear to "embedded" and let the caller
            raise YouTubeError with the safe watch link.
        """
        success = False
        try:
            await asyncio.to_thread(self._open_browser, url)
            success = True
        except Exception:
            pass

        # --- we are back on the event loop; all state reads/writes are safe ---

        # BLOCKER 2: immutable operation token+key check BEFORE any shared-state
        # mutation.  The operation is identified by (session_at_dispatch, clean_id).
        # If EITHER the media_session changed (a stop() or a new play/pending B
        # superseded this operation A) OR the pending sentinel no longer names
        # this exact key (operation B took ownership of the pending slot), then
        # this late OS-thread completion of A must be a pure no-op:
        #   - do NOT clear _host_open_pending (it belongs to B now),
        #   - do NOT clear _force_claim_during_pending,
        #   - do NOT commit host_browser mode / publish / rebind / start a new item,
        #   - do NOT publish a failure or stop playback,
        #   - do NOT remove B's inflight entry.
        # Pending/inflight cleanup happens ONLY when the stored token+key match
        # this completion (the ownership guard below), so A can never disturb B.
        superseded = (
            session_at_dispatch != self.media_session
            or self._host_open_pending != clean_id
        )
        if superseded:
            # Remove ONLY our own inflight entry, and only if the stored task is
            # still ours (identity match).  Never touch a differently-keyed entry
            # that a superseding operation registered.
            stored = self._host_open_inflight.get(clean_id)
            if stored is not None and stored is asyncio.current_task():
                self._host_open_inflight.pop(clean_id, None)
            return False

        # We own the pending slot (token+key match): safe to capture and clear.
        force_owner = self._force_claim_during_pending
        self._host_open_pending = ""
        self._force_claim_during_pending = ""

        if success:
            if force_owner:
                # An embedded owner took over while we were opening.  The tab
                # was opened but the server now serves an embedded owner, so we
                # must not set host_browser mode.  The in-flight entry is removed
                # so a future host-browser open of the same id can run fresh.
                self._host_open_inflight.pop(clean_id, None)
                # Rebound the play command to the new owner so the embed starts.
                if (
                    self.owner_id == force_owner
                    and self.command
                    and self.command.get("target_id") != force_owner
                ):
                    self.revision += 1
                    self.command = {
                        **self.command,
                        "command_id": secrets.token_hex(8),
                        "revision": self.revision,
                        "target_id": force_owner,
                    }
                    self.updated_at = self._now()
                    self.bus.publish("media_control", **self.command)
                # Leave playback_mode as "embedded" (already the case since the
                # reset happens in the next non-pending _emit_play_async call).
                return False  # Caller should not set host_browser
            else:
                # Normal success path: commit host_browser.
                self._host_browser_video_id = clean_id
                return True
        else:
            # Failure: remove from map so a retry can register a new task.
            self._host_open_inflight.pop(clean_id, None)
            if self._host_browser_video_id == clean_id:
                self._host_browser_video_id = ""
            return False

    async def _open_host_browser_async(self, video_id: str) -> bool:
        """Open the canonical watch URL for *video_id* in the host browser.

        Single-flight, event-loop-owned: concurrent calls for the SAME validated
        video id await the same in-flight task, so the opener runs exactly once
        even under overlapping fallback POSTs or no-owner play requests.

        A ``_host_open_pending`` sentinel is set SYNCHRONOUSLY before the first
        ``await`` so that claim/report/control transitions arriving between the
        dispatch and the completion see the pending state and cannot reset it or
        trigger a duplicate iframe.

        Returns True when the tab was opened (or is already open for this exact
        id), False if the opener raised or was superseded by a force-claim.

        Safety: this method performs its dedup decision, pending-state update,
        and task registration SYNCHRONOUSLY (no await) before creating/awaiting
        the task.  Because the asyncio event loop is single-threaded, no two
        coroutines can interleave within this synchronous region, so the
        check-then-register sequence is race-free without any lock.
        """
        clean_id = extract_video_id(video_id)  # revalidate; raises on hostile input

        # Fast dedup: already committed open for this exact id.
        if self.playback_mode == "host_browser" and self._host_browser_video_id == clean_id:
            return True

        # An open for this exact id is already in flight: await the SAME task so
        # the opener runs exactly once.
        existing = self._host_open_inflight.get(clean_id)
        if existing is not None:
            return await existing

        # --- synchronous region: set pending + register task, no await yet ---
        url = canonical_watch_url(clean_id)
        # Capture the current media_session as an immutable operation token.
        # _run_host_open checks this on completion: if the session changed (stop,
        # new play) the late result is discarded without mutating state.
        session_token = self.media_session
        # Mark the pending state BEFORE creating the task so that any transition
        # (claim/report/control) arriving while we yield sees the pending flag.
        self._host_open_pending = clean_id
        task = asyncio.ensure_future(self._run_host_open(clean_id, url, session_token))
        self._host_open_inflight[clean_id] = task
        # --- end synchronous region -------------------------------------------
        return await task

    # -- internal event emission and state publishing -----------------------

    def _emit_control(self, action: str, **data) -> dict:
        """Record and broadcast a media_control command, return the raw command dict."""
        self._expire_owner()
        self.revision += 1
        self.updated_at = self._now()
        self.command = {
            "command_id": secrets.token_hex(8),
            "revision": self.revision,
            "action": action,
            "target_id": self.owner_id,
            **data,
        }
        self.bus.publish("media_control", **self.command)
        return self.command

    def _emit_sync(self, action: str, **data) -> dict:
        """Emit a control command that does NOT need a host-browser open.

        Used for pause/stop/seek where no async I/O is needed.  When a
        host-browser launch is pending or committed, we do NOT call
        _reset_host_browser_state() — that would orphan the in-flight task and
        let it later mutate a freshly-embedded state.
        """
        self._emit_control(action, **data)
        has_owner = bool(self.owner_id)
        self._publish_media_state()
        if has_owner and not self._host_browser_active():
            # Committed embedded playback with an owner: reset host-browser state.
            self.playback_mode = "embedded"
            self._reset_host_browser_state()
            return {
                "queued": False,
                "started": True,
                "action": action,
                "player_needed": False,
                "playback_mode": "embedded",
                "message": "Sent to the selected Media page.",
                **self.snapshot(),
            }
        return {
            "queued": False,
            "started": has_owner,
            "action": action,
            "player_needed": not has_owner,
            "playback_mode": self.snapshot()["playback_mode"],
            "message": (
                "Sent to the selected Media page." if has_owner else
                "No embedded Media player is connected. Ask to play something to start "
                "playback in the browser on this computer, or open the Media page to use "
                "the embedded player."
            ),
            **self.snapshot(),
        }

    async def _emit_play_async(self, **data) -> dict:
        """Emit a play command, dispatching to the host browser off the event
        loop when no embedded owner is available.

        Never returns an optimistic success: the browser open is awaited before
        returning so callers always know the actual outcome.

        A connected companion extension is the primary media owner: the
        server-derived video id (and queue) go to it and it becomes the
        authoritative "browser_companion" playback surface, superseding the
        embedded iframe and host-browser fallbacks entirely.
        """
        companion_result = await self._maybe_emit_play_companion(**data)
        if companion_result is not None:
            return companion_result

        cmd = self._emit_control("play", **data)

        has_owner = bool(self.owner_id)
        if has_owner:
            # An embedded Media page owns playback: the official iframe player
            # will execute this command.
            if not self._host_browser_active():
                self.playback_mode = "embedded"
                self._reset_host_browser_state()
            self._publish_media_state()
            return {
                "queued": False,
                "started": True,
                "action": "play",
                "player_needed": False,
                "playback_mode": "embedded",
                "message": "Playing on the selected Media page.",
                **self.snapshot(),
            }

        # No embedded owner: open the canonical watch URL in the host browser.
        # This call is awaited, so we never return an optimistic success.
        if self.video_id:
            # BLOCKER 2: capture the immutable operation token+key BEFORE the
            # await so a superseded completion can be detected without touching
            # shared state.  The key is the validated video id; the token is the
            # media_session generation at dispatch.
            op_key = extract_video_id(self.video_id)
            op_token = self.media_session
            opened = await self._open_host_browser_async(self.video_id)
            # If this operation was superseded while awaiting (a stop() or a new
            # play/pending B bumped media_session, or B took the pending slot),
            # this late completion must NOT publish a failure, stop playback, or
            # clear any pending state that now belongs to B.  Return the current
            # snapshot as a pure no-op so B's state/pending stay untouched.
            superseded = (
                op_token != self.media_session
                or (self._host_open_pending and self._host_open_pending != op_key)
            )
            if opened:
                self.playback_mode = "host_browser"
                self.status = "playing"
                self._refresh_audible()
                self.updated_at = self._now()
                self._publish_media_state()
                return {
                    "queued": False,
                    "started": True,
                    "action": "play",
                    "player_needed": False,
                    "playback_mode": "host_browser",
                    "message": (
                        "Playing in your default browser on this computer. "
                        "Use YouTube's own controls in that tab to pause, seek, or change volume."
                    ),
                    **self.snapshot(),
                }
            if superseded:
                # A newer operation owns the shared state now.  Do not mutate,
                # publish a failure, or stop playback: return the current
                # snapshot verbatim so B's state and pending are preserved.
                return {
                    "queued": False,
                    "started": False,
                    "action": "play",
                    "player_needed": False,
                    "playback_mode": self.snapshot()["playback_mode"],
                    "message": "Superseded by a newer playback request.",
                    **self.snapshot(),
                }
            # Opening failed OR superseded by a force-claim that took over.
            # Check whether an owner appeared during the await.
            if self.owner_id:
                # An owner appeared (force-claim) while we were opening.
                # The _run_host_open callback already rebound the command.
                # Return an embedded-mode response so the caller knows the
                # owner's embed will handle playback.
                self._publish_media_state()
                return {
                    "queued": False,
                    "started": True,
                    "action": "play",
                    "player_needed": False,
                    "playback_mode": "embedded",
                    "message": "Playing on the selected Media page.",
                    **self.snapshot(),
                }
            # Genuine failure: clear mode and surface the safe watch link.
            self.playback_mode = "embedded"
            self.status = "stopped"
            self._set_playing(False)
            self.updated_at = self._now()
            self._publish_media_state()
            raise YouTubeError(
                "Could not open the video in your browser on this computer. "
                f"Open it manually: {canonical_watch_url(self.video_id)}"
            )

        # Transport control with no player and no video.
        self._publish_media_state()
        return {
            "queued": False,
            "started": False,
            "action": "play",
            "player_needed": True,
            "playback_mode": self.snapshot()["playback_mode"],
            "message": (
                "No embedded Media player is connected and no video is selected. "
                "Ask to play something to start playback."
            ),
            **self.snapshot(),
        }

    def _publish_media_state(self) -> None:
        """Publish the authoritative playback mode/state to the event bus.

        Keeps every dashboard tab's playback banner live even when no embedded
        player is reporting (host-browser mode), so the UI can honestly say
        whether the video is embedded or playing in the host browser.
        """
        state = self.snapshot()
        self.bus.publish(
            "media_state",
            status=self.status,
            video_id=self.video_id,
            title=self.title,
            position_seconds=state["position_seconds"],
            duration_seconds=state["duration_seconds"],
            queue_index=self.queue_index,
            target_id=self.owner_id,
            playback_mode=state["playback_mode"],
            media_kind=self.media_kind,
            playlist_id=self.playlist_id,
            playlist_title=self.playlist_title,
            continuous=bool(self.continuous),
            media_session=self.media_session,
        )

    # -- public async host-browser fallback (101/150, autoplay-blocked) -----

    async def host_browser_fallback(self, client_id: object) -> dict:
        """Open the *currently active* canonical video in the host browser.

        Invoked by the narrowly scoped authenticated + CSRF-protected endpoint
        after the official embed reports error 101/150 or after the browser
        blocks autoplay on the leased Media page.  Accepts no URL, host, or
        command from the caller: it re-derives the URL from the server's own
        active ``video_id`` via canonical_watch_url(extract_video_id(...)).

        The caller must be the current lease owner (proved by heartbeat).  The
        browser launch is dispatched to asyncio.to_thread so the blocking OS
        call never stalls the event loop.  We never return optimistic success:
        the result reflects the actual outcome of the open attempt.

        Raises :class:`YouTubeError` if the caller is not the active player, if
        there is no active video, if the id is invalid, or if the browser open
        failed.
        """
        if not self.heartbeat(client_id):
            raise YouTubeError("this page is not the selected Media player")
        if not self.video_id:
            raise YouTubeError("there is no active YouTube video to open")
        # Revalidate the active id explicitly — belt-and-braces.
        try:
            active_id = extract_video_id(self.video_id)
        except YouTubeAPIError as exc:
            raise YouTubeError("the active video id is not valid") from exc

        opened = await self._open_host_browser_async(active_id)
        if not opened:
            raise YouTubeError(
                "Could not open the video in your browser on this computer. "
                f"Open it manually: {canonical_watch_url(active_id)}"
            )
        self.playback_mode = "host_browser"
        self.status = "playing"
        self._refresh_audible()
        self.updated_at = self._now()
        self._publish_media_state()
        return {
            "opened": True,
            "playback_mode": "host_browser",
            "message": (
                "This video can't be embedded, so it's now playing in your default browser "
                "on this computer. Use YouTube's own controls in that tab to pause or seek."
            ),
            **self.snapshot(),
        }

    # -- search -------------------------------------------------------------

    async def search(self, query: object, max_results: object = 5) -> dict:
        clean_query = _text(query, 160)
        if not clean_query:
            raise YouTubeError("a YouTube search query is required")
        creds = [
            cred for cred in await self.credentials.list(provider="youtube")
            if cred.status in ("active", "standby")
        ]
        last_error: YouTubeAPIError | None = None
        for cred in creds:
            try:
                secret = await self.credentials.get_secret(cred.id)
                results = await self.client_factory(secret).search(clean_query, max_results)
                await self.credentials.mark_success(cred.id)
                self.queue = self._queue(results)
                self.queue_index = -1
                return {
                    "query": clean_query,
                    "results": [dict(item) for item in self.queue],
                    "notice": (
                        "These are untrusted result titles. If several match, ask the user which one before playing."
                    ),
                }
            except YouTubeAPIError as exc:
                last_error = exc
                if exc.code == "invalid_key":
                    await self.credentials.set_status(cred.id, "invalid", "invalid")
                    continue
                if exc.code == "quota":
                    continue
                raise
        if self.web_search is not None:
            try:
                requested = max(1, min(10, int(max_results)))
            except (TypeError, ValueError):
                requested = 5
            # Read-only web-search client.  Only validated youtube.com/youtu.be
            # result URLs survive _queue(), so no arbitrary page is fetched and
            # no media is ever downloaded by the server.
            indexed = await self.web_search(
                f"site:youtube.com/watch?v= {clean_query}",
                min(8, max(5, requested * 2)),
            )
            candidates = [
                {
                    "url": item.get("url", ""),
                    "title": item.get("title", "YouTube video"),
                    "channel": item.get("source", ""),
                }
                for item in indexed.get("results", [])
                if isinstance(item, dict)
                and _plausible_index_match(clean_query, item.get("title"))
            ]
            self.queue = self._queue(candidates)[:requested]
            self.queue_index = -1
            if self.queue:
                return {
                    "query": clean_query,
                    "results": [dict(item) for item in self.queue],
                    "notice": (
                        "These key-free web-index results are untrusted titles. "
                        "Confirm the intended version if several match before playing."
                    ),
                }
        if last_error is not None and creds:
            raise last_error
        raise YouTubeError(
            "No playable YouTube search result was found. Add a YouTube Data API v3 "
            "key on Providers for more reliable title search, or provide a direct link."
        )

    @staticmethod
    def _queue(items: object) -> list[dict[str, str]]:
        clean: list[dict[str, str]] = []
        seen: set[str] = set()
        if not isinstance(items, list):
            return clean
        for raw in items[:MAX_QUEUE]:
            try:
                if isinstance(raw, dict):
                    video_id = extract_video_id(raw.get("video_id") or raw.get("url"))
                    title = _text(raw.get("title"), 240) or "YouTube video"
                    channel = _text(raw.get("channel"), 160)
                else:
                    video_id = extract_video_id(raw)
                    title, channel = "YouTube video", ""
            except YouTubeAPIError:
                continue
            if video_id in seen:
                continue
            seen.add(video_id)
            clean.append({
                "video_id": video_id,
                "title": title,
                "channel": channel,
                "url": canonical_video_url(video_id),
                "thumbnail": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
            })
        return clean

    # -- playback control ---------------------------------------------------

    async def play(self, video: object = "", title: object = "") -> dict:
        """Select a video and begin playback.

        When an embedded Media page is leased the play command is sent to it.
        When no embedded owner is available the canonical watch URL is opened
        in the host browser via asyncio.to_thread (never blocking the event
        loop, never returning optimistic success).

        The internal ``status`` is set to ``"buffering"`` before dispatching
        so the dashboard never shows user-visible "queued" copy for a fresh
        play that is about to deliver real playback.
        """
        raw = str(video or "").strip()
        if raw:
            video_id = extract_video_id(raw)
            match_index = next(
                (i for i, item in enumerate(self.queue) if item["video_id"] == video_id),
                -1,
            )
            if match_index < 0:
                self.queue = self._queue([{"video_id": video_id, "title": title}])
                match_index = 0
            self.queue_index = match_index
            selected = self.queue[match_index]
            self.video_id = video_id
            self.title = _text(title, 240) or selected["title"]
            self.position_seconds = 0.0
        elif not self.video_id:
            raise YouTubeError("there is no YouTube video to resume")
        # A fresh explicit video play switches away from playlist mode and
        # starts a new media session (any late playlist/ended report is stale).
        # Exception: if the same video already has an in-flight host-browser open
        # (single-flight dedup case), do NOT increment the session — both
        # concurrent callers are requesting the same video and share the same
        # in-flight task; bumping the session would invalidate the shared task's
        # token and cause both callers to see a spurious failure.
        if raw:
            self.media_kind = "video"
            self.playlist_id = ""
            self.playlist_title = ""
            same_video_in_flight = (
                self._host_open_inflight.get(self.video_id) is not None
            )
            if not same_video_in_flight:
                self.media_session += 1
            self._advancing = False
        # Use "buffering" rather than "queued" so the dashboard never shows
        # user-visible "queued" copy for a fresh play that is about to deliver
        # real playback (embedded or host-browser).  The internal candidate
        # list (self.queue) is unaffected.
        self.status = "buffering"
        return await self._emit_play_async(
            video_id=self.video_id,
            title=self.title,
            start_seconds=self.position_seconds,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    async def play_url(self, url: object, title: object = "") -> dict:
        """Normalise a YouTube URL to a video_id and play it.

        Accepts any supported youtube.com / youtu.be URL form.  Rejects
        non-YouTube hosts with a clear :class:`YouTubeError`.
        The actual browser open (when no embedded owner is leased) is done
        in asyncio.to_thread so the event loop is never blocked.
        """
        raw = str(url or "").strip()
        if not raw:
            raise YouTubeError("a YouTube URL is required")
        try:
            video_id = extract_video_id(raw)
        except YouTubeAPIError as exc:
            raise YouTubeError(str(exc)) from exc
        return await self.play(video_id, title)

    async def play_query(self, query: object, title: object = "") -> dict:
        """Search for *query*, select the most canonical result, and play it.

        Uses the same search path as :meth:`search` (API key if available,
        web-index fallback), then applies :func:`_pick_best_result` to choose
        the canonical version automatically.  The browser open is dispatched
        to asyncio.to_thread so the event loop is never blocked.
        """
        clean_query = _text(query, 160)
        if not clean_query:
            raise YouTubeError("a YouTube search query is required")
        result = await self.search(clean_query, 8)
        candidates = result.get("results") or []
        best = _pick_best_result(candidates, clean_query)
        if best is None:
            raise YouTubeError(
                f"No playable result found for '{clean_query}'. "
                "Try providing a direct YouTube link or add a YouTube Data API key."
            )
        chosen_title = _text(title, 240) or best.get("title", "")
        outcome = await self.play(best["video_id"], chosen_title)
        # Ordinary free-text playback keeps advancing through the bounded
        # canonical search-result queue until a media-qualified stop.  Enable
        # continuous auto-advance by default for play-query results.
        self.continuous = True
        self.auto_advance = True
        outcome["continuous"] = True
        return outcome

    # -- playlist search + playback ----------------------------------------

    async def search_playlists(self, query: object, max_results: object = 5) -> dict:
        """Search public YouTube playlists via the official Data API only.

        Requires a configured YouTube Data API v3 key; there is NO web-index
        fallback for playlist content (playlist items are never scraped).  When
        no key is configured a clear setup error is raised.
        """
        clean_query = _text(query, 160)
        if not clean_query:
            raise YouTubeError("a YouTube playlist search query is required")
        creds = [
            cred for cred in await self.credentials.list(provider="youtube")
            if cred.status in ("active", "standby")
        ]
        if not creds:
            raise YouTubeError(
                "Searching for a YouTube playlist needs a YouTube Data API v3 key. "
                "Add one on the Providers page, or give a direct playlist link or ID."
            )
        last_error: YouTubeAPIError | None = None
        for cred in creds:
            try:
                secret = await self.credentials.get_secret(cred.id)
                results = await self.client_factory(secret).search_playlists(
                    clean_query, max_results
                )
                await self.credentials.mark_success(cred.id)
                return {
                    "query": clean_query,
                    "results": [dict(item) for item in results],
                    "notice": (
                        "These are untrusted playlist titles from the official API."
                    ),
                }
            except YouTubeAPIError as exc:
                last_error = exc
                if exc.code == "invalid_key":
                    await self.credentials.set_status(cred.id, "invalid", "invalid")
                    continue
                if exc.code == "quota":
                    continue
                raise YouTubeError(str(exc)) from exc
        if last_error is not None:
            raise YouTubeError(str(last_error))
        raise YouTubeError("no matching public YouTube playlist was found")

    async def play_playlist(
        self,
        *,
        playlist_id: object = "",
        playlist_url: object = "",
        query: object = "",
        title: object = "",
    ) -> dict:
        """Play an official YouTube playlist by validated id, URL, or search.

        Resolution order:
          1. Direct ``playlist_id`` or ``playlist_url`` -> server re-validates and
             owns the canonical playlist id (caller strings are never trusted).
          2. Free-text ``query`` -> official playlist search (requires an API key;
             never scrapes playlist contents).

        Embedded mode emits a playlist play command for the videoseries iframe.
        With no owner (or an embed/autoplay fallback), only the canonical
        official playlist URL is opened in the host browser, reusing the async
        single-flight / pending race protections adapted for the playlist target.
        """
        resolved_id = ""
        resolved_title = _text(title, 240)
        raw_url = str(playlist_url or "").strip()
        raw_id = str(playlist_id or "").strip()
        if raw_url:
            try:
                resolved_id = extract_playlist_id(raw_url)
            except YouTubeAPIError as exc:
                raise YouTubeError(str(exc)) from exc
        elif raw_id:
            try:
                resolved_id = extract_playlist_id(raw_id)
            except YouTubeAPIError as exc:
                raise YouTubeError(str(exc)) from exc
        else:
            clean_query = _text(query, 160)
            if not clean_query:
                raise YouTubeError("a playlist link, ID, or search query is required")
            found = await self.search_playlists(clean_query, 5)
            candidates = found.get("results") or []
            if not candidates:
                raise YouTubeError("no matching public YouTube playlist was found")
            resolved_id = extract_playlist_id(candidates[0]["playlist_id"])
            resolved_title = resolved_title or _text(candidates[0].get("title"), 240)

        # Server owns the validated id from here on.
        self.media_kind = "playlist"
        self.playlist_id = resolved_id
        self.playlist_title = resolved_title or "YouTube playlist"
        # Playlist continuation is handled by YouTube itself, so server-side
        # auto-advance is off for playlist mode.
        self.continuous = True
        self.auto_advance = False
        # A playlist supersedes any active single-video queue selection.
        self.video_id = ""
        self.title = self.playlist_title
        self.position_seconds = 0.0
        self.media_session += 1
        self._advancing = False
        self.status = "buffering"
        return await self._emit_playlist_async()

    async def _emit_playlist_async(self) -> dict:
        """Emit a playlist play command, or open the canonical playlist URL.

        With a leased embedded owner the official videoseries iframe plays the
        playlist.  With no owner the canonical official playlist URL is opened
        in the host browser exactly once (single-flight), never a duplicate tab.

        A connected companion extension takes precedence: the validated playlist
        id is sent to it and it becomes the "browser_companion" surface.
        """
        companion_result = await self._maybe_emit_playlist_companion()
        if companion_result is not None:
            return companion_result

        cmd = self._emit_control(
            "play_playlist",
            playlist_id=self.playlist_id,
            title=self.playlist_title,
        )
        has_owner = bool(self.owner_id)
        if has_owner:
            if not self._host_browser_active():
                self.playback_mode = "embedded"
                self._reset_host_browser_state()
            self._publish_media_state()
            return {
                "queued": False,
                "started": True,
                "action": "play_playlist",
                "player_needed": False,
                "playback_mode": "embedded",
                "media_kind": "playlist",
                "playlist_id": self.playlist_id,
                "message": "Playing this playlist on the selected Media page.",
                **self.snapshot(),
            }
        # BLOCKER 2 (playlist): capture the immutable operation token+key BEFORE
        # the await so a superseded completion can be detected without touching
        # shared state.  The key is the pl:<validated playlist id> sentinel used
        # by _open_host_browser_playlist_async; the token is the media_session
        # generation at dispatch.
        op_key = f"pl:{extract_playlist_id(self.playlist_id)}"
        op_token = self.media_session
        opened = await self._open_host_browser_playlist_async(self.playlist_id)
        # If this operation was superseded while awaiting (a Stop(), a new media
        # play, or another pending op bumped media_session or took the pending
        # slot), this late completion must NOT commit host_browser, publish,
        # raise a failure, stop playback, or clean up pending state that now
        # belongs to the superseding operation.  Return the current snapshot as
        # a benign no-op for BOTH the opened-True and opened-False paths.
        superseded = (
            op_token != self.media_session
            or (self._host_open_pending and self._host_open_pending != op_key)
        )
        if superseded:
            return {
                "queued": False,
                "started": False,
                "action": "play_playlist",
                "player_needed": False,
                "playback_mode": self.snapshot()["playback_mode"],
                "media_kind": self.snapshot()["media_kind"],
                "playlist_id": self.playlist_id,
                "message": "Superseded by a newer playback request.",
                **self.snapshot(),
            }
        if opened:
            self.playback_mode = "host_browser"
            self.status = "playing"
            self._refresh_audible()
            self.updated_at = self._now()
            self._publish_media_state()
            return {
                "queued": False,
                "started": True,
                "action": "play_playlist",
                "player_needed": False,
                "playback_mode": "host_browser",
                "media_kind": "playlist",
                "playlist_id": self.playlist_id,
                "message": (
                    "Playing this playlist in your default browser on this computer. "
                    "Use YouTube's own controls in that tab to change tracks or pause."
                ),
                **self.snapshot(),
            }
        if self.owner_id:
            self._publish_media_state()
            return {
                "queued": False,
                "started": True,
                "action": "play_playlist",
                "player_needed": False,
                "playback_mode": "embedded",
                "media_kind": "playlist",
                "playlist_id": self.playlist_id,
                "message": "Playing this playlist on the selected Media page.",
                **self.snapshot(),
            }
        self.playback_mode = "embedded"
        self.status = "stopped"
        self._set_playing(False)
        self.updated_at = self._now()
        self._publish_media_state()
        raise YouTubeError(
            "Could not open the playlist in your browser on this computer. "
            f"Open it manually: {canonical_playlist_url(self.playlist_id)}"
        )

    async def _open_host_browser_playlist_async(self, playlist_id: str) -> bool:
        """Single-flight host-browser open of the canonical playlist URL.

        Mirrors :meth:`_open_host_browser_async` for the playlist target: the
        pending sentinel and in-flight map are keyed by ``pl:<id>`` so a playlist
        open never collides with a video open, and concurrent calls for the same
        playlist await the same task (opener runs exactly once, no duplicate
        tab).
        """
        clean_id = extract_playlist_id(playlist_id)  # revalidate; raises on hostile input
        key = f"pl:{clean_id}"
        if self.playback_mode == "host_browser" and self._host_browser_video_id == key:
            return True
        existing = self._host_open_inflight.get(key)
        if existing is not None:
            return await existing
        url = canonical_playlist_url(clean_id)
        # Capture the current media_session as an immutable operation token.
        session_token = self.media_session
        self._host_open_pending = key
        task = asyncio.ensure_future(self._run_host_open(key, url, session_token))
        self._host_open_inflight[key] = task
        return await task

    def pause(self) -> dict:
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to pause")
        self.status = "paused"
        self._set_playing(False)
        return self._emit_sync("pause", video_id=self.video_id)

    def stop(self) -> dict:
        self.status = "stopped"
        self.position_seconds = 0.0
        self._set_playing(False)
        # A media-qualified stop disables continuous advancement, bumps the media
        # session generation (so any in-flight/late ended report is stale), and
        # clears any pending advance.  Playlist metadata is cleared so the UI no
        # longer labels a playlist as active.
        self.continuous = False
        self.auto_advance = False
        self._advancing = False
        self.media_session += 1
        self.media_kind = "video"
        self.playlist_id = ""
        self.playlist_title = ""
        # Cancel any in-flight advance task (the session bump above is the
        # authoritative guard, but explicit cancellation cleans up faster).
        if self._advance_task is not None and not self._advance_task.done():
            self._advance_task.cancel()
        self._advance_task = None
        # stop() supersedes everything including any in-flight host-browser open.
        self.playback_mode = "embedded"
        self._full_reset_host_browser_state()
        return self._emit_sync("stop", video_id=self.video_id)

    def seek(self, offset_seconds: object) -> dict:
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to seek")
        try:
            offset = int(offset_seconds)
        except (TypeError, ValueError) as exc:
            raise YouTubeError("seek amount must be a number of seconds") from exc
        if offset == 0 or abs(offset) > MAX_SEEK_SECONDS:
            raise YouTubeError(f"seek amount must be between 1 and {MAX_SEEK_SECONDS} seconds")
        target = max(0.0, self.position_seconds + offset)
        if self.duration_seconds > 0:
            target = min(target, self.duration_seconds)
        self.position_seconds = target
        return self._emit_sync(
            "seek",
            video_id=self.video_id,
            offset_seconds=offset,
            target_seconds=round(target, 3),
        )

    # -- companion-aware transport controls ---------------------------------
    #
    # These async methods are the service's entry points.  When a companion
    # extension is connected they forward the (server-derived) command to it;
    # otherwise they fall back to the existing synchronous embedded/host-browser
    # behaviour, so the embedded fallback is fully preserved.

    async def pause_media(self) -> dict:
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to pause")
        companion = await self._maybe_emit_sync_companion("pause")
        if companion is not None:
            self.status = "paused"
            self._set_playing(False)
            return {**companion, **self.snapshot()}
        return self.pause()

    async def stop_media(self) -> dict:
        if self._companion_active():
            # Synchronously claim ownership (invalidate any in-flight voice op)
            # AND bump the media/bridge session BEFORE dispatching stop, so the
            # stop command carries the NEW session.  This lets the extension's
            # immediate stopped/ad state (which will be stamped with the new
            # session) be accepted, while any late state from the OLD media —
            # stamped with the old session — is fenced out.  We must NOT bump
            # again after dispatch, or the stop command's session would be one
            # generation behind the state it triggers.
            self._claim_explicit_command()
            self.media_session = self._companion.bump_session()
            # Stop supersedes any voice-focus duck.
            self._voice_ducked = False
            async with self._companion_cmd_lock:
                await self._send_companion("stop")
            self.status = "stopped"
            self.position_seconds = 0.0
            self.continuous = False
            self.auto_advance = False
            self._advancing = False
            self._set_playing(False)
            self.updated_at = self._now()
            self._publish_media_state()
            return {
                "queued": False,
                "started": True,
                "action": "stop",
                "player_needed": False,
                "playback_mode": "browser_companion",
                "message": "Sent to the YouTube companion extension.",
                **self.snapshot(),
            }
        return self.stop()

    async def seek_media(self, offset_seconds: object) -> dict:
        if not self.video_id and not self._companion_active():
            raise YouTubeError("there is no YouTube video to seek")
        try:
            offset = int(offset_seconds)
        except (TypeError, ValueError) as exc:
            raise YouTubeError("seek amount must be a number of seconds") from exc
        if offset == 0 or abs(offset) > MAX_SEEK_SECONDS:
            raise YouTubeError(f"seek amount must be between 1 and {MAX_SEEK_SECONDS} seconds")
        if self._companion_active():
            target = max(0.0, self.position_seconds + offset)
            if self.duration_seconds > 0:
                target = min(target, self.duration_seconds)
            companion = await self._maybe_emit_sync_companion(
                "seek", offset_seconds=offset, target_seconds=round(target, 3)
            )
            self.position_seconds = target
            return {**companion, **self.snapshot()}
        return self.seek(offset_seconds)

    async def restart_media(self) -> dict:
        """Restart from the beginning.  Uses canonical 'restart' for the companion."""
        if not self.video_id and not self._companion_active():
            raise YouTubeError("there is no YouTube video to restart")
        if self._companion_active():
            companion = await self._maybe_emit_sync_companion("restart")
            self.position_seconds = 0.0
            return {**companion, **self.snapshot()}
        # Embedded/host-browser: absolute seek to 0 via the sync emitter.
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to restart")
        self.position_seconds = 0.0
        return self._emit_sync(
            "seek", video_id=self.video_id, offset_seconds=0, target_seconds=0.0
        )

    async def set_volume(self, percent: object) -> dict:
        """Set an absolute volume 0..100.  Companion only (real volume)."""
        try:
            level = int(percent)
        except (TypeError, ValueError) as exc:
            raise YouTubeError("volume must be a number between 0 and 100") from exc
        level = max(0, min(100, level))
        if not self._companion_active():
            raise YouTubeError(
                "Volume control needs the YouTube companion extension connected. "
                "Without it, use YouTube's own volume control in the browser tab."
            )
        companion = await self._maybe_emit_sync_companion("set_volume", volume=level)
        self.volume = level
        self.muted = level == 0 and self.muted
        # Volume 0 is silence: stop gating the microphone for it.
        self._refresh_audible()
        return {**companion, **self.snapshot()}

    async def adjust_volume(self, delta: object) -> dict:
        """Change volume by a relative amount.  Companion only (real volume)."""
        try:
            step = int(delta)
        except (TypeError, ValueError) as exc:
            raise YouTubeError("volume change must be a number") from exc
        if step == 0:
            raise YouTubeError("volume change must be non-zero")
        if not self._companion_active():
            raise YouTubeError(
                "Volume control needs the YouTube companion extension connected. "
                "Without it, use YouTube's own volume control in the browser tab."
            )
        target = max(0, min(100, int(self.volume) + step))
        companion = await self._maybe_emit_sync_companion("set_volume", volume=target)
        self.volume = target
        self._refresh_audible()
        return {**companion, **self.snapshot()}

    async def set_muted(self, muted: object) -> dict:
        """Mute or unmute.  Companion only (real mute)."""
        want = bool(muted)
        if not self._companion_active():
            raise YouTubeError(
                "Mute control needs the YouTube companion extension connected. "
                "Without it, use YouTube's own mute control in the browser tab."
            )
        companion = await self._maybe_emit_sync_companion(
            "mute" if want else "unmute"
        )
        self.muted = want
        # Muting silences the room: the microphone gate must reopen at once so
        # the user can simply talk to Chat over a muted song.
        self._refresh_audible()
        return {**companion, **self.snapshot()}

    async def voice_focus_duck(self) -> bool:
        """Duck companion volume for voice focus (verified speech / wake).

        Sends the canonical ``duck`` command to lower volume so the assistant
        can be heard clearly.  Tracks that *Jarvis* initiated the duck so
        restore only happens when we own it.  Returns True on success.

        Ownership generation
        --------------------
        The current generation is captured before the first await.  The gate,
        ad, and ``_voice_ducked`` checks and the actual dispatch all happen
        again *under* ``_companion_cmd_lock`` after re-checking the generation.
        If ANY explicit command (play/navigate/pause/stop/seek/restart/next/
        previous/set/adjust volume/mute/unmute) has run in the meantime, the
        generation advanced and this duck aborts without sending anything.

        Best-effort: failures are swallowed so wake listening is never affected.
        """
        if not self._companion_active():
            return False
        gen = self._voice_owner_gen
        async with self._companion_cmd_lock:
            # Re-check EVERYTHING under the lock, immediately before dispatch.
            if not self._command_still_current(gen):
                return False  # an explicit command superseded us
            if not self._companion_active():
                return False
            if self.status not in ("playing", "buffering"):
                return False
            if self._voice_ducked:
                return True   # already ducked
            if self._ad_active():
                return False  # never interrupt an ad
            try:
                await self._send_companion("duck", volume=20)
            except YouTubeError:
                return False
            # Commit only if still current (send did not race an explicit cmd).
            if not self._command_still_current(gen):
                return False
            self._voice_ducked = True
        self.updated_at = self._now()
        self._publish_media_state()
        return True

    async def voice_focus_restore(self) -> bool:
        """Restore companion volume after voice focus ends.

        Only restores if *Jarvis* initiated the duck (``_voice_ducked=True``)
        AND no explicit command has taken over since.  Every explicit command
        clears ``_voice_ducked`` and advances the ownership generation, so a
        session-end restore that arrives after an explicit mute/volume/pause/
        stop/navigate is a GUARANTEED no-op: it never unmutes and never changes
        volume.  Best-effort: failures are swallowed.
        """
        if not self._companion_active():
            self._voice_ducked = False
            return False
        gen = self._voice_owner_gen
        async with self._companion_cmd_lock:
            # If an explicit command ran since we were scheduled, the generation
            # advanced and _voice_ducked was cleared: stop wins, no restore.
            if not self._command_still_current(gen):
                return False
            if not self._voice_ducked:
                return False
            try:
                await self._send_companion("restore")
            except YouTubeError:
                pass
            # Re-check after the await: an explicit command may have raced in.
            if not self._command_still_current(gen):
                return False
            self._voice_ducked = False
        self.updated_at = self._now()
        self._publish_media_state()
        return True

    async def voice_focus_pause(self) -> bool:
        """Pause companion playback during a confirmed voice session.

        Called after a verified wake or during active conversation, after
        duck has already been sent (or as an alternative if the session is
        long).  Only pauses through an authenticated companion; never affects
        host-browser or embedded fallback paths.

        Like duck/restore this is generation-checked: an explicit command that
        runs before this pause dispatches makes it a no-op (the explicit
        command's intent wins).  Best-effort: failures are swallowed.
        """
        if not self._companion_active():
            return False
        gen = self._voice_owner_gen
        async with self._companion_cmd_lock:
            if not self._command_still_current(gen):
                return False
            if not self._companion_active():
                return False
            if self.status not in ("playing", "buffering"):
                return False
            if self._ad_active():
                return False
            try:
                await self._send_companion("pause")
            except YouTubeError:
                return False
            if not self._command_still_current(gen):
                return False
            self.status = "paused"
            self._set_playing(False)
        self.updated_at = self._now()
        self._publish_media_state()
        return True

    async def next(self) -> dict:
        """Advance to the next item in the candidate list and begin playback."""
        if self.queue_index < 0 or self.queue_index + 1 >= len(self.queue):
            raise YouTubeError("there is no next video in the current queue")
        self.queue_index += 1
        selected = self.queue[self.queue_index]
        self.video_id, self.title = selected["video_id"], selected["title"]
        self.position_seconds = 0.0
        self.status = "buffering"
        return await self._emit_play_async(
            video_id=self.video_id,
            title=self.title,
            start_seconds=0,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    async def previous(self) -> dict:
        """Return to the previous item in the candidate list and begin playback."""
        if self.queue_index <= 0:
            raise YouTubeError("there is no previous video in the current queue")
        self.queue_index -= 1
        selected = self.queue[self.queue_index]
        self.video_id, self.title = selected["video_id"], selected["title"]
        self.position_seconds = 0.0
        self.status = "buffering"
        return await self._emit_play_async(
            video_id=self.video_id,
            title=self.title,
            start_seconds=0,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    def report(self, client_id: object, data: dict) -> dict:
        """Accept bounded player state only from the current lease owner.

        While a host-browser open is pending or committed, stale embedded-iframe
        reports are silently dropped so they cannot overwrite the authoritative
        playback_mode or clear the in-flight single-flight map.  The caller's
        heartbeat is still updated to keep the lease alive.

        For ``"ended"`` status the report is only authoritative when ALL of the
        following are true:
          - ``media_session`` is explicitly present in the payload and matches
            the current session.  Missing or mismatched = stale.
          - ``video_id`` is explicitly present in the payload and matches the
            current ``self.video_id``.  Missing or mismatched = stale.
          - Current ``playback_mode`` is ``"embedded"`` (not host_browser).
          - ``continuous`` and ``auto_advance`` are both True.
          - No advance is already in flight.
        Any missing identity field is treated as stale (not backward-compatible
        fallback) for ended specifically, to prevent double-advance races.

        Before scheduling the advance coroutine, the media_session is
        incremented (invalidating the end token) so a duplicate ended report
        arriving while the advance coroutine is awaiting cannot qualify.
        """
        if not self.heartbeat(client_id):
            raise YouTubeError("this page is not the selected Media player")

        # Stale or in-flight host-browser: update heartbeat but do not let this
        # report overwrite the pending/committed mode or clear the in-flight map.
        if self._host_browser_active():
            return self.snapshot()

        status = str(data.get("status", self.status)).strip().lower()
        if status not in {"queued", "playing", "paused", "buffering", "ended", "stopped", "error"}:
            raise YouTubeError("invalid media status")

        # Determine whether an "ended" report is authoritative for the CURRENT
        # media session / video before mutating any state.  Strict identity
        # check for "ended": both session AND video_id must be explicitly
        # present in the payload and match exactly.  Missing = stale.
        reported_session = data.get("media_session")
        reported_video = data.get("video_id")

        # For "ended" specifically, missing session or video is treated as stale.
        if status == "ended":
            # media_session must be present and match.
            if reported_session is None:
                session_match = False
            else:
                try:
                    session_match = int(reported_session) == self.media_session
                except (TypeError, ValueError):
                    session_match = False
            # video_id must be present and match.
            if not reported_video:
                video_match = False
            else:
                try:
                    video_match = extract_video_id(reported_video) == self.video_id
                except YouTubeAPIError:
                    video_match = False
        else:
            # Non-ended statuses: backward-compatible optional matching.
            session_match = True
            if reported_session is not None:
                try:
                    session_match = int(reported_session) == self.media_session
                except (TypeError, ValueError):
                    session_match = False
            video_match = True
            if reported_video:
                try:
                    video_match = extract_video_id(reported_video) == self.video_id
                except YouTubeAPIError:
                    video_match = False

        should_advance = (
            status == "ended"
            and self.continuous
            and self.auto_advance
            and self.media_kind == "video"
            and self.playback_mode == "embedded"
            and bool(self.queue)
            and session_match
            and video_match
            and not self._advancing
        )

        # BLOCKER 1: for "ended", ALL authoritative predicate checks above must
        # complete BEFORE any mutation.  A stale/duplicate/mismatched/host-mode/
        # non-continuous/advance-in-flight "ended" must NOT change status, video,
        # index, playback_mode, pending/inflight, or publish anything.  Only a
        # fully accepted ended (should_advance) is allowed to proceed and mutate.
        # We return the CURRENT snapshot unchanged so the OS-thread completion of
        # a superseded end event is a pure no-op observable to the caller.
        if status == "ended" and not should_advance:
            return self.snapshot()

        self.status = status
        raw_id = data.get("video_id")
        if raw_id:
            self.video_id = extract_video_id(raw_id)
        self.title = _text(data.get("title", self.title), 240)
        for field, maximum in (("position_seconds", 86400.0), ("duration_seconds", 86400.0)):
            if field in data:
                try:
                    value = float(data[field])
                except (TypeError, ValueError) as exc:
                    raise YouTubeError(f"invalid {field}") from exc
                setattr(self, field, max(0.0, min(maximum, value)))
        if "queue_index" in data:
            try:
                index = int(data["queue_index"])
            except (TypeError, ValueError) as exc:
                raise YouTubeError("invalid queue index") from exc
            if self.queue and 0 <= index < len(self.queue):
                self.queue_index = index
        # A reporting embedded player is authoritative: clear any lingering
        # host-browser state (safe because _host_browser_active() was False).
        self.playback_mode = "embedded"
        self._reset_host_browser_state()
        self.updated_at = self._now()
        self._refresh_audible()
        self._publish_media_state()

        if should_advance:
            # Invalidate the current end token BEFORE scheduling the advance so
            # a duplicate ended report arriving while the coroutine is awaiting
            # cannot qualify (the session no longer matches).
            self._advancing = True
            self.media_session += 1
            self._advance_task = asyncio.ensure_future(
                self._auto_advance(self.media_session)
            )
        return self.snapshot()

    async def _auto_advance(self, session: int) -> None:
        """Advance to the next queue item (looping) for a continuous video queue.

        Guarded by the media session generation captured when the ended report
        was accepted (and incremented by report() before scheduling so no
        duplicate ended can qualify): if the session no longer matches (stop,
        new play, playlist switch, or the incremented value differs) the advance
        is abandoned.

        The session passed in is the NEW (already incremented) value.  Any stop
        or new-play that bumps media_session again means session != media_session
        here and the advance is abandoned without touching playback state.
        """
        try:
            # Verify the immutable token still matches.
            if session != self.media_session or not self.continuous:
                return
            # Extra guard: mode must still be embedded (not host_browser).
            if self.playback_mode != "embedded":
                return
            if not self.queue:
                return
            # Loop back to the queue start when at the end while continuous.
            next_index = self.queue_index + 1
            if next_index >= len(self.queue):
                next_index = 0
            self.queue_index = next_index
            selected = self.queue[self.queue_index]
            self.video_id, self.title = selected["video_id"], selected["title"]
            self.position_seconds = 0.0
            self.status = "buffering"
            # _emit_play_async increments media_session for the new play, so the
            # next ended report for this new video will carry the new session.
            self.media_session += 1
            await self._emit_play_async(
                video_id=self.video_id,
                title=self.title,
                start_seconds=0,
                queue=[item["video_id"] for item in self.queue],
                queue_index=self.queue_index,
            )
        finally:
            self._advancing = False
