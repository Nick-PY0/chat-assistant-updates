"""Dashboard authentication: Argon2id password, signed cookies, CSRF,
and login rate limiting."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time
import asyncio
from collections.abc import Awaitable, Callable

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

_hasher = PasswordHasher()  # argon2id by default


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


class SessionManager:
    _MAX_REVOCATIONS = 2048
    REMEMBERED_MAX_AGE = 30 * 86400

    def __init__(
        self,
        secret: str,
        max_age_seconds: int,
        security_state: dict | None = None,
        persist_security_state: Callable[[dict], Awaitable[None]] | None = None,
    ) -> None:
        self._serializer = URLSafeTimedSerializer(secret, salt="chat-session")
        self._cap_serializer = URLSafeTimedSerializer(secret, salt="chat-capability")
        self._csrf_key = hashlib.sha256(("csrf:" + secret).encode()).digest()
        self.max_age = max_age_seconds
        # The ordinary session lifetime remains configurable. Remembered
        # sessions have a fixed, server-owned upper bound; a value carried in
        # the signed token can select a shorter lifetime but never extend it.
        self.remembered_max_age = self.REMEMBERED_MAX_AGE
        self._max_token_age = max(self.max_age, self.remembered_max_age)
        state = security_state if isinstance(security_state, dict) else {}
        try:
            self._generation = max(0, int(state.get("generation", 0)))
        except (TypeError, ValueError):
            self._generation = 0
        now = int(time.time())
        revoked = state.get("revoked", {})
        self._revoked = {
            str(sid): int(expiry)
            for sid, expiry in (revoked.items() if isinstance(revoked, dict) else ())
            if isinstance(sid, str)
            and isinstance(expiry, (int, float))
            and int(expiry) > now
        }
        # An oversized persisted value must fail closed rather than restoring
        # old sessions by dropping live revocations.
        if len(self._revoked) > self._MAX_REVOCATIONS:
            self._generation += 1
            self._revoked.clear()
        self._persist_security_state = persist_security_state
        self._security_lock = asyncio.Lock()

    def issue(self, max_age_seconds: int | None = None) -> str:
        ttl = self.max_age if max_age_seconds is None else max_age_seconds
        if (
            isinstance(ttl, bool)
            or not isinstance(ttl, int)
            or ttl <= 0
            or ttl > self._max_token_age
        ):
            raise ValueError("session lifetime is outside the server limit")
        return self._serializer.dumps({
            "sid": secrets.token_hex(16),
            "generation": self._generation,
            "ttl": ttl,
        })

    def _load(self, token: str | None) -> tuple[dict, int, int] | None:
        if not token:
            return None
        try:
            data, timestamp = self._serializer.loads(
                token, max_age=self._max_token_age, return_timestamp=True
            )
        except (BadSignature, SignatureExpired):
            return None
        if not isinstance(data, dict) or not isinstance(data.get("sid"), str):
            return None
        # Cookies issued before per-session lifetimes were introduced did not
        # contain ttl. Keep them valid for the ordinary configured lifetime.
        ttl = data.get("ttl", self.max_age)
        if (
            isinstance(ttl, bool)
            or not isinstance(ttl, int)
            or ttl <= 0
            or ttl > self._max_token_age
        ):
            return None
        try:
            # Re-run the timed verification with the signed per-session bound.
            self._serializer.loads(token, max_age=ttl)
        except (BadSignature, SignatureExpired):
            return None
        try:
            generation = int(data.get("generation", 0))
        except (TypeError, ValueError):
            return None
        if generation != self._generation:
            return None
        issued_at = int(timestamp.timestamp())
        return data, ttl, issued_at

    def validate(self, token: str | None) -> dict | None:
        loaded = self._load(token)
        if loaded is None:
            return None
        data, _, _ = loaded
        expiry = self._revoked.get(data["sid"])
        if expiry is not None:
            if expiry > int(time.time()):
                return None
            self._revoked.pop(data["sid"], None)
        return data

    def _state(self) -> dict:
        now = int(time.time())
        self._revoked = {
            sid: expiry for sid, expiry in self._revoked.items()
            if expiry > now
        }
        return {
            "generation": self._generation,
            "revoked": dict(self._revoked),
        }

    async def _persist(self) -> None:
        if self._persist_security_state is not None:
            await self._persist_security_state(self._state())

    async def revoke(self, token: str | None) -> bool:
        """Revoke one valid session and persist the revocation before return."""
        if self.validate(token) is None:
            return False
        async with self._security_lock:
            # Re-check after acquiring the lock so concurrent logout/password
            # mutations can't overwrite or revive one another.
            loaded = self._load(token)
            if loaded is None or self.validate(token) is None:
                return False
            data, ttl, issued_at = loaded
            # Retain the revocation through this token's own signed expiry.
            # In particular, a 30-day token must not revive when the old
            # ordinary-session prune horizon passes.
            self._revoked[data["sid"]] = issued_at + ttl + 1
            if len(self._revoked) > self._MAX_REVOCATIONS:
                self._generation += 1
                self._revoked.clear()
            await self._persist()
        return True

    async def invalidate_all(self) -> None:
        """Invalidate every issued session, used after a password change."""
        async with self._security_lock:
            self._generation += 1
            self._revoked.clear()
            await self._persist()

    def csrf_for(self, token: str) -> str:
        return hmac.new(self._csrf_key, token.encode(), hashlib.sha256).hexdigest()

    def csrf_ok(self, token: str | None, csrf: str | None) -> bool:
        if not token or not csrf:
            return False
        return hmac.compare_digest(self.csrf_for(token), csrf)

    # -- scoped capabilities ------------------------------------------------
    # WebSocket handshakes cannot carry custom headers, and putting the
    # session cookie value in JavaScript-visible messages would widen its
    # exposure. Instead the page fetches a short-lived capability over an
    # authenticated (cookie + CSRF) endpoint and presents it in the socket
    # hello. A capability is bound to the session id AND an explicit scope,
    # so it cannot be replayed for a different purpose or another session.

    def capability_for(self, cookie_token: str | None, scope: str) -> str | None:
        """Issue a signed, scoped capability for the authenticated session."""
        data = self.validate(cookie_token)
        if not isinstance(data, dict) or not data.get("sid"):
            return None
        return self._cap_serializer.dumps({"sid": data["sid"], "scope": scope})

    def capability_ok(
        self,
        cookie_token: str | None,
        capability: str | None,
        scope: str,
        max_age: int = 120,
    ) -> bool:
        """True when *capability* is fresh, matches *scope*, and belongs to
        the same session that presents it."""
        data = self.validate(cookie_token)
        if not isinstance(data, dict) or not data.get("sid") or not capability:
            return False
        try:
            cap = self._cap_serializer.loads(capability, max_age=max_age)
        except (BadSignature, SignatureExpired):
            return False
        if not isinstance(cap, dict):
            return False
        return hmac.compare_digest(
            str(cap.get("sid", "")), str(data["sid"])
        ) and hmac.compare_digest(str(cap.get("scope", "")), scope)


class LoginRateLimiter:
    def __init__(self, max_attempts: int, window_seconds: int) -> None:
        self.max_attempts = max_attempts
        self.window = window_seconds
        self._attempts: dict[str, list[float]] = {}

    def check(self, ip: str) -> bool:
        """True if this IP may attempt a login."""
        now = time.monotonic()
        attempts = [t for t in self._attempts.get(ip, []) if now - t < self.window]
        self._attempts[ip] = attempts
        return len(attempts) < self.max_attempts

    def record_failure(self, ip: str) -> None:
        self._attempts.setdefault(ip, []).append(time.monotonic())

    def reset(self, ip: str) -> None:
        self._attempts.pop(ip, None)

    def retry_in(self, ip: str) -> int:
        attempts = self._attempts.get(ip, [])
        if not attempts:
            return 0
        return max(0, int(self.window - (time.monotonic() - min(attempts))))
