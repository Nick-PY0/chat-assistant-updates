"""Focused signed session lifetime and compatibility tests."""

from __future__ import annotations

import time

from itsdangerous import TimestampSigner

from chat_core.security.auth import SessionManager


def test_session_ttl_is_signed_and_server_bounded():
    sessions = SessionManager("ttl-test-secret", 86400)
    token = sessions.issue(sessions.remembered_max_age)
    assert sessions.validate(token) is not None

    payload, timestamp = sessions._serializer.loads(token, return_timestamp=True)
    payload["ttl"] = sessions.remembered_max_age + 1
    overlong = sessions._serializer.dumps(payload)
    assert sessions.validate(overlong) is None

    pieces = token.split(".")
    pieces[0] = ("A" if pieces[0][0] != "A" else "B") + pieces[0][1:]
    assert sessions.validate(".".join(pieces)) is None


def test_per_session_ttl_expires_and_legacy_cookie_keeps_normal_ttl(monkeypatch):
    sessions = SessionManager("expiry-test-secret", 60)
    now = int(time.time())
    monkeypatch.setattr(TimestampSigner, "get_timestamp", lambda self: now - 61)
    expired = sessions.issue(60)
    legacy = sessions._serializer.dumps({"sid": "legacy", "generation": 0})
    monkeypatch.undo()

    assert sessions.validate(expired) is None
    assert sessions.validate(legacy) is None

    current_legacy = sessions._serializer.dumps({
        "sid": "current-legacy",
        "generation": 0,
    })
    assert sessions.validate(current_legacy) is not None


async def test_long_session_revocation_uses_its_signed_expiry():
    persisted = []

    async def persist(state):
        persisted.append(state)

    sessions = SessionManager(
        "revocation-horizon-test-secret",
        86400,
        persist_security_state=persist,
    )
    token = sessions.issue(sessions.remembered_max_age)
    assert await sessions.revoke(token)
    expiry = next(iter(persisted[-1]["revoked"].values()))
    assert expiry > int(time.time()) + 29 * 86400