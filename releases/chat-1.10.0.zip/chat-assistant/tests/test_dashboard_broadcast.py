"""Desktop-side broadcast protocol security tests."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac

import pytest

from apps.dashboard.broadcast import (
    PROTOCOL_MESSAGE,
    BroadcastConnector,
    BroadcastPolicy,
    BroadcastRejected,
    _PinnedConnect,
    _request,
    _secure_cookie,
    relay_endpoint,
)
from apps.dashboard.app import create_app
from chat_core.config.settings import Settings
from chat_core.runtime import Runtime
from chat_core.security.auth import hash_password
from websockets.exceptions import SecurityError


ORIGIN = "https://jarvis.example"


@pytest.fixture
async def runtime(settings):
    value = Runtime(settings)
    await value.start(voice=False, cloud=False, monitoring=False)
    yield value
    await value.stop()


def http_frame(**changes):
    frame = {
        "type": "http",
        "id": "opaque-1",
        "method": "GET",
        "path": "/",
        "query": "",
        "headers": [["accept", "text/html"]],
        "body": "",
    }
    frame.update(changes)
    return frame


def test_broadcast_is_persisted_default_off():
    assert Settings().broadcast_enabled is False
    assert Settings().cloud_schedule_enabled is False


def test_relay_url_is_https_origin_pinned():
    assert relay_endpoint("https://jarvis.example") == (
        ORIGIN,
        "wss://jarvis.example/remote-link/connect",
    )
    for unsafe in (
        "http://jarvis.example",
        "https://jarvis.example/other",
        "https://user:pass@jarvis.example",
        "https://jarvis.example?next=evil",
    ):
        with pytest.raises(BroadcastRejected):
            relay_endpoint(unsafe)


def test_policy_rejects_bad_methods_paths_and_remote_admin():
    policy = BroadcastPolicy()
    for frame in (
        http_frame(method="PATCH", path="/api/chat"),
        http_frame(path="/settings"),
        http_frame(path="/api/settings"),
        http_frame(path="/foo//bar"),
        http_frame(path="/static/../settings"),
        http_frame(path="/static/%2e%2e/settings"),
    ):
        with pytest.raises(BroadcastRejected):
            _request(frame, policy, ORIGIN)


def test_policy_keeps_routine_catalog_and_dynamic_reads():
    policy = BroadcastPolicy()
    assert policy.allows_http("GET", "/api/routines")
    assert policy.allows_http("GET", "/api/routines/catalog-entry_1")
    assert policy.allows_http("POST", "/api/routines/templates/morning")


def test_mutations_and_websockets_require_exact_pinned_origin():
    policy = BroadcastPolicy()
    post = http_frame(
        method="POST",
        path="/api/chat",
        headers=[["origin", "https://evil.example"], ["content-type", "application/json"]],
    )
    with pytest.raises(BroadcastRejected):
        _request(post, policy, ORIGIN)
    post["headers"][0][1] = ORIGIN
    assert _request(post, policy, ORIGIN)[1] == "POST"

    ws = {
        "type": "ws.open", "id": "socket-1", "path": "/ws/audio", "query": "",
        "headers": [["origin", "https://evil.example"], ["cookie", "chat_session=x"]],
    }
    with pytest.raises(BroadcastRejected):
        _request(ws, policy, ORIGIN, websocket=True)
    ws["headers"][0][1] = ORIGIN
    assert _request(ws, policy, ORIGIN, websocket=True)[1] == "/ws/audio"


def test_dashboard_alias_maps_only_at_dispatch_boundary():
    parsed = _request(http_frame(path="/dashboard"), BroadcastPolicy(), ORIGIN)
    assert parsed[2] == "/dashboard"


def test_remote_cookie_flags_are_forced():
    cookie = _secure_cookie("chat_session=value; Path=/; SameSite=Lax")
    assert "Secure" in cookie
    assert "HttpOnly" in cookie
    assert "SameSite=Strict" in cookie
    assert "SameSite=Lax" not in cookie


def test_redirects_are_rejected_before_reusing_authorization(monkeypatch):
    marker = "wss://elsewhere.example/remote-link/connect"
    monkeypatch.setattr(
        _PinnedConnect.__mro__[1],
        "process_redirect",
        lambda self, exc: marker,
    )
    connector = object.__new__(_PinnedConnect)
    result = connector.process_redirect(RuntimeError())
    assert isinstance(result, SecurityError)
    assert marker not in str(result)


async def test_configuration_requires_password_and_never_uses_hosted_secret_for_custom_url(
    runtime, monkeypatch,
):
    runtime.settings.broadcast_enabled = True
    runtime.settings.relay_url = "https://custom.example"
    connector = BroadcastConnector(lambda scope, receive, send: None, runtime)

    with pytest.raises(RuntimeError, match="password"):
        await connector._configuration()

    await runtime.db.set_setting("admin_password_hash", hash_password("owner-password"))
    monkeypatch.setenv("CHAT_RELAY_SECRET", "hosted-only-secret")
    monkeypatch.setenv("REPLIT_DEV_DOMAIN", "trusted-dev.example")
    with pytest.raises(RuntimeError, match="active Relay credential"):
        await connector._configuration()

    runtime.settings.relay_url = ""
    origin, endpoint, token = await connector._configuration()
    assert origin == "https://trusted-dev.example"
    assert endpoint == "wss://trusted-dev.example/remote-link/connect"
    assert token == hmac.new(
        b"hosted-only-secret", PROTOCOL_MESSAGE, hashlib.sha256
    ).hexdigest()

    runtime.settings.relay_url = "https://custom.example"
    credential = await runtime.store.add("relay", "encrypted-custom-secret", purpose="chat")
    assert credential is not None
    origin, _, token = await connector._configuration()
    assert origin == "https://custom.example"
    assert token == hmac.new(
        b"encrypted-custom-secret", PROTOCOL_MESSAGE, hashlib.sha256
    ).hexdigest()


async def test_disable_cancels_streams_and_stale_generation_cannot_send(runtime):
    runtime.settings.broadcast_enabled = True
    connector = BroadcastConnector(lambda scope, receive, send: None, runtime)
    connector._epoch = 7
    connector._outgoing = asyncio.Queue(maxsize=1)

    await connector._send({"type": "error", "id": "old"}, 6)
    assert connector._outgoing.empty()

    started = asyncio.Event()

    async def stream():
        started.set()
        await asyncio.Future()

    task = asyncio.create_task(stream())
    await started.wait()
    connector._active["stream"] = task
    await connector.set_enabled(False)
    assert task.cancelled()
    assert connector.state == "disabled"
    assert connector._epoch == 8


async def test_remote_login_cookie_and_csrf_roundtrip_through_asgi_stream(runtime):
    await runtime.db.set_setting("admin_password_hash", hash_password("owner-password"))
    app = create_app(runtime)
    connector = app.state.broadcast
    sent: list[dict] = []

    async def capture(frame, epoch):
        sent.append(frame)

    connector._send = capture
    connector._epoch = 3
    form = b"password=owner-password&remember=true"
    login = http_frame(
        method="POST",
        path="/login",
        headers=[
            ["origin", ORIGIN],
            ["content-type", "application/x-www-form-urlencoded"],
        ],
        body=base64.b64encode(form).decode(),
    )
    await connector._http(_request(login, connector.policy, ORIGIN), ORIGIN, 3)

    start = next(frame for frame in sent if frame["type"] == "http.start")
    headers = dict(start["headers"])
    assert start["status"] == 303
    assert headers["location"] == "/dashboard"
    cookie = headers["set-cookie"]
    assert all(flag in cookie for flag in ("Secure", "HttpOnly", "SameSite=Strict"))
    assert "Max-Age=2592000" in cookie

    cookie_pair = cookie.split(";", 1)[0]
    sent.clear()
    dashboard = http_frame(path="/dashboard", headers=[["cookie", cookie_pair]])
    await connector._http(_request(dashboard, connector.policy, ORIGIN), ORIGIN, 3)
    body = b"".join(
        base64.b64decode(frame["body"])
        for frame in sent
        if frame["type"] == "http.body"
    ).decode()
    assert 'meta name="csrf" content="' in body
    assert 'href="/dashboard"' in body
    assert 'href="/settings"' not in body