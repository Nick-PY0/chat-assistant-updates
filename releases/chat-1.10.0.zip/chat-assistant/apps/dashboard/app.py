"""Dashboard + authenticated management API (FastAPI).

Security baseline honored:
  * LAN/local binding only (configurable), optional HTTPS via local cert
  * Argon2id password, signed HttpOnly SameSite cookies, CSRF, login rate limit
  * No plaintext secret ever leaves the server; adds are validated then
    encrypted; UI shows only masked suffixes
  * Live status over Server-Sent Events
"""

from __future__ import annotations

import asyncio
import hashlib
import html
import json
import os
import secrets
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, Form, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from chat_core.net import lan_ip
from chat_core.runtime import Runtime
from chat_core.config.settings import TYPED_CHAT_PROVIDERS, valid_model_id
from chat_core.models.state import ChatState
from chat_core.version import APP_VERSION
from chat_core.security.auth import (
    LoginRateLimiter,
    SessionManager,
    hash_password,
    verify_password,
)
from chat_core.models.google_account import OAuthStateError
from chat_core.logging_setup import sanitize
from apps.tool_service.local_grammar import parse as parse_command
from apps.tool_service.calendar_tool import CalendarToolError
from apps.tool_service.briefing_scheduler import SchedulerError
from apps.live_gateway.text_chat import TextChatError
from integrations.gemini.errors import GeminiFailure
from integrations.gemini.validator import validate_key
from integrations.govee.client import GoveeClient, GoveeError
from integrations.lg_webos import WebOSTVError
from integrations.openai_rt.validator import validate_openai_key
from integrations.relay.client import RelayClient, RelayError
from integrations.cloud_schedule import CloudScheduleError
from integrations.weather import WeatherError
from integrations.youtube import YouTubeAPIError, YouTubeClient
from integrations.google_calendar import GoogleCalendarError
from integrations.github_publish import (
    GitHubBrokerClient,
    GitHubBrokerError,
    GitHubPublishError,
    GitHubPublishService,
)
from apps.tool_service.youtube_tool import YouTubeError
from apps.tool_service.music_tool import MusicError
from apps.tool_service.routines import RoutineError
from chat_core.music import LocalMusicLibraryError
from integrations.spotify import SpotifyError
from apps.tool_service.companion_bridge import CompanionError
from apps.tool_service.expert_tool import ExpertError
from apps.dashboard.companion_server import serve_companion_socket
from apps.dashboard.remote_voice_socket import serve_remote_voice_socket
from apps.dashboard.broadcast import BroadcastConnector

BASE_DIR = Path(__file__).resolve().parent
COOKIE = "chat_session"
GOOGLE_OAUTH_COOKIE = "chat_google_oauth"
SPOTIFY_OAUTH_COOKIE = "chat_spotify_oauth"


def create_app(rt: Runtime) -> FastAPI:
    @asynccontextmanager
    async def lifespan(application: FastAPI):
        # The connector schedules its network loop and returns immediately.
        # It receives only HTTP/websocket scopes, never this lifespan scope.
        await application.state.broadcast.start()
        try:
            yield
        finally:
            await application.state.broadcast.stop()

    app = FastAPI(
        title="Nexa", docs_url=None, redoc_url=None, openapi_url=None,
        lifespan=lifespan,
    )
    templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    limiter = LoginRateLimiter(rt.settings.login_max_attempts, rt.settings.login_window_seconds)
    https_on = bool(rt.settings.ssl_certfile and rt.settings.ssl_keyfile)
    broadcast = BroadcastConnector(app, rt)
    app.state.broadcast = broadcast

    def protected_update_repositories() -> set[str]:
        protected = {"Nick-PY0/chat-assistant-updates"}
        parsed = urlparse(str(rt.settings.update_url or ""))
        parts = [part for part in parsed.path.split("/") if part]
        if parsed.hostname in {"raw.githubusercontent.com", "github.com"} and len(parts) >= 2:
            protected.add(f"{parts[0]}/{parts[1]}")
        return protected

    async def github_broker_client() -> GitHubBrokerClient:
        environment_secret = os.environ.get("CHAT_RELAY_SECRET", "").strip()
        secret = ""
        if rt.store is not None:
            credentials = await rt.store.list("relay")
            credential = next(
                (
                    item for item in credentials
                    if item.status not in {"disabled", "invalid"}
                ),
                None,
            )
            if credential is not None:
                secret = await rt.store.get_secret(credential.id)

        if secret:
            relay_url = rt.settings.relay_url.strip()
            if not relay_url:
                raise GitHubPublishError(
                    "No Relay address is set. Configure it under Providers first.",
                    status=503,
                )
        else:
            # Replit-hosted development can reuse the workspace Relay secret,
            # but it may only be sent to this workspace's own trusted domain.
            # Custom/desktop Relay URLs must use their encrypted Provider
            # credential and can never receive the managed environment secret.
            development_domain = os.environ.get("REPLIT_DEV_DOMAIN", "").strip()
            relay_url = (
                f"https://{development_domain}"
                if environment_secret and development_domain
                else ""
            )
            secret = environment_secret
        if not secret:
            raise GitHubPublishError(
                "No Relay password is available. Configure it under Providers first.",
                status=503,
            )
        if not relay_url:
            raise GitHubPublishError(
                "The hosted GitHub Relay is unavailable. Configure the Relay under Providers.",
                status=503,
            )
        try:
            return GitHubBrokerClient(relay_url, secret)
        except GitHubBrokerError as exc:
            raise GitHubPublishError(str(exc), status=exc.status) from exc

    github_publish = GitHubPublishService(
        Path(__file__).resolve().parents[2],
        rt.settings.data_path,
        github_broker_client,
        protected_repositories=protected_update_repositories,
    )
    app.state.github_publish = github_publish

    # session secret: env wins, else generated once and stored
    session_init_lock = asyncio.Lock()

    async def session_mgr() -> SessionManager:
        if hasattr(app.state, "sessions"):
            return app.state.sessions
        # One manager owns revocation mutations, including the first concurrent
        # requests after a restart. Separate lazy loads could lose a logout.
        async with session_init_lock:
            return await load_session_mgr()

    async def load_session_mgr() -> SessionManager:
        if not hasattr(app.state, "sessions"):
            import os
            secret = os.environ.get("SESSION_SECRET") or await rt.db.get_setting("session_secret")
            if not secret:
                secret = secrets.token_hex(32)
                await rt.db.set_setting("session_secret", secret)
            raw_security = await rt.db.get_setting("session_security_state")
            try:
                security_state = json.loads(raw_security) if raw_security else {}
            except (json.JSONDecodeError, TypeError):
                # Corrupt revocation state fails closed for pre-generation
                # cookies and is replaced on the next auth mutation.
                security_state = {"generation": 1, "revoked": {}}

            async def persist_security_state(state: dict) -> None:
                await rt.db.set_setting(
                    "session_security_state",
                    json.dumps(state, separators=(",", ":"), sort_keys=True),
                )

            app.state.sessions = SessionManager(
                secret,
                rt.settings.session_max_age_days * 86400,
                security_state,
                persist_security_state,
            )
        return app.state.sessions

    # -- auth plumbing ---------------------------------------------------
    async def current_session(request: Request) -> dict | None:
        sm = await session_mgr()
        return sm.validate(request.cookies.get(COOKIE))

    async def require_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        if await current_session(request) is None:
            return RedirectResponse("/login", status_code=303)
        return None

    async def require_api(request: Request) -> JSONResponse | None:
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        if request.method in ("POST", "PUT", "DELETE"):
            sm = await session_mgr()
            token = request.cookies.get(COOKIE)
            csrf = request.headers.get("x-csrf") or (await _form_csrf(request))
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
        return None

    async def _form_csrf(request: Request) -> str | None:
        if request.headers.get("content-type", "").startswith("application/x-www-form-urlencoded"):
            form = await request.form()
            value = form.get("_csrf")
            return value if isinstance(value, str) else None
        return None

    def same_site_ok(request: Request) -> bool:
        """Cross-site protection for the pre-auth forms (/setup, /login),
        which cannot rely on session-bound CSRF tokens. A hostile web page
        form-posting to this dashboard sends Origin and/or Sec-Fetch-Site
        headers that give it away; same-origin posts and non-browser tools
        pass."""
        origin = request.headers.get("origin")
        if origin and origin != "null":
            if urlparse(origin).netloc != request.headers.get("host", ""):
                return False
        elif origin == "null":
            return False
        fetch_site = request.headers.get("sec-fetch-site")
        if fetch_site and fetch_site.lower() == "cross-site":
            return False
        return True

    def is_loopback(request: Request) -> bool:
        """True when the request comes from this computer itself. First-time
        setup is restricted to loopback so a LAN device can never claim the
        admin password before the owner does."""
        host = request.client.host if request.client else ""
        return host.startswith("127.") or host in ("::1", "localhost")

    _lan_cache = {"ts": 0.0, "ip": ""}

    def dashboard_urls() -> dict:
        """Local + LAN URLs for 'open this on your phone' hints (cached)."""
        now = time.monotonic()
        if now - _lan_cache["ts"] > 60:
            _lan_cache["ip"] = lan_ip()
            _lan_cache["ts"] = now
        scheme = "https" if https_on else "http"
        port = rt.settings.dashboard_port
        urls = {"local": f"{scheme}://127.0.0.1:{port}"}
        if rt.settings.dashboard_host in ("0.0.0.0", "::") and _lan_cache["ip"]:
            urls["lan"] = f"{scheme}://{_lan_cache['ip']}:{port}"
        return urls

    async def page_ctx(request: Request, active: str) -> dict:
        sm = await session_mgr()
        token = request.cookies.get(COOKIE) or ""
        from dataclasses import asdict

        settings_public = asdict(rt.settings)
        settings_public.pop("extra", None)
        remote = bool(request.scope.get("jarvis.broadcast"))
        # Escape </script> so a stored payload in any string field cannot
        # break out of the inline <script> block that injects settings_json.
        settings_json_safe = json.dumps(settings_public).replace(
            "</", "<\\/"
        )
        return {
            "request": request,
            "active": active,
            "csrf": sm.csrf_for(token) if token else "",
            "state": rt.state.snapshot(),
            "voice_ok": bool(rt.audio and rt.audio.voice_available),
            "voice_reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            "keychain_source": rt.master.source,
            "settings_json": settings_json_safe,
            "typed_chat_provider": rt.settings.typed_chat_provider,
            "typed_chat_model": (
                rt.settings.openai_text_model
                if rt.settings.typed_chat_provider == "openai"
                else rt.settings.relay_chat_model
            ),
            "app_version": APP_VERSION,
            "quiet": rt.quiet,
            "ringing": rt.ringing,
            "broadcast_request": remote,
            "home_url": "/dashboard" if remote else "/",
        }

    # -- public health identity endpoint (unauthenticated; no secrets) ------
    @app.get("/api/healthz")
    async def api_healthz():
        """Unauthenticated identity endpoint used to verify this process is
        Nexa before acting on a port-in-use signal. No secrets are exposed."""
        from chat_core.version import APP_VERSION as _VER

        return {"app": "chat-assistant", "version": _VER}

    # -- one-time phone HTTPS setup ----------------------------------------
    def _ca_cert_fingerprint(path: Path) -> str | None:
        """Return the colon-separated SHA-256 fingerprint of a PEM certificate,
        or None if the file cannot be read or parsed."""
        try:
            from cryptography import x509 as _x509
            from cryptography.hazmat.primitives import hashes as _hashes

            data = path.read_bytes()
            cert = _x509.load_pem_x509_certificate(data)
            digest = cert.fingerprint(_hashes.SHA256())
            return ":".join(f"{b:02X}" for b in digest)
        except Exception:
            return None

    @app.get("/ca-cert.pem")
    async def public_ca_certificate(request: Request):
        """Serve the public CA certificate for download — loopback only.

        A LAN device must not be able to pull the file anonymously: the owner
        must download it on the Nexa computer and transfer it out-of-band.
        The private CA key is never served under any circumstances.
        """
        if not is_loopback(request):
            return JSONResponse(
                {
                    "error": (
                        "The CA certificate may only be downloaded directly on the computer "
                        "running Nexa. Open http://127.0.0.1:<port>/mobile-setup there, "
                        "download the file, verify the fingerprint, then transfer it to your "
                        "device via USB, AirDrop, or another trusted local method."
                    )
                },
                status_code=403,
            )
        path = rt.settings.data_path / "ca-cert.pem"
        if not path.is_file():
            return JSONResponse(
                {"error": "Run deployment/windows/make_cert.py, then restart Nexa."},
                status_code=404,
            )
        return FileResponse(
            path,
            media_type="application/x-x509-ca-cert",
            filename="chat-assistant-local-ca.pem",
            headers={
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/mobile-setup", response_class=HTMLResponse)
    async def mobile_setup_page(request: Request):
        urls = dashboard_urls()
        ca_path = rt.settings.data_path / "ca-cert.pem"
        ca_ready = ca_path.is_file()
        fingerprint = _ca_cert_fingerprint(ca_path) if ca_ready else None
        return templates.TemplateResponse(
            request,
            "mobile_setup.html",
            {
                "request": request,
                "lan_url": urls.get("lan", ""),
                "ca_ready": ca_ready,
                "fingerprint": fingerprint,
                "is_loopback": is_loopback(request),
                "phone_access_enabled": rt.settings.dashboard_host in ("0.0.0.0", "::"),
            },
        )

    # -- Windows startup (per-user, loopback-only) -------------------------
    @app.get("/api/startup/status")
    async def api_startup_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        from deployment.windows.startup_helper import _get_status  # noqa: PLC0415

        return _get_status()

    @app.post("/api/startup/enable")
    async def api_startup_enable(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Startup settings may only be changed from the computer running Nexa."},
                status_code=403,
            )
        from deployment.windows.startup_helper import enable as _enable  # noqa: PLC0415

        rc = _enable()
        if rc != 0:
            return JSONResponse({"error": "Failed to enable startup entry."}, status_code=500)
        return {"ok": True, "enabled": True}

    @app.post("/api/startup/disable")
    async def api_startup_disable(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Startup settings may only be changed from the computer running Nexa."},
                status_code=403,
            )
        from deployment.windows.startup_helper import disable as _disable  # noqa: PLC0415

        rc = _disable()
        if rc != 0:
            return JSONResponse({"error": "Failed to disable startup entry."}, status_code=500)
        return {"ok": True, "enabled": False}

    # -- setup & login -----------------------------------------------------
    @app.get("/setup", response_class=HTMLResponse)
    async def setup_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if not is_loopback(request):
            return HTMLResponse(
                "<p>First-time setup happens on the computer running Nexa itself. "
                "Open the dashboard there (the console window shows the address), "
                "create the password, then sign in from this device.</p>",
                status_code=403,
            )
        return templates.TemplateResponse(request, "setup.html", {"request": request, "error": ""})

    @app.post("/setup")
    async def setup_submit(request: Request, password: str = Form(...), confirm: str = Form(...)):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        if not is_loopback(request):
            return JSONResponse(
                {"error": "first-time setup is only allowed on the computer running Nexa"},
                status_code=403,
            )
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if len(password) < 8:
            return templates.TemplateResponse(
                request, "setup.html",
                {"request": request, "error": "Password must be at least 8 characters."},
            )
        if password != confirm:
            return templates.TemplateResponse(
                request, "setup.html", {"request": request, "error": "Passwords do not match."}
            )
        await rt.db.set_setting("admin_password_hash", hash_password(password))
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(
            COOKIE, sm.issue(), max_age=sm.max_age, httponly=True,
            samesite="strict", secure=https_on,
        )
        await rt.db.log("INFO", "dashboard", "admin password set")
        return resp

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        return templates.TemplateResponse(
            request, "login.html",
            {
                "request": request,
                "error": "",
                "remember": True,
                "broadcast_request": bool(request.scope.get("jarvis.broadcast")),
                "home_url": "/dashboard" if request.scope.get("jarvis.broadcast") else "/",
            },
        )

    @app.post("/login")
    async def login_submit(
        request: Request,
        password: str = Form(...),
        remember: str | None = Form(None),
    ):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        if remember not in (None, "true", "false"):
            return JSONResponse({"error": "invalid remember value"}, status_code=400)
        should_remember = remember == "true"
        # A missing field identifies older API/automation clients that predate
        # the checkbox; retain their ordinary persistent cookie. The browser
        # form always submits either true or false.
        legacy_login = remember is None
        ip = request.client.host if request.client else "unknown"
        if not limiter.check(ip):
            return templates.TemplateResponse(
                request, "login.html",
                {
                    "request": request,
                    "error": f"Too many attempts. Try again in {limiter.retry_in(ip) // 60 + 1} min.",
                    "remember": should_remember,
                },
                status_code=429,
            )
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, password):
            limiter.record_failure(ip)
            await rt.db.log("WARNING", "dashboard", f"failed login from {ip}")
            return templates.TemplateResponse(
                request,
                "login.html",
                {
                    "request": request,
                    "error": "Wrong password.",
                    "remember": should_remember,
                },
                status_code=401,
            )
        limiter.reset(ip)
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        cookie_args = {
            "httponly": True,
            "samesite": "strict",
            "secure": https_on or bool(request.scope.get("jarvis.broadcast")),
        }
        if should_remember or legacy_login:
            cookie_args["max_age"] = (
                sm.remembered_max_age if should_remember else sm.max_age
            )
        resp.set_cookie(
            COOKIE,
            sm.issue(
                sm.remembered_max_age if should_remember else sm.max_age
            ),
            **cookie_args,
        )
        return resp

    @app.post("/logout")
    async def logout(request: Request):
        sm = await session_mgr()
        token = request.cookies.get(COOKIE)
        if sm.validate(token) is not None:
            csrf = await _form_csrf(request)
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
            await sm.revoke(token)
        resp = RedirectResponse("/login", status_code=303)
        resp.delete_cookie(COOKIE)
        return resp

    # -- pages ------------------------------------------------------------
    def page(route: str, template: str, name: str):
        @app.get(route, response_class=HTMLResponse, name=f"page_{name}")
        async def _page(request: Request):
            redirect = await require_page(request)
            if redirect:
                return redirect
            return templates.TemplateResponse(request, template, await page_ctx(request, name))
        return _page

    page("/", "status.html", "status")
    page("/chat", "chat.html", "chat")
    page("/media", "media.html", "media")
    page("/credentials", "credentials.html", "credentials")
    page("/providers", "providers.html", "providers")
    page("/usage", "usage.html", "usage")
    page("/devices", "devices.html", "devices")
    page("/timers", "timers.html", "timers")
    page("/reminders", "reminders.html", "reminders")
    page("/routines", "routines.html", "routines")
    page("/calendar", "calendar.html", "calendar")
    page("/memory", "memory.html", "memory")
    page("/logs", "logs.html", "logs")
    page("/settings", "settings.html", "settings")
    page("/transcripts", "transcripts.html", "transcripts")
    page("/github", "github.html", "github")
    page("/mobile-app", "mobile_app.html", "mobile_app")

    # -- dedicated voice controller popup (owns remote-audio lease) ----------
    @app.get("/voice-controller", response_class=HTMLResponse)
    async def voice_controller_page(request: Request):
        redirect = await require_page(request)
        if redirect:
            return redirect
        sm = await session_mgr()
        token = request.cookies.get(COOKIE) or ""
        return templates.TemplateResponse(
            request, "voice_controller.html",
            {
                "request": request,
                "csrf": sm.csrf_for(token) if token else "",
                "app_version": APP_VERSION,
                "broadcast_request": bool(request.scope.get("jarvis.broadcast")),
                "home_url": "/dashboard" if request.scope.get("jarvis.broadcast") else "/",
            },
        )

    # -- live events (SSE) ---------------------------------------------------
    @app.get("/events")
    async def sse(request: Request):
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)

        async def stream():
            q = rt.bus.subscribe("*", maxsize=64)
            try:
                yield f"data: {json.dumps({'topic': 'state', **rt.state.snapshot()})}\n\n"
                while True:
                    try:
                        ev = await asyncio.wait_for(q.get(), timeout=25)
                        yield f"data: {json.dumps({'topic': ev.topic, **_jsonsafe(ev.data)})}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                rt.bus.unsubscribe(q)

        return StreamingResponse(stream(), media_type="text/event-stream")

    # -- state & health APIs ---------------------------------------------
    @app.get("/api/state")
    async def api_state(request: Request):
        err = await require_api(request)
        if err:
            return err
        health = await rt.db.fetchall("SELECT * FROM health ORDER BY component")
        eligible = 0
        if rt.gateway:
            eligible = await rt.gateway.rotation.eligible_count()
        retry_at = await rt.db.get_setting("quota_retry_at")
        return {
            "state": rt.state.snapshot(),
            "health": [dict(h) for h in health],
            "eligible_keys": eligible,
            "quota_retry_at": retry_at,
            "voice": {
                "available": bool(rt.audio and rt.audio.voice_available),
                "reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            },
            "keychain": rt.master.source,
            "uptime_seconds": int(time.time() - rt.started_at),
            "quiet": rt.quiet,
            "ringing": rt.ringing,
            "urls": dashboard_urls(),
        }

    # -- provider availability summary ------------------------------------
    @app.get("/api/providers/summary")
    async def api_providers_summary(request: Request):
        """Return safe (no secrets) availability status of every provider."""
        err = await require_api(request)
        if err:
            return err

        # Gemini keys
        creds = await rt.store.list()
        gemini_all = [c for c in creds if c.provider == "gemini"]
        gemini_eligible = 0
        if rt.gateway:
            gemini_eligible = await rt.gateway.rotation.eligible_count()
        gemini_failure = None
        for c in gemini_all:
            if c.failure_code:
                gemini_failure = c.failure_code
                break

        # OpenAI live
        openai_creds = [c for c in creds if c.provider == "openai"]
        openai_configured = bool(openai_creds)

        # Relay
        relay_creds = [c for c in creds if c.provider == "relay"]
        relay_url = (rt.settings.relay_url or "").strip()
        relay_configured = bool(relay_creds and relay_url)

        # Voice pipeline
        voice_available = bool(rt.audio and rt.audio.voice_available)
        voice_reason = (rt.audio.unavailable_reason if rt.audio else "cloud disabled") or ""

        # Typed chat provider
        typed_provider = rt.settings.typed_chat_provider
        typed_model = (
            rt.settings.openai_text_model
            if typed_provider == "openai"
            else rt.settings.relay_chat_model
        )

        # Remote voice endpoint (is any device currently connected?)
        remote_voice = rt.remote_voice.diagnostics() if rt.remote_voice else None

        # Media player
        media_available = rt.youtube_tools is not None
        google_calendar = (
            await rt.google_account.public_metadata()
            if rt.google_account is not None
            else {"configured": False, "connected": False, "status": "unavailable"}
        )
        spotify = (
            await rt.spotify_account.public_metadata()
            if rt.spotify_account is not None
            else {"configured": False, "connected": False, "status": "unavailable"}
        )

        return {
            "gemini": {
                "total_keys": len(gemini_all),
                "eligible_keys": gemini_eligible,
                "failure_reason": gemini_failure,
                "ok": gemini_eligible > 0,
            },
            "openai_live": {
                "configured": openai_configured,
                "ok": openai_configured,
            },
            "relay": {
                "configured": relay_configured,
                "address": relay_url if relay_url else None,
                "ok": relay_configured,
            },
            "voice_pipeline": {
                "available": voice_available,
                "reason": voice_reason,
                "ok": voice_available,
            },
            "typed_chat": {
                "provider": typed_provider,
                "model": typed_model,
                "ok": bool(
                    (typed_provider == "openai" and openai_configured)
                    or (typed_provider == "relay" and relay_configured)
                ),
            },
            "remote_mic": {
                "active": bool(remote_voice and remote_voice.get("connected")),
                "device": (remote_voice or {}).get("device"),
                "conversation": bool(remote_voice and remote_voice.get("conversation_active")),
            },
            "media_player": {
                "available": media_available,
                "ok": media_available,
            },
            "google_calendar": {
                **google_calendar,
                "ok": bool(
                    google_calendar.get("connected")
                    and not google_calendar.get("needs_reauthorization")
                    and google_calendar.get("status") == "connected"
                ),
            },
            "spotify": {
                **spotify,
                "ok": bool(
                    spotify.get("connected")
                    and not spotify.get("needs_reauthorization")
                    and spotify.get("status") == "connected"
                ),
            },
        }

    # -- Google Calendar connected account ----------------------------------
    google_oauth_handoffs: dict[str, tuple[float, str]] = {}
    spotify_oauth_handoffs: dict[str, tuple[float, str]] = {}

    def google_redirect_uri() -> str:
        return dashboard_urls()["local"] + "/api/calendar/oauth/callback"

    def calendar_unavailable() -> JSONResponse | None:
        if (
            rt.google_account is None
            or rt.google_calendar is None
            or rt.calendar is None
            or rt.calendar_scheduler is None
        ):
            return JSONResponse(
                {"error": "Google Calendar is unavailable"}, status_code=503
            )
        return None

    @app.get("/api/calendar/status")
    async def api_calendar_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        account = await rt.google_account.public_metadata()
        account["redirect_uri"] = google_redirect_uri()
        calendars: list[dict] = []
        if account["connected"] and not account["needs_reauthorization"]:
            try:
                calendars = await rt.google_calendar.calendars()
            except GoogleCalendarError:
                # The safe account health fields already explain whether a
                # reconnect is required. Cached events remain readable.
                calendars = []
                account = await rt.google_account.public_metadata()
                account["redirect_uri"] = google_redirect_uri()
        _, writable = await rt.google_account.selection()
        for item in calendars:
            item["default_write"] = item["id"] == writable
        return {
            "account": account,
            "calendars": calendars,
            "preferences": await rt.calendar_scheduler.get_preferences(),
        }

    @app.post("/api/calendar/oauth/start")
    async def api_calendar_oauth_start(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        if not is_loopback(request):
            return JSONResponse(
                {
                    "error": (
                        "Google setup must be started on the computer running Nexa. "
                        "Open the local dashboard there, connect Google, then return "
                        "to this device."
                    )
                },
                status_code=403,
            )
        try:
            body = await request.json()
        except Exception:
            body = {}
        client_id = str(body.get("client_id", "")).strip()
        client_secret = str(body.get("client_secret", "")).strip()
        if bool(client_id) != bool(client_secret):
            return JSONResponse(
                {"error": "both the OAuth client ID and secret are required"},
                status_code=400,
            )
        try:
            if client_id and client_secret:
                await rt.google_account.configure(client_id, client_secret)
            elif not (await rt.google_account.public_metadata())["configured"]:
                return JSONResponse(
                    {"error": "enter the Google OAuth client ID and secret first"},
                    status_code=400,
                )
            binding = secrets.token_urlsafe(32)
            authorization_url, _ = await rt.google_calendar.authorization_url(
                google_redirect_uri(), binding
            )
        except (ValueError, LookupError, GoogleCalendarError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        now = time.monotonic()
        for key, (expires, _) in list(google_oauth_handoffs.items()):
            if expires <= now:
                google_oauth_handoffs.pop(key, None)
        handoff = secrets.token_urlsafe(24)
        google_oauth_handoffs[handoff] = (now + 60, authorization_url)
        response = JSONResponse(
            {"authorization_url": f"/calendar/oauth/continue?handoff={handoff}"}
        )
        response.set_cookie(
            GOOGLE_OAUTH_COOKIE,
            binding,
            max_age=600,
            httponly=True,
            samesite="lax",
            secure=https_on,
        )
        return response

    @app.get("/calendar/oauth/continue")
    async def calendar_oauth_continue(request: Request):
        if not is_loopback(request):
            return HTMLResponse(
                "<h1>Finish setup on the Nexa computer</h1>"
                "<p>Google Calendar setup can only continue in the local browser.</p>",
                status_code=403,
            )
        handoff = str(request.query_params.get("handoff", ""))
        pending = google_oauth_handoffs.pop(handoff, None)
        if not pending or pending[0] <= time.monotonic():
            return HTMLResponse(
                "<h1>Google setup link expired</h1>"
                "<p>Return to Providers and start the connection again.</p>",
                status_code=400,
            )
        return RedirectResponse(pending[1], status_code=303)

    @app.get("/api/calendar/oauth/callback")
    async def api_calendar_oauth_callback(request: Request):
        """Google's browser redirect. State+PKCE+the short-lived Lax binding
        cookie authenticate this one callback; dashboard session contents and
        provider secrets are never put in the URL."""
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        if not is_loopback(request):
            return HTMLResponse(
                "<h1>Finish setup on the Nexa computer</h1>"
                "<p>Google Calendar authorization can only be completed in the "
                "local browser on the computer running Nexa.</p>",
                status_code=403,
            )
        state = str(request.query_params.get("state", ""))
        code = str(request.query_params.get("code", ""))
        binding = request.cookies.get(GOOGLE_OAUTH_COOKIE, "")
        if request.query_params.get("error"):
            if state and binding:
                try:
                    await rt.google_account.consume_pending(state, binding)
                except OAuthStateError:
                    pass
            response = RedirectResponse("/providers?google=cancelled", status_code=303)
            response.delete_cookie(GOOGLE_OAUTH_COOKIE)
            return response
        if not state or not code or not binding:
            return HTMLResponse(
                "<h1>Google Calendar was not connected</h1>"
                "<p>The authorization request is missing, expired, or was opened "
                "in a different browser. Return to Providers and try again.</p>",
                status_code=400,
            )
        try:
            await rt.google_calendar.exchange_code(
                code, state, binding, google_redirect_uri()
            )
            selected, _ = await rt.google_account.selection()
            for calendar_id in selected:
                await rt.google_calendar.sync(calendar_id)
            await rt.db.log("INFO", "calendar", "Google Calendar connected")
            rt.bus.publish("calendar_changed", action="connected")
        except (OAuthStateError, GoogleCalendarError, ValueError):
            response = RedirectResponse("/providers?google=error", status_code=303)
            response.delete_cookie(GOOGLE_OAUTH_COOKIE)
            return response
        response = RedirectResponse("/providers?google=connected", status_code=303)
        response.delete_cookie(GOOGLE_OAUTH_COOKIE)
        return response

    @app.post("/api/calendar/disconnect")
    async def api_calendar_disconnect(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        account = await rt.google_account.disconnect(retain_client_config=True)
        await rt.db.log("INFO", "calendar", "Google Calendar disconnected")
        rt.bus.publish("calendar_changed", action="disconnected")
        return {"account": account}

    # -- Spotify connected account -------------------------------------------
    def spotify_redirect_uri() -> str:
        return dashboard_urls()["local"] + "/api/spotify/oauth/callback"

    def spotify_unavailable() -> JSONResponse | None:
        if rt.spotify_account is None or rt.spotify is None:
            return JSONResponse({"error": "Spotify is unavailable"}, status_code=503)
        return None

    @app.get("/api/spotify/status")
    async def api_spotify_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = spotify_unavailable()
        if unavailable:
            return unavailable
        account = await rt.spotify_account.public_metadata()
        account["redirect_uri"] = spotify_redirect_uri()
        devices: list[dict] = []
        if account["connected"] and not account["needs_reauthorization"]:
            try:
                devices = await rt.spotify.devices()
            except SpotifyError:
                # Return the encrypted store's safe health fields. Device
                # discovery errors never disclose provider identifiers.
                account = await rt.spotify_account.public_metadata()
                account["redirect_uri"] = spotify_redirect_uri()
        return {
            "account": account,
            "devices": devices,
            "premium_required_for_playback": True,
        }

    @app.post("/api/spotify/oauth/start")
    async def api_spotify_oauth_start(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = spotify_unavailable()
        if unavailable:
            return unavailable
        if not is_loopback(request):
            return JSONResponse(
                {
                    "error": (
                        "Spotify setup must be started on the computer running Nexa. "
                        "Open the local dashboard there, connect Spotify, then return "
                        "to this device."
                    )
                },
                status_code=403,
            )
        try:
            body = await request.json()
        except Exception:
            body = {}
        client_id = str(body.get("client_id", "")).strip()
        client_secret = str(body.get("client_secret", "")).strip()
        if bool(client_id) != bool(client_secret):
            return JSONResponse(
                {"error": "both the OAuth client ID and secret are required"},
                status_code=400,
            )
        try:
            if client_id and client_secret:
                await rt.spotify_account.configure(client_id, client_secret)
            elif not (await rt.spotify_account.public_metadata())["configured"]:
                return JSONResponse(
                    {"error": "enter the Spotify OAuth client ID and secret first"},
                    status_code=400,
                )
            binding = secrets.token_urlsafe(32)
            authorization_url, _ = await rt.spotify.authorization_url(
                spotify_redirect_uri(), binding
            )
        except (ValueError, LookupError, SpotifyError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        now = time.monotonic()
        for key, (expires, _) in list(spotify_oauth_handoffs.items()):
            if expires <= now:
                spotify_oauth_handoffs.pop(key, None)
        handoff = secrets.token_urlsafe(24)
        spotify_oauth_handoffs[handoff] = (now + 60, authorization_url)
        response = JSONResponse(
            {"authorization_url": f"/spotify/oauth/continue?handoff={handoff}"}
        )
        response.set_cookie(
            SPOTIFY_OAUTH_COOKIE,
            binding,
            max_age=600,
            httponly=True,
            samesite="lax",
            secure=https_on,
        )
        return response

    @app.get("/spotify/oauth/continue")
    async def spotify_oauth_continue(request: Request):
        if not is_loopback(request):
            return HTMLResponse(
                "<h1>Finish setup on the Nexa computer</h1>"
                "<p>Spotify setup can only continue in the local browser.</p>",
                status_code=403,
            )
        handoff = str(request.query_params.get("handoff", ""))
        pending = spotify_oauth_handoffs.pop(handoff, None)
        if not pending or pending[0] <= time.monotonic():
            return HTMLResponse(
                "<h1>Spotify setup link expired</h1>"
                "<p>Return to Providers and start the connection again.</p>",
                status_code=400,
            )
        return RedirectResponse(pending[1], status_code=303)

    @app.get("/api/spotify/oauth/callback")
    async def api_spotify_oauth_callback(request: Request):
        unavailable = spotify_unavailable()
        if unavailable:
            return unavailable
        if not is_loopback(request):
            return HTMLResponse(
                "<h1>Finish setup on the Nexa computer</h1>"
                "<p>Spotify authorization can only be completed in the local "
                "browser on the computer running Nexa.</p>",
                status_code=403,
            )
        state = str(request.query_params.get("state", ""))
        code = str(request.query_params.get("code", ""))
        binding = request.cookies.get(SPOTIFY_OAUTH_COOKIE, "")
        if request.query_params.get("error"):
            if state and binding:
                try:
                    await rt.spotify_account.consume_pending(state, binding)
                except OAuthStateError:
                    pass
            response = RedirectResponse("/providers?spotify=cancelled", status_code=303)
            response.delete_cookie(SPOTIFY_OAUTH_COOKIE)
            return response
        if not state or not code or not binding:
            return HTMLResponse(
                "<h1>Spotify was not connected</h1>"
                "<p>The authorization request is missing, expired, or was opened "
                "in a different browser. Return to Providers and try again.</p>",
                status_code=400,
            )
        try:
            await rt.spotify.exchange_code(
                code, state, binding, spotify_redirect_uri()
            )
            await rt.db.log("INFO", "spotify", "Spotify connected")
            rt.bus.publish("music_changed", provider="spotify", action="connected")
        except (OAuthStateError, SpotifyError, ValueError):
            response = RedirectResponse("/providers?spotify=error", status_code=303)
            response.delete_cookie(SPOTIFY_OAUTH_COOKIE)
            return response
        response = RedirectResponse("/providers?spotify=connected", status_code=303)
        response.delete_cookie(SPOTIFY_OAUTH_COOKIE)
        return response

    @app.post("/api/spotify/disconnect")
    async def api_spotify_disconnect(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = spotify_unavailable()
        if unavailable:
            return unavailable
        account = await rt.spotify_account.disconnect(retain_client_config=True)
        await rt.db.log("INFO", "spotify", "Spotify disconnected")
        rt.bus.publish("music_changed", provider="spotify", action="disconnected")
        return {"account": account}

    @app.post("/api/calendar/calendars")
    async def api_calendar_select(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        readable = body.get("readable_ids")
        if not isinstance(readable, list):
            return JSONResponse(
                {"error": "readable_ids must be a list"}, status_code=400
            )
        try:
            await rt.google_calendar.select_calendars(
                readable, str(body.get("writable_id", "")).strip() or None
            )
            for calendar_id in readable:
                await rt.google_calendar.sync(str(calendar_id))
        except (GoogleCalendarError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        rt.bus.publish("calendar_changed", action="selection")
        return await api_calendar_status(request)

    @app.post("/api/calendar/sync")
    async def api_calendar_sync(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        selected, _ = await rt.google_account.selection()
        if not selected:
            return JSONResponse(
                {"error": "select at least one readable calendar"}, status_code=400
            )
        synced = 0
        try:
            for calendar_id in selected:
                await rt.google_calendar.sync(calendar_id)
                synced += 1
        except GoogleCalendarError as exc:
            return JSONResponse({"error": str(exc), "synced": synced}, status_code=502)
        rt.bus.publish("calendar_changed", action="sync")
        return {"ok": True, "synced": synced}

    @app.get("/api/calendar/events")
    async def api_calendar_events(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        try:
            days = int(request.query_params.get("days", "14"))
            limit = int(request.query_params.get("limit", "100"))
            return await rt.calendar.upcoming(days=days, limit=limit)
        except (TypeError, ValueError, CalendarToolError, GoogleCalendarError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/calendar/appointments/review")
    async def api_calendar_appointment_review(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        try:
            return await rt.calendar.review_appointment(
                title=str(body.get("title", "")),
                start_local=str(body.get("start_local", "")),
                duration_minutes=body.get("duration_minutes"),
                calendar_id=str(body.get("calendar_id", "")).strip() or None,
                timezone_name=str(body.get("timezone", "")).strip() or None,
            )
        except (CalendarToolError, GoogleCalendarError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/calendar/appointments/confirm")
    async def api_calendar_appointment_confirm(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        try:
            return await rt.calendar.confirm_appointment(
                str(body.get("draft_id", "")), body.get("confirmed") is True
            )
        except (CalendarToolError, GoogleCalendarError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/calendar/preferences")
    async def api_calendar_preferences(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = calendar_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        try:
            preferences = await rt.calendar_scheduler.set_combined_preferences(
                timezone_name=str(body.get("timezone", "")),
                meeting_alert_enabled=bool(body.get("meeting_alert_enabled")),
                meeting_lead_minutes=body.get("meeting_lead_minutes", 10),
                briefing_enabled=bool(body.get("briefing_enabled")),
                briefing_time=str(body.get("briefing_time", "")),
                weekdays=body.get("weekdays", []),
                sections=body.get("sections", []),
            )
        except (SchedulerError, TypeError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        rt.bus.publish("calendar_preferences_changed")
        return {"preferences": preferences}

    # -- selected-device YouTube player -----------------------------------
    @app.get("/api/media")
    async def api_media(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        return rt.youtube_tools.snapshot()

    @app.post("/api/media/claim")
    async def api_media_claim(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.claim(
                body.get("client_id"), body.get("label", ""), force=bool(body.get("force"))
            )
        except YouTubeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/media/release")
    async def api_media_release(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.release(body.get("client_id"))
        except YouTubeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/media/search")
    async def api_media_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "search_youtube", {
                "query": str(body.get("query", ""))[:160],
                "max_results": body.get("max_results", 5),
            }
        )
        return JSONResponse(result, status_code=400 if "error" in result else 200)

    @app.post("/api/media/control")
    async def api_media_control(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", "")).strip().lower()
        tool = {
            "play": "play_youtube",
            "resume": "play_youtube",
            "play_playlist": "play_playlist",
            "playlist": "play_playlist",
            "pause": "pause_youtube",
            "stop": "stop_youtube",
            "seek": "seek_youtube",
            "next": "next_youtube",
            "previous": "previous_youtube",
        }.get(action)
        if tool is None:
            return JSONResponse({"error": "unknown media action"}, status_code=400)
        if tool == "play_playlist":
            args = {
                "playlist_url": body.get("playlist_url", ""),
                "playlist_id": body.get("playlist_id", ""),
                "playlist_query": body.get("playlist_query", "") or body.get("query", ""),
                "title": body.get("title", ""),
            }
        else:
            args = {
                "video": body.get("video") or body.get("video_id") or "",
                "title": body.get("title", ""),
                "offset_seconds": body.get("offset_seconds"),
            }
        result = await rt.tools.dispatch("", tool, args)
        return JSONResponse(result, status_code=400 if "error" in result else 200)

    @app.post("/api/media/state")
    async def api_media_report(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.report(body.get("client_id"), body)
        except (YouTubeError, YouTubeAPIError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)

    @app.post("/api/media/host-open")
    async def api_media_host_open(request: Request):
        """Open the currently active canonical video in the host browser.

        Narrowly scoped fallback for embed error 101/150. Authenticated and
        CSRF-protected via require_api. Accepts NO url/host/query/command from
        the caller — only the client_id used to prove the caller is the current
        lease owner. The server re-derives the watch URL from its own active
        video id via canonical_watch_url(extract_video_id(...)).
        """
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return await rt.youtube_tools.host_browser_fallback(body.get("client_id"))
        except (YouTubeError, YouTubeAPIError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)

    # -- unified room-aware music --------------------------------------------
    def music_unavailable() -> JSONResponse | None:
        if rt.music is None or rt.local_music is None:
            return JSONResponse({"error": "music controls are unavailable"}, status_code=503)
        return None

    async def music_dispatch(name: str, args: dict) -> JSONResponse:
        result = await rt.tools.dispatch("", name, args)
        if "error" in result:
            return JSONResponse(result, status_code=400)
        if rt.music is not None:
            try:
                snapshot = await rt.music.snapshot(
                    str(args.get("room", "")).strip() or None
                )
                result = {**result, **snapshot}
            except (MusicError, LookupError, ValueError):
                pass
        return JSONResponse(result)

    @app.get("/api/music")
    async def api_music(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = music_unavailable()
        if unavailable:
            return unavailable
        try:
            return await rt.music.snapshot(
                str(request.query_params.get("room", "")).strip() or None
            )
        except (MusicError, SpotifyError, LocalMusicLibraryError, LookupError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/music/claim")
    async def api_music_claim(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media player is unavailable"}, status_code=503)
        body = await request.json()
        try:
            result = rt.youtube_tools.claim(
                body.get("client_id"), body.get("label", ""), force=bool(body.get("force"))
            )
            if rt.music is not None:
                await rt.music.player_claimed(result)
            return result
        except (MusicError, YouTubeError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/music/release")
    async def api_music_release(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media player is unavailable"}, status_code=503)
        body = await request.json()
        try:
            client_id = body.get("client_id")
            result = rt.youtube_tools.release(client_id)
            if rt.music is not None:
                await rt.music.player_released(client_id)
            return result
        except (MusicError, YouTubeError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/music/search")
    async def api_music_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch(
            "search_music",
            {
                "query": body.get("query", ""),
                "provider": body.get("provider", "auto"),
                "kind": body.get("kind", "any"),
                "max_results": body.get("max_results", 10),
            },
        )

    @app.post("/api/music/play")
    async def api_music_play(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch(
            "play_music",
            {
                "query": body.get("query", ""),
                "item_id": body.get("item_id", ""),
                "provider": body.get("provider", "auto"),
                "room": body.get("room", ""),
                "favorites": bool(body.get("favorites")),
                "playlist_name": body.get("playlist_name", ""),
                "provider_playlist_id": body.get("provider_playlist_id", ""),
            },
        )

    @app.post("/api/music/control")
    async def api_music_control(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", "")).strip().lower()
        room = body.get("room", "")
        if action == "seek":
            return await music_dispatch(
                "seek_music",
                {"offset_seconds": body.get("offset_seconds"), "room": room},
            )
        if action in {"volume", "set_volume", "adjust_volume"}:
            return await music_dispatch(
                "set_music_volume",
                {
                    "percentage": body.get("percentage"),
                    "delta": body.get("delta"),
                    "room": room,
                },
            )
        return await music_dispatch("control_music", {"action": action, "room": room})

    @app.post("/api/music/report")
    async def api_music_report(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = music_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        try:
            outcome = await rt.music.report_local(body.get("client_id"), body)
            snapshot = await rt.music.snapshot(
                str(body.get("room_id", "")).strip() or None
            )
            return {**({"outcome": outcome} if isinstance(outcome, dict) else {}), **snapshot}
        except (MusicError, LocalMusicLibraryError, LookupError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)

    @app.post("/api/music/queue")
    async def api_music_queue(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch("manage_music_queue", dict(body))

    @app.post("/api/music/favorites")
    async def api_music_favorites(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch("manage_music_favorites", dict(body))

    @app.post("/api/music/playlists")
    async def api_music_playlists(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch("manage_music_playlist", dict(body))

    @app.post("/api/music/rooms")
    async def api_music_rooms(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        return await music_dispatch("configure_music_room", dict(body))

    @app.post("/api/music/library")
    async def api_music_library(request: Request):
        err = await require_api(request)
        if err:
            return err
        unavailable = music_unavailable()
        if unavailable:
            return unavailable
        body = await request.json()
        action = str(body.get("action", "list")).strip().lower()
        try:
            if action in {"list", "roots"}:
                return {"roots": await rt.local_music.list_roots()}
            if action in {"tracks", "browse"}:
                return {
                    "tracks": await rt.local_music.list(
                        str(body.get("root_id", "")).strip() or None,
                        offset=body.get("offset", 0),
                        limit=body.get("limit", 100),
                    )
                }
            if action == "search":
                return {
                    "tracks": await rt.local_music.search(
                        str(body.get("query", "")),
                        root_id=str(body.get("root_id", "")).strip() or None,
                        limit=body.get("limit", 100),
                    )
                }
            if not is_loopback(request):
                return JSONResponse(
                    {
                        "error": (
                            "Local music folders can only be changed on the "
                            "computer running Nexa."
                        )
                    },
                    status_code=403,
                )
            if action in {"add", "add_root", "configure"}:
                root = await rt.local_music.setup_root(
                    str(body.get("path", "")), str(body.get("label", "")).strip() or None
                )
                scan = await rt.local_music.scan(root["id"])
                rt.bus.publish("music_library_changed", action="scan", root_id=root["id"])
                return {"root": root, "scan": scan}
            root_id = str(body.get("root_id", "")).strip()
            if action == "scan":
                if root_id:
                    results = [await rt.local_music.scan(root_id)]
                else:
                    results = [
                        await rt.local_music.scan(root["id"])
                        for root in await rt.local_music.list_roots()
                    ]
                rt.bus.publish("music_library_changed", action="scan", root_id=root_id)
                return {"scan": results[0] if len(results) == 1 else results}
            if action in {"delete", "remove", "remove_root"}:
                await rt.local_music.delete_root(root_id)
                rt.bus.publish("music_library_changed", action="delete", root_id=root_id)
                return {"deleted": True, "root_id": root_id}
            raise LocalMusicLibraryError("unknown local library action")
        except (LocalMusicLibraryError, LookupError, TypeError, ValueError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    def _range_bounds(value: str, size: int) -> tuple[int, int] | None:
        if not value:
            return None
        if not value.startswith("bytes=") or "," in value:
            raise ValueError("invalid byte range")
        raw = value[6:].strip()
        if "-" not in raw:
            raise ValueError("invalid byte range")
        first, last = raw.split("-", 1)
        if not first:
            length = int(last)
            if length <= 0:
                raise ValueError("invalid byte range")
            start = max(0, size - length)
            return start, size - 1
        start = int(first)
        end = int(last) if last else size - 1
        if start < 0 or start >= size or end < start:
            raise ValueError("invalid byte range")
        return start, min(end, size - 1)

    @app.get("/api/music/local/{item_id}")
    async def api_music_local_stream(request: Request, item_id: str):
        err = await require_api(request)
        if err:
            return err
        unavailable = music_unavailable()
        if unavailable:
            return unavailable
        source = None
        try:
            source, track = await rt.local_music.open_for_stream(item_id)
            size = int(track["size"])
        except (LocalMusicLibraryError, LookupError, OSError, ValueError):
            return JSONResponse({"error": "local track is unavailable"}, status_code=404)
        try:
            bounds = _range_bounds(request.headers.get("range", ""), size)
        except (TypeError, ValueError):
            source.close()
            return JSONResponse(
                {"error": "requested byte range is not satisfiable"},
                status_code=416,
                headers={"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"},
            )

        start, end = bounds or (0, size - 1)
        length = end - start + 1

        def chunks():
            remaining = length
            try:
                source.seek(start)
                while remaining:
                    block = source.read(min(64 * 1024, remaining))
                    if not block:
                        break
                    remaining -= len(block)
                    yield block
            finally:
                source.close()

        headers = {
            "Accept-Ranges": "bytes",
            "Content-Length": str(length),
            "Cache-Control": "private, no-store",
            "X-Content-Type-Options": "nosniff",
        }
        status_code = 200
        if bounds:
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
            status_code = 206
        return StreamingResponse(
            chunks(),
            status_code=status_code,
            media_type=str(track.get("mime") or "application/octet-stream"),
            headers=headers,
        )

    # -- YouTube companion extension pairing/bridge ------------------------
    #
    # The companion extension is opt-in and local-only.  Pairing is managed
    # here (authenticated + CSRF-protected + loopback-only for mutations); the
    # extension itself connects over the loopback-only /ws/companion socket and
    # authenticates with the bridge secret it received on first pairing.
    def companion_bridge_base() -> dict:
        """Bridge address the extension should use.

        The dedicated loopback bridge is always plain ws://, because a browser
        extension cannot approve the dashboard's self-signed certificate: a
        wss:// socket opened in its service worker just fails with no way for
        the owner to accept the certificate.  Only if that bridge is not
        running do we fall back to the dashboard's own scheme, and then we say
        plainly that TLS will block the extension.
        """
        port = getattr(rt, "companion_bridge_port", None)
        if port:
            return {"bridge_base": f"ws://127.0.0.1:{int(port)}", "bridge_tls_blocked": False}
        scheme = "wss" if https_on else "ws"
        return {
            "bridge_base": f"{scheme}://127.0.0.1:{rt.settings.dashboard_port}",
            "bridge_tls_blocked": bool(https_on),
        }

    @app.get("/api/companion/status")
    async def api_companion_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.companion is None:
            return JSONResponse({"error": "companion is unavailable"}, status_code=503)
        return {
            "paired": await rt.companion.is_paired(),
            "pending_pairing": await rt.companion.has_pending_pairing(),
            **companion_bridge_base(),
            **rt.companion.status(),
        }

    @app.post("/api/companion/pair")
    async def api_companion_pair(request: Request):
        """Issue a one-time pairing token (shown once).  Loopback-only.

        Pairing must be initiated on the computer running Nexa so a LAN device
        can never bootstrap the companion bridge.
        """
        err = await require_api(request)
        if err:
            return err
        if rt.companion is None:
            return JSONResponse({"error": "companion is unavailable"}, status_code=503)
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Companion pairing must be started on the computer running Nexa."},
                status_code=403,
            )
        token = await rt.companion.issue_pairing_token()
        # The plaintext token is returned exactly once; it is stored only as a
        # salted hash server-side.
        return {"pairing_token": token, **companion_bridge_base()}

    @app.post("/api/companion/rotate")
    async def api_companion_rotate(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.companion is None:
            return JSONResponse({"error": "companion is unavailable"}, status_code=503)
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Companion pairing must be managed on the computer running Nexa."},
                status_code=403,
            )
        token = await rt.companion.rotate()
        return {"pairing_token": token, **companion_bridge_base()}

    @app.post("/api/companion/revoke")
    async def api_companion_revoke(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.companion is None:
            return JSONResponse({"error": "companion is unavailable"}, status_code=503)
        await rt.companion.revoke()
        return {"ok": True, "paired": False}

    @app.websocket("/ws/companion")
    async def ws_companion(ws: WebSocket):
        """Loopback-only companion protocol socket (dashboard port).

        Kept for plain-HTTP dashboards and for extensions paired before the
        dedicated bridge port existed.  The dedicated loopback bridge server is
        the preferred address because it is never TLS.

        Security (identical on both ports, one shared handler):
          * Rejected before upgrade unless the client is on a loopback address,
            regardless of dashboard_host, so no LAN device can ever reach it.
          * The socket authenticates via the bridge protocol (bridge secret or a
            one-time pairing token) before any command/state is honoured.  No
            dashboard session cookie is required because the extension is a
            different origin than the dashboard page; loopback + bridge-secret
            auth is the trust boundary.
        """
        await serve_companion_socket(rt, ws)

    # -- credentials -------------------------------------------------------
    @app.get("/api/credentials")
    async def api_credentials(request: Request):
        err = await require_api(request)
        if err:
            return err
        creds = await rt.store.list()
        groups: dict[str, dict] = {}
        for c in creds:
            if c.provider != "gemini":
                continue
            g = groups.setdefault(
                c.project_fingerprint,
                {"fingerprint": c.project_fingerprint, "label": c.project_label or "Ungrouped key", "keys": [], "exhausted_until": None},
            )
            g["keys"].append(c.public())
            if c.status == "exhausted" and c.retry_after:
                cur = g["exhausted_until"]
                iso_ra = c.retry_after.isoformat()
                g["exhausted_until"] = max(cur, iso_ra) if cur else iso_ra
        govee = [c.public() for c in creds if c.provider == "govee"]
        youtube_keys = [c.public() for c in creds if c.provider == "youtube"]
        openai_keys = [c.public() for c in creds if c.provider == "openai"]
        relay_keys = [c.public() for c in creds if c.provider == "relay"]
        return {"projects": list(groups.values()), "govee": govee,
                "youtube": youtube_keys,
                "openai": openai_keys, "relay": relay_keys}

    @app.post("/api/credentials")
    async def api_add_credential(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        provider = str(body.get("provider", "gemini")).lower()
        secret = str(body.get("secret", "")).strip()
        label = str(body.get("project_label", "")).strip()[:60]
        if provider not in ("gemini", "govee", "openai", "relay", "youtube"):
            return JSONResponse({"error": "unsupported provider"}, status_code=400)
        if len(secret) < 8 or len(secret) > 300 or any(ch.isspace() for ch in secret):
            return JSONResponse({"error": "that doesn't look like a valid key"}, status_code=400)

        warning = ""
        if provider == "gemini":
            try:
                await validate_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "Google rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "govee":
            try:
                await GoveeClient(secret).list_devices()
            except GoveeError as exc:
                if "rejected" in str(exc):
                    return JSONResponse({"error": "Govee rejected this key."}, status_code=400)
                warning = "saved without live validation (Govee unreachable)"
        elif provider == "openai":
            try:
                await validate_openai_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "OpenAI rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if relay_url:
                try:
                    await RelayClient(relay_url, secret).health()
                except RelayError as exc:
                    if "password" in str(exc):
                        return JSONResponse({"error": str(exc)}, status_code=400)
                    warning = f"saved without live validation ({exc})"
            else:
                warning = ("saved; set the relay address in Settings -> Brain "
                           "so it can be checked")
        elif provider == "youtube":
            try:
                await YouTubeClient(secret).validate_key()
            except YouTubeAPIError as exc:
                if exc.code == "invalid_key":
                    return JSONResponse({"error": str(exc)}, status_code=400)
                warning = f"saved without live validation ({exc})"

        cred = await rt.store.add(provider, secret, project_label=label)
        if provider in ("gemini", "youtube") and not warning:
            await rt.store.mark_validated(cred.id)
        rt.bus.publish("credentials_changed", added=cred.id)
        await rt.db.log("INFO", "credentials", f"added {provider} key {cred.masked_suffix}")
        # NOTE: the active connection is deliberately left untouched.
        return {"ok": True, "credential": cred.public(), "warning": warning}

    @app.post("/api/credentials/{cred_id}/action")
    async def api_credential_action(cred_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", ""))
        cred = await rt.store.get(cred_id)
        if cred is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        if action == "disable":
            await rt.store.set_status(cred_id, "disabled")
        elif action == "enable":
            await rt.store.set_status(cred_id, "standby")
        elif action == "make_active":
            if rt.gateway:
                await rt.gateway.rotation.promote(cred_id)
                rt.gateway.set_preferred(cred_id)
            else:
                await rt.store.set_status(cred_id, "active")
        elif action == "delete":
            await rt.store.remove(cred_id)
        elif action == "validate" and cred.provider == "gemini":
            try:
                await validate_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "openai":
            try:
                await validate_openai_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if not relay_url:
                return {"ok": False, "result": "set the relay address in Settings -> Brain first"}
            try:
                await RelayClient(relay_url, await rt.store.get_secret(cred_id)).health()
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except RelayError as exc:
                if "password" in str(exc):
                    await rt.store.set_status(cred_id, "invalid", "invalid")
                return {"ok": False, "result": str(exc)}
        elif action == "validate" and cred.provider == "youtube":
            try:
                await YouTubeClient(await rt.store.get_secret(cred_id)).validate_key()
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except YouTubeAPIError as exc:
                if exc.code == "invalid_key":
                    await rt.store.set_status(cred_id, "invalid", "invalid")
                return {"ok": False, "result": str(exc)}
        else:
            return JSONResponse({"error": "unknown action"}, status_code=400)
        rt.bus.publish("credentials_changed", id=cred_id, action=action)
        await rt.db.log("INFO", "credentials", f"{action} on {cred.masked_suffix}")
        return {"ok": True}

    # -- timers ---------------------------------------------------------
    @app.get("/api/timers")
    async def api_timers(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {"timers": await rt.timers.list_timers()}

    @app.post("/api/timers")
    async def api_add_timer(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "start_timer",
            {"duration_seconds": body.get("duration_seconds"), "label": body.get("label", ""), "confirmed": True},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/timers/{timer_id}/{action}")
    async def api_timer_action(timer_id: str, action: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if action not in ("cancel", "pause", "resume"):
            return JSONResponse({"error": "unknown action"}, status_code=400)
        result = await rt.tools.dispatch("", f"{action}_timer", {"timer_id": timer_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- reminders & alarms -------------------------------------------------
    @app.get("/api/reminders")
    async def api_reminders(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {
            "reminders": await rt.reminders.list_reminders(include_recent=True),
            "ringing": rt.ringing,
        }

    @app.post("/api/reminders")
    async def api_add_reminder(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        time_str = str(body.get("time", "")).strip()   # "HH:MM", 24h
        date_str = str(body.get("date", "")).strip()   # optional "YYYY-MM-DD"
        try:
            hh, mm = (int(x) for x in time_str.split(":")[:2])
            if not (0 <= hh <= 23 and 0 <= mm <= 59):
                raise ValueError
        except ValueError:
            return JSONResponse({"error": "pick a time first"}, status_code=400)
        if date_str:
            at_local = f"{date_str}T{hh:02d}:{mm:02d}"
        else:
            now = datetime.now().astimezone()
            local = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if local <= now:
                local += timedelta(days=1)  # next time the clock shows it
            at_local = local.strftime("%Y-%m-%dT%H:%M")
        result = await rt.tools.dispatch(
            "", "set_reminder",
            {"message": str(body.get("message", "")),
             "kind": str(body.get("kind", "reminder")), "at_local": at_local},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/reminders/dismiss")
    async def api_dismiss_ring(request: Request):
        """Stop a ringing alarm/reminder and clear the persisted ring state.
        Idempotent: safe to call even when nothing is ringing."""
        err = await require_api(request)
        if err:
            return err
        dismissed = await rt.dismiss_ring()
        return {"ok": True, "dismissed": dismissed}

    @app.post("/api/reminders/snooze")
    async def api_snooze_ring(request: Request):
        """Snooze the currently ringing alarm/reminder.

        Optional JSON body: {"minutes": N}  (default: 10 minutes).
        The snooze deadline is persisted to DB so a restart resumes the wait.
        Idempotent: returns ok=True even if nothing is currently ringing."""
        err = await require_api(request)
        if err:
            return err
        body: dict = {}
        try:
            body = await request.json()
        except Exception:
            pass
        minutes = body.get("minutes")
        if minutes is not None:
            try:
                minutes = int(minutes)
            except (TypeError, ValueError):
                return JSONResponse({"error": "minutes must be an integer"}, status_code=400)
        snoozed = await rt.snooze_ring(minutes=minutes)
        return {"ok": True, "snoozed": snoozed}

    @app.post("/api/reminders/{reminder_id}/cancel")
    async def api_cancel_reminder(reminder_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        result = await rt.tools.dispatch("", "cancel_reminder", {"ref": reminder_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- bounded user routines -----------------------------------------------
    def routine_error(exc: RoutineError) -> JSONResponse:
        message = str(exc)
        conflict = "version conflict" in message or "already running" in message
        return JSONResponse({"error": message}, status_code=409 if conflict else 400)

    @app.get("/api/routines/catalog")
    async def api_routine_catalog(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        return {
            "actions": rt.routines.catalog_public(),
            "default_timezone": rt.routines.default_timezone,
            "weekdays": [
                {"value": 0, "label": "Mon"},
                {"value": 1, "label": "Tue"},
                {"value": 2, "label": "Wed"},
                {"value": 3, "label": "Thu"},
                {"value": 4, "label": "Fri"},
                {"value": 5, "label": "Sat"},
                {"value": 6, "label": "Sun"},
            ],
        }

    @app.get("/api/routines/templates")
    async def api_routine_templates(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        return {"templates": rt.routines.templates()}

    @app.post("/api/routines/templates/{template_id}")
    async def api_routine_template_create(template_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            return JSONResponse(
                {"routine": await rt.routines.create_from_template(template_id)},
                status_code=201,
            )
        except RoutineError as exc:
            return routine_error(exc)

    @app.get("/api/routines")
    async def api_routines(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        return {
            "routines": await rt.routines.list_routines(),
            "recent_runs": await rt.routines.list_runs(limit=50),
        }

    @app.post("/api/routines")
    async def api_routine_create(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            body = await request.json()
            return JSONResponse(
                {"routine": await rt.routines.create_routine(body)},
                status_code=201,
            )
        except RoutineError as exc:
            return routine_error(exc)

    @app.post("/api/routines/validate")
    async def api_routine_validate(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            definition = rt.routines.validate(await request.json())
            return {"valid": True, "errors": [], "definition": definition}
        except RoutineError as exc:
            return {"valid": False, "errors": [str(exc)]}

    @app.get("/api/routines/{routine_id}")
    async def api_routine_detail(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            return {
                "routine": await rt.routines.get_routine(routine_id),
                "runs": await rt.routines.list_runs(routine_id=routine_id, limit=50),
            }
        except RoutineError as exc:
            return routine_error(exc)

    @app.put("/api/routines/{routine_id}")
    async def api_routine_update(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        body = dict(await request.json())
        expected_version = body.pop("expected_version", None)
        try:
            return {
                "routine": await rt.routines.update_routine(
                    routine_id, body, expected_version=expected_version
                )
            }
        except RoutineError as exc:
            return routine_error(exc)

    @app.post("/api/routines/{routine_id}/duplicate")
    async def api_routine_duplicate(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return JSONResponse(
                {
                    "routine": await rt.routines.duplicate_routine(
                        routine_id, str(body.get("name", "")).strip() or None
                    )
                },
                status_code=201,
            )
        except RoutineError as exc:
            return routine_error(exc)

    @app.post("/api/routines/{routine_id}/enable")
    async def api_routine_enable(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return {
                "routine": await rt.routines.set_enabled(
                    routine_id, body.get("enabled")
                )
            }
        except RoutineError as exc:
            return routine_error(exc)

    @app.post("/api/routines/{routine_id}/test")
    async def api_routine_test(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        return await rt.routines.validate_routine(routine_id)

    @app.post("/api/routines/{routine_id}/run")
    async def api_routine_run(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            run = await rt.routines.run(routine_id, source="dashboard")
            return {"run": await rt.routines.get_run(run["run_id"])}
        except RoutineError as exc:
            return routine_error(exc)

    @app.delete("/api/routines/{routine_id}")
    async def api_routine_delete(routine_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.routines is None:
            return JSONResponse({"error": "routines are unavailable"}, status_code=503)
        try:
            return await rt.routines.delete_routine(routine_id)
        except RoutineError as exc:
            return routine_error(exc)

    # -- weather & quiet mode -------------------------------------------------
    @app.get("/api/weather")
    async def api_weather(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            return await rt.weather_tool.get(str(request.query_params.get("day", "today")))
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.get("/api/location/search")
    async def api_location_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            results = await rt.weather_tool.client.geocode(str(request.query_params.get("q", "")))
            return {"results": results}
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/quiet")
    async def api_quiet(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_quiet(bool(body.get("quiet")))
        return {"ok": True, "quiet": rt.quiet}

    # -- devices -----------------------------------------------------------
    @app.get("/api/devices")
    async def api_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            devices = await rt.tools.devices(refresh=bool(request.query_params.get("refresh")))
            return {"devices": devices}
        except GoveeError as exc:
            return {"devices": [], "error": str(exc)}

    # -- LG TV (optional local webOS control) --------------------------------
    # All TV routes need an authenticated session + CSRF (require_api), which
    # can only exist after the admin password is set -- so the no-password
    # first-run window can never reach pairing.  Responses never contain the
    # pairing key or the MAC address (only booleans like wol_ready).
    def _tv_manager():
        if rt.tv is None:
            return None, JSONResponse({"error": "TV control is not available"}, status_code=503)
        return rt.tv, None

    @app.get("/api/tv")
    async def api_tv(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        return tv.snapshot()

    @app.post("/api/tv/refresh")
    async def api_tv_refresh(request: Request):
        """A real health check / reconnect attempt (no page reload): probes a
        live connection or cuts the reconnect backoff short, then returns the
        resulting snapshot.  An offline TV is a state, not an error, so this
        never 4xxes for one."""
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        return await tv.refresh()

    @app.post("/api/tv/config")
    async def api_tv_config(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        body = await request.json()
        kwargs: dict = {}
        if "name" in body:
            kwargs["name"] = str(body.get("name", ""))[:80]
        if "host" in body:
            kwargs["host"] = str(body.get("host", ""))[:253]
        if "mac" in body:
            kwargs["mac"] = str(body.get("mac", ""))[:40]
        if "enabled" in body:
            kwargs["enabled"] = bool(body.get("enabled"))
        try:
            return await tv.configure(**kwargs)
        except WebOSTVError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/tv/discover")
    async def api_tv_discover(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        try:
            return {"tvs": await tv.discover()}
        except WebOSTVError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/tv/pair")
    async def api_tv_pair(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        try:
            # returns immediately; the UI polls /api/tv for pairing progress
            # while the user approves the prompt on the TV screen
            return await tv.start_pairing()
        except WebOSTVError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/tv/unpair")
    async def api_tv_unpair(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        return await tv.unpair()

    @app.get("/api/tv/apps")
    async def api_tv_apps(request: Request):
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        try:
            return tv.search_apps(str(request.query_params.get("query", ""))[:80])
        except WebOSTVError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/tv/command")
    async def api_tv_command(request: Request):
        """Bounded remote actions -- the same narrow surface the voice tools
        use.  There is deliberately no endpoint for raw webOS URIs."""
        err = await require_api(request)
        if err:
            return err
        tv, unavailable = _tv_manager()
        if unavailable:
            return unavailable
        body = await request.json()
        action = str(body.get("action", "")).strip().lower()
        try:
            if action == "power_on":
                return await tv.power_on()
            if action == "power_off":
                return await tv.power_off()
            if action == "volume_set":
                return await tv.set_volume(percentage=body.get("percentage"))
            if action == "volume_delta":
                return await tv.set_volume(delta=body.get("delta"))
            if action == "mute":
                return await tv.set_mute(True)
            if action == "unmute":
                return await tv.set_mute(False)
            if action == "media":
                return await tv.media(str(body.get("value", "")))
            if action == "button":
                return await tv.button(str(body.get("value", "")))
            if action == "type_text":
                # The typed text is validated and bounded by the manager and is
                # never logged or persisted anywhere on the way through.  The
                # browser composer sends {"action": "type_text", "text": ...,
                # "submit": ..., "youtube_grid_ready": ...}.  The final flag
                # is a one-shot user confirmation, not inferred server-side.
                return await tv.type_text(
                    str(body.get("text", "")),
                    submit=bool(body.get("submit")),
                    youtube_grid_ready=bool(body.get("youtube_grid_ready")),
                )
            if action == "input":
                return await tv.set_input(str(body.get("value", "")))
            if action == "launch":
                return await tv.launch_app(str(body.get("value", "")))
            if action == "refresh_apps":
                return await tv.refresh_apps()
            return JSONResponse({"error": "unknown TV action"}, status_code=400)
        except WebOSTVError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    # -- local command box -------------------------------------------------
    @app.post("/api/command")
    async def api_command(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        text = str(body.get("text", ""))[:200]
        cmd = parse_command(text)
        if cmd is None and rt.routines is not None:
            routine = await rt.routines.resolve_command(text)
            if routine is not None:
                cmd = {
                    "tool": "run_routine",
                    "args": {
                        "routine": routine["routine_id"],
                        "source": "dashboard_command",
                    },
                }
        if cmd is None:
            return JSONResponse(
                {
                    "error": (
                        "Not in the local grammar. Try: 'set a timer for ten minutes' "
                        "or 'run <routine name>'."
                    )
                },
                status_code=400,
            )
        result = await rt.tools.dispatch("", cmd["tool"], cmd["args"])
        return {"command": cmd, "result": result}

    # -- typed chat -------------------------------------------------------
    @app.get("/api/chat/conversations")
    async def api_chat_conversations(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        try:
            limit = int(request.query_params.get("limit", "100"))
        except ValueError:
            limit = 100
        return {"conversations": await rt.text_chat.list_conversations(limit)}

    @app.post("/api/chat/conversations")
    async def api_chat_conversation_create(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        body = await request.json()
        try:
            conversation = await rt.text_chat.create_conversation(str(body.get("title", "")))
            return JSONResponse({"conversation": conversation}, status_code=201)
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.get("/api/chat/conversations/{conversation_id}")
    async def api_chat_conversation_get(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        conversation = await rt.text_chat.get_conversation(conversation_id)
        if conversation is None:
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"conversation": conversation}

    @app.post("/api/chat/conversations/{conversation_id}/rename")
    async def api_chat_conversation_rename(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        body = await request.json()
        try:
            conversation = await rt.text_chat.rename_conversation(
                conversation_id, str(body.get("title", ""))
            )
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        if conversation is None:
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"conversation": conversation}

    @app.delete("/api/chat/conversations/{conversation_id}")
    async def api_chat_conversation_delete(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        if not await rt.text_chat.delete_conversation(conversation_id):
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"ok": True}

    async def _start_chat_turn(request: Request, forced_conversation_id: str | None = None):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)

        attachments = []
        try:
            content_type = request.headers.get("content-type", "").lower()
            if content_type.startswith("multipart/form-data"):
                # Reject a clearly oversized body before the multipart parser
                # spools it. Chunked bodies are still bounded while each file
                # is read below and again by the service's total-size check.
                try:
                    content_length = int(request.headers.get("content-length", "0") or 0)
                except ValueError:
                    content_length = 0
                if content_length > 13 * 1024 * 1024:
                    return JSONResponse(
                        {"error": "Images in one message can total at most 12 MB."},
                        status_code=413,
                    )
                form = await request.form()
                text = str(form.get("text", ""))
                conversation_id = (
                    forced_conversation_id or str(form.get("conversation_id", "")) or None
                )
                request_id = str(form.get("request_id", "")) or request.headers.get("idempotency-key")
                uploads = [*form.getlist("images"), *form.getlist("image")]
                if len(uploads) > 4:
                    return JSONResponse(
                        {"error": "Attach at most four images to one message."},
                        status_code=400,
                    )
                raw_files = []
                total_image_bytes = 0
                for upload in uploads:
                    if not hasattr(upload, "read"):
                        continue
                    data = await upload.read(8 * 1024 * 1024 + 1)
                    total_image_bytes += len(data)
                    if total_image_bytes > 12 * 1024 * 1024:
                        return JSONResponse(
                            {"error": "Images in one message can total at most 12 MB."},
                            status_code=413,
                        )
                    raw_files.append((
                        str(getattr(upload, "filename", "") or "image"),
                        str(getattr(upload, "content_type", "") or ""),
                        data,
                    ))
                attachments = await rt.text_chat.store_attachments(raw_files)
            else:
                body = await request.json()
                text = str(body.get("text", ""))
                conversation_id = (
                    forced_conversation_id or str(body.get("conversation_id", "")) or None
                )
                request_id = str(body.get("request_id", "")) or request.headers.get("idempotency-key")

            turn = await rt.text_chat.start_turn(
                text, conversation_id, request_id, attachments
            )
            return JSONResponse(turn, status_code=202)
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/chat/turns")
    async def api_chat_turn_create(request: Request):
        return await _start_chat_turn(request)

    @app.post("/api/chat/conversations/{conversation_id}/turns")
    async def api_chat_conversation_turn_create(request: Request, conversation_id: str):
        return await _start_chat_turn(request, conversation_id)

    @app.get("/api/chat/conversations/{conversation_id}/turns/{request_id}")
    async def api_chat_turn_get(request: Request, conversation_id: str, request_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        turn = await rt.text_chat.get_turn(conversation_id, request_id)
        if turn is None:
            return JSONResponse({"error": "chat request not found"}, status_code=404)
        return turn

    @app.get("/api/chat/attachments/{attachment_id}")
    async def api_chat_attachment(request: Request, attachment_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        found = await rt.text_chat.attachment_file(attachment_id)
        if found is None:
            return JSONResponse({"error": "image not found"}, status_code=404)
        path, mime_type = found
        return FileResponse(
            path,
            media_type=mime_type,
            headers={
                "Cache-Control": "private, max-age=3600",
                "Content-Disposition": "inline",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.post("/api/chat")
    async def api_chat(request: Request):
        """Compatibility endpoint; new clients use the durable turn API."""
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        try:
            return await rt.text_chat.ask(
                str(body.get("text", "")),
                str(body.get("conversation_id", "")) or None,
            )
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/chat/reset")
    async def api_chat_reset(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if rt.text_chat is not None:
            await rt.text_chat.clear(str(body.get("conversation_id", "")) or None)
        return {"ok": True}

    # -- usage & logs ---------------------------------------------------------
    @app.get("/api/usage")
    async def api_usage(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT u.ts, u.event, u.detail, c.masked_suffix, c.project_label "
            "FROM usage_log u LEFT JOIN credentials c ON c.id = u.credential_id "
            "ORDER BY u.id DESC LIMIT 200"
        )
        return {"usage": [dict(r) for r in rows]}

    @app.get("/api/logs")
    async def api_logs(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall("SELECT * FROM events_log ORDER BY id DESC LIMIT 300")
        return {"logs": [dict(r) for r in rows]}

    # -- settings & controls -----------------------------------------------
    @app.post("/api/mute")
    async def api_mute(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_muted(bool(body.get("muted")))
        return {"ok": True, "muted": rt.state.muted}

    def expert_config() -> dict:
        return {
            "auto_use": bool(rt.settings.expert_auto_use),
            "reasoning": rt.settings.expert_reasoning,
            "enabled_models_empty_means": "all_discovered",
            "providers": {
                "chatgpt": {
                    "enabled": bool(rt.settings.expert_chatgpt_enabled),
                    "preferred_model": rt.settings.expert_chatgpt_model,
                    "enabled_models": list(rt.settings.expert_chatgpt_models),
                },
                "claude": {
                    "enabled": bool(rt.settings.expert_claude_enabled),
                    "preferred_model": rt.settings.expert_claude_model,
                    "enabled_models": list(rt.settings.expert_claude_models),
                },
            },
        }

    @app.get("/api/experts")
    async def api_experts(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            catalog = await rt.experts.catalog()
            return {
                "config": expert_config(),
                "catalog": catalog["providers"],
                "model_policy": {"empty_enabled_models": "all_discovered"},
            }
        except (RelayError, ExpertError) as exc:
            # Configuration remains inspectable while Relay is unavailable;
            # the error is sanitized and no credential is returned.
            return {
                "config": expert_config(),
                "catalog": {"chatgpt": [], "claude": []},
                "model_policy": {"empty_enabled_models": "all_discovered"},
                "catalog_error": str(exc) if isinstance(exc, ExpertError)
                else "Relay catalog unavailable",
            }
        except Exception:
            return {
                "config": expert_config(),
                "catalog": {"chatgpt": [], "claude": []},
                "model_policy": {"empty_enabled_models": "all_discovered"},
                "catalog_error": "Relay catalog unavailable",
            }

    @app.patch("/api/experts")
    @app.post("/api/experts")
    async def api_update_experts(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if not isinstance(body, dict):
            return JSONResponse({"error": "configuration must be an object"}, status_code=400)
        allowed_top = {"auto_use", "reasoning", "providers"}
        if set(body) - allowed_top:
            return JSONResponse({"error": "unknown expert configuration field"}, status_code=400)
        candidate = expert_config()
        if "auto_use" in body:
            if not isinstance(body["auto_use"], bool):
                return JSONResponse({"error": "auto_use must be boolean"}, status_code=400)
            candidate["auto_use"] = body["auto_use"]
        if "reasoning" in body:
            if body["reasoning"] not in ("max", "high", "medium", "low"):
                return JSONResponse({"error": "invalid reasoning policy"}, status_code=400)
            candidate["reasoning"] = body["reasoning"]
        providers = body.get("providers", {})
        if not isinstance(providers, dict) or set(providers) - {"chatgpt", "claude"}:
            return JSONResponse({"error": "invalid expert provider"}, status_code=400)
        for provider, update in providers.items():
            if not isinstance(update, dict) or set(update) - {
                "enabled", "preferred_model", "enabled_models"
            }:
                return JSONResponse({"error": f"invalid {provider} configuration"}, status_code=400)
            target = candidate["providers"][provider]
            if "enabled" in update:
                if not isinstance(update["enabled"], bool):
                    return JSONResponse({"error": "enabled must be boolean"}, status_code=400)
                target["enabled"] = update["enabled"]
            if "preferred_model" in update:
                value = str(update["preferred_model"] or "").strip()
                if not valid_model_id(value):
                    return JSONResponse({"error": "invalid preferred model"}, status_code=400)
                target["preferred_model"] = value
            if "enabled_models" in update:
                values = update["enabled_models"]
                if (
                    not isinstance(values, list) or len(values) > 50
                    or any(not isinstance(value, str) or not valid_model_id(value)
                           for value in values)
                ):
                    return JSONResponse({"error": "invalid enabled model list"}, status_code=400)
                target["enabled_models"] = list(dict.fromkeys(values))
        try:
            catalog = (await rt.experts.catalog())["providers"]
        except Exception:
            return JSONResponse(
                {"error": "Relay credential and model catalog must be available"},
                status_code=409,
            )
        for provider, config in candidate["providers"].items():
            discovered = {item["id"] for item in catalog[provider]}
            if config["enabled"] and config["preferred_model"] not in discovered:
                return JSONResponse(
                    {"error": f"{provider} preferred model is not available"},
                    status_code=400,
                )
            if not set(config["enabled_models"]).issubset(discovered):
                return JSONResponse(
                    {"error": f"{provider} enabled models include unavailable entries"},
                    status_code=400,
                )
            if config["enabled"] and config["enabled_models"] and (
                config["preferred_model"] not in config["enabled_models"]
            ):
                return JSONResponse(
                    {"error": f"{provider} preferred model must be enabled"},
                    status_code=400,
                )
        old = expert_config()
        try:
            rt.settings.expert_auto_use = candidate["auto_use"]
            rt.settings.expert_reasoning = candidate["reasoning"]
            for provider, prefix in (("chatgpt", "expert_chatgpt"),
                                     ("claude", "expert_claude")):
                config = candidate["providers"][provider]
                setattr(rt.settings, prefix + "_enabled", config["enabled"])
                setattr(rt.settings, prefix + "_model", config["preferred_model"])
                setattr(rt.settings, prefix + "_models", config["enabled_models"])
            rt.settings.save()
            applied = await rt.refresh_online_tool_declarations()
        except Exception:
            rt.settings.expert_auto_use = old["auto_use"]
            rt.settings.expert_reasoning = old["reasoning"]
            for provider, prefix in (("chatgpt", "expert_chatgpt"),
                                     ("claude", "expert_claude")):
                config = old["providers"][provider]
                setattr(rt.settings, prefix + "_enabled", config["enabled"])
                setattr(rt.settings, prefix + "_model", config["preferred_model"])
                setattr(rt.settings, prefix + "_models", config["enabled_models"])
            try:
                rt.settings.save()
                await rt.refresh_online_tool_declarations()
            except Exception:
                pass
            return JSONResponse({"error": "could not save expert configuration"}, status_code=500)
        return {
            "ok": True,
            "runtime": applied,
            "config": expert_config(),
            "catalog": catalog,
            "model_policy": {"empty_enabled_models": "all_discovered"},
        }

    @app.post("/api/settings")
    async def api_settings(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        editable = {
            "low_power": bool, "voice_enabled": bool, "wake_word_model": str,
            "wake_threshold": float, "inactivity_timeout_seconds": int,
            "gemini_model": str, "gemini_voice": str, "system_prompt": str,
            # brains
            "voice_brain": str, "openai_live_model": str, "openai_voice": str,
            "typed_chat_provider": str, "openai_text_model": str,
            "relay_url": str, "relay_chat_model": str, "relay_command_model": str,
            "relay_voice": str, "relay_daily_request_cap": int,
            "cloud_schedule_enabled": bool,
            "dashboard_host": str, "dashboard_port": int,
            "interrupt_rms_threshold": int,
            # audio routing, devices, offline voice
            "audio_output_route": str, "mic_device": str, "speaker_device": str,
            "vosk_model_path": str,
            # updates
            "update_url": str, "auto_update": bool,
            "update_require_signature": bool,
            # reminders, weather, quiet mode
            "alarm_ring_seconds": int, "alarm_volume": float,
            "quiet_override_alarms": bool, "weather_units": str,
            "location_name": str, "location_lat": float, "location_lon": float,
            # key rotation & quota behavior
            "rotation_enabled": bool, "rate_limit_rotate_after_failures": int,
            "unavailable_retry_seconds": int, "quota_reset_timezone": str,
            "quota_reset_jitter_seconds": int, "retry_window_backoff_seconds": int,
            # health checks
            "pulse_internet_interval": int, "pulse_govee_interval": int,
            "pulse_credential_interval": int, "pulse_timer_interval": int,
            "pulse_audio_idle_interval": int, "pulse_tv_interval": int,
            # dashboard access
            "session_max_age_days": int, "login_max_attempts": int,
            "login_window_seconds": int, "log_level": str,
        }
        # 1) cast everything into a candidate dict — live settings untouched
        candidate: dict = {}
        for key, caster in editable.items():
            if key in body:
                try:
                    candidate[key] = caster(body[key])
                except (TypeError, ValueError):
                    return JSONResponse({"error": f"bad value for {key}"}, status_code=400)

        # 2) validate the candidate; a rejected save must change NOTHING
        if candidate.get("audio_output_route") not in (None, "speaker", "phone", "both"):
            candidate["audio_output_route"] = "speaker"
        if candidate.get("voice_brain") not in (None, "gemini", "openai_live", "relay"):
            candidate["voice_brain"] = "gemini"
        if "typed_chat_provider" in candidate:
            candidate["typed_chat_provider"] = str(candidate["typed_chat_provider"]).strip().lower()
            if candidate["typed_chat_provider"] not in TYPED_CHAT_PROVIDERS:
                return JSONResponse(
                    {"error": "typed chat provider must be openai or relay"},
                    status_code=400,
                )
        if "openai_text_model" in candidate:
            candidate["openai_text_model"] = str(candidate["openai_text_model"]).strip()
            if not valid_model_id(candidate["openai_text_model"]):
                return JSONResponse(
                    {"error": "that OpenAI text model id looks invalid"},
                    status_code=400,
                )
        if "relay_daily_request_cap" in candidate:
            candidate["relay_daily_request_cap"] = max(0, int(candidate["relay_daily_request_cap"]))
        if candidate.get("relay_url"):
            fixed = str(candidate["relay_url"]).strip()
            if not fixed.startswith(("http://", "https://")):
                fixed = "https://" + fixed
            if fixed.startswith("http://"):
                return JSONResponse(
                    {"error": "the relay address must start with https:// "
                              "(plain http would expose the relay password)"},
                    status_code=400)
            candidate["relay_url"] = fixed
        if "quota_reset_timezone" in candidate:
            from zoneinfo import ZoneInfo
            candidate["quota_reset_timezone"] = candidate["quota_reset_timezone"].strip()
            try:
                ZoneInfo(candidate["quota_reset_timezone"])
            except Exception:
                return JSONResponse(
                    {"error": "unknown timezone (try America/Los_Angeles)"}, status_code=400
                )
        if "dashboard_port" in candidate and not (1 <= candidate["dashboard_port"] <= 65535):
            return JSONResponse({"error": "port must be 1-65535"}, status_code=400)
        if "wake_threshold" in candidate:
            candidate["wake_threshold"] = min(0.99, max(0.05, candidate["wake_threshold"]))
        if "log_level" in candidate:
            candidate["log_level"] = candidate["log_level"].upper()
            if candidate["log_level"] not in ("DEBUG", "INFO", "WARNING", "ERROR"):
                return JSONResponse({"error": "log level must be DEBUG/INFO/WARNING/ERROR"}, status_code=400)
        if "alarm_volume" in candidate:
            candidate["alarm_volume"] = min(1.0, max(0.2, candidate["alarm_volume"]))
        if "alarm_ring_seconds" in candidate:
            candidate["alarm_ring_seconds"] = min(600, candidate["alarm_ring_seconds"])
        if "weather_units" in candidate and candidate["weather_units"] not in ("celsius", "fahrenheit"):
            return JSONResponse({"error": "units must be celsius or fahrenheit"}, status_code=400)
        if "location_lat" in candidate and not -90 <= candidate["location_lat"] <= 90:
            return JSONResponse({"error": "latitude must be -90..90"}, status_code=400)
        if "location_lon" in candidate and not -180 <= candidate["location_lon"] <= 180:
            return JSONResponse({"error": "longitude must be -180..180"}, status_code=400)
        minimums = {
            "inactivity_timeout_seconds": 5, "interrupt_rms_threshold": 50,
            "rate_limit_rotate_after_failures": 1, "unavailable_retry_seconds": 0,
            "quota_reset_jitter_seconds": 0, "retry_window_backoff_seconds": 0,
            "pulse_internet_interval": 5, "pulse_govee_interval": 5,
            "pulse_credential_interval": 5, "pulse_timer_interval": 1,
            "pulse_audio_idle_interval": 5, "pulse_tv_interval": 5,
            "session_max_age_days": 1,
            "login_max_attempts": 1, "login_window_seconds": 10,
            "alarm_ring_seconds": 5,
        }
        for key, lo in minimums.items():
            if key in candidate and candidate[key] < lo:
                return JSONResponse({"error": f"{key} must be at least {lo}"}, status_code=400)

        # 3) apply atomically, then persist
        for key, value in candidate.items():
            setattr(rt.settings, key, value)
        changed = list(candidate)
        rt.settings.save()
        await rt.db.log("INFO", "settings", f"updated: {', '.join(changed) or 'nothing'}")

        # apply live where possible
        note = ""
        engine_keys = {"wake_word_model", "voice_enabled", "mic_device", "speaker_device", "vosk_model_path"}
        if engine_keys & set(changed):
            rt.schedule_audio_reload()
            note = "voice settings applied live"
        if {"dashboard_host", "dashboard_port"} & set(changed):
            note = "host/port change needs a restart"
        if "cloud_schedule_enabled" in changed:
            await rt.refresh_online_tool_declarations()
        return {"ok": True, "changed": changed, "note": note}

    @app.get("/api/broadcast/status")
    async def api_broadcast_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Broadcast settings are only available on this computer."},
                status_code=403,
            )
        return broadcast.status()

    @app.post("/api/broadcast")
    async def api_broadcast_toggle(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Broadcast may only be changed on the computer running Nexa."},
                status_code=403,
            )
        if await rt.db.get_setting("admin_password_hash") is None:
            return JSONResponse(
                {"error": "Set the Nexa dashboard password before enabling broadcast."},
                status_code=409,
            )
        body = await request.json()
        if set(body) != {"enabled"} or type(body.get("enabled")) is not bool:
            return JSONResponse({"error": "enabled must be explicitly true or false"}, status_code=400)
        await broadcast.set_enabled(body["enabled"])
        return broadcast.status()

    @app.get("/api/cloud-schedule/status")
    async def api_cloud_schedule_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        credentials = await rt.store.list("relay") if rt.store is not None else []
        return {
            "enabled": bool(rt.settings.cloud_schedule_enabled),
            "configured": bool(
                str(rt.settings.relay_url or "").strip()
                and any(item.status not in {"disabled", "invalid"} for item in credentials)
            ),
        }

    @app.post("/api/cloud-schedule")
    async def api_cloud_schedule_enable(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if set(body) != {"enabled"} or type(body.get("enabled")) is not bool:
            return JSONResponse({"error": "enabled must be explicitly true or false"}, status_code=400)
        enabled = body["enabled"]
        if enabled:
            previous = rt.settings.cloud_schedule_enabled
            rt.settings.cloud_schedule_enabled = True
            try:
                await rt.cloud_schedule.client()
            except CloudScheduleError as exc:
                rt.settings.cloud_schedule_enabled = previous
                return JSONResponse({"error": str(exc)}, status_code=exc.status)
            rt.settings.cloud_schedule_enabled = previous
        rt.settings.cloud_schedule_enabled = enabled
        rt.settings.save()
        await rt.refresh_online_tool_declarations()
        return {"ok": True, "enabled": enabled}

    @app.post("/api/cloud-schedule/launch")
    async def api_cloud_schedule_launch(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            client = await rt.cloud_schedule.client()
            result = await client.ticket()
        except CloudScheduleError as exc:
            return HTMLResponse(
                "<!doctype html><title>Cloud schedule unavailable</title>"
                f"<p>{html.escape(str(exc))}</p>",
                status_code=exc.status,
                headers={"Cache-Control": "no-store"},
            )
        ticket = result.get("ticket") if isinstance(result, dict) else None
        if not isinstance(ticket, str) or not ticket or len(ticket) > 8192:
            return HTMLResponse(
                "<!doctype html><title>Cloud schedule unavailable</title>"
                "<p>The cloud returned an invalid launch ticket.</p>",
                status_code=502,
                headers={"Cache-Control": "no-store"},
            )
        action = client.origin + "/api/jarvis/session/start"
        content = (
            "<!doctype html><html><head><meta charset=\"utf-8\">"
            "<meta name=\"referrer\" content=\"no-referrer\">"
            "<title>Opening Cloud schedule</title></head><body>"
            "<p>Opening Cloud schedule&hellip;</p>"
            f"<form id=\"launch\" method=\"post\" action=\"{html.escape(action, quote=True)}\">"
            f"<input type=\"hidden\" name=\"ticket\" value=\"{html.escape(ticket, quote=True)}\">"
            "</form><script>document.getElementById('launch').submit()</script>"
            "</body></html>"
        )
        return HTMLResponse(
            content,
            headers={
                "Cache-Control": "no-store",
                "Content-Security-Policy": (
                    "default-src 'none'; script-src 'unsafe-inline'; "
                    f"form-action {client.origin}; base-uri 'none'; frame-ancestors 'none'"
                ),
                "Referrer-Policy": "no-referrer",
            },
        )

    @app.post("/api/password")
    async def api_password(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        current, new = str(body.get("current", "")), str(body.get("new", ""))
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, current):
            return JSONResponse({"error": "current password is wrong"}, status_code=403)
        if len(new) < 8:
            return JSONResponse({"error": "new password must be at least 8 characters"}, status_code=400)
        sm = await session_mgr()
        await sm.invalidate_all()
        # Persist session invalidation before the new verifier. A crash between
        # these writes can log the owner out, but can never leave old stolen
        # cookies valid after the password has changed.
        await rt.db.set_setting("admin_password_hash", hash_password(new))
        return {"ok": True}

    @app.post("/api/wake")
    async def api_wake(request: Request):
        """Manual session trigger (useful before a wake-word model is set up)."""
        err = await require_api(request)
        if err:
            return err
        if rt.gateway is None:
            return JSONResponse({"error": "cloud gateway disabled"}, status_code=400)
        rt.gateway.request_session()
        return {"ok": True}

    @app.post("/api/stop")
    async def api_stop(request: Request):
        """Immediately silence all speech output."""
        err = await require_api(request)
        if err:
            return err
        rt.stop_output()
        return {"ok": True}

    @app.post("/api/session/end")
    async def api_end_session(request: Request):
        """End hands-free listening and return to wake-word mode."""
        err = await require_api(request)
        if err:
            return err
        if rt.gateway is not None:
            await rt.gateway.end_session("ended from dashboard")
        rt.stop_output()
        return {"ok": True}

    # -- memory ------------------------------------------------------------
    @app.get("/api/memories")
    async def api_memories(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT id, content, source, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT 500"
        )
        return {"memories": [dict(r) for r in rows]}

    @app.post("/api/memories")
    async def api_add_memory(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "remember_fact", {"content": str(body.get("content", ""))[:600], "source": "dashboard"}
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/memories/{mem_id}/delete")
    async def api_delete_memory(mem_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        rt.bus.publish("memories_changed", action="deleted")
        return {"ok": True}

    # -- transcripts -------------------------------------------------------
    @app.get("/api/transcripts")
    async def api_transcripts(request: Request):
        """List voice sessions with their transcript summary (paginated, newest first).

        Pages voice_sessions first with a bounded offset, then computes line_count
        only for those page rows using the existing session/id index — no full-table
        GROUP BY scan.
        """
        err = await require_api(request)
        if err:
            return err
        try:
            limit = min(int(request.query_params.get("limit", "50")), 200)
            offset = max(int(request.query_params.get("offset", "0")), 0)
        except (ValueError, TypeError):
            return JSONResponse({"error": "limit and offset must be integers"}, status_code=400)
        # Bound offset so a huge page number cannot trigger a full-table scan.
        offset = min(offset, 10_000)
        # Page voice_sessions first (uses idx_voice_sessions_started), then
        # count lines only for the page rows via the session/id index.
        rows = await rt.db.fetchall(
            "WITH page AS ("
            "  SELECT id, provider, started_at, ended_at, close_reason"
            "  FROM voice_sessions"
            "  ORDER BY started_at DESC, id DESC"
            "  LIMIT ? OFFSET ?"
            ") "
            "SELECT p.id, p.provider, p.started_at, p.ended_at, p.close_reason,"
            "       COUNT(t.id) AS line_count"
            " FROM page p"
            " LEFT JOIN transcripts t ON t.session_id = p.id"
            " GROUP BY p.id, p.provider, p.started_at, p.ended_at, p.close_reason"
            " ORDER BY p.started_at DESC, p.id DESC",
            (limit, offset),
        )
        return {"sessions": [dict(r) for r in rows], "limit": limit, "offset": offset}

    @app.get("/api/transcripts/{session_id}")
    async def api_transcript_detail(session_id: str, request: Request):
        """Return the session metadata and a bounded page of transcript lines.

        Default (no cursor): returns the newest up-to 200 lines in chronological
        order, plus has_more=True and next_before=<oldest_id> when more exist.

        With ?before=<line_id>: returns the next older page (lines with id <
        before), newest-first internally then reversed for display, same limit.
        Never returns unlimited text.
        """
        err = await require_api(request)
        if err:
            return err
        # Validate session exists — avoids leaking timing info via error shape.
        session_row = await rt.db.fetchone(
            "SELECT id, provider, started_at, ended_at, close_reason "
            "FROM voice_sessions WHERE id = ?",
            (session_id,),
        )
        if session_row is None:
            return JSONResponse({"error": "not found"}, status_code=404)

        # Parse and validate limit.
        try:
            line_limit = min(int(request.query_params.get("limit", "200")), 200)
            if line_limit < 1:
                line_limit = 200
        except (ValueError, TypeError):
            return JSONResponse({"error": "limit must be an integer"}, status_code=400)

        # Parse and validate optional before cursor.
        before_raw = request.query_params.get("before", "")
        before_id: int | None = None
        if before_raw:
            try:
                before_id = int(before_raw)
                if before_id < 1:
                    return JSONResponse({"error": "before must be a positive integer"}, status_code=400)
            except (ValueError, TypeError):
                return JSONResponse({"error": "before must be a positive integer"}, status_code=400)

        # Fetch one extra row to detect has_more.
        fetch_limit = line_limit + 1
        if before_id is not None:
            # Older page: rows with id < before_id, descending (newest first) so
            # we take the closest older rows, then reverse for display order.
            raw_rows = await rt.db.fetchall(
                "SELECT id, ts, role, text FROM transcripts"
                " WHERE session_id = ? AND id < ?"
                " ORDER BY id DESC LIMIT ?",
                (session_id, before_id, fetch_limit),
            )
        else:
            # Default: newest rows first (descending), then reverse for display.
            raw_rows = await rt.db.fetchall(
                "SELECT id, ts, role, text FROM transcripts"
                " WHERE session_id = ?"
                " ORDER BY id DESC LIMIT ?",
                (session_id, fetch_limit),
            )

        has_more = len(raw_rows) > line_limit
        page_rows = raw_rows[:line_limit]
        # Reverse so lines are in chronological (ascending) order for display.
        page_rows = list(reversed(page_rows))

        next_before: int | None = None
        if has_more and page_rows:
            next_before = page_rows[0]["id"]

        return {
            "session": dict(session_row),
            "lines": [dict(r) for r in page_rows],
            "has_more": has_more,
            "next_before": next_before,
        }

    # -- updates & restart ---------------------------------------------------
    @app.get("/api/update/status")
    async def api_update_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        return rt.updater.status() if rt.updater else {"error": "updater not running"}

    # -- separate GitHub source publishing & sync --------------------------
    def github_owner(request: Request) -> str:
        token = request.cookies.get(COOKIE) or ""
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    def github_failure(exc: Exception) -> JSONResponse:
        if isinstance(exc, json.JSONDecodeError):
            return JSONResponse(
                {"error": "Request body must be valid JSON."},
                status_code=400,
            )
        if isinstance(exc, (GitHubPublishError, GitHubBrokerError)):
            return JSONResponse(
                {"error": sanitize(str(exc))},
                status_code=max(400, min(int(exc.status), 599)),
            )
        return JSONResponse(
            {"error": "GitHub operation could not be completed."},
            status_code=500,
        )

    async def github_config() -> object | None:
        raw = await rt.db.get_setting("github_publish_config")
        return github_publish.config_from_json(raw)

    @app.get("/api/github/status")
    async def api_github_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        config = await github_config()
        base = {
            "available": False,
            "authenticated": False,
            "login": "",
            "config": config.public() if config else None,
            "limits": {
                "max_files": 12,
                "max_file_bytes": 128 * 1024,
                "review_expires_in_seconds": 10 * 60,
            },
            "release_permissions": "separate",
            "latest_checkpoint": await asyncio.to_thread(
                github_publish.latest_checkpoint
            ),
        }
        try:
            status = await github_publish.broker_status()
        except (GitHubPublishError, GitHubBrokerError) as exc:
            base["error"] = str(exc)
            return base
        login = status.get("login")
        if not isinstance(login, str) or not login:
            base["error"] = "GitHub connection did not return an account."
            return base
        base.update({"available": True, "authenticated": True, "login": login})
        return base

    @app.post("/api/github/config")
    async def api_github_config(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            body = await request.json()
            if not isinstance(body, dict):
                raise GitHubPublishError("Request body must be a JSON object.")
            config = github_publish.validate_config(
                str(body.get("repository", "")),
                str(body.get("branch", "")),
                str(body.get("remote_prefix", "")),
            )
            head = await github_publish.verify_config(config)
            await rt.db.set_setting(
                "github_publish_config",
                json.dumps(config.public(), separators=(",", ":")),
            )
            await rt.db.log(
                "INFO",
                "github_publish",
                sanitize(
                    f"source target configured: {config.repository} "
                    f"branch {config.branch}"
                ),
            )
            return {"ok": True, "config": config.public(), "head": head}
        except Exception as exc:
            return github_failure(exc)

    @app.post("/api/github/review")
    async def api_github_review(request: Request):
        err = await require_api(request)
        if err:
            return err
        config = await github_config()
        if config is None:
            return JSONResponse(
                {"error": "Configure a repository and branch first."},
                status_code=400,
            )
        try:
            body = await request.json()
            if not isinstance(body, dict):
                raise GitHubPublishError("Request body must be a JSON object.")
            paths = body.get("paths")
            if not isinstance(paths, list):
                raise GitHubPublishError("Paths must be a list.")
            return await github_publish.review(
                owner=github_owner(request),
                direction=str(body.get("direction", "")),
                config=config,
                paths=paths,
            )
        except Exception as exc:
            return github_failure(exc)

    @app.post("/api/github/publish")
    async def api_github_publish(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            body = await request.json()
            if not isinstance(body, dict):
                raise GitHubPublishError("Request body must be a JSON object.")
            result = await github_publish.publish(
                owner=github_owner(request),
                review_id=str(body.get("review_id", "")),
                message=str(body.get("message", "")),
                confirm_repository=str(body.get("confirm_repository", "")),
                confirm_branch=str(body.get("confirm_branch", "")),
            )
            await rt.db.log(
                "INFO",
                "github_publish",
                sanitize(
                    f"source commit confirmed on {result['repository']} "
                    f"branch {result['branch']}"
                ),
            )
            return result
        except Exception as exc:
            return github_failure(exc)

    @app.post("/api/github/sync")
    async def api_github_sync(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            body = await request.json()
            if not isinstance(body, dict):
                raise GitHubPublishError("Request body must be a JSON object.")
            result = await github_publish.sync(
                owner=github_owner(request),
                review_id=str(body.get("review_id", "")),
                confirm_repository=str(body.get("confirm_repository", "")),
                confirm_branch=str(body.get("confirm_branch", "")),
            )
            await rt.db.log(
                "INFO",
                "github_publish",
                f"synced {len(result['files'])} reviewed source file(s); "
                f"checkpoint {result['checkpoint_id']}",
            )
            return result
        except Exception as exc:
            return github_failure(exc)

    @app.post("/api/github/restore")
    async def api_github_restore(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            body = await request.json()
            if not isinstance(body, dict):
                raise GitHubPublishError("Request body must be a JSON object.")
            result = await asyncio.to_thread(
                github_publish.restore,
                str(body.get("checkpoint_id", "")),
            )
            await rt.db.log(
                "INFO",
                "github_publish",
                f"restored {len(result['files'])} source file(s) from sync checkpoint",
            )
            return result
        except Exception as exc:
            return github_failure(exc)

    @app.post("/api/update/check")
    async def api_update_check(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.updater is None:
            return JSONResponse({"error": "updater not running"}, status_code=400)
        return await rt.updater.check_now()

    @app.post("/api/restart")
    async def api_restart(request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.log("INFO", "dashboard", "restart requested")
        rt.request_restart()
        return {"ok": True, "note": "Nexa is restarting; this page will reconnect."}

    # -- audio devices & phone listening -------------------------------------
    @app.get("/api/audio/devices")
    async def api_audio_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        devices = {"inputs": [], "outputs": []}
        try:
            import sounddevice as sd

            for i, d in enumerate(sd.query_devices()):
                entry = {"index": i, "name": d["name"]}
                if d.get("max_input_channels", 0) > 0:
                    devices["inputs"].append(entry)
                if d.get("max_output_channels", 0) > 0:
                    devices["outputs"].append(entry)
        except Exception:
            pass  # no sound stack on this machine; lists stay empty
        return devices

    @app.websocket("/ws/audio")
    async def ws_audio(ws: WebSocket):
        """Streams Nexa's output audio (PCM16 mono 24 kHz) to the browser."""
        sm = await session_mgr()
        if sm.validate(ws.cookies.get(COOKIE)) is None:
            await ws.close(code=4401)
            return
        await ws.accept()
        q = rt.broadcast.subscribe()

        async def sink_incoming():
            try:
                while True:
                    await ws.receive_text()  # keepalives from the browser
            except Exception:
                pass

        recv_task = asyncio.create_task(sink_incoming())
        try:
            while True:
                kind, payload = await q.get()
                if kind == "pcm":
                    await ws.send_bytes(payload)
                else:
                    await ws.send_text('{"type":"clear"}')
        except (WebSocketDisconnect, RuntimeError, ConnectionError):
            pass
        finally:
            rt.broadcast.unsubscribe(q)
            recv_task.cancel()

    @app.post("/api/remote-voice/token")
    async def api_remote_voice_token(request: Request):
        """Mint a short-lived, session-bound capability for /ws/remote-voice.

        Browsers cannot attach custom headers to WebSocket handshakes, so the
        page fetches this scoped token (cookie + CSRF protected) and presents
        it in the socket's hello frame instead.
        """
        err = await require_api(request)
        if err:
            return err
        if rt.remote_voice is None:
            return JSONResponse({"error": "cloud voice is disabled"}, status_code=503)
        sm = await session_mgr()
        cap = sm.capability_for(request.cookies.get(COOKIE), "remote-voice")
        if not cap:
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        return {"token": cap, "expires_in": 120}

    @app.get("/api/remote-voice/diagnostics")
    async def api_remote_voice_diagnostics(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.remote_voice is None:
            return JSONResponse({"error": "cloud voice is disabled"}, status_code=503)
        return rt.remote_voice.diagnostics()

    @app.websocket("/ws/remote-voice")
    async def ws_remote_voice(ws: WebSocket):
        """Remote device voice endpoint — a DEDICATED provider session.

        The full lifecycle (hello/capability auth, lease claim/resume,
        wake listening, conversation, barge-in, reconnect grace) lives in
        apps/dashboard/remote_voice_socket.py; the provider stack lives in
        apps/live_gateway/remote_voice.py and never touches the host
        microphone, speakers, or the host gateway session.
        """
        await serve_remote_voice_socket(rt, ws, await session_mgr())
    return app


def _jsonsafe(data: dict) -> dict:
    out = {}
    for k, v in data.items():
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, (set, frozenset)):
            out[k] = sorted(v)
        else:
            out[k] = v
    return out
