@echo off
title Nexa
color 07
cd /d "%~dp0"

if exist .venv\Scripts\python.exe (
    set PY=.venv\Scripts\python.exe
) else (
    set PY=python
)

:run
%PY% run_chat.py %*
if "%errorlevel%"=="42" (
    echo Restarting Nexa...
    goto run
)
if errorlevel 1 (
    echo.
    echo Nexa exited with an error. See above.
    pause
)
