"""Official, read-only YouTube Data API integration."""

from .client import (
    YouTubeAPIError,
    YouTubeClient,
    canonical_playlist_url,
    canonical_video_url,
    canonical_watch_url,
    extract_playlist_id,
    extract_video_id,
)

__all__ = [
    "YouTubeAPIError",
    "YouTubeClient",
    "canonical_playlist_url",
    "canonical_video_url",
    "canonical_watch_url",
    "extract_playlist_id",
    "extract_video_id",
]
