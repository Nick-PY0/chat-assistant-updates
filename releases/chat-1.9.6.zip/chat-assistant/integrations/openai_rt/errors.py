"""Failure classification for OpenAI, using the same small vocabulary the
rest of Chat already speaks (invalid / quota / rate_limited / unavailable).

The shared vocabulary matters: the credential store, the dashboard pills,
and the gateway's announcements all key off those four words, so an OpenAI
problem shows up in exactly the same places a Gemini problem would.
"""

from __future__ import annotations

import json

from integrations.gemini.errors import (  # single source of failure words
    GeminiFailure as ProviderFailure,
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
)

__all__ = ["ProviderFailure", "classify_openai", "INVALID", "QUOTA_EXHAUSTED",
           "RATE_LIMITED", "UNAVAILABLE"]


def _short(text: str, limit: int = 200) -> str:
    text = " ".join(str(text or "").split())
    return text[:limit]


def classify_openai(status: int | None, text: str = "") -> ProviderFailure:
    """HTTP status + body (or an error event's JSON) -> ProviderFailure."""
    low = (text or "").lower()

    # Body signals beat status codes: OpenAI reports "insufficient_quota"
    # with status 429, which is a spent allowance, not a speed limit.
    if "insufficient_quota" in low or "exceeded your current quota" in low:
        return ProviderFailure(QUOTA_EXHAUSTED, _short(text) or "quota spent", retry_after=None)
    if "invalid_api_key" in low or "incorrect api key" in low or "invalid_request_error" in low and "api key" in low:
        return ProviderFailure(INVALID, _short(text) or "key rejected", retry_after=None)

    if status in (401, 403):
        return ProviderFailure(INVALID, _short(text) or f"HTTP {status}", retry_after=None)
    if status == 429:
        return ProviderFailure(RATE_LIMITED, _short(text) or "too many requests", retry_after=None)
    if status is not None and status >= 500:
        return ProviderFailure(UNAVAILABLE, _short(text) or f"HTTP {status}", retry_after=None)

    if "rate limit" in low or "rate_limit" in low:
        return ProviderFailure(RATE_LIMITED, _short(text) or "too many requests", retry_after=None)
    return ProviderFailure(UNAVAILABLE, _short(text) or "connection failure", retry_after=None)


def classify_error_event(event: dict) -> ProviderFailure:
    """Classify a realtime `error` event payload."""
    err = event.get("error") or {}
    return classify_openai(None, json.dumps(err))
