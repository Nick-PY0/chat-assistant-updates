"""Cheap validity check for an OpenAI key: list models, spend nothing."""

from __future__ import annotations

import httpx

from integrations.openai_rt.errors import ProviderFailure, classify_openai


async def validate_openai_key(secret: str, timeout: float = 10.0) -> None:
    """Raises ProviderFailure when the key is rejected or OpenAI is down."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {secret}"},
            )
    except httpx.HTTPError as exc:
        raise classify_openai(None, f"connection failure: {exc}") from exc
    if resp.status_code == 200:
        return
    raise classify_openai(resp.status_code, resp.text)
