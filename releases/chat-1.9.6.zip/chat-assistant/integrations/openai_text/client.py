"""A deliberately small async client for ``POST /v1/responses``.

Typed chat uses Responses instead of Chat Completions so reasoning-capable
models, image inputs, and function tools share one supported request shape.
The client contains no credential lookup and stores no conversation state.
"""

from __future__ import annotations

import json

import httpx


RESPONSES_URL = "https://api.openai.com/v1/responses"


class OpenAITextError(Exception):
    """A sanitized OpenAI error safe to show on the local dashboard."""


class OpenAIResponsesClient:
    def __init__(
        self,
        api_key: str,
        timeout: float = 90.0,
        transport: httpx.AsyncBaseTransport | None = None,
        url: str = RESPONSES_URL,
    ) -> None:
        self.api_key = str(api_key or "").strip()
        self.timeout = timeout
        self.transport = transport
        self.url = url

    async def create(self, payload: dict) -> dict:
        if not self.api_key:
            raise OpenAITextError("no OpenAI API key is available")
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                transport=self.transport,
            ) as client:
                response = await client.post(
                    self.url,
                    headers={
                        "Authorization": f"Bearer {self.api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
        except httpx.HTTPError as exc:
            raise OpenAITextError("OpenAI could not be reached") from exc

        try:
            data = response.json()
        except ValueError:
            data = {}
        if response.status_code >= 400:
            error = data.get("error") if isinstance(data, dict) else None
            message = error.get("message") if isinstance(error, dict) else None
            raise OpenAITextError(str(message or f"OpenAI error (HTTP {response.status_code})"))
        if not isinstance(data, dict):
            raise OpenAITextError("OpenAI returned an unreadable response")
        return data


def to_responses_tools(declarations: list[dict]) -> list[dict]:
    """Convert the app's Gemini-style schemas to Responses function tools."""

    def lower_types(node):
        if isinstance(node, dict):
            return {
                key: (
                    value.lower()
                    if key == "type" and isinstance(value, str)
                    else lower_types(value)
                )
                for key, value in node.items()
            }
        if isinstance(node, list):
            return [lower_types(item) for item in node]
        return node

    return [
        {
            "type": "function",
            "name": str(declaration.get("name") or ""),
            "description": str(declaration.get("description") or ""),
            "parameters": lower_types(
                declaration.get("parameters")
                or {"type": "object", "properties": {}}
            ),
            "strict": False,
        }
        for declaration in declarations
    ]


def response_result(data: dict) -> dict:
    """Extract text, local function calls, usage, and cited URLs."""
    text_parts: list[str] = []
    calls: list[dict] = []
    sources: list[dict[str, str]] = []
    seen_urls: set[str] = set()

    for item in data.get("output") or []:
        if not isinstance(item, dict):
            continue
        if item.get("type") == "function_call":
            raw_args = item.get("arguments") or "{}"
            try:
                args = json.loads(raw_args) if isinstance(raw_args, str) else dict(raw_args)
            except (TypeError, ValueError):
                args = {}
            calls.append({
                "call_id": str(item.get("call_id") or item.get("id") or ""),
                "name": str(item.get("name") or ""),
                "arguments": args,
            })
            continue
        if item.get("type") != "message":
            continue
        for content in item.get("content") or []:
            if not isinstance(content, dict) or content.get("type") != "output_text":
                continue
            value = str(content.get("text") or "").strip()
            if value:
                text_parts.append(value)
            for annotation in content.get("annotations") or []:
                if not isinstance(annotation, dict) or annotation.get("type") != "url_citation":
                    continue
                url = str(annotation.get("url") or "").strip()
                if not url.startswith(("http://", "https://")) or url in seen_urls:
                    continue
                seen_urls.add(url)
                sources.append({
                    "title": str(annotation.get("title") or url).strip(),
                    "url": url,
                })

    usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
    return {
        "id": str(data.get("id") or ""),
        "text": "\n\n".join(text_parts).strip(),
        "tool_calls": calls,
        "sources": sources,
        "usage": usage,
        "model": str(data.get("model") or ""),
        "status": str(data.get("status") or ""),
    }
