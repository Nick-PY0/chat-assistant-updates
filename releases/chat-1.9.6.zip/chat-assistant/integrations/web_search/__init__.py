"""Small, read-only web and news search integration."""

from .client import WebSearchClient, WebSearchError

__all__ = ["WebSearchClient", "WebSearchError"]
