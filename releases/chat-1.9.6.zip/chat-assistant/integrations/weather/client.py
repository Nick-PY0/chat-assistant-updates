"""Weather via Open-Meteo: free, no account, no API key.

Two endpoints are used:
  * geocoding-api.open-meteo.com to turn a city name into coordinates (done
    once, when the user sets their location in Settings);
  * api.open-meteo.com for the forecast (cached ~15 minutes so voice
    questions and the dashboard card don't hammer the service).
"""

from __future__ import annotations

import time

import httpx

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
CACHE_SECONDS = 15 * 60

_WMO = {
    0: "clear skies", 1: "mostly clear", 2: "partly cloudy", 3: "overcast",
    45: "foggy", 48: "icy fog",
    51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
    56: "freezing drizzle", 57: "heavy freezing drizzle",
    61: "light rain", 63: "rain", 65: "heavy rain",
    66: "freezing rain", 67: "heavy freezing rain",
    71: "light snow", 73: "snow", 75: "heavy snow", 77: "snow grains",
    80: "light showers", 81: "showers", 82: "heavy showers",
    85: "snow showers", 86: "heavy snow showers",
    95: "a thunderstorm", 96: "a thunderstorm with hail",
    99: "a severe thunderstorm with hail",
}


def wmo_text(code) -> str:
    try:
        return _WMO.get(int(code), "changing conditions")
    except (TypeError, ValueError):
        return "changing conditions"


class WeatherError(Exception):
    pass


class WeatherClient:
    def __init__(self, timeout: float = 15.0) -> None:
        self.timeout = timeout
        self._cache: dict[tuple, tuple[float, dict]] = {}

    async def _get(self, url: str, params: dict) -> dict:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(url, params=params)
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPError as exc:
            raise WeatherError(f"weather service unreachable ({type(exc).__name__})") from exc

    async def geocode(self, query: str, count: int = 5) -> list[dict]:
        query = str(query or "").strip()
        if len(query) < 2:
            raise WeatherError("type a town or city name")
        data = await self._get(
            GEOCODE_URL, {"name": query, "count": count, "language": "en", "format": "json"}
        )
        out = []
        for r in data.get("results") or []:
            label = r.get("name", "")
            extra = ", ".join(x for x in (r.get("admin1"), r.get("country")) if x)
            out.append(
                {
                    "name": f"{label} ({extra})" if extra else label,
                    "lat": float(r.get("latitude", 0.0)),
                    "lon": float(r.get("longitude", 0.0)),
                }
            )
        return out

    async def forecast(self, lat: float, lon: float, units: str = "celsius") -> dict:
        """Normalized current + today + tomorrow. Cached."""
        units = "fahrenheit" if str(units).lower().startswith("f") else "celsius"
        key = (round(float(lat), 3), round(float(lon), 3), units)
        hit = self._cache.get(key)
        now = time.monotonic()
        if hit and now - hit[0] < CACHE_SECONDS:
            return hit[1]

        data = await self._get(
            FORECAST_URL,
            {
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,"
                           "weather_code,wind_speed_10m",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code,"
                         "precipitation_probability_max",
                "forecast_days": 2,
                "timezone": "auto",
                "temperature_unit": units,
                "wind_speed_unit": "kmh" if units == "celsius" else "mph",
            },
        )
        cur = data.get("current") or {}
        daily = data.get("daily") or {}

        def day(i: int) -> dict:
            def col(name, default=None):
                vals = daily.get(name) or []
                return vals[i] if i < len(vals) else default

            return {
                "date": col("time", ""),
                "high": col("temperature_2m_max"),
                "low": col("temperature_2m_min"),
                "code": col("weather_code"),
                "text": wmo_text(col("weather_code")),
                "rain_chance": col("precipitation_probability_max"),
            }

        result = {
            "units": units,
            "unit_symbol": "°F" if units == "fahrenheit" else "°C",
            "wind_unit": "mph" if units == "fahrenheit" else "km/h",
            "current": {
                "temp": cur.get("temperature_2m"),
                "feels": cur.get("apparent_temperature"),
                "humidity": cur.get("relative_humidity_2m"),
                "wind": cur.get("wind_speed_10m"),
                "code": cur.get("weather_code"),
                "text": wmo_text(cur.get("weather_code")),
            },
            "today": day(0),
            "tomorrow": day(1),
        }
        self._cache[key] = (now, result)
        return result

    @staticmethod
    def summary_sentence(data: dict, day: str = "today", location: str = "") -> str:
        """Short spoken-style summary, used for voice replies and offline TTS."""
        unit = "degrees"
        where = f" in {location}" if location else ""
        if day == "tomorrow":
            d = data.get("tomorrow") or {}
            parts = [f"Tomorrow{where}: {d.get('text', 'no data')}"]
            if d.get("high") is not None:
                parts.append(f"high {round(d['high'])} {unit}, low {round(d.get('low') or 0)}")
            if d.get("rain_chance") is not None:
                parts.append(f"rain chance {round(d['rain_chance'])} percent")
            return ". ".join(parts) + "."
        cur = data.get("current") or {}
        today = data.get("today") or {}
        parts = []
        if cur.get("temp") is not None:
            parts.append(f"It's {round(cur['temp'])} {unit} and {cur.get('text', '')}{where}")
        else:
            parts.append(f"Today{where}: {today.get('text', 'no data')}")
        if today.get("high") is not None:
            parts.append(f"high {round(today['high'])}, low {round(today.get('low') or 0)}")
        if today.get("rain_chance") is not None:
            parts.append(f"rain chance {round(today['rain_chance'])} percent")
        return ". ".join(parts) + "."
