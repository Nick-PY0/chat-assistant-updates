"""Govee official cloud API adapter with strict input validation."""

from __future__ import annotations

import secrets
from typing import Any

import httpx

BASE = "https://openapi.api.govee.com"

COLOR_NAMES = {
    "red": (255, 0, 0),
    "green": (0, 255, 0),
    "blue": (0, 0, 255),
    "white": (255, 255, 255),
    "warm white": (255, 244, 229),
    "yellow": (255, 255, 0),
    "orange": (255, 165, 0),
    "purple": (128, 0, 128),
    "pink": (255, 105, 180),
    "cyan": (0, 255, 255),
    "teal": (0, 128, 128),
}


class GoveeError(Exception):
    pass


def parse_color(color: str) -> tuple[int, int, int]:
    c = color.strip().lower()
    if c in COLOR_NAMES:
        return COLOR_NAMES[c]
    if c.startswith("#") and len(c) == 7:
        try:
            return int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)
        except ValueError as exc:
            raise GoveeError(f"invalid hex color: {color}") from exc
    raise GoveeError(f"unknown color: {color}")


def validate_percentage(value: Any) -> int:
    try:
        pct = int(value)
    except (TypeError, ValueError) as exc:
        raise GoveeError("percentage must be a number") from exc
    if not 0 <= pct <= 100:
        raise GoveeError("percentage must be between 0 and 100")
    return pct


class GoveeClient:
    def __init__(self, api_key: str, timeout: float = 3.0) -> None:
        self._key = api_key
        self.timeout = timeout

    def _headers(self) -> dict:
        return {"Govee-API-Key": self._key, "Content-Type": "application/json"}

    async def _post(self, path: str, payload: dict) -> dict:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(BASE + path, json=payload, headers=self._headers())
        except httpx.HTTPError as exc:
            raise GoveeError(f"network: {type(exc).__name__}") from exc
        if resp.status_code == 401:
            raise GoveeError("Govee API key rejected")
        if resp.status_code == 429:
            raise GoveeError("Govee rate limit hit; try again shortly")
        if resp.status_code >= 400:
            raise GoveeError(f"Govee error HTTP {resp.status_code}")
        try:
            return resp.json()
        except ValueError as exc:
            raise GoveeError("Govee returned invalid JSON") from exc

    async def _get(self, path: str) -> dict:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(BASE + path, headers=self._headers())
        except httpx.HTTPError as exc:
            raise GoveeError(f"network: {type(exc).__name__}") from exc
        if resp.status_code == 401:
            raise GoveeError("Govee API key rejected")
        if resp.status_code >= 400:
            raise GoveeError(f"Govee error HTTP {resp.status_code}")
        try:
            return resp.json()
        except ValueError as exc:
            raise GoveeError("Govee returned invalid JSON") from exc

    # ------------------------------------------------------------------
    async def list_devices(self) -> list[dict]:
        data = await self._get("/router/api/v1/user/devices")
        devices = []
        for item in data.get("data", []) or []:
            devices.append(
                {
                    "device": item.get("device"),
                    "sku": item.get("sku"),
                    "name": item.get("deviceName") or item.get("device"),
                    "capabilities": [c.get("instance") for c in item.get("capabilities", []) or []],
                }
            )
        return devices

    async def _control(self, sku: str, device: str, capability: dict) -> dict:
        payload = {
            "requestId": secrets.token_hex(8),
            "payload": {"sku": sku, "device": device, "capability": capability},
        }
        return await self._post("/router/api/v1/device/control", payload)

    async def set_power(self, sku: str, device: str, on: bool) -> dict:
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.on_off", "instance": "powerSwitch", "value": 1 if on else 0},
        )

    async def set_brightness(self, sku: str, device: str, percentage: int) -> dict:
        pct = validate_percentage(percentage)
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.range", "instance": "brightness", "value": max(pct, 1)},
        )

    async def set_color(self, sku: str, device: str, color: str) -> dict:
        r, g, b = parse_color(color)
        return await self._control(
            sku,
            device,
            {
                "type": "devices.capabilities.color_setting",
                "instance": "colorRgb",
                "value": (r << 16) | (g << 8) | b,
            },
        )

    async def activate_scene(self, sku: str, device: str, scene_value: Any) -> dict:
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.dynamic_scene", "instance": "lightScene", "value": scene_value},
        )

    async def get_state(self, sku: str, device: str) -> dict:
        payload = {
            "requestId": secrets.token_hex(8),
            "payload": {"sku": sku, "device": device},
        }
        return await self._post("/router/api/v1/device/state", payload)
