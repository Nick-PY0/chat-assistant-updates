"""Client for the owner's relay on Replit -- the doorway to the second brain.

The relay holds no state and stores nothing; every call carries one turn.
Every request is authenticated with the relay password, which lives in the
laptop's encrypted vault like every other credential.
"""

from __future__ import annotations

import base64
import io
import struct
import wave

import httpx

DEFAULT_TIMEOUT = 60.0  # voice turns carry audio both ways; give them room


class RelayError(Exception):
    """A relay problem, always phrased so it can be shown to the owner."""


def wrap_wav(pcm: bytes, rate: int, channels: int = 1) -> bytes:
    """PCM16 -> a minimal WAV container (what the relay expects)."""
    header = io.BytesIO()
    data_size = len(pcm)
    byte_rate = rate * channels * 2
    header.write(b"RIFF")
    header.write(struct.pack("<I", 36 + data_size))
    header.write(b"WAVEfmt ")
    header.write(struct.pack("<IHHIIHH", 16, 1, channels, rate, byte_rate, channels * 2, 16))
    header.write(b"data")
    header.write(struct.pack("<I", data_size))
    return header.getvalue() + pcm


def parse_wav(blob: bytes) -> tuple[bytes, int]:
    """WAV bytes -> (pcm16 mono-ish frames, sample rate)."""
    try:
        with wave.open(io.BytesIO(blob), "rb") as wav:
            rate = wav.getframerate()
            frames = wav.readframes(wav.getnframes())
            if wav.getnchannels() == 2:  # fold stereo down so playback stays mono
                mono = bytearray()
                for i in range(0, len(frames) - 3, 4):
                    left = struct.unpack_from("<h", frames, i)[0]
                    right = struct.unpack_from("<h", frames, i + 2)[0]
                    mono += struct.pack("<h", (left + right) // 2)
                frames = bytes(mono)
            return frames, rate
    except (wave.Error, EOFError, struct.error) as exc:
        raise RelayError(f"the relay sent audio that could not be read: {exc}") from exc


class RelayClient:
    """Thin async HTTP client for the relay routes."""

    def __init__(self, base_url: str, secret: str, timeout: float = DEFAULT_TIMEOUT,
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        base = (base_url or "").strip().rstrip("/")
        if base and not base.startswith(("http://", "https://")):
            base = "https://" + base
        if base.startswith("http://"):
            raise RelayError(
                "the relay address must start with https:// -- over plain "
                "http the relay password would travel unprotected")
        # The relay mounts under /api on the server.
        if base and not base.endswith("/api"):
            base = base + "/api"
        self.base = base
        self._secret = secret
        self._timeout = timeout
        self._transport = transport  # tests inject a fake network here

    def _headers(self) -> dict:
        return {"x-chat-relay-key": self._secret}

    async def _post(self, path: str, payload: dict) -> dict:
        if not self.base:
            raise RelayError("no relay address is set (Settings -> Brain).")
        try:
            async with httpx.AsyncClient(timeout=self._timeout, transport=self._transport) as client:
                resp = await client.post(self.base + path, json=payload, headers=self._headers())
        except httpx.HTTPError as exc:
            raise RelayError(f"the relay could not be reached: {exc}") from exc
        return self._decode(resp)

    async def _get(self, path: str) -> dict:
        if not self.base:
            raise RelayError("no relay address is set (Settings -> Brain).")
        try:
            async with httpx.AsyncClient(timeout=15.0, transport=self._transport) as client:
                resp = await client.get(self.base + path, headers=self._headers())
        except httpx.HTTPError as exc:
            raise RelayError(f"the relay could not be reached: {exc}") from exc
        return self._decode(resp)

    @staticmethod
    def _decode(resp: httpx.Response) -> dict:
        if resp.status_code == 401:
            raise RelayError("the relay refused the password (check Providers -> Relay).")
        if resp.status_code == 503:
            raise RelayError("the relay is up but has no password set on the server side.")
        try:
            data = resp.json()
        except ValueError:
            data = {}
        if resp.status_code >= 400:
            raise RelayError(str(data.get("error") or f"relay error (HTTP {resp.status_code})"))
        if not isinstance(data, dict):
            raise RelayError("the relay sent something that was not JSON.")
        return data

    # -- the four calls Chat makes ------------------------------------
    async def health(self) -> None:
        await self._get("/relay/health")

    async def models(self) -> dict:
        return await self._get("/relay/models")

    async def transcribe(self, pcm16k: bytes) -> str:
        blob = wrap_wav(pcm16k, 16000)
        data = await self._post("/relay/transcribe", {
            "audio_b64": base64.b64encode(blob).decode(),
        })
        return str(data.get("text", "")).strip()

    # Reasoning models spend tokens thinking before they answer; a small
    # budget can be eaten entirely by thought, leaving an empty reply.
    async def ask(self, messages: list[dict], tools: list[dict], model: str,
                  max_tokens: int = 1600) -> dict:
        return await self._post("/relay/ask", {
            "messages": messages,
            "tools": tools,
            "model": model,
            "max_tokens": max_tokens,
        })

    async def speak(self, text: str, voice: str) -> tuple[bytes, int]:
        data = await self._post("/relay/speak", {"text": text, "voice": voice})
        blob = base64.b64decode(str(data.get("audio_b64", "")) or b"")
        if not blob:
            raise RelayError("the relay sent an empty spoken reply.")
        return parse_wav(blob)
