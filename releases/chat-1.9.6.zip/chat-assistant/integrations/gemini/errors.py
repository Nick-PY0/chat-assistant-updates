"""Gemini failure classification.

Distinguishes, per the implementation plan:
  invalid          -> credential is bad (401/403, "API key not valid")
  rate_limited     -> short-window 429; brief backoff, key stays usable
  quota_exhausted  -> the project's daily quota is spent; blocked until the
                      documented reset (midnight Pacific) plus jitter
  unavailable      -> transient server/network trouble; bounded backoff
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

INVALID = "invalid"
RATE_LIMITED = "rate_limited"
QUOTA_EXHAUSTED = "quota_exhausted"
UNAVAILABLE = "unavailable"


@dataclass
class GeminiFailure(Exception):
    code: str
    message: str
    retry_after: datetime | None = None

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


def next_quota_reset(tz_name: str = "America/Los_Angeles", jitter_seconds: int = 300) -> datetime:
    """Daily Gemini quotas reset at midnight Pacific time."""
    tz = ZoneInfo(tz_name)
    now_pt = datetime.now(tz)
    tomorrow = (now_pt + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return (tomorrow + timedelta(seconds=jitter_seconds)).astimezone(timezone.utc)


_RETRY_DELAY_RE = re.compile(r"retry(?:\s|-)?(?:in|after|delay)\D*(\d+(?:\.\d+)?)\s*s", re.IGNORECASE)
_DAILY_HINTS = ("perday", "per day", "daily", "generaterequestsperday", "quota exceeded", "exceeded your current quota")
_KEY_HINTS = ("api key not valid", "api_key_invalid", "invalid api key", "permission denied", "api key expired", "consumer_suspended")


def _extract_retry_delay(payload: dict | None, text: str) -> float | None:
    if payload:
        for detail in payload.get("error", {}).get("details", []) or []:
            if str(detail.get("@type", "")).endswith("RetryInfo"):
                delay = str(detail.get("retryDelay", ""))
                m = re.match(r"(\d+(?:\.\d+)?)s?", delay)
                if m:
                    return float(m.group(1))
    m = _RETRY_DELAY_RE.search(text)
    if m:
        return float(m.group(1))
    return None


def _quota_is_daily(payload: dict | None, text: str) -> bool:
    lowered = text.lower()
    if payload:
        for detail in payload.get("error", {}).get("details", []) or []:
            if str(detail.get("@type", "")).endswith("QuotaFailure"):
                for violation in detail.get("violations", []) or []:
                    blob = json.dumps(violation).lower()
                    if any(h in blob for h in ("perday", "daily")):
                        return True
    return any(h in lowered for h in _DAILY_HINTS)


def classify(
    status_code: int | None,
    body: str = "",
    tz_name: str = "America/Los_Angeles",
    jitter_seconds: int = 300,
    now: datetime | None = None,
) -> GeminiFailure:
    """Map an HTTP/WebSocket failure to a policy decision."""
    now = now or datetime.now(timezone.utc)
    payload: dict | None = None
    try:
        payload = json.loads(body) if body and body.strip().startswith("{") else None
    except json.JSONDecodeError:
        payload = None
    text = body or ""
    lowered = text.lower()

    if status_code in (401, 403) or any(h in lowered for h in _KEY_HINTS):
        return GeminiFailure(INVALID, _short(text) or f"HTTP {status_code}")

    if status_code == 429:
        delay = _extract_retry_delay(payload, text)
        daily = _quota_is_daily(payload, text)
        if daily and (delay is None or delay > 15 * 60):
            return GeminiFailure(
                QUOTA_EXHAUSTED,
                _short(text) or "project quota exhausted",
                retry_after=next_quota_reset(tz_name, jitter_seconds),
            )
        if delay is None and daily:
            return GeminiFailure(
                QUOTA_EXHAUSTED,
                _short(text) or "project quota exhausted",
                retry_after=next_quota_reset(tz_name, jitter_seconds),
            )
        # short-window rate limit
        backoff = delay if delay is not None else 30.0
        return GeminiFailure(
            RATE_LIMITED,
            _short(text) or "rate limited",
            retry_after=now + timedelta(seconds=min(backoff, 15 * 60)),
        )

    if status_code is not None and status_code >= 500:
        return GeminiFailure(UNAVAILABLE, _short(text) or f"HTTP {status_code}", retry_after=None)

    if "quota" in lowered:
        return GeminiFailure(
            QUOTA_EXHAUSTED,
            _short(text) or "quota exhausted",
            retry_after=next_quota_reset(tz_name, jitter_seconds),
        )

    return GeminiFailure(UNAVAILABLE, _short(text) or "connection failure", retry_after=None)


def _short(text: str, limit: int = 200) -> str:
    text = " ".join(text.split())
    return text[:limit]
