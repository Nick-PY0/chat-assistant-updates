"""Minimal, cheap credential validation against the Gemini REST API."""

from __future__ import annotations

import httpx

from integrations.gemini.errors import GeminiFailure, classify

BASE = "https://generativelanguage.googleapis.com"


async def validate_key(secret: str, timeout: float = 5.0) -> None:
    """Raise GeminiFailure if the key is not currently usable."""
    url = f"{BASE}/v1beta/models"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url, params={"pageSize": 1, "key": secret})
    except httpx.HTTPError as exc:
        raise GeminiFailure("unavailable", f"network: {type(exc).__name__}") from exc
    if resp.status_code == 200:
        return
    raise classify(resp.status_code, resp.text)
