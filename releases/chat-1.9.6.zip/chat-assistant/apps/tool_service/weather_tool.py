"""Weather as a tool: binds the Open-Meteo client to the saved location."""

from __future__ import annotations

from chat_core.config import Settings
from integrations.weather import WeatherClient, WeatherError


class WeatherTool:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.client = WeatherClient()

    def spoken_location(self) -> str:
        # "Georgetown (Demerara-Mahaica, Guyana)" -> "Georgetown"
        return (self.settings.location_name or "").split(" (")[0]

    async def get(self, day: str = "today") -> dict:
        s = self.settings
        if not s.location_lat and not s.location_lon:
            raise WeatherError("no home location set -- add your town under Settings")
        day = "tomorrow" if str(day or "").strip().lower() == "tomorrow" else "today"
        data = await self.client.forecast(s.location_lat, s.location_lon, s.weather_units)
        return {
            "location": s.location_name,
            "day": day,
            **data,
            "summary": WeatherClient.summary_sentence(data, day, self.spoken_location()),
        }
