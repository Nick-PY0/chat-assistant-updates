"""Restricted local command grammar for LOCAL_ONLY mode.

Understands only the allowlisted patterns from the plan, e.g.:
  "set a timer for ten minutes"
  "list my timers"
  "cancel the kitchen timer"
  "turn off the bedroom light"
  "set the desk light to fifty percent"

Returns a structured command dict or None if the utterance is outside the
grammar (never guesses).
"""

from __future__ import annotations

import re

_UNITS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
    "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
    "seventeen": 17, "eighteen": 18, "nineteen": 19,
}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60,
         "seventy": 70, "eighty": 80, "ninety": 90}


def words_to_number(text: str) -> int | None:
    text = text.strip().lower().replace("-", " ")
    if text.isdigit():
        return int(text)
    total = 0
    found = False
    for word in text.split():
        if word in ("a", "an"):
            total += 1
            found = True
        elif word in _UNITS:
            total += _UNITS[word]
            found = True
        elif word in _TENS:
            total += _TENS[word]
            found = True
        elif word == "hundred" and found:
            total *= 100
        elif word in ("and",):
            continue
        else:
            return None
    return total if found else None


def parse_spoken_time(text: str) -> tuple[int, int, str] | None:
    """'7', '7:30', 'seven thirty pm', 'seven oh five', 'noon' -> (hour, minute, ampm).

    ampm is '' when the speaker didn't say it (the reminder scheduler then
    picks the next matching clock time)."""
    text = text.strip().lower().replace(".", " ").replace(":", " ")
    text = re.sub(r"\bo'?clock\b", " ", text)
    toks = " ".join(text.split()).split()
    if not toks:
        return None
    ap = ""
    if toks[-1] in ("am", "pm"):
        ap = toks.pop()
    elif len(toks) >= 2 and toks[-2] in ("a", "p") and toks[-1] == "m":
        ap = toks[-2] + "m"
        toks = toks[:-2]
    if not toks:
        return None
    if toks[0] in ("noon", "midday"):
        return 12, 0, "pm"
    if toks[0] == "midnight":
        return 12, 0, "am"
    hour = words_to_number(toks[0])
    if hour is None or not 0 <= hour <= 23:
        return None
    minute = 0
    rest = toks[1:]
    if rest and rest[0] in ("oh", "o"):  # "seven oh five"
        rest = rest[1:]
    if rest:
        minute = words_to_number(" ".join(rest))
        if minute is None or not 0 <= minute <= 59:
            return None
    return hour, minute, ap


# A bare stop only flushes spoken output and keeps listening (stop_output).
# A goodbye ends the conversation and returns to wake-word mode
# (end_voice_session).  The two are deliberately disjoint, matching the shared
# stop/goodbye split in apps/live_gateway/prompts.py.
_STOP = re.compile(
    r"^(?:stop(?:\s+(?:it|talking|that|now|please))?|be\s+quiet|quiet|hush|shut\s+up"
    r"|silence|never\s?mind|cancel\s+that)$"
)
_GOODBYE = re.compile(
    r"^(?:good\s?bye(?:\s+jarvis)?|bye(?:\s+jarvis)?|stop\s+listening"
    r"|end(?:\s+(?:this|the))?\s+(?:conversation|session)|go\s+to\s+sleep"
    r"|that(?:'s| is)\s+all(?:\s+jarvis)?)$"
)
_REMEMBER = re.compile(r"^remember\s+(?:that\s+)?(?P<content>.{2,})$")
_RECALL = re.compile(
    r"^(?:what\s+do\s+you\s+remember(?:\s+about\s+(?P<q1>.+))?"
    r"|what\s+did\s+i\s+tell\s+you(?:\s+about\s+(?P<q2>.+))?"
    r"|do\s+you\s+remember\s+(?P<q3>.+))\??$"
)
_FORGET = re.compile(r"^forget\s+(?:that\s+|about\s+)?(?P<q>.{2,})$")

_TIME = r"(?P<time>[\w:'. ]+?)"
_DAY = r"(?:\s+(?P<day>today|tonight|tomorrow))?"
_REMIND_PREFIXED = re.compile(rf"^remind\s+me\s+at\s+{_TIME}{_DAY}\s+(?:to|that|about)\s+(?P<msg>.+)$")
_REMIND_SUFFIXED = re.compile(rf"^remind\s+me\s+(?:to\s+|that\s+|about\s+)?(?P<msg>.+?)\s+at\s+{_TIME}{_DAY}$")
_ALARM = re.compile(rf"^(?:set\s+(?:an?\s+)?alarm\s+for|wake\s+me\s+(?:up\s+)?at)\s+{_TIME}{_DAY}$")
_REM_LIST = re.compile(r"^(?:list|what\s+are)\s+(?:my\s+)?(?:reminders?|alarms?)$")
_REM_CANCEL = re.compile(r"^cancel\s+(?:the\s+|my\s+)?(?P<ref>[\w ]+?\s+)?(?P<kind>alarm|reminder)$")
_WEATHER = re.compile(
    r"^(?:what(?:'s|\s+is)\s+the\s+weather(?:\s+like)?|how(?:'s|\s+is)\s+the\s+weather"
    r"|weather(?:\s+(?:report|forecast))?|(?:will|is)\s+it\s+(?:going\s+to\s+)?rain)"
    r"(?:\s+(?:for\s+|out\s+)?(?P<day>today|tonight|tomorrow))?\s*\??$"
)
_QUIET_OFF = re.compile(
    r"^(?:(?:turn|switch)\s+)?quiet\s+mode\s+off$|^(?:exit|leave|end|stop)\s+quiet\s+mode$"
    r"|^(?:you\s+can\s+)?(?:talk|speak)\s+(?:again|now)$|^do\s+not\s+disturb\s+off$"
)
_QUIET_ON = re.compile(
    r"^(?:(?:turn|switch)\s+)?quiet\s+mode(?:\s+on)?$|^(?:enter|start)\s+quiet\s+mode$"
    r"|^go\s+quiet$|^do\s+not\s+disturb(?:\s+on)?$"
)

_NUM = r"(?P<num>\d+|[a-z\- ]+?)"

_TIMER_START = re.compile(
    rf"\b(?:set|start)\s+(?:a\s+)?(?:(?P<label>[\w ]+?)\s+)?timer\s+for\s+{_NUM}\s+(?P<unit>seconds?|minutes?|hours?)\b"
)
_TIMER_LIST = re.compile(r"\b(?:list|what are)\s+(?:my\s+)?timers?\b")
_TIMER_CANCEL = re.compile(r"\bcancel\s+(?:the\s+)?(?P<label>[\w ]+?)?\s*timer\b")
_LIGHT_POWER = re.compile(r"\bturn\s+(?P<state>on|off)\s+(?:the\s+)?(?P<device>[\w ]+?)(?:\s+lights?)?\s*$")
_LIGHT_POWER2 = re.compile(r"\bturn\s+(?:the\s+)?(?P<device>[\w ]+?)\s+lights?\s+(?P<state>on|off)\b")
_LIGHT_BRIGHT = re.compile(
    rf"\bset\s+(?:the\s+)?(?P<device>[\w ]+?)\s+lights?\s+to\s+{_NUM}\s*(?:percent|%)\b"
)

# ---- YouTube / media -------------------------------------------------------

# ---- playlists -------------------------------------------------------------
# Direct official playlist URL or "play the playlist <id/url>".
_YT_PLAYLIST_URL = re.compile(
    r"(?P<url>(?:https?://)?(?:www\.|m\.|music\.)?(?:youtube\.com|youtu\.be)/\S*\blist=[A-Za-z0-9_-]+\S*)",
    re.IGNORECASE,
)
# "play a relaxing music playlist" / "play the <name> playlist" /
# "play a playlist of jazz" / "start a workout playlist"
_PLAY_PLAYLIST = re.compile(
    r"^(?:play|start|put\s+on)\s+"
    r"(?:(?:a|an|the|some)\s+)?"
    r"(?:(?P<q1>.+?)\s+playlist|playlist\s+(?:of\s+)?(?P<q2>.+))"
    r"(?:\s+on\s+youtube)?$"
)

# "play Blinding Lights on YouTube"
# "play Blinding Lights"            (implicit YouTube)
# "search YouTube for Blinding Lights"
# "open YouTube"
_PLAY_YT = re.compile(
    r"^(?:play|open|search(?:\s+youtube)?(?:\s+for)?)\s+"
    r"(?:(?P<query>.+?)\s+on\s+youtube|(?P<query2>.+?)\s+on\s+yt"
    r"|(?:youtube\s+for\s+)?(?P<query3>.+))$"
)
_OPEN_YT = re.compile(r"^open\s+youtube\s*$")

# media transport controls (now dispatch to YouTube-specific tools)
_MEDIA_RESUME = re.compile(r"^(?:resume(?:\s+(?:video|music|playback))?|play\s+(?:it|that|again|music))$")
_MEDIA_PAUSE  = re.compile(r"^pause(?:\s+(?:the\s+)?(?:music|it|that|playback|video|song))?$")
_MEDIA_TOGGLE = re.compile(r"^(?:play\s*/?\s*pause|toggle\s+(?:play|music|playback))$")
_MEDIA_STOP   = re.compile(r"^stop\s+(?:the\s+)?(?:music|playback|the\s+music|the\s+song|the\s+video|playing|song|video|playlist)$")
_MEDIA_NEXT   = re.compile(r"^(?:next|skip(?:\s+ahead)?|next\s+(?:song|track|video))$")
_MEDIA_PREV   = re.compile(r"^(?:previous(?:\s+(?:song|track|video))?|prev|back|go\s+back|last\s+(?:song|track)|previous\s+video)$")
_MEDIA_SEEK_BACK = re.compile(
    r"^(?:rewind|go\s+back|skip\s+back(?:ward)?)\s+(?P<num>[\w ]+?)\s+(?P<unit>seconds?|minutes?|mins?)$"
)
_MEDIA_SEEK_FWD = re.compile(
    r"^(?:skip\s+ahead|go\s+forward|fast\s+forward|seek\s+forward)\s+(?P<num>[\w ]+?)\s+(?P<unit>seconds?|minutes?|mins?)$"
)

# restart / start over
_MEDIA_RESTART = re.compile(
    r"^(?:restart(?:\s+(?:the\s+)?(?:video|song|music|track|playback))?"
    r"|start\s+(?:it\s+)?over(?:\s+again)?"
    r"|(?:play\s+)?(?:it\s+)?from\s+the\s+(?:top|beginning|start)"
    r"|go\s+back\s+to\s+the\s+(?:start|beginning))$"
)

# mute / unmute
_MEDIA_MUTE = re.compile(
    r"^(?:mute(?:\s+(?:the\s+)?(?:music|video|song|volume|playback|it|youtube))?)$"
)
_MEDIA_UNMUTE = re.compile(
    r"^(?:unmute(?:\s+(?:the\s+)?(?:music|video|song|volume|playback|it|youtube))?"
    r"|turn\s+the\s+(?:sound|audio)\s+back\s+on)$"
)

# absolute volume: "set the volume to 30 percent", "volume 50"
_MEDIA_VOLUME_SET = re.compile(
    r"^(?:set\s+(?:the\s+)?volume\s+to|(?:change\s+)?volume(?:\s+to)?)\s+"
    rf"{_NUM}\s*(?:percent|%)?$"
)
# relative volume: "turn it up", "volume up", "turn the volume down a bit"
_MEDIA_VOLUME_UP = re.compile(
    r"^(?:turn\s+(?:it|the\s+(?:volume|sound|music))\s+up(?:\s+a\s+(?:bit|little))?"
    r"|volume\s+up|louder|turn\s+it\s+louder)$"
)
_MEDIA_VOLUME_DOWN = re.compile(
    r"^(?:turn\s+(?:it|the\s+(?:volume|sound|music))\s+down(?:\s+a\s+(?:bit|little))?"
    r"|volume\s+down|quieter|turn\s+it\s+down)$"
)


def parse(utterance: str) -> dict | None:
    text = " ".join(utterance.lower().strip().rstrip(".!?").split())
    # strip leading wake word
    text = re.sub(r"^(?:hey\s+)?(?:chat|jarvis)[,:]?\s*", "", text)

    if _GOODBYE.match(text):
        return {"tool": "end_voice_session", "args": {}}

    if _STOP.match(text):
        return {"tool": "stop_output", "args": {}}

    if _QUIET_OFF.match(text):
        return {"tool": "set_quiet_mode", "args": {"enabled": False}}
    if _QUIET_ON.match(text):
        return {"tool": "set_quiet_mode", "args": {"enabled": True}}

    for pattern, kind in (
        (_REMIND_PREFIXED, "reminder"),
        (_REMIND_SUFFIXED, "reminder"),
        (_ALARM, "alarm"),
    ):
        m = pattern.match(text)
        if m:
            parts = parse_spoken_time(m.group("time"))
            if parts is None:
                continue
            hour, minute, ampm = parts
            groups = m.groupdict()
            return {
                "tool": "set_reminder",
                "args": {
                    "hour": hour,
                    "minute": minute,
                    "ampm": ampm,
                    "day": groups.get("day") or "",
                    "message": (groups.get("msg") or "").strip(),
                    "kind": kind,
                },
            }

    if _REM_LIST.match(text):
        return {"tool": "list_reminders", "args": {}}

    m = _REM_CANCEL.match(text)
    if m:
        ref = (m.group("ref") or "").strip()
        return {"tool": "cancel_reminder", "args": {"ref": ref or m.group("kind")}}

    m = _WEATHER.match(text)
    if m:
        day = m.group("day") or "today"
        return {"tool": "get_weather", "args": {"day": "tomorrow" if day == "tomorrow" else "today"}}

    m = _REMEMBER.match(text)
    if m:
        return {"tool": "remember_fact", "args": {"content": m.group("content").strip()}}

    m = _RECALL.match(text)
    if m:
        query = (m.group("q1") or m.group("q2") or m.group("q3") or "").strip().rstrip("?")
        return {"tool": "recall_memories", "args": {"query": query}}

    m = _FORGET.match(text)
    if m and not re.search(r"\btimer\b", text):
        return {"tool": "forget_memory", "args": {"query": m.group("q").strip()}}

    m = _TIMER_START.search(text)
    if m:
        n = words_to_number(m.group("num") or "")
        if n is None:
            return None
        unit = m.group("unit")
        seconds = n * (3600 if unit.startswith("hour") else 60 if unit.startswith("minute") else 1)
        label = (m.group("label") or "").strip()
        if label in ("a", "the", "my"):
            label = ""
        return {"tool": "start_timer", "args": {"duration_seconds": seconds, "label": label}}

    if _TIMER_LIST.search(text):
        return {"tool": "list_timers", "args": {}}

    m = _TIMER_CANCEL.search(text)
    if m:
        label = (m.group("label") or "").strip()
        return {"tool": "cancel_timer", "args": {"timer_id": label or ""}}

    m = _LIGHT_BRIGHT.search(text)
    if m:
        n = words_to_number(m.group("num") or "")
        if n is None:
            return None
        return {
            "tool": "set_govee_brightness",
            "args": {"device": m.group("device").strip(), "percentage": n},
        }

    for pattern in (_LIGHT_POWER2, _LIGHT_POWER):
        m = pattern.search(text)
        if m:
            device = m.group("device").strip()
            device = re.sub(r"\s+lights?$", "", device)
            return {
                "tool": "set_govee_power",
                "args": {"device": device, "state": m.group("state")},
            }

    # ---- YouTube / media controls -------------------------------------------

    # restart / start over.  Checked BEFORE the generic play/seek rules so
    # "play it from the beginning" / "go back to the start" are restarts, not a
    # new play-query or a relative seek.
    if _MEDIA_RESTART.match(text):
        return {"tool": "restart_youtube", "args": {}}

    # mute / unmute
    if _MEDIA_UNMUTE.match(text):
        return {"tool": "unmute_youtube", "args": {}}
    if _MEDIA_MUTE.match(text):
        return {"tool": "mute_youtube", "args": {}}

    # absolute / relative volume (before play so "volume up" is not a query)
    m = _MEDIA_VOLUME_SET.match(text)
    if m:
        n = words_to_number(m.group("num") or "")
        if n is not None:
            return {"tool": "set_youtube_volume", "args": {"percentage": n}}
    if _MEDIA_VOLUME_UP.match(text):
        return {"tool": "set_youtube_volume", "args": {"delta": 10}}
    if _MEDIA_VOLUME_DOWN.match(text):
        return {"tool": "set_youtube_volume", "args": {"delta": -10}}

    # Direct official playlist URL anywhere in the utterance -> play_playlist.
    m = _YT_PLAYLIST_URL.search(utterance.strip())
    if m and re.match(r"^(?:hey\s+)?(?:chat|jarvis)?[,:]?\s*(?:play|open|start|put\s+on)\b", text):
        return {"tool": "play_playlist", "args": {"playlist_url": m.group("url")}}

    # "play a relaxing music playlist" -> playlist search.
    m = _PLAY_PLAYLIST.match(text)
    if m:
        query = (m.group("q1") or m.group("q2") or "").strip()
        if query and query not in ("youtube", "yt"):
            return {"tool": "play_playlist", "args": {"playlist_query": query}}

    # "open youtube" with no query
    if _OPEN_YT.match(text):
        return {"tool": "play_youtube", "args": {"query": "YouTube"}}

    # "play X on YouTube" / "search youtube for X" / "play X"
    m = _PLAY_YT.match(text)
    if m:
        query = (m.group("query") or m.group("query2") or m.group("query3") or "").strip()
        # reject bare "play" with no query content
        if query and query not in ("youtube", "yt", "music"):
            return {"tool": "play_youtube", "args": {"query": query}}

    # seek (must come before generic next/prev to match "go back 30 seconds")
    m = _MEDIA_SEEK_BACK.match(text)
    if m:
        n = words_to_number(m.group("num") or "")
        if n is not None:
            unit = m.group("unit")
            secs = n * (60 if unit.startswith("min") else 1)
            return {"tool": "seek_youtube", "args": {"offset_seconds": -secs}}

    m = _MEDIA_SEEK_FWD.match(text)
    if m:
        n = words_to_number(m.group("num") or "")
        if n is not None:
            unit = m.group("unit")
            secs = n * (60 if unit.startswith("min") else 1)
            return {"tool": "seek_youtube", "args": {"offset_seconds": secs}}

    # media transport – order matters: check stop AFTER the main stop pattern
    # (which was already checked above); these are more specific
    if _MEDIA_STOP.match(text):
        return {"tool": "stop_youtube", "args": {}}
    if _MEDIA_TOGGLE.match(text):
        return {"tool": "media_control", "args": {"action": "play_pause"}}
    if _MEDIA_PAUSE.match(text):
        return {"tool": "pause_youtube", "args": {}}
    if _MEDIA_RESUME.match(text):
        return {"tool": "play_youtube", "args": {}}
    if _MEDIA_NEXT.match(text):
        return {"tool": "next_youtube", "args": {}}
    if _MEDIA_PREV.match(text):
        return {"tool": "previous_youtube", "args": {}}

    return None
