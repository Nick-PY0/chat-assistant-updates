"""Allowlisted current-time, web-search, and news tools."""

from __future__ import annotations

from datetime import datetime

from integrations.web_search import WebSearchClient


class WebResearchTool:
    def __init__(self, client: WebSearchClient | None = None) -> None:
        self.client = client or WebSearchClient()

    @staticmethod
    def current_time() -> dict:
        now = datetime.now().astimezone()
        hour = now.strftime("%I").lstrip("0") or "0"
        return {
            "local_time": f"{hour}:{now:%M:%S %p}",
            "local_date": now.strftime("%A, %B %d, %Y").replace(" 0", " "),
            "iso": now.isoformat(timespec="seconds"),
            "timezone": str(now.tzname() or "local"),
            "utc_offset": now.strftime("%z"),
        }

    async def search(self, query: object, max_results: object = 5) -> dict:
        return await self.client.search(query, max_results)

    async def news(self, query: object = "", max_results: object = 6) -> dict:
        return await self.client.news(query, max_results)
