"""Persistent timers with wall-clock deadlines.

Timers survive restarts: deadlines are absolute UTC timestamps in SQLite.
On startup, overdue timers are surfaced as 'missed' (announced once)
rather than silently discarded.
"""

from __future__ import annotations

import asyncio
import secrets
from datetime import timedelta

from chat_core.events import EventBus
from chat_core.models.credentials import iso, parse_iso, utcnow
from chat_core.models.db import Database

MAX_TIMER_SECONDS = 12 * 3600


class TimerError(Exception):
    pass


class TimerManager:
    def __init__(self, db: Database, bus: EventBus) -> None:
        self.db = db
        self.bus = bus
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    # -- lifecycle -------------------------------------------------------
    async def start(self) -> None:
        await self._restore()
        self._task = asyncio.create_task(self._scheduler(), name="timer-scheduler")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def _restore(self) -> None:
        """Surface overdue timers after restart per policy: mark missed + announce."""
        now = utcnow()
        rows = await self.db.fetchall("SELECT * FROM timers WHERE status='running'")
        for row in rows:
            deadline = parse_iso(row["deadline"])
            if deadline and deadline <= now:
                await self.db.execute(
                    "UPDATE timers SET status='missed', finished_at=? WHERE id=?",
                    (iso(now), row["id"]),
                )
                self.bus.publish("timer_missed", id=row["id"], label=row["label"])
                await self.db.log("WARNING", "timers", f"missed while offline: {row['label'] or row['id']}")

    async def _scheduler(self) -> None:
        """Light-footprint loop: wakes at most once per second only when a
        timer is close, otherwise sleeps until the next deadline."""
        while not self._stop.is_set():
            row = await self.db.fetchone(
                "SELECT id, label, deadline FROM timers WHERE status='running' ORDER BY deadline LIMIT 1"
            )
            if row is None:
                await asyncio.sleep(2.0)
                continue
            deadline = parse_iso(row["deadline"])
            if deadline is None:
                await asyncio.sleep(1.0)
                continue
            wait = (deadline - utcnow()).total_seconds()
            if wait > 0:
                await asyncio.sleep(min(wait, 2.0))
                continue
            await self.db.execute(
                "UPDATE timers SET status='completed', finished_at=? WHERE id=? AND status='running'",
                (iso(utcnow()), row["id"]),
            )
            self.bus.publish("timer_fired", id=row["id"], label=row["label"])
            await self.db.log("INFO", "timers", f"timer fired: {row['label'] or row['id']}")

    # -- operations --------------------------------------------------------
    async def start_timer(self, duration_seconds: int, label: str = "") -> dict:
        try:
            duration = int(duration_seconds)
        except (TypeError, ValueError) as exc:
            raise TimerError("duration must be a number of seconds") from exc
        if not 1 <= duration <= MAX_TIMER_SECONDS:
            raise TimerError(f"duration must be 1..{MAX_TIMER_SECONDS} seconds")
        label = str(label or "").strip()[:60]
        timer_id = "t_" + secrets.token_hex(4)
        deadline = utcnow() + timedelta(seconds=duration)
        await self.db.execute(
            "INSERT INTO timers (id, label, duration_seconds, deadline, status, created_at) "
            "VALUES (?, ?, ?, ?, 'running', ?)",
            (timer_id, label, duration, iso(deadline), iso(utcnow())),
        )
        self.bus.publish("timers_changed")
        return {"id": timer_id, "label": label, "ends_at": iso(deadline), "duration_seconds": duration}

    async def list_timers(self) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM timers WHERE status IN ('running','paused') ORDER BY created_at"
        )
        now = utcnow()
        out = []
        for r in rows:
            if r["status"] == "running":
                deadline = parse_iso(r["deadline"])
                remaining = max(0, int((deadline - now).total_seconds())) if deadline else 0
            else:
                remaining = int(r["remaining_seconds"] or 0)
            out.append(
                {
                    "id": r["id"],
                    "label": r["label"],
                    "status": r["status"],
                    "remaining_seconds": remaining,
                    "duration_seconds": r["duration_seconds"],
                }
            )
        return out

    async def _find(self, ref: str):
        ref = str(ref or "").strip()
        row = await self.db.fetchone(
            "SELECT * FROM timers WHERE id=? AND status IN ('running','paused')", (ref,)
        )
        if row:
            return row
        row = await self.db.fetchone(
            "SELECT * FROM timers WHERE lower(label)=lower(?) AND status IN ('running','paused') "
            "ORDER BY created_at LIMIT 1",
            (ref,),
        )
        if row:
            return row
        raise TimerError(f"no active timer matching '{ref}'")

    async def cancel_timer(self, ref: str) -> dict:
        row = await self._find(ref)
        await self.db.execute(
            "UPDATE timers SET status='cancelled', finished_at=? WHERE id=?",
            (iso(utcnow()), row["id"]),
        )
        self.bus.publish("timers_changed")
        return {"id": row["id"], "label": row["label"], "status": "cancelled"}

    async def pause_timer(self, ref: str) -> dict:
        row = await self._find(ref)
        if row["status"] != "running":
            raise TimerError("timer is not running")
        deadline = parse_iso(row["deadline"])
        remaining = max(0, int((deadline - utcnow()).total_seconds())) if deadline else 0
        await self.db.execute(
            "UPDATE timers SET status='paused', deadline=NULL, remaining_seconds=? WHERE id=?",
            (remaining, row["id"]),
        )
        self.bus.publish("timers_changed")
        return {"id": row["id"], "label": row["label"], "status": "paused", "remaining_seconds": remaining}

    async def resume_timer(self, ref: str) -> dict:
        row = await self._find(ref)
        if row["status"] != "paused":
            raise TimerError("timer is not paused")
        remaining = int(row["remaining_seconds"] or 0)
        deadline = utcnow() + timedelta(seconds=max(remaining, 1))
        await self.db.execute(
            "UPDATE timers SET status='running', deadline=?, remaining_seconds=NULL WHERE id=?",
            (iso(deadline), row["id"]),
        )
        self.bus.publish("timers_changed")
        return {"id": row["id"], "label": row["label"], "status": "running", "ends_at": iso(deadline)}
