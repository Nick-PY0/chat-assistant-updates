"""Clock-time reminders and alarms.

Unlike timers (countdowns), these fire at a wall-clock moment: "remind me to
take the chicken out at 5", "wake me up at 7 am". Deadlines are stored as
absolute UTC timestamps so they survive restarts; anything that fired while
the machine was off is surfaced once as 'missed'.

Time words are resolved here, deterministically:
  * explicit am/pm is respected;
  * a bare hour 1-12 means the NEXT time the clock shows it ("at 5" said at
    2 pm -> 5 pm today; said at 6 pm -> 5 am tomorrow);
  * "tonight" prefers the evening reading;
  * an explicit "tomorrow"/date with an ambiguous hour takes the morning
    reading (say "5 pm" to be precise).
"""

from __future__ import annotations

import asyncio
import secrets
from datetime import date as date_cls
from datetime import datetime, time as time_cls, timedelta, timezone

from chat_core.events import EventBus
from chat_core.models.credentials import iso, parse_iso, utcnow
from chat_core.models.db import Database

MAX_SCHEDULED = 200
MAX_MESSAGE_CHARS = 200


class ReminderError(Exception):
    pass


def now_local() -> datetime:
    return datetime.now().astimezone()


def resolve_fire_time(
    hour, minute=0, ampm: str = "", day: str = "", now: datetime | None = None
) -> datetime:
    """Turn spoken time parts into a concrete future LOCAL datetime.

    Wall times are computed as naive local datetimes and made aware only at
    the end via .astimezone(), which applies the system timezone rules for
    THAT date -- so a reminder set across a DST change still fires at the
    spoken wall-clock time. When tests pass an aware `now`, candidates
    share its tzinfo instead (deterministic fixed offset).
    """
    system_mode = now is None
    if system_mode:
        now = datetime.now()  # naive system-local
    try:
        h = int(hour)
        m = int(minute or 0)
    except (TypeError, ValueError) as exc:
        raise ReminderError("I need a time, like 'at 5' or 'at 7:30 pm'") from exc
    if not 0 <= m <= 59:
        raise ReminderError("minutes must be 0-59")
    ap = str(ampm or "").strip().lower().replace(".", "")
    day = str(day or "").strip().lower()

    if ap in ("am", "a"):
        if not 1 <= h <= 12:
            raise ReminderError("with am/pm the hour must be 1-12")
        hours = [h % 12]
    elif ap in ("pm", "p"):
        if not 1 <= h <= 12:
            raise ReminderError("with am/pm the hour must be 1-12")
        hours = [h % 12 + 12]
    elif 1 <= h <= 12:
        hours = sorted({h % 12, h % 12 + 12})  # ambiguous: both readings
        if day == "tonight":
            hours = [h % 12 + 12]  # "tonight at 9" is 21:00, not 09:00
    elif 0 <= h <= 23:
        hours = [h]
    else:
        raise ReminderError("hour must be 0-23")

    def candidate(d: date_cls, hh: int) -> datetime:
        naive = datetime.combine(d, time_cls(hh, m))
        return naive if system_mode else naive.replace(tzinfo=now.tzinfo)

    def finalize(dt: datetime) -> datetime:
        # naive local -> aware, with the UTC offset correct for dt's date
        return dt.astimezone() if system_mode else dt

    if day in ("", "today", "tonight"):
        cands = [candidate(now.date(), hh) for hh in hours]
        future = [c for c in cands if c > now + timedelta(seconds=5)]
        if future:
            return finalize(min(future))
        if day:  # they said "today"/"tonight" explicitly
            raise ReminderError("that time today has already passed")
        return finalize(min(candidate(now.date() + timedelta(days=1), hh) for hh in hours))

    if day == "tomorrow":
        target = now.date() + timedelta(days=1)
    else:
        try:
            target = date_cls.fromisoformat(day)
        except ValueError as exc:
            raise ReminderError("day must be today, tomorrow, or YYYY-MM-DD") from exc
    result = candidate(target, hours[0])  # explicit day + bare hour -> morning
    if result <= now:
        raise ReminderError("that time has already passed")
    return finalize(result)


def _local_label(fires_at_utc: datetime) -> str:
    local = fires_at_utc.astimezone()
    today = now_local().date()
    if local.date() == today:
        day = "today"
    elif local.date() == today + timedelta(days=1):
        day = "tomorrow"
    else:
        day = local.strftime("%a %d %b")
    return f"{day} {local.strftime('%H:%M')}"


class ReminderManager:
    def __init__(self, db: Database, bus: EventBus) -> None:
        self.db = db
        self.bus = bus
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    # -- lifecycle -------------------------------------------------------
    async def start(self) -> None:
        await self._restore()
        self._task = asyncio.create_task(self._scheduler(), name="reminder-scheduler")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)

    async def _restore(self) -> None:
        now = utcnow()
        rows = await self.db.fetchall("SELECT * FROM reminders WHERE status='scheduled'")
        for row in rows:
            due = parse_iso(row["fires_at"])
            if due and due <= now:
                await self.db.execute(
                    "UPDATE reminders SET status='missed', finished_at=? WHERE id=?",
                    (iso(now), row["id"]),
                )
                self.bus.publish(
                    "reminder_missed", id=row["id"], message=row["message"], kind=row["kind"]
                )
                await self.db.log(
                    "WARNING", "reminders", f"missed while off: {row['message'] or row['kind']}"
                )

    async def _scheduler(self) -> None:
        while not self._stop.is_set():
            row = await self.db.fetchone(
                "SELECT id, message, kind, fires_at FROM reminders "
                "WHERE status='scheduled' ORDER BY fires_at LIMIT 1"
            )
            if row is None:
                await asyncio.sleep(2.0)
                continue
            due = parse_iso(row["fires_at"])
            if due is None:
                await asyncio.sleep(1.0)
                continue
            wait = (due - utcnow()).total_seconds()
            if wait > 0:
                await asyncio.sleep(min(wait, 2.0))
                continue
            claimed = await self.db.execute(
                "UPDATE reminders SET status='fired', finished_at=? WHERE id=? AND status='scheduled'",
                (iso(utcnow()), row["id"]),
            )
            if claimed != 1:
                continue  # cancelled between the SELECT and the claim: no ring
            self.bus.publish(
                "reminder_fired", id=row["id"], message=row["message"], kind=row["kind"]
            )
            self.bus.publish("reminders_changed")
            await self.db.log("INFO", "reminders", f"fired: {row['message'] or row['kind']}")

    # -- operations --------------------------------------------------------
    async def set_reminder(
        self,
        message: str = "",
        hour=None,
        minute=0,
        ampm: str = "",
        day: str = "",
        kind: str = "reminder",
        at_local: str = "",
    ) -> dict:
        """Schedule a reminder/alarm. Either (hour, minute, ampm, day) from
        speech, or at_local='YYYY-MM-DDTHH:MM' from the dashboard form."""
        kind = "alarm" if str(kind or "").strip().lower() == "alarm" else "reminder"
        message = " ".join(str(message or "").split())[:MAX_MESSAGE_CHARS]

        if at_local:
            try:
                local = datetime.fromisoformat(at_local)
            except ValueError as exc:
                raise ReminderError("bad date/time") from exc
            if local.tzinfo is None:
                # interpret as system-local wall time with the DST rules of
                # THAT date, not today's fixed offset
                local = local.astimezone()
            if local <= now_local():
                raise ReminderError("that time has already passed")
        else:
            if hour is None:
                raise ReminderError("I need a time, like 'at 5' or 'at 7:30 pm'")
            local = resolve_fire_time(hour, minute, ampm, day)

        count = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM reminders WHERE status='scheduled'"
        )
        if count and count["n"] >= MAX_SCHEDULED:
            raise ReminderError("too many scheduled reminders")

        fires_utc = local.astimezone(timezone.utc)
        rid = "r_" + secrets.token_hex(4)
        await self.db.execute(
            "INSERT INTO reminders (id, message, kind, fires_at, status, created_at) "
            "VALUES (?, ?, ?, ?, 'scheduled', ?)",
            (rid, message, kind, iso(fires_utc), iso(utcnow())),
        )
        self.bus.publish("reminders_changed")
        return {
            "id": rid,
            "message": message,
            "kind": kind,
            "fires_at": iso(fires_utc),
            "when": _local_label(fires_utc),
        }

    async def list_reminders(self, include_recent: bool = False) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM reminders WHERE status='scheduled' ORDER BY fires_at"
        )
        out = [
            {
                "id": r["id"],
                "message": r["message"],
                "kind": r["kind"],
                "status": r["status"],
                "fires_at": r["fires_at"],
                "when": _local_label(parse_iso(r["fires_at"]) or utcnow()),
            }
            for r in rows
        ]
        if include_recent:
            recent = await self.db.fetchall(
                "SELECT * FROM reminders WHERE status IN ('fired','missed') "
                "ORDER BY finished_at DESC LIMIT 10"
            )
            out += [
                {
                    "id": r["id"],
                    "message": r["message"],
                    "kind": r["kind"],
                    "status": r["status"],
                    "fires_at": r["fires_at"],
                    "when": _local_label(parse_iso(r["fires_at"]) or utcnow()),
                }
                for r in recent
            ]
        return out

    async def cancel_reminder(self, ref: str = "") -> dict:
        ref = str(ref or "").strip()
        row = None
        if ref:
            row = await self.db.fetchone(
                "SELECT * FROM reminders WHERE id=? AND status='scheduled'", (ref,)
            )
        if row is None and ref.lower() in ("", "alarm", "reminder", "the alarm", "the reminder"):
            kind = "alarm" if "alarm" in ref.lower() else ("reminder" if "reminder" in ref.lower() else "")
            if kind:
                row = await self.db.fetchone(
                    "SELECT * FROM reminders WHERE status='scheduled' AND kind=? "
                    "ORDER BY fires_at LIMIT 1",
                    (kind,),
                )
            else:
                rows = await self.db.fetchall(
                    "SELECT * FROM reminders WHERE status='scheduled' ORDER BY fires_at LIMIT 2"
                )
                if len(rows) == 1:
                    row = rows[0]
                elif len(rows) > 1:
                    raise ReminderError("several are scheduled; say which one")
        if row is None and ref:
            row = await self.db.fetchone(
                "SELECT * FROM reminders WHERE status='scheduled' AND LOWER(message) LIKE ? "
                "ORDER BY fires_at LIMIT 1",
                (f"%{ref.lower()}%",),
            )
        if row is None:
            raise ReminderError(f"no scheduled reminder matching '{ref}'" if ref else "nothing is scheduled")
        changed = await self.db.execute(
            "UPDATE reminders SET status='cancelled', finished_at=? "
            "WHERE id=? AND status='scheduled'",
            (iso(utcnow()), row["id"]),
        )
        if changed != 1:
            raise ReminderError("that one just fired -- say stop to silence it")
        self.bus.publish("reminders_changed")
        return {"id": row["id"], "message": row["message"], "kind": row["kind"], "status": "cancelled"}
