"""Legal YouTube / media-control tool.

play_youtube  – builds a safe YouTube search URL or canonical watch URL and
                opens it in the user's default browser on the Windows host.
                No downloading, no DRM bypass, no ad bypass, no scraping.

media_control – sends standard OS media key events on Windows so the user
                can play/pause/stop/next/previous/seek without touching the
                keyboard.  On non-Windows platforms it returns a clear error
                instead of silently failing.
"""

from __future__ import annotations

import re
import sys
from urllib.parse import quote_plus, urlparse

# ---------------------------------------------------------------------------
# URL safety
# ---------------------------------------------------------------------------

_YOUTUBE_HOSTS = frozenset(
    {
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
        "www.youtu.be",
    }
)


def _is_youtube_url(url: str) -> bool:
    """Return True only when *url* is an https YouTube / youtu.be link."""
    try:
        p = urlparse(url)
    except ValueError:
        return False
    return (
        p.scheme in ("https", "http")
        and p.netloc.lower() in _YOUTUBE_HOSTS
    )


def build_youtube_url(query: str, video_id: str = "") -> str:
    """Return a safe, percent-encoded YouTube URL.

    * If *video_id* is supplied (and looks valid) it returns the canonical
      watch URL, which is the most direct legal link.
    * Otherwise it returns a YouTube search-results URL for *query*.

    Either way the URL is safe: no javascript:, no data:, no non-YouTube hosts.
    """
    if video_id:
        # video IDs are 11 base64url chars; reject anything else
        if re.fullmatch(r"[A-Za-z0-9_\-]{11}", video_id):
            return f"https://www.youtube.com/watch?v={video_id}"
    # search fallback
    q = quote_plus(query.strip())
    return f"https://www.youtube.com/results?search_query={q}"


def validate_direct_url(url: str) -> str:
    """Validate that a caller-supplied URL is a safe YouTube link.

    Raises :class:`MediaError` if it is not.
    Returns the URL unchanged if it passes.
    """
    if not _is_youtube_url(url):
        raise MediaError(
            "Only youtube.com / youtu.be URLs are accepted; "
            "no external sites, no javascript: or data: URIs."
        )
    return url


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class MediaError(Exception):
    """Safe-to-display media tool error."""


# ---------------------------------------------------------------------------
# Browser open (injectable for tests)
# ---------------------------------------------------------------------------

def _open_browser_real(url: str) -> None:
    """Thin wrapper around webbrowser.open – real implementation."""
    import webbrowser
    webbrowser.open(url)


# ---------------------------------------------------------------------------
# OS media keys (Windows only)
# ---------------------------------------------------------------------------

#  VK codes from winuser.h
_VK_MEDIA_PLAY_PAUSE = 0xB3
_VK_MEDIA_STOP = 0xB2
_VK_MEDIA_NEXT_TRACK = 0xB0
_VK_MEDIA_PREV_TRACK = 0xB1

# INPUT / KEYBDINPUT constants
_INPUT_KEYBOARD = 1
_KEYEVENTF_KEYUP = 0x0002

# seek amounts expressed as volume-key repeats is non-standard;
# we skip seek on systems that don't support it cleanly.

_MEDIA_KEY_MAP: dict[str, int] = {
    "play": _VK_MEDIA_PLAY_PAUSE,
    "pause": _VK_MEDIA_PLAY_PAUSE,
    "play_pause": _VK_MEDIA_PLAY_PAUSE,
    "toggle": _VK_MEDIA_PLAY_PAUSE,
    "stop": _VK_MEDIA_STOP,
    "next": _VK_MEDIA_NEXT_TRACK,
    "next_track": _VK_MEDIA_NEXT_TRACK,
    "previous": _VK_MEDIA_PREV_TRACK,
    "prev": _VK_MEDIA_PREV_TRACK,
    "prev_track": _VK_MEDIA_PREV_TRACK,
    "back": _VK_MEDIA_PREV_TRACK,
}


def _send_media_key_windows(vk: int, open_browser_fn=None) -> None:  # noqa: ARG001
    """Send a keydown+keyup pair for *vk* via SendInput on Windows."""
    import ctypes
    import ctypes.wintypes

    # KEYBDINPUT
    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [
            ("wVk", ctypes.wintypes.WORD),
            ("wScan", ctypes.wintypes.WORD),
            ("dwFlags", ctypes.wintypes.DWORD),
            ("time", ctypes.wintypes.DWORD),
            ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
        ]

    class _INPUT_UNION(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", ctypes.wintypes.DWORD), ("_", _INPUT_UNION)]

    def _make(vk_code: int, flags: int) -> INPUT:
        inp = INPUT()
        inp.type = _INPUT_KEYBOARD
        inp._.ki.wVk = vk_code
        inp._.ki.dwFlags = flags
        return inp

    inputs = (_make(vk, 0), _make(vk, _KEYEVENTF_KEYUP))
    arr = (INPUT * 2)(*inputs)
    sent = ctypes.windll.user32.SendInput(2, arr, ctypes.sizeof(INPUT))
    if sent != 2:
        raise MediaError("SendInput did not deliver all key events")


def send_media_key(action: str, *, _open_browser_fn=None, _send_key_fn=None) -> dict:
    """Send a media key event.

    Parameters
    ----------
    action:
        One of ``play``, ``pause``, ``play_pause``, ``toggle``, ``stop``,
        ``next``, ``next_track``, ``previous``, ``prev``, ``prev_track``,
        ``back``.
    _open_browser_fn, _send_key_fn:
        Injected in tests so no real OS calls happen.

    Returns a dict with ``action`` and ``sent=True`` on success.
    Raises :class:`MediaError` on unsupported platforms or bad action names.
    """
    action_key = action.strip().lower()
    if action_key not in _MEDIA_KEY_MAP:
        valid = ", ".join(sorted(_MEDIA_KEY_MAP))
        raise MediaError(f"Unknown media action '{action}'. Valid: {valid}")

    vk = _MEDIA_KEY_MAP[action_key]

    if sys.platform != "win32":
        raise MediaError(
            f"OS media keys are only supported on Windows (current platform: {sys.platform}). "
            "Use play_youtube to open the media in a browser instead."
        )

    send_fn = _send_key_fn if _send_key_fn is not None else _send_media_key_windows
    send_fn(vk)
    return {"action": action_key, "sent": True}


# ---------------------------------------------------------------------------
# Seek (expressed in seconds – best-effort via URL fragment; no JS)
# ---------------------------------------------------------------------------

def seek_youtube_url(url: str, seconds: int) -> str:
    """Append a ``#t=Ns`` fragment to a YouTube watch URL so the browser
    jumps to the requested position.  Only modifies *url* if it is a valid
    YouTube watch URL; returns it unchanged otherwise."""
    if not _is_youtube_url(url):
        raise MediaError("seek requires a youtube.com/youtu.be URL")
    p = urlparse(url)
    if "watch" not in p.path and p.netloc != "youtu.be":
        raise MediaError("seek is only supported on /watch URLs")
    seconds = max(0, int(seconds))
    return f"{url.split('#')[0]}#t={seconds}s"


# ---------------------------------------------------------------------------
# High-level tool entry points (importable by service.py)
# ---------------------------------------------------------------------------

def media_control(action: str, *, _open_browser_fn=None, _send_key_fn=None) -> dict:
    """Dispatch a media transport action.  Thin alias for :func:`send_media_key`."""
    return send_media_key(action, _open_browser_fn=_open_browser_fn, _send_key_fn=_send_key_fn)


def play_youtube(
    query: str = "",
    video_id: str = "",
    url: str = "",
    *,
    _open_browser_fn=None,
) -> dict:
    """Open YouTube in the default browser.

    Accepts one of:
    * ``query``    – free-text search (opens youtube.com/results)
    * ``video_id`` – 11-character YouTube video ID (opens watch URL)
    * ``url``      – a fully-formed youtube.com / youtu.be URL (validated)

    The caller-supplied ``url`` must be a youtube.com / youtu.be https link;
    any other domain raises :class:`MediaError`.

    No downloading, scraping, DRM bypass, or ad bypass occurs.
    """
    if url:
        final_url = validate_direct_url(url)
    elif video_id:
        final_url = build_youtube_url("", video_id=video_id)
        if not _is_youtube_url(final_url):  # shouldn't happen, but guard
            raise MediaError("Generated URL is not a valid YouTube URL")
    elif query:
        final_url = build_youtube_url(query)
    else:
        raise MediaError("Provide a search query, a video_id, or a youtube URL")

    open_fn = _open_browser_fn if _open_browser_fn is not None else _open_browser_real
    open_fn(final_url)
    return {"opened_url": final_url, "query": query or video_id or url}
