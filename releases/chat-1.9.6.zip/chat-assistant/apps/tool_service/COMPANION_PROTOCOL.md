# Companion Extension WebSocket Protocol — Version 1

**Status**: Authoritative server-side specification.  The Python
`companion_bridge.py` module is the single source of truth; this document
describes exactly what it sends, accepts, and rejects.

---

## Overview

The companion extension connects to the loopback-only WebSocket endpoint:

```
ws://127.0.0.1:<port>/ws/companion
```

All frames are **JSON text**.  Binary frames are ignored.  The server
terminates any connection that sends a frame larger than **8 192 bytes**.

A single companion connection is supported at a time.  A new connection
displaces the previous one (the old socket receives a `revoked` frame).

---

## Security constraints

* **Loopback-only**: the server rejects the WebSocket upgrade before it
  completes for any non-loopback client (`127.x.x.x`, `::1`, `localhost`).
  Dashboard `host=0.0.0.0` does not affect this gate.
* **Authentication before anything**: until a valid `hello` is processed,
  only `hello` frames are accepted.  Any other frame type causes an
  `auth_error` and the socket is closed.
* **Server-derived commands only**: the server never reads a URL, hostname,
  video id, playlist id, or free-form command string *from* the extension.
  Every command payload is built server-side from ids the server validated.
* **Ad gate**: while `ad_playing=true` has been received, **every** companion
  command (navigation, transport, next/previous, volume/mute, duck/restore)
  returns a `busy_ad` error without touching the player.  The server-side
  blocked set equals the full action set — strictly a superset of the
  extension's own client-side gate.

---

## Connection lifecycle

```
Extension                          Server
   |                                  |
   |<---- TCP + HTTP upgrade -------->|
   |<---- welcome -------------------|   protocol=1
   |                                  |
   |----> hello (token or secret) --->|   authentication
   |<---- paired (secret, once) ------|   only on first pairing
   |<---- auth_ok --------------------|
   |                                  |
   |   ... authenticated session ...  |
   |                                  |
   |<---- ping (id) -----------------|
   |----> pong (id) ----------------->|
   |                                  |
   |<---- command (id, action, ...) --|
   |----> ack (id, ok, error?) ------>|
   |                                  |
   |----> state (status, ...) ------->|
   |                                  |
   |<---- revoked -------------------|   on rotate/revoke/replaced
   |                                  |
  close                             close
```

---

## Frame reference

### Server → Extension

#### `welcome`
Sent immediately on socket accept, before authentication.

```json
{ "type": "welcome", "protocol": 1 }
```

#### `auth_ok`
Sent after a valid `hello`.

```json
{ "type": "auth_ok", "target": "browser_companion", "session": 3 }
```

| Field     | Type   | Description |
|-----------|--------|-------------|
| `target`  | string | Always `"browser_companion"`. |
| `session` | int    | Current media session counter. |

#### `paired`
Sent **once**, immediately before `auth_ok`, when the connection authenticated
using a one-time pairing token (not a bridge secret).  The extension **must**
persist this secret for all future reconnects.  One-time tokens are never
reused.

```json
{ "type": "paired", "secret": "<high-entropy-urlsafe-base64>" }
```

#### `auth_error`
Sent when authentication fails, immediately before the socket is closed
(code 4401).

```json
{ "type": "auth_error", "reason": "invalid credentials" }
```

#### `command`
A media command.  Every field is server-derived; the extension must send an
`ack` with the same `id`.

```json
{
  "type":    "command",
  "id":      42,
  "session": 3,
  "target":  "browser_companion",
  "action":  "<action>",
  ...payload fields...
}
```

| Field     | Type   | Description |
|-----------|--------|-------------|
| `id`      | int    | Monotonic sequence number; correlates with `ack`. |
| `session` | int    | Current media session. State frames must echo this. |
| `target`  | string | Always `"browser_companion"`. |
| `action`  | string | One of the canonical actions below. |

**Canonical actions and their payload fields**:

| Action               | Payload fields                                      | Notes |
|----------------------|-----------------------------------------------------|-------|
| `navigate_video`     | `video_id` (str), `start_seconds` (float, default 0) | Navigate to a validated video; begin playback. |
| `navigate_playlist`  | `playlist_id` (str)                                 | Navigate to a validated playlist. |
| `play`               | *(none)*                                            | Resume playback if paused. |
| `pause`              | *(none)*                                            | Pause current playback. |
| `stop`               | *(none)*                                            | Stop playback. |
| `next`               | *(none)*                                            | Next item in YouTube's native queue. |
| `previous`           | *(none)*                                            | Previous item. |
| `seek`               | `offset_seconds` (int), `target_seconds` (float)   | Relative seek; target_seconds is the computed absolute position. |
| `restart`            | *(none)*                                            | Seek to the start of the current video (position 0). |
| `set_volume`         | `volume` (int, 0–100)                               | Absolute volume. |
| `adjust_volume`      | `delta` (int, negative to lower)                    | Relative volume change. |
| `mute`               | *(none)*                                            | Mute. |
| `unmute`             | *(none)*                                            | Unmute. |
| `duck`               | `volume` (int, 0–100, optional, default 20)         | Lower volume for voice focus; restore with `restore`. |
| `restore`            | *(none)*                                            | Restore volume/state after duck. |

**Ad gate (block everything)**: when `ad_playing=true` has been most recently
reported, the server returns `{"ok": false, "error": "busy_ad"}` for **every
companion action** — the entire action list above, including `next`,
`previous`, `duck` and `restore` — without sending a `command` frame at all.
The server refuses to touch the player in any way while an ad is running, so a
blocked action never reaches the tab.  This is deliberately **stricter** than
the extension's own client-side `AD_BLOCKED_ACTIONS`: the server is the first
line of defence and the extension is the last.  Formally,
`_AD_BLOCKED_ACTIONS == ALL_COMPANION_ACTIONS` on the server, which is always a
superset of the extension's set.  The extension need not handle this case
specially; the server simply does not call it.

#### `revoked`
Sent before the socket is closed on rotate, revoke, or displacement.

```json
{ "type": "revoked", "reason": "rotated" }
```

The extension must forget its bridge secret and stop reconnecting until
the user re-pairs.

#### `ping`
Liveness check.  Sent every ~20 seconds on an authenticated connection.

```json
{ "type": "ping", "id": 7 }
```

---

### Extension → Server

#### `hello`
Must be the **first** frame after receiving `welcome`.  Exactly one of
`token` or `secret` must be present.

**Initial pairing** (one-time token, shown once by the dashboard):
```json
{ "type": "hello", "token": "<one-time-pairing-token>" }
```

**Reconnect** (persistent bridge secret received in `paired`):
```json
{ "type": "hello", "secret": "<bridge-secret>" }
```

One-time tokens are consumed on first use.  Subsequent connections must use
the bridge secret.

#### `ack`
Acknowledge a command.  Must reference the command's `id`.

```json
{ "type": "ack", "id": 42, "ok": true }
```
```json
{ "type": "ack", "id": 42, "ok": false, "error": "not_navigable" }
```

| Field   | Type   | Description |
|---------|--------|-------------|
| `id`    | int    | Must match the `command` frame's `id`. |
| `ok`    | bool   | `true` if the command was executed. |
| `error` | string | Optional error code when `ok=false`. |

The server waits up to **6 seconds** for an ack.  Timeout raises an error in
the tool and the command is treated as failed.

#### `state`
Authoritative playback state.  May be sent at any time after authentication.

```json
{
  "type":             "state",
  "session":          3,
  "target":           "browser_companion",
  "status":           "playing",
  "video_id":         "dQw4w9WgXcQ",
  "position_seconds": 42.5,
  "duration_seconds": 212.0,
  "volume":           85,
  "muted":            false,
  "ad_playing":       false
}
```

| Field              | Type            | Required | Description |
|--------------------|-----------------|----------|-------------|
| `session`          | int             | **yes**  | Must match the server's current session or frame is dropped. |
| `target`           | string          | **yes**  | Must be `"browser_companion"` or frame is dropped. |
| `status`           | string          | **yes**  | One of `playing`, `paused`, `ended`, `buffering`, `stopped`, `error`. |
| `video_id`         | string (≤64)    | no       | Current video id (server uses for matching only, never to derive URLs). |
| `position_seconds` | float (0–86400) | no       | Current playback position. |
| `duration_seconds` | float (0–86400) | no       | Total duration. |
| `volume`           | int (0–100)     | no       | Current volume. |
| `muted`            | bool            | no       | Muted state. |
| `ad_playing`       | bool            | no       | **True when a YouTube ad is currently playing.**  Omit or set false otherwise.  When true the server blocks **every** companion command (navigation, transport, next/previous, volume/mute, and duck/restore). |

**Fencing rules** (server drops the frame silently if violated):
1. `target` ≠ `"browser_companion"`.
2. `session` ≠ current server session.
3. `status` not in the valid set.

The server never reads `url`, `host`, `command`, or any other field not in
the allowlist above.

#### `pong`
Response to a `ping`.

```json
{ "type": "pong", "id": 7 }
```

---

## Pairing flow (dashboard)

1. Dashboard owner (authenticated + loopback) calls `POST /api/companion/pair`.
2. Server mints a one-time token and shows it **once**.
3. Owner enters token in the extension's options page.
4. Extension opens `ws://127.0.0.1:<port>/ws/companion` and sends
   `{"type":"hello","token":"<token>"}`.
5. Server validates, consumes the token, sends `paired` (bridge secret) then
   `auth_ok`.
6. Extension persists the bridge secret for future reconnects.
7. All future connections: `{"type":"hello","secret":"<bridge-secret>"}`.

---

## Rotate / revoke (dashboard)

| Action  | Endpoint                     | Effect |
|---------|------------------------------|--------|
| Rotate  | `POST /api/companion/rotate` | Drops the current secret, disconnects live extension, issues a new pairing token.  Extension must re-pair. |
| Revoke  | `POST /api/companion/revoke` | Drops everything; extension receives `revoked` and must stop. |

Both endpoints require dashboard authentication + CSRF and are loopback-only.

---

## Voice-focus duck/restore

When the server detects verified user speech (conversation mode or confirmed
wake hit) while companion media is playing, it may send:

```json
{"type":"command","id":N,"session":S,"target":"browser_companion","action":"duck","volume":20}
```

When the voice session ends or the user explicitly resumes:

```json
{"type":"command","id":N,"session":S,"target":"browser_companion","action":"restore"}
```

**Restore is only sent if Jarvis initiated the duck** and no explicit media
command (pause, stop, play, navigate, seek, restart, set/adjust volume, mute,
unmute, next, previous) has superseded it.  The extension should restore to its
pre-duck volume on `restore`; the server does not track the pre-duck volume.

Duck and restore **are** blocked during ad playback (see the strict ad gate
above): the server sends nothing to the player while an ad runs.

### Ownership generation + serialized command lock

The server guarantees that an explicit media command **always wins** a race
against a delayed voice-focus operation.  The mechanism:

* A monotonic **ownership generation** counter is incremented
  **synchronously** (before any `await`) at the start of **every** explicit
  media command: `navigate_video`, `navigate_playlist`, `play`, `pause`,
  `stop`, `seek`, `restart`, `next`, `previous`, `set_volume`,
  `adjust_volume`, `mute`, `unmute`.  The same synchronous step clears the
  "Jarvis ducked" flag.
* Each voice-focus op (`duck`, `pause`, `restore`) **captures** the generation
  before its first `await`, then re-checks it **under a per-companion command
  lock** immediately before dispatch and again before committing local state.
  If the generation advanced, the voice op aborts: it sends nothing and
  mutates no volume/mute/pause state.
* All companion command dispatch is serialized by the command lock, so the
  generation check and the send/commit are atomic with respect to other
  commands.

Consequences (all covered by deterministic race tests):

* A **session-end `restore` after any explicit command** is a guaranteed
  no-op — it never unmutes and never changes volume.
* **Stop / new media always wins**: a duck/pause/restore in flight when the
  user stops or navigates has no effect on the new media.
* An explicit `mute`/`set_volume`/`pause`/`stop`/`navigate` racing a delayed
  `restore` leaves the explicit command's effect intact.

---

## Best-effort limitations

* **Ad detection**: the server relies on the extension to honestly report
  `ad_playing`.  A missed report means a blocked command attempt, not a
  crash; the command simply fails with `busy_ad` or the normal ack failure.
* **Voice-focus pause**: conservative gate-based detection means a near-silent
  utterance may not trigger duck/restore, and a very song-like vocal may
  briefly trigger it.  These are best-effort; wake listening remains active
  throughout.
* **Network**: the companion bridge is loopback-only, so latency is
  negligible; however a slow extension ack can still trigger the 6 s timeout.
