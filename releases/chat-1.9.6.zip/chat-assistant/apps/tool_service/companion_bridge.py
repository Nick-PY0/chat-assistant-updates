"""Local-only, authenticated bridge to the opt-in YouTube companion extension.

Threat model & security posture
--------------------------------
This module lets an *opt-in*, locally-installed browser extension become a
first-class YouTube playback surface (the ``browser_companion`` playback mode)
for regular YouTube tabs the user already has open, without Selenium, without
downloads, and without any ad/DRM interference.  It is intentionally locked
down:

* **Loopback only.**  The companion WebSocket is only ever served on the
  dashboard's own origin.  The dashboard endpoint that upgrades to the
  companion protocol rejects any non-loopback client (``127.0.0.0/8`` / ``::1``)
  *before* upgrading, regardless of ``dashboard_host``.  A LAN device can reach
  the password-protected dashboard, but never the companion bridge.

* **Explicit one-time pairing.**  The extension cannot connect until the owner
  generates a pairing token *in the dashboard* (authenticated + CSRF-protected)
  and pastes it into the extension.  The token is a high-entropy secret, stored
  server-side as a salted hash only, compared in constant time, and consumed on
  first successful use (converted into a long-lived rotating *bridge secret*
  that the extension keeps for all future reconnects).  The plaintext pairing
  token is shown **once** and never persisted in the clear.

* **Reconnect uses only the bridge secret.**  After the initial pairing the
  extension reconnects with its persistent bridge secret; one-time tokens are
  never reused.

* **Rotate / revoke.**  The owner can rotate (invalidate the old secret, mint a
  new pairing token) or fully revoke (drop the secret, disconnect the
  extension) at any time from the authenticated Settings panel.

* **Authenticate before anything.**  A freshly-connected socket is in the
  ``unauthenticated`` state and may ONLY send a ``hello`` frame carrying the
  bridge secret (or a fresh pairing token during initial pairing).  No command
  acknowledgement, no state event, and no media control is accepted until the
  socket has authenticated.  A short auth deadline closes idle sockets.

* **Server-derived targets only.**  The extension is NEVER trusted to supply a
  URL, host, video id, playlist id, or free-form command.  Every command the
  server sends is built from ids the server itself validated via
  ``extract_video_id`` / ``extract_playlist_id``.  Inbound state events are
  bounded, type-checked, and — critically — matched against the server's own
  ``media_session``, ``target`` (media-session / target fencing), and active
  ``video_id``: a state event that names a stale session, a non-owning target,
  or an unexpected video id is dropped.

* **Ad-blocked actions.**  When the companion reports ``ad_playing=true`` the
  server rejects every action command (navigate/play/pause/seek/volume/mute)
  via a ``busy_ad`` error ack so the extension and YouTube remain unimpeded.

Protocol version: 1  (see COMPANION_PROTOCOL.md for the full spec)
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import ipaddress
import json
import secrets
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


PROTOCOL_VERSION = 1

# Setting keys (persisted via Database.set_setting / get_setting).
_SETTING_PAIRING_HASH = "companion_pairing_hash"    # sha256 of the salt+token
_SETTING_PAIRING_SALT = "companion_pairing_salt"    # per-token random salt
_SETTING_SECRET_HASH  = "companion_secret_hash"     # sha256 of salt+bridge secret
_SETTING_SECRET_SALT  = "companion_secret_salt"

# Timeouts / bounds.
AUTH_DEADLINE_SECONDS     = 10.0
PING_INTERVAL_SECONDS     = 20.0
COMMAND_ACK_TIMEOUT       = 6.0
MAX_FRAME_BYTES           = 8192
MAX_INFLIGHT_COMMANDS     = 32

# Canonical command action names (server → extension).
#
# These MUST match the COMPANION_ACTIONS array in the extension's common.js.
# The cross-language contract test (tests/test_companion_contract.py) reads
# common.js directly and asserts every constant below is present in the JS
# array, so any drift fails Python CI immediately.
#
# Navigation actions: the extension navigates the YouTube tab to a canonical
# URL it constructs itself from the server-supplied validated id.
CMD_NAVIGATE_VIDEO    = "navigate_video"    # video_id (str), start_seconds (float)
CMD_NAVIGATE_PLAYLIST = "navigate_playlist" # playlist_id (str)
# Transport actions (resume/state control, no id).
CMD_PLAY              = "play"              # resume playback (no id)
CMD_PAUSE             = "pause"
CMD_STOP              = "stop"
CMD_NEXT              = "next"
CMD_PREVIOUS          = "previous"
CMD_SEEK              = "seek"              # offset_seconds (int), target_seconds (float)
CMD_RESTART           = "restart"
CMD_SET_VOLUME        = "set_volume"        # volume (int, 0–100)
CMD_ADJUST_VOLUME     = "adjust_volume"     # delta (int)
CMD_MUTE              = "mute"
CMD_UNMUTE            = "unmute"
CMD_DUCK              = "duck"              # volume (int, optional, default 20)
CMD_RESTORE           = "restore"

# Full set of actions the extension's COMPANION_ACTIONS array accepts.
# Must exactly match common.js COMPANION_ACTIONS; verified by the contract test.
ALL_COMPANION_ACTIONS: frozenset[str] = frozenset({
    CMD_NAVIGATE_VIDEO, CMD_NAVIGATE_PLAYLIST,
    CMD_PLAY, CMD_PAUSE, CMD_STOP,
    CMD_NEXT, CMD_PREVIOUS,
    CMD_SEEK, CMD_RESTART,
    CMD_SET_VOLUME, CMD_ADJUST_VOLUME,
    CMD_MUTE, CMD_UNMUTE,
    CMD_DUCK, CMD_RESTORE,
})

_VALID_STATUS = frozenset(
    {"playing", "paused", "ended", "buffering", "stopped", "error"}
)

# Commands that must be blocked during an active YouTube ad.
#
# The server enforces a STRICTER policy than the extension: EVERY companion
# media command is rejected while an ad is playing, including next/previous
# (which would skip within an ad-interrupted stream) and duck/restore (whose
# volume side effects on the ad player are undesirable and racy).  This is a
# superset of common.js AD_BLOCKED_ACTIONS — the extension is the last line of
# defence, but the server refuses to emit any command at all during an ad so a
# blocked action never reaches the tab.  The cross-language contract test
# asserts this set is a superset of common.js AD_BLOCKED_ACTIONS.
_AD_BLOCKED_ACTIONS = ALL_COMPANION_ACTIONS


class CompanionError(Exception):
    """Safe companion-bridge error (may be shown to the user)."""


class CompanionSocket(Protocol):
    """Minimal duck-typed interface for a WebSocket text channel."""

    async def send_text(self, data: str) -> None: ...
    async def receive_text(self) -> str: ...
    async def close(self, code: int = 1000, reason: str | None = None) -> None: ...


def _hash(salt: str, value: str) -> str:
    return hashlib.sha256(f"{salt}:{value}".encode()).hexdigest()


@dataclass
class _Connection:
    """One authenticated companion socket."""

    socket: CompanionSocket
    authenticated: bool = False
    target_id: str = ""
    connected_at: float = field(default_factory=time.monotonic)
    last_seen: float = field(default_factory=time.monotonic)
    pending_acks: dict[int, asyncio.Future] = field(default_factory=dict)


class CompanionBridge:
    """Owns pairing, authentication, and the companion message protocol.

    A single companion connection is supported at a time.  The bridge exposes
    ``send_command`` used by :class:`YouTubeTool` and an inbound state callback
    that feeds authoritative, ad-gated, fenced player state back to tool state.

    Ad state
    --------
    When the extension reports ``ad_playing=true`` in a state frame the bridge
    records it and rejects every blocked action with a ``busy_ad`` error ack,
    leaving YouTube's ad playback completely unimpeded.  The flag clears
    automatically when the next state frame carries ``ad_playing=false`` (or
    omits the field), so that normal commands resume immediately after the ad.
    """

    TARGET_ID = "browser_companion"

    def __init__(
        self,
        db,
        bus,
        *,
        on_state: Callable[[dict], None] | None = None,
        now: Callable[[], float] = time.monotonic,
    ) -> None:
        self.db = db
        self.bus = bus
        self._on_state = on_state
        self._now = now
        self._conn: _Connection | None = None
        self._command_seq = 0
        self._session = 0
        self._ad_playing = False          # authoritative ad flag from extension
        self._last_issued_token: str = ""

    # ------------------------------------------------------------------
    # Loopback enforcement
    # ------------------------------------------------------------------
    @staticmethod
    def is_loopback_host(host: str) -> bool:
        """True only for a genuine loopback client address."""
        host = (host or "").strip()
        if host == "localhost":
            return True
        host = host.strip("[]").split("%", 1)[0]
        try:
            return ipaddress.ip_address(host).is_loopback
        except ValueError:
            return False

    # ------------------------------------------------------------------
    # Pairing token lifecycle
    # ------------------------------------------------------------------
    async def is_paired(self) -> bool:
        return bool(await self.db.get_setting(_SETTING_SECRET_HASH))

    async def has_pending_pairing(self) -> bool:
        return bool(await self.db.get_setting(_SETTING_PAIRING_HASH))

    async def issue_pairing_token(self) -> str:
        """Mint a new one-time pairing token; store only its salted hash.

        Issuing a new token invalidates any previously-issued (but not yet
        consumed) token.  An already-established bridge secret is NOT dropped
        until the new token is consumed, so an in-use extension keeps working
        until the owner completes re-pairing.
        """
        token = secrets.token_urlsafe(32)
        salt = secrets.token_hex(16)
        await self.db.set_setting(_SETTING_PAIRING_SALT, salt)
        await self.db.set_setting(_SETTING_PAIRING_HASH, _hash(salt, token))
        self._last_issued_token = token
        await self.db.log("INFO", "companion", "pairing token issued")
        return token

    async def rotate(self) -> str:
        """Invalidate the current bridge secret; mint a new pairing token.

        Any live connection is dropped: the extension must re-pair.
        """
        await self._drop_secret()
        await self._disconnect(reason="rotated")
        await self.db.log("INFO", "companion", "companion bridge rotated")
        return await self.issue_pairing_token()

    async def revoke(self) -> None:
        """Fully revoke: drop the secret, pending token, and the connection."""
        await self._drop_secret()
        await self.db.delete_setting(_SETTING_PAIRING_HASH)
        await self.db.delete_setting(_SETTING_PAIRING_SALT)
        self._last_issued_token = ""
        await self._disconnect(reason="revoked")
        await self.db.log("INFO", "companion", "companion bridge revoked")

    async def _drop_secret(self) -> None:
        await self.db.delete_setting(_SETTING_SECRET_HASH)
        await self.db.delete_setting(_SETTING_SECRET_SALT)

    async def _consume_pairing(self, token: str) -> str:
        """Validate a one-time pairing token and mint a persistent bridge secret.

        Returns the plaintext bridge secret (given once to the extension so it
        can reconnect without re-pairing) and clears the pending pairing token.
        The token is one-time: calling again after it has been consumed raises
        :class:`CompanionError`.
        """
        stored_hash = await self.db.get_setting(_SETTING_PAIRING_HASH)
        salt        = await self.db.get_setting(_SETTING_PAIRING_SALT)
        if not stored_hash or not salt:
            raise CompanionError("no pairing is pending")
        if not hmac.compare_digest(_hash(salt, str(token or "")), stored_hash):
            raise CompanionError("invalid pairing token")
        # Consume the one-time token.
        await self.db.delete_setting(_SETTING_PAIRING_HASH)
        await self.db.delete_setting(_SETTING_PAIRING_SALT)
        self._last_issued_token = ""
        # Mint the persistent rotating bridge secret.
        secret      = secrets.token_urlsafe(32)
        secret_salt = secrets.token_hex(16)
        await self.db.set_setting(_SETTING_SECRET_SALT, secret_salt)
        await self.db.set_setting(_SETTING_SECRET_HASH, _hash(secret_salt, secret))
        await self.db.log("INFO", "companion", "companion paired")
        return secret

    async def _verify_secret(self, secret: str) -> bool:
        stored_hash = await self.db.get_setting(_SETTING_SECRET_HASH)
        salt        = await self.db.get_setting(_SETTING_SECRET_SALT)
        if not stored_hash or not salt:
            return False
        return hmac.compare_digest(_hash(salt, str(secret or "")), stored_hash)

    # ------------------------------------------------------------------
    # Connection state
    # ------------------------------------------------------------------
    @property
    def connected(self) -> bool:
        return self._conn is not None and self._conn.authenticated

    @property
    def ad_playing(self) -> bool:
        """True when the extension has reported an active YouTube ad."""
        return self._ad_playing

    def status(self) -> dict:
        """Safe, secret-free status dict for the dashboard."""
        return {
            "connected": self.connected,
            "session": self._session,
            "target": self.TARGET_ID,
            "ad_playing": self._ad_playing,
        }

    async def _disconnect(self, *, reason: str) -> None:
        conn = self._conn
        if conn is None:
            return
        self._conn = None
        self._ad_playing = False
        for fut in list(conn.pending_acks.values()):
            if not fut.done():
                fut.cancel()
        conn.pending_acks.clear()
        try:
            await conn.socket.send_text(
                json.dumps({"type": "revoked", "reason": reason})
            )
        except Exception:
            pass
        try:
            await conn.socket.close(code=1000, reason=reason[:120])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Session / target fencing
    # ------------------------------------------------------------------
    def bump_session(self) -> int:
        """Advance the media session counter.

        Called by :class:`YouTubeTool` whenever it starts a new companion play,
        stop, or mode transition.  State frames with an older session are stale.
        """
        self._session += 1
        return self._session

    @property
    def session(self) -> int:
        return self._session

    # ------------------------------------------------------------------
    # Outbound commands (server → extension)
    # ------------------------------------------------------------------
    async def send_command(self, action: str, **args: Any) -> dict:
        """Send a *server-derived* command to the companion and await its ack.

        Ad guard: if the companion has reported ``ad_playing`` and the requested
        action is in ``_AD_BLOCKED_ACTIONS``, return ``{"ok": False,
        "error": "busy_ad"}`` immediately without sending anything.

        Returns ``{"ok": bool, "error": str}``.  Raises :class:`CompanionError`
        if no companion is connected or it does not ack in time.

        Every payload field is server-derived; the extension never supplies ids,
        URLs, or commands.  The frame shape is::

            {
              "type":    "command",
              "id":      <monotonic int>,
              "session": <int>,
              "target":  "browser_companion",
              "action":  "<action>",
              ... validated args ...
            }
        """
        conn = self._conn
        if conn is None or not conn.authenticated:
            raise CompanionError("no companion is connected")

        # Ad guard: reject blocked actions while an ad is playing.
        if self._ad_playing and action in _AD_BLOCKED_ACTIONS:
            return {"ok": False, "error": "busy_ad"}

        if len(conn.pending_acks) >= MAX_INFLIGHT_COMMANDS:
            raise CompanionError("too many in-flight companion commands")

        self._command_seq += 1
        cmd_id = self._command_seq
        frame = {
            "type":    "command",
            "id":      cmd_id,
            "session": self._session,
            "target":  self.TARGET_ID,
            "action":  action,
            **args,
        }
        loop = asyncio.get_event_loop()
        fut: asyncio.Future = loop.create_future()
        conn.pending_acks[cmd_id] = fut
        try:
            await conn.socket.send_text(json.dumps(frame))
        except Exception as exc:
            conn.pending_acks.pop(cmd_id, None)
            await self._disconnect(reason="transport error")
            raise CompanionError("companion connection lost") from exc
        try:
            ack = await asyncio.wait_for(fut, timeout=COMMAND_ACK_TIMEOUT)
        except asyncio.TimeoutError as exc:
            conn.pending_acks.pop(cmd_id, None)
            raise CompanionError("companion did not acknowledge the command") from exc
        finally:
            conn.pending_acks.pop(cmd_id, None)
        return ack

    # ------------------------------------------------------------------
    # Inbound frame handling (extension → server)
    # ------------------------------------------------------------------
    async def handle(self, socket: CompanionSocket) -> None:
        """Drive one companion connection until it closes.

        Must only be called after the caller has verified the client is on a
        loopback address.  Manages auth, ping/pong, acks, and state frames.
        """
        # Displace any previously-connected companion.
        if self._conn is not None:
            await self._disconnect(reason="replaced by a new companion")
        conn = _Connection(socket=socket)
        self._conn = conn
        try:
            await socket.send_text(
                json.dumps({"type": "welcome", "protocol": PROTOCOL_VERSION})
            )
        except Exception:
            self._conn = None
            return

        ping_task = asyncio.ensure_future(self._ping_loop(conn))
        try:
            while self._conn is conn:
                if not conn.authenticated:
                    remaining = AUTH_DEADLINE_SECONDS - (self._now() - conn.connected_at)
                    if remaining <= 0:
                        await self._reject(conn, "authentication timed out")
                        return
                    try:
                        raw = await asyncio.wait_for(
                            socket.receive_text(), timeout=remaining
                        )
                    except asyncio.TimeoutError:
                        await self._reject(conn, "authentication timed out")
                        return
                else:
                    raw = await socket.receive_text()

                if len(raw) > MAX_FRAME_BYTES:
                    await self._reject(conn, "frame too large")
                    return
                try:
                    frame = json.loads(raw)
                except (TypeError, ValueError):
                    if not conn.authenticated:
                        await self._reject(conn, "malformed frame")
                        return
                    continue
                if not isinstance(frame, dict):
                    continue
                conn.last_seen = self._now()
                await self._dispatch_frame(conn, frame)
        except (asyncio.CancelledError, Exception):
            pass
        finally:
            ping_task.cancel()
            try:
                await ping_task
            except (asyncio.CancelledError, Exception):
                pass
            if self._conn is conn:
                self._conn = None
                self._ad_playing = False
            for fut in list(conn.pending_acks.values()):
                if not fut.done():
                    fut.cancel()
            conn.pending_acks.clear()

    async def _reject(self, conn: _Connection, reason: str) -> None:
        try:
            await conn.socket.send_text(
                json.dumps({"type": "auth_error", "reason": reason})
            )
        except Exception:
            pass
        try:
            await conn.socket.close(code=4401, reason=reason[:120])
        except Exception:
            pass
        if self._conn is conn:
            self._conn = None

    async def _dispatch_frame(self, conn: _Connection, frame: dict) -> None:
        ftype = str(frame.get("type", ""))

        if not conn.authenticated:
            if ftype != "hello":
                await self._reject(conn, "authentication required")
                return
            await self._handle_hello(conn, frame)
            return

        if ftype == "ack":
            self._handle_ack(conn, frame)
        elif ftype == "state":
            self._handle_state(conn, frame)
        elif ftype == "pong":
            pass  # last_seen already updated
        # Unknown authenticated frame types are silently dropped; the server
        # never accepts URLs, hosts, or commands FROM the extension.

    async def _handle_hello(self, conn: _Connection, frame: dict) -> None:
        """Handle the initial hello frame (pairing token or bridge secret)."""
        token  = frame.get("token")
        secret = frame.get("secret")
        try:
            if token is not None:
                # One-time pairing path: consumes the token, mints a persistent secret.
                minted = await self._consume_pairing(str(token))
                # Send the bridge secret BEFORE auth_ok so the extension can
                # persist it synchronously.
                await conn.socket.send_text(
                    json.dumps({"type": "paired", "secret": minted})
                )
                conn.authenticated = True
            elif secret is not None and await self._verify_secret(str(secret)):
                # Reconnect path: extension already has the persistent secret.
                conn.authenticated = True
            else:
                await self._reject(conn, "invalid credentials")
                return
        except CompanionError as exc:
            await self._reject(conn, str(exc))
            return

        conn.target_id = self.TARGET_ID
        await conn.socket.send_text(
            json.dumps({
                "type":    "auth_ok",
                "target":  self.TARGET_ID,
                "session": self._session,
            })
        )
        self.bus.publish("companion_state", connected=True)

    def _handle_ack(self, conn: _Connection, frame: dict) -> None:
        """Resolve a pending command future with the ack result."""
        try:
            cmd_id = int(frame.get("id"))
        except (TypeError, ValueError):
            return
        fut = conn.pending_acks.get(cmd_id)
        if fut is not None and not fut.done():
            fut.set_result({
                "ok":    bool(frame.get("ok", False)),
                "error": str(frame.get("error", ""))[:200],
            })

    def _handle_state(self, conn: _Connection, frame: dict) -> None:
        """Ingest a bounded, session/target-fenced state event.

        Fencing rules (all must pass or the frame is dropped):
          1. ``target`` must equal ``TARGET_ID`` ("browser_companion").
          2. ``session`` must equal the current ``_session``.
          3. ``status`` must be a known playback status string.

        The ``ad_playing`` field is extracted unconditionally on any valid
        fenced state frame; it controls whether subsequent commands are allowed.

        Only a strict allowlist of fields is copied into the clean event dict;
        no URL, host, command, or free-form string ever reaches ``on_state``.
        """
        # 1. Target fencing.
        if str(frame.get("target", "")) != self.TARGET_ID:
            return
        # 2. Session fencing.
        reported_session = frame.get("session")
        try:
            if int(reported_session) != self._session:
                return
        except (TypeError, ValueError):
            return
        # 3. Status must be known.
        status = str(frame.get("status", "")).strip().lower()
        if status not in _VALID_STATUS:
            return

        # Extract ad_playing unconditionally — it's a safety signal even if
        # the rest of state is unchanged.
        ad_raw = frame.get("ad_playing")
        if isinstance(ad_raw, bool):
            self._ad_playing = ad_raw
        elif ad_raw is None:
            # Absence means not in an ad (extension omits when false).
            self._ad_playing = False

        clean: dict[str, Any] = {"status": status, "session": self._session,
                                  "ad_playing": self._ad_playing}
        # Bounded numeric fields.
        for key, lo, hi in (
            ("position_seconds", 0.0, 86400.0),
            ("duration_seconds", 0.0, 86400.0),
        ):
            if key in frame:
                try:
                    clean[key] = max(lo, min(hi, float(frame[key])))
                except (TypeError, ValueError):
                    return   # malformed numeric — drop entire frame
        # Volume.
        if "volume" in frame:
            try:
                clean["volume"] = max(0, min(100, int(frame["volume"])))
            except (TypeError, ValueError):
                return
        # Muted flag.
        if "muted" in frame and isinstance(frame["muted"], bool):
            clean["muted"] = frame["muted"]
        # video_id: only used to *match* the server's own active id; bounded
        # and never used to derive a URL.
        vid = frame.get("video_id")
        if isinstance(vid, str) and vid:
            clean["video_id"] = vid[:64]

        # playlist_id: only used to *match* the server's own active playlist id;
        # bounded and never used to derive a URL.
        pid = frame.get("playlist_id")
        if isinstance(pid, str) and pid:
            clean["playlist_id"] = pid[:64]

        if self._on_state is not None:
            self._on_state(clean)

    async def _ping_loop(self, conn: _Connection) -> None:
        seq = 0
        while self._conn is conn:
            await asyncio.sleep(PING_INTERVAL_SECONDS)
            if self._conn is not conn or not conn.authenticated:
                continue
            seq += 1
            try:
                await conn.socket.send_text(
                    json.dumps({"type": "ping", "id": seq})
                )
            except Exception:
                await self._disconnect(reason="ping failed")
                return
