"""Fan-out of Chat's output audio to dashboard listeners (e.g. your phone).

Every browser that opens the "Listen on this device" control subscribes
here over a WebSocket and receives the same 24 kHz PCM16 mono stream that
goes to the speakers. Bounded queues with drop-oldest keep a slow phone
from ever blocking the assistant.

Used from the asyncio event loop only (never from audio callbacks).
"""

from __future__ import annotations

import asyncio

RATE = 24000  # every broadcast frame is PCM16 mono at this rate


class AudioBroadcast:
    def __init__(self) -> None:
        self._subs: set[asyncio.Queue] = set()

    @property
    def has_listeners(self) -> bool:
        return bool(self._subs)

    @property
    def listener_count(self) -> int:
        return len(self._subs)

    def subscribe(self, maxsize: int = 256) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        self._subs.discard(q)

    def publish(self, pcm: bytes) -> None:
        if not pcm:
            return
        for q in self._subs:
            self._offer(q, ("pcm", pcm))

    def clear(self) -> None:
        """Stop pressed / interruption: flush queued audio on every listener."""
        for q in self._subs:
            while not q.empty():
                try:
                    q.get_nowait()
                except asyncio.QueueEmpty:
                    break
            self._offer(q, ("clear", b""))

    @staticmethod
    def _offer(q: asyncio.Queue, item: tuple[str, bytes]) -> None:
        if q.full():
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            q.put_nowait(item)
        except asyncio.QueueFull:
            pass


def resample_pcm16(pcm: bytes, src_rate: int, dst_rate: int) -> bytes:
    """Nearest-sample mono PCM16 resampler with no dependencies.
    Fine for short announcement clips; Gemini audio is already 24 kHz."""
    if src_rate == dst_rate or src_rate <= 0 or dst_rate <= 0:
        return pcm
    import array

    a = array.array("h")
    a.frombytes(pcm[: (len(pcm) // 2) * 2])
    n = int(len(a) * dst_rate / src_rate)
    if n <= 0 or not len(a):
        return b""
    out = array.array("h", bytes(2 * n))
    step = len(a) / n
    for i in range(n):
        out[i] = a[int(i * step)]
    return out.tobytes()
