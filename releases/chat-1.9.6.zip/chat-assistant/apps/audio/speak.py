"""Offline text-to-speech for dynamic sentences (reminder messages, weather).

Uses pyttsx3 (Windows' built-in voices) when installed; returns None when it
is not available so callers can fall back to a canned announcement. Blocking
-- run through asyncio.to_thread.
"""

from __future__ import annotations

import logging
import os
import tempfile

log = logging.getLogger("speak")


def synth_text(text: str) -> tuple[bytes, int] | None:
    """Render text to (pcm16 mono bytes, sample_rate), or None if no TTS."""
    text = " ".join(str(text or "").split())[:400]
    if not text:
        return None
    try:
        import pyttsx3  # optional dependency (requirements-voice.txt)
    except Exception:
        return None
    path = ""
    try:
        fd, path = tempfile.mkstemp(suffix=".wav", prefix="chat_say_")
        os.close(fd)
        engine = pyttsx3.init()
        engine.save_to_file(text, path)
        engine.runAndWait()
        try:
            engine.stop()
        except Exception:
            pass
        import wave

        with wave.open(path, "rb") as w:
            rate = w.getframerate()
            channels = w.getnchannels()
            width = w.getsampwidth()
            pcm = w.readframes(w.getnframes())
        if width != 2:
            return None  # unexpected format; let the caller fall back
        if channels == 2:  # simple downmix to mono
            mono = bytearray(len(pcm) // 2)
            for i in range(0, len(pcm) - 3, 4):
                left = int.from_bytes(pcm[i : i + 2], "little", signed=True)
                right = int.from_bytes(pcm[i + 2 : i + 4], "little", signed=True)
                mono[i // 2 : i // 2 + 2] = ((left + right) // 2).to_bytes(2, "little", signed=True)
            pcm = bytes(mono)
        return pcm, rate
    except Exception as exc:
        log.debug("offline tts failed: %s", type(exc).__name__)
        return None
    finally:
        if path:
            try:
                os.unlink(path)
            except OSError:
                pass
