"""Loud alarm ring, generated in code (no sound files to download).

One cycle is ~2 seconds: three bright two-tone bell pulses with a fast
tremolo, then a short gap. The runtime loops cycles until the alarm is
dismissed or the ring time limit is reached.
"""

from __future__ import annotations

import array
import math

RING_RATE = 24000
_CACHE: dict[int, bytes] = {}


def build_ring_cycle(volume: float = 1.0) -> bytes:
    """Return one ring cycle as 16-bit mono PCM at RING_RATE."""
    volume = min(1.0, max(0.2, float(volume)))
    key = int(volume * 100)
    cached = _CACHE.get(key)
    if cached is not None:
        return cached

    seconds = 2.0
    n = int(RING_RATE * seconds)
    pulses = ((0.00, 0.38), (0.50, 0.88), (1.00, 1.38))  # start/end seconds
    amp = 32000.0 * volume
    two_pi = 2.0 * math.pi
    samples = array.array("h", bytes(2 * n))

    for start, end in pulses:
        i0, i1 = int(start * RING_RATE), min(int(end * RING_RATE), n)
        length = i1 - i0
        for j in range(length):
            t = j / RING_RATE
            # sharp attack, exponential decay like a struck bell
            env = min(1.0, t / 0.008) * math.exp(-3.2 * t)
            # urgent tremolo
            trem = 1.0 + 0.35 * math.sin(two_pi * 15.0 * t)
            v = (
                0.62 * math.sin(two_pi * 880.0 * t)
                + 0.30 * math.sin(two_pi * 1760.0 * t)
                + 0.08 * math.sin(two_pi * 2640.0 * t)
            )
            s = amp * env * trem * v * 0.72
            samples[i0 + j] = max(-32767, min(32767, int(s)))

    pcm = samples.tobytes()
    _CACHE[key] = pcm
    return pcm
