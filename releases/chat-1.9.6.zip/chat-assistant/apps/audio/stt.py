"""Optional offline speech recognition (vosk) for local-only voice commands.

When every Gemini key is blocked, Gemini can no longer transcribe speech.
With a vosk model on disk, Chat records the short utterance after the wake
word and transcribes it locally, so "set a timer for ten minutes" keeps
working with zero internet.

Entirely optional: without the vosk package or a model folder, Chat behaves
exactly as before (announcement points the user to the dashboard).

Model download (small English, ~40 MB): https://alphacephei.com/vosk/models
-> unzip so the folder sits at  assets/vosk-model  (or set the path in
Settings -> Voice).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from chat_core.config import Settings
from chat_core.paths import install_dir

log = logging.getLogger("stt")


class LocalTranscriber:
    """Blocking vosk wrapper; call transcribe() via asyncio.to_thread."""

    def __init__(self, model_path: Path) -> None:
        self.available = False
        self.reason = ""
        self._vosk = None
        self._model = None
        try:
            import vosk  # type: ignore
        except Exception:
            self.reason = "vosk not installed (pip install vosk)"
            return
        if not model_path.is_dir():
            self.reason = f"model folder not found: {model_path}"
            return
        try:
            vosk.SetLogLevel(-1)
            self._model = vosk.Model(str(model_path))
            self._vosk = vosk
            self.available = True
        except Exception as exc:
            self.reason = f"model failed to load: {type(exc).__name__}"

    def transcribe(self, pcm: bytes, rate: int = 16000) -> str:
        """PCM16 mono -> text. Returns '' when nothing was recognized."""
        if not self.available or not pcm:
            return ""
        try:
            rec = self._vosk.KaldiRecognizer(self._model, rate)
            rec.AcceptWaveform(pcm)
            data = json.loads(rec.FinalResult() or "{}")
            return str(data.get("text", "")).strip()
        except Exception as exc:
            log.warning("transcription failed: %s", type(exc).__name__)
            return ""


def build_transcriber(settings: Settings) -> LocalTranscriber | None:
    """Returns a transcriber if a model path is configured or the default
    folder exists; None means 'feature not set up' (perfectly fine)."""
    if settings.vosk_model_path:
        path = Path(settings.vosk_model_path).expanduser()
    else:
        path = install_dir() / "assets" / "vosk-model"
        if not path.is_dir():
            return None
    return LocalTranscriber(path)
