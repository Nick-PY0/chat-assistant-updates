"""Pulse: isolated health monitoring and scheduled retry decisions.

Allowed: update health records, notify the dashboard, schedule reconnects,
mark components degraded.
Forbidden (enforced by having no references to them): touching playback
buffers, restarting audio, muting, reconnect loops, or validating every
credential at once (it validates at most ONE stale credential per cycle).

In low-power mode every interval doubles, keeping the machine quiet.
"""

from __future__ import annotations

import asyncio
import logging
import socket

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore, iso, parse_iso, utcnow
from chat_core.models.db import Database
from chat_core.models.state import StateMachine
from integrations.gemini.errors import GeminiFailure
from integrations.gemini.validator import validate_key
from integrations.govee.client import GoveeClient, GoveeError

log = logging.getLogger("pulse")


class Pulse:
    def __init__(
        self,
        settings: Settings,
        db: Database,
        store: CredentialStore,
        bus: EventBus,
        state: StateMachine,
    ) -> None:
        self.settings = settings
        self.db = db
        self.store = store
        self.bus = bus
        self.state = state
        self._stop = asyncio.Event()
        self._validate_cursor = 0
        self._retry_announced: str | None = None

    async def run(self) -> None:
        tasks = [
            asyncio.create_task(self._loop(self._check_internet, self.settings.pulse_internet_interval), name="pulse-net"),
            asyncio.create_task(self._loop(self._check_govee, self.settings.pulse_govee_interval), name="pulse-govee"),
            asyncio.create_task(self._loop(self._check_credentials, self.settings.pulse_credential_interval), name="pulse-creds"),
            asyncio.create_task(self._loop(self._check_quota_recovery, self.settings.pulse_timer_interval), name="pulse-quota"),
        ]
        await self._stop.wait()
        for t in tasks:
            t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def stop(self) -> None:
        self._stop.set()

    async def _loop(self, fn, base_interval: int) -> None:
        interval = self.settings.pulse_interval(base_interval)
        # stagger startup so checks never fire simultaneously
        await asyncio.sleep(min(5, interval / 4))
        while not self._stop.is_set():
            try:
                await fn()
            except Exception as exc:
                log.debug("pulse check %s error: %s", fn.__name__, type(exc).__name__)
            await asyncio.sleep(interval)

    # ------------------------------------------------------------------
    async def _set_health(self, component: str, status: str, detail: str = "") -> None:
        await self.db.execute(
            "INSERT INTO health (component, status, detail, updated_at) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(component) DO UPDATE SET status=excluded.status, detail=excluded.detail, updated_at=excluded.updated_at",
            (component, status, detail, iso(utcnow())),
        )
        self.bus.publish("health", component=component, status=status, detail=detail)
        self.state.mark_degraded(component, status not in ("ok", "unknown"))

    async def _check_internet(self) -> None:
        def probe() -> bool:
            try:
                with socket.create_connection(("8.8.8.8", 53), timeout=2):
                    return True
            except OSError:
                return False

        ok = await asyncio.to_thread(probe)
        await self._set_health("internet", "ok" if ok else "down", "" if ok else "no route")

    async def _check_govee(self) -> None:
        creds = [c for c in await self.store.list(provider="govee") if c.status in ("active", "standby")]
        if not creds:
            await self._set_health("govee", "unknown", "no key saved")
            return
        try:
            key = await self.store.get_secret(creds[0].id)
            client = GoveeClient(key, timeout=3.0)
            devices = await client.list_devices()
            await self._set_health("govee", "ok", f"{len(devices)} device(s)")
        except GoveeError as exc:
            await self._set_health("govee", "degraded", str(exc)[:120])

    async def _check_credentials(self) -> None:
        """Validate at most one stale Gemini credential per cycle."""
        creds = [c for c in await self.store.list(provider="gemini") if c.status in ("active", "standby")]
        if not creds:
            return
        stale_cutoff = utcnow().timestamp() - 24 * 3600
        stale = [
            c for c in creds
            if c.last_validated_at is None or c.last_validated_at.timestamp() < stale_cutoff
        ]
        if not stale:
            return
        self._validate_cursor = (self._validate_cursor + 1) % len(stale)
        cred = stale[self._validate_cursor]
        try:
            secret = await self.store.get_secret(cred.id)
            await validate_key(secret, timeout=5.0)
            await self.store.mark_validated(cred.id)
        except GeminiFailure as failure:
            if failure.code == "invalid":
                await self.store.set_status(cred.id, "invalid", failure.code, None)
                self.bus.publish("credential_alert", id=cred.id, code="invalid")
                await self.db.log("WARNING", "pulse", f"credential {cred.masked_suffix} invalid")
            # quota/unavailable results are left to the live path to classify

    async def _check_quota_recovery(self) -> None:
        """Release expired blocks; fire exactly one retry event per window."""
        released = await self.store.release_expired_blocks()
        if released:
            self.bus.publish("credentials_changed", released=len(released))
        retry_at_s = await self.db.get_setting("quota_retry_at")
        if not retry_at_s:
            return
        retry_at = parse_iso(retry_at_s)
        if retry_at is None:
            await self.db.delete_setting("quota_retry_at")
            return
        if utcnow() >= retry_at and self._retry_announced != retry_at_s:
            self._retry_announced = retry_at_s
            await self.db.delete_setting("quota_retry_at")
            self.bus.publish("quota_retry_window")
            await self.db.log("INFO", "pulse", "quota retry window reached")
