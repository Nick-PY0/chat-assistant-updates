"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const appEl = $("chat-app");
  if (!appEl) return;

  const messagesEl = $("chat-messages");
  const emptyEl = $("chat-empty");
  const inputEl = $("chat-input");
  const formEl = $("chat-form");
  const sendEl = $("chat-send");
  const errorEl = $("chat-error");
  const imageInput = $("chat-images");
  const attachmentTray = $("chat-attachment-tray");
  const historyList = $("chat-history-list");
  const historyStatus = $("chat-history-status");
  const searchInput = $("chat-search-input");
  const titleEl = $("chat-title");
  const titleDetail = $("chat-title-detail");
  const headActions = $("chat-head-actions");
  const historyToggle = $("chat-history-toggle");
  const readEl = $("read-aloud");
  const READ_STORE = "chat-dashboard-read-aloud-v1";
  const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
  const MAX_IMAGE_COUNT = 4;
  const MAX_IMAGE_BYTES = 12 * 1024 * 1024;

  let conversations = [];
  let activeConversation = null;
  let selectedFiles = [];
  let previewUrls = [];
  let sending = false;
  let loadSequence = 0;
  let pendingTimer = null;
  let speakWhenDoneRequestId = null;

  function setError(message = "") {
    errorEl.textContent = message;
  }

  function setHistoryOpen(open) {
    appEl.classList.toggle("history-open", open);
    historyToggle.setAttribute("aria-expanded", String(open));
  }

  function conversationUrl(id) {
    const url = new URL(location.href);
    if (id) url.searchParams.set("conversation", id);
    else url.searchParams.delete("conversation");
    return url.pathname + url.search + url.hash;
  }

  function setAddressConversation(id, replace = true) {
    const method = replace ? "replaceState" : "pushState";
    history[method]({ conversation: id || null }, "", conversationUrl(id));
  }

  function randomRequestId() {
    if (crypto.randomUUID) return crypto.randomUUID();
    const bytes = new Uint8Array(18);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  }

  async function requestJson(path, method = "GET", body = null) {
    return api(path, method, body);
  }

  async function requestMultipart(path, formData) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    let response;
    try {
      response = await fetch(path, {
        method: "POST",
        headers: { "x-csrf": csrf },
        body: formData,
        signal: controller.signal,
      });
    } catch (error) {
      const message = error && error.name === "AbortError"
        ? "The server did not accept the message within 30 seconds."
        : "Could not reach Chat. The saved request will be checked again.";
      const wrapped = new Error(message);
      wrapped.network = true;
      throw wrapped;
    } finally {
      clearTimeout(timer);
    }
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(data.error || `HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function formatUpdated(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return "";
    const today = new Date();
    if (date.toDateString() === today.toDateString()) {
      return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(date);
    }
    return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(date);
  }

  function historyGroup(iso) {
    const date = new Date(iso);
    if (Number.isNaN(date.getTime())) return "Older";
    const startToday = new Date();
    startToday.setHours(0, 0, 0, 0);
    const startDate = new Date(date);
    startDate.setHours(0, 0, 0, 0);
    const days = Math.round((startToday - startDate) / 86400000);
    if (days <= 0) return "Today";
    if (days === 1) return "Yesterday";
    if (days < 7) return "Previous 7 days";
    if (date.getFullYear() === startToday.getFullYear()) return "Earlier this year";
    return "Older";
  }

  function renderConversationList() {
    historyList.replaceChildren();
    const query = searchInput.value.trim().toLocaleLowerCase();
    const filtered = conversations.filter((item) => {
      if (!query) return true;
      return `${item.title || ""} ${item.last_message || ""}`.toLocaleLowerCase().includes(query);
    });
    historyStatus.hidden = filtered.length > 0;
    historyStatus.textContent = conversations.length === 0
      ? "No conversations yet."
      : "No conversations match your search.";

    let currentGroup = "";
    for (const conversation of filtered) {
      const group = historyGroup(conversation.updated_at);
      if (group !== currentGroup) {
        currentGroup = group;
        const label = document.createElement("li");
        label.className = "chat-history-group";
        label.textContent = group;
        historyList.appendChild(label);
      }

      const item = document.createElement("li");
      item.className = "chat-history-item";
      if (activeConversation && activeConversation.id === conversation.id) item.classList.add("active");
      const button = document.createElement("button");
      button.className = "chat-history-open";
      button.type = "button";
      button.addEventListener("click", () => openConversation(conversation.id, false));

      const top = document.createElement("span");
      top.className = "chat-history-item-top";
      const title = document.createElement("strong");
      title.textContent = conversation.title || "New chat";
      const time = document.createElement("time");
      time.dateTime = conversation.updated_at || "";
      time.textContent = formatUpdated(conversation.updated_at);
      top.append(title, time);

      const preview = document.createElement("span");
      preview.className = "chat-history-preview";
      if (conversation.pending) {
        const dot = document.createElement("i");
        dot.className = "chat-pending-dot";
        dot.setAttribute("aria-hidden", "true");
        preview.append(dot, document.createTextNode("Working on a reply…"));
      } else {
        preview.textContent = conversation.last_message || "Empty conversation";
      }
      button.append(top, preview);
      item.appendChild(button);
      historyList.appendChild(item);
    }
  }

  async function loadConversationList({ quiet = false } = {}) {
    if (!quiet) {
      historyStatus.hidden = false;
      historyStatus.textContent = "Loading conversations…";
    }
    try {
      const result = await requestJson("/api/chat/conversations?limit=200");
      conversations = Array.isArray(result.conversations) ? result.conversations.slice() : [];
      conversations.sort((a, b) => String(b.updated_at || "").localeCompare(String(a.updated_at || "")));
      renderConversationList();
    } catch (error) {
      if (!quiet) {
        historyStatus.hidden = false;
        historyStatus.textContent = error.message;
      }
    }
  }

  function createAttachmentFigure(attachment) {
    const figure = document.createElement("figure");
    figure.className = "chat-image";
    const link = document.createElement("a");
    link.href = attachment.url;
    link.target = "_blank";
    link.rel = "noopener";
    link.title = `Open ${attachment.original_name || "image"}`;
    const image = document.createElement("img");
    image.src = attachment.url;
    image.alt = attachment.original_name || "Attached image";
    image.loading = "lazy";
    link.appendChild(image);
    const caption = document.createElement("figcaption");
    caption.textContent = attachment.original_name || "Image";
    figure.append(link, caption);
    return figure;
  }

  function speak(text) {
    if (!("speechSynthesis" in window) || !text) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    window.speechSynthesis.speak(utterance);
  }

  function addMessage(message) {
    const row = document.createElement("article");
    row.className = `chat-row ${message.role}`;
    row.dataset.messageId = String(message.id || "");
    row.dataset.requestId = message.request_id || "";

    if (Array.isArray(message.attachments) && message.attachments.length) {
      const gallery = document.createElement("div");
      gallery.className = "chat-image-gallery";
      for (const attachment of message.attachments) gallery.appendChild(createAttachmentFigure(attachment));
      row.appendChild(gallery);
    }

    const bubble = document.createElement("div");
    bubble.className = "chat-bubble";
    if (message.status === "pending") {
      bubble.classList.add("pending");
      bubble.textContent = "Working on your reply…";
      row.setAttribute("aria-label", "Reply pending");
    } else {
      bubble.textContent = message.content || (message.role === "user" ? "Image attached" : "No reply text");
      if (message.status === "error") bubble.classList.add("failed");
    }
    row.appendChild(bubble);

    if (message.role === "assistant" && message.status !== "pending" && message.content) {
      const controls = document.createElement("div");
      controls.className = "chat-message-controls";
      const play = document.createElement("button");
      play.className = "bubble-play";
      play.type = "button";
      play.textContent = "Read aloud";
      play.addEventListener("click", () => speak(message.content));
      controls.appendChild(play);
      if (message.status === "error") {
        const failed = document.createElement("span");
        failed.className = "chat-message-error";
        failed.textContent = "Reply failed";
        controls.appendChild(failed);
      }
      row.appendChild(controls);
    }
    messagesEl.appendChild(row);
  }

  function renderMessages(conversation, { forceBottom = false } = {}) {
    const nearBottom = messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 120;
    messagesEl.querySelectorAll(".chat-row, .chat-loading").forEach((element) => element.remove());
    const messages = conversation && Array.isArray(conversation.messages) ? conversation.messages : [];
    emptyEl.hidden = messages.length > 0;
    for (const message of messages) addMessage(message);
    messagesEl.setAttribute("aria-busy", "false");
    if (forceBottom || nearBottom) messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function showDraft() {
    loadSequence += 1;
    activeConversation = null;
    clearTimeout(pendingTimer);
    pendingTimer = null;
    titleEl.textContent = "New chat";
    titleDetail.textContent = "Messages and replies are saved on your server.";
    headActions.hidden = true;
    renderMessages(null, { forceBottom: true });
    renderConversationList();
    setError();
    setAddressConversation(null);
    inputEl.focus();
  }

  function schedulePendingRefresh() {
    clearTimeout(pendingTimer);
    pendingTimer = null;
    if (!activeConversation) return;
    const pending = activeConversation.messages.some((message) => message.role === "assistant" && message.status === "pending");
    if (!pending) return;
    pendingTimer = setTimeout(() => refreshActiveConversation(), 1400);
  }

  async function openConversation(id, replaceAddress = true) {
    if (!id) {
      showDraft();
      return;
    }
    const sequence = ++loadSequence;
    clearTimeout(pendingTimer);
    pendingTimer = null;
    messagesEl.setAttribute("aria-busy", "true");
    titleEl.textContent = "Loading…";
    setError();
    try {
      const result = await requestJson(`/api/chat/conversations/${encodeURIComponent(id)}`);
      if (sequence !== loadSequence) return;
      activeConversation = result.conversation;
      titleEl.textContent = activeConversation.title || "New chat";
      titleDetail.textContent = `${activeConversation.messages.length} ${activeConversation.messages.length === 1 ? "message" : "messages"} · saved on your server`;
      headActions.hidden = false;
      renderMessages(activeConversation, { forceBottom: true });
      renderConversationList();
      setAddressConversation(id, replaceAddress);
      schedulePendingRefresh();
      setHistoryOpen(false);
    } catch (error) {
      if (sequence !== loadSequence) return;
      if (error.message.toLowerCase().includes("not found")) {
        await loadConversationList({ quiet: true });
        showDraft();
      }
      setError(error.message);
      messagesEl.setAttribute("aria-busy", "false");
    }
  }

  async function refreshActiveConversation() {
    const id = activeConversation && activeConversation.id;
    if (!id || document.hidden) {
      if (id) pendingTimer = setTimeout(() => refreshActiveConversation(), 2000);
      return;
    }
    const previous = new Map(activeConversation.messages.map((message) => [message.id, message.status]));
    try {
      const result = await requestJson(`/api/chat/conversations/${encodeURIComponent(id)}`);
      if (!activeConversation || activeConversation.id !== id) return;
      activeConversation = result.conversation;
      titleEl.textContent = activeConversation.title || "New chat";
      titleDetail.textContent = `${activeConversation.messages.length} ${activeConversation.messages.length === 1 ? "message" : "messages"} · saved on your server`;
      renderMessages(activeConversation);
      const finished = activeConversation.messages.find((message) =>
        message.request_id === speakWhenDoneRequestId
        && message.role === "assistant"
        && previous.get(message.id) === "pending"
        && message.status !== "pending"
      );
      if (finished) {
        if (readEl.checked && finished.status === "completed") speak(finished.content);
        speakWhenDoneRequestId = null;
        await loadConversationList({ quiet: true });
      }
      schedulePendingRefresh();
    } catch (error) {
      setError(`Could not refresh this reply: ${error.message}`);
      pendingTimer = setTimeout(() => refreshActiveConversation(), 3000);
    }
  }

  function releasePreviews() {
    for (const url of previewUrls) URL.revokeObjectURL(url);
    previewUrls = [];
  }

  function renderSelectedFiles() {
    releasePreviews();
    attachmentTray.replaceChildren();
    attachmentTray.hidden = selectedFiles.length === 0;
    selectedFiles.forEach((file, index) => {
      const item = document.createElement("div");
      item.className = "chat-selected-image";
      const url = URL.createObjectURL(file);
      previewUrls.push(url);
      const image = document.createElement("img");
      image.src = url;
      image.alt = "";
      const name = document.createElement("span");
      name.textContent = file.name;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.setAttribute("aria-label", `Remove ${file.name}`);
      remove.textContent = "×";
      remove.addEventListener("click", () => {
        selectedFiles.splice(index, 1);
        renderSelectedFiles();
      });
      item.append(image, name, remove);
      attachmentTray.appendChild(item);
    });
  }

  function validateFiles(files) {
    if (files.length > MAX_IMAGE_COUNT) return "Attach at most four images to one message.";
    let total = 0;
    for (const file of files) {
      if (!ALLOWED_IMAGE_TYPES.has(file.type)) return "Use JPEG, PNG, WebP, or GIF images.";
      total += file.size;
    }
    if (total > MAX_IMAGE_BYTES) return "Images in one message can total at most 12 MB.";
    return "";
  }

  async function ensureConversation(seed) {
    if (activeConversation) return activeConversation.id;
    const title = seed.trim().replace(/\s+/g, " ").slice(0, 72)
      || (selectedFiles[0] ? `Image: ${selectedFiles[0].name}` : "New chat");
    const result = await requestJson("/api/chat/conversations", "POST", { title });
    activeConversation = { ...result.conversation, messages: [] };
    setAddressConversation(activeConversation.id);
    return activeConversation.id;
  }

  async function recoverSubmittedTurn(conversationId, requestId) {
    try {
      const result = await requestJson(
        `/api/chat/conversations/${encodeURIComponent(conversationId)}/turns/${encodeURIComponent(requestId)}`
      );
      return result && Array.isArray(result.messages) ? result : null;
    } catch (_) {
      return null;
    }
  }

  async function submitMessage(event) {
    event.preventDefault();
    const text = inputEl.value.trim();
    if ((!text && selectedFiles.length === 0) || sending) return;
    const validationError = validateFiles(selectedFiles);
    if (validationError) {
      setError(validationError);
      return;
    }

    sending = true;
    sendEl.disabled = true;
    imageInput.disabled = true;
    setError();
    const requestId = randomRequestId();
    let conversationId = null;
    try {
      conversationId = await ensureConversation(text);
      const data = new FormData();
      data.append("text", text);
      data.append("request_id", requestId);
      for (const file of selectedFiles) data.append("images", file, file.name);
      let turn;
      try {
        turn = await requestMultipart(
          `/api/chat/conversations/${encodeURIComponent(conversationId)}/turns`, data
        );
      } catch (error) {
        if (!error.network) throw error;
        turn = await recoverSubmittedTurn(conversationId, requestId);
        if (!turn) throw error;
      }

      speakWhenDoneRequestId = requestId;
      inputEl.value = "";
      inputEl.style.height = "auto";
      selectedFiles = [];
      imageInput.value = "";
      renderSelectedFiles();
      await Promise.all([
        openConversation(turn.conversation_id, true),
        loadConversationList({ quiet: true }),
      ]);
    } catch (error) {
      setError(error.message);
      if (conversationId) await openConversation(conversationId, true);
    } finally {
      sending = false;
      sendEl.disabled = false;
      imageInput.disabled = false;
      inputEl.focus();
    }
  }

  async function renameConversation() {
    if (!activeConversation) return;
    const next = window.prompt("Rename this conversation", activeConversation.title || "New chat");
    if (next === null || !next.trim() || next.trim() === activeConversation.title) return;
    try {
      const result = await requestJson(
        `/api/chat/conversations/${encodeURIComponent(activeConversation.id)}/rename`,
        "POST",
        { title: next.trim() }
      );
      activeConversation.title = result.conversation.title;
      titleEl.textContent = activeConversation.title;
      await loadConversationList({ quiet: true });
    } catch (error) {
      setError(error.message);
    }
  }

  async function deleteConversation() {
    if (!activeConversation) return;
    const title = activeConversation.title || "this conversation";
    if (!window.confirm(`Delete “${title}” and its attached images? This cannot be undone.`)) return;
    const id = activeConversation.id;
    try {
      await requestJson(`/api/chat/conversations/${encodeURIComponent(id)}`, "DELETE");
      showDraft();
      await loadConversationList({ quiet: true });
      if (conversations.length) await openConversation(conversations[0].id, true);
    } catch (error) {
      setError(error.message);
    }
  }

  formEl.addEventListener("submit", submitMessage);
  inputEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      formEl.requestSubmit();
    }
  });
  inputEl.addEventListener("input", () => {
    inputEl.style.height = "auto";
    inputEl.style.height = `${Math.min(inputEl.scrollHeight, 180)}px`;
  });
  imageInput.addEventListener("change", () => {
    const files = Array.from(imageInput.files || []);
    const error = validateFiles(files);
    if (error) {
      setError(error);
      imageInput.value = "";
      return;
    }
    setError();
    selectedFiles = files;
    renderSelectedFiles();
  });
  searchInput.addEventListener("input", renderConversationList);
  $("new-chat-btn").addEventListener("click", () => {
    showDraft();
    setHistoryOpen(false);
  });
  $("rename-chat-btn").addEventListener("click", renameConversation);
  $("delete-chat-btn").addEventListener("click", deleteConversation);
  historyToggle.addEventListener("click", () => setHistoryOpen(!appEl.classList.contains("history-open")));
  $("chat-history-close").addEventListener("click", () => setHistoryOpen(false));
  $("chat-history-scrim").addEventListener("click", () => setHistoryOpen(false));

  try { readEl.checked = localStorage.getItem(READ_STORE) === "true"; } catch (_) { /* private mode */ }
  readEl.addEventListener("change", () => {
    try { localStorage.setItem(READ_STORE, String(readEl.checked)); } catch (_) { /* private mode */ }
    if (!readEl.checked && "speechSynthesis" in window) window.speechSynthesis.cancel();
  });
  $("stop-reading").addEventListener("click", () => {
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  });

  window.addEventListener("beforeunload", () => {
    releasePreviews();
  });
  window.addEventListener("popstate", () => {
    const id = new URL(location.href).searchParams.get("conversation");
    if (id) openConversation(id, true);
    else showDraft();
  });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && activeConversation) refreshActiveConversation();
  });

  async function initialize() {
    await loadConversationList();
    const requested = new URL(location.href).searchParams.get("conversation");
    if (requested) await openConversation(requested, true);
    else if (conversations.length) await openConversation(conversations[0].id, true);
    else showDraft();
    setInterval(() => {
      if (!document.hidden) loadConversationList({ quiet: true });
    }, 15000);
  }

  initialize().catch((error) => setError(error.message));
})();

// ---------------------------------------------------------------------------
// Media-state voice bridge: forwards BroadcastChannel media state to any
// open voice WebSocket.  This runs on the chat page where the voice session
// lives so that the media page (a separate tab) can keep the server informed
// about what is currently playing.  It does NOT perform any microphone
// capture or session control – it is read-only media metadata forwarding.
// ---------------------------------------------------------------------------
(() => {
  let _voiceWs = null;

  // Expose a hook so the voice session logic (if/when loaded) can register
  // its WebSocket here.
  window._chatRegisterVoiceWs = (ws) => { _voiceWs = ws; };

  const mediaStateChannel = "BroadcastChannel" in window
    ? new BroadcastChannel("chat-media-state-v1")
    : null;
  if (mediaStateChannel) {
    mediaStateChannel.addEventListener("message", (event) => {
      const message = event.data;
      if (
        message && message.type === "media_state"
        && typeof message.playing === "boolean"
        && _voiceWs && _voiceWs.readyState === WebSocket.OPEN
      ) {
        _voiceWs.send(JSON.stringify({ type: "media_state", playing: message.playing }));
      }
    });
  }
})();
