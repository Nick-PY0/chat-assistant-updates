"use strict";

/*
 * YouTube media player for the Chat dashboard.
 *
 * Playback is performed by a plain https://www.youtube.com/embed/<id> iframe
 * with enablejsapi=1.  All player control uses the documented postMessage
 * command protocol (playVideo, pauseVideo, stopVideo, seekTo).  No external
 * script is ever loaded: no dynamic script injection,
 * and no remote JS/CSS/font import of any kind.
 *
 * The only external resources this page ever contacts are:
 *   • https://www.youtube.com/embed/<validated-id>  — the embedded player
 *   • https://i.ytimg.com/vi/<id>/mqdefault.jpg     — queue thumbnails
 *   • /api/media/*                                   — local server APIs
 *
 * Embed error 101/150 (embedding disabled) and browser autoplay-block both
 * invoke the narrowly scoped /api/media/host-open endpoint which opens the
 * canonical watch URL in the Chat host computer's default browser.
 * Dashboard controls remain available for selecting/changing/stopping state;
 * copy is honest that YouTube's own pause/seek/volume controls live in the
 * host browser when external fallback is active.
 */

(() => {
  const $ = (id) => document.getElementById(id);
  const page = $("media-page");
  if (!page) return;

  const form              = $("media-request-form");
  const requestInput      = $("media-request-input");
  const requestButton     = $("media-request-button");
  const connectionEl      = $("media-connection");
  const takeoverButton    = $("media-takeover");
  const stageEl           = $("media-stage");
  const placeholder       = $("media-placeholder");
  const tapToPlay         = $("media-tap-play");
  const titleEl           = $("media-title");
  const timeEl            = $("media-time");
  const youtubeLink       = $("media-youtube-link");
  const messageEl         = $("media-message");
  const queueEl           = $("media-queue");
  const queueCount        = $("media-queue-count");
  const resultsMessage    = $("media-results-message");
  const playPauseButton   = $("media-play-pause");
  const stopButton        = $("media-stop");
  const previousButton    = $("media-previous");
  const nextButton        = $("media-next");
  const seekBackButton    = $("media-seek-back");
  const seekForwardButton = $("media-seek-forward");
  const seekSecondsInput  = $("media-seek-seconds");

  /* ── constants ─────────────────────────────────────────────────────── */
  const EMPTY_STATE = {
    revision: 0,
    status: "stopped",
    video_id: "",
    title: "",
    url: "",
    position_seconds: 0,
    duration_seconds: 0,
    queue: [],
    queue_index: -1,
    command: null,
    target_id: "",
    target_label: "",
    player_connected: false,
    playback_mode: "embedded",
    media_kind: "video",
    playlist_id: "",
    playlist_title: "",
    playlist_url: "",
    continuous: false,
    media_session: 0,
  };
  const MEDIA_CHANNEL = "chat-media-state-v1";
  /* YouTube postMessage state codes (YT IFrame API reference). */
  const YT_STATES = {
    "-1": "buffering",  /* unstarted / video cued — show as buffering, not queued */
     "0": "ended",
     "1": "playing",
     "2": "paused",
     "3": "buffering",
     "5": "buffering",  /* video cued — show as buffering */
  };
  /* Unembeddable / blocked error codes that require a host-browser fallback. */
  const UNEMBEDDABLE_ERRORS = new Set([101, 150]);
  /* Other embeddable-player error codes. */
  const PLAYER_ERROR_MESSAGES = {
    2:   "That YouTube video ID is invalid.",
    5:   "YouTube could not play this video in the browser.",
    100: "That video was removed or is private.",
    101: "The video owner has disabled embedded playback.",
    150: "The video owner has disabled embedded playback.",
  };
  const EMBED_ORIGIN = location.origin;

  /* ── mutable state ──────────────────────────────────────────────────── */
  let state            = { ...EMPTY_STATE };
  let owner            = false;
  let busy             = false;
  let iframeEl         = null;   /* the live <iframe> element, or null */
  let currentVideoId   = "";     /* video ID the iframe was built for */
  let currentPlaylistId = "";    /* playlist ID the iframe was built for */
  let progressTimer    = null;
  let leaseTimer       = null;
  let progressTicks    = 0;
  let reportChain      = Promise.resolve();
  let lastVoicePlaying = null;
  let lastCommandId    = "";
  /* Estimated playback position — updated each second while playing. */
  let localPosition    = 0;
  let localDuration    = 0;

  /* ── client identity (session-scoped, sessionStorage only) ─────────── */
  function makeClientId() {
    const storageKey = "chat-media-client-v1";
    try {
      const existing = sessionStorage.getItem(storageKey);
      if (/^[A-Za-z0-9_-]{8,80}$/.test(existing || "")) return existing;
    } catch (_) { /* sessionStorage can be disabled */ }
    const bytes = crypto.getRandomValues(new Uint8Array(18));
    const id = "media_" + Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    try { sessionStorage.setItem(storageKey, id); } catch (_) { /* page lifetime is enough */ }
    return id;
  }

  const clientId    = makeClientId();
  const mediaChannel = "BroadcastChannel" in window
    ? new BroadcastChannel(MEDIA_CHANNEL)
    : null;

  /* ── UI helpers ─────────────────────────────────────────────────────── */
  function setMessage(message = "", tone = "") {
    messageEl.textContent = message;
    messageEl.className = `media-message${tone ? ` ${tone}` : ""}`;
  }

  function formatTime(value) {
    const total = Math.max(0, Number.isFinite(Number(value)) ? Math.floor(Number(value)) : 0);
    const hours   = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    return hours
      ? `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
      : `${minutes}:${String(seconds).padStart(2, "0")}`;
  }

  function seekAmount() {
    const v = Math.round(Number(seekSecondsInput.value));
    return Math.max(1, Math.min(3600, Number.isFinite(v) ? v : 10));
  }

  function updateSeekLabels() {
    const s = seekAmount();
    seekSecondsInput.value = String(s);
    seekBackButton.setAttribute("aria-label", `Seek backward ${s} seconds`);
    seekBackButton.title    = `Back ${s} seconds`;
    seekForwardButton.setAttribute("aria-label", `Seek forward ${s} seconds`);
    seekForwardButton.title = `Forward ${s} seconds`;
  }

  /* ── BroadcastChannel voice bridge ─────────────────────────────────── */
  function notifyRemoteVoice(playing, force = false) {
    const next = Boolean(playing);
    if (!force && lastVoicePlaying === next) return;
    lastVoicePlaying = next;
    if (mediaChannel) mediaChannel.postMessage({ type: "media_state", playing: next });
  }

  if (mediaChannel) {
    mediaChannel.addEventListener("message", (event) => {
      if (event.data && event.data.type === "request_media_state") {
        notifyRemoteVoice(state.status === "playing", true);
      }
    });
  }

  /* ── postMessage player control ─────────────────────────────────────── */
  /*
   * Build and inject a bare <iframe> pointing at the official embed URL.
   * No external script is loaded; all control goes through postMessage.
   * The iframe is only created when there is an actual video to show AND
   * the server's playback_mode is "embedded".
   */
  function buildEmbedUrl(videoId, startSeconds) {
    const start = Math.max(0, Math.floor(Number(startSeconds) || 0));
    const params = new URLSearchParams({
      enablejsapi: "1",
      origin: EMBED_ORIGIN,
      autoplay: "1",
      playsinline: "1",
      rel: "0",
      modestbranding: "1",
    });
    if (start > 0) params.set("start", String(start));
    return `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?${params}`;
  }

  /* Official playlist embed: youtube.com/embed/videoseries?list=<validated id>.
     No remote IFrame API script; control uses the documented postMessage
     commands (nextVideo/previousVideo/playVideo/pauseVideo/stopVideo). */
  function buildPlaylistEmbedUrl(playlistId) {
    const params = new URLSearchParams({
      enablejsapi: "1",
      origin: EMBED_ORIGIN,
      autoplay: "1",
      loop: "1",
      playsinline: "1",
      rel: "0",
      modestbranding: "1",
      controls: "1",
      list: playlistId,
    });
    return `https://www.youtube.com/embed/videoseries?${params}`;
  }

  function postToPlayer(func, args) {
    if (!iframeEl || !iframeEl.contentWindow) return;
    iframeEl.contentWindow.postMessage(
      JSON.stringify({ event: "command", func, args: args ?? [] }),
      "https://www.youtube.com"
    );
  }

  function teardownIframe() {
    if (iframeEl) {
      iframeEl.remove();
      iframeEl = null;
    }
    currentVideoId = "";
    currentPlaylistId = "";
    localPosition  = 0;
    localDuration  = 0;
  }

  /* Build (or reuse) the official playlist videoseries iframe. */
  function ensurePlaylistIframe(playlistId) {
    if (!/^[A-Za-z0-9_-]{10,44}$/.test(playlistId)) return;
    if (iframeEl && currentPlaylistId === playlistId) {
      postToPlayer("playVideo", []);
      return;
    }
    teardownIframe();
    const iframe = document.createElement("iframe");
    iframe.id                = "youtube-iframe";
    iframe.src               = buildPlaylistEmbedUrl(playlistId);
    iframe.allow             = "autoplay; fullscreen; picture-in-picture";
    iframe.allowFullscreen   = true;
    iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
    iframe.style.cssText     = "position:absolute;inset:0;width:100%;height:100%;border:0;";
    stageEl.appendChild(iframe);
    iframeEl          = iframe;
    currentPlaylistId = playlistId;
    currentVideoId    = "";
    placeholder.hidden = true;
    tapToPlay.hidden   = true;
  }

  function ensureIframe(videoId, startSeconds) {
    /* Re-use the existing iframe if the video hasn't changed. */
    if (iframeEl && currentVideoId === videoId) {
      const start = Math.max(0, Number(startSeconds) || 0);
      if (start > 1) postToPlayer("seekTo", [start, true]);
      postToPlayer("playVideo", []);
      return;
    }
    teardownIframe();

    const iframe = document.createElement("iframe");
    iframe.id                = "youtube-iframe";
    iframe.src               = buildEmbedUrl(videoId, startSeconds);
    iframe.allow             = "autoplay; fullscreen; picture-in-picture";
    iframe.allowFullscreen   = true;
    iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
    /* Dimensions are controlled by CSS (.media-stage iframe). */
    iframe.style.cssText     = "position:absolute;inset:0;width:100%;height:100%;border:0;";
    stageEl.appendChild(iframe);
    iframeEl       = iframe;
    currentVideoId = videoId;
    placeholder.hidden = true;
    tapToPlay.hidden   = true;
  }

  /* Receive events from the embedded player. */
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://www.youtube.com") return;
    /* Ignore any message that isn't sent by the *active* iframe's window. */
    if (!iframeEl || !iframeEl.contentWindow || event.source !== iframeEl.contentWindow) return;
    let msg;
    try { msg = JSON.parse(typeof event.data === "string" ? event.data : JSON.stringify(event.data)); }
    catch (_) { return; }
    /* The YT IFrame API echoes the iframe's own `id` attribute in every
       event. Accept only events bound to the live iframe element, so a
       spoofed message carrying a wrong id (or no id) is rejected. */
    if (!msg || String(msg.id) !== iframeEl.id) return;

    if (msg.event === "onStateChange") {
      const raw    = String(msg.info);
      const status = YT_STATES[raw] || state.status;
      onPlayerStateChange(status);
    } else if (msg.event === "onError") {
      onPlayerError(Number(msg.info));
    } else if (msg.event === "onAutoplayBlocked") {
      onAutoplayBlocked();
    } else if (msg.event === "infoDelivery" && msg.info) {
      /* Position/duration updates delivered by the YT iframe. */
      if (typeof msg.info.currentTime === "number") localPosition = msg.info.currentTime;
      if (typeof msg.info.duration    === "number") localDuration = msg.info.duration;
      /* In playlist mode, report the current video id when safely delivered so
         the dashboard can label the active track. Only accept a valid 11-char
         id derived from the delivered videoData; never trust arbitrary text. */
      if (state.media_kind === "playlist" && msg.info.videoData
          && typeof msg.info.videoData.video_id === "string"
          && /^[A-Za-z0-9_-]{11}$/.test(msg.info.videoData.video_id)) {
        state.video_id = msg.info.videoData.video_id;
      }
    }
  });

  function onPlayerStateChange(status) {
    state.status = status;
    state.url    = state.video_id
      ? `https://www.youtube.com/watch?v=${encodeURIComponent(state.video_id)}`
      : "";
    renderState();
    notifyRemoteVoice(status === "playing");
    scheduleProgressUpdate();
    reportPlayerState(status);
  }

  function onAutoplayBlocked() {
    /* The browser blocked autoplay on the embedded iframe.  Tear it down
       and invoke the same host-browser fallback as 101/150.  The tap-play
       overlay is never shown: the host browser is the canonical fallback. */
    stopProgressUpdates();
    notifyRemoteVoice(false);
    teardownIframe();
    tapToPlay.hidden = true;
    placeholder.hidden = false;
    state.status = "buffering";
    renderState();
    /* Do NOT call reportPlayerState here — the fallback endpoint updates
       authoritative state on the server so a subsequent report from the
       (now-removed) iframe cannot overwrite host_browser mode. */
    renderHostBrowserFallback("autoplay_blocked");
  }

  /* Build the safe validated watch link. Assembled with createElement so no
     untrusted string is ever parsed as HTML; href uses an encoded 11-char id. */
  function appendWatchLink(target) {
    if (!target || !/^[A-Za-z0-9_-]{11}$/.test(state.video_id)) return;
    const link = document.createElement("a");
    link.href = `https://www.youtube.com/watch?v=${encodeURIComponent(state.video_id)}`;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "Open on YouTube ↗";
    target.appendChild(link);
  }

  /* 101/150 / autoplay-blocked fallback.
     Ask the narrowly scoped, CSRF-protected /api/media/host-open endpoint
     to open the currently active canonical video in the host computer's
     default browser.  We send only client_id; the server chooses the URL.
     On failure we show a clear error plus the safe watch link.
     Never calls reportPlayerState("error") so a stale iframe report
     cannot overwrite the host_browser state the server establishes. */
  async function renderHostBrowserFallback(reason) {
    void reason;
    messageEl.className = "media-message";
    messageEl.textContent = "Opening this video in your browser on this computer… ";
    appendWatchLink(messageEl);
    if (!owner) {
      messageEl.textContent = "This video can't be embedded. ";
      appendWatchLink(messageEl);
      return;
    }
    try {
      const result = await api("/api/media/host-open", "POST", { client_id: clientId });
      applyState(result);
      messageEl.className = "media-message good";
      messageEl.textContent =
        "Playing in your default browser on this computer. " +
        "Use YouTube's own controls in that tab to pause, seek, or change the volume. ";
      appendWatchLink(messageEl);
    } catch (error) {
      messageEl.className = "media-message bad";
      messageEl.textContent =
        (error && error.message ? error.message + " " : "Could not open the browser on this computer. ");
      appendWatchLink(messageEl);
    }
  }

  function onPlayerError(code) {
    notifyRemoteVoice(false);
    stopProgressUpdates();
    tapToPlay.hidden = true;

    if (UNEMBEDDABLE_ERRORS.has(code) && /^[A-Za-z0-9_-]{11}$/.test(state.video_id)) {
      /* Embed error 101/150: tear down the iframe, invoke host-browser
         fallback.  Do NOT call reportPlayerState("error") — the fallback
         endpoint sets authoritative host_browser state on the server and a
         stale iframe error report from the (now-removed) iframe must not
         overwrite it. */
      teardownIframe();
      placeholder.hidden = false;
      state.status = "buffering";
      renderState();
      renderHostBrowserFallback(code);
    } else {
      state.status = "error";
      renderState();
      const msg = PLAYER_ERROR_MESSAGES[code]
        || "YouTube could not play that video.";
      setMessage(msg, "bad");
      /* Only report non-fallback errors back to the server so state is
         accurate for recoverable errors (invalid id, removed video, etc.). */
      reportPlayerState("error");
    }
  }

  /* ── progress ticker (setTimeout chain) ────────────────────────────── */
  function stopProgressUpdates() {
    clearTimeout(progressTimer);
    progressTimer = null;
    progressTicks = 0;
  }

  function scheduleProgressUpdate() {
    stopProgressUpdates();
    if (state.status !== "playing") return;
    const tick = () => {
      if (state.status !== "playing") { stopProgressUpdates(); return; }
      /* Increment local estimate by 1s; postMessage delivers real values. */
      localPosition = Math.min(
        localDuration > 0 ? localDuration : Infinity,
        localPosition + 1
      );
      state.position_seconds = localPosition;
      state.duration_seconds = localDuration;
      timeEl.textContent = `${formatTime(state.position_seconds)} / ${formatTime(state.duration_seconds)}`;
      progressTicks += 1;
      if (progressTicks % 10 === 0) reportPlayerState("playing");
      progressTimer = setTimeout(tick, 1000);
    };
    progressTimer = setTimeout(tick, 1000);
  }

  /* ── connection / UI rendering ──────────────────────────────────────── */
  function setConnection() {
    connectionEl.className = "status-pill";
    /* Honest playlist/continuous suffix appended to the connection label so the
       dashboard visibly shows when a playlist or continuous auto-advance is
       active.  In host_browser mode the Continuous label is suppressed: Chat
       cannot observe end events for an external tab, so auto-advance is not
       active there and showing it would be misleading. */
    const isPlaylist = state.media_kind === "playlist" && Boolean(state.playlist_id);
    const isHostBrowser = state.playback_mode === "host_browser";
    /* Playlist suffix shown in host_browser too (YouTube's own tab handles it),
       but Continuous is NOT shown in host_browser (Chat has no end-event feed). */
    const modeSuffix = isPlaylist
      ? " · Playlist"
      : (!isHostBrowser && state.continuous ? " · Continuous" : "");
    if (isHostBrowser) {
      /* Honest copy: playback is in a separate browser tab on the Chat
         computer.  The dashboard cannot pause/seek/control that tab.
         Stop tracking is available; use YouTube's own controls for everything
         else.  For a playlist, YouTube's own tab handles track continuation. */
      connectionEl.classList.add("standby");
      connectionEl.textContent = "Playing in browser on this computer" + modeSuffix;
      takeoverButton.hidden = !owner;
      return;
    }
    if (owner) {
      connectionEl.classList.add("ok");
      connectionEl.textContent = "This device selected";
      takeoverButton.hidden = true;
    } else if (state.player_connected) {
      connectionEl.classList.add("standby");
      connectionEl.textContent = state.target_label
        ? `Playing on ${state.target_label}`
        : "Another device selected";
      takeoverButton.hidden = false;
    } else {
      connectionEl.classList.add("unknown");
      connectionEl.textContent = "No player selected";
      takeoverButton.hidden = false;
    }
  }

  function updateControls() {
    const isPlaylist   = state.media_kind === "playlist" && Boolean(state.playlist_id);
    const hasVideo     = Boolean(state.video_id) || isPlaylist;
    const locked       = !owner || busy;
    const isHostBrowser = state.playback_mode === "host_browser";
    requestInput.disabled    = locked;
    requestButton.disabled   = locked;
    /* In host_browser mode the dashboard cannot control the separate YouTube
       tab: play/pause/seek/previous/next are all disabled.  Only Stop remains
       (and is clearly labelled that it stops Chat tracking, not the tab).
       Seeking and next/previous are also unavailable — use YouTube's own
       controls in that browser tab. */
    playPauseButton.disabled = locked || !hasVideo || isHostBrowser;
    stopButton.disabled      = locked || !hasVideo;
    seekBackButton.disabled  = locked || !hasVideo || isPlaylist || isHostBrowser;
    seekForwardButton.disabled = locked || !hasVideo || isPlaylist || isHostBrowser;
    if (isPlaylist) {
      /* Playlist next/previous drive YouTube's own cursor via postMessage —
         only available when an embedded iframe is present (not host_browser). */
      previousButton.disabled = locked || !iframeEl || isHostBrowser;
      nextButton.disabled     = locked || !iframeEl || isHostBrowser;
    } else {
      previousButton.disabled = locked || state.queue_index <= 0 || isHostBrowser;
      nextButton.disabled     = locked
        || state.queue_index < 0
        || state.queue_index + 1 >= state.queue.length
        || isHostBrowser;
    }
    playPauseButton.textContent =
      state.status === "playing" || state.status === "buffering" ? "Pause" : "Play";
    /* Honest stop label in host_browser mode: the Chat server forgets the
       session but cannot close or pause the separate YouTube tab. */
    stopButton.textContent = isHostBrowser
      ? "Stop tracking"
      : "Stop";
    stopButton.title = isHostBrowser
      ? "Stops Chat tracking only. The YouTube tab remains open and playing."
      : "";
  }

  function renderQueue() {
    queueEl.replaceChildren();
    const queue = Array.isArray(state.queue) ? state.queue : [];
    queueCount.textContent = `${queue.length} ${queue.length === 1 ? "video" : "videos"}`;
    resultsMessage.hidden  = queue.length > 0;
    for (const [index, item] of queue.entries()) {
      const row    = document.createElement("li");
      row.className = "media-queue-item";
      if (index === state.queue_index) row.classList.add("active");
      const button = document.createElement("button");
      button.type     = "button";
      button.disabled = !owner || busy;
      button.addEventListener("click", () => manualControl("play", {
        video: item.video_id,
        title: item.title || "YouTube video",
      }));
      const image  = document.createElement("img");
      image.src    = item.thumbnail
        || `https://i.ytimg.com/vi/${encodeURIComponent(item.video_id)}/mqdefault.jpg`;
      image.alt    = "";
      image.loading = "lazy";
      image.referrerPolicy = "strict-origin-when-cross-origin";
      const copy    = document.createElement("span");
      copy.className = "media-queue-copy";
      const title   = document.createElement("strong");
      title.textContent = item.title || "YouTube video";
      const channel = document.createElement("span");
      channel.textContent = item.channel
        || (index === state.queue_index ? "Now selected" : "YouTube");
      copy.append(title, channel);
      button.append(image, copy);
      row.appendChild(button);
      queueEl.appendChild(row);
    }
  }

  function renderState() {
    setConnection();
    const isPlaylist = state.media_kind === "playlist" && Boolean(state.playlist_id);
    if (isPlaylist) {
      const base = state.playlist_title || "YouTube playlist";
      titleEl.textContent = `Playlist: ${base}`;
    } else {
      titleEl.textContent = state.title
        || (state.video_id ? "YouTube video" : "Nothing selected");
    }
    timeEl.textContent  = `${formatTime(state.position_seconds)} / ${formatTime(state.duration_seconds)}`;
    /* Prefer the canonical playlist URL for the "Open on YouTube" link when a
       playlist is active. */
    const link = isPlaylist ? (state.playlist_url || "") : (state.url || "");
    youtubeLink.hidden = !link;
    if (link) youtubeLink.href = link;
    placeholder.hidden  = Boolean(state.video_id) || isPlaylist || Boolean(iframeEl);
    updateControls();
    renderQueue();
  }

  function applyState(next) {
    if (!next || typeof next !== "object") return;
    state = {
      ...state,
      ...next,
      queue:   Array.isArray(next.queue)  ? next.queue  : state.queue,
      command: next.command === undefined  ? state.command : next.command,
    };
    owner = state.target_id === clientId;
    updateLeaseRenewal();
    renderState();
  }

  /* ── lease renewal (timeout chain) ─────────────────────────────────── */
  function updateLeaseRenewal() {
    if (!owner) {
      clearTimeout(leaseTimer);
      leaseTimer = null;
      return;
    }
    if (leaseTimer) return;
    leaseTimer = setTimeout(async () => {
      leaseTimer = null;
      await reportPlayerState(state.status);
      updateLeaseRenewal();
    }, 20000);
  }

  /* ── server API helpers ─────────────────────────────────────────────── */
  async function claimPlayer(force = false) {
    setMessage(force ? "Selecting this browser…" : "Connecting this browser…");
    try {
      const result = await api("/api/media/claim", "POST", {
        client_id: clientId,
        label: "Media page",
        force,
      });
      owner = Boolean(result.owner);
      applyState(result);
      if (owner) {
        if (result.playback_mode === "host_browser") {
          /* The server already has active host_browser playback (from a
             prior 101/150 fallback or autoplay-block on another page).
             Preserve it: do not build a new iframe, do not autoplay a
             second video.  Show the honest banner. */
          setMessage(
            "Playing in your default browser on this computer. " +
            "Use YouTube's own controls in that tab to pause, seek, or change the volume."
          );
        } else {
          setMessage("This browser is ready for Jarvis media commands.", "good");
          if (result.command) await handleCommand(result.command);
        }
      } else {
        setMessage(
          "Media is selected on another device. " +
          "Choose \"Use this device\" to move playback here."
        );
      }
      return owner;
    } catch (error) {
      owner = false;
      setMessage(error.message, "bad");
      renderState();
      return false;
    }
  }

  async function reconcileState() {
    try {
      const result = await api("/api/media");
      applyState(result);
      return result;
    } catch (error) {
      setMessage(error.message, "bad");
      return null;
    }
  }

  function reportPlayerState(status = state.status) {
    if (!owner) return Promise.resolve();
    /* Do not report embedded iframe state while the server is in
       host_browser mode — stale iframe events must not overwrite the
       authoritative host_browser playback_mode. */
    if (state.playback_mode === "host_browser") return Promise.resolve();
    const payload = {
      client_id:        clientId,
      status,
      video_id:         state.video_id,
      title:            state.title,
      position_seconds: localPosition,
      duration_seconds: localDuration,
      queue_index:      state.queue_index,
      /* The media session the client observed. The server ignores any ended
         report whose session no longer matches the current one (stop, new
         play, playlist switch, lease loss) so stale/duplicate reports cannot
         double-advance. The client does not locally guess advancement. */
      media_session:    Number(state.media_session) || 0,
    };
    reportChain = reportChain.then(async () => {
      try {
        const result = await api("/api/media/state", "POST", payload);
        if (result.target_id && result.target_id !== clientId) {
          owner = false;
          applyState(result);
        }
      } catch (error) {
        if (/selected Media player/i.test(error.message)) {
          owner = false;
          await reconcileState();
        }
      }
    });
    return reportChain;
  }

  /* ── command execution ──────────────────────────────────────────────── */
  async function executePlayerCommand(command) {
    if (!owner || !command) return;
    const action = command.action;

    if (action === "play_playlist") {
      /* Official playlist: build the videoseries iframe. YouTube's own
         continuation advances tracks; the server does not auto-advance. */
      if (state.playback_mode === "host_browser") return;
      const playlistId = String(command.playlist_id || state.playlist_id || "");
      if (!playlistId) return;
      state.media_kind  = "playlist";
      state.playlist_id = playlistId;
      state.video_id    = "";
      ensurePlaylistIframe(playlistId);
    } else if (action === "play") {
      /* Never build an iframe while the server is in host_browser mode —
         that would create a second, unwanted player for a video already
         open in the host browser. */
      if (state.playback_mode === "host_browser") return;
      const videoId      = String(command.video_id || state.video_id || "");
      const startSeconds = Math.max(0, Number(command.start_seconds) || 0);
      if (!videoId) return;
      state.media_kind = "video";
      state.video_id = videoId;
      localPosition  = startSeconds;
      /* Build or reuse the embed iframe — the only external resource load. */
      ensureIframe(videoId, startSeconds);
    } else if (action === "pause") {
      postToPlayer("pauseVideo", []);
    } else if (action === "stop") {
      postToPlayer("stopVideo", []);
      stopProgressUpdates();
      state.position_seconds = 0;
      localPosition          = 0;
      teardownIframe();
      placeholder.hidden = false;
      renderState();
    } else if (action === "seek") {
      const target = Math.max(0, Number(command.target_seconds) || 0);
      localPosition = target;
      postToPlayer("seekTo", [target, true]);
    }
  }

  async function handleCommand(command) {
    if (!command || typeof command !== "object") return;
    if (command.target_id && command.target_id !== clientId) {
      owner = false;
      await reconcileState();
      return;
    }
    if (!command.target_id) {
      if (await claimPlayer(false)) return;
      return;
    }
    if (command.command_id && command.command_id === lastCommandId) return;
    if (command.command_id) lastCommandId = command.command_id;

    state.command   = command;
    state.revision  = Math.max(Number(state.revision) || 0, Number(command.revision) || 0);
    if (command.video_id) state.video_id = command.video_id;
    if (command.title)    state.title    = command.title;
    if (Number.isFinite(Number(command.queue_index)))
      state.queue_index = Number(command.queue_index);
    /* Use "buffering" (not "queued") for fresh play commands so the UI
       never shows user-visible "queued" copy. */
    if (command.action === "play" || command.action === "play_playlist") state.status = "buffering";
    else if (command.action === "pause") state.status = "paused";
    else if (command.action === "stop")  state.status = "stopped";
    if (command.action === "play_playlist" && command.playlist_id) {
      state.media_kind  = "playlist";
      state.playlist_id = command.playlist_id;
      if (command.title) state.playlist_title = command.title;
    }
    renderState();
    await executePlayerCommand(command);
  }

  /* ── event listeners ────────────────────────────────────────────────── */
  function looksLikeDirectVideo(value) {
    return /^[A-Za-z0-9_-]{11}$/.test(value)
      || /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?(?:youtube\.com|youtu\.be)\//i.test(value);
  }

  async function submitRequest(event) {
    event.preventDefault();
    const value = requestInput.value.trim();
    if (!value || busy) return;
    if (!owner) {
      setMessage("Select \"Use this device\" before starting media here.", "bad");
      return;
    }
    if (looksLikeDirectVideo(value)) {
      await manualControl("play", { video: value });
      return;
    }
    busy = true;
    renderState();
    setMessage("Searching YouTube…");
    try {
      const result = await api("/api/media/search", "POST", { query: value, max_results: 8 });
      state.queue       = Array.isArray(result.results) ? result.results : [];
      state.queue_index = -1;
      resultsMessage.textContent = state.queue.length
        ? "Choose a result to play."
        : "No playable videos were found.";
      renderState();
      setMessage(state.queue.length
        ? "Choose a search result from the queue."
        : "No playable videos were found.");
    } catch (error) {
      setMessage(error.message, "bad");
    } finally {
      busy = false;
      renderState();
    }
  }

  async function manualControl(action, extra = {}) {
    if (!owner) {
      setMessage("Select \"Use this device\" before controlling playback here.", "bad");
      return null;
    }
    busy = true;
    renderState();
    setMessage();
    try {
      const result = await api("/api/media/control", "POST", { action, ...extra });
      applyState(result);
      if (result.command) await handleCommand(result.command);
      return result;
    } catch (error) {
      setMessage(error.message, "bad");
      return null;
    } finally {
      busy = false;
      renderState();
    }
  }

  form.addEventListener("submit", submitRequest);
  takeoverButton.addEventListener("click", () => claimPlayer(true));
  playPauseButton.addEventListener("click", () => {
    const wantPause = state.status === "playing" || state.status === "buffering";
    /* Playlist embedded mode: drive the iframe directly (the server has no
       single video to pause/resume for a playlist). */
    if (state.media_kind === "playlist"
        && state.playback_mode !== "host_browser" && iframeEl) {
      postToPlayer(wantPause ? "pauseVideo" : "playVideo", []);
      state.status = wantPause ? "paused" : "playing";
      renderState();
      return;
    }
    manualControl(wantPause ? "pause" : "play");
  });
  stopButton.addEventListener("click", () => manualControl("stop"));
  previousButton.addEventListener("click", () => {
    /* In embedded playlist mode, use the documented playlist postMessage
       command so YouTube's own playlist cursor advances; the server has no
       video queue for a playlist. */
    if (state.media_kind === "playlist"
        && state.playback_mode !== "host_browser" && iframeEl) {
      postToPlayer("previousVideo", []);
      return;
    }
    manualControl("previous");
  });
  nextButton.addEventListener("click", () => {
    if (state.media_kind === "playlist"
        && state.playback_mode !== "host_browser" && iframeEl) {
      postToPlayer("nextVideo", []);
      return;
    }
    manualControl("next");
  });
  seekBackButton.addEventListener("click", () =>
    manualControl("seek", { offset_seconds: -seekAmount() })
  );
  seekForwardButton.addEventListener("click", () =>
    manualControl("seek", { offset_seconds: seekAmount() })
  );
  seekSecondsInput.addEventListener("change", updateSeekLabels);
  tapToPlay.addEventListener("click", () => {
    tapToPlay.hidden = true;
    setMessage();
    postToPlayer("playVideo", []);
  });

  document.addEventListener("chat-event", async (event) => {
    const detail = event.detail || {};
    if (detail.topic === "media_control") {
      await handleCommand(detail);
    } else if (detail.topic === "media_state") {
      await reconcileState();
    }
  });

  window.addEventListener("pagehide", () => {
    stopProgressUpdates();
    clearTimeout(leaseTimer);
    leaseTimer = null;
    notifyRemoteVoice(false, true);
    if (mediaChannel) mediaChannel.close();
    fetch("/api/media/release", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf": csrf },
      body: JSON.stringify({ client_id: clientId }),
      keepalive: true,
    }).catch(() => {});
  });

  async function initialize() {
    updateSeekLabels();
    renderState();
    await claimPlayer(false);
    /* Auto-start the official embed after claim only when the server is in
       embedded mode.  If the server is already in host_browser mode (from a
       prior 101/150 or autoplay-block), claimPlayer showed the honest banner
       above — we must not build a second iframe or autoplay a duplicate. */
    if (owner && state.video_id && state.playback_mode !== "host_browser") {
      if (state.command) {
        await handleCommand(state.command);
      } else if (!iframeEl) {
        ensureIframe(state.video_id, state.position_seconds || 0);
      }
    }
  }

  initialize().catch((error) => setMessage(error.message, "bad"));
})();
