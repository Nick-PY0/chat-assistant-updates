"""Automatic cross-project key rotation.

User's policy variant of the plan's credential model:
  * Every non-disabled, non-invalid key participates in rotation --
    capacity scales with how many keys are stored. No paid-fallback tier.
  * A healthy session keeps its current key; adding keys never interrupts.
  * Auth failure -> mark invalid, move to the next key immediately.
  * Short-window 429 -> brief backoff on the same key; if it repeats,
    rotate to the next key.
  * Daily quota exhaustion -> the whole project group is blocked until the
    documented reset time (midnight Pacific + jitter), and rotation moves
    to the next *different* project group immediately.
  * Keys sharing a project label share one quota group and are treated as
    redundancy, never extra quota.
  * When nothing is eligible -> LOCAL_ONLY, with the earliest retry time
    reported so the pulse can schedule exactly one retry per window.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from chat_core.models.credentials import Credential, CredentialStore, utcnow


@dataclass
class NoEligibleKey(Exception):
    """Raised when every key is blocked; carries the earliest retry time."""

    earliest_retry: datetime | None

    def __str__(self) -> str:
        if self.earliest_retry:
            return f"no eligible credential until {self.earliest_retry.isoformat()}"
        return "no eligible credential"


class RotationPolicy:
    def __init__(self, store: CredentialStore) -> None:
        self.store = store

    async def pick(
        self,
        exclude_ids: set[str] | None = None,
        prefer_id: str | None = None,
        avoid_fingerprints: set[str] | None = None,
    ) -> Credential:
        """Choose the credential for the next session attempt.

        Order of preference:
          1. The explicitly preferred key (dashboard "Make active"), if eligible.
          2. The currently 'active' key (sticky sessions).
          3. Standby keys by priority, skipping blocked project groups.
        """
        exclude_ids = exclude_ids or set()
        avoid_fingerprints = avoid_fingerprints or set()
        now = utcnow()
        creds = await self.store.list(provider="gemini")

        def eligible(c: Credential) -> bool:
            return (
                c.id not in exclude_ids
                and c.project_fingerprint not in avoid_fingerprints
                and c.selectable_at(now)
            )

        pool = [c for c in creds if eligible(c)]
        if not pool:
            raise NoEligibleKey(self._earliest_retry(creds))

        if prefer_id:
            for c in pool:
                if c.id == prefer_id:
                    return c

        actives = [c for c in pool if c.status == "active"]
        if actives:
            return actives[0]

        pool.sort(key=lambda c: (c.priority, c.created_at))
        return pool[0]

    @staticmethod
    def _earliest_retry(creds: list[Credential]) -> datetime | None:
        times = [
            c.retry_after
            for c in creds
            if c.status in ("exhausted", "unavailable", "standby", "active") and c.retry_after
        ]
        return min(times) if times else None

    # ------------------------------------------------------------------
    async def promote(self, cred_id: str) -> None:
        """Make `cred_id` the single 'active' credential."""
        for c in await self.store.list(provider="gemini"):
            if c.id == cred_id:
                await self.store.set_status(c.id, "active")
            elif c.status == "active":
                await self.store.set_status(c.id, "standby")

    async def eligible_count(self) -> int:
        now = utcnow()
        return sum(1 for c in await self.store.list(provider="gemini") if c.selectable_at(now))
