"""Gemini Live gateway: session lifecycle + failover driver.

Owns the audio_in/audio_out queues shared with the audio engine and runs
the user's automatic cross-project rotation policy on every failure.
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timedelta

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore, utcnow
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from apps.live_gateway.rotation import NoEligibleKey, RotationPolicy
from integrations.gemini.errors import (
    GeminiFailure,
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
    next_quota_reset,
)
from integrations.gemini.live_client import LiveSession
from integrations.openai_rt.live_client import RealtimeSession
from integrations.relay.client import RelayClient, RelayError
from apps.live_gateway.relay_session import RelayVoiceSession
from apps.live_gateway.prompts import PROMPT_TOOLS_SUFFIX

log = logging.getLogger("gateway")

AUDIO_IN_MAX = 250   # ~20s: preserves a question while a provider connects
AUDIO_OUT_MAX = 120
RECONNECTABLE_SESSION_ENDS = frozenset({"closed", "server_go_away"})


@dataclass
class FailureAction:
    """What _apply_failure decided for the rest of this conversation."""

    exclude_key: bool       # stop trying this key in this conversation
    avoid_project: bool     # skip the whole project group too


class LiveGateway:
    def __init__(
        self,
        settings: Settings,
        db: Database,
        store: CredentialStore,
        bus: EventBus,
        state: StateMachine,
        tool_declarations: list[dict],
        tool_handler,
    ) -> None:
        self.settings = settings
        self.db = db
        self.store = store
        self.bus = bus
        self.state = state
        self.rotation = RotationPolicy(store)
        self.tool_declarations = tool_declarations
        self.tool_handler = tool_handler

        self.audio_in: asyncio.Queue[bytes] = asyncio.Queue(maxsize=AUDIO_IN_MAX)
        self.audio_out: asyncio.Queue[bytes] = asyncio.Queue(maxsize=AUDIO_OUT_MAX)

        self._session: LiveSession | None = None
        self._session_task: asyncio.Task | None = None
        self._wanted = asyncio.Event()          # a wake word wants a session
        self._stop = asyncio.Event()
        self._preferred_id: str | None = None
        self._rate_limit_strikes: dict[str, int] = {}
        self._last_window_retry: datetime | None = None
        self.current_credential_id: str | None = None
        self._session_intent_active = False
        self._keep_listening = False
        self._last_interaction_at = 0.0
        self._last_session_reason = ""
        self._gemini_resume_handle: str | None = None
        # A session generation identifies one logical hands-free lease.  It
        # advances only when a fresh wake/manual start is accepted.  Remote
        # microphone cleanup passes the generation it owns so a late socket
        # cannot tear down a newer conversation.
        self._voice_session_generation = 0
        # Explicit ends are a separate generation from natural provider
        # timeouts. Remote microphone owners use this boundary to stop old
        # queued speech from crossing a Goodbye/mute into the next wake, while
        # the transport itself may remain open in wake-listening mode.
        self._voice_end_generation = 0
        self._voice_end_event = asyncio.Event()

    # -- public controls -------------------------------------------------
    @property
    def voice_session_generation(self) -> int:
        return self._voice_session_generation

    @property
    def voice_end_generation(self) -> int:
        return self._voice_end_generation

    @property
    def session_intent_active(self) -> bool:
        """Whether the current logical wake/manual lease is still active."""
        return self._session_intent_active

    def request_session(self) -> int:
        """Accept a fresh wake/manual start and return its lease generation.

        Repeated requests while the same intent is connecting or active are
        idempotent.  The return value lets remote-microphone owners bind their
        cleanup to exactly the session they opened.
        """
        if self._session is not None or self._session_intent_active:
            return self._voice_session_generation
        self._voice_session_generation += 1
        self._gemini_resume_handle = None
        self._session_intent_active = True
        self._keep_listening = bool(getattr(self.settings, "continuous_conversation", True))
        self._last_interaction_at = time.monotonic()
        self.state.set(ChatState.CONNECTING, "starting conversation")
        self._wanted.set()
        return self._voice_session_generation

    def request_end_session(
        self,
        reason: str = "requested",
        *,
        expected_generation: int | None = None,
    ) -> bool:
        """End the current hands-free lease without waiting on the socket.

        Voice tools call this while their tool response is still being sent.
        The provider session then closes itself cleanly after acknowledging the
        tool, and the gateway cannot reconnect it in the meantime.  A caller
        that owns an older generation is stale and has no authority over the
        current session.
        """
        if (
            expected_generation is not None
            and expected_generation != self._voice_session_generation
        ):
            return False
        self._session_intent_active = False
        self._keep_listening = False
        self._gemini_resume_handle = None
        self._wanted.clear()
        self._last_session_reason = reason
        old_end_event = self._voice_end_event
        self._voice_end_generation += 1
        self._voice_end_event = asyncio.Event()
        old_end_event.set()
        while not self.audio_in.empty():
            try:
                self.audio_in.get_nowait()
            except asyncio.QueueEmpty:
                break
        return True

    async def end_session(
        self,
        reason: str = "requested",
        *,
        expected_generation: int | None = None,
    ) -> bool:
        if not self.request_end_session(
            reason, expected_generation=expected_generation
        ):
            return False
        if self._session:
            await self._session.close(reason)
        elif not self._stop.is_set() and self.state.raw_state != ChatState.LOCAL_ONLY:
            self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
        return True

    async def wait_for_voice_end(self, generation: int) -> int:
        """Wait until an explicit end newer than *generation* is requested.

        The Event instance is rotated on every end so observers cannot miss a
        stop between reading the generation and beginning their wait.
        Natural inactivity/provider closes intentionally do not signal this.
        """
        while generation == self._voice_end_generation:
            event = self._voice_end_event
            if generation != self._voice_end_generation:
                break
            await event.wait()
        return self._voice_end_generation

    def _conversation_timeout(self) -> float:
        """A wake opens a hands-free conversation, not merely one sentence."""
        if getattr(self.settings, "continuous_conversation", True):
            return float(max(
                self.settings.inactivity_timeout_seconds,
                getattr(self.settings, "continuous_session_seconds", 1800),
            ))
        return float(self.settings.inactivity_timeout_seconds)

    def _conversation_idle_elapsed(self) -> float:
        """Idle already accumulated by this lease, including reconnects."""
        if not self._last_interaction_at:
            return 0.0
        return max(0.0, time.monotonic() - self._last_interaction_at)

    def _on_session_activity(self) -> None:
        """A real user/model turn resets the rolling inactivity window."""
        if self._session_intent_active:
            self._last_interaction_at = time.monotonic()

    def _should_reconnect(self, reason: str) -> bool:
        """Reconnect maintenance closes, never inactivity or an explicit stop."""
        return (
            self._session_intent_active
            and self._keep_listening
            and reason in RECONNECTABLE_SESSION_ENDS
            and not self._stop.is_set()
        )

    def set_preferred(self, cred_id: str | None) -> None:
        """Dashboard 'Make active': applies to the NEXT session; the
        current healthy connection is never interrupted."""
        self._preferred_id = cred_id

    def interrupt(self) -> None:
        """Local VAD says the user is talking over playback."""
        if self._session:
            self._session._drain_output()

    # -- main loop ---------------------------------------------------------
    async def run(self) -> None:
        credentials_changed = self.bus.subscribe("credentials_changed")
        retry_eligible = self.bus.subscribe("quota_retry_window")
        while not self._stop.is_set():
            # drain control topics without blocking
            for q in (credentials_changed, retry_eligible):
                while not q.empty():
                    ev = q.get_nowait()
                    if ev.topic == "quota_retry_window":
                        # one retry attempt per window, driven by the pulse
                        if self.state.raw_state == ChatState.LOCAL_ONLY:
                            self._wanted.set()
            try:
                await asyncio.wait_for(self._wanted.wait(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            self._wanted.clear()
            await self._run_conversation()
            if self._should_reconnect(self._last_session_reason):
                # Provider maintenance/connection limits should not make the
                # owner repeat the wake word during an intentional session.
                await asyncio.sleep(0.5)
                self._wanted.set()
            else:
                self._session_intent_active = False
                self._keep_listening = False

    async def stop(self) -> None:
        self._stop.set()
        await self.end_session("shutdown")

    # ----------------------------------------------------------------------
    async def _run_conversation(self) -> None:
        """One conversation: pick key, connect, converse, classify failures,
        rotate until success or nothing is eligible."""
        if not self._session_intent_active:
            return
        # The owner picks the brain in Settings. Google is the default; the
        # others fall back to Google for this conversation if they cannot
        # start, with the reason spelled out in the log.
        brain = getattr(self.settings, "voice_brain", "gemini")
        if brain == "openai_live":
            if await self._run_openai_live():
                return
            if not self._session_intent_active:
                return
        elif brain == "relay":
            if await self._run_relay():
                return
            if not self._session_intent_active:
                return

        tried: set[str] = set()
        avoid_projects: set[str] = set()

        while not self._stop.is_set() and self._session_intent_active:
            self.state.set(ChatState.CONNECTING, "selecting credential")
            try:
                cred = await self.rotation.pick(
                    exclude_ids=tried,
                    prefer_id=self._preferred_id,
                    avoid_fingerprints=avoid_projects,
                )
            except NoEligibleKey as exc:
                await self._enter_local_only(exc.earliest_retry)
                return

            try:
                secret = await self.store.get_secret(cred.id)
            except KeyError:
                tried.add(cred.id)
                continue
            if not self._session_intent_active:
                del secret
                return

            self.current_credential_id = cred.id
            session_token = secrets.token_hex(16)
            session = LiveSession(
                api_key=secret,
                model=self.settings.gemini_model,
                system_prompt=self.settings.system_prompt + PROMPT_TOOLS_SUFFIX,
                tool_declarations=self.tool_declarations,
                tool_handler=self.tool_handler,
                audio_in=self.audio_in,
                audio_out=self.audio_out,
                voice=self.settings.gemini_voice,
                inactivity_timeout=self._conversation_timeout(),
                initial_idle_seconds=self._conversation_idle_elapsed(),
                speech_pause_ms=getattr(self.settings, "speech_pause_ms", 1600),
                resume_handle=self._gemini_resume_handle,
            )
            session.on_speaking_change = self._on_speaking_change
            session.on_interrupted = lambda: self.bus.publish("interrupted")
            session.on_activity = self._on_session_activity
            # Bind transcript callbacks to this specific session_token immutably.
            _stok = session_token  # captured in closure; does not change on reconnect
            session.on_input_transcript = lambda t, s=_stok: asyncio.ensure_future(
                self.db.add_transcript(s, "user", t))
            session.on_output_transcript = lambda t, s=_stok: asyncio.ensure_future(
                self.db.add_transcript(s, "assistant", t))
            self._session = session
            del secret  # keep plaintext lifetime minimal

            try:
                self.state.set(ChatState.LISTENING, f"session on \u2022\u2022\u2022\u2022{cred.masked_suffix[-4:]}")
                await self.store.mark_success(cred.id)
                if cred.status != "active":
                    await self.rotation.promote(cred.id)
                await self.db.usage(cred.id, "session_start")
                await self.db.open_voice_session(session_token, "gemini", cred.id)
                self.bus.publish("session", status="open", credential=cred.masked_suffix)
                reason = await session.run()
                self._gemini_resume_handle = session.resume_handle
                self._last_session_reason = reason
                await self.db.usage(cred.id, "session_end", reason)
                await self.db.close_voice_session(session_token, reason)
                self.bus.publish("session", status="closed", reason=reason)
                self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
                self._rate_limit_strikes.pop(cred.id, None)
                return
            except GeminiFailure as failure:
                self._last_session_reason = "failure"
                self._gemini_resume_handle = None
                await self.db.usage(cred.id, "session_failure", f"{failure.code}")
                await self.db.close_voice_session(session_token, f"failure:{failure.code}")
                await self.db.log("WARNING", "gateway", f"{cred.masked_suffix}: {failure}")
                action = await self._apply_failure(cred, failure)
                if action.exclude_key:
                    tried.add(cred.id)
                if action.avoid_project:
                    avoid_projects.add(cred.project_fingerprint)
                continue
            finally:
                self._session = None
                self.current_credential_id = None

    async def _apply_failure(self, cred, failure: GeminiFailure) -> FailureAction:
        """Update credential state per the rotation policy and decide how the
        conversation loop should proceed."""
        if failure.code == INVALID:
            await self.store.set_status(cred.id, "invalid", INVALID, None)
            self.bus.publish("credential_alert", id=cred.id, code=INVALID)
            return FailureAction(exclude_key=True, avoid_project=False)

        if failure.code == QUOTA_EXHAUSTED:
            # Policy: a spent project is ALWAYS blocked until the documented
            # reset (midnight in the configured quota timezone + jitter),
            # regardless of any provider-supplied retry timestamp.
            retry = next_quota_reset(
                self.settings.quota_reset_timezone,
                self.settings.quota_reset_jitter_seconds,
            )
            n = await self.store.mark_project_exhausted(cred.project_fingerprint, retry)
            self.bus.publish(
                "credential_alert", id=cred.id, code=QUOTA_EXHAUSTED, keys_blocked=n,
                retry_after=retry.isoformat(),
            )
            return FailureAction(exclude_key=True, avoid_project=True)

        if failure.code == RATE_LIMITED:
            strikes = self._rate_limit_strikes.get(cred.id, 0) + 1
            self._rate_limit_strikes[cred.id] = strikes
            if strikes < self.settings.rate_limit_rotate_after_failures:
                # brief same-key backoff, then RETRY THE SAME KEY
                delay = 5.0
                if failure.retry_after:
                    delay = max(1.0, min((failure.retry_after - utcnow()).total_seconds(), 60.0))
                await asyncio.sleep(delay)
                return FailureAction(exclude_key=False, avoid_project=False)
            self._rate_limit_strikes.pop(cred.id, None)
            retry = failure.retry_after or (utcnow() + timedelta(seconds=60))
            await self.store.set_status(cred.id, "unavailable", RATE_LIMITED, retry)
            return FailureAction(exclude_key=True, avoid_project=False)

        # UNAVAILABLE: brief backoff so the next key isn't hammered instantly,
        # block this key for a bounded window, then move on.
        await asyncio.sleep(min(self.settings.unavailable_retry_seconds, 30))
        await self.store.set_status(
            cred.id, "unavailable", UNAVAILABLE,
            utcnow() + timedelta(seconds=max(self.settings.unavailable_retry_seconds, 15) * 4),
        )
        return FailureAction(exclude_key=True, avoid_project=False)

    # -- the other brains ---------------------------------------------------
    @staticmethod
    def _brain_key_usable(cred, now) -> bool:
        """A key is worth trying if it isn't dead and isn't inside a backoff
        window. An expired window means: try again, re-mark if still broken."""
        if cred.status in ("invalid", "disabled"):
            return False
        if cred.retry_after and cred.retry_after > now:
            return False
        return True

    async def _run_openai_live(self) -> bool:
        """One conversation on the OpenAI live line. False means Google
        should take this conversation (the reason is already logged)."""
        now = utcnow()
        creds = [c for c in await self.store.list(provider="openai")
                 if self._brain_key_usable(c, now)]
        if not creds:
            await self.db.log(
                "WARNING", "gateway",
                "OpenAI brain is selected but no usable OpenAI key is saved "
                "(Providers page); using Google for this conversation")
            return False
        cred = creds[0]
        try:
            secret = await self.store.get_secret(cred.id)
        except KeyError:
            await self.db.log("WARNING", "gateway",
                              "the OpenAI key could not be unlocked; using Google instead")
            return False
        self.state.set(ChatState.CONNECTING, "openai live")
        session = RealtimeSession(
            api_key=secret,
            model=getattr(self.settings, "openai_live_model", "gpt-realtime"),
            system_prompt=self.settings.system_prompt + PROMPT_TOOLS_SUFFIX,
            tool_declarations=self.tool_declarations,
            tool_handler=self.tool_handler,
            audio_in=self.audio_in,
            audio_out=self.audio_out,
            voice=getattr(self.settings, "openai_voice", "alloy"),
            inactivity_timeout=self._conversation_timeout(),
            initial_idle_seconds=self._conversation_idle_elapsed(),
        )
        del secret
        session.on_speaking_change = self._on_speaking_change
        session.on_interrupted = lambda: self.bus.publish("interrupted")
        session.on_activity = self._on_session_activity
        self._session = session
        self.current_credential_id = cred.id
        session_token = secrets.token_hex(16)
        # Bind transcript callbacks to this specific session_token immutably.
        _stok_oai = session_token
        session.on_input_transcript = lambda t, s=_stok_oai: asyncio.ensure_future(
            self.db.add_transcript(s, "user", t))
        session.on_output_transcript = lambda t, s=_stok_oai: asyncio.ensure_future(
            self.db.add_transcript(s, "assistant", t))
        try:
            self.state.set(ChatState.LISTENING, "openai live session")
            await self.db.usage(cred.id, "session_start", "openai_live")
            await self.db.open_voice_session(session_token, "openai_live", cred.id)
            reason = await session.run()
            self._last_session_reason = reason
            await self.db.usage(cred.id, "session_end", reason)
            await self.db.close_voice_session(session_token, reason)
            self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
            return True
        except GeminiFailure as failure:
            self._last_session_reason = "failure"
            await self.db.usage(cred.id, "session_failure", failure.code)
            await self.db.close_voice_session(session_token, f"failure:{failure.code}")
            await self.db.log(
                "WARNING", "gateway",
                f"openai key {cred.masked_suffix}: {failure.code} -- {failure}; "
                "using Google for this conversation")
            await self._note_openai_failure(cred, failure)
            return False
        finally:
            self._session = None
            self.current_credential_id = None

    async def _note_openai_failure(self, cred, failure: GeminiFailure) -> None:
        """Reflect an OpenAI failure in the credential pill on the dashboard."""
        if failure.code == INVALID:
            await self.store.set_status(cred.id, "invalid", INVALID, None)
            self.bus.publish("credential_alert", id=cred.id, code=INVALID)
        elif failure.code == QUOTA_EXHAUSTED:
            await self.store.set_status(
                cred.id, "exhausted", QUOTA_EXHAUSTED, utcnow() + timedelta(hours=1))
        elif failure.code == RATE_LIMITED:
            await self.store.set_status(
                cred.id, "unavailable", RATE_LIMITED,
                failure.retry_after or (utcnow() + timedelta(seconds=60)))
        else:
            await self.store.set_status(
                cred.id, "unavailable", UNAVAILABLE,
                utcnow() + timedelta(seconds=max(self.settings.unavailable_retry_seconds, 15) * 4))

    async def _run_relay(self) -> bool:
        """One conversation through the relay. False = Google takes over."""
        url = (getattr(self.settings, "relay_url", "") or "").strip()
        if not url:
            await self.db.log(
                "WARNING", "gateway",
                "Relay brain is selected but no relay address is set "
                "(Settings page, Brain section); using Google for this conversation")
            return False
        relay_creds = [c for c in await self.store.list(provider="relay")
                       if self._brain_key_usable(c, utcnow())]
        if not relay_creds:
            await self.db.log(
                "WARNING", "gateway",
                "Relay brain is selected but no relay password is saved "
                "(Providers page); using Google for this conversation")
            return False
        try:
            password = await self.store.get_secret(relay_creds[0].id)
        except KeyError:
            await self.db.log("WARNING", "gateway",
                              "the relay password could not be unlocked; using Google instead")
            return False
        self.state.set(ChatState.CONNECTING, "relay")
        session_token = secrets.token_hex(16)
        try:
            # Construction can refuse bad addresses (e.g. plain http), so it
            # lives inside the same net as the session itself.
            session = RelayVoiceSession(
                RelayClient(url, password), self.settings, self.db, self.bus, self.state,
                self.tool_declarations, self.tool_handler,
                self.audio_in, self.audio_out,
                on_speaking_change=self._on_speaking_change,
                on_activity=self._on_session_activity,
                inactivity_timeout=self._conversation_timeout(),
                initial_idle_seconds=self._conversation_idle_elapsed(),
                session_id=session_token,
            )
            del password
            self._session = session
            await self.db.open_voice_session(session_token, "relay", relay_creds[0].id)
            reason = await session.run()
            self._last_session_reason = reason
            await self.db.close_voice_session(session_token, reason)
            self.state.set(ChatState.SLEEPING, f"session closed: {reason}")
            return True
        except RelayError as exc:
            self._last_session_reason = "failure"
            await self.db.usage(None, "session_failure", f"relay: {exc}")
            await self.db.close_voice_session(session_token, f"failure:relay:{exc}")
            await self.db.log("WARNING", "gateway",
                              f"relay: {exc} Using Google for this conversation.")
            return False
        finally:
            self._session = None

    async def _enter_local_only(self, earliest_retry: datetime | None) -> None:
        self._keep_listening = False
        self.state.set(ChatState.LOCAL_ONLY, "no eligible credential")
        quota_related = False
        for c in await self.store.list(provider="gemini"):
            if c.status == "exhausted":
                quota_related = True
                break
        self.bus.publish(
            "local_only",
            quota=quota_related,
            retry_at=earliest_retry.isoformat() if earliest_retry else None,
        )
        if earliest_retry:
            await self.db.set_setting("quota_retry_at", earliest_retry.isoformat())
        await self.db.log(
            "WARNING",
            "gateway",
            "entering local-only mode"
            + (f"; retry at {earliest_retry.isoformat()}" if earliest_retry else ""),
        )

    def _on_speaking_change(self, speaking: bool) -> None:
        if speaking:
            self.state.set(ChatState.SPEAKING, "model audio")
        else:
            self.state.set(ChatState.LISTENING, "turn complete")
