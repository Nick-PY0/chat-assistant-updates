"""Create keys for, and sign, Chat update manifests.

Chat refuses updates whose manifest is not signed by the publisher. This
script is the publisher side. Run it from the chat-assistant folder (it
imports the updater so both sides use the exact same payload format).

  python deployment/release/sign_manifest.py keygen
      Makes deployment/release/signing_key.pem (if missing) and prints the
      public key to embed in apps/updater/updater.py. Guard that .pem file:
      whoever holds it can publish updates to every install that trusts it.
      Never commit it, never include it in a release zip.

  python deployment/release/sign_manifest.py sign <latest.json> <release.zip>
      Fills in "sha256" (fingerprint of the zip) and "sig" in the manifest,
      in place. Upload the zip and the signed manifest together.

Set CHAT_SIGNING_KEY to a path to use a key file kept somewhere else.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

HERE = Path(__file__).resolve().parent
APP_ROOT = HERE.parents[1]  # .../chat-assistant
KEY_PATH = Path(os.environ.get("CHAT_SIGNING_KEY", HERE / "signing_key.pem"))


def _payload(manifest: dict) -> bytes:
    sys.path.insert(0, str(APP_ROOT))
    from apps.updater.updater import Updater  # single source of truth

    return Updater.manifest_payload(manifest)


def keygen() -> int:
    if KEY_PATH.exists():
        priv = serialization.load_pem_private_key(KEY_PATH.read_bytes(), password=None)
        print(f"key already exists: {KEY_PATH}")
    else:
        priv = ed25519.Ed25519PrivateKey.generate()
        KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
        KEY_PATH.write_bytes(
            priv.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )
        )
        try:
            KEY_PATH.chmod(0o600)
        except OSError:
            pass  # Windows: not supported; the file sits in your own folder
        print(f"new key written: {KEY_PATH}")
    pub = (
        priv.public_key()
        .public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        .hex()
    )
    print("public key (goes in apps/updater/updater.py UPDATE_PUBLIC_KEY_HEX):")
    print(pub)
    return 0


def sign(manifest_path: Path, zip_path: Path) -> int:
    if not KEY_PATH.exists():
        print(f"no signing key at {KEY_PATH} -- run keygen first")
        return 1
    priv = serialization.load_pem_private_key(KEY_PATH.read_bytes(), password=None)
    manifest = json.loads(manifest_path.read_text())
    if not str(manifest.get("version", "")).strip():
        print("manifest has no version -- refusing to sign")
        return 1
    digest = hashlib.sha256()
    with zip_path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            digest.update(chunk)
    manifest["sha256"] = digest.hexdigest()
    signature = priv.sign(_payload(manifest))
    manifest["sig"] = base64.b64encode(signature).decode()
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    print(
        f"signed {manifest_path.name}: version {manifest.get('version')}, "
        f"sha256 {manifest['sha256'][:16]}..."
    )
    return 0


def main(argv: list[str]) -> int:
    if argv[:1] == ["keygen"]:
        return keygen()
    if len(argv) == 3 and argv[0] == "sign":
        return sign(Path(argv[1]), Path(argv[2]))
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
