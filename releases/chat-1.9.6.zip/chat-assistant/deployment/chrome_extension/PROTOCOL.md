# Companion Extension WebSocket Protocol — Version 1

> **Authority**: `apps/tool_service/COMPANION_PROTOCOL.md` is the single source
> of truth.  This file is an extension-local digest.  If anything conflicts,
> the backend document wins.

---

## Endpoint

```
ws://127.0.0.1:<port>/ws/companion
```

All frames are **JSON text**.  Binary frames are ignored.  Maximum frame size:
**8 192 bytes** (server terminates the connection if exceeded).

---

## Connection lifecycle

```
Extension                          Server
   |                                  |
   |<---- TCP + HTTP upgrade -------->|
   |<---- welcome -------------------|   protocol=1
   |                                  |
   |----> hello (token or secret) --->|   authentication
   |<---- paired (secret, once) ------|   first pairing only
   |<---- auth_ok --------------------|
   |                                  |
   |<---- ping (id) -----------------|   ~every 20 s
   |----> pong (id) ----------------->|
   |                                  |
   |<---- command (id, action, ...) --|
   |----> ack (id, ok, error?) ------>|   within 6 s
   |                                  |
   |----> state (status, ...) ------->|   any time after auth
   |                                  |
   |<---- revoked -------------------|   on rotate / revoke / displacement
  close                             close
```

---

## Frame reference

### Server → Extension

| Frame        | Shape |
|--------------|-------|
| `welcome`    | `{ type: "welcome", protocol: 1 }` |
| `auth_ok`    | `{ type: "auth_ok", target: "browser_companion", session: N }` |
| `paired`     | `{ type: "paired", secret: "<base64url>" }` — once on first pairing |
| `auth_error` | `{ type: "auth_error", reason: "…" }` — socket closed after |
| `command`    | `{ type: "command", id: N, session: N, target: "browser_companion", action: "…", …payload }` |
| `ping`       | `{ type: "ping", id: N }` |
| `revoked`    | `{ type: "revoked", reason: "…" }` |

### Canonical actions (server → extension)

| Action               | Payload fields                                      | Notes |
|----------------------|-----------------------------------------------------|-------|
| `navigate_video`     | `video_id` (str, 11 chars), `start_seconds` (float, default 0) | Navigate to video; begin playback. |
| `navigate_playlist`  | `playlist_id` (str)                                 | Navigate to playlist. |
| `play`               | *(none)*                                            | Resume playback if paused. |
| `pause`              | *(none)*                                            | Pause current playback. |
| `stop`               | *(none)*                                            | Stop playback. |
| `next`               | *(none)*                                            | Next item in YouTube's native queue. |
| `previous`           | *(none)*                                            | Previous item. |
| `seek`               | `offset_seconds` (int), `target_seconds` (float)   | Relative seek; `target_seconds` is the absolute computed position. |
| `restart`            | *(none)*                                            | Seek to position 0. |
| `set_volume`         | `volume` (int, 0–100)                               | Absolute volume. |
| `adjust_volume`      | `delta` (int, negative to lower)                    | Relative volume. |
| `mute`               | *(none)*                                            | Mute. |
| `unmute`             | *(none)*                                            | Unmute. |
| `duck`               | `volume` (int, 0–100, optional, default 20)         | Lower volume for voice focus. |
| `restore`            | *(none)*                                            | Restore volume after duck. |

**Ad gate — FULL PASSIVITY (extension-enforced).** When an ad is playing the
extension is completely passive: **every one of the 15 actions** — including
`next`, `previous`, `duck`, and `restore` — is blocked. The extension acks
`busy_ad` and performs **no** navigation, **no** DOM click, **no** media
control, **no** volume mutation, and does **not** touch its saved pre-duck
state. The server also blocks ad-gated actions on its side; the extension gate
is the authoritative local defense.

The extension's ad-blocked set is exactly equal to the full action set — there
are no exceptions.

**Navigation ad-safety.** For `navigate_video` / `navigate_playlist` targeting
an **existing** YouTube tab, the background worker performs a **synchronous
fresh ad check** against that tab's content script *immediately before*
`tabs.update`:

* If content reports an ad → ack `busy_ad`, do not navigate.
* If content cannot confirm safely (unreachable, off-origin, malformed reply)
  → ack `busy_ad_unconfirmed`, do not navigate.
* Only when content confirms *no* ad is the tab navigated.

A **new** tab is created only when there is **no** existing target tab (no ad
context can exist), so new-tab navigation needs no ad check.

**preDuck lifecycle.** `duck` saves the pre-duck volume/mute once; `restore`
returns to it. Any **explicit non-voice** command (`play`, `pause`, `stop`,
`next`, `previous`, `seek`, `restart`, `set_volume`, `adjust_volume`, `mute`,
`unmute`, navigation) **drops the saved pre-duck state without restoring**, so a
later `restore` cannot overwrite the explicit change. `restore` mutates nothing
when no matching duck is pending.

### Extension → Server

#### `hello` — first frame after `welcome`

First pairing (one-time token):
```json
{ "type": "hello", "token": "<one-time-token>" }
```

Reconnect (persistent secret):
```json
{ "type": "hello", "secret": "<bridge-secret>" }
```

#### `ack`
```json
{ "type": "ack", "id": 42, "ok": true }
{ "type": "ack", "id": 42, "ok": false, "error": "ad_playing" }
```

#### `state`
```json
{
  "type":             "state",
  "session":          3,
  "target":           "browser_companion",
  "status":           "playing",
  "video_id":         "dQw4w9WgXcQ",
  "playlist_id":      "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l",
  "position_seconds": 42.5,
  "duration_seconds": 212.0,
  "volume":           85,
  "muted":            false,
  "ad_playing":       false
}
```

| Field              | Type     | Required | Description |
|--------------------|----------|----------|-------------|
| `session`          | int      | **yes**  | Current server session; frame dropped if wrong. |
| `target`           | string   | **yes**  | Must be `"browser_companion"`. |
| `status`           | string   | **yes**  | One of `playing`, `paused`, `ended`, `buffering`, `stopped`, `error`. |
| `video_id`         | string   | no       | Current video id. |
| `playlist_id`      | string   | no       | Current playlist id (empty when not in a playlist). |
| `position_seconds` | float    | no       | Playback position (0–86400). |
| `duration_seconds` | float    | no       | Total duration (0–86400). |
| `volume`           | int      | no       | Current volume (0–100). |
| `muted`            | bool     | no       | Muted state. |
| `ad_playing`       | bool     | no       | **True when a YouTube ad is playing.** Omit or `false` otherwise. When `true`, the server blocks all ad-gated commands. |

**`status` is always a valid wire value.** The extension never sends
`"ad_playing"` as a status; it sends `ad_playing: true` alongside a real
status (e.g. `"playing"` while the ad plays).

**Server fencing rules** (frame silently dropped if violated):
1. `target` ≠ `"browser_companion"`.
2. `session` ≠ current server session.
3. `status` not in the valid set.

#### `pong`
```json
{ "type": "pong", "id": <ping.id> }
```

---

## Auth lifecycle

| Event | Extension action |
|-------|-----------------|
| `paired` | Persist `secret` immediately; pairing token is NEVER stored. |
| `auth_ok` | Set `authenticated = true`; reset reconnect counter. |
| `auth_error` (on a secret) | Clear `bridge_secret`; report unpaired. |
| `revoked` | Clear `bridge_secret`; set `reconnectAttempt = 999` (suppress reconnect). |

---

## Security constraints

* **Loopback-only**: extension only connects to `127.x.x.x`, `localhost`, `::1`.
* **Server-derived IDs only**: the extension validates video/playlist IDs locally
  and derives canonical URLs itself — it never follows a raw URL from the bridge.
* **No token storage**: the one-time pairing token is held in memory only and
  cleared from the DOM immediately after the background receives it.
* **Target fencing**: commands with `target ≠ "browser_companion"` are rejected.
* **Session fencing**: state frames with the wrong session are silently dropped
  by the server.
