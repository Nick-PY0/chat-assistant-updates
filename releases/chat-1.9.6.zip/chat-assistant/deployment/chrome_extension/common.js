// common.js — shared constants and validators for the Chat YouTube Companion.
//
// Dependency-free. Imported by background.js and options.js (ES module scripts).
// Content script (classic script) inlines its own copy of the few constants it needs.
//
// Authority: apps/tool_service/COMPANION_PROTOCOL.md (server side of truth)
//
// SECURITY NOTE: No secrets here. The bridge secret lives only in
// chrome.storage.local, read exclusively by the background service worker.

// The ONLY origin this extension operates on.
export const YOUTUBE_ORIGIN = "https://www.youtube.com";

// The exact WebSocket path of the Chat companion bridge endpoint.
export const COMPANION_WS_PATH = "/ws/companion";

// chrome.storage.local keys.
export const STORAGE_KEYS = Object.freeze({
  bridgeBase:   "bridge_base",    // loopback base URL, e.g. ws://127.0.0.1:8756
  bridgeSecret: "bridge_secret",  // persistent bridge secret — NEVER logged
  paired:       "paired",         // boolean: a bridge_secret is held
});

// Internal message channel names (background ↔ content, background ↔ UI).
export const MSG = Object.freeze({
  // content -> background
  CONTENT_STATE: "content_state",   // periodic / edge-triggered playback state
  CONTENT_HELLO: "content_hello",   // content script announcing itself
  // background -> content
  COMMAND:       "command",         // trusted, validated command envelope
  AD_CHECK:      "ad_check",        // synchronous fresh ad-state probe before navigation
  // popup / options -> background
  GET_STATUS:    "get_status",
  PAIR:          "pair",            // initiate pairing with a one-time token
  UNPAIR:        "unpair",
  TEST_BRIDGE:   "test_bridge",     // tokenless reachability probe
});

// ---------------------------------------------------------------------------
// Canonical action allowlist (COMPANION_PROTOCOL.md §command table)
//
// navigate_video    video_id (str), start_seconds (float, default 0)
// navigate_playlist playlist_id (str)
// play              (none) — resume playback
// pause             (none)
// stop              (none)
// next              (none)
// previous          (none)
// seek              offset_seconds (int), target_seconds (float)
// restart           (none)
// set_volume        volume (int, 0–100)
// adjust_volume     delta (int, negative to lower)
// mute              (none)
// unmute            (none)
// duck              volume (int, 0–100, optional, default 20)
// restore           (none)
//
// FULL AD PASSIVITY: every action is blocked while an ad is playing.
// During an ad the extension performs NO navigation, NO click, NO media
// control, and NO volume mutation of any kind — including next/previous and
// the voice-focus duck/restore. The extension acks "busy_ad" and waits.
// ---------------------------------------------------------------------------
export const COMPANION_ACTIONS = Object.freeze([
  "navigate_video",
  "navigate_playlist",
  "play",
  "pause",
  "stop",
  "next",
  "previous",
  "seek",
  "restart",
  "set_volume",
  "adjust_volume",
  "mute",
  "unmute",
  "duck",
  "restore",
]);

// Actions blocked locally by the extension when an ad is playing.
// This is EXACTLY the full COMPANION_ACTIONS set — no exceptions. Every action,
// including duck/restore and next/previous, must ack busy_ad and mutate nothing
// while an ad is on screen.
export const AD_BLOCKED_ACTIONS = Object.freeze(new Set(COMPANION_ACTIONS));

// Valid wire status values for state frames (COMPANION_PROTOCOL.md §state).
export const VALID_STATUSES = Object.freeze(new Set([
  "playing", "paused", "ended", "buffering", "stopped", "error",
]));

// ---------------------------------------------------------------------------
// Loopback guard
// ---------------------------------------------------------------------------
const LOOPBACK_HOSTS = new Set(["127.0.0.1", "localhost", "[::1]", "::1"]);

/**
 * Validate that a base URL points at the loopback interface using ws/wss/http/https.
 * Returns a normalised origin string (no trailing slash) or throws.
 * Caller appends COMPANION_WS_PATH when opening the socket.
 */
export function validateBridgeBase(raw) {
  const text = String(raw || "").trim();
  if (!text) throw new Error("A bridge base URL is required.");
  let u;
  try { u = new URL(text); } catch (_e) { throw new Error("Not a valid URL."); }
  if (!["ws:", "wss:", "http:", "https:"].includes(u.protocol))
    throw new Error("The bridge URL must use ws://, wss://, http://, or https://.");
  const host = u.hostname.toLowerCase();
  if (!LOOPBACK_HOSTS.has(host))
    throw new Error("The bridge URL must point at the local loopback (127.0.0.1 or localhost).");
  return u.origin;
}

/** Validate a pairing token (one-time, from the Chat dashboard). */
export function validatePairingToken(raw) {
  const text = String(raw || "").trim();
  if (!text) throw new Error("A pairing token is required.");
  if (text.length < 8 || text.length > 512)
    throw new Error("Token length looks wrong (expected 8–512 characters).");
  if (!/^[A-Za-z0-9._~+/=:_-]+$/.test(text))
    throw new Error("Token contains disallowed characters.");
  return text;
}

/** Validate a bridge secret (persistent, issued by the Chat bridge on pairing). */
export function validateBridgeSecret(raw) {
  const text = String(raw || "").trim();
  if (!text) throw new Error("No bridge secret.");
  if (text.length < 8 || text.length > 512) throw new Error("Secret length invalid.");
  return text;
}

// ---------------------------------------------------------------------------
// ID validators and canonical URL builders.
// The extension NEVER accepts a raw URL from the bridge wire.
// ---------------------------------------------------------------------------

// Strict 11-character YouTube video ID.
const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;

// Public YouTube playlist prefixes (from integrations/youtube/client.py).
// LL/WL/HL are private and rejected.
const PLAYLIST_ID_RE = /^(?:PL|UU|FL|OL|RD|UL|LP)[A-Za-z0-9_-]{10,42}$/;
const PRIVATE_PLAYLIST_PREFIXES = ["LL", "WL", "HL"];

export function validateVideoId(raw) {
  const text = String(raw || "").trim();
  if (!VIDEO_ID_RE.test(text)) throw new Error("Invalid YouTube video id.");
  return text;
}

export function validatePlaylistId(raw) {
  const text = String(raw || "").trim();
  if (!PLAYLIST_ID_RE.test(text)) throw new Error("Invalid YouTube playlist id.");
  if (PRIVATE_PLAYLIST_PREFIXES.includes(text.slice(0, 2)))
    throw new Error("Private playlists cannot be played.");
  return text;
}

/** Return the canonical watch URL for a strictly validated video id. */
export function canonicalWatchUrl(videoId) {
  return `${YOUTUBE_ORIGIN}/watch?v=${validateVideoId(videoId)}`;
}

/** Return the canonical playlist URL for a strictly validated playlist id. */
export function canonicalPlaylistUrl(playlistId) {
  return `${YOUTUBE_ORIGIN}/playlist?list=${validatePlaylistId(playlistId)}`;
}
