#!/usr/bin/env bash
# package.sh — build a distributable extension zip.
#
# Produces chat-youtube-companion-<version>.zip containing ONLY the files the
# extension needs. It EXCLUDES the test harness, any credentials, VCS files,
# and OS cruft so no token, server code, or secret ever ships.
#
# Usage:   ./package.sh
# Requires: zip (and jq if available, else version is read with a fallback).
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

# Read version from manifest.json (jq if present, else grep fallback).
if command -v jq >/dev/null 2>&1; then
  VERSION="$(jq -r .version manifest.json)"
else
  VERSION="$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[^"]+"' manifest.json | head -1 | sed -E 's/.*"([0-9.]+)".*/\1/')"
fi
[ -n "$VERSION" ] || { echo "could not read version from manifest.json"; exit 1; }

OUT="chat-youtube-companion-${VERSION}.zip"
rm -f "$OUT"

# Explicit allow-list of shipped files. Anything not listed is NOT packaged.
FILES=(
  manifest.json
  background.js
  content.js
  common.js
  options.html
  options.js
  popup.html
  popup.js
  ui.css
  PROTOCOL.md
  icons/icon16.png
  icons/icon48.png
  icons/icon128.png
)

# Verify every file exists before zipping.
missing=0
for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then echo "MISSING: $f"; missing=1; fi
done
[ "$missing" -eq 0 ] || { echo "refusing to package: files missing"; exit 1; }

# Safety: never allow credential-like files into the package.
for pattern in "*.pem" "*.key" "*token*" "*secret*" "*.env" "*credentials*"; do
  hits="$(printf '%s\n' "${FILES[@]}" | grep -iE "${pattern//\*/.*}" || true)"
  if [ -n "$hits" ]; then echo "refusing: credential-like file in allow-list: $hits"; exit 1; fi
done

zip -q "$OUT" "${FILES[@]}"

echo "Packaged $OUT"
echo "Contents:"
unzip -l "$OUT"
echo ""
echo "Excluded from the package: harness/, package.sh, README.md, and anything"
echo "not in the explicit allow-list (no tokens or server code ship)."
