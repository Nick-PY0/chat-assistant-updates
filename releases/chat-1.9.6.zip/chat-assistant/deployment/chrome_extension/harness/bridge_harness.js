#!/usr/bin/env node
/*
 * bridge_harness.js — dependency-free local test bridge.
 *
 * Implements the SERVER side of the Chat CompanionBridge v1 protocol
 * (companion_bridge.py) using only Node built-ins: http, crypto, readline.
 * No npm packages.
 *
 * This matches the exact wire format:
 *   server sends: welcome, paired, auth_ok, auth_error, command, revoked, ping
 *   client sends: hello(token|secret), ack, state, pong
 *
 * Usage
 * -----
 *   node harness/bridge_harness.js [port]
 *   -> prints ws://127.0.0.1:<port>/ws/companion and a pairing token
 *
 *   In the extension pairing page:
 *     Bridge base URL: ws://127.0.0.1:<port>
 *     Token: <printed token>
 *   Click "Pair now".
 *
 *   Then type commands at the prompt (type 'help').
 *
 * Excluded from the distributed extension zip (see package.sh).
 */
"use strict";

const http     = require("http");
const crypto   = require("crypto");
const readline = require("readline");

const HOST      = "127.0.0.1";
const PORT      = Number(process.argv[2] || process.env.PORT || 8757);
const WS_PATH   = "/ws/companion";
const TARGET_ID = "browser_companion";
const PROTOCOL  = 1;

// Fresh one-time pairing token per run (never reused).
const PAIRING_TOKEN = crypto.randomBytes(24).toString("base64url");

// Stored bridge secret (hashed) — mirrors companion_bridge.py's salted hash.
let secretSalt = "";
let secretHash = "";
let sessionCounter = 0;
let activeConn  = null; // {socket, authenticated, target_id}
let cmdSeq      = 0;

function sha256hex(s) {
  return crypto.createHash("sha256").update(s, "utf8").digest("hex");
}
function hashOf(salt, value) {
  return sha256hex(salt + ":" + value);
}
function hmacEqual(a, b) {
  if (a.length !== b.length) {
    // constant-time: still run the compare but with the wrong data
    return crypto.timingSafeEqual(
      Buffer.from(a, "hex"),
      Buffer.from(b.padEnd(a.length, "0"), "hex")
    ) && false;
  }
  return crypto.timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
}

// ---- WebSocket RFC 6455 implementation ------------------------------------
const WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
function wsAcceptKey(k) {
  return crypto.createHash("sha1").update(k + WS_GUID).digest("base64");
}
function wsEncodeText(str) {
  const payload = Buffer.from(str, "utf8");
  const len = payload.length;
  let hdr;
  if (len < 126)       { hdr = Buffer.from([0x81, len]); }
  else if (len < 65536){ hdr = Buffer.alloc(4); hdr[0]=0x81; hdr[1]=126; hdr.writeUInt16BE(len,2); }
  else                 { hdr = Buffer.alloc(10); hdr[0]=0x81; hdr[1]=127; hdr.writeBigUInt64BE(BigInt(len),2); }
  return Buffer.concat([hdr, payload]);
}
function makeDecoder(onMsg, onClose) {
  let buf = Buffer.alloc(0);
  return (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 2) {
      const opcode = buf[0] & 0x0f;
      const masked  = !!(buf[1] & 0x80);
      let   len     = buf[1] & 0x7f;
      let   offset  = 2;
      if (len === 126) { if (buf.length < 4)  return; len = buf.readUInt16BE(2); offset = 4; }
      if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); offset = 10; }
      let mask;
      if (masked) { if (buf.length < offset+4) return; mask = buf.slice(offset, offset+4); offset += 4; }
      if (buf.length < offset + len) return;
      let payload = buf.slice(offset, offset + len);
      if (masked) {
        const out = Buffer.alloc(len);
        for (let i = 0; i < len; i++) out[i] = payload[i] ^ mask[i % 4];
        payload = out;
      }
      buf = buf.slice(offset + len);
      if (opcode === 0x8) { onClose(); return; }
      if (opcode === 0x1) onMsg(payload.toString("utf8"));
    }
  };
}
function wsSend(sock, obj) {
  try { sock.write(wsEncodeText(JSON.stringify(obj))); } catch (_e) {}
}
function wsClose(sock) {
  try { sock.destroy(); } catch (_e) {}
}

// ---- HTTP/WS server -------------------------------------------------------
const server = http.createServer((req, res) => {
  res.writeHead(200, {"content-type": "text/plain"});
  res.end("chat-companion-harness ok (protocol v" + PROTOCOL + ")\n");
});

server.on("upgrade", (req, socket) => {
  const urlPath = req.url.split("?")[0];
  if (urlPath !== WS_PATH || req.headers.upgrade !== "websocket") {
    socket.destroy(); return;
  }
  const key = req.headers["sec-websocket-key"];
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n" +
    "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
    "Sec-WebSocket-Accept: " + wsAcceptKey(key) + "\r\n\r\n"
  );

  // Displace any existing connection (single companion at a time).
  if (activeConn && activeConn.socket !== socket) {
    wsSend(activeConn.socket, {type:"revoked", reason:"replaced by a new companion"});
    wsClose(activeConn.socket);
  }
  const conn = { socket, authenticated: false, target_id: "" };
  activeConn = conn;
  console.log("[harness] new connection");

  // Send welcome immediately.
  wsSend(socket, { type: "welcome", protocol: PROTOCOL });

  // Auth deadline.
  const authTimer = setTimeout(() => {
    if (!conn.authenticated) {
      wsSend(socket, { type: "auth_error", reason: "authentication timed out" });
      wsClose(socket);
    }
  }, 10000);

  const decode = makeDecoder(
    (text) => handleFrame(conn, text, authTimer),
    () => { if (activeConn === conn) activeConn = null; console.log("[harness] disconnected"); }
  );
  socket.on("data", decode);
  socket.on("close", () => { clearTimeout(authTimer); if (activeConn === conn) activeConn = null; });
  socket.on("error", () => {});
});

function handleFrame(conn, text, authTimer) {
  let frame;
  try { frame = JSON.parse(text); } catch (_e) { return; }
  if (!frame || typeof frame !== "object") return;

  if (!conn.authenticated) {
    if (frame.type !== "hello") {
      wsSend(conn.socket, { type: "auth_error", reason: "authentication required" });
      wsClose(conn.socket);
      return;
    }
    handleHello(conn, frame, authTimer);
    return;
  }
  switch (frame.type) {
    case "ack":
      console.log("[harness] ack: cmd=" + frame.id + " ok=" + frame.ok + (frame.error ? " err="+frame.error : ""));
      break;
    case "state":
      // Session + target fencing (mirrors companion_bridge.py._handle_state).
      if (String(frame.target || "") !== TARGET_ID) break;
      if (typeof frame.session !== "number" || frame.session !== sessionCounter) break;
      const validStatus = new Set(["playing","paused","ended","buffering","stopped","error"]);
      if (!validStatus.has(String(frame.status || ""))) break;
      console.log("[harness] state:", JSON.stringify({
        status: frame.status,
        session: frame.session,
        video_id: frame.video_id || "",
        position_seconds: frame.position_seconds,
        volume: frame.volume,
        muted: frame.muted,
      }));
      break;
    case "pong":
      break;
    default:
      break;
  }
}

function handleHello(conn, frame, authTimer) {
  // Pairing path: one-time token.
  if (frame.token !== undefined) {
    const tok = String(frame.token || "");
    if (tok !== PAIRING_TOKEN) {
      wsSend(conn.socket, { type: "auth_error", reason: "invalid pairing token" });
      wsClose(conn.socket);
      return;
    }
    // Consume token: mint bridge secret.
    const secret = crypto.randomBytes(24).toString("base64url");
    secretSalt   = crypto.randomBytes(16).toString("hex");
    secretHash   = hashOf(secretSalt, secret);
    sessionCounter = 0;
    clearTimeout(authTimer);
    conn.authenticated = true;
    conn.target_id     = TARGET_ID;
    // Send paired THEN auth_ok (matches companion_bridge.py._handle_hello).
    wsSend(conn.socket, { type: "paired", secret });
    wsSend(conn.socket, { type: "auth_ok", target: TARGET_ID, session: sessionCounter });
    console.log("[harness] paired OK — secret issued");
    return;
  }
  // Reconnect path: bridge secret.
  if (frame.secret !== undefined) {
    const provided = String(frame.secret || "");
    if (!secretSalt || !secretHash || !hmacEqual(hashOf(secretSalt, provided), secretHash)) {
      wsSend(conn.socket, { type: "auth_error", reason: "invalid credentials" });
      wsClose(conn.socket);
      return;
    }
    clearTimeout(authTimer);
    conn.authenticated = true;
    conn.target_id     = TARGET_ID;
    wsSend(conn.socket, { type: "auth_ok", target: TARGET_ID, session: sessionCounter });
    console.log("[harness] reconnect auth OK, session=" + sessionCounter);
    return;
  }
  wsSend(conn.socket, { type: "auth_error", reason: "invalid credentials" });
  wsClose(conn.socket);
}

// ---- ping loop ------------------------------------------------------------
setInterval(() => {
  if (activeConn && activeConn.authenticated) {
    wsSend(activeConn.socket, { type: "ping", id: Date.now() });
  }
}, 20000);

// ---- command console -------------------------------------------------------
server.listen(PORT, HOST, () => {
  console.log("=".repeat(60));
  console.log("Chat YouTube Companion — local test bridge");
  console.log("Protocol version:", PROTOCOL);
  console.log("Bridge base URL : ws://" + HOST + ":" + PORT);
  console.log("  → extension connects to ws://" + HOST + ":" + PORT + WS_PATH);
  console.log("One-time pairing token:");
  console.log("    " + PAIRING_TOKEN);
  console.log("Pairing page: enter base URL and token, click 'Pair now'.");
  console.log("=".repeat(60));
  console.log("Type 'help' for commands. Ctrl+C to quit.");
  prompt();
});

const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "> " });
function prompt() { rl.prompt(); }

function sendCmd(action, args) {
  if (!activeConn || !activeConn.authenticated) { console.log("(not connected/authed)"); return; }
  cmdSeq++;
  sessionCounter++; // simulate a new session for each command
  const frame = { type: "command", id: cmdSeq, session: sessionCounter, target: TARGET_ID, action, ...args };
  wsSend(activeConn.socket, frame);
  console.log("[harness] sent:", JSON.stringify({ id: cmdSeq, session: sessionCounter, action, ...args }));
}

rl.on("line", (line) => {
  const parts = line.trim().split(/\s+/);
  const cmd = (parts[0] || "").toLowerCase();
  const arg = parts[1];
  switch (cmd) {
    case "": break;
    case "help":
      console.log(`commands:
  video <11-char-id> [start_seconds]   play action with video_id
  playlist <playlist-id>               play_playlist action
  pause | stop | mute | unmute | restore
  seek <offset_seconds> <target>       seek action
  volume <0-100>                       set_volume action
  duck [level]                         duck to level (default 20)
  revoke                               send revoked frame
  bad                                  send unknown action (rejected)
  quit`);
      break;
    case "pause": case "stop": case "mute": case "unmute": case "restore":
      sendCmd(cmd); break;
    case "video":
      sendCmd("navigate_video", { video_id: arg || "dQw4w9WgXcQ", start_seconds: Number(parts[2] || 0) }); break;
    case "playlist":
      sendCmd("navigate_playlist", { playlist_id: arg || "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l" }); break;
    case "play":
      sendCmd("play"); break;
    case "next":
      sendCmd("next"); break;
    case "previous":
      sendCmd("previous"); break;
    case "restart":
      sendCmd("restart"); break;
    case "seek":
      sendCmd("seek", { offset_seconds: Number(arg || 0), target_seconds: Number(parts[2] || 0) }); break;
    case "volume":
      sendCmd("set_volume", { volume: Number(arg || 50) }); break;
    case "volrel":
      sendCmd("adjust_volume", { delta: Number(arg || 10) }); break;
    case "duck":
      // COMPANION_PROTOCOL.md: duck payload field is "volume" (not "level")
      sendCmd("duck", { volume: Number(arg || 20) }); break;
    case "revoke":
      if (activeConn) { wsSend(activeConn.socket, { type: "revoked", reason: "manual revoke from harness" }); }
      break;
    case "bad":
      sendCmd("delete_everything"); break;
    case "quit": case "exit":
      rl.close(); return;
    default: console.log("unknown command; type 'help'");
  }
  prompt();
});

rl.on("close", () => { console.log("bye"); process.exit(0); });
