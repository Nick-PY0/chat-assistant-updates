#!/usr/bin/env node
/*
 * static_check.js — dependency-free static validation of the extension.
 *
 * Authority: apps/tool_service/COMPANION_PROTOCOL.md
 *
 * Checks:
 *   1. manifest: MV3, youtube-only scope, minimal permissions, files exist.
 *   2. background.js: correct protocol frame types, action names, ad gate,
 *      auth lifecycle, canonical URL builders, secret handling.
 *   3. content.js: ad detection, ad gate (duck/restore NOT blocked), valid
 *      wire status always present, playlist_id validation, origin check.
 *   4. common.js: exact action allowlist from COMPANION_PROTOCOL.md,
 *      AD_BLOCKED_ACTIONS set, loopback guard, URL builders.
 *   5. No token/secret is ever logged.
 *   6. /ws/companion path is consistent across files.
 *
 * Exit 0 = all passed, non-zero = failures.
 */
"use strict";

const fs   = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
let failures = 0;

function ok(msg)  { console.log("  ok  " + msg); }
function bad(msg) { console.log("FAIL  " + msg); failures++; }
function has(hay, needle, label) {
  String(hay).includes(needle) ? ok(label) : bad(label + " (missing: " + JSON.stringify(needle) + ")");
}
function notin(hay, needle, label) {
  !String(hay).includes(needle) ? ok(label) : bad(label + " (must NOT contain: " + JSON.stringify(needle) + ")");
}
function readText(rel) { return fs.readFileSync(path.join(root, rel), "utf8"); }
function exists(rel)   { return fs.existsSync(path.join(root, rel)); }

console.log("Static check: Chat YouTube Companion (authority: COMPANION_PROTOCOL.md)");

// ── 1. Manifest ──────────────────────────────────────────────────────────────
let manifest;
try {
  manifest = JSON.parse(readText("manifest.json"));
  ok("manifest.json parses");
} catch (e) { bad("manifest.json parses: " + e.message); process.exit(1); }

manifest.manifest_version === 3 ? ok("manifest_version is 3")
  : bad("manifest_version must be 3, got " + manifest.manifest_version);

const hostPerms = manifest.host_permissions || [];
(hostPerms.length === 1 && hostPerms[0] === "https://www.youtube.com/*")
  ? ok("host_permissions limited to youtube.com only")
  : bad("host_permissions must be ['https://www.youtube.com/*'], got " + JSON.stringify(hostPerms));

for (const p of (manifest.permissions || [])) {
  if (p === "<all_urls>" || String(p).includes("://*/"))
    bad("broad permission present: " + p);
}
ok("permissions: " + JSON.stringify(manifest.permissions || []));

const cs = (manifest.content_scripts || [])[0] || {};
JSON.stringify(cs.matches) === JSON.stringify(["https://www.youtube.com/*"])
  ? ok("content script matches youtube.com only")
  : bad("content_scripts.matches must be ['https://www.youtube.com/*'], got " + JSON.stringify(cs.matches));

const referenced = [
  manifest.background && manifest.background.service_worker,
  manifest.options_page,
  manifest.action && manifest.action.default_popup,
  ...(cs.js || []),
].filter(Boolean);
for (const f of referenced) {
  exists(f) ? ok("exists: " + f) : bad("missing referenced file: " + f);
}
for (const [sz, f] of Object.entries(manifest.icons || {})) {
  exists(f) ? ok("icon " + sz + ": " + f) : bad("missing icon " + sz + ": " + f);
}

// ── 2. background.js ─────────────────────────────────────────────────────────
const bg = readText("background.js");

// Protocol path
has(bg, "COMPANION_WS_PATH",        "bg: imports COMPANION_WS_PATH");
has(bg, "/ws/companion",            "bg: has /ws/companion literal");

// Hello frames
has(bg, '{ type: "hello", secret',  "bg: hello(secret) for reconnect");
has(bg, '{ type: "hello", token }', "bg: hello(token) for pairing");

// Server→ext frame handling
has(bg, '"paired"',                  "bg: handles paired frame");
has(bg, "storeSecret",               "bg: stores secret after paired");
has(bg, '"auth_ok"',                 "bg: handles auth_ok");
has(bg, '"auth_error"',              "bg: handles auth_error");
has(bg, "clearSecret",               "bg: clears secret on auth_error/revoked");
has(bg, '"revoked"',                 "bg: handles revoked frame");
has(bg, "reconnectAttempt = 999",    "bg: suppresses reconnect after revoked");
has(bg, '"pong"',                    "bg: sends pong on ping");
has(bg, '"ack"',                     "bg: sends ack frames");

// Correct action names per COMPANION_PROTOCOL.md
has(bg, '"navigate_video"',          "bg: navigate_video action");
has(bg, '"navigate_playlist"',       "bg: navigate_playlist action");
notin(bg, '"play_playlist"',         "bg: does NOT use old play_playlist name");

// Navigation uses canonical URL builders from validated IDs
has(bg, "validateVideoId",           "bg: validates video_id before navigate");
has(bg, "validatePlaylistId",        "bg: validates playlist_id before navigate");
has(bg, "canonicalWatchUrl",         "bg: builds canonical watch URL");
has(bg, "canonicalPlaylistUrl",      "bg: builds canonical playlist URL");
has(bg, "frame.video_id",            "bg: reads video_id from navigate_video frame");
has(bg, "frame.playlist_id",         "bg: reads playlist_id from navigate_playlist frame");
has(bg, "frame.start_seconds",       "bg: reads start_seconds from navigate_video frame");

// Ad gate — FULL PASSIVITY (background)
has(bg, "AD_BLOCKED_ACTIONS",        "bg: imports AD_BLOCKED_ACTIONS");
has(bg, "adPlaying",                 "bg: tracks adPlaying flag");
has(bg, 'ackErr("busy_ad")',         "bg: acks busy_ad during ad");

// Navigation ad-safety: synchronous fresh ad check before navigating an
// existing tab; new-tab creation only when no existing tab.
has(bg, "freshAdCheck",              "bg: has synchronous fresh ad check for navigation");
has(bg, "MSG.AD_CHECK",              "bg: sends AD_CHECK probe to content");
has(bg, "navigateYouTubeGuarded",    "bg: guarded navigation function");
has(bg, '"busy_ad_unconfirmed"',     "bg: rejects navigation when ad state cannot be confirmed");
has(bg, "chrome.tabs.update",        "bg: navigates existing tab via tabs.update");
has(bg, "chrome.tabs.create",        "bg: creates new tab only when no existing tab");
// The fresh ad check must happen BEFORE tabs.update (guard ordering).
const guardIdx  = bg.indexOf("freshAdCheck(tab.id)");
const updateIdx = bg.indexOf("chrome.tabs.update(tab.id");
(guardIdx !== -1 && updateIdx !== -1 && guardIdx < updateIdx)
  ? ok("bg: fresh ad check runs before tabs.update")
  : bad("bg: fresh ad check must run before tabs.update");

// adjust_volume with delta
has(bg, '"adjust_volume"',           "bg: handles adjust_volume action");
has(bg, "frame.delta",               "bg: reads delta from adjust_volume frame");

// duck payload field is "volume" per COMPANION_PROTOCOL.md §duck
has(bg, "frame.volume",              "bg: reads volume from duck/set_volume frames");

// next/previous route through the generic content-script path (no special casing).
// background.js gates them via COMPANION_ACTIONS.includes(action); the presence of
// "next" and "previous" in COMPANION_ACTIONS is verified in the common.js section.
has(bg, "COMPANION_ACTIONS.includes", "bg: COMPANION_ACTIONS.includes gates all actions (incl. next/previous)");
has(bg, '"action_not_allowed"',       "bg: actions outside allowlist are rejected");

// State relay includes ad_playing and playlist_id
has(bg, "ad_playing",                "bg: relays ad_playing in state frame");
has(bg, "playlist_id",               "bg: relays playlist_id in state frame");

// Target
has(bg, '"browser_companion"',       "bg: TARGET_ID = browser_companion");
has(bg, '"wrong_target"',            "bg: rejects wrong target");
has(bg, '"action_not_allowed"',      "bg: rejects unknown actions");

// Secret storage keys
has(bg, "STORAGE_KEYS.bridgeSecret", "bg: uses bridgeSecret storage key");
notin(bg, "pairing_token",           "bg: does NOT store pairing_token");
notin(bg, "pairingToken",            "bg: does NOT store pairingToken");

// ── 3. content.js ────────────────────────────────────────────────────────────
const content = readText("content.js");

// Correct action names
has(content, '"navigate_video"',     "content: navigate_video name present (rejected as navigation_only)");
has(content, '"navigate_playlist"',  "content: navigate_playlist name present (rejected as navigation_only)");
notin(content, '"play_playlist"',    "content: does NOT use old play_playlist name");

// Ad detection
has(content, "isAdPlaying",          "content: isAdPlaying function");
has(content, "ad-showing",           "content: checks ad-showing class");
has(content, "ad-interrupting",      "content: checks ad-interrupting class");

// State always includes ad_playing boolean
has(content, "ad_playing",           "content: includes ad_playing in state");

// State has playlist_id with strict validation
has(content, "currentPlaylistId",    "content: currentPlaylistId function");
has(content, "PLAYLIST_ID_RE",       "content: playlist ID regex");
has(content, "PRIVATE_PL_PREFIXES",  "content: private playlist prefix guard");
has(content, "playlist_id",          "content: includes playlist_id in state");

// Status is ALWAYS a valid wire status (never "ad_playing" on the wire)
has(content, "videoStatus",          "content: videoStatus helper for wire status");
has(content, '"stopped"',            "content: stopped status");
has(content, '"buffering"',          "content: buffering status");
has(content, "readyState",           "content: uses readyState for buffering");
notin(content, 'status: "ad_playing"', 'content: status field is never set to "ad_playing"');

// Ad gate — FULL PASSIVITY: AD_BLOCKED is exactly ALL_ACTIONS.
has(content, "new Set(ALL_ACTIONS)",   "content: AD_BLOCKED === ALL_ACTIONS (full passivity)");
has(content, 'error: "busy_ad"',       "content: acks busy_ad for blocked actions during ad");
// The full-passivity gate must return before any player mutation or preDuck touch.
has(content, "if (isAdPlaying() && AD_BLOCKED.has(action))", "content: ad gate precedes all mutation");

// Synchronous ad-check probe support.
has(content, "MSG_AD_CHECK",           "content: handles AD_CHECK probe");
has(content, "ad_playing: !!ad",       "content: AD_CHECK replies with a boolean ad_playing");

// preDuck lifecycle: explicit non-voice command drops preDuck WITHOUT restoring.
has(content, "VOICE_FOCUS_ACTIONS",    "content: has VOICE_FOCUS_ACTIONS set");
has(content, "if (!VOICE_FOCUS_ACTIONS.has(action)) {", "content: explicit command drops preDuck");
has(content, "preDuck = null;",        "content: preDuck is cleared without restore on explicit command");

// duck uses "volume" param (not "level") per COMPANION_PROTOCOL.md
has(content, "params.volume",        "content: duck reads params.volume");

// adjust_volume with delta
has(content, '"adjust_volume"',      "content: adjust_volume case");
has(content, "params.delta",         "content: adjust_volume reads params.delta");

// next/previous/restart/play controls
has(content, '"next"',               "content: next action");
has(content, '"previous"',           "content: previous action");
has(content, '"restart"',            "content: restart action");
has(content, 'case "play"',          "content: play (resume) action");
has(content, "ytp-next-button",      "content: uses .ytp-next-button");
has(content, "ytp-prev-button",      "content: uses .ytp-prev-button");

// seek uses target_seconds + offset_seconds
has(content, "target_seconds",       "content: seek uses target_seconds");
has(content, "offset_seconds",       "content: seek uses offset_seconds");

// Origin and sender trust
has(content, "window.location.origin === YOUTUBE_ORIGIN", "content: validates origin");
has(content, "chrome.runtime.id",    "content: checks sender.id == runtime.id");

// ── 4. common.js ─────────────────────────────────────────────────────────────
const common = readText("common.js");

has(common, "COMPANION_WS_PATH",     "common: exports COMPANION_WS_PATH");
has(common, "/ws/companion",         "common: /ws/companion literal");
has(common, "LOOPBACK_HOSTS",        "common: loopback guard");
has(common, "AD_BLOCKED_ACTIONS",    "common: exports AD_BLOCKED_ACTIONS");
has(common, "VALID_STATUSES",        "common: exports VALID_STATUSES");

// Exact action list from COMPANION_PROTOCOL.md
const requiredActions = [
  "navigate_video", "navigate_playlist",
  "play", "pause", "stop",
  "next", "previous",
  "seek", "restart",
  "set_volume", "adjust_volume",
  "mute", "unmute",
  "duck", "restore",
];
for (const a of requiredActions) {
  has(common, '"' + a + '"', "common: COMPANION_ACTIONS includes " + a);
}
notin(common, '"play_playlist"',     "common: does NOT list old play_playlist");
notin(common, '"navigate_video",\n  "navigate_playlist",\n  "play",\n  "play_playlist"',
              "common: old play_playlist not in list");

// FULL AD PASSIVITY: AD_BLOCKED_ACTIONS must equal the full COMPANION_ACTIONS
// set — derived directly from it so it can never drift.
has(common, "new Set(COMPANION_ACTIONS)",
            "common: AD_BLOCKED_ACTIONS === new Set(COMPANION_ACTIONS) (full passivity)");
// The AD_BLOCKED_ACTIONS declaration must NOT enumerate a partial subset.
const adBlockedDecl = common.slice(
  common.indexOf("export const AD_BLOCKED_ACTIONS"),
  common.indexOf("// Valid wire status")
);
notin(adBlockedDecl, '"navigate_video",',
            "common: AD_BLOCKED_ACTIONS is not a hand-listed partial subset");

has(common, "validateBridgeBase",    "common: validateBridgeBase exported");
has(common, "validatePairingToken",  "common: validatePairingToken exported");
has(common, "validateVideoId",       "common: validateVideoId exported");
has(common, "validatePlaylistId",    "common: validatePlaylistId exported");

// ── 5. No secret/token logging ────────────────────────────────────────────────
const LOG_RE = /console\.(log|info|debug|warn|error)\s*\([^)]*(?:bridge_secret|bridgeSecret|pairing_token|pairingToken)\b/;
for (const [name, src] of [["background.js", bg], ["content.js", content], ["options.js", readText("options.js")]]) {
  LOG_RE.test(src) ? bad(name + " appears to log a secret/token") : ok(name + " does not log secrets/tokens");
}

// ── 6. /ws/companion path consistency ────────────────────────────────────────
const allHavePath = bg.includes("/ws/companion") && common.includes("/ws/companion") &&
                    readText("PROTOCOL.md").includes("/ws/companion");
allHavePath ? ok("/ws/companion consistent across bg+common+PROTOCOL.md")
            : bad("/ws/companion path inconsistency across files");

// ── Result ───────────────────────────────────────────────────────────────────
console.log("");
if (failures) { console.log(failures + " check(s) FAILED"); process.exit(1); }
else           { console.log("All static checks passed."); }
