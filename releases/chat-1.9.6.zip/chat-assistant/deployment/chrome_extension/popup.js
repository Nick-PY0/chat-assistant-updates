// popup.js — compact status popup + link to the pairing page.
import { MSG } from "./common.js";

const statusEl = document.getElementById("status");
const detailEl = document.getElementById("detail");
const dotEl    = document.getElementById("dot");

document.getElementById("open").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

function sendToBg(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (resp) => {
      void chrome.runtime.lastError;
      resolve(resp || { ok: false });
    });
  });
}

async function refresh() {
  const res = await sendToBg({ type: MSG.GET_STATUS });
  const s = (res && res.status) || {};
  if (!s.paired) {
    statusEl.textContent = "Not paired";
    dotEl.className      = "dot";
    detailEl.textContent = "Open pairing & settings to connect.";
  } else if (s.connected) {
    statusEl.textContent = "Connected";
    dotEl.className      = "dot good";
    detailEl.textContent = s.detail ? s.detail : "Bridge ready.";
  } else {
    statusEl.textContent = "Paired · reconnecting";
    dotEl.className      = "dot warn";
    detailEl.textContent = s.detail ? s.detail : "Trying to reach /ws/companion…";
  }
}

refresh();
setInterval(refresh, 2000);
