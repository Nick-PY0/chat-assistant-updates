// content.js — runs ONLY on https://www.youtube.com/* (manifest matches).
//
// Classic content script (no ES module imports). Constants are inlined below.
// Authority: apps/tool_service/COMPANION_PROTOCOL.md
//
// Responsibilities
// ----------------
// 1. Observe the standard HTML5 <video> element and report playback state to
//    the background service worker every ~1 second and on every media event.
//
// 2. Every state report includes:
//    - status: always a valid wire status (playing|paused|ended|buffering|
//      stopped|error) — NEVER omitted, even during ads.
//    - ad_playing: boolean — true when a YouTube ad is detected.
//    - playlist_id: strictly validated ?list= parameter (empty string otherwise).
//    - video_id, position_seconds, duration_seconds, volume, muted.
//
// 3. Accept ONLY trusted commands from our own background worker (verified via
//    sender.id == chrome.runtime.id).
//
// 4. Ad gate (COMPANION_PROTOCOL.md §Ad gate):
//    - Ad-blocked actions (navigate_video, navigate_playlist, play, pause, stop,
//      seek, restart, set_volume, adjust_volume, mute, unmute) → rejected with
//      error:"ad_playing".
//    - duck and restore are NOT blocked during ads (per spec §Voice-focus).
//
// 5. Never builds or navigates to any external URL (navigation = background).

(() => {
  "use strict";

  // ── Inlined constants (must stay in sync with common.js) ────────────────
  const YOUTUBE_ORIGIN      = "https://www.youtube.com";
  const MSG_CONTENT_STATE   = "content_state";
  const MSG_CONTENT_HELLO   = "content_hello";
  const MSG_COMMAND         = "command";
  const MSG_AD_CHECK        = "ad_check";

  // All canonical actions (COMPANION_PROTOCOL.md §command table).
  const ALL_ACTIONS = new Set([
    "navigate_video", "navigate_playlist",
    "play", "pause", "stop", "next", "previous",
    "seek", "restart",
    "set_volume", "adjust_volume",
    "mute", "unmute",
    "duck", "restore",
  ]);

  // FULL AD PASSIVITY: every action is blocked while an ad is playing.
  // AD_BLOCKED is EXACTLY ALL_ACTIONS — no exceptions. During an ad the content
  // script performs NO media control, NO click, NO volume mutation, and does not
  // touch preDuck state. It acks busy_ad and waits.
  const AD_BLOCKED = new Set(ALL_ACTIONS);

  // Actions that are part of the voice-focus lifecycle. Any OTHER action is an
  // "explicit" (non-voice) command; when one arrives, a pending duck's saved
  // pre-duck state must be dropped WITHOUT restoring, so a later restore cannot
  // overwrite the explicit mute/volume/stop/navigation the user just issued.
  const VOICE_FOCUS_ACTIONS = new Set(["duck", "restore"]);

  // Valid wire status values (COMPANION_PROTOCOL.md §state).
  const VALID_STATUSES = new Set([
    "playing", "paused", "ended", "buffering", "stopped", "error",
  ]);

  // Strict playlist ID pattern (mirrors integrations/youtube/client.py).
  const PLAYLIST_ID_RE = /^(?:PL|UU|FL|OL|RD|UL|LP)[A-Za-z0-9_-]{10,42}$/;
  const PRIVATE_PL_PREFIXES = ["LL", "WL", "HL"];

  // ── Origin guard ─────────────────────────────────────────────────────────
  function isYouTube() {
    try { return window.location.origin === YOUTUBE_ORIGIN; } catch (_e) { return false; }
  }
  if (!isYouTube()) return;

  // ── Worker state ─────────────────────────────────────────────────────────
  let preDuck      = null;  // {volume: 0..1, muted: bool} before duck
  let lastStateJson = "";
  let reportTimer  = null;

  // ── Player helpers ────────────────────────────────────────────────────────
  function getVideo() {
    const v = document.querySelector(
      ".html5-main-video, video.video-stream, video.html5-main-video, video"
    );
    return v instanceof HTMLMediaElement ? v : null;
  }

  // YouTube ad detection: primary signal is the player container CSS class.
  // Secondary: visible ad overlay elements.
  function isAdPlaying() {
    const player = document.querySelector("#movie_player, .html5-video-player");
    if (player && player.classList) {
      if (
        player.classList.contains("ad-showing") ||
        player.classList.contains("ad-interrupting")
      ) return true;
    }
    const overlay = document.querySelector(".ytp-ad-player-overlay, .ytp-ad-module, .ytp-ad-text");
    if (overlay && overlay.offsetParent !== null) return true;
    return false;
  }

  // Extract current video_id from location (read-only; never used to construct URLs).
  function currentVideoId() {
    try {
      const v = new URLSearchParams(window.location.search).get("v") || "";
      return /^[A-Za-z0-9_-]{11}$/.test(v) ? v : "";
    } catch (_e) { return ""; }
  }

  // Extract and strictly validate the current playlist_id from location.
  // Returns empty string when not in a valid public playlist context.
  function currentPlaylistId() {
    try {
      const list = new URLSearchParams(window.location.search).get("list") || "";
      if (!PLAYLIST_ID_RE.test(list)) return "";
      if (PRIVATE_PL_PREFIXES.includes(list.slice(0, 2))) return "";
      return list;
    } catch (_e) { return ""; }
  }

  // Map the raw HTML5 <video> state to a valid wire status.
  function videoStatus(v) {
    if (!v)            return "stopped";
    if (v.ended)       return "ended";
    if (!v.paused && v.readyState < 3) return "buffering";
    if (!v.paused && !v.seeking)       return "playing";
    if (v.paused && v.currentTime > 0) return "paused";
    return "stopped";
  }

  // Build the full state object to send to the background.
  // - status is always a valid wire status, even during ads.
  // - ad_playing is always present as a boolean.
  // - playlist_id is always present (empty string outside playlists).
  function buildState() {
    const ad       = isAdPlaying();
    const v        = getVideo();
    const videoId  = currentVideoId();
    const listId   = currentPlaylistId();
    const status   = videoStatus(v); // always a valid wire status

    const state = {
      status,
      ad_playing:  ad,
      video_id:    videoId,
      playlist_id: listId,
    };

    if (v) {
      state.position_seconds = round3(v.currentTime);
      state.duration_seconds = isFinite(v.duration) ? round3(v.duration) : 0;
      state.volume           = Math.round(v.volume * 100);
      state.muted            = !!v.muted;
    }

    return state;
  }

  function round3(n) {
    return Math.round((Number(n) || 0) * 1000) / 1000;
  }

  // ── State reporting ───────────────────────────────────────────────────────
  function reportState(force) {
    if (!isYouTube()) return;
    const state = buildState();
    const json  = JSON.stringify(state);
    if (!force && json === lastStateJson) return;
    lastStateJson = json;
    try {
      chrome.runtime.sendMessage({ type: MSG_CONTENT_STATE, state }, () => {
        void chrome.runtime.lastError; // swallow "no receiver" while worker sleeps
      });
    } catch (_e) {}
  }

  // ── Command execution (standard HTML5 video API only) ────────────────────
  function applyCommand(action, params) {
    // Trust boundary: if the action is not in our set, reject.
    if (!ALL_ACTIONS.has(action)) return { accepted: false, error: "action_not_allowed" };

    // FULL AD PASSIVITY: while an ad is playing EVERY action is blocked. We ack
    // busy_ad and mutate nothing — no media control, no click, no volume, and
    // crucially no touch of preDuck state (so an ad cannot lose a legitimate
    // pending duck, nor can a blocked command clear it).
    if (isAdPlaying() && AD_BLOCKED.has(action)) {
      return { accepted: false, error: "busy_ad" };
    }

    // Explicit (non-voice) command supersedes any pending voice-focus duck.
    // Drop the saved pre-duck state WITHOUT restoring, so a later "restore"
    // cannot overwrite the explicit mute/volume/stop/navigation just issued.
    // (Only reached when NOT in an ad, per the gate above.)
    if (!VOICE_FOCUS_ACTIONS.has(action)) {
      preDuck = null;
    }

    const v = getVideo();

    switch (action) {
      // Navigation actions arrive here only if background routing fails (shouldn't
      // happen in practice). Reject with a clear reason.
      case "navigate_video":
      case "navigate_playlist":
        return { accepted: false, error: "navigation_only" };

      case "play":
        if (!v) return { accepted: false, error: "no_player" };
        v.play().catch(() => {});
        return ok();

      case "pause":
        if (!v) return { accepted: false, error: "no_player" };
        v.pause();
        return ok();

      case "stop":
        if (!v) return { accepted: false, error: "no_player" };
        v.pause();
        try { v.currentTime = 0; } catch (_e) {}
        return ok();

      case "next": {
        const btn = document.querySelector(".ytp-next-button");
        if (btn && typeof btn.click === "function") { btn.click(); return ok(); }
        return { accepted: false, error: "no_next_control" };
      }

      case "previous": {
        const btn = document.querySelector(".ytp-prev-button");
        if (btn && typeof btn.click === "function") { btn.click(); return ok(); }
        return { accepted: false, error: "no_previous_control" };
      }

      case "restart":
        if (!v) return { accepted: false, error: "no_player" };
        try { v.currentTime = 0; } catch (_e) {}
        v.play().catch(() => {});
        return ok();

      case "seek": {
        if (!v) return { accepted: false, error: "no_player" };
        // Use target_seconds (absolute computed position) when present; fall
        // back to offset delta. COMPANION_PROTOCOL.md sends both.
        let target = null;
        if (typeof params.target_seconds === "number" && params.target_seconds >= 0) {
          target = params.target_seconds;
        } else if (typeof params.offset_seconds === "number") {
          target = v.currentTime + params.offset_seconds;
        }
        if (target === null) return { accepted: false, error: "no_seek_target" };
        const max = isFinite(v.duration) ? v.duration : target;
        try { v.currentTime = Math.max(0, Math.min(max, target)); } catch (_e) {}
        return ok();
      }

      case "set_volume": {
        if (!v) return { accepted: false, error: "no_player" };
        if (typeof params.volume !== "number") return { accepted: false, error: "no_volume" };
        v.volume = clamp01(params.volume / 100);
        if (v.volume > 0) v.muted = false;
        // preDuck already cleared centrally (explicit command supersedes duck).
        return ok();
      }

      case "adjust_volume": {
        if (!v) return { accepted: false, error: "no_player" };
        if (typeof params.delta !== "number") return { accepted: false, error: "no_delta" };
        v.volume = clamp01(v.volume + params.delta / 100);
        if (v.volume > 0) v.muted = false;
        // preDuck already cleared centrally (explicit command supersedes duck).
        return ok();
      }

      case "mute":
        if (!v) return { accepted: false, error: "no_player" };
        v.muted = true;
        return ok();

      case "unmute":
        if (!v) return { accepted: false, error: "no_player" };
        v.muted = false;
        return ok();

      case "duck": {
        if (!v) return { accepted: false, error: "no_player" };
        // Save pre-duck state only on first duck (not repeated duck calls).
        if (preDuck === null) preDuck = { volume: v.volume, muted: v.muted };
        // COMPANION_PROTOCOL.md: duck payload field is "volume" (default 20).
        const level = typeof params.volume === "number" ? params.volume : 20;
        v.volume = clamp01(level / 100);
        return ok();
      }

      case "restore": {
        if (!v) return { accepted: false, error: "no_player" };
        // Only restore for a matching voice-focus lifecycle: a duck must be
        // pending. If an explicit non-voice command cleared preDuck (or no duck
        // ever happened), restore mutates NOTHING — it must not overwrite the
        // user's explicit mute/volume/stop/navigation.
        if (preDuck !== null) {
          v.volume = clamp01(preDuck.volume);
          v.muted  = preDuck.muted;
          preDuck  = null;
          return ok();
        }
        // Nothing to restore — acknowledge as a no-op without mutation.
        return { accepted: true };
      }

      default:
        return { accepted: false, error: "action_not_allowed" };
    }
  }

  function ok() {
    setTimeout(() => reportState(true), 60); // prompt a state update
    return { accepted: true };
  }

  function clamp01(n) {
    return Math.max(0, Math.min(1, Number(n) || 0));
  }

  // ── Message handler: background → content ────────────────────────────────
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message) return false;
    const kind = message.type;
    if (kind !== MSG_COMMAND && kind !== MSG_AD_CHECK) return false;

    // Verify this came from our own background worker.
    if (
      sender.id &&
      typeof chrome.runtime.id === "string" &&
      sender.id !== chrome.runtime.id
    ) {
      // Ad-check from an untrusted sender must be treated as "cannot confirm".
      sendResponse(kind === MSG_AD_CHECK
        ? { error: "untrusted_sender" }
        : { accepted: false, error: "untrusted_sender" });
      return true;
    }

    // Re-validate origin at execution time.
    if (!isYouTube()) {
      // Off-origin: for an ad-check, do NOT return a boolean — the background
      // treats a missing boolean as "cannot confirm → refuse navigation".
      sendResponse(kind === MSG_AD_CHECK
        ? { error: "wrong_origin" }
        : { accepted: false, error: "wrong_origin" });
      return true;
    }

    // Synchronous fresh ad-state probe (used by background immediately before
    // navigating an existing target tab). Always answers with a boolean when it
    // can read the player; the reading is taken live at call time.
    if (kind === MSG_AD_CHECK) {
      let ad;
      try   { ad = isAdPlaying(); }
      catch (_e) { sendResponse({ error: "ad_check_failed" }); return true; }
      sendResponse({ ad_playing: !!ad });
      return true;
    }

    const action = String(message.action || "");
    const params = message.params && typeof message.params === "object" ? message.params : {};
    let result;
    try   { result = applyCommand(action, params); }
    catch (_e) { result = { accepted: false, error: "execution_error" }; }
    sendResponse(result);
    return true;
  });

  // ── Observers ─────────────────────────────────────────────────────────────
  function attachVideoListeners(v) {
    if (v.__chatCompanionBound) return;
    v.__chatCompanionBound = true;
    const events = [
      "play", "pause", "ended", "seeked", "volumechange",
      "waiting", "canplay", "playing",
    ];
    events.forEach((evt) => v.addEventListener(evt, () => reportState(true)));
  }

  function startObserving() {
    if (reportTimer) clearInterval(reportTimer);
    reportTimer = setInterval(() => reportState(false), 1000);

    const attach = () => { const v = getVideo(); if (v) attachVideoListeners(v); };
    attach();

    // Watch for player/ad DOM mutations (YouTube SPA + ad start/end/skip).
    const mo = new MutationObserver(() => { attach(); reportState(false); });
    const root = document.querySelector("#movie_player") || document.body;
    if (root) {
      mo.observe(root, { attributes: true, attributeFilter: ["class"], subtree: true });
    }

    // YouTube SPA navigation events.
    window.addEventListener("yt-navigate-finish", () => reportState(true));
    window.addEventListener("yt-navigate-start",  () => reportState(true));

    // Announce to background.
    try {
      chrome.runtime.sendMessage({ type: MSG_CONTENT_HELLO }, () => {
        void chrome.runtime.lastError;
      });
    } catch (_e) {}

    reportState(true);
  }

  if (document.readyState === "complete" || document.readyState === "interactive") {
    startObserving();
  } else {
    window.addEventListener("DOMContentLoaded", startObserving);
  }
})();
