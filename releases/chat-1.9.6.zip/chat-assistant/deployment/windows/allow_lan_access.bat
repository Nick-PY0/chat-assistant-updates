@echo off
title Chat - Allow LAN Access

:: Elevate to Administrator if not already running as one.
:: This script must be run by the user deliberately -- it is never
:: invoked automatically by Chat.
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting Administrator privileges...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b 0
)

:: Move to the chat-assistant folder (two levels up from deployment\windows)
cd /d "%~dp0..\.."

echo.
echo Creating Windows Defender firewall rule for Chat dashboard LAN access.
echo Rule scope: TCP, Private profile, same subnet only (LocalSubnet).
echo.

.venv\Scripts\python.exe deployment\windows\firewall_helper.py allow
if errorlevel 1 (
    echo.
    echo Firewall rule could not be created. See error above.
    pause
    exit /b 1
)

echo.
echo Done. Phones on the same Wi-Fi network can now reach the dashboard.
echo Use the address printed in the Chat console window when it starts.
echo.
pause
exit /b 0
