' Starts Chat with NO window at all (fully invisible).
' Prefer run_chat.bat if you want the small black console window.
Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(CreateObject("Scripting.FileSystemObject").GetParentFolderName(CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)))
shell.Run """" & shell.CurrentDirectory & "\run_chat.bat""", 0, False
