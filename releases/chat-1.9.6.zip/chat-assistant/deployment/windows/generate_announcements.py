"""Generate the local announcement WAV files once, offline, using the
operating system's built-in text-to-speech (SAPI5 on Windows).

Run from the chat-assistant folder:
    python deployment/windows/generate_announcements.py

Requires:  pip install pyttsx3   (included in requirements-voice.txt)

These files make quota/outage announcements spoken instead of console-only,
and they never depend on Gemini.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from apps.audio.announcements import ASSETS, MESSAGES  # noqa: E402


def main() -> int:
    try:
        import pyttsx3
    except ImportError:
        print("pyttsx3 is not installed. Run: pip install pyttsx3")
        return 1

    ASSETS.mkdir(parents=True, exist_ok=True)
    engine = pyttsx3.init()
    engine.setProperty("rate", 175)
    for key, text in MESSAGES.items():
        out = ASSETS / f"{key}.wav"
        print(f"  -> {out.name}: {text[:60]}...")
        engine.save_to_file(text, str(out))
    engine.runAndWait()
    print(f"Done. {len(MESSAGES)} announcements saved to {ASSETS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
