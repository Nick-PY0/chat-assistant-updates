@echo off
title Chat - build Chat.exe
cd /d "%~dp0..\.."

if exist .venv\Scripts\python.exe (
    set PY=.venv\Scripts\python.exe
) else (
    set PY=python
)

echo Installing the build tool (PyInstaller)...
%PY% -m pip install --upgrade pyinstaller || goto :err

echo.
echo Building Chat.exe - this takes a few minutes...
%PY% -m PyInstaller deployment\windows\chat.spec --noconfirm --distpath dist --workpath build\pyinstaller || goto :err

echo.
echo Done! Your app folder is:   dist\Chat\
echo Start it with Chat.exe inside that folder. The whole folder can be
echo copied to any Windows computer - Python does not need to be installed.
echo.
echo NOTE: whatever is installed in .venv right now gets baked in. Install
echo the voice packages first (install.bat) if you want voice in the exe.
pause
exit /b 0

:err
echo.
echo Build failed. See the messages above.
pause
exit /b 1
