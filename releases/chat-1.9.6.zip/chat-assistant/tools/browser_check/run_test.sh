#!/bin/bash
# Boots Chat on a throwaway data dir and runs harness.mjs (jsdom) against it:
# every dashboard page's JavaScript executes in browser-like document order,
# so script-ordering bugs ("api is not defined") are caught here -- pytest and
# curl execute zero JS and cannot see them.
#
# One-time setup in this directory:  npm init -y && npm i jsdom
#
# Self-safe pkill: this script's own cmdline never contains the server
# filename, so the pattern below cannot match and kill the runner itself.
HERE="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$HERE/../.." && pwd)"
pkill -f "run_chat[.]py" 2>/dev/null
sleep 1
rm -rf /tmp/uitest_data
cd "$APP_DIR" || exit 3
CHAT_DATA_DIR=/tmp/uitest_data timeout 130 python run_chat.py > /tmp/uitest_server.log 2>&1 &
SERVER_PID=$!
sleep 5
cd "$HERE" || exit 3
node harness.mjs
EC=$?
kill "$SERVER_PID" 2>/dev/null
wait "$SERVER_PID" 2>/dev/null
exit "$EC"
