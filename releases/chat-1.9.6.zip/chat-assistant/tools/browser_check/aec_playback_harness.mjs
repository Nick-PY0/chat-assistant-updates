/**
 * aec_playback_harness.mjs — deterministic tests for acoustic-feedback safeguard
 * changes in voice_controller.js.
 *
 * Tests:
 *   1. Zero-gain graph: micProcessor connects to a GainNode (not direct to
 *      destination), and that GainNode has gain.value === 0.
 *   2. AEC constraints: getUserMedia is called with echoCancellation,
 *      noiseSuppression, and autoGainControl.
 *   3. Single AudioContext: handleBinaryAudio uses the same context as startMic
 *      (audioCtx is not created inside handleBinaryAudio).
 *   4. assistant_playback deduplication: reportAssistantPlayback(true) sends
 *      exactly one message; a second call with the same value sends none.
 *   5. assistant_playback false-on-flush: flushAudio() sends playing=false even
 *      if playing was already false (idempotent but also fires on flush).
 *      Specifically: true→flush must yield a false message.
 *   6. assistant_playback false-on-close: ws.onclose triggers reportAssistantPlayback(false).
 *   7. assistant_playback false-on-goodbye: goodbyeBtn click triggers reportAssistantPlayback(false).
 *   8. Resampler class is still present and functional (regression guard).
 *
 * Run: node aec_playback_harness.mjs
 * Exit 0 = all pass, 1 = failures.
 */

import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const JS_PATH   = join(__dirname, "../../apps/dashboard/static/voice_controller.js");

const src = readFileSync(JS_PATH, "utf8");

let failures = 0;
function assert(cond, msg) {
  if (cond) {
    console.log("PASS:", msg);
  } else {
    console.error("FAIL:", msg);
    failures++;
  }
}

// ---------------------------------------------------------------------------
// Static source-code structural checks (no eval needed for some tests)
// ---------------------------------------------------------------------------

// Test 1: zero-gain graph — verify zeroGainNode exists and is used as a
// keepalive rather than direct processor-to-destination routing.
{
  // Must declare a zero-gain node
  assert(
    src.includes("zeroGainNode") && src.includes("createGain"),
    "1a: zeroGainNode declared and createGain called"
  );

  // gain.value must be set to 0
  assert(
    src.includes("zeroGainNode.gain.value = 0") || src.includes(".gain.value=0"),
    "1b: zero-gain node gain.value = 0"
  );

  // micProcessor must connect to zeroGainNode, NOT directly to destination
  // Check that the connection chain is processor → zeroGain → destination
  assert(
    src.includes("micProcessor.connect(zeroGainNode)"),
    "1c: micProcessor.connect(zeroGainNode) (not direct to destination)"
  );

  assert(
    src.includes("zeroGainNode.connect(audioCtx.destination)"),
    "1d: zeroGainNode.connect(audioCtx.destination)"
  );

  // The OLD direct connection must NOT be present
  assert(
    !src.includes("micProcessor.connect(micCtx.destination)"),
    "1e: old micCtx.destination direct routing is gone"
  );
}

// Test 2: AEC constraints — getUserMedia called with the three constraints
{
  assert(
    src.includes("echoCancellation"),
    "2a: echoCancellation constraint present"
  );
  assert(
    src.includes("noiseSuppression"),
    "2b: noiseSuppression constraint present"
  );
  assert(
    src.includes("autoGainControl"),
    "2c: autoGainControl constraint present"
  );
  // Constraints should use ideal: true form (not just plain true) for
  // best compatibility per spec.
  assert(
    src.includes("echoCancellation: { ideal: true }") || src.includes("echoCancellation:true") || src.includes("echoCancellation: true"),
    "2d: echoCancellation requests true (ideal or direct)"
  );
}

// Test 3: single AudioContext — startMic must NOT create its own context;
// it must use the outer audioCtx created in the startBtn handler.
{
  // Count how many times 'new AudioContext' / 'new webkitAudioContext' appears
  // inside startMic. Strategy: check that startMic does NOT contain 'new (...AudioContext'
  const startMicMatch = src.match(/async function startMic\(\)([\s\S]*?)^  \}/m);
  // Fallback: look for the pattern more broadly
  const startMicIdx = src.indexOf("async function startMic()");
  const startMicEnd = src.indexOf("\n  function stopMic()", startMicIdx);
  const startMicBody = startMicIdx !== -1 ? src.slice(startMicIdx, startMicEnd) : "";

  assert(
    !startMicBody.includes("new (window.AudioContext") &&
    !startMicBody.includes("new AudioContext") &&
    !startMicBody.includes("new webkitAudioContext"),
    "3a: startMic does NOT create its own AudioContext (uses shared outer audioCtx)"
  );

  // The shared audioCtx must be created exactly once in the startBtn handler
  const btnHandlerIdx = src.indexOf("startBtn.addEventListener");
  const btnHandlerEnd = src.indexOf("startBtn.disabled = false;\n    connectWs()", btnHandlerIdx);
  const btnBody = btnHandlerIdx !== -1 ? src.slice(btnHandlerIdx, btnHandlerEnd + 80) : "";

  assert(
    btnBody.includes("new (window.AudioContext || window.webkitAudioContext)()"),
    "3b: single AudioContext created in startBtn user-gesture handler"
  );

  // handleBinaryAudio must NOT create a new context
  const handleBinaryIdx = src.indexOf("function handleBinaryAudio(");
  const handleBinaryEnd = src.indexOf("\n  // ---- AEC", handleBinaryIdx);
  const handleBinaryBody = handleBinaryIdx !== -1 ? src.slice(handleBinaryIdx, handleBinaryEnd) : "";

  assert(
    !handleBinaryBody.includes("new (window.AudioContext") &&
    !handleBinaryBody.includes("new AudioContext"),
    "3c: handleBinaryAudio does NOT create a new AudioContext"
  );

  // handleBinaryAudio must connect to audioCtx.destination (shared context)
  assert(
    handleBinaryBody.includes("audioCtx.destination"),
    "3d: handleBinaryAudio connects to shared audioCtx.destination"
  );
}

// Test 4 & 5: assistant_playback deduplication and false-on-flush
// These require a lightweight runtime simulation.
{
  // Extract the IIFE body and re-evaluate with stubbed DOM and WebSocket.
  // We need to exercise the playback state machine logic.

  // Build a minimal simulation environment.
  const sentMessages = [];
  let currentState = null;

  // Simulate the JS module's internal reportAssistantPlayback behavior
  // by re-implementing the exact logic from voice_controller.js
  // (extracted and tested in isolation).

  // Extract the relevant functions by parsing the source.
  // We look for reportAssistantPlayback and schedulePlaybackFalseWhenDone.

  // Simpler approach: re-implement the logic and test it mirrors the source.
  // Verify the source contains the deduplication guard.
  assert(
    src.includes("if (playing === assistantPlaying) return"),
    "4a: deduplication guard 'if (playing === assistantPlaying) return' present"
  );

  // Verify the source sends the control message.
  assert(
    src.includes('type: "assistant_playback"'),
    "4b: sends assistant_playback type in control message"
  );

  // Verify flushAudio calls reportAssistantPlayback(false).
  const flushIdx = src.indexOf("function flushAudio()");
  const flushEnd = src.indexOf("\n  // ---- Assistant", flushIdx);
  const flushBody = src.slice(flushIdx, flushEnd);
  assert(
    flushBody.includes("reportAssistantPlayback(false)"),
    "5a: flushAudio calls reportAssistantPlayback(false)"
  );
}

// Test 5b: false-on-stop (Stop button)
{
  const stopIdx = src.indexOf('stopBtn.addEventListener("click"');
  const stopEnd = src.indexOf('\n  // Goodbye', stopIdx);
  const stopBody = src.slice(stopIdx, stopEnd);
  assert(
    stopBody.includes("flushAudio()"),
    "5b: Stop button calls flushAudio() (which reports playback=false)"
  );
}

// Test 6: false-on-close (ws.onclose)
{
  const oncloseIdx = src.indexOf("ws.onclose = (e) => {");
  const oncloseEnd = src.indexOf("\n    ws.onerror", oncloseIdx);
  const oncloseBody = src.slice(oncloseIdx, oncloseEnd);
  assert(
    oncloseBody.includes("reportAssistantPlayback(false)"),
    "6a: ws.onclose calls reportAssistantPlayback(false)"
  );
}

// Test 7: false-on-goodbye (goodbyeBtn click) — must call flushAudio() which
// stops queued sources AND sends assistant_playback=false, matching Stop's
// contract.  A bare reportAssistantPlayback(false) without flushAudio() is
// insufficient because it leaves audio sources playing.
{
  const goodbyeIdx = src.indexOf('goodbyeBtn.addEventListener("click"');
  const goodbyeEnd = src.indexOf('\n  muteBtn.addEventListener', goodbyeIdx);
  const goodbyeBody = src.slice(goodbyeIdx, goodbyeEnd);

  // 7a: flushAudio() must be called (stops sources + sends false)
  assert(
    goodbyeBody.includes("flushAudio()"),
    "7a: goodbyeBtn click calls flushAudio() before session end"
  );

  // 7b: flushAudio must appear before the session-end fetch
  const flushPos   = goodbyeBody.indexOf("flushAudio()");
  const fetchPos   = goodbyeBody.indexOf('fetch("/api/session/end"');
  assert(
    flushPos !== -1 && fetchPos !== -1 && flushPos < fetchPos,
    "7b: flushAudio() is called BEFORE fetch('/api/session/end')"
  );

  // 7c: flushAudio itself must call reportAssistantPlayback(false) (regression guard)
  const flushFnIdx = src.indexOf("function flushAudio()");
  const flushFnEnd = src.indexOf("\n  // ---- Assistant", flushFnIdx);
  const flushFnBody = src.slice(flushFnIdx, flushFnEnd);
  assert(
    flushFnBody.includes("reportAssistantPlayback(false)"),
    "7c: flushAudio() body calls reportAssistantPlayback(false)"
  );
}

// Test 8: Resampler still present (regression guard)
{
  assert(
    src.includes("class Resampler {"),
    "8a: Resampler class still present"
  );
  assert(
    src.includes("this.chunkSamples"),
    "8b: Resampler still has chunkSamples"
  );
}

// Test 9: AEC warning — inspectAEC function present and warns on disabled AEC
{
  assert(
    src.includes("function inspectAEC("),
    "9a: inspectAEC function present"
  );
  assert(
    src.includes("echoCancellation is not available") ||
    src.includes("Echo cancellation is not available"),
    "9b: inspectAEC warns about AEC unavailable"
  );
  assert(
    src.includes("headphones") || src.includes("Headphones"),
    "9c: inspectAEC recommends headphones"
  );
  assert(
    src.includes("getSettings") && src.includes("getCapabilities"),
    "9d: inspectAEC checks track settings and capabilities"
  );
}

// Test 10: assistant_playback false after source ends (schedulePlaybackFalseWhenDone)
{
  assert(
    src.includes("schedulePlaybackFalseWhenDone"),
    "10a: schedulePlaybackFalseWhenDone function present"
  );
  // It must be called in src.onended
  const onendedIdx = src.indexOf("src.onended = () => {");
  const onendedEnd = src.indexOf("};", onendedIdx);
  const onendedBody = src.slice(onendedIdx, onendedEnd);
  assert(
    onendedBody.includes("schedulePlaybackFalseWhenDone()"),
    "10b: src.onended calls schedulePlaybackFalseWhenDone()"
  );
}

// ---------------------------------------------------------------------------
// Runtime simulation: test deduplication + false-on-flush behavior
// ---------------------------------------------------------------------------
{
  // Simulate the internal state machine with a minimal JS evaluation.
  // We extract just the playback tracking variables and functions.

  // Build a fresh simulation matching the voice_controller.js logic.
  let simAssistantPlaying = false;
  let simTimer = null;
  const simSent = [];
  const simLiveSources = [];

  function simSendPlaybackMsg(playing) {
    simSent.push(playing);
  }

  function simReportAssistantPlayback(playing) {
    if (simTimer !== null) { clearTimeout(simTimer); simTimer = null; }
    if (playing === simAssistantPlaying) return;
    simAssistantPlaying = playing;
    simSendPlaybackMsg(playing);
  }

  // Test: true sends once
  simReportAssistantPlayback(true);
  assert(simSent.length === 1 && simSent[0] === true, "sim-4a: first true sends exactly one message");

  // Test: second true sends nothing (dedup)
  simReportAssistantPlayback(true);
  assert(simSent.length === 1, "sim-4b: second true is deduplicated (no extra send)");

  // Test: false sends once
  simReportAssistantPlayback(false);
  assert(simSent.length === 2 && simSent[1] === false, "sim-4c: first false sends exactly one message");

  // Test: second false sends nothing (dedup)
  simReportAssistantPlayback(false);
  assert(simSent.length === 2, "sim-4d: second false is deduplicated");

  // Test: true→flush path sends false
  simSent.length = 0;
  simAssistantPlaying = false;
  simReportAssistantPlayback(true);  // sends true
  // Simulate flushAudio calling reportAssistantPlayback(false)
  simReportAssistantPlayback(false); // sends false
  assert(simSent.length === 2 && simSent[0] === true && simSent[1] === false,
    "sim-5: true → flush (false) sends both messages in order");
}

// ---------------------------------------------------------------------------
// Result
// ---------------------------------------------------------------------------
console.log("");
if (failures === 0) {
  console.log("ALL AEC/PLAYBACK HARNESS CHECKS PASSED");
  process.exit(0);
} else {
  console.log(`${failures} AEC/PLAYBACK FAILURE(S)`);
  process.exit(1);
}
