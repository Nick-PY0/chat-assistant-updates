/**
 * resampler_harness.mjs — browser/jsdom harness for voice_controller.js Resampler.
 *
 * Proves that:
 *   1. 48 kHz input produces exactly-sized 16 kHz PCM frames (CHUNK = 1280 samples).
 *   2. Duration is preserved: same number of output samples as expected from ratio.
 *   3. A 1 kHz sine at 48 kHz resampled to 16 kHz retains the correct frequency.
 *   4. Partial (wrong-sized) frames are never sent.
 *   5. 44.1 kHz input also produces exact 1280-sample frames.
 *   6. Identity pass-through (16 kHz → 16 kHz) works without distortion.
 *   7. State survives across many small push() calls (no cross-boundary glitches).
 *
 * Run: node resampler_harness.mjs
 * Exit 0 = all pass, 1 = failures.
 *
 * The Resampler class is extracted verbatim from voice_controller.js and
 * evaluated in a fresh Function scope — same semantics as a browser executing
 * the script.  jsdom is used only for script validation; the math runs in Node.
 */

import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const JS_PATH   = join(__dirname, "../../apps/dashboard/static/voice_controller.js");

// ---------------------------------------------------------------------------
// Extract and instantiate the Resampler class from voice_controller.js
// ---------------------------------------------------------------------------
const src = readFileSync(JS_PATH, "utf8");

const classStart = src.indexOf("class Resampler {");
if (classStart === -1) {
  console.error("FATAL: Resampler class not found in voice_controller.js");
  process.exit(1);
}

// Find the matching closing brace (class level, depth 0).
let depth = 0, classEnd = classStart;
for (let i = classStart; i < src.length; i++) {
  if (src[i] === "{") depth++;
  else if (src[i] === "}") {
    depth--;
    if (depth === 0) { classEnd = i + 1; break; }
  }
}
const classCode = src.slice(classStart, classEnd);

// Evaluate in an isolated Function scope so it does not pollute globals.
// This is equivalent to how a browser evaluates a script tag.
let Resampler;
try {
  Resampler = new Function(`"use strict"; return (${classCode});`)();
} catch (e) {
  console.error("FATAL: Resampler class failed to evaluate:", e.message);
  process.exit(1);
}
if (typeof Resampler !== "function") {
  console.error("FATAL: Resampler is not a constructor after eval");
  process.exit(1);
}
console.log("Resampler class loaded from voice_controller.js");

// ---------------------------------------------------------------------------
// Test helpers
// ---------------------------------------------------------------------------
const IN_RATE = 16000;
const CHUNK   = 1280;   // must match engine.py CHUNK

let failures = 0;

function assert(cond, msg) {
  if (!cond) {
    console.error("FAIL:", msg);
    failures++;
  } else {
    console.log("PASS:", msg);
  }
}

/** Generate a mono sine wave as Float32Array at the given sampleRate. */
function sine(freq, durationSec, sampleRate) {
  const n = Math.round(durationSec * sampleRate);
  const f = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    f[i] = Math.sin(2 * Math.PI * freq * i / sampleRate) * 0.8;
  }
  return f;
}

/**
 * Feed a signal through a Resampler in ScriptProcessor-sized chunks (4096
 * samples), matching how voice_controller.js calls push() in onaudioprocess.
 * Returns all complete PCM ArrayBuffer frames.
 */
function resampleAll(signal, srcRate, cbSize = 4096) {
  const r      = new Resampler(srcRate, IN_RATE, CHUNK);
  const frames = [];
  for (let off = 0; off < signal.length; off += cbSize) {
    const slice = signal.subarray(off, off + cbSize);
    for (const buf of r.push(slice)) {
      frames.push(buf);
    }
  }
  return frames;
}

/** Decode an ArrayBuffer to Int16Array. */
function decode(buf) {
  return new Int16Array(buf);
}

/**
 * Measure the dominant frequency of a PCM16 Int16Array via a simple DFT.
 * Only checks the first maxN samples for speed.
 */
function dominantFreq(samples, rate, maxN = 8192) {
  const N      = Math.min(samples.length, maxN);
  let bestBin  = 0, bestPow = -Infinity;
  const maxBin = Math.floor(N / 2);
  for (let k = 1; k < maxBin; k++) {
    let re = 0, im = 0;
    for (let n = 0; n < N; n++) {
      const angle = (2 * Math.PI * k * n) / N;
      re += samples[n] * Math.cos(angle);
      im -= samples[n] * Math.sin(angle);
    }
    const pow = re * re + im * im;
    if (pow > bestPow) { bestPow = pow; bestBin = k; }
  }
  return bestBin * rate / N;
}

// ---------------------------------------------------------------------------
// Test 1: 48 kHz → 16 kHz — every frame is exactly CHUNK samples
// ---------------------------------------------------------------------------
{
  const SRC_RATE = 48000;
  const DUR      = 2.0;
  const signal   = sine(440, DUR, SRC_RATE);
  const frames   = resampleAll(signal, SRC_RATE);

  assert(frames.length > 0, "48k→16k: at least one frame produced");

  const allCorrectSize = frames.every(f => decode(f).length === CHUNK);
  assert(allCorrectSize, `48k→16k: all ${frames.length} frames are exactly ${CHUNK} samples`);

  const anyWrongSize = frames.some(f => decode(f).length !== CHUNK);
  assert(!anyWrongSize, "48k→16k: no wrong-size (partial) frames sent");
}

// ---------------------------------------------------------------------------
// Test 2: Duration is preserved — total output samples ≈ DUR * IN_RATE
// ---------------------------------------------------------------------------
{
  const SRC_RATE    = 48000;
  const DUR         = 3.0;
  const signal      = sine(880, DUR, SRC_RATE);
  const frames      = resampleAll(signal, SRC_RATE);
  const totalOut    = frames.reduce((s, f) => s + decode(f).length, 0);
  const expectedOut = Math.round(DUR * IN_RATE);
  // Allow up to one chunk of rounding (partial trailing chunk is not emitted).
  const diff = Math.abs(totalOut - expectedOut);
  assert(
    diff <= CHUNK,
    `48k→16k: output duration within ±${CHUNK} samples (got ${totalOut}, expected ~${expectedOut})`
  );
}

// ---------------------------------------------------------------------------
// Test 3: Frequency is preserved — 1 kHz sine at 48 kHz resampled to 16 kHz
// ---------------------------------------------------------------------------
{
  const SRC_RATE = 48000;
  const FREQ     = 1000;
  const DUR      = 2.5;
  const signal   = sine(FREQ, DUR, SRC_RATE);
  const frames   = resampleAll(signal, SRC_RATE);

  // Flatten all frames.
  const totalLen  = frames.reduce((s, f) => s + decode(f).length, 0);
  const allSamples = new Int16Array(totalLen);
  let offset = 0;
  for (const f of frames) {
    const s = decode(f);
    allSamples.set(s, offset);
    offset += s.length;
  }

  const measured  = dominantFreq(allSamples, IN_RATE);
  // Tolerance: ±5% or one DFT bin, whichever is larger.
  const binWidth  = IN_RATE / Math.min(allSamples.length, 8192);
  const tolerance = Math.max(FREQ * 0.05, binWidth);
  assert(
    Math.abs(measured - FREQ) <= tolerance,
    `48k→16k: 1 kHz sine preserved (measured ${measured.toFixed(1)} Hz, expected ${FREQ} Hz)`
  );
}

// ---------------------------------------------------------------------------
// Test 4: 44.1 kHz → 16 kHz — exact frame sizes
// ---------------------------------------------------------------------------
{
  const SRC_RATE = 44100;
  const DUR      = 2.0;
  const signal   = sine(440, DUR, SRC_RATE);
  const frames   = resampleAll(signal, SRC_RATE);

  assert(frames.length > 0, "44.1k→16k: at least one frame produced");
  const allCorrectSize = frames.every(f => decode(f).length === CHUNK);
  assert(allCorrectSize, `44.1k→16k: all ${frames.length} frames are exactly ${CHUNK} samples`);
}

// ---------------------------------------------------------------------------
// Test 5: Identity — 16 kHz → 16 kHz preserves samples exactly
// ---------------------------------------------------------------------------
{
  const DUR    = 1.0;
  const signal = sine(440, DUR, IN_RATE);
  const frames = resampleAll(signal, IN_RATE);

  assert(frames.length > 0, "16k→16k identity: frames produced");
  const allCorrectSize = frames.every(f => decode(f).length === CHUNK);
  assert(allCorrectSize, `16k→16k identity: all frames are exactly ${CHUNK} samples`);

  // First sample should be identical to the input (within ±1 LSB rounding).
  const first    = decode(frames[0]);
  const expected = Math.round(signal[0] * 0x7fff);
  assert(
    Math.abs(first[0] - expected) <= 1,
    `16k→16k identity: first sample matches (got ${first[0]}, expected ${expected})`
  );
}

// ---------------------------------------------------------------------------
// Test 6: State survives across many tiny push() calls
// ---------------------------------------------------------------------------
{
  const SRC_RATE = 48000;
  const DUR      = 1.0;
  const signal   = sine(330, DUR, SRC_RATE);
  const frames   = resampleAll(signal, SRC_RATE, 128); // 128-sample chunks

  const allCorrectSize = frames.every(f => decode(f).length === CHUNK);
  assert(allCorrectSize, "small-chunk feeding: all frames are exactly CHUNK samples");
  assert(frames.length > 0, "small-chunk feeding: at least one frame produced");
}

// ---------------------------------------------------------------------------
// Test 7: reset() clears internal state without crashing
// ---------------------------------------------------------------------------
{
  const r      = new Resampler(48000, IN_RATE, CHUNK);
  const signal = sine(440, 0.5, 48000);
  // Feed some data, then reset and feed again.
  r.push(signal.subarray(0, 4096));
  r.reset();
  const frames = [];
  for (const buf of r.push(signal.subarray(0, 4096))) {
    frames.push(buf);
  }
  assert(true, "reset(): completes without error");
  const allCorrectSize = frames.every(f => decode(f).length === CHUNK);
  assert(
    frames.length === 0 || allCorrectSize,
    "reset(): frames after reset are correct size"
  );
}

// ---------------------------------------------------------------------------
// Result
// ---------------------------------------------------------------------------
console.log("");
if (failures === 0) {
  console.log("ALL RESAMPLER CHECKS PASSED");
  process.exit(0);
} else {
  console.log(`${failures} RESAMPLER FAILURE(S)`);
  process.exit(1);
}
