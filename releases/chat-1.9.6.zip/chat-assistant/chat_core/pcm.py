"""Tiny pure-stdlib PCM16 helpers.

These live in chat_core (not apps.audio) because brains and tests need them
on machines that have no audio stack installed at all -- no numpy, no
sounddevice. 80 ms chunks are small enough that plain Python keeps up.
"""

from __future__ import annotations

import array
import math


def resample_linear(pcm: bytes, src_rate: int, dst_rate: int) -> bytes:
    """Linear-interpolation resample of PCM16 mono bytes."""
    if not pcm or src_rate <= 0 or dst_rate <= 0 or src_rate == dst_rate:
        return pcm
    src = array.array("h")
    src.frombytes(pcm[: len(pcm) - (len(pcm) % 2)])
    n = len(src)
    if n == 0:
        return b""
    out_n = max(1, int(n * dst_rate / src_rate))
    out = array.array("h", bytes(out_n * 2))
    step = src_rate / dst_rate
    for i in range(out_n):
        pos = i * step
        j = int(pos)
        frac = pos - j
        a = src[j] if j < n else src[n - 1]
        b = src[j + 1] if j + 1 < n else a
        out[i] = int(a + (b - a) * frac)
    return out.tobytes()


def rms16(chunk: bytes) -> float:
    """Root-mean-square level of a PCM16 chunk; 0.0 for silence/empty."""
    if len(chunk) < 2:
        return 0.0
    samples = array.array("h")
    samples.frombytes(chunk[: len(chunk) - (len(chunk) % 2)])
    if not samples:
        return 0.0
    total = 0
    for value in samples:
        total += value * value
    return math.sqrt(total / len(samples))
