"""Path resolution that works both when running from source and when
frozen into an .exe by PyInstaller (see deployment/windows/build_exe.bat).

  resource_root(): read-only bundled files (templates, migrations, assets)
  install_dir():   the folder an auto-update should replace
"""

from __future__ import annotations

import sys
from pathlib import Path


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def resource_root() -> Path:
    if is_frozen():
        # onedir build: bundled data lives in _internal (sys._MEIPASS)
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    return Path(__file__).resolve().parents[1]


def install_dir() -> Path:
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]
