"""Credential vault: AES-256-GCM with per-item nonces and context separation.

Each secret is encrypted with a key derived from the master secret and a
context string (provider:purpose), so Gemini and Govee material live in
separate encryption contexts as required by the security baseline.
Plaintext secrets exist only transiently in memory and are never logged
or returned by any API.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_NONCE_LEN = 12


def _derive_key(master: bytes, context: str) -> bytes:
    return hmac.new(master, b"chat-vault:" + context.encode(), hashlib.sha256).digest()


class Vault:
    def __init__(self, master_secret: bytes) -> None:
        if len(master_secret) < 16:
            raise ValueError("master secret too short")
        self._master = master_secret

    def encrypt(self, plaintext: str, context: str) -> bytes:
        key = _derive_key(self._master, context)
        nonce = secrets.token_bytes(_NONCE_LEN)
        ct = AESGCM(key).encrypt(nonce, plaintext.encode(), context.encode())
        return nonce + ct

    def decrypt(self, blob: bytes, context: str) -> str:
        key = _derive_key(self._master, context)
        nonce, ct = blob[:_NONCE_LEN], blob[_NONCE_LEN:]
        return AESGCM(key).decrypt(nonce, ct, context.encode()).decode()

    @staticmethod
    def mask(secret: str) -> str:
        tail = secret[-4:] if len(secret) >= 4 else secret
        return "\u2022\u2022\u2022\u2022" + tail

    @staticmethod
    def fingerprint(value: str) -> str:
        return hashlib.sha256(value.encode()).hexdigest()[:16]
