"""Dashboard authentication: Argon2id password, signed cookies, CSRF,
and login rate limiting."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

_hasher = PasswordHasher()  # argon2id by default


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


class SessionManager:
    def __init__(self, secret: str, max_age_seconds: int) -> None:
        self._serializer = URLSafeTimedSerializer(secret, salt="chat-session")
        self._csrf_key = hashlib.sha256(("csrf:" + secret).encode()).digest()
        self.max_age = max_age_seconds

    def issue(self) -> str:
        return self._serializer.dumps({"sid": secrets.token_hex(16)})

    def validate(self, token: str | None) -> dict | None:
        if not token:
            return None
        try:
            return self._serializer.loads(token, max_age=self.max_age)
        except (BadSignature, SignatureExpired):
            return None

    def csrf_for(self, token: str) -> str:
        return hmac.new(self._csrf_key, token.encode(), hashlib.sha256).hexdigest()

    def csrf_ok(self, token: str | None, csrf: str | None) -> bool:
        if not token or not csrf:
            return False
        return hmac.compare_digest(self.csrf_for(token), csrf)


class LoginRateLimiter:
    def __init__(self, max_attempts: int, window_seconds: int) -> None:
        self.max_attempts = max_attempts
        self.window = window_seconds
        self._attempts: dict[str, list[float]] = {}

    def check(self, ip: str) -> bool:
        """True if this IP may attempt a login."""
        now = time.monotonic()
        attempts = [t for t in self._attempts.get(ip, []) if now - t < self.window]
        self._attempts[ip] = attempts
        return len(attempts) < self.max_attempts

    def record_failure(self, ip: str) -> None:
        self._attempts.setdefault(ip, []).append(time.monotonic())

    def reset(self, ip: str) -> None:
        self._attempts.pop(ip, None)

    def retry_in(self, ip: str) -> int:
        attempts = self._attempts.get(ip, [])
        if not attempts:
            return 0
        return max(0, int(self.window - (time.monotonic() - min(attempts))))
