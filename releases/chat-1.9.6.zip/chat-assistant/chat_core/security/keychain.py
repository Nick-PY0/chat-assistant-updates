"""Master secret storage.

Preferred: the operating system keychain (Windows Credential Locker,
macOS Keychain, or Secret Service on Linux) via the optional `keyring`
package. Fallback: a file inside the data directory with restrictive
permissions, plus a clear warning surfaced in the dashboard.

The master secret encrypts every stored credential. A database copied to
another machine without this secret is unreadable.
"""

from __future__ import annotations

import os
import secrets
from pathlib import Path

SERVICE = "chat-assistant"
ENTRY = "master-secret"

try:  # optional
    import keyring  # type: ignore
    from keyring.errors import KeyringError  # type: ignore

    _KEYRING = True
except Exception:  # pragma: no cover - import guard
    _KEYRING = False


class MasterSecret:
    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir
        self.source = "unset"
        self._secret: bytes | None = None

    def load_or_create(self) -> bytes:
        if self._secret is not None:
            return self._secret
        if _KEYRING:
            try:
                stored = keyring.get_password(SERVICE, ENTRY)
                if stored is None:
                    stored = secrets.token_hex(32)
                    keyring.set_password(SERVICE, ENTRY, stored)
                self._secret = bytes.fromhex(stored)
                self.source = "os-keychain"
                return self._secret
            except (KeyringError, ValueError):
                pass  # fall through to file
        path = self.data_dir / "master.key"
        if path.exists():
            self._secret = bytes.fromhex(path.read_text().strip())
        else:
            self._secret = secrets.token_bytes(32)
            path.write_text(self._secret.hex())
            try:
                os.chmod(path, 0o600)
            except OSError:  # Windows ignores POSIX modes; ACLs cover the profile dir
                pass
        self.source = "file"
        return self._secret
