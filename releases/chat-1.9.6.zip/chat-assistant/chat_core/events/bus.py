"""In-process event bus with bounded queues.

Audio buffers NEVER travel through this bus -- it is for control/health
events only. Queues are bounded; slow subscribers lose oldest events
rather than blocking publishers.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Event:
    topic: str
    data: dict[str, Any] = field(default_factory=dict)
    ts: float = field(default_factory=time.time)


class EventBus:
    def __init__(self) -> None:
        self._subs: dict[str, list[asyncio.Queue[Event]]] = {}

    def subscribe(self, *topics: str, maxsize: int = 256) -> asyncio.Queue[Event]:
        q: asyncio.Queue[Event] = asyncio.Queue(maxsize=maxsize)
        for t in topics:
            self._subs.setdefault(t, []).append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue[Event]) -> None:
        for queues in self._subs.values():
            if q in queues:
                queues.remove(q)

    def publish(self, topic: str, **data: Any) -> None:
        ev = Event(topic=topic, data=data)
        for q in self._subs.get(topic, []) + self._subs.get("*", []):
            if q.full():
                try:
                    q.get_nowait()  # drop oldest
                except asyncio.QueueEmpty:
                    pass
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                pass
