"""Quiet-by-default logging.

In low-power mode the console shows only warnings and errors, keeping the
console window ("the black screen") calm and the CPU idle. Full detail is
always available on the dashboard Logs page, sourced from SQLite.
Exception text is sanitized so secrets can never leak into logs.
"""

from __future__ import annotations

import logging
import re

_SECRET_RE = re.compile(r"(key=)[A-Za-z0-9_\-]{8,}|AIza[A-Za-z0-9_\-]{10,}")


def sanitize(text: str) -> str:
    return _SECRET_RE.sub(r"\1[redacted]", text)


class SanitizingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return sanitize(super().format(record))


def setup_logging(level: str = "WARNING") -> None:
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.WARNING))
    handler = logging.StreamHandler()
    handler.setFormatter(SanitizingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
    root.handlers[:] = [handler]
    for noisy in ("uvicorn.access", "websockets", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
