"""Small network helpers."""

from __future__ import annotations

import ipaddress
import socket
from typing import List


# Explicit RFC-1918 networks — the only ranges accepted as private LAN
# addresses.  Using addr.is_private is intentionally avoided: Python's
# definition of "private" expanded in 3.11 to include documentation
# ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24), shared-address
# space (100.64.0.0/10), reserved (240.0.0.0/4), and others that must
# never be presented to a user as a reachable LAN address.
_RFC1918 = (
    ipaddress.IPv4Network("10.0.0.0/8"),
    ipaddress.IPv4Network("172.16.0.0/12"),
    ipaddress.IPv4Network("192.168.0.0/16"),
)


def _is_private_candidate(ip_str: str) -> bool:
    """Return True when *ip_str* is a usable RFC-1918 private IPv4 address.

    Accepted ranges (explicit whitelist):
      10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16

    Rejected regardless of Python version's is_private definition:
      loopback (127.x), unspecified (0.0.0.0), link-local (169.254.x),
      multicast (224+), documentation (192.0.2.x, 198.51.100.x,
      203.0.113.x), shared-address / CGNAT (100.64.0.0/10),
      reserved (240.0.0.0/4), and all other non-RFC-1918 addresses.
    """
    try:
        addr = ipaddress.IPv4Address(ip_str)
    except ValueError:
        return False
    # Fast rejection of well-known non-routable classes before the
    # network membership test (these properties are stable across versions).
    if addr.is_loopback:
        return False
    if addr.is_unspecified:
        return False
    if addr.is_link_local:
        return False
    if addr.is_multicast:
        return False
    # Whitelist: must be inside one of the three RFC-1918 blocks.
    return any(addr in net for net in _RFC1918)


def _adapter_ips() -> List[str]:
    """Return all IPv4 addresses bound to this host's network adapters."""
    try:
        hostname = socket.gethostname()
        infos = socket.getaddrinfo(hostname, None, socket.AF_INET)
        return [info[4][0] for info in infos if info[0] == socket.AF_INET]
    except OSError:
        return []


def _udp_route_ip(target: str = "8.8.8.8") -> str:
    """Discover the preferred outbound interface IP via a UDP route probe.

    No traffic is sent; connecting a UDP socket forces the OS to choose
    the right outbound adapter.  Returns empty string on failure.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((target, 80))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def lan_ips() -> List[str]:
    """Return a deterministic, deduplicated list of usable private IPv4
    candidates for this machine.

    Discovery strategy:
    1. UDP route probe to 8.8.8.8 — the OS-preferred outbound adapter.
       This is the most likely address a phone on the same Wi-Fi needs.
    2. UDP route probe to 1.1.1.1 — catches multi-homed machines where
       the two probes differ (e.g. both Ethernet and Wi-Fi are active).
    3. All addresses from getaddrinfo(hostname) — catches adapters that
       are not the default route.

    All results are filtered through ``_is_private_candidate``.
    The UDP route IPs are placed first (most likely primary adapter).
    Public, loopback, link-local, and multicast addresses are removed.
    """
    seen: dict[str, None] = {}  # insertion-ordered set (Python 3.7+)

    # Priority probes first
    for target in ("8.8.8.8", "1.1.1.1"):
        ip = _udp_route_ip(target)
        if ip and _is_private_candidate(ip) and ip not in seen:
            seen[ip] = None

    # All adapter IPs
    for ip in _adapter_ips():
        if _is_private_candidate(ip) and ip not in seen:
            seen[ip] = None

    return list(seen)


def lan_ip() -> str:
    """Backward-compatible single-address helper.

    Returns the first candidate from ``lan_ips()``, or the UDP route
    probe result (even if public), or empty string when offline.
    """
    candidates = lan_ips()
    if candidates:
        return candidates[0]
    # Fallback: original behaviour (may return a public IP if no private
    # adapter exists, but keeps backward compatibility)
    return _udp_route_ip()
