"""Operating state machine for Chat."""

from __future__ import annotations

from enum import Enum

from chat_core.events import EventBus


class ChatState(str, Enum):
    SLEEPING = "SLEEPING"
    CONNECTING = "CONNECTING"
    LISTENING = "LISTENING"
    SPEAKING = "SPEAKING"
    LOCAL_ONLY = "LOCAL_ONLY"
    MUTED = "MUTED"


class StateMachine:
    """Primary state + overlay flags (muted / degraded components).

    Degraded components now carry a reason string so the dashboard can
    show "audio: device not found" instead of the generic "degraded".
    """

    def __init__(self, bus: EventBus) -> None:
        self._bus = bus
        self._state = ChatState.SLEEPING
        self._muted = False
        # Maps component name -> reason string (non-empty = degraded).
        self._degraded: dict[str, str] = {}
        self.last_reason = "startup"

    # ------------------------------------------------------------------
    @property
    def state(self) -> ChatState:
        if self._muted:
            return ChatState.MUTED
        return self._state

    @property
    def raw_state(self) -> ChatState:
        return self._state

    @property
    def muted(self) -> bool:
        return self._muted

    @property
    def degraded(self) -> set[str]:
        """Names of currently-degraded components (backwards-compatible)."""
        return set(self._degraded)

    def degraded_reasons(self) -> dict[str, str]:
        """Return a copy of the component -> reason mapping."""
        return dict(self._degraded)

    # ------------------------------------------------------------------
    def set(self, state: ChatState, reason: str = "") -> None:
        if state == self._state:
            return
        self._state = state
        self.last_reason = reason
        self._emit()

    def set_muted(self, muted: bool) -> None:
        if muted == self._muted:
            return
        self._muted = muted
        self._emit()

    def mark_degraded(self, component: str, degraded: bool, reason: str = "") -> None:
        """Mark *component* degraded (with an optional reason) or healthy.

        Old callers that pass only (component, bool) still work because
        *reason* defaults to the empty string.
        """
        was_degraded = component in self._degraded
        if degraded:
            self._degraded[component] = reason or component
        else:
            self._degraded.pop(component, None)
        if was_degraded != (component in self._degraded):
            self._emit()

    def snapshot(self) -> dict:
        return {
            "state": self.state.value,
            "muted": self._muted,
            # list of names for backwards-compatible clients
            "degraded": sorted(self._degraded),
            # richer per-component details for newer clients
            "degraded_detail": [
                {"component": c, "reason": r}
                for c, r in sorted(self._degraded.items())
            ],
            "reason": self.last_reason,
        }

    def _emit(self) -> None:
        self._bus.publish("state", **self.snapshot())
