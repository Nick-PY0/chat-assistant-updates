"""Credential storage and lifecycle.

Statuses (user's policy -- no paid-fallback tier):
  active      preferred for new Gemini sessions
  standby     eligible for rotation
  disabled    never selected
  exhausted   project quota spent; blocked until retry_after
  invalid     rejected credential; never selected until replaced/re-enabled
  unavailable temporary provider trouble; retried with bounded backoff

Keys are grouped by project fingerprint. Keys in the same group share one
quota, so when a group is exhausted every key in it is blocked until the
group's retry time. Keys in *different* groups are rotated automatically.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import datetime, timezone

from chat_core.models.db import Database
from chat_core.security.vault import Vault

ROTATABLE = ("active", "standby", "exhausted", "unavailable")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime | None) -> str | None:
    return dt.astimezone(timezone.utc).isoformat() if dt else None


def parse_iso(s: str | None) -> datetime | None:
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


@dataclass
class Credential:
    id: str
    provider: str
    masked_suffix: str
    project_label: str
    project_fingerprint: str
    purpose: str
    priority: int
    status: str
    last_validated_at: datetime | None
    last_success_at: datetime | None
    failure_code: str | None
    retry_after: datetime | None
    created_at: datetime

    @property
    def blocked_until(self) -> datetime | None:
        return self.retry_after

    def selectable_at(self, now: datetime) -> bool:
        if self.status not in ROTATABLE:
            return False
        if self.retry_after and self.retry_after > now:
            return False
        return True

    def public(self) -> dict:
        return {
            "id": self.id,
            "provider": self.provider,
            "masked_suffix": self.masked_suffix,
            "project_label": self.project_label,
            "project_fingerprint": self.project_fingerprint,
            "purpose": self.purpose,
            "priority": self.priority,
            "status": self.status,
            "last_validated_at": iso(self.last_validated_at),
            "last_success_at": iso(self.last_success_at),
            "failure_code": self.failure_code,
            "retry_after": iso(self.retry_after),
            "created_at": iso(self.created_at),
        }


def _row_to_cred(row) -> Credential:
    return Credential(
        id=row["id"],
        provider=row["provider"],
        masked_suffix=row["masked_suffix"],
        project_label=row["project_label"],
        project_fingerprint=row["project_fingerprint"],
        purpose=row["purpose"],
        priority=row["priority"],
        status=row["status"],
        last_validated_at=parse_iso(row["last_validated_at"]),
        last_success_at=parse_iso(row["last_success_at"]),
        failure_code=row["failure_code"],
        retry_after=parse_iso(row["retry_after"]),
        created_at=parse_iso(row["created_at"]) or utcnow(),
    )


class CredentialStore:
    def __init__(self, db: Database, vault: Vault) -> None:
        self.db = db
        self.vault = vault

    @staticmethod
    def context(provider: str, purpose: str) -> str:
        return f"{provider}:{purpose}"

    # -- CRUD -----------------------------------------------------------
    async def add(
        self,
        provider: str,
        secret: str,
        project_label: str = "",
        purpose: str = "voice",
    ) -> Credential:
        secret = secret.strip()
        if not secret:
            raise ValueError("empty secret")
        cred_id = "c_" + secrets.token_hex(8)
        # Same explicit project label => same quota group. Otherwise each
        # key is its own group, which is exactly the user's rotation model:
        # more keys added = more rotation capacity.
        group_source = f"label:{project_label.strip().lower()}" if project_label.strip() else f"key:{cred_id}"
        fingerprint = Vault.fingerprint(group_source)
        blob = self.vault.encrypt(secret, self.context(provider, purpose))
        count = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM credentials WHERE provider=?", (provider,)
        )
        n = int(count["n"]) if count else 0
        status = "active" if provider == "gemini" and n == 0 else "standby"
        await self.db.execute(
            """INSERT INTO credentials
               (id, provider, encrypted_secret, masked_suffix, project_label,
                project_fingerprint, purpose, priority, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                cred_id,
                provider,
                blob,
                Vault.mask(secret),
                project_label.strip(),
                fingerprint,
                purpose,
                (n + 1) * 10,
                status,
                iso(utcnow()),
            ),
        )
        cred = await self.get(cred_id)
        assert cred is not None
        return cred

    async def get(self, cred_id: str) -> Credential | None:
        row = await self.db.fetchone("SELECT * FROM credentials WHERE id=?", (cred_id,))
        return _row_to_cred(row) if row else None

    async def get_secret(self, cred_id: str) -> str:
        """Decrypt a stored secret. Internal use only -- never expose via API."""
        row = await self.db.fetchone(
            "SELECT provider, purpose, encrypted_secret FROM credentials WHERE id=?",
            (cred_id,),
        )
        if row is None:
            raise KeyError(cred_id)
        return self.vault.decrypt(row["encrypted_secret"], self.context(row["provider"], row["purpose"]))

    async def list(self, provider: str | None = None) -> list[Credential]:
        if provider:
            rows = await self.db.fetchall(
                "SELECT * FROM credentials WHERE provider=? ORDER BY priority, created_at",
                (provider,),
            )
        else:
            rows = await self.db.fetchall(
                "SELECT * FROM credentials ORDER BY provider, priority, created_at"
            )
        return [_row_to_cred(r) for r in rows]

    async def remove(self, cred_id: str) -> None:
        await self.db.execute("DELETE FROM credentials WHERE id=?", (cred_id,))

    # -- status transitions ----------------------------------------------
    async def set_status(
        self,
        cred_id: str,
        status: str,
        failure_code: str | None = None,
        retry_after: datetime | None = None,
    ) -> None:
        await self.db.execute(
            "UPDATE credentials SET status=?, failure_code=?, retry_after=? WHERE id=?",
            (status, failure_code, iso(retry_after), cred_id),
        )

    async def set_priority(self, cred_id: str, priority: int) -> None:
        await self.db.execute("UPDATE credentials SET priority=? WHERE id=?", (priority, cred_id))

    async def mark_validated(self, cred_id: str) -> None:
        await self.db.execute(
            "UPDATE credentials SET last_validated_at=? WHERE id=?", (iso(utcnow()), cred_id)
        )

    async def mark_success(self, cred_id: str) -> None:
        await self.db.execute(
            "UPDATE credentials SET last_success_at=?, failure_code=NULL, retry_after=NULL, "
            "status=CASE WHEN status IN ('exhausted','unavailable') THEN 'standby' ELSE status END "
            "WHERE id=?",
            (iso(utcnow()), cred_id),
        )

    async def mark_project_exhausted(
        self, fingerprint: str, retry_after: datetime, failure_code: str = "quota_exhausted"
    ) -> int:
        """Quota is per project: block every key sharing the fingerprint."""
        rows = await self.db.fetchall(
            "SELECT id FROM credentials WHERE project_fingerprint=? AND status NOT IN ('disabled','invalid')",
            (fingerprint,),
        )
        for row in rows:
            await self.set_status(row["id"], "exhausted", failure_code, retry_after)
        return len(rows)

    async def release_expired_blocks(self) -> list[str]:
        """Return ids whose retry window has arrived; flip them to standby."""
        now = iso(utcnow())
        rows = await self.db.fetchall(
            "SELECT id FROM credentials WHERE status IN ('exhausted','unavailable') "
            "AND retry_after IS NOT NULL AND retry_after <= ?",
            (now,),
        )
        ids = [r["id"] for r in rows]
        for cred_id in ids:
            await self.set_status(cred_id, "standby", None, None)
        return ids
