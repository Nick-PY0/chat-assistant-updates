@echo off
title Chat
color 07
cd /d "%~dp0"

if exist .venv\Scripts\python.exe (
    set PY=.venv\Scripts\python.exe
) else (
    set PY=python
)

:run
%PY% run_chat.py %*
if "%errorlevel%"=="42" (
    echo Restarting Chat...
    goto run
)
if errorlevel 1 (
    echo.
    echo Chat exited with an error. See above.
    pause
)
