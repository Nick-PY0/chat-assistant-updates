CREATE TABLE IF NOT EXISTS credentials (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,                -- 'gemini' | 'govee'
    encrypted_secret BLOB NOT NULL,
    masked_suffix TEXT NOT NULL,
    project_label TEXT NOT NULL DEFAULT '',
    project_fingerprint TEXT NOT NULL,
    purpose TEXT NOT NULL DEFAULT 'voice',
    priority INTEGER NOT NULL DEFAULT 100,
    status TEXT NOT NULL DEFAULT 'standby', -- active|standby|disabled|exhausted|invalid|unavailable
    last_validated_at TEXT,
    last_success_at TEXT,
    failure_code TEXT,
    retry_after TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS timers (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL DEFAULT '',
    duration_seconds INTEGER NOT NULL,
    deadline TEXT,                          -- NULL while paused
    remaining_seconds INTEGER,              -- set while paused
    status TEXT NOT NULL DEFAULT 'running', -- running|paused|completed|cancelled|missed
    created_at TEXT NOT NULL,
    finished_at TEXT
);

CREATE TABLE IF NOT EXISTS health (
    component TEXT PRIMARY KEY,
    status TEXT NOT NULL,                   -- ok|degraded|down|unknown
    detail TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    level TEXT NOT NULL,
    component TEXT NOT NULL,
    message TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS usage_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    credential_id TEXT,
    event TEXT NOT NULL,
    detail TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_credentials_provider ON credentials(provider);
CREATE INDEX IF NOT EXISTS idx_timers_status ON timers(status);
CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage_log(ts);
