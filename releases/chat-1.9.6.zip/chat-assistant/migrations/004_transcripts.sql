-- Voice session registry and transcripts store.
-- session_id is a random token issued at session-start; it binds
-- async cleanup so a rapid Stop→Start cannot let stale cleanup
-- clear the newly-started session.
CREATE TABLE IF NOT EXISTS voice_sessions (
    id TEXT PRIMARY KEY,           -- random token, e.g. secrets.token_hex(16)
    provider TEXT NOT NULL,        -- gemini | openai_live | relay
    credential_id TEXT,
    started_at TEXT NOT NULL,      -- UTC ISO
    ended_at TEXT,
    close_reason TEXT
);

CREATE TABLE IF NOT EXISTS transcripts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES voice_sessions(id) ON DELETE CASCADE,
    ts TEXT NOT NULL,              -- UTC ISO
    role TEXT NOT NULL,            -- 'user' | 'assistant'
    text TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_transcripts_session ON transcripts(session_id, id);
CREATE INDEX IF NOT EXISTS idx_voice_sessions_started ON voice_sessions(started_at DESC);
