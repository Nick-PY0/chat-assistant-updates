-- Clock-time reminders and alarms ("remind me to take the chicken out at 5").
CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY,
    message TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL DEFAULT 'reminder',   -- 'reminder' | 'alarm'
    fires_at TEXT NOT NULL,                  -- absolute UTC ISO timestamp
    status TEXT NOT NULL DEFAULT 'scheduled',-- scheduled|fired|missed|cancelled
    created_at TEXT NOT NULL,
    finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(status, fires_at);
