-- Persist the active ring state so a process restart resumes ringing.
-- Only one row should ever exist (id='current').
CREATE TABLE IF NOT EXISTS active_ring (
    id TEXT PRIMARY KEY DEFAULT 'current',
    reminder_id TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'reminder',
    message TEXT NOT NULL DEFAULT '',
    started_at TEXT NOT NULL,
    snoozed_until TEXT         -- NULL = not snoozed; ISO UTC
);
