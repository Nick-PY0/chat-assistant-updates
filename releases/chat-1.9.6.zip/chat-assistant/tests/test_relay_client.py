"""Relay client: URL shaping, auth errors in plain words, WAV plumbing."""

from __future__ import annotations

import base64
import json

import httpx
import pytest

from integrations.relay.client import RelayClient, RelayError, parse_wav, wrap_wav


def test_base_url_shaping():
    assert RelayClient("https://x.replit.app", "s").base == "https://x.replit.app/api"
    assert RelayClient("x.replit.app", "s").base == "https://x.replit.app/api"
    assert RelayClient("https://x.replit.app/", "s").base == "https://x.replit.app/api"
    assert RelayClient("https://x.replit.app/api", "s").base == "https://x.replit.app/api"
    assert RelayClient("", "s").base == ""


def test_plain_http_is_refused():
    with pytest.raises(RelayError) as info:
        RelayClient("http://sketchy.example", "s")
    assert "https" in str(info.value)


def test_wav_roundtrip_mono():
    pcm = b"\x01\x02" * 1000
    blob = wrap_wav(pcm, 16000)
    out, rate = parse_wav(blob)
    assert out == pcm
    assert rate == 16000


def test_wav_stereo_folds_to_mono():
    import struct
    frames = b"".join(struct.pack("<hh", 1000, 3000) for _ in range(100))
    blob = wrap_wav(frames, 24000, channels=2)
    out, rate = parse_wav(blob)
    assert rate == 24000
    assert len(out) == 100 * 2  # one sample per frame now
    import array
    folded = array.array("h")
    folded.frombytes(out)
    assert all(v == 2000 for v in folded)


def test_parse_wav_garbage_is_a_relay_error():
    with pytest.raises(RelayError):
        parse_wav(b"this is not audio")


def make_client(handler) -> RelayClient:
    return RelayClient("https://relay.test", "pw123",
                       transport=httpx.MockTransport(handler))


async def test_missing_url_fails_before_network():
    client = RelayClient("", "pw")
    with pytest.raises(RelayError) as info:
        await client.health()
    assert "no relay address" in str(info.value)


async def test_auth_errors_speak_plainly():
    def handler(request):
        return httpx.Response(401, json={"error": "bad key"})
    with pytest.raises(RelayError) as info:
        await make_client(handler).health()
    assert "password" in str(info.value)

    def handler503(request):
        return httpx.Response(503, json={"error": "relay not configured"})
    with pytest.raises(RelayError) as info:
        await make_client(handler503).health()
    assert "no password set" in str(info.value)


async def test_ask_passes_through_and_sends_auth_header():
    seen = {}

    def handler(request):
        seen["path"] = request.url.path
        seen["key"] = request.headers.get("x-chat-relay-key")
        seen["body"] = json.loads(request.content)
        return httpx.Response(200, json={
            "model": "gpt-5.6-terra", "reply": "hello", "tool_calls": [],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2},
        })

    data = await make_client(handler).ask(
        [{"role": "user", "content": "hi"}], [], "gpt-5.6-terra")
    assert data["reply"] == "hello"
    assert seen["path"] == "/api/relay/ask"
    assert seen["key"] == "pw123"
    assert seen["body"]["model"] == "gpt-5.6-terra"
    assert seen["body"]["max_tokens"] >= 1000  # room for reasoning models


async def test_transcribe_wraps_pcm_into_wav():
    seen = {}

    def handler(request):
        body = json.loads(request.content)
        seen["audio"] = base64.b64decode(body["audio_b64"])
        return httpx.Response(200, json={"text": " turn on the lights "})

    text = await make_client(handler).transcribe(b"\x00\x01" * 800)
    assert text == "turn on the lights"
    assert seen["audio"][:4] == b"RIFF"
    assert b"WAVE" in seen["audio"][:16]


async def test_speak_decodes_wav():
    pcm = b"\x07\x00" * 2400

    def handler(request):
        blob = wrap_wav(pcm, 24000)
        return httpx.Response(200, json={"audio_b64": base64.b64encode(blob).decode()})

    out, rate = await make_client(handler).speak("hi there", "alloy")
    assert rate == 24000
    assert out == pcm


async def test_speak_empty_audio_is_an_error():
    def handler(request):
        return httpx.Response(200, json={"audio_b64": ""})
    with pytest.raises(RelayError):
        await make_client(handler).speak("hi", "alloy")


async def test_server_error_message_surfaces():
    def handler(request):
        return httpx.Response(429, json={"error": "daily relay budget on the server is spent"})
    with pytest.raises(RelayError) as info:
        await make_client(handler).health()
    assert "budget" in str(info.value)
