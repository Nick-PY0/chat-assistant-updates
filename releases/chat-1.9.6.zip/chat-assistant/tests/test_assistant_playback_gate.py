"""Tests for assistant_playback WebSocket control message gating.

Covers:
  1. assistant_playback playing=true arms the mic gate (frames withheld while
     Chat speaks).
  2. assistant_playback playing=false releases the gate after the settling tail.
  3. Post-playback settling tail: audio arriving within ~400 ms of playback=false
     is still suppressed; audio after the tail passes through.
  4. Loud user speech (clearly above calibrated leakage) eventually forwards
     through the gate even during the settling tail (barge-in path).
  5. media_state messages still work alongside assistant_playback.
  6. Unknown control-message types are silently ignored (no crash).
  7. assistant_playback=false on flush/Stop/Goodbye (WebSocket lifecycle).
"""

from __future__ import annotations

import asyncio
import json
import time
from types import SimpleNamespace

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.audio.mic_gate import PlaybackAwareMicGate, ASSISTANT_SETTLE_SECONDS
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


# ---------------------------------------------------------------------------
# Unit tests for PlaybackAwareMicGate.set_assistant_playing
# ---------------------------------------------------------------------------

def pcm(level: int, seconds: float = 0.08) -> bytes:
    import array
    return array.array("h", [level] * int(16_000 * seconds)).tobytes()


class TestAssistantPlaybackGate:
    """Unit tests for the new set_assistant_playing path."""

    def test_passthrough_when_nothing_playing(self):
        gate = PlaybackAwareMicGate(700)
        frame = pcm(100)
        assert gate.feed(frame) == (frame,)

    def test_gate_armed_when_assistant_playing(self):
        """While assistant is playing, mic input is gated like media playback."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        assert gate.assistant_playing is True
        # Low-level residue must be withheld.
        assert gate.feed(pcm(100)) == ()

    def test_no_duplicate_state_change_on_same_value(self):
        """Calling set_assistant_playing with the same value twice does not
        reset the learned noise floor."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        # Feed some audio to build calibration
        for _ in range(5):
            gate.feed(pcm(300))
        floor_before = gate._noise_floor

        gate.set_assistant_playing(True)  # same value — should be no-op
        assert gate._noise_floor == floor_before

    def test_settling_tail_suppresses_immediately_after_false(self):
        """After assistant playing → false, frames are still gated during the
        settling tail (reverb window)."""
        gate = PlaybackAwareMicGate(700, assistant_settle_seconds=0.4)
        gate.set_assistant_playing(True)
        # Feed calibration during playback.
        for _ in range(5):
            gate.feed(pcm(200))
        # Stop playback.
        gate.set_assistant_playing(False)
        # Immediately after stopping, the settling tail should still gate.
        assert gate._in_settling_tail is True
        assert gate.feed(pcm(200)) == ()

    def test_settling_tail_expires_and_gate_opens(self):
        """After the settling tail expires, frames pass through normally."""
        gate = PlaybackAwareMicGate(700, assistant_settle_seconds=0.001)
        gate.set_assistant_playing(True)
        gate.set_assistant_playing(False)
        # Wait for settling tail to expire.
        time.sleep(0.05)
        frame = pcm(100)
        assert gate.feed(frame) == (frame,)

    def test_loud_speech_during_settling_tail_can_open_gate(self):
        """Even within the settling tail, clearly loud speech can open the
        gate once the onset threshold is met (barge-in path)."""
        gate = PlaybackAwareMicGate(700, calibration_seconds=0, assistant_settle_seconds=2.0)
        gate.set_assistant_playing(True)
        gate.set_assistant_playing(False)
        assert gate._in_settling_tail is True

        # Push very loud audio: should satisfy onset threshold
        very_loud = pcm(20_000)
        # Feed multiple frames to clear onset_seconds requirement.
        result = []
        for _ in range(5):
            result.extend(gate.feed(very_loud))

        assert gate.is_open, "Barge-in: gate must open for clearly loud speech in settling tail"

    def test_assistant_and_media_combined(self):
        """Both assistant and media playing combine correctly: gate stays
        armed while either is active."""
        gate = PlaybackAwareMicGate(700)
        gate.set_media_playing(True)
        gate.set_assistant_playing(True)

        # Gate is armed — residue withheld.
        assert gate.feed(pcm(100)) == ()

        # Media stops, but assistant still playing.
        gate.set_media_playing(False)
        assert gate.assistant_playing is True
        # Gate must still be armed.
        assert gate.feed(pcm(100)) == ()

    def test_assistant_stops_resets_utterance_not_noise_floor(self):
        """set_assistant_playing(False) closes the utterance window but
        does NOT wipe the learned noise floor (unlike set_media_playing)."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        # Feed enough to build noise floor.
        for _ in range(10):
            gate.feed(pcm(1_500))
        floor_before = gate._noise_floor

        # Open the gate by feeding loud speech.
        for _ in range(5):
            gate.feed(pcm(8_000))
        assert gate.is_open

        gate.set_assistant_playing(False)
        # Utterance must be closed.
        assert not gate.is_open
        # Noise floor should be retained (not None).
        assert gate._noise_floor is not None


# ---------------------------------------------------------------------------
# WebSocket integration tests (server-side)
# ---------------------------------------------------------------------------

async def _dummy_tools(call_id, name, args):
    return {}


class FakeWebSocket:
    """Small ASGI-WebSocket double."""

    def __init__(self, token: str) -> None:
        self.cookies = {COOKIE: token}
        self.incoming: asyncio.Queue[dict] = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code: int | None = None
        self.close_reason = ""
        self.sent_bytes: list[bytes] = []
        self.sent_text: list[str] = []

    async def accept(self) -> None:
        self.accepted.set()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        self.close_code = code
        self.close_reason = reason or ""
        self.closed.set()

    async def receive(self) -> dict:
        return await self.incoming.get()

    async def send_bytes(self, payload: bytes) -> None:
        self.sent_bytes.append(payload)

    async def send_text(self, payload: str) -> None:
        self.sent_text.append(payload)

    def feed_text(self, payload: str) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "text": payload})

    def feed_audio(self, payload: bytes) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": payload})

    def disconnect(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})


@pytest.fixture
def playback_app(settings, db, store, bus):
    state = StateMachine(bus)
    gateway = LiveGateway(settings, db, store, bus, state, [], _dummy_tools)
    runtime = SimpleNamespace(
        settings=settings,
        db=db,
        state=state,
        gateway=gateway,
        broadcast=AudioBroadcast(),
        audio=None,
        media_playing=False,
        stop_calls=0,
    )

    def stop_output() -> None:
        runtime.stop_calls += 1
        gateway.interrupt()
        runtime.broadcast.clear()

    runtime.stop_output = stop_output
    app = create_app(runtime)
    sessions = SessionManager("playback-gate-test-secret", 3600)
    app.state.sessions = sessions
    token = sessions.issue()
    endpoint = next(
        route.endpoint for route in app.routes if route.path == "/ws/remote-audio"
    )
    return app, runtime, token, endpoint


async def _open_socket(app, token, endpoint) -> tuple[FakeWebSocket, asyncio.Task]:
    ws = FakeWebSocket(token)
    task = asyncio.create_task(endpoint(ws))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    for _ in range(20):
        owner = app.state.remote_mic_owner
        if owner is not None and owner.socket is ws:
            break
        if ws.closed.is_set():
            break
        await asyncio.sleep(0)
    return ws, task


async def test_assistant_playback_true_gates_mic(playback_app):
    """assistant_playback playing=true arms the mic gate; PCM frames are
    withheld while Chat is speaking (session must be active to forward)."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    # Start a session so PCM can be forwarded.
    gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Without playback gating, loud audio should reach audio_in.
    loud = (3000).to_bytes(2, "little", signed=True) * 800  # 1600 bytes
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)
    has_audio_initially = not rt.gateway.audio_in.empty()
    # Drain.
    while not rt.gateway.audio_in.empty():
        rt.gateway.audio_in.get_nowait()

    # Now arm assistant playback gate.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": True}))
    await asyncio.sleep(0.05)

    # Feed audio at a level that would normally pass through.
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)

    # Gate should suppress it.
    assert rt.gateway.audio_in.empty(), (
        "assistant_playback=true must gate mic: no PCM should reach audio_in"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_assistant_playback_false_releases_gate_after_tail(playback_app):
    """assistant_playback playing=false starts the settling tail; after the
    tail expires, normal loud speech reaches audio_in."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Arm the gate.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": True}))
    await asyncio.sleep(0.05)

    # Release — settling tail begins.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": False}))
    await asyncio.sleep(0.05)

    # Immediately after false, the settling tail should still suppress.
    loud = (3000).to_bytes(2, "little", signed=True) * 800
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.05)
    still_gated = rt.gateway.audio_in.empty()

    # Wait for tail to expire (ASSISTANT_SETTLE_SECONDS + margin).
    await asyncio.sleep(ASSISTANT_SETTLE_SECONDS + 0.15)

    # Now feed very loud audio — must pass through.
    very_loud = (10000).to_bytes(2, "little", signed=True) * 800
    ws.feed_audio(very_loud)
    ws.feed_audio(very_loud)
    ws.feed_audio(very_loud)
    await asyncio.sleep(0.2)

    forwarded_after_tail = not rt.gateway.audio_in.empty()

    # Settling tail behavior: gated immediately after false.
    assert still_gated, "Audio immediately after playback=false must still be gated (settling tail)"
    # After tail: loud speech must forward.
    assert forwarded_after_tail, (
        "Loud speech after settling tail must reach audio_in"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_loud_barge_in_during_playback_eventually_forwards(playback_app):
    """Very loud user speech that rises clearly above calibrated playback
    leakage must eventually forward through the gate, even while assistant
    is playing (barge-in path).

    Scenario:
      1. Assistant starts playing at a moderate level (calibrated as noise floor).
      2. The user speaks at a level significantly above the calibrated floor.
      3. After the onset window, the gate opens and frames reach audio_in.
    """
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Arm assistant playback gate.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": True}))
    await asyncio.sleep(0.05)

    # Simulate assistant TTS leaking into the mic at a moderate level.
    # This represents the speaker bleed during playback — calibrated as noise.
    playback_leakage = (1500).to_bytes(2, "little", signed=True) * 800  # 1600 bytes, 0.05 s

    # Feed calibration frames so the gate learns the leakage level.
    # Default calibration_seconds = 0.16 s, so ~4 frames at 0.05 s each.
    for _ in range(6):  # slightly more than needed for calibration
        ws.feed_audio(playback_leakage)

    await asyncio.sleep(0.15)

    # Now the user speaks loudly — well above the calibrated leakage level.
    # leakage level ~1500, noise_ratio = 1.55 → threshold ≈ 2325.
    # User voice at 12000 >> 2325, so it must open the gate.
    user_voice = (12000).to_bytes(2, "little", signed=True) * 800

    # Feed enough frames to clear onset (0.12 s ≈ 3 frames) with margin.
    for _ in range(8):
        ws.feed_audio(user_voice)

    await asyncio.sleep(0.3)

    assert not rt.gateway.audio_in.empty(), (
        "Very loud barge-in speech must eventually reach audio_in even during assistant playback"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_media_state_and_assistant_playback_coexist(playback_app):
    """media_state and assistant_playback control messages both work and
    combine correctly without interfering with each other."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Send media_state playing=true.
    ws.feed_text(json.dumps({"type": "media_state", "playing": True}))
    await asyncio.sleep(0.05)

    # Also send assistant_playback playing=true.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": True}))
    await asyncio.sleep(0.05)

    # Both should gate the mic.
    loud = (3000).to_bytes(2, "little", signed=True) * 800
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)
    assert rt.gateway.audio_in.empty(), "Combined media+assistant gate must suppress audio"

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_unknown_control_message_ignored(playback_app):
    """Unknown control message types must be silently ignored (no crash, no
    gate state change)."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Send an unknown control message.
    ws.feed_text(json.dumps({"type": "future_feature", "data": "xyz"}))
    await asyncio.sleep(0.05)

    # Socket must still be alive.
    assert not ws.closed.is_set(), "Unknown control message must not crash the socket"

    # PCM should still pass through (gate not armed).
    loud = (3000).to_bytes(2, "little", signed=True) * 800
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)
    # Gate not armed → audio should reach audio_in.
    assert not rt.gateway.audio_in.empty(), (
        "After unknown control message, gate must remain open (audio should forward)"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_invalid_json_control_ignored(playback_app):
    """Malformed JSON in a control message must be silently ignored."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    ws.feed_text("{not valid json!!")
    await asyncio.sleep(0.05)

    assert not ws.closed.is_set(), "Malformed JSON must not crash the socket"

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_assistant_playback_preserves_voice_session_contract(playback_app):
    """assistant_playback messages must not interfere with the voice session
    contract: wake→session→end cycle still works normally."""
    app, rt, token, endpoint = playback_app
    ws, task = await _open_socket(app, token, endpoint)

    assert rt.gateway.voice_session_generation == 0

    # Wake hit.
    first_gen = rt.gateway.request_session()
    await asyncio.sleep(0)

    # Send assistant_playback=true (Chat starts speaking).
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": True}))
    await asyncio.sleep(0.05)

    # Session still active.
    assert rt.gateway.session_intent_active, "Session must remain active during assistant playback"

    # Send assistant_playback=false.
    ws.feed_text(json.dumps({"type": "assistant_playback", "playing": False}))
    await asyncio.sleep(0.05)

    # End session (goodbye equivalent).
    rt.gateway.request_end_session("goodbye")
    rt.state.set(ChatState.SLEEPING, "goodbye")
    await asyncio.sleep(0.15)

    # Socket must stay open.
    assert not ws.closed.is_set(), "Socket must stay open after session end"

    # Second wake hit must work.
    second_gen = rt.gateway.request_session()
    assert second_gen > first_gen, "Second wake must produce a higher generation"

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
    assert app.state.remote_mic_owner is None
