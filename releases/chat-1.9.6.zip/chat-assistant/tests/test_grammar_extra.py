"""Grammar coverage for the stop/memory additions."""

from __future__ import annotations

import pytest

from apps.tool_service.local_grammar import parse


@pytest.mark.parametrize("text", [
    "stop", "Stop.", "stop talking", "stop it", "be quiet", "shut up",
    "never mind", "nevermind", "cancel that", "hey chat stop",
])
def test_stop_variants(text):
    assert parse(text) == {"tool": "stop_output", "args": {}}


def test_stop_does_not_eat_timer_cancel():
    cmd = parse("cancel the pasta timer")
    assert cmd is not None
    assert cmd["tool"] != "stop_output"


@pytest.mark.parametrize("text,expected", [
    ("remember that the garage code is 4417", "the garage code is 4417"),
    ("remember I parked on level 3", "i parked on level 3"),
    ("chat remember that bins go out on tuesday", "bins go out on tuesday"),
])
def test_remember_patterns(text, expected):
    cmd = parse(text)
    assert cmd["tool"] == "remember_fact"
    assert cmd["args"]["content"] == expected


@pytest.mark.parametrize("text,query", [
    ("what do you remember", ""),
    ("what do you remember about parking", "parking"),
    ("what did i tell you about the garage", "the garage"),
    ("do you remember the wifi password", "the wifi password"),
])
def test_recall_patterns(text, query):
    cmd = parse(text)
    assert cmd["tool"] == "recall_memories"
    assert cmd["args"]["query"] == query


@pytest.mark.parametrize("text,query", [
    ("forget the garage code", "the garage code"),
    ("forget about the parking spot", "the parking spot"),
    ("forget that i parked on level 3", "i parked on level 3"),
])
def test_forget_patterns(text, query):
    cmd = parse(text)
    assert cmd["tool"] == "forget_memory"
    assert cmd["args"]["query"] == query


def test_forget_timer_still_goes_to_timer_logic():
    """'forget the timer' must not delete memories."""
    cmd = parse("forget the pasta timer")
    assert cmd is None or cmd["tool"] != "forget_memory"
