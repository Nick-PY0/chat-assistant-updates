"""chat_core.pcm: pure-stdlib resampling and level metering."""

from __future__ import annotations

import array
import math

from chat_core.pcm import resample_linear, rms16


def tone(freq: int, rate: int, seconds: float, amp: int = 8000) -> bytes:
    n = int(rate * seconds)
    samples = array.array("h", (int(amp * math.sin(2 * math.pi * freq * i / rate)) for i in range(n)))
    return samples.tobytes()


def test_resample_identity():
    pcm = tone(440, 16000, 0.1)
    assert resample_linear(pcm, 16000, 16000) == pcm


def test_resample_16_to_24_length():
    pcm = tone(440, 16000, 0.1)  # 1600 samples
    out = resample_linear(pcm, 16000, 24000)
    assert len(out) == 1600 * 3 // 2 * 2  # 2400 samples, 2 bytes each


def test_resample_24_to_16_length():
    pcm = tone(440, 24000, 0.1)  # 2400 samples
    out = resample_linear(pcm, 24000, 16000)
    assert abs(len(out) // 2 - 1600) <= 1


def test_resample_preserves_loudness_roughly():
    pcm = tone(440, 16000, 0.2)
    out = resample_linear(pcm, 16000, 24000)
    assert abs(rms16(out) - rms16(pcm)) / rms16(pcm) < 0.1


def test_resample_empty_and_odd_bytes():
    assert resample_linear(b"", 16000, 24000) == b""
    assert resample_linear(b"\x01", 16000, 24000) == b""  # half a sample


def test_rms_silence_vs_tone():
    assert rms16(b"\x00" * 3200) == 0.0
    assert rms16(tone(440, 16000, 0.1)) > 4000
    assert rms16(b"") == 0.0
