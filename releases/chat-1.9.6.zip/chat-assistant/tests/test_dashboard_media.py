from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


VIDEO_ID = "dQw4w9WgXcQ"


@pytest.fixture
async def media_rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    # Never launch a real browser during tests: replace the host-browser opener
    # on the live YouTubeTool with a recording stub.
    runtime.host_browser_opens = []
    if runtime.youtube_tools is not None:
        runtime.youtube_tools._open_browser = runtime.host_browser_opens.append
    yield runtime
    await runtime.stop()


@pytest.fixture
async def media_client(media_rt):
    app = create_app(media_rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        client.app = app
        response = await client.post(
            "/setup", data={"password": "media-password-123", "confirm": "media-password-123"}
        )
        assert response.status_code == 303
        yield client


def _csrf(client) -> str:
    return client.app.state.sessions.csrf_for(client.cookies.get(COOKIE))


@pytest.mark.asyncio
async def test_authenticated_media_state_control_and_single_owner(media_client, media_rt):
    csrf = _csrf(media_client)
    headers = {"x-csrf": csrf}

    # ── part 1: no-owner play auto-opens the host browser ─────────────────
    response = await media_client.post(
        "/api/media/control",
        json={"action": "play", "video_id": VIDEO_ID, "title": "Test video"},
        headers=headers,
    )
    assert response.status_code == 200
    body = response.json()
    # No embedded owner: playback auto-starts in the host browser, never
    # falsely "queued".
    assert body["queued"] is False
    assert body["playback_mode"] == "host_browser"
    assert media_rt.host_browser_opens == [f"https://www.youtube.com/watch?v={VIDEO_ID}"]

    state = await media_client.get("/api/media")
    assert state.status_code == 200
    assert state.json()["video_id"] == VIDEO_ID

    # ── part 2: passive claim while host_browser is active ────────────────
    # A fresh page claiming gets owner=True but playback_mode stays host_browser.
    # No command rebound is emitted (that would create an unwanted iframe).
    passive = await media_client.post(
        "/api/media/claim",
        json={"client_id": "phone_12345678", "label": "Phone"},
        headers=headers,
    )
    assert passive.json()["owner"] is True
    assert passive.json()["playback_mode"] == "host_browser"

    # Viewer from a second device still gets owner=False.
    viewer = await media_client.post(
        "/api/media/claim",
        json={"client_id": "laptop_12345678", "label": "Laptop"},
        headers=headers,
    )
    assert viewer.json()["owner"] is False

    # ── part 3: force-takeover resets to embedded playback ────────────────
    takeover = await media_client.post(
        "/api/media/claim",
        json={"client_id": "phone_12345678", "label": "Phone", "force": True},
        headers=headers,
    )
    assert takeover.json()["owner"] is True
    assert takeover.json()["playback_mode"] == "embedded"
    assert takeover.json()["command"]["target_id"] == "phone_12345678"

    # ── part 4: embedded report + pause ───────────────────────────────────
    report = await media_client.post(
        "/api/media/state",
        json={
            "client_id": "phone_12345678",
            "status": "playing",
            "video_id": VIDEO_ID,
            "position_seconds": 12.5,
        },
        headers=headers,
    )
    assert report.status_code == 200
    assert media_rt.media_playing is True

    paused = await media_client.post(
        "/api/media/control", json={"action": "pause"}, headers=headers
    )
    assert paused.status_code == 200
    assert media_rt.media_playing is False

    # ── part 5: second takeover + stale report is rejected ────────────────
    takeover2 = await media_client.post(
        "/api/media/claim",
        json={"client_id": "laptop_12345678", "label": "Laptop", "force": True},
        headers=headers,
    )
    assert takeover2.json()["owner"] is True
    stale = await media_client.post(
        "/api/media/state",
        json={"client_id": "phone_12345678", "status": "playing"},
        headers=headers,
    )
    assert stale.status_code == 409


@pytest.mark.asyncio
async def test_media_writes_require_csrf(media_client):
    response = await media_client.post(
        "/api/media/control", json={"action": "play", "video_id": VIDEO_ID}
    )
    assert response.status_code == 403


@pytest.mark.asyncio
async def test_host_open_endpoint_requires_csrf(media_client, media_rt):
    """The 101/150 host-open endpoint must reject a POST without a CSRF token,
    and never open a browser."""
    response = await media_client.post(
        "/api/media/host-open", json={"client_id": "phone_12345678"}
    )
    assert response.status_code == 403
    assert media_rt.host_browser_opens == []


@pytest.mark.asyncio
async def test_host_open_endpoint_requires_auth(media_rt):
    """Unauthenticated request (no session) is rejected with 401; no browser."""
    app = create_app(media_rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.post(
            "/api/media/host-open", json={"client_id": "phone_12345678"}
        )
    assert response.status_code in (401, 303)
    assert media_rt.host_browser_opens == []


@pytest.mark.asyncio
async def test_host_open_endpoint_opens_only_for_active_owner(media_client, media_rt):
    """The endpoint opens the active canonical video only for the current lease
    owner, exactly once, and rejects a non-owner and hostile client ids."""
    csrf = _csrf(media_client)
    headers = {"x-csrf": csrf}

    # Claim + set an active video via the embedded owner.
    owner = await media_client.post(
        "/api/media/claim",
        json={"client_id": "phone_12345678", "label": "Phone"},
        headers=headers,
    )
    assert owner.json()["owner"] is True
    play = await media_client.post(
        "/api/media/control",
        json={"action": "play", "video_id": VIDEO_ID, "title": "Test video"},
        headers=headers,
    )
    assert play.status_code == 200
    # Embedded owner: no host-browser open yet.
    assert media_rt.host_browser_opens == []

    # A non-owner client cannot trigger a host open.
    bad = await media_client.post(
        "/api/media/host-open",
        json={"client_id": "laptop_87654321"},
        headers=headers,
    )
    assert bad.status_code == 409
    assert media_rt.host_browser_opens == []

    # Hostile/malformed client id is rejected and opens nothing.
    hostile = await media_client.post(
        "/api/media/host-open",
        json={"client_id": "../etc/passwd"},
        headers=headers,
    )
    assert hostile.status_code == 409
    assert media_rt.host_browser_opens == []

    # The genuine owner triggers exactly one host-browser open of the canonical URL.
    good = await media_client.post(
        "/api/media/host-open",
        json={"client_id": "phone_12345678"},
        headers=headers,
    )
    assert good.status_code == 200
    body = good.json()
    assert body["opened"] is True
    assert body["playback_mode"] == "host_browser"
    assert media_rt.host_browser_opens == [f"https://www.youtube.com/watch?v={VIDEO_ID}"]

    # Repeating for the same active video does not open a duplicate tab.
    again = await media_client.post(
        "/api/media/host-open",
        json={"client_id": "phone_12345678"},
        headers=headers,
    )
    assert again.status_code == 200
    assert media_rt.host_browser_opens == [f"https://www.youtube.com/watch?v={VIDEO_ID}"]


@pytest.mark.asyncio
async def test_youtube_key_is_validated_and_only_mask_is_returned(
    media_client, media_rt, monkeypatch
):
    class FakeClient:
        def __init__(self, secret):
            assert secret == "youtube-api-key-12345"

        async def validate_key(self):
            return None

    monkeypatch.setattr(dashboard_module, "YouTubeClient", FakeClient)
    response = await media_client.post(
        "/api/credentials",
        json={"provider": "youtube", "secret": "youtube-api-key-12345"},
        headers={"x-csrf": _csrf(media_client)},
    )
    assert response.status_code == 200
    assert "youtube-api-key-12345" not in response.text
    listing = await media_client.get("/api/credentials")
    assert "youtube-api-key-12345" not in listing.text
    assert len(listing.json()["youtube"]) == 1
    row = await media_rt.db.fetchone(
        "SELECT encrypted_secret FROM credentials WHERE provider='youtube'"
    )
    assert "youtube-api-key-12345" not in str(row["encrypted_secret"])
