"""Tests for AudioEngine voice-focus callback integration.

Verifies that the duck/pause/restore callbacks:
 1. Are called at the correct gate transitions (gate open → duck, session start → pause,
    session end → restore).
 2. Are never called from raw RMS or unverified audio.
 3. Are never called while the assistant is playing.
 4. Are best-effort: failures are swallowed and never propagate.
 5. Restore is called on BOTH explicit session-end and natural session close.
 6. No callbacks fire when they are not injected (default None).

These tests exercise AudioEngine._mic_loop via the helper coroutines
_fire_voice_duck / _fire_voice_pause / _fire_voice_restore directly, and also
test the state-machine integration at the public API level.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from apps.audio.engine import AudioEngine
from apps.audio.mic_gate import PlaybackAwareMicGate
from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.state import ChatState, StateMachine


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_engine(
    *,
    on_voice_duck=None,
    on_voice_pause=None,
    on_voice_restore=None,
) -> AudioEngine:
    """Build a minimal AudioEngine with fake dependencies."""
    settings = MagicMock(spec=Settings)
    settings.voice_enabled = False
    settings.interrupt_rms_threshold = 1000
    settings.low_power = False
    settings.audio_output_route = "speaker"
    settings.mic_device = None
    settings.speaker_device = None
    settings.wake_word_model = None
    settings.wake_threshold = 0.5

    bus = MagicMock(spec=EventBus)
    state = MagicMock(spec=StateMachine)
    state.muted = False
    state.raw_state = ChatState.SLEEPING

    audio_in = asyncio.Queue(maxsize=32)
    audio_out = asyncio.Queue(maxsize=32)

    engine = AudioEngine(
        settings=settings,
        bus=bus,
        state=state,
        audio_in=audio_in,
        audio_out=audio_out,
        on_wake=MagicMock(),
        on_interrupt=MagicMock(),
        on_voice_duck=on_voice_duck,
        on_voice_pause=on_voice_pause,
        on_voice_restore=on_voice_restore,
    )
    return engine


# ── Tests: callback injection ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fire_voice_duck_calls_callback():
    """_fire_voice_duck must call the injected on_voice_duck callback."""
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_duck=cb)
    await engine._fire_voice_duck()
    cb.assert_awaited_once()


@pytest.mark.asyncio
async def test_fire_voice_pause_calls_callback():
    """_fire_voice_pause must call the injected on_voice_pause callback."""
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_pause=cb)
    await engine._fire_voice_pause()
    cb.assert_awaited_once()


@pytest.mark.asyncio
async def test_fire_voice_restore_calls_callback():
    """_fire_voice_restore must call the injected on_voice_restore callback."""
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_restore=cb)
    await engine._fire_voice_restore()
    cb.assert_awaited_once()


@pytest.mark.asyncio
async def test_no_callbacks_when_not_injected():
    """All three fire helpers must be no-ops when callbacks are not injected."""
    engine = _make_engine()  # no callbacks
    # Must not raise
    await engine._fire_voice_duck()
    await engine._fire_voice_pause()
    await engine._fire_voice_restore()


@pytest.mark.asyncio
async def test_fire_voice_duck_swallows_exception():
    """A failing on_voice_duck callback must not propagate to the caller."""
    async def bad():
        raise RuntimeError("duck exploded")
    engine = _make_engine(on_voice_duck=bad)
    # Must not raise
    await engine._fire_voice_duck()


@pytest.mark.asyncio
async def test_fire_voice_pause_swallows_exception():
    """A failing on_voice_pause callback must not propagate."""
    async def bad():
        raise RuntimeError("pause exploded")
    engine = _make_engine(on_voice_pause=bad)
    await engine._fire_voice_pause()


@pytest.mark.asyncio
async def test_fire_voice_restore_swallows_exception():
    """A failing on_voice_restore callback must not propagate."""
    async def bad():
        raise RuntimeError("restore exploded")
    engine = _make_engine(on_voice_restore=bad)
    await engine._fire_voice_restore()


# ── Tests: assistant_playing gate ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fire_voice_duck_skipped_while_assistant_playing():
    """_fire_voice_duck must NOT call the callback while assistant is playing."""
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_duck=cb)
    # Simulate assistant playing.
    engine._media_mic_gate.set_assistant_playing(True)
    await engine._fire_voice_duck()
    cb.assert_not_awaited()


@pytest.mark.asyncio
async def test_fire_voice_pause_skipped_while_assistant_playing():
    """_fire_voice_pause must NOT call the callback while assistant is playing."""
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_pause=cb)
    engine._media_mic_gate.set_assistant_playing(True)
    await engine._fire_voice_pause()
    cb.assert_not_awaited()


@pytest.mark.asyncio
async def test_fire_voice_restore_not_gated_by_assistant():
    """_fire_voice_restore must call the callback regardless of assistant state.

    Restore must fire even if the assistant starts playing immediately after the
    session ends (e.g. Jarvis responds with TTS right away).
    """
    cb = AsyncMock(return_value=True)
    engine = _make_engine(on_voice_restore=cb)
    engine._media_mic_gate.set_assistant_playing(True)
    await engine._fire_voice_restore()
    cb.assert_awaited_once()


# ── Tests: gate transition detection ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_gate_open_transition_detected_correctly():
    """The engine detects is_open False→True transition on the gate object.

    This tests the exact gate condition used in _mic_loop (prev_open vs current).
    No actual audio is fed; we manipulate the gate's internal state directly.
    """
    duck_calls = []

    async def on_duck():
        duck_calls.append(True)

    engine = _make_engine(on_voice_duck=on_duck)
    gate = engine._media_mic_gate

    # Initially closed.
    assert not gate.is_open

    # Simulate the transition: prev_open=False, is_open becomes True.
    gate._open = True   # simulate gate opening
    prev_open = False
    gate_now_open = gate.is_open
    if not prev_open and gate_now_open and not gate.assistant_playing:
        await engine._fire_voice_duck()

    assert len(duck_calls) == 1, "duck must fire on gate open transition"


@pytest.mark.asyncio
async def test_no_duck_on_second_open_same_session():
    """Duck must not be called again if gate is already open (no transition)."""
    duck_calls = []

    async def on_duck():
        duck_calls.append(True)

    engine = _make_engine(on_voice_duck=on_duck)
    gate = engine._media_mic_gate
    gate._open = True

    # Simulate: prev_open=True (already was open), gate is still open.
    prev_open = True
    gate_now_open = gate.is_open
    if not prev_open and gate_now_open and not gate.assistant_playing:
        await engine._fire_voice_duck()

    assert len(duck_calls) == 0, "duck must not fire when gate was already open"


# ── Tests: voice focus on_voice_duck / on_voice_pause / on_voice_restore
#    triggered via companion YouTubeTool integration ──────────────────────────

@pytest.mark.asyncio
async def test_engine_voice_duck_wires_to_youtube_tool(bus, store):
    """When wired to YouTubeTool.voice_focus_duck, the engine callback works end-to-end."""
    from apps.tool_service.youtube_tool import YouTubeTool, YouTubeError

    class FakeCompanion:
        connected = True
        ad_playing = False
        _session = 0
        commands: list[dict] = []

        def bump_session(self):
            self._session += 1
            return self._session

        @property
        def session(self):
            return self._session

        async def send_command(self, action, **args):
            self.commands.append({"action": action, **args})
            return {"ok": True}

    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.status = "playing"
    yt.playback_mode = "browser_companion"

    engine = _make_engine(
        on_voice_duck=yt.voice_focus_duck,
        on_voice_pause=yt.voice_focus_pause,
        on_voice_restore=yt.voice_focus_restore,
    )

    # Firing duck should call yt.voice_focus_duck → send "duck" command.
    await engine._fire_voice_duck()
    assert any(c["action"] == "duck" for c in comp.commands), \
        "duck command must be sent to companion"
    assert yt._voice_ducked is True

    # Firing restore should clear _voice_ducked.
    comp.commands.clear()
    await engine._fire_voice_restore()
    assert any(c["action"] == "restore" for c in comp.commands), \
        "restore command must be sent to companion"
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_engine_voice_pause_wires_to_youtube_tool(bus, store):
    """When wired to YouTubeTool.voice_focus_pause, the engine callback pauses companion."""
    from apps.tool_service.youtube_tool import YouTubeTool

    class FakeCompanion:
        connected = True
        ad_playing = False
        _session = 0
        commands: list[dict] = []

        def bump_session(self):
            self._session += 1
            return self._session

        @property
        def session(self):
            return self._session

        async def send_command(self, action, **args):
            self.commands.append({"action": action, **args})
            return {"ok": True}

    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.status = "playing"
    yt.playback_mode = "browser_companion"

    engine = _make_engine(on_voice_pause=yt.voice_focus_pause)

    await engine._fire_voice_pause()
    assert any(c["action"] == "pause" for c in comp.commands)
    assert yt.status == "paused"


@pytest.mark.asyncio
async def test_engine_voice_restore_noop_when_not_ducked(bus, store):
    """Restore via engine must be a no-op when YouTubeTool._voice_ducked=False."""
    from apps.tool_service.youtube_tool import YouTubeTool

    class FakeCompanion:
        connected = True
        ad_playing = False
        _session = 0
        commands: list[dict] = []

        def bump_session(self):
            self._session += 1
            return self._session

        @property
        def session(self):
            return self._session

        async def send_command(self, action, **args):
            self.commands.append({"action": action, **args})
            return {"ok": True}

    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.status = "playing"
    yt._voice_ducked = False  # not ducked

    engine = _make_engine(on_voice_restore=yt.voice_focus_restore)
    await engine._fire_voice_restore()
    # No restore command should have been sent.
    assert not any(c["action"] == "restore" for c in comp.commands), \
        "restore must be no-op when _voice_ducked=False"
