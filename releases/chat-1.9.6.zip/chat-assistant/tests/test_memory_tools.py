"""Persistent memory + stop tools through the ToolService allowlist."""

from __future__ import annotations

import pytest

from apps.tool_service.service import MAX_MEMORY_CHARS, ToolService
from apps.tool_service.timers import TimerManager


@pytest.fixture
async def tools(db, bus, store):
    timers = TimerManager(db, bus)  # not started; memory tools never touch it
    stopped: list[int] = []
    svc = ToolService(db, bus, timers, store, on_stop=lambda: stopped.append(1))
    svc.test_stopped = stopped
    return svc


async def test_remember_and_recall(tools):
    r = await tools.dispatch("", "remember_fact", {"content": "the wifi password is on the fridge"})
    assert r["remembered"].startswith("the wifi")
    r2 = await tools.dispatch("", "remember_fact", {"content": "I parked on level 3"})
    assert r2["id"] != r["id"]

    out = await tools.dispatch("", "recall_memories", {"query": "parked"})
    assert out["count"] == 1
    assert "level 3" in out["memories"][0]["content"]

    latest = await tools.dispatch("", "recall_memories", {})
    assert latest["count"] == 2  # newest first
    assert latest["memories"][0]["content"] == "I parked on level 3"


async def test_remember_rejects_empty(tools):
    r = await tools.dispatch("", "remember_fact", {"content": "   "})
    assert "error" in r


async def test_remember_truncates_long_content(tools):
    r = await tools.dispatch("", "remember_fact", {"content": "x" * 2000})
    assert len(r["remembered"]) == MAX_MEMORY_CHARS


async def test_forget_by_phrase_and_words(tools):
    await tools.dispatch("", "remember_fact", {"content": "the garage code is 4417"})
    await tools.dispatch("", "remember_fact", {"content": "dentist appointment friday"})

    r = await tools.dispatch("", "forget_memory", {"query": "garage code"})
    assert r["forgotten"] == 1

    # word-based fallback: exact phrase doesn't appear, but all words do
    r2 = await tools.dispatch("", "forget_memory", {"query": "appointment dentist"})
    assert r2["forgotten"] == 1

    left = await tools.dispatch("", "recall_memories", {})
    assert left["count"] == 0


async def test_forget_requires_query(tools):
    r = await tools.dispatch("", "forget_memory", {"query": ""})
    assert "error" in r


async def test_stop_speaking_calls_hook(tools):
    r = await tools.dispatch("", "stop_speaking", {})
    assert r == {"stopped": True}
    assert tools.test_stopped == [1]
    # grammar alias used by the local command path
    r2 = await tools.dispatch("", "stop_output", {})
    assert r2 == {"stopped": True}
    assert tools.test_stopped == [1, 1]
