"""Low-power wake inference keeps reliability while reducing call cadence."""

from __future__ import annotations

import asyncio

from apps.audio.engine import AudioEngine, CHUNK
from chat_core.models.state import StateMachine


def _engine(settings, bus) -> AudioEngine:
    return AudioEngine(
        settings,
        bus,
        StateMachine(bus),
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        on_wake=lambda: None,
        on_interrupt=lambda: None,
    )


def test_low_power_combines_two_80ms_frames(settings, bus):
    settings.low_power = True
    engine = _engine(settings, bus)
    first = b"a" * (CHUNK * 2)   # PCM16: two bytes per sample
    second = b"b" * (CHUNK * 2)

    assert engine._prepare_wake_input(first) is None
    assert engine._prepare_wake_input(second) == first + second
    assert engine._wake_batch == []


def test_normal_profile_keeps_original_80ms_cadence(settings, bus):
    settings.low_power = False
    engine = _engine(settings, bus)
    chunk = b"x" * (CHUNK * 2)

    assert engine._prepare_wake_input(chunk) == chunk
    assert engine._wake_batch == []


def test_switching_profile_discards_partial_sleeping_audio(settings, bus):
    settings.low_power = True
    engine = _engine(settings, bus)
    stale = b"s" * (CHUNK * 2)
    current = b"c" * (CHUNK * 2)

    assert engine._prepare_wake_input(stale) is None
    settings.low_power = False

    assert engine._prepare_wake_input(current) == current
    assert engine._wake_batch == []
