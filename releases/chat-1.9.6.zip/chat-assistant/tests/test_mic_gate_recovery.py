"""The microphone must recover as soon as playback stops making sound.

Regression cover for a real failure: with music playing, the gate learned a
high noise floor.  When the song was muted (or ducked, or paused at the
source), the floor stayed high, so ordinary speech never cleared the bar and
Chat behaved as if it could not hear the user at all.
"""

from __future__ import annotations

import math
import struct

import pytest

from apps.audio.mic_gate import PlaybackAwareMicGate

SAMPLE_RATE = 16_000
CHUNK_SECONDS = 0.02
CHUNK_SAMPLES = int(SAMPLE_RATE * CHUNK_SECONDS)
THRESHOLD = 900.0


def tone(level: float, samples: int = CHUNK_SAMPLES) -> bytes:
    """PCM16 chunk whose RMS is approximately ``level``."""
    if level <= 0:
        return b"\x00\x00" * samples
    amplitude = level * math.sqrt(2.0)
    return b"".join(
        struct.pack(
            "<h",
            max(-32768, min(32767, int(amplitude * math.sin(2 * math.pi * 440 * n / SAMPLE_RATE)))),
        )
        for n in range(samples)
    )


def gate() -> PlaybackAwareMicGate:
    return PlaybackAwareMicGate(THRESHOLD, sample_rate=SAMPLE_RATE)


def feed_for(g: PlaybackAwareMicGate, level: float, seconds: float) -> int:
    """Feed ``seconds`` of audio at ``level``; return frames forwarded."""
    forwarded = 0
    for _ in range(int(seconds / CHUNK_SECONDS)):
        forwarded += len(g.feed(tone(level)))
    return forwarded


def test_sustained_music_still_holds_the_gate_shut():
    """The point of the gate: lyrics must not be mistaken for the user."""
    g = gate()
    g.set_media_playing(True)
    assert feed_for(g, 2500.0, 3.0) == 0
    assert not g.is_open


def test_talking_under_the_bar_barely_moves_it():
    """Half-heard speech must not ratchet Chat into deafness.

    The floor rises slowly on purpose: someone talking for a second while
    music plays used to push the bar up fast, so every following word needed
    to be louder than the last.
    """
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 1500.0, 2.0)
    bar_before = g.speech_bar()
    feed_for(g, 1800.0, 1.0)          # user's voice, still under the bar
    assert g.speech_bar() < bar_before * 1.25


def test_the_bar_returns_to_baseline_after_the_room_goes_quiet():
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 2000.0, 3.0)
    feed_for(g, 30.0, 1.0)
    assert g.speech_bar() == pytest.approx(THRESHOLD, rel=0.05)


def test_speech_is_heard_again_shortly_after_the_song_is_muted():
    """The exact user-reported bug: mute the song, then talk."""
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 1500.0, 4.0)          # music leaking in; floor climbs

    # Song muted at the source. Chat is not told (host-browser playback), so
    # media_playing stays True; the room simply goes quiet.
    feed_for(g, 30.0, 1.0)

    forwarded = feed_for(g, 2200.0, 0.6)   # normal speaking voice
    assert forwarded > 0, "speech after muting the song must reach Chat"
    assert g.is_open


def test_quiet_room_recovery_is_fast_not_minutes():
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 1500.0, 3.0)
    high = g._noise_floor
    feed_for(g, 30.0, 0.8)
    assert g._noise_floor < high * 0.5, "the learned floor must collapse quickly"


def test_single_quiet_beat_does_not_collapse_the_floor():
    """A short gap inside a song must not disarm playback protection."""
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 1500.0, 3.0)
    before = g._noise_floor
    feed_for(g, 30.0, 0.10)           # shorter than quiet_collapse_seconds
    assert g._noise_floor > before * 0.8


def test_assistant_playback_keeps_the_strict_bar():
    """Feedback protection for Chat's own voice must not be relaxed."""
    g = gate()
    g.set_assistant_playing(True)
    assert feed_for(g, 2500.0, 3.0) == 0
    assert g.speech_bar() > THRESHOLD * 2


def test_muted_media_reported_as_inaudible_passes_audio_straight_through():
    g = gate()
    g.set_media_playing(True)
    feed_for(g, 6000.0, 1.0)
    g.set_media_playing(False)        # what YouTubeTool now reports on mute
    assert g.feed(tone(300.0)) == (tone(300.0),)
