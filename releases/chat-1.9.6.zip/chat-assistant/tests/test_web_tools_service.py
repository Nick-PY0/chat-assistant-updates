from __future__ import annotations

from datetime import datetime

import pytest

from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from apps.tool_service.web_tool import WebResearchTool


class FakeWeb:
    def current_time(self):
        return {"local_time": "10:45 PM", "timezone": "PDT"}

    async def search(self, query, max_results=5):
        return {"query": query, "max_results": max_results, "results": []}

    async def news(self, query="", max_results=6):
        return {"query": query or "top headlines", "max_results": max_results, "results": []}


@pytest.mark.asyncio
async def test_allowlisted_time_search_and_news_dispatch(db, bus, store):
    service = ToolService(db, bus, TimerManager(db, bus), store, web=FakeWeb())
    assert await service.dispatch("", "get_current_time", {}) == {
        "local_time": "10:45 PM", "timezone": "PDT"
    }
    assert (await service.dispatch("", "search_web", {
        "query": "space weather", "max_results": 3
    }))["max_results"] == 3
    assert (await service.dispatch("", "get_latest_news", {}))["query"] == "top headlines"


def test_web_tool_schemas_are_exposed_to_every_brain():
    names = {declaration["name"] for declaration in TOOL_DECLARATIONS}
    assert {"get_current_time", "search_web", "get_latest_news"} <= names


def test_current_time_reports_an_aware_live_clock():
    result = WebResearchTool.current_time()
    parsed = datetime.fromisoformat(result["iso"])
    assert parsed.tzinfo is not None
    assert result["local_time"]
    assert result["local_date"]
