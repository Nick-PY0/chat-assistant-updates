"""Clock-time reminders/alarms: time resolution, persistence, cancelling."""

import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from apps.tool_service.reminders import (
    ReminderError,
    ReminderManager,
    resolve_fire_time,
)
from chat_core.models.credentials import iso, utcnow

TZ = timezone(timedelta(hours=-4))  # a fixed local zone for deterministic tests


def at(h, m=0):
    return datetime(2026, 8, 18, h, m, tzinfo=TZ)


# ---- resolve_fire_time -------------------------------------------------


def test_bare_hour_picks_next_occurrence():
    # "at 5" said at 2 pm -> 5 pm today
    assert resolve_fire_time(5, now=at(14)) == at(17)
    # "at 5" said at 6 pm -> 5 am tomorrow
    assert resolve_fire_time(5, now=at(18)) == at(5) + timedelta(days=1)
    # 24h hour is taken literally
    assert resolve_fire_time(14, now=at(10)) == at(14)


def test_am_pm_is_respected():
    assert resolve_fire_time(7, 0, "pm", now=at(14)) == at(19)
    # 7 am already passed -> tomorrow morning
    assert resolve_fire_time(7, 0, "am", now=at(14)) == at(7) + timedelta(days=1)
    # 12 am is midnight, 12 pm is noon
    assert resolve_fire_time(12, 0, "am", now=at(14)) == at(0) + timedelta(days=1)
    assert resolve_fire_time(12, 0, "pm", now=at(14)) == at(12) + timedelta(days=1)


def test_tonight_prefers_evening():
    assert resolve_fire_time(9, day="tonight", now=at(10)) == at(21)
    with pytest.raises(ReminderError):
        resolve_fire_time(9, day="tonight", now=at(22))  # 9 pm already passed


def test_explicit_day_takes_morning_reading():
    tomorrow = at(5) + timedelta(days=1)
    assert resolve_fire_time(5, day="tomorrow", now=at(14)) == tomorrow
    assert resolve_fire_time(8, day="2026-12-25", now=at(14)) == datetime(
        2026, 12, 25, 8, 0, tzinfo=TZ
    )


def test_bad_input_rejected():
    with pytest.raises(ReminderError):
        resolve_fire_time("banana", now=at(10))
    with pytest.raises(ReminderError):
        resolve_fire_time(30, now=at(10))
    with pytest.raises(ReminderError):
        resolve_fire_time(7, 75, now=at(10))
    with pytest.raises(ReminderError):
        resolve_fire_time(0, 0, "pm", now=at(10))  # am/pm hour must be 1-12
    with pytest.raises(ReminderError):
        resolve_fire_time(8, day="2020-01-01", now=at(10))  # past date
    with pytest.raises(ReminderError):
        resolve_fire_time(9, day="today", now=at(22))  # explicitly today, passed


# ---- manager -----------------------------------------------------------


async def test_set_and_list(db, bus):
    rm = ReminderManager(db, bus)
    r = await rm.set_reminder(message="x" * 300, hour=23, minute=59)
    assert r["id"].startswith("r_")
    assert len(r["message"]) == 200  # capped
    assert r["when"]  # human label like "today 23:59"

    rows = await rm.list_reminders()
    assert len(rows) == 1 and rows[0]["status"] == "scheduled"


async def test_dashboard_at_local(db, bus):
    rm = ReminderManager(db, bus)
    future = (datetime.now().astimezone() + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M")
    r = await rm.set_reminder(message="dentist", kind="alarm", at_local=future)
    assert r["kind"] == "alarm"
    with pytest.raises(ReminderError):
        await rm.set_reminder(message="x", at_local="2020-01-01T08:00")
    with pytest.raises(ReminderError):
        await rm.set_reminder(message="x", at_local="not-a-date")
    with pytest.raises(ReminderError):
        await rm.set_reminder(message="no time given")


async def test_reminder_fires(db, bus):
    rm = ReminderManager(db, bus)
    fired = bus.subscribe("reminder_fired")
    await rm.start()
    try:
        soon = (datetime.now().astimezone() + timedelta(seconds=1)).strftime(
            "%Y-%m-%dT%H:%M:%S"
        )
        await rm.set_reminder(message="tea", at_local=soon)
        ev = await asyncio.wait_for(fired.get(), timeout=8)
        assert ev.data["message"] == "tea"
        assert await rm.list_reminders() == []
        recent = await rm.list_reminders(include_recent=True)
        assert recent and recent[0]["status"] == "fired"
    finally:
        await rm.stop()


async def test_missed_while_off(db, bus):
    await db.execute(
        "INSERT INTO reminders (id, message, kind, fires_at, status, created_at) "
        "VALUES ('r_old', 'pills', 'reminder', ?, 'scheduled', ?)",
        (iso(utcnow() - timedelta(minutes=30)), iso(utcnow() - timedelta(hours=1))),
    )
    missed = bus.subscribe("reminder_missed")
    rm = ReminderManager(db, bus)
    await rm.start()
    try:
        ev = missed.get_nowait()
        assert ev.data["message"] == "pills"
        row = await db.fetchone("SELECT status FROM reminders WHERE id='r_old'")
        assert row["status"] == "missed"
    finally:
        await rm.stop()


async def test_cancel_disambiguation(db, bus):
    rm = ReminderManager(db, bus)
    with pytest.raises(ReminderError):
        await rm.cancel_reminder("")  # nothing scheduled

    a = await rm.set_reminder(message="take out chicken", hour=23, minute=58)
    await rm.set_reminder(message="", hour=23, minute=59, kind="alarm")

    with pytest.raises(ReminderError):
        await rm.cancel_reminder("")  # two scheduled, ambiguous

    got = await rm.cancel_reminder("alarm")  # kind word
    assert got["kind"] == "alarm" and got["status"] == "cancelled"

    got = await rm.cancel_reminder("chicken")  # message fragment
    assert got["id"] == a["id"]

    b = await rm.set_reminder(message="stretch", hour=23, minute=57)
    got = await rm.cancel_reminder(b["id"])  # exact id
    assert got["id"] == b["id"]

    c = await rm.set_reminder(message="solo", hour=23, minute=56)
    got = await rm.cancel_reminder("")  # single scheduled -> no ambiguity
    assert got["id"] == c["id"]


async def test_persistence_across_instances(db, bus):
    rm1 = ReminderManager(db, bus)
    await rm1.set_reminder(message="water plants", hour=23, minute=59)
    rm2 = ReminderManager(db, bus)
    rows = await rm2.list_reminders()
    assert len(rows) == 1 and rows[0]["message"] == "water plants"


async def test_conditional_updates_are_atomic_claims(db, bus):
    """Fire and cancel both claim the row with a conditional UPDATE; only
    one side can win, so a just-cancelled reminder never rings and a
    just-fired one cannot be overwritten as cancelled."""
    rm = ReminderManager(db, bus)
    r = await rm.set_reminder(message="x", hour=23, minute=59)
    won = await db.execute(
        "UPDATE reminders SET status='fired' WHERE id=? AND status='scheduled'",
        (r["id"],),
    )
    lost = await db.execute(
        "UPDATE reminders SET status='cancelled' WHERE id=? AND status='scheduled'",
        (r["id"],),
    )
    assert won == 1 and lost == 0


async def test_cancel_loses_race_to_fire(db, bus):
    """If the scheduler fires a reminder between cancel's SELECT and its
    UPDATE, cancel must report it instead of silently un-firing the row."""
    rm = ReminderManager(db, bus)
    r = await rm.set_reminder(message="tea", hour=23, minute=59)
    real_fetchone = db.fetchone

    async def stale_fetchone(sql, params=()):
        row = await real_fetchone(sql, params)
        if row is not None and "FROM reminders" in sql:
            await db.execute(
                "UPDATE reminders SET status='fired' WHERE id=? AND status='scheduled'",
                (row["id"],),
            )
        return row

    db.fetchone = stale_fetchone
    try:
        with pytest.raises(ReminderError):
            await rm.cancel_reminder(r["id"])
    finally:
        db.fetchone = real_fetchone
