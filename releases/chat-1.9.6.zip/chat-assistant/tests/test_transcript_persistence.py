"""Regression tests: transcript rows written to the DB for all three providers.

Tests use fake WebSocket / relay servers so no external network call is made.
Each test opens a voice session, runs a provider session with transcript events,
then queries the transcripts table to confirm rows were persisted.
"""

from __future__ import annotations

import asyncio
import base64
import json

import pytest
import websockets
import websockets.server

from integrations.gemini.live_client import LiveSession
from integrations.openai_rt.live_client import RealtimeSession
from apps.live_gateway.relay_session import RelayVoiceSession
from chat_core.models.db import Database
from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.state import StateMachine


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

async def _start_ws_server(handler):
    """Spin up a localhost WebSocket server for one test. Returns (server, url)."""
    server = await websockets.server.serve(handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    return server, f"ws://127.0.0.1:{port}"


async def _transcript_rows(db: Database, session_id: str) -> list[dict]:
    rows = await db.fetchall(
        "SELECT role, text FROM transcripts WHERE session_id=? ORDER BY id",
        (session_id,),
    )
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Gemini Live transcript persistence
# ---------------------------------------------------------------------------

async def test_gemini_transcripts_persisted(db: Database):
    """inputTranscription / outputTranscription events write rows to DB."""

    async def fake_gemini(ws):
        # Wait for setup message, send setupComplete
        await ws.recv()
        await ws.send(json.dumps({"setupComplete": {}}))
        # Send input transcription (user speech)
        await ws.send(json.dumps({
            "serverContent": {
                "inputTranscription": {"text": "What time is it?"},
            }
        }))
        # Send output transcription (model speech)
        await ws.send(json.dumps({
            "serverContent": {
                "outputTranscription": {"text": "It is three o'clock."},
            }
        }))
        # Close cleanly
        await ws.close(1000, "done")

    server, url = await _start_ws_server(fake_gemini)
    session_id = "gemini-test-001"
    await db.open_voice_session(session_id, "gemini", None)

    session = LiveSession(
        api_key="test-key",
        model="models/test",
        system_prompt="be helpful",
        tool_declarations=[],
        tool_handler=lambda *_: {},
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
    )
    # Wire transcript callbacks (mirrors what the gateway does).
    session.on_input_transcript = lambda t: asyncio.ensure_future(
        db.add_transcript(session_id, "user", t))
    session.on_output_transcript = lambda t: asyncio.ensure_future(
        db.add_transcript(session_id, "assistant", t))

    # Patch the URL so it hits our fake server.
    import integrations.gemini.live_client as _glc
    orig_host, orig_path = _glc.HOST, _glc.PATH
    _glc.HOST = "127.0.0.1"
    _glc.PATH = f"/{url.split('/', 3)[-1]}"
    # Override URL construction: monkey-patch run() to use plain ws:// directly
    # by redirecting host/path.  Easier: just call _receiver directly.
    _glc.HOST, _glc.PATH = orig_host, orig_path
    server.close()
    await server.wait_closed()

    # Instead of monkey-patching the URL, drive the _receiver directly via a
    # fake socket that yields the same messages.
    class FakeSocket:
        def __init__(self, messages):
            self._msgs = iter(messages)

        def __aiter__(self):
            return self

        async def __anext__(self):
            try:
                return next(self._msgs)
            except StopIteration:
                raise StopAsyncIteration

    msgs = [
        json.dumps({"serverContent": {"inputTranscription": {"text": "What time is it?"}}}),
        json.dumps({"serverContent": {"outputTranscription": {"text": "It is three o'clock."}}}),
    ]
    await session._receiver(FakeSocket(msgs))
    # Give ensure_future tasks (including the serialized DB lock) time to run.
    await asyncio.sleep(0.05)

    rows = await _transcript_rows(db, session_id)
    assert len(rows) == 2
    assert rows[0] == {"role": "user", "text": "What time is it?"}
    assert rows[1] == {"role": "assistant", "text": "It is three o'clock."}


# ---------------------------------------------------------------------------
# OpenAI Realtime transcript persistence
# ---------------------------------------------------------------------------

async def _start_openai_fake(handler):
    server = await websockets.server.serve(handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    return server, f"ws://127.0.0.1:{port}"


async def test_openai_rt_transcripts_persisted(db: Database):
    """conversation.item.input_audio_transcription.completed and
    response.audio_transcript.done events persist rows to DB."""

    async def fake_openai(ws):
        try:
            await ws.recv()  # session.update
            await ws.send(json.dumps({"type": "session.created"}))
            await ws.send(json.dumps({
                "type": "conversation.item.input_audio_transcription.completed",
                "transcript": "Turn off the lights",
            }))
            await ws.send(json.dumps({
                "type": "response.audio_transcript.done",
                "transcript": "Turning off the lights now.",
            }))
            await ws.close(1000, "done")
        except websockets.exceptions.ConnectionClosed:
            pass

    server, url = await _start_openai_fake(fake_openai)
    session_id = "openai-test-001"
    await db.open_voice_session(session_id, "openai_live", None)

    async def _tool_handler(*_):
        return {}

    session = RealtimeSession(
        api_key="sk-test",
        model="gpt-realtime",
        system_prompt="be brief",
        tool_declarations=[],
        tool_handler=_tool_handler,
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        url=url,
    )
    session.on_input_transcript = lambda t: asyncio.ensure_future(
        db.add_transcript(session_id, "user", t))
    session.on_output_transcript = lambda t: asyncio.ensure_future(
        db.add_transcript(session_id, "assistant", t))

    try:
        await asyncio.wait_for(session.run(), timeout=5)
    except Exception:
        pass
    finally:
        server.close()
        await server.wait_closed()

    await asyncio.sleep(0.05)

    rows = await _transcript_rows(db, session_id)
    assert len(rows) == 2, f"expected 2 rows, got: {rows}"
    assert rows[0] == {"role": "user", "text": "Turn off the lights"}
    assert rows[1] == {"role": "assistant", "text": "Turning off the lights now."}


# ---------------------------------------------------------------------------
# Relay session transcript persistence
# ---------------------------------------------------------------------------

async def _dummy_relay_tool(*_):
    return {}


class _FakeRelayClient:
    """Minimal relay stub: transcribes and replies with canned text."""

    async def health(self):
        pass

    async def transcribe(self, pcm: bytes) -> str:
        return "Set a five minute timer"

    async def ask(self, messages, tools, model) -> dict:
        return {
            "reply": "Timer started.",
            "tool_calls": [],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            "model": model,
        }

    async def speak(self, text: str, voice: str) -> tuple[bytes, int]:
        # Return minimal silent PCM at 24 kHz so playback completes quickly.
        return b"\x00\x00" * 240, 24000


async def test_relay_transcripts_persisted(db: Database, settings: Settings, bus: EventBus):
    """Relay transcribes user speech and model reply; both must appear in DB."""
    state = StateMachine(bus)
    session_id = "relay-test-001"
    await db.open_voice_session(session_id, "relay", None)

    audio_in: asyncio.Queue = asyncio.Queue()
    audio_out: asyncio.Queue = asyncio.Queue()
    settings.inactivity_timeout_seconds = 5
    settings.interrupt_rms_threshold = 100
    settings.speech_pause_ms = 800  # keep test fast: pause_chunks = ceil(0.8/0.08)=10

    # Feed enough loud audio followed by silence to trigger one full utterance.
    # With speech_pause_ms=800: pause_chunks = max(10, ceil(0.8/0.08)) = 10
    loud_chunk = (2000).to_bytes(2, "little", signed=True) * 1280
    silent_chunk = b"\x00\x00" * 1280
    for _ in range(12):  # loud speech frames > 8 (long_enough)
        audio_in.put_nowait(loud_chunk)
    for _ in range(12):  # silence frames >= pause_chunks (10)
        audio_in.put_nowait(silent_chunk)

    session = RelayVoiceSession(
        client=_FakeRelayClient(),
        settings=settings,
        db=db,
        bus=bus,
        state=state,
        tool_declarations=[],
        tool_handler=_dummy_relay_tool,
        audio_in=audio_in,
        audio_out=audio_out,
        session_id=session_id,
        inactivity_timeout=3.0,
    )

    async def _stop_after():
        await asyncio.sleep(0.8)
        await session.close("stopped")

    await asyncio.gather(
        asyncio.wait_for(session.run(), timeout=5),
        _stop_after(),
        return_exceptions=True,
    )

    rows = await _transcript_rows(db, session_id)
    # At minimum we should see user text; assistant text may arrive if think() completed.
    assert any(r["role"] == "user" and "timer" in r["text"].lower() for r in rows), (
        f"Expected user transcript row; got: {rows}"
    )
    assert any(r["role"] == "assistant" for r in rows), (
        f"Expected assistant transcript row; got: {rows}"
    )
