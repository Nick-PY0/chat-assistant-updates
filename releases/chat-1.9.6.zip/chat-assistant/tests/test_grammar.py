from apps.tool_service.local_grammar import parse, words_to_number


def test_words_to_number():
    assert words_to_number("ten") == 10
    assert words_to_number("twenty five") == 25
    assert words_to_number("45") == 45
    assert words_to_number("a") == 1
    assert words_to_number("banana") is None


def test_timer_phrases():
    cmd = parse("Chat, set a timer for ten minutes")
    assert cmd == {"tool": "start_timer", "args": {"duration_seconds": 600, "label": ""}}

    cmd = parse("start a pasta timer for 8 minutes")
    assert cmd["tool"] == "start_timer"
    assert cmd["args"]["duration_seconds"] == 480
    assert cmd["args"]["label"] == "pasta"

    cmd = parse("set a timer for one hour")
    assert cmd["args"]["duration_seconds"] == 3600

    assert parse("list my timers") == {"tool": "list_timers", "args": {}}

    cmd = parse("cancel the pasta timer")
    assert cmd == {"tool": "cancel_timer", "args": {"timer_id": "pasta"}}


def test_light_phrases():
    cmd = parse("turn off the bedroom light")
    assert cmd == {"tool": "set_govee_power", "args": {"device": "bedroom", "state": "off"}}

    cmd = parse("hey chat turn the desk light on")
    assert cmd == {"tool": "set_govee_power", "args": {"device": "desk", "state": "on"}}

    cmd = parse("set the desk light to fifty percent")
    assert cmd == {"tool": "set_govee_brightness", "args": {"device": "desk", "percentage": 50}}


def test_out_of_grammar_is_rejected():
    # NOTE: "play some music" now maps to play_youtube (YouTube search) by design.
    # Verify it resolves to play_youtube rather than returning None.
    result = parse("play some music")
    assert result is not None and result["tool"] == "play_youtube"
    assert parse("delete all my files") is None
    assert parse("set a timer for banana minutes") is None
