"""YouTubeTool companion (browser_companion) playback-mode integration.

Verifies: a connected companion becomes the primary media owner using canonical
protocol action names; validated play/playlist/pause/seek/volume/mute route to
it; ad_playing blocks actions; the embedded fallback is preserved when no
companion is connected; volume/mute require the companion; voice-focus
duck/pause/restore track Jarvis-initiated state separately.
"""

from __future__ import annotations

import pytest

from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from apps.tool_service.youtube_tool import YouTubeError, YouTubeTool
from apps.tool_service.local_grammar import parse
from apps.tool_service.schemas import TOOL_DECLARATIONS


VIDEO_A = "dQw4w9WgXcQ"
PLAYLIST_A = "PLabcdefghij123456"


class FakeCompanion:
    """A connected companion double recording commands and acking them ok."""

    TARGET_ID = "browser_companion"

    def __init__(self, connected: bool = True) -> None:
        self.connected = connected
        self.commands: list[dict] = []
        self._session = 0
        self.ack_ok = True
        self.ack_error = ""
        self.ad_playing = False

    def bump_session(self) -> int:
        self._session += 1
        return self._session

    @property
    def session(self) -> int:
        return self._session

    async def send_command(self, action, **args):
        # Simulate the server-strict ad gate: EVERY companion action is
        # rejected with busy_ad while an ad is playing (matches the real
        # CompanionBridge whose _AD_BLOCKED_ACTIONS == ALL_COMPANION_ACTIONS).
        if self.ad_playing:
            return {"ok": False, "error": "busy_ad"}
        self.commands.append({"action": action, **args})
        return {"ok": self.ack_ok, "error": self.ack_error}


class GatedCompanion(FakeCompanion):
    """A companion whose send_command blocks on a per-action asyncio.Event.

    Lets a test deterministically interleave a slow voice op with a fast
    explicit command: the voice op's send_command awaits the release event
    while the test runs the explicit command to completion, then releases.
    """

    def __init__(self, connected: bool = True) -> None:
        super().__init__(connected)
        self._release = __import__("asyncio").Event()
        self._entered = __import__("asyncio").Event()
        self.gate_actions: set[str] = set()

    async def send_command(self, action, **args):
        if self.ad_playing:
            return {"ok": False, "error": "busy_ad"}
        if action in self.gate_actions:
            self._entered.set()
            await self._release.wait()
        self.commands.append({"action": action, **args})
        return {"ok": self.ack_ok, "error": self.ack_error}

    async def wait_entered(self):
        await self._entered.wait()

    def release(self):
        self._release.set()


# ---------------------------------------------------------------------------
# Canonical command names
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_companion_play_uses_navigate_video(bus, store):
    opened: list[str] = []
    yt = YouTubeTool(bus, store, open_browser=opened.append)
    comp = FakeCompanion()
    yt.register_companion(comp)

    result = await yt.play(VIDEO_A)
    # No host browser opened: the companion owns playback.
    assert opened == []
    assert result["playback_mode"] == "browser_companion"
    assert result["started"] is True
    # Canonical action per common.js COMPANION_ACTIONS: "navigate_video"
    assert comp.commands[0]["action"] == "navigate_video"
    assert comp.commands[0]["video_id"] == VIDEO_A
    assert "url" not in comp.commands[0]
    assert yt.snapshot()["playback_mode"] == "browser_companion"
    assert yt.snapshot()["companion_connected"] is True


def test_companion_play_uses_navigate_video_matches_js_constant():
    """The action sent for video navigation must match CMD_NAVIGATE_VIDEO."""
    from apps.tool_service.companion_bridge import CMD_NAVIGATE_VIDEO
    assert CMD_NAVIGATE_VIDEO == "navigate_video"


@pytest.mark.asyncio
async def test_companion_playlist_uses_navigate_playlist(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    result = await yt.play_playlist(playlist_id=PLAYLIST_A)
    assert result["playback_mode"] == "browser_companion"
    # Canonical action: navigate_playlist
    assert comp.commands[0]["action"] == "navigate_playlist"
    assert comp.commands[0]["playlist_id"] == PLAYLIST_A


@pytest.mark.asyncio
async def test_companion_play_url_sends_only_validated_id(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    result = await yt.play_url(f"https://www.youtube.com/watch?v={VIDEO_A}")
    assert result["playback_mode"] == "browser_companion"
    assert comp.commands[0]["action"] == "navigate_video"
    assert comp.commands[0]["video_id"] == VIDEO_A


@pytest.mark.asyncio
async def test_restart_uses_canonical_restart_action(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    comp.commands.clear()
    restarted = await yt.restart_media()
    # Must use canonical "restart" action, not "seek"
    assert comp.commands[-1]["action"] == "restart"
    assert yt.position_seconds == 0.0


# ---------------------------------------------------------------------------
# Embedded / host-browser fallback preserved when no companion is connected
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_no_companion_falls_back_to_host_browser(bus, store):
    opened: list[str] = []
    yt = YouTubeTool(bus, store, open_browser=opened.append)
    yt.register_companion(FakeCompanion(connected=False))
    result = await yt.play(VIDEO_A)
    assert result["playback_mode"] == "host_browser"
    assert opened == [f"https://www.youtube.com/watch?v={VIDEO_A}"]


# ---------------------------------------------------------------------------
# Transport controls route to the companion
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_companion_pause_stop_seek(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    comp.commands.clear()

    paused = await yt.pause_media()
    assert paused["status"] == "paused"
    assert comp.commands[-1]["action"] == "pause"

    yt.status = "playing"
    yt.position_seconds = 100.0
    seeked = await yt.seek_media(-30)
    assert comp.commands[-1]["action"] == "seek"
    assert yt.position_seconds == 70.0

    stopped = await yt.stop_media()
    assert comp.commands[-1]["action"] == "stop"
    assert yt.status == "stopped"


# ---------------------------------------------------------------------------
# Ad-playing blocks commands and tool reports ad state
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ad_playing_blocks_navigate(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    comp.ad_playing = True
    yt.register_companion(comp)
    # Simulate companion already playing (ad_playing set via state ingest)
    yt._ingest_companion_state({
        "status": "playing", "session": 0, "target": "browser_companion",
        "ad_playing": True,
    })
    assert yt.ad_playing is True
    # Navigate_video should raise YouTubeError because companion returns busy_ad
    with pytest.raises(YouTubeError, match="ad"):
        await yt.play(VIDEO_A)


@pytest.mark.asyncio
async def test_ad_state_reported_in_snapshot(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt._ingest_companion_state({
        "status": "playing", "session": 0, "target": "browser_companion",
        "ad_playing": True,
    })
    snap = yt.snapshot()
    assert snap["ad_playing"] is True


@pytest.mark.asyncio
async def test_ad_clears_when_state_reports_false(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt._ingest_companion_state({
        "status": "playing", "session": 0, "target": "browser_companion",
        "ad_playing": True,
    })
    yt._ingest_companion_state({
        "status": "playing", "session": 0, "target": "browser_companion",
        "ad_playing": False,
    })
    assert yt.ad_playing is False


def test_ad_playing_true_alongside_valid_status_ingested(bus, store):
    """ad_playing=True with a valid status must update both fields.

    The bridge never drops a frame because ad_playing=True; the status
    (paused/stopped/buffering/etc.) is still valid and must be applied.
    """
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    # Set up companion mode first.
    yt.playback_mode = "browser_companion"
    yt.video_id = VIDEO_A
    yt.media_kind = "video"
    # State frame: ad playing but status is "stopped" (valid combination).
    yt._ingest_companion_state({
        "status": "stopped", "session": 0,
        "ad_playing": True, "video_id": VIDEO_A,
    })
    assert yt.ad_playing is True
    assert yt.status == "stopped"


def test_ad_playing_false_alongside_playing_status_ingested(bus, store):
    """ad_playing=False with status=playing must set both normally."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.video_id = VIDEO_A
    yt.media_kind = "video"
    yt._ingest_companion_state({
        "status": "playing", "session": 0,
        "ad_playing": False, "video_id": VIDEO_A,
    })
    assert yt.ad_playing is False
    assert yt.status == "playing"


# ---------------------------------------------------------------------------
# Media fencing in _ingest_companion_state
# ---------------------------------------------------------------------------

def test_wrong_video_id_in_state_is_no_op_for_status(bus, store):
    """A state frame reporting a different video_id must be a full no-op for status.

    Ad state is still extracted (safety signal), but status and position
    must not be mutated when the video id doesn't match.
    """
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.video_id = VIDEO_A
    yt.media_kind = "video"
    yt.status = "playing"
    yt.position_seconds = 30.0

    # State reports a DIFFERENT video id.
    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        "video_id": "jNQXAC9IVRw",   # different 11-char id
        "position_seconds": 99.0,
        "ad_playing": False,
    })
    # Status and position must not have changed.
    assert yt.status == "playing"
    assert yt.position_seconds == 30.0


def test_missing_video_id_in_state_is_no_op_when_video_tracked(bus, store):
    """If the server has a video_id but the state frame omits it, it's a no-op."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.video_id = VIDEO_A
    yt.media_kind = "video"
    yt.status = "playing"

    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        # No video_id supplied.
        "ad_playing": False,
    })
    assert yt.status == "playing"  # no-op


def test_correct_video_id_in_state_is_applied(bus, store):
    """A state frame with the correct video_id must be applied normally."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.video_id = VIDEO_A
    yt.media_kind = "video"
    yt.status = "playing"
    yt.position_seconds = 0.0

    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        "video_id": VIDEO_A,   # correct match
        "position_seconds": 42.0,
        "ad_playing": False,
    })
    assert yt.status == "paused"
    assert yt.position_seconds == 42.0


def test_wrong_playlist_id_in_state_is_no_op(bus, store):
    """A state frame with a different playlist_id must be a no-op for status."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.playlist_id = PLAYLIST_A
    yt.media_kind = "playlist"
    yt.status = "playing"

    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        "playlist_id": "PLwrongwrongwrongwrongwrongwrong1",  # different
        "ad_playing": False,
    })
    assert yt.status == "playing"  # no-op


def test_missing_playlist_id_in_state_is_no_op_when_playlist_tracked(bus, store):
    """If server has a playlist but state frame omits playlist_id, it's a no-op."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.playlist_id = PLAYLIST_A
    yt.media_kind = "playlist"
    yt.status = "playing"

    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        "ad_playing": False,
        # No playlist_id.
    })
    assert yt.status == "playing"


def test_correct_playlist_id_in_state_applied(bus, store):
    """A state frame with the correct playlist_id must be applied."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.playlist_id = PLAYLIST_A
    yt.media_kind = "playlist"
    yt.status = "playing"

    yt._ingest_companion_state({
        "status": "paused", "session": 0,
        "playlist_id": PLAYLIST_A,
        "ad_playing": False,
    })
    assert yt.status == "paused"


def test_state_accepted_without_fencing_when_no_video_tracked(bus, store):
    """When playback_mode is browser_companion but no video_id is tracked yet,
    state frames are accepted (early state flow-in before the first play ack)."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    yt.playback_mode = "browser_companion"
    yt.video_id = ""  # no id tracked yet
    yt.media_kind = "video"
    yt.status = "stopped"

    yt._ingest_companion_state({
        "status": "playing", "session": 0,
        "video_id": VIDEO_A,
        "ad_playing": False,
    })
    assert yt.status == "playing"


# ---------------------------------------------------------------------------
# Volume / mute require the companion; give a clear message otherwise
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_volume_and_mute_route_to_companion(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    comp.commands.clear()

    await yt.set_volume(30)
    assert comp.commands[-1] == {"action": "set_volume", "volume": 30}
    assert yt.volume == 30

    await yt.adjust_volume(15)
    assert comp.commands[-1]["volume"] == 45
    assert yt.volume == 45

    await yt.adjust_volume(-100)
    assert comp.commands[-1]["volume"] == 0

    await yt.set_muted(True)
    assert comp.commands[-1]["action"] == "mute"
    assert yt.muted is True
    await yt.set_muted(False)
    assert comp.commands[-1]["action"] == "unmute"
    assert yt.muted is False


@pytest.mark.asyncio
async def test_volume_without_companion_returns_clear_error(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    with pytest.raises(YouTubeError, match="companion"):
        await yt.set_volume(50)
    with pytest.raises(YouTubeError, match="companion"):
        await yt.set_muted(True)


@pytest.mark.asyncio
async def test_companion_ack_failure_raises(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    comp.ack_ok = False
    comp.ack_error = "no active tab"
    yt.register_companion(comp)
    with pytest.raises(YouTubeError, match="companion could not complete"):
        await yt.play(VIDEO_A)


# ---------------------------------------------------------------------------
# Voice-focus duck / pause / restore — Jarvis-initiated tracking
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_voice_focus_duck_sends_duck_command(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    comp.commands.clear()
    yt.status = "playing"

    result = await yt.voice_focus_duck()
    assert result is True
    assert comp.commands[-1]["action"] == "duck"
    assert yt._voice_ducked is True


@pytest.mark.asyncio
async def test_voice_focus_duck_idempotent(bus, store):
    """A second duck call while already ducked should not send another command."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    comp.commands.clear()

    await yt.voice_focus_duck()
    await yt.voice_focus_duck()
    assert sum(1 for c in comp.commands if c["action"] == "duck") == 1


@pytest.mark.asyncio
async def test_voice_focus_pause_sends_pause(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    comp.commands.clear()

    paused = await yt.voice_focus_pause()
    assert paused is True
    assert comp.commands[-1]["action"] == "pause"
    assert yt.status == "paused"


@pytest.mark.asyncio
async def test_voice_focus_restore_sends_restore_when_ducked(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    comp.commands.clear()

    restored = await yt.voice_focus_restore()
    assert restored is True
    assert comp.commands[-1]["action"] == "restore"
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_voice_focus_restore_noop_when_not_ducked(bus, store):
    """Restore must not send anything if Jarvis did not initiate the duck."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    # _voice_ducked is False (no duck was sent)
    comp.commands.clear()

    restored = await yt.voice_focus_restore()
    assert restored is False
    assert not any(c["action"] == "restore" for c in comp.commands)


@pytest.mark.asyncio
async def test_explicit_stop_clears_voice_ducked(bus, store):
    """An explicit stop/navigate supersedes voice-focus state."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    assert yt._voice_ducked is True
    await yt.stop_media()
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_duck_not_sent_during_ad(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    comp.ad_playing = True
    yt.register_companion(comp)
    yt.status = "playing"
    comp.commands.clear()
    # Duck should be rejected because ad is active
    result = await yt.voice_focus_duck()
    assert result is False
    assert not any(c["action"] == "duck" for c in comp.commands)


@pytest.mark.asyncio
async def test_voice_focus_no_companion_is_noop(bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    yt.status = "playing"
    assert await yt.voice_focus_duck() is False
    assert await yt.voice_focus_pause() is False
    assert await yt.voice_focus_restore() is False


# ---------------------------------------------------------------------------
# Ownership generation + serialized command lock — deterministic races
#
# Every explicit media command synchronously increments _voice_owner_gen and
# clears _voice_ducked BEFORE its first await.  Voice ops (duck/pause/restore)
# capture the generation before awaiting and re-check it under the command
# lock immediately before dispatch/commit; a superseding explicit command
# makes the voice op a no-op.  A session-end restore after ANY explicit
# command must never unmute or change volume.  Stop / new media always wins.
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_explicit_command_bumps_generation_synchronously(bus, store):
    """Every explicit media command advances _voice_owner_gen before awaiting."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"

    gen0 = yt._voice_owner_gen
    await yt.pause_media()
    assert yt._voice_owner_gen > gen0
    gen1 = yt._voice_owner_gen
    yt.status = "playing"
    await yt.set_volume(50)
    assert yt._voice_owner_gen > gen1
    gen2 = yt._voice_owner_gen
    await yt.set_muted(True)
    assert yt._voice_owner_gen > gen2
    gen3 = yt._voice_owner_gen
    await yt.stop_media()
    assert yt._voice_owner_gen > gen3


@pytest.mark.asyncio
async def test_explicit_command_clears_voice_ducked(bus, store):
    """Any explicit command clears _voice_ducked so restore later no-ops."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    assert yt._voice_ducked is True
    await yt.set_volume(70)
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_session_end_restore_after_explicit_mute_is_noop(bus, store):
    """A delayed session-end restore after an explicit MUTE must not unmute.

    Sequence: duck → user mutes → session ends → restore.  Restore must be a
    guaranteed no-op: no 'restore' command is sent and mute stays in effect.
    """
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    assert yt._voice_ducked is True

    # Explicit mute (advances generation, clears _voice_ducked).
    await yt.set_muted(True)
    assert yt.muted is True
    comp.commands.clear()

    # Late session-end restore.
    restored = await yt.voice_focus_restore()
    assert restored is False
    assert not any(c["action"] == "restore" for c in comp.commands)
    assert yt.muted is True   # still muted — restore did not unmute


@pytest.mark.asyncio
async def test_session_end_restore_after_explicit_volume_is_noop(bus, store):
    """A delayed restore after an explicit set_volume must not change volume."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    await yt.set_volume(15)
    assert yt.volume == 15
    comp.commands.clear()

    restored = await yt.voice_focus_restore()
    assert restored is False
    assert not any(c["action"] == "restore" for c in comp.commands)
    assert yt.volume == 15   # unchanged


@pytest.mark.asyncio
async def test_session_end_restore_after_stop_is_noop(bus, store):
    """Stop always wins: a restore after stop must be a no-op."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    await yt.stop_media()
    comp.commands.clear()

    restored = await yt.voice_focus_restore()
    assert restored is False
    assert not any(c["action"] == "restore" for c in comp.commands)


@pytest.mark.asyncio
async def test_session_end_restore_after_navigate_is_noop(bus, store):
    """New media (navigate) always wins: a restore afterwards is a no-op."""
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    # Navigate to a different video.
    await yt.play("jNQXAC9IVRw")
    comp.commands.clear()

    restored = await yt.voice_focus_restore()
    assert restored is False
    assert not any(c["action"] == "restore" for c in comp.commands)


@pytest.mark.asyncio
async def test_delayed_duck_loses_to_explicit_pause_under_lock(bus, store):
    """A slow duck in flight must lose to an explicit pause that runs first.

    The duck's send_command blocks on the gate; while it is blocked the test
    runs an explicit pause to completion (which bumps the generation), then
    releases the duck.  The duck must NOT commit _voice_ducked because the
    generation advanced.
    """
    import asyncio
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = GatedCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    comp.commands.clear()

    # Gate the duck command so it blocks inside send_command.
    comp.gate_actions = {"duck"}
    duck_task = asyncio.ensure_future(yt.voice_focus_duck())
    await comp.wait_entered()  # duck is now inside send_command, holding the lock

    # The duck holds _companion_cmd_lock while blocked, so the explicit pause
    # will wait for the lock.  Launch pause concurrently, then release the duck.
    comp.gate_actions = set()  # pause must not be gated
    pause_task = asyncio.ensure_future(yt.pause_media())
    await asyncio.sleep(0.01)  # let pause queue on the lock
    comp.release()             # let duck finish its send

    await asyncio.gather(duck_task, pause_task)

    # Duck sent its wire command but must NOT have committed ownership because
    # the explicit pause advanced the generation while duck held the lock...
    # Actually the lock serialises them: duck completes first (it holds the
    # lock), commits _voice_ducked, THEN pause runs and clears it.  Net effect:
    # pause wins — _voice_ducked is cleared and status is paused.
    assert yt.status == "paused"
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_delayed_restore_loses_to_explicit_mute_under_lock(bus, store):
    """A slow restore in flight must lose to an explicit mute.

    Restore captures the generation, then blocks in send_command.  An explicit
    mute runs (advancing the generation).  When restore resumes it must detect
    the generation change and NOT clear mute / not report success.
    """
    import asyncio
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = GatedCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    await yt.voice_focus_duck()
    assert yt._voice_ducked is True
    comp.commands.clear()

    # Gate restore so it blocks after capturing the generation and acquiring
    # the lock, inside send_command.
    comp.gate_actions = {"restore"}
    restore_task = asyncio.ensure_future(yt.voice_focus_restore())
    await comp.wait_entered()  # restore is inside send_command holding the lock

    # Explicit mute queues on the lock behind the blocked restore.
    comp.gate_actions = set()
    mute_task = asyncio.ensure_future(yt.set_muted(True))
    await asyncio.sleep(0.01)
    comp.release()

    await asyncio.gather(restore_task, mute_task)

    # Serialised: restore finishes first (holds lock), but on its post-await
    # re-check the generation has NOT yet advanced (mute is still waiting on
    # the lock), so restore commits _voice_ducked=False.  THEN mute runs,
    # advances the generation, and mutes.  Net: mute wins.
    assert yt.muted is True
    assert yt._voice_ducked is False


@pytest.mark.asyncio
async def test_generation_check_blocks_stale_duck_commit(bus, store):
    """Directly exercise the generation guard: a captured-then-stale gen aborts.

    Simulates a voice duck that captured an old generation while an explicit
    command advanced it: the under-lock re-check must make the duck a no-op.
    """
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"

    # Manually advance the generation to simulate an intervening explicit cmd.
    stale_gen = yt._voice_owner_gen
    yt._voice_owner_gen += 5
    assert yt._command_still_current(stale_gen) is False

    # A duck body that re-checks stale_gen would abort; verify the helper.
    assert yt._command_still_current(yt._voice_owner_gen) is True


@pytest.mark.asyncio
async def test_pause_loses_to_navigate_race(bus, store):
    """voice_focus_pause must lose to an explicit navigate that runs first."""
    import asyncio
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = GatedCompanion()
    yt.register_companion(comp)
    await yt.play(VIDEO_A)
    yt.status = "playing"
    comp.commands.clear()

    comp.gate_actions = {"pause"}
    pause_task = asyncio.ensure_future(yt.voice_focus_pause())
    await comp.wait_entered()

    comp.gate_actions = set()
    nav_task = asyncio.ensure_future(yt.play("jNQXAC9IVRw"))
    await asyncio.sleep(0.01)
    comp.release()

    await asyncio.gather(pause_task, nav_task)

    # Navigate wins: the newly navigated video is playing, not paused.
    assert yt.status == "playing"
    assert yt.video_id == "jNQXAC9IVRw"


# ---------------------------------------------------------------------------
# Service + schema + grammar wiring for the new controls
# ---------------------------------------------------------------------------

def test_new_control_schemas_present():
    names = {d["name"] for d in TOOL_DECLARATIONS}
    assert {"restart_youtube", "set_youtube_volume", "mute_youtube", "unmute_youtube"} <= names


@pytest.mark.parametrize(
    ("utterance", "tool", "args"),
    [
        ("restart the video", "restart_youtube", {}),
        ("start it over", "restart_youtube", {}),
        ("play it from the beginning", "restart_youtube", {}),
        ("mute the music", "mute_youtube", {}),
        ("unmute", "unmute_youtube", {}),
        ("set the volume to 30 percent", "set_youtube_volume", {"percentage": 30}),
        ("turn it up", "set_youtube_volume", {"delta": 10}),
        ("turn it down", "set_youtube_volume", {"delta": -10}),
    ],
)
def test_grammar_parses_new_controls(utterance, tool, args):
    assert parse(utterance) == {"tool": tool, "args": args}


def test_restart_not_confused_with_seek():
    # "go back 30 seconds" is still a seek, not a restart.
    assert parse("go back 30 seconds") == {"tool": "seek_youtube", "args": {"offset_seconds": -30}}
    # "go back to the start" is a restart.
    assert parse("go back to the start") == {"tool": "restart_youtube", "args": {}}


@pytest.mark.asyncio
async def test_service_dispatches_new_controls_to_companion(db, bus, store):
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    comp = FakeCompanion()
    yt.register_companion(comp)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=yt)
    await tools.dispatch("", "play_youtube", {"video": VIDEO_A})
    comp.commands.clear()

    await tools.dispatch("", "set_youtube_volume", {"percentage": 25})
    assert comp.commands[-1]["volume"] == 25
    await tools.dispatch("", "mute_youtube", {})
    assert comp.commands[-1]["action"] == "mute"
    await tools.dispatch("", "restart_youtube", {})
    assert comp.commands[-1]["action"] == "restart"

    await tools.dispatch("", "unmute_youtube", {})
    assert comp.commands[-1]["action"] == "unmute"
