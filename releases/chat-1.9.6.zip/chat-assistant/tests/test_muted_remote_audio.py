"""Regression tests: muted state prevents remote PCM from reaching gateway.audio_in.

Verifies that:
1. Server drops all incoming PCM frames when rt.state.muted is True.
2. set_muted(True) on the runtime drains audio_in and revokes any active Talk lease.
3. Pre-mute frames queued before the mute command cannot be forwarded after mute.
"""

from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


async def _dummy_tools(call_id, name, args):
    return {}


class FakeWebSocket:
    """Minimal ASGI WebSocket double."""

    def __init__(self, token: str) -> None:
        self.cookies = {COOKIE: token}
        self.incoming: asyncio.Queue[dict] = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code: int | None = None
        self.close_reason = ""
        self.sent_bytes: list[bytes] = []
        self.sent_text: list[str] = []

    async def accept(self) -> None:
        self.accepted.set()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        self.close_code = code
        self.close_reason = reason or ""
        self.closed.set()

    async def receive(self) -> dict:
        return await self.incoming.get()

    async def send_bytes(self, payload: bytes) -> None:
        self.sent_bytes.append(payload)

    async def send_text(self, payload: str) -> None:
        self.sent_text.append(payload)

    def feed_audio(self, payload: bytes) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": payload})

    def disconnect(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})


@pytest.fixture
def mute_app(settings, db, store, bus):
    state = StateMachine(bus)
    gateway = LiveGateway(settings, db, store, bus, state, [], _dummy_tools)
    runtime = SimpleNamespace(
        settings=settings,
        db=db,
        state=state,
        gateway=gateway,
        broadcast=AudioBroadcast(),
        audio=None,
        media_playing=False,
        stop_calls=0,
    )

    def stop_output() -> None:
        runtime.stop_calls += 1
        gateway.interrupt()
        runtime.broadcast.clear()

    async def set_muted(muted: bool) -> None:
        runtime.state.set_muted(muted)
        if muted and runtime.gateway is not None:
            runtime.gateway.request_end_session("muted")
            while not runtime.gateway.audio_in.empty():
                try:
                    runtime.gateway.audio_in.get_nowait()
                except asyncio.QueueEmpty:
                    break

    runtime.stop_output = stop_output
    runtime.set_muted = set_muted
    app = create_app(runtime)
    sessions = SessionManager("mute-test-secret", 3600)
    app.state.sessions = sessions
    token = sessions.issue()
    endpoint = next(
        route.endpoint for route in app.routes if route.path == "/ws/remote-audio"
    )
    return app, runtime, token, endpoint


async def _open_socket(app, token, endpoint) -> tuple[FakeWebSocket, asyncio.Task]:
    ws = FakeWebSocket(token)
    task = asyncio.create_task(endpoint(ws))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    for _ in range(20):
        owner = app.state.remote_mic_owner
        if owner is not None and owner.socket is ws:
            break
        if ws.closed.is_set():
            break
        await asyncio.sleep(0)
    return ws, task


# ---------------------------------------------------------------------------
# Test 1: server-side muted state drops incoming PCM immediately
# ---------------------------------------------------------------------------

async def test_muted_pcm_never_reaches_gateway_audio_in(mute_app):
    """With state.muted=True, every incoming PCM frame is silently dropped
    and nothing is written to gateway.audio_in."""
    app, rt, token, endpoint = mute_app
    ws, task = await _open_socket(app, token, endpoint)

    # Mute BEFORE feeding audio.
    rt.state.set_muted(True)
    assert rt.state.muted

    loud = (3000).to_bytes(2, "little", signed=True) * 1600
    for _ in range(5):
        ws.feed_audio(loud)
    # Give the event loop time to process all frames.
    await asyncio.sleep(0.1)

    # Nothing should have reached audio_in.
    assert rt.gateway.audio_in.empty(), (
        f"Expected audio_in empty after mute; got {rt.gateway.audio_in.qsize()} item(s)"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


# ---------------------------------------------------------------------------
# Test 2: frames already in audio_in are drained when mute is engaged
# ---------------------------------------------------------------------------

async def test_set_muted_drains_audio_in_queue(mute_app):
    """Frames that arrived before the mute command are drained from audio_in."""
    app, rt, token, endpoint = mute_app
    ws, task = await _open_socket(app, token, endpoint)

    # Directly stuff pre-mute audio into audio_in (simulates frames that
    # arrived at the gateway before set_muted was processed).
    pre_mute_frame = b"\x01\x00" * 1280
    for _ in range(5):
        rt.gateway.audio_in.put_nowait(pre_mute_frame)
    assert not rt.gateway.audio_in.empty()

    # Engage mute: this should drain the queue.
    await rt.set_muted(True)

    # All pre-mute frames must be gone.
    assert rt.gateway.audio_in.empty(), (
        f"Pre-mute frames remain in audio_in after set_muted(True): "
        f"{rt.gateway.audio_in.qsize()} item(s)"
    )

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


# ---------------------------------------------------------------------------
# Test 3: set_muted(True) revokes the active Talk lease
# ---------------------------------------------------------------------------

async def test_set_muted_keeps_socket_open_and_drops_pcm(mute_app):
    """set_muted(True) ends the provider session and drops incoming PCM,
    but keeps the WebSocket open so the user can say Hey Jarvis after unmuting.
    The owner remains set; no close code is sent."""
    app, rt, token, endpoint = mute_app
    ws, task = await _open_socket(app, token, endpoint)
    assert app.state.remote_mic_owner is not None

    await rt.set_muted(True)
    await asyncio.sleep(0.15)

    # Socket must remain open — mute does not revoke the microphone lease.
    assert not ws.closed.is_set(), "Socket must stay open after mute"
    assert app.state.remote_mic_owner is not None
    assert not rt.gateway.session_intent_active

    # PCM sent while muted must be dropped server-side.
    loud = (3000).to_bytes(2, "little", signed=True) * 1600
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)
    assert rt.gateway.audio_in.empty(), "Muted PCM reached gateway.audio_in"

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
    assert app.state.remote_mic_owner is None


# ---------------------------------------------------------------------------
# Test 4: post-mute PCM frames sent after set_muted are dropped
# ---------------------------------------------------------------------------

async def test_late_arriving_pcm_dropped_after_mute(mute_app):
    """Frames sent by the browser after the server engages mute must not reach
    gateway.audio_in even if they arrive before the lease closes."""
    app, rt, token, endpoint = mute_app
    ws, task = await _open_socket(app, token, endpoint)

    await rt.set_muted(True)

    # Send audio after mute — these must be dropped.
    loud = (3000).to_bytes(2, "little", signed=True) * 1600
    ws.feed_audio(loud)
    ws.feed_audio(loud)
    await asyncio.sleep(0.1)

    assert rt.gateway.audio_in.empty(), (
        "Post-mute frames reached gateway.audio_in"
    )

    # Clean up
    if not ws.closed.is_set():
        ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)
