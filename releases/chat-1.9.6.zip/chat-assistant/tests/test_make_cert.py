from __future__ import annotations

import datetime
import ipaddress
import json
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.x509.oid import ExtendedKeyUsageOID

from chat_core.config import Settings
from deployment.windows import make_cert


NOW = datetime.datetime(2026, 8, 19, 12, 0, tzinfo=datetime.timezone.utc)


def _certificates(path: Path) -> list[x509.Certificate]:
    return x509.load_pem_x509_certificates(path.read_bytes())


def test_creates_ca_and_signed_server_certificate(tmp_path):
    paths = make_cert.create_certificates(
        tmp_path,
        hostname="chat-home",
        ip_addresses=["172.16.151.129", "192.168.1.25"],
        now=NOW,
    )

    ca = x509.load_pem_x509_certificate(paths.ca_certificate.read_bytes())
    leaf, bundled_ca = _certificates(paths.certificate)
    server_key = serialization.load_pem_private_key(paths.private_key.read_bytes(), password=None)

    assert paths.ca_private_key.parent == tmp_path.resolve()
    assert bundled_ca.fingerprint(hashes.SHA256()) == ca.fingerprint(hashes.SHA256())
    assert leaf.issuer == ca.subject
    assert leaf.public_key().public_numbers() == server_key.public_key().public_numbers()
    ca.public_key().verify(
        leaf.signature,
        leaf.tbs_certificate_bytes,
        padding.PKCS1v15(),
        leaf.signature_hash_algorithm,
    )

    ca_constraints = ca.extensions.get_extension_for_class(x509.BasicConstraints).value
    ca_usage = ca.extensions.get_extension_for_class(x509.KeyUsage).value
    assert ca_constraints.ca is True
    assert ca_usage.key_cert_sign is True

    leaf_constraints = leaf.extensions.get_extension_for_class(x509.BasicConstraints).value
    leaf_usage = leaf.extensions.get_extension_for_class(x509.KeyUsage).value
    leaf_eku = leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
    san = leaf.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert leaf_constraints.ca is False
    assert leaf_usage.digital_signature is True
    assert leaf_usage.key_encipherment is True
    assert leaf_usage.key_cert_sign is False
    assert ExtendedKeyUsageOID.SERVER_AUTH in leaf_eku
    assert set(san.get_values_for_type(x509.DNSName)) >= {
        "localhost",
        "chat-home",
        "chat-home.local",
    }
    assert set(san.get_values_for_type(x509.IPAddress)) >= {
        ipaddress.IPv4Address("127.0.0.1"),
        ipaddress.IPv4Address("172.16.151.129"),
        ipaddress.IPv4Address("192.168.1.25"),
    }


def test_reuses_ca_but_rotates_server_leaf(tmp_path):
    first = make_cert.create_certificates(
        tmp_path,
        hostname="chat-home",
        ip_addresses=["10.0.0.10"],
        now=NOW,
    )
    ca_before = first.ca_certificate.read_bytes()
    ca_key_before = first.ca_private_key.read_bytes()
    leaf_before = _certificates(first.certificate)[0]

    second = make_cert.create_certificates(
        tmp_path,
        hostname="chat-home",
        ip_addresses=["10.0.0.11"],
        now=NOW + datetime.timedelta(days=1),
    )
    leaf_after = _certificates(second.certificate)[0]

    assert second.ca_certificate.read_bytes() == ca_before
    assert second.ca_private_key.read_bytes() == ca_key_before
    assert leaf_after.serial_number != leaf_before.serial_number
    san = leaf_after.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert ipaddress.IPv4Address("10.0.0.11") in san.get_values_for_type(x509.IPAddress)


def test_ip_discovery_combines_name_resolution_and_route_probe(monkeypatch):
    monkeypatch.setattr(make_cert.socket, "gethostname", lambda: "chat-home")
    monkeypatch.setattr(make_cert.socket, "getfqdn", lambda *_args: "chat-home.local")
    monkeypatch.setattr(
        make_cert.socket,
        "gethostbyname_ex",
        lambda _host: ("chat-home", [], ["172.16.151.129"]),
    )
    monkeypatch.setattr(
        make_cert.socket,
        "getaddrinfo",
        lambda *_args: [
            (make_cert.socket.AF_INET, make_cert.socket.SOCK_STREAM, 6, "", ("192.168.1.25", 0))
        ],
    )

    class FakeRouteSocket:
        def settimeout(self, _timeout):
            pass

        def connect(self, _destination):
            pass

        def getsockname(self):
            return ("10.0.0.50", 49152)

        def close(self):
            pass

    monkeypatch.setattr(make_cert.socket, "socket", lambda *_args: FakeRouteSocket())

    assert set(make_cert.discover_local_ipv4_addresses()) == {
        ipaddress.IPv4Address("127.0.0.1"),
        ipaddress.IPv4Address("10.0.0.50"),
        ipaddress.IPv4Address("172.16.151.129"),
        ipaddress.IPv4Address("192.168.1.25"),
    }


def test_main_preserves_dashboard_ssl_config_paths(tmp_path, monkeypatch):
    settings = Settings(data_dir=str(tmp_path))
    monkeypatch.setattr(make_cert, "load_settings", lambda: settings)
    monkeypatch.setattr(make_cert.socket, "gethostname", lambda: "chat-home")
    monkeypatch.setattr(make_cert.socket, "getfqdn", lambda *_args: "chat-home.local")
    monkeypatch.setattr(make_cert, "discover_local_ipv4_addresses", lambda: [])

    assert make_cert.main() == 0

    saved = json.loads((tmp_path / "config.json").read_text())
    assert saved["ssl_certfile"] == str(tmp_path / "cert.pem")
    assert saved["ssl_keyfile"] == str(tmp_path / "key.pem")
    assert (tmp_path / "ca-cert.pem").is_file()
    assert (tmp_path / "ca-key.pem").is_file()


def test_ca_certificate_common_name_is_chat_branded(tmp_path):
    """The CA CN must say Chat, not Jarvis."""
    paths = make_cert.create_certificates(
        tmp_path,
        hostname="chat-home",
        ip_addresses=[],
        now=NOW,
    )
    ca = x509.load_pem_x509_certificate(paths.ca_certificate.read_bytes())
    cn = ca.subject.get_attributes_for_oid(x509.oid.NameOID.COMMON_NAME)[0].value
    assert "Chat" in cn
    assert "Jarvis" not in cn
