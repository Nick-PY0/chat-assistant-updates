"""The companion bridge must be reachable by a browser extension.

A browser extension cannot approve a self-signed certificate, so when the
dashboard runs HTTPS the extension can never open wss://127.0.0.1 — pairing
fails with an opaque error.  The bridge therefore runs on its own loopback
port, always plain HTTP, and the dashboard advertises that address.
"""

from __future__ import annotations

import asyncio
import contextlib
import socket

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from apps.dashboard.companion_server import (
    COMPANION_WS_PATH,
    CompanionBridgeServer,
    create_companion_app,
    reserve_bridge_socket,
    serve_companion_socket,
)
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def _login(client) -> str:
    resp = await client.post(
        "/setup", data={"password": "hunter2secure", "confirm": "hunter2secure"}
    )
    assert resp.status_code == 303
    return client.app.state.sessions.csrf_for(client.cookies.get(COOKIE))


# ---------------------------------------------------------------------------
# Port selection
# ---------------------------------------------------------------------------

def _reserve(configured: int, dashboard_port: int):
    """reserve_bridge_socket, always closing the socket it hands back."""
    reserved = reserve_bridge_socket(configured, dashboard_port)
    if reserved is None:
        return None
    sock, port = reserved
    sock.close()
    return port


def test_auto_port_follows_the_dashboard_port():
    assert _reserve(0, 8756) == 8757


def test_auto_port_walks_past_a_busy_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen(1)
        busy = taken.getsockname()[1]
        assert _reserve(0, busy - 1) != busy


def test_configured_port_is_never_silently_moved():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen(1)
        busy = taken.getsockname()[1]
        assert _reserve(busy, 8756) is None


def test_reserved_port_is_held_until_the_server_takes_it():
    """No gap between choosing a port and owning it."""
    reserved = reserve_bridge_socket(0, 8900)
    assert reserved is not None
    sock, port = reserved
    try:
        assert _reserve(port, 8900) is None, "the reserved port must be held"
    finally:
        sock.close()


def test_out_of_range_configured_port_fails_cleanly():
    assert reserve_bridge_socket(70000, 8756) is None
    assert reserve_bridge_socket(-1, 8756) is None


# ---------------------------------------------------------------------------
# The bridge app itself
# ---------------------------------------------------------------------------

async def test_bridge_app_exposes_only_health_and_the_socket(rt):
    app = create_companion_app(rt)
    paths = {route.path for route in app.routes if hasattr(route, "path")}
    assert COMPANION_WS_PATH in paths
    assert "/companion/health" in paths
    # No dashboard surface may be reachable on the plain-HTTP bridge port.
    for leaked in ("/", "/login", "/settings", "/api/companion/pair"):
        assert leaked not in paths


async def test_bridge_health_reports_liveness_without_secrets(rt):
    app = create_companion_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        resp = await c.get("/companion/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True
    assert "token" not in str(body).lower()
    assert "secret" not in str(body).lower()


async def test_bridge_server_binds_loopback_only(rt):
    server = CompanionBridgeServer(rt)
    assert await server.start() is True
    try:
        assert server.running
        assert rt.companion_bridge_port == server.port
        # Reachable on loopback...
        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{server.port}") as c:
            assert (await c.get("/companion/health")).status_code == 200
        # ...and bound to loopback only, whatever dashboard_host says, so no
        # LAN device can ever reach the bridge.
        assert rt.settings.dashboard_host == "0.0.0.0"
        assert server.bound_host == "127.0.0.1"
    finally:
        await server.stop()
    assert rt.companion_bridge_port is None


async def test_bridge_start_fails_cleanly_when_the_pinned_port_is_taken(rt):
    """An unavailable port must never take Chat down with it."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen(1)
        rt.settings.companion_bridge_port = taken.getsockname()[1]
        server = CompanionBridgeServer(rt)
        assert await server.start() is False
        assert server.error
        assert not server.running
        assert rt.companion_bridge_port is None


async def test_socket_rejects_a_non_loopback_peer_before_accepting(rt):
    """Loopback enforcement happens before the WebSocket is accepted."""

    class FakeWS:
        def __init__(self, host):
            self.client = type("C", (), {"host": host})()
            self.accepted = False
            self.close_code = None

        async def accept(self):
            self.accepted = True

        async def close(self, code=1000, reason=None):
            self.close_code = code

    ws = FakeWS("192.168.1.44")
    await serve_companion_socket(rt, ws)
    assert ws.accepted is False
    assert ws.close_code == 4403


async def test_new_port_still_demands_authentication(rt):
    """The plain-HTTP port must be no more trusting than the dashboard one."""
    import websockets

    server = CompanionBridgeServer(rt)
    assert await server.start() is True
    try:
        url = f"ws://127.0.0.1:{server.port}{COMPANION_WS_PATH}"
        async with websockets.connect(url) as ws:
            # The bridge greets, but a command sent without authenticating
            # must not be honoured — the socket is closed instead.
            await ws.recv()
            await ws.send('{"type":"state","status":"playing","session":1}')
            with pytest.raises(Exception):
                for _ in range(5):
                    await asyncio.wait_for(ws.recv(), timeout=2)

        # A wrong token is refused too, and leaves the bridge unpaired.
        async with websockets.connect(url) as ws:
            await ws.recv()
            await ws.send('{"type":"hello","token":"not-the-real-token"}')
            frames = []
            with contextlib.suppress(Exception):
                for _ in range(5):
                    frames.append(await asyncio.wait_for(ws.recv(), timeout=2))
            assert any("auth_error" in f for f in frames), frames
        assert await rt.companion.is_paired() is False
    finally:
        await server.stop()


# ---------------------------------------------------------------------------
# What the dashboard tells the owner to type into the extension
# ---------------------------------------------------------------------------

async def test_status_advertises_the_plain_ws_bridge_port(client, rt):
    csrf = await _login(client)
    rt.companion_bridge_port = 8757
    resp = await client.get("/api/companion/status", headers={"x-csrf": csrf})
    body = resp.json()
    assert body["bridge_base"] == "ws://127.0.0.1:8757"
    assert body["bridge_tls_blocked"] is False


async def test_pair_advertises_the_plain_ws_bridge_port(client, rt):
    csrf = await _login(client)
    rt.companion_bridge_port = 8757
    resp = await client.post("/api/companion/pair", json={}, headers={"x-csrf": csrf})
    body = resp.json()
    assert body["pairing_token"]
    assert body["bridge_base"] == "ws://127.0.0.1:8757"


async def test_https_dashboard_without_bridge_port_warns_instead_of_lying(settings, monkeypatch):
    """Falling back to wss must be reported as blocked, not offered silently."""
    settings.ssl_certfile = "cert.pem"
    settings.ssl_keyfile = "key.pem"
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    try:
        async def fake_validate(secret, timeout=5.0):
            return None

        monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
        app = create_app(runtime)
        transport = httpx.ASGITransport(app=app)
        # https base URL: with TLS configured the session cookie is Secure, so
        # a plain-http test client would silently drop it.
        async with httpx.AsyncClient(transport=transport, base_url="https://test") as c:
            c.app = app
            csrf = await _login(c)
            body = (await c.get("/api/companion/status", headers={"x-csrf": csrf})).json()
        assert body["bridge_base"].startswith("wss://")
        assert body["bridge_tls_blocked"] is True
    finally:
        await runtime.stop()
