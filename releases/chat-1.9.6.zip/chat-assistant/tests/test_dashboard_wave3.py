"""Dashboard endpoints added in wave 3: reminders, weather, quiet, settings."""

from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    monkeypatch.setattr(runtime.announcer, "announce", lambda key: None)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def signed_in(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    return {"x-csrf": await csrf_of(client)}


async def test_reminder_crud(client, rt):
    hdrs = await signed_in(client)

    resp = await client.post(
        "/api/reminders",
        json={"time": "12:00", "message": "dentist", "kind": "alarm"},
        headers=hdrs,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["kind"] == "alarm" and body["when"]
    rid = body["id"]

    resp = await client.get("/api/reminders")
    listed = resp.json()["reminders"]
    assert any(r["id"] == rid for r in listed)

    resp = await client.post(f"/api/reminders/{rid}/cancel", headers=hdrs)
    assert resp.status_code == 200
    assert resp.json()["status"] == "cancelled"

    # bad input is a clean 400, not a crash
    resp = await client.post("/api/reminders", json={"time": ""}, headers=hdrs)
    assert resp.status_code == 400
    resp = await client.post(
        "/api/reminders", json={"time": "08:00", "date": "2020-01-01"}, headers=hdrs
    )
    assert resp.status_code == 400

    resp = await client.post("/api/reminders/dismiss", headers=hdrs)
    assert resp.status_code == 200


async def test_quiet_toggle(client, rt):
    hdrs = await signed_in(client)
    resp = await client.post("/api/quiet", json={"quiet": True}, headers=hdrs)
    assert resp.json()["quiet"] is True and rt.quiet is True

    state = (await client.get("/api/state")).json()
    assert state["quiet"] is True
    assert "urls" in state and state["urls"]["local"].startswith("http://127.0.0.1:")

    resp = await client.post("/api/quiet", json={"quiet": False}, headers=hdrs)
    assert resp.json()["quiet"] is False and rt.quiet is False


async def test_weather_endpoints(client, rt, monkeypatch):
    hdrs = await signed_in(client)

    resp = await client.get("/api/weather")  # no location saved yet
    assert resp.status_code == 400
    assert "location" in resp.json()["error"]

    async def fake_geocode(q, count=5):
        return [{"name": "Georgetown (Demerara-Mahaica, Guyana)", "lat": 6.8, "lon": -58.16}]

    monkeypatch.setattr(rt.weather_tool.client, "geocode", fake_geocode)
    resp = await client.get("/api/location/search", params={"q": "georgetown"})
    assert resp.json()["results"][0]["lat"] == 6.8

    rt.settings.location_name = "Georgetown (Demerara-Mahaica, Guyana)"
    rt.settings.location_lat = 6.8
    rt.settings.location_lon = -58.16

    async def fake_forecast(lat, lon, units):
        return {
            "units": "celsius",
            "unit_symbol": "°C",
            "current": {"temp": 29.6, "text": "partly cloudy"},
            "today": {"text": "partly cloudy", "high": 31.0, "low": 24.1, "rain_chance": 35},
            "tomorrow": {"text": "light showers", "high": 30.2, "low": 23.8, "rain_chance": 70},
        }

    monkeypatch.setattr(rt.weather_tool.client, "forecast", fake_forecast)
    resp = await client.get("/api/weather", params={"day": "tomorrow"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["day"] == "tomorrow" and "Tomorrow in Georgetown" in body["summary"]


async def test_settings_validation(client, rt):
    hdrs = await signed_in(client)

    resp = await client.post("/api/settings", json={"alarm_volume": 5.0}, headers=hdrs)
    assert resp.status_code == 200
    assert rt.settings.alarm_volume == 1.0  # clamped

    resp = await client.post("/api/settings", json={"alarm_ring_seconds": 2}, headers=hdrs)
    assert resp.status_code == 400  # below minimum

    resp = await client.post("/api/settings", json={"weather_units": "kelvin"}, headers=hdrs)
    assert resp.status_code == 400

    resp = await client.post("/api/settings", json={"location_lat": 123.0}, headers=hdrs)
    assert resp.status_code == 400

    resp = await client.post(
        "/api/settings",
        json={
            "alarm_ring_seconds": 30,
            "quiet_override_alarms": False,
            "weather_units": "fahrenheit",
            "location_name": "Georgetown (Demerara-Mahaica, Guyana)",
            "location_lat": 6.8,
            "location_lon": -58.16,
        },
        headers=hdrs,
    )
    assert resp.status_code == 200
    assert rt.settings.alarm_ring_seconds == 30
    assert rt.settings.quiet_override_alarms is False
    assert rt.settings.weather_units == "fahrenheit"


async def test_first_run_setup_is_loopback_only(rt):
    """A LAN device must never be able to claim the admin password first."""
    app = create_app(rt)
    pw = {"password": "hunter2secure", "confirm": "hunter2secure"}
    lan = httpx.ASGITransport(app=app, client=("192.168.1.50", 40000))
    async with httpx.AsyncClient(transport=lan, base_url="http://test") as remote:
        assert (await remote.get("/setup")).status_code == 403
        assert (await remote.post("/setup", data=pw)).status_code == 403
    # on the computer itself (loopback) setup works...
    local = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=local, base_url="http://test") as here:
        assert (await here.post("/setup", data=pw)).status_code == 303
    # ...and once the password exists, LAN devices sign in normally
    async with httpx.AsyncClient(transport=lan, base_url="http://test") as remote:
        resp = await remote.post("/login", data={"password": "hunter2secure"})
        assert resp.status_code == 303
