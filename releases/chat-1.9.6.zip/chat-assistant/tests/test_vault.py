import pytest

from chat_core.security.vault import Vault


def test_roundtrip(vault):
    blob = vault.encrypt("AIzaSecretKey123", "gemini:voice")
    assert vault.decrypt(blob, "gemini:voice") == "AIzaSecretKey123"


def test_ciphertext_is_not_plaintext(vault):
    blob = vault.encrypt("AIzaSecretKey123", "gemini:voice")
    assert b"AIzaSecretKey123" not in blob


def test_context_separation(vault):
    blob = vault.encrypt("AIzaSecretKey123", "gemini:voice")
    with pytest.raises(Exception):
        vault.decrypt(blob, "govee:voice")


def test_wrong_master_fails(vault):
    blob = vault.encrypt("AIzaSecretKey123", "gemini:voice")
    other = Vault(b"x" * 32)
    with pytest.raises(Exception):
        other.decrypt(blob, "gemini:voice")


def test_mask_shows_only_tail():
    assert Vault.mask("AIzaSyExample1234") == "\u2022\u2022\u2022\u20221234"
    assert "Example" not in Vault.mask("AIzaSyExample1234")


def test_fingerprint_stable():
    assert Vault.fingerprint("label:p1") == Vault.fingerprint("label:p1")
    assert Vault.fingerprint("label:p1") != Vault.fingerprint("label:p2")


async def test_store_roundtrip_no_plaintext_in_db(store, db):
    cred = await store.add("gemini", "AIzaSyExampleSecret99", project_label="p1")
    assert await store.get_secret(cred.id) == "AIzaSyExampleSecret99"
    row = await db.fetchone("SELECT * FROM credentials WHERE id=?", (cred.id,))
    for key in row.keys():
        value = row[key]
        if isinstance(value, str):
            assert "AIzaSyExampleSecret99" not in value
        elif isinstance(value, bytes):
            assert b"AIzaSyExampleSecret99" not in value
    assert cred.public().get("masked_suffix", "").endswith("t99")
    assert "secret" not in cred.public()
