"""Tests for session token binding, transcript persistence, the transcripts
dashboard page and API, degraded-detail state snapshots, and safe
settings_json serialisation.
"""

from __future__ import annotations

import asyncio
import json

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.models.state import ChatState, StateMachine
from chat_core.events import EventBus
from chat_core.runtime import Runtime


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_ok(secret, timeout=10.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_ok)
    monkeypatch.setattr(dashboard_module, "validate_openai_key", fake_ok)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def _login(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    token = client.cookies.get(COOKIE)
    return {"x-csrf": client.app.state.sessions.csrf_for(token)}


# ---------------------------------------------------------------------------
# Database transcript helpers
# ---------------------------------------------------------------------------

async def test_open_close_voice_session(db):
    """open_voice_session + close_voice_session round-trips correctly."""
    sid = "testsession001"
    await db.open_voice_session(sid, "gemini", None)
    row = await db.fetchone("SELECT * FROM voice_sessions WHERE id = ?", (sid,))
    assert row is not None
    assert row["provider"] == "gemini"
    assert row["ended_at"] is None

    await db.close_voice_session(sid, "inactivity")
    row = await db.fetchone("SELECT * FROM voice_sessions WHERE id = ?", (sid,))
    assert row["ended_at"] is not None
    assert row["close_reason"] == "inactivity"


async def test_add_transcript(db):
    """add_transcript stores lines and respects session_id foreign key."""
    sid = "tsession002"
    await db.open_voice_session(sid, "relay", "cred1")
    await db.add_transcript(sid, "user", "Hello there")
    await db.add_transcript(sid, "assistant", "Hi, how can I help?")

    rows = await db.fetchall(
        "SELECT role, text FROM transcripts WHERE session_id = ? ORDER BY id",
        (sid,),
    )
    assert len(rows) == 2
    assert rows[0]["role"] == "user"
    assert rows[0]["text"] == "Hello there"
    assert rows[1]["role"] == "assistant"


async def test_add_transcript_unknown_session_ignored(db):
    """add_transcript for a non-existent session_id must not crash."""
    # Silently ignored; no row inserted, no exception raised.
    try:
        await db.add_transcript("does-not-exist", "user", "test")
    except Exception as exc:
        pytest.fail(f"add_transcript raised unexpectedly: {exc}")


async def test_close_voice_session_idempotent(db):
    """Closing a session twice must not update ended_at the second time."""
    sid = "tsession003"
    await db.open_voice_session(sid, "openai_live", None)
    await db.close_voice_session(sid, "first")
    row1 = await db.fetchone("SELECT ended_at FROM voice_sessions WHERE id=?", (sid,))
    ended1 = row1["ended_at"]

    # Simulate a stale cleanup call arriving later.
    await asyncio.sleep(0.01)
    await db.close_voice_session(sid, "second")
    row2 = await db.fetchone("SELECT ended_at FROM voice_sessions WHERE id=?", (sid,))
    # The WHERE includes ended_at IS NULL, so this is a no-op.
    assert row2["ended_at"] == ended1


# ---------------------------------------------------------------------------
# Session generation binding in gateway
# ---------------------------------------------------------------------------

async def test_gateway_generation_binding_prevents_stale_close(rt):
    """end_session called with a stale generation must not close the current session."""
    from apps.live_gateway.gateway import LiveGateway

    gw = LiveGateway(
        rt.settings, rt.db, rt.store, rt.bus, rt.state, [], lambda *a: {}
    )

    class _FakeSession:
        closed = False
        async def close(self, reason="stopped"): self.closed = True
        def _drain_output(self): pass

    real_session = _FakeSession()
    # Simulate first generation being active (no existing session so request_session works).
    gen1 = gw.request_session()
    assert gen1 == 1
    gw._session = real_session  # set session AFTER calling request_session

    # Simulate a second generation starting (rapid Stop → Start).
    gw._session_intent_active = False  # allow new session
    gw._session = None                  # clear so request_session isn't idempotent
    gen2 = gw.request_session()
    assert gen2 == 2
    gw._session = real_session  # put back

    # Stale call with the old generation should do nothing.
    result = await gw.end_session("stale-cleanup", expected_generation=gen1)
    assert not result  # rejected
    assert not real_session.closed
    assert gw._session is real_session  # session still live

    # Correct generation closes it.
    result = await gw.end_session("proper-close", expected_generation=gen2)
    assert result


async def test_gateway_generation_advance_on_new_session(rt):
    """Each new wake/manual request advances the session generation."""
    from apps.live_gateway.gateway import LiveGateway

    gw = LiveGateway(
        rt.settings, rt.db, rt.store, rt.bus, rt.state, [], lambda *a: {}
    )
    assert gw.voice_session_generation == 0
    gen1 = gw.request_session()
    assert gen1 == 1
    assert gw._session_intent_active
    # Repeated request while session active is idempotent.
    gen1b = gw.request_session()
    assert gen1b == 1
    # End the session and request a new one.
    gw._session_intent_active = False
    gen2 = gw.request_session()
    assert gen2 == 2


# ---------------------------------------------------------------------------
# Transcripts API (authenticated)
# ---------------------------------------------------------------------------

async def test_transcripts_api_requires_auth(client):
    r = await client.get("/api/transcripts")
    assert r.status_code == 401

    r = await client.get("/api/transcripts/someid")
    assert r.status_code == 401


async def test_transcripts_list_empty(client):
    headers = await _login(client)
    r = await client.get("/api/transcripts", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert "sessions" in data
    assert isinstance(data["sessions"], list)


async def test_transcripts_detail_not_found(client):
    headers = await _login(client)
    r = await client.get("/api/transcripts/nonexistent-id", headers=headers)
    assert r.status_code == 404


async def test_transcripts_create_and_retrieve(client, rt):
    headers = await _login(client)

    sid = "apisession001"
    await rt.db.open_voice_session(sid, "gemini", None)
    await rt.db.add_transcript(sid, "user", "What time is it?")
    await rt.db.add_transcript(sid, "assistant", "I don't know the time.")
    await rt.db.close_voice_session(sid, "inactivity")

    r = await client.get("/api/transcripts", headers=headers)
    assert r.status_code == 200
    sessions = r.json()["sessions"]
    ids = [s["id"] for s in sessions]
    assert sid in ids

    r2 = await client.get(f"/api/transcripts/{sid}", headers=headers)
    assert r2.status_code == 200
    data2 = r2.json()
    assert data2["session"]["id"] == sid
    # With pagination the response always includes has_more and next_before.
    assert "has_more" in data2
    assert "next_before" in data2
    # Only 2 lines, so no pagination needed.
    assert data2["has_more"] is False
    assert data2["next_before"] is None
    assert len(data2["lines"]) == 2
    assert data2["lines"][0]["role"] == "user"
    assert data2["lines"][0]["text"] == "What time is it?"
    assert data2["lines"][1]["role"] == "assistant"


async def test_transcripts_pagination(client, rt):
    headers = await _login(client)

    for i in range(5):
        sid = f"pgsession{i:03d}"
        await rt.db.open_voice_session(sid, "relay", None)
        await rt.db.add_transcript(sid, "user", f"message {i}")
        await rt.db.close_voice_session(sid, "ok")

    r = await client.get("/api/transcripts?limit=3&offset=0", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert len(data["sessions"]) == 3

    r2 = await client.get("/api/transcripts?limit=3&offset=3", headers=headers)
    assert r2.status_code == 200
    data2 = r2.json()
    # Remaining 2 sessions.
    assert len(data2["sessions"]) == 2


async def test_transcripts_page_requires_auth(client):
    r = await client.get("/transcripts")
    assert r.status_code == 303  # redirected to login


async def test_transcripts_page_accessible_when_logged_in(client):
    await _login(client)
    r = await client.get("/transcripts")
    assert r.status_code == 200
    assert b"Transcripts" in r.content


# ---------------------------------------------------------------------------
# Degraded-detail in StateMachine
# ---------------------------------------------------------------------------

def test_degraded_reasons_empty():
    bus = EventBus()
    sm = StateMachine(bus)
    assert sm.degraded_reasons() == {}
    assert sm.snapshot()["degraded_detail"] == []


def test_degraded_mark_with_reason():
    bus = EventBus()
    sm = StateMachine(bus)
    sm.mark_degraded("audio", True, "device not found")
    snap = sm.snapshot()
    assert "audio" in snap["degraded"]
    detail = snap["degraded_detail"]
    assert any(d["component"] == "audio" and d["reason"] == "device not found"
               for d in detail)


def test_degraded_mark_without_reason_falls_back_to_component():
    bus = EventBus()
    sm = StateMachine(bus)
    sm.mark_degraded("network", True)
    snap = sm.snapshot()
    detail = snap["degraded_detail"]
    assert any(d["component"] == "network" and d["reason"] == "network" for d in detail)


def test_degraded_clear():
    bus = EventBus()
    sm = StateMachine(bus)
    sm.mark_degraded("audio", True, "broken")
    sm.mark_degraded("audio", False)
    assert "audio" not in sm.snapshot()["degraded"]
    assert sm.snapshot()["degraded_detail"] == []


def test_degraded_backwards_compat_bool_api():
    """Old callers that pass (component, bool) without a reason still work."""
    bus = EventBus()
    sm = StateMachine(bus)
    sm.mark_degraded("pulse", True)  # no reason
    assert "pulse" in sm.degraded
    sm.mark_degraded("pulse", False)
    assert "pulse" not in sm.degraded


def test_degraded_emits_event():
    bus = EventBus()
    events = []
    q = bus.subscribe("state")
    sm = StateMachine(bus)
    sm.mark_degraded("voice", True, "timeout")
    ev = q.get_nowait()
    detail = ev.data.get("degraded_detail", [])
    assert any(d["component"] == "voice" for d in detail)


# ---------------------------------------------------------------------------
# Safe settings_json serialisation
# ---------------------------------------------------------------------------

async def test_settings_json_escapes_script_injection(client, rt):
    """A </script> payload stored in a settings field must not break the page."""
    headers = await _login(client)
    # Inject a payload into system_prompt via the API.
    payload = 'hello </script><script>alert(1)</script>'
    r = await client.post("/api/settings", json={"system_prompt": payload}, headers=headers)
    assert r.status_code == 200

    # Fetch the settings page.
    page = await client.get("/settings")
    assert page.status_code == 200
    body = page.text
    # The raw </script> must not appear outside of a safe encoding.
    assert "</script><script>" not in body
    # The escaped form must be present.
    assert "<\\/script>" in body


async def test_settings_json_valid_json_after_escaping(client, rt):
    """settings_json must still be valid JSON despite the escaping."""
    headers = await _login(client)
    payload = 'safe </script> test'
    await client.post("/api/settings", json={"system_prompt": payload}, headers=headers)

    page = await client.get("/settings")
    assert page.status_code == 200
    body = page.text

    # Extract the inline JSON from the script block.
    import re
    match = re.search(r"const\s+s\s*=\s*(\{.*?\});", body, re.DOTALL)
    if match:
        extracted = match.group(1)
        # Undo the JS-safe escaping to verify it parses as JSON.
        extracted_clean = extracted.replace("<\\/", "</")
        parsed = json.loads(extracted_clean)
        assert "system_prompt" in parsed


# ---------------------------------------------------------------------------
# Transcript detail pagination — 500+ lines
# ---------------------------------------------------------------------------

async def _make_session_with_lines(rt, sid: str, count: int, provider: str = "gemini") -> None:
    """Helper: open a session and insert *count* transcript lines."""
    await rt.db.open_voice_session(sid, provider, None)
    for i in range(count):
        role = "user" if i % 2 == 0 else "assistant"
        await rt.db.add_transcript(sid, role, f"line {i}")
    await rt.db.close_voice_session(sid, "done")


async def test_detail_initial_page_max_200_lines(client, rt):
    """Initial detail fetch must return at most 200 (newest) lines."""
    headers = await _login(client)
    sid = "big500"
    await _make_session_with_lines(rt, sid, 500)

    r = await client.get(f"/api/transcripts/{sid}", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert len(data["lines"]) <= 200


async def test_detail_initial_has_more_and_next_before(client, rt):
    """has_more=True and next_before set when session has more than 200 lines."""
    headers = await _login(client)
    sid = "big501"
    await _make_session_with_lines(rt, sid, 501)

    r = await client.get(f"/api/transcripts/{sid}", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert data["has_more"] is True
    assert data["next_before"] is not None
    assert isinstance(data["next_before"], int)
    assert data["next_before"] > 0


async def test_detail_initial_returns_newest_rows(client, rt):
    """Without a cursor, the API returns the NEWEST lines in chronological order."""
    headers = await _login(client)
    sid = "big502"
    await _make_session_with_lines(rt, sid, 300)

    r = await client.get(f"/api/transcripts/{sid}", headers=headers)
    assert r.status_code == 200
    data = r.json()
    lines = data["lines"]
    assert len(lines) == 200
    # Lines returned in chronological (ascending id) order.
    ids = [ln["id"] for ln in lines]
    assert ids == sorted(ids), "lines must be in ascending id order"
    # The newest 200 lines: texts should be "line 100" through "line 299".
    texts = [ln["text"] for ln in lines]
    assert texts[0] == "line 100"
    assert texts[-1] == "line 299"


async def test_detail_load_earlier_non_overlapping(client, rt):
    """Load-earlier pages (before cursor) must be non-overlapping."""
    headers = await _login(client)
    sid = "big503"
    await _make_session_with_lines(rt, sid, 450)

    # First page: newest 200 lines.
    r1 = await client.get(f"/api/transcripts/{sid}", headers=headers)
    assert r1.status_code == 200
    d1 = r1.json()
    ids_page1 = {ln["id"] for ln in d1["lines"]}
    assert d1["has_more"] is True
    cursor = d1["next_before"]

    # Second page: older lines before cursor.
    r2 = await client.get(
        f"/api/transcripts/{sid}?before={cursor}", headers=headers
    )
    assert r2.status_code == 200
    d2 = r2.json()
    ids_page2 = {ln["id"] for ln in d2["lines"]}

    # No overlap between pages.
    assert ids_page1.isdisjoint(ids_page2), "pages must not overlap"

    # All page-2 ids must be smaller than the smallest page-1 id.
    assert max(ids_page2) < min(ids_page1), "older page ids must all be below newer page ids"


async def test_detail_load_earlier_ordered(client, rt):
    """Load-earlier response lines must be in ascending (chronological) order."""
    headers = await _login(client)
    sid = "big504"
    await _make_session_with_lines(rt, sid, 250)

    r1 = await client.get(f"/api/transcripts/{sid}", headers=headers)
    d1 = r1.json()
    cursor = d1["next_before"]

    r2 = await client.get(
        f"/api/transcripts/{sid}?before={cursor}", headers=headers
    )
    assert r2.status_code == 200
    d2 = r2.json()
    ids = [ln["id"] for ln in d2["lines"]]
    assert ids == sorted(ids), "load-earlier lines must be in ascending id order"


async def test_detail_all_pages_cover_full_session(client, rt):
    """Walking all before-cursor pages must cover every line exactly once."""
    headers = await _login(client)
    sid = "big505"
    total = 350
    await _make_session_with_lines(rt, sid, total)

    all_ids = set()
    cursor = None

    # First fetch (no cursor).
    r = await client.get(f"/api/transcripts/{sid}", headers=headers)
    d = r.json()
    for ln in d["lines"]:
        all_ids.add(ln["id"])
    cursor = d.get("next_before")

    # Walk older pages.
    while cursor is not None:
        r = await client.get(
            f"/api/transcripts/{sid}?before={cursor}", headers=headers
        )
        assert r.status_code == 200
        d = r.json()
        for ln in d["lines"]:
            assert ln["id"] not in all_ids, f"duplicate line id {ln['id']}"
            all_ids.add(ln["id"])
        cursor = d.get("next_before")

    assert len(all_ids) == total, f"expected {total} unique ids, got {len(all_ids)}"


async def test_detail_malformed_cursor_safe(client, rt):
    """A malformed before cursor must return 400, not crash."""
    headers = await _login(client)
    sid = "big506"
    await _make_session_with_lines(rt, sid, 5)

    for bad in ["abc", "1.5", "", " ", "-1", "0"]:
        r = await client.get(
            f"/api/transcripts/{sid}?before={bad}", headers=headers
        )
        # Empty string is treated as no cursor (no error); other bad values → 400.
        if bad in ("",):
            assert r.status_code == 200
        else:
            assert r.status_code == 400, f"expected 400 for before={bad!r}, got {r.status_code}"


async def test_detail_never_returns_unlimited(client, rt):
    """Even with limit=9999 in query string, max 200 lines returned."""
    headers = await _login(client)
    sid = "big507"
    await _make_session_with_lines(rt, sid, 600)

    r = await client.get(f"/api/transcripts/{sid}?limit=9999", headers=headers)
    assert r.status_code == 200
    assert len(r.json()["lines"]) <= 200


async def test_list_summary_count_correct(client, rt):
    """Session list line_count must match the actual number of transcript rows."""
    headers = await _login(client)
    sid = "big508"
    await _make_session_with_lines(rt, sid, 50)

    r = await client.get("/api/transcripts", headers=headers)
    assert r.status_code == 200
    sessions = r.json()["sessions"]
    match = next((s for s in sessions if s["id"] == sid), None)
    assert match is not None
    assert match["line_count"] == 50


async def test_list_offset_bound(client, rt):
    """Extreme offsets must not stall; the API returns an empty list gracefully."""
    headers = await _login(client)

    r = await client.get("/api/transcripts?limit=50&offset=999999", headers=headers)
    assert r.status_code == 200
    data = r.json()
    # Offset is clamped to 10_000 — with few or no sessions the result is empty.
    assert isinstance(data["sessions"], list)


# ---------------------------------------------------------------------------
# Static / browser behaviour for transcripts page
# ---------------------------------------------------------------------------

async def test_transcripts_html_has_load_earlier_button(client):
    """The transcripts page must contain the Load earlier button."""
    await _login(client)
    r = await client.get("/transcripts")
    assert r.status_code == 200
    assert b"load-earlier-btn" in r.content


async def test_transcripts_html_no_unlimited_render(client, rt):
    """Transcripts page must not contain any element that would render all rows
    at once — the Load earlier button and cursor approach replaces the old
    flat list."""
    await _login(client)
    r = await client.get("/transcripts")
    assert r.status_code == 200
    body = r.content
    # The page must reference detailNextBefore (cursor state management).
    assert b"detailNextBefore" in body
    # Must have the load-earlier wrapper.
    assert b"load-earlier-wrap" in body
