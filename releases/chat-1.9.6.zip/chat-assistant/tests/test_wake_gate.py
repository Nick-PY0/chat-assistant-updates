"""The wake gate must win races: wake-word inference runs OFF the event
loop, so a mute click or a session start can land while predict() computes.
Acting on a stale wake hit afterward would defeat the emergency mute."""

import asyncio

from apps.audio.engine import AudioEngine
from chat_core.models.state import ChatState, StateMachine


def make_engine(settings, bus, state) -> AudioEngine:
    return AudioEngine(
        settings,
        bus,
        state,
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        on_wake=lambda: None,
        on_interrupt=lambda: None,
    )


async def test_wake_gate_blocks_mute_and_active_sessions(settings, bus):
    state = StateMachine(bus)
    eng = make_engine(settings, bus, state)

    # sleeping and unmuted: a wake hit may act
    assert eng._wake_gate_open()

    # the emergency mute wins even when it landed mid-inference
    state.set_muted(True)
    assert not eng._wake_gate_open()
    state.set_muted(False)

    # a session that started during inference must not get a second wake
    for st in (ChatState.CONNECTING, ChatState.LISTENING, ChatState.SPEAKING):
        state.set(st, "test")
        assert not eng._wake_gate_open()

    # back to rest states: gate reopens (LOCAL_ONLY also listens for wake)
    state.set(ChatState.SLEEPING, "test")
    assert eng._wake_gate_open()
    state.set(ChatState.LOCAL_ONLY, "test")
    assert eng._wake_gate_open()

    # engine shutdown closes the gate for good
    eng._stop.set()
    assert not eng._wake_gate_open()
