"""Offline grammar for reminders, alarms, weather and quiet mode."""

from apps.tool_service.local_grammar import parse, parse_spoken_time


def test_spoken_time_forms():
    assert parse_spoken_time("7") == (7, 0, "")
    assert parse_spoken_time("7:30 pm") == (7, 30, "pm")
    assert parse_spoken_time("seven thirty p m") == (7, 30, "pm")
    assert parse_spoken_time("seven oh five") == (7, 5, "")
    assert parse_spoken_time("5 o'clock") == (5, 0, "")
    assert parse_spoken_time("noon") == (12, 0, "pm")
    assert parse_spoken_time("midnight") == (12, 0, "am")
    assert parse_spoken_time("banana") is None
    assert parse_spoken_time("25") is None
    assert parse_spoken_time("7 75") is None


def test_remind_prefixed_and_suffixed():
    cmd = parse("remind me at 5 to take the chicken out")
    assert cmd == {
        "tool": "set_reminder",
        "args": {"hour": 5, "minute": 0, "ampm": "", "day": "",
                 "message": "take the chicken out", "kind": "reminder"},
    }
    cmd = parse("remind me to stretch at seven thirty pm")
    assert cmd["args"]["hour"] == 7 and cmd["args"]["minute"] == 30
    assert cmd["args"]["ampm"] == "pm" and cmd["args"]["message"] == "stretch"

    cmd = parse("remind me at 9 tonight to check the oven")
    assert cmd["args"]["day"] == "tonight"


def test_alarms():
    cmd = parse("wake me up at 7 am")
    assert cmd["tool"] == "set_reminder" and cmd["args"]["kind"] == "alarm"
    assert (cmd["args"]["hour"], cmd["args"]["ampm"]) == (7, "am")

    cmd = parse("set an alarm for 6:30")
    assert cmd["args"]["kind"] == "alarm" and cmd["args"]["minute"] == 30

    cmd = parse("hey chat wake me at noon")
    assert cmd["args"]["hour"] == 12 and cmd["args"]["ampm"] == "pm"


def test_list_and_cancel():
    assert parse("list my reminders") == {"tool": "list_reminders", "args": {}}
    assert parse("what are my alarms") == {"tool": "list_reminders", "args": {}}
    assert parse("cancel the alarm") == {"tool": "cancel_reminder", "args": {"ref": "alarm"}}
    assert parse("cancel the chicken reminder") == {
        "tool": "cancel_reminder", "args": {"ref": "chicken"}}
    # timers keep their own cancel path
    assert parse("cancel the tea timer")["tool"] == "cancel_timer"


def test_weather_phrases():
    assert parse("what's the weather") == {"tool": "get_weather", "args": {"day": "today"}}
    assert parse("what's the weather like tomorrow")["args"]["day"] == "tomorrow"
    assert parse("will it rain tomorrow")["args"]["day"] == "tomorrow"
    assert parse("how's the weather tonight")["args"]["day"] == "today"
    assert parse("weather report") == {"tool": "get_weather", "args": {"day": "today"}}


def test_quiet_phrases():
    assert parse("quiet mode on") == {"tool": "set_quiet_mode", "args": {"enabled": True}}
    assert parse("quiet mode") == {"tool": "set_quiet_mode", "args": {"enabled": True}}
    assert parse("go quiet")["args"]["enabled"] is True
    assert parse("do not disturb")["args"]["enabled"] is True
    assert parse("quiet mode off")["args"]["enabled"] is False
    assert parse("you can talk now")["args"]["enabled"] is False
    # bare "quiet" / "be quiet" stay an immediate stop, not a mode change
    assert parse("quiet") == {"tool": "stop_output", "args": {}}
    assert parse("be quiet") == {"tool": "stop_output", "args": {}}


def test_failed_time_parse_falls_through():
    assert parse("remind me to call mom at banana") is None
