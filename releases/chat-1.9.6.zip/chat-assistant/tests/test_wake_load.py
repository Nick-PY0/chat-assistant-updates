"""First-run wake model loading: model files download on demand, and every
failure produces a plain-language reason (the old code logged only the
exception type, which hid a missing-files problem for months)."""

from __future__ import annotations

import pytest

from apps.audio import engine


class RecordingModel:
    """Stands in for openwakeword.model.Model."""

    fail_until_downloaded = False
    downloaded = False
    constructed_with: list = []

    def __init__(self, wakeword_models=None):
        type(self).constructed_with.append(wakeword_models)
        if type(self).fail_until_downloaded and not type(self).downloaded:
            # mimics a fresh install without the model files
            raise ValueError("Could not find model file")


@pytest.fixture(autouse=True)
def fake_wake(monkeypatch):
    RecordingModel.fail_until_downloaded = False
    RecordingModel.downloaded = False
    RecordingModel.constructed_with = []
    monkeypatch.setattr(engine, "WakeModel", RecordingModel, raising=False)
    yield


def test_fresh_install_downloads_files_then_loads(monkeypatch):
    RecordingModel.fail_until_downloaded = True
    calls = []

    def fake_download():
        calls.append(1)
        RecordingModel.downloaded = True

    monkeypatch.setattr(engine, "_download_wake_models", fake_download)
    model, reason = engine._load_wake_model_blocking("hey_jarvis")
    assert model is not None and reason == ""
    assert calls == [1]
    assert RecordingModel.constructed_with == [["hey_jarvis"], ["hey_jarvis"]]


def test_download_failure_is_explained(monkeypatch):
    RecordingModel.fail_until_downloaded = True

    def fake_download():
        raise OSError("no internet")

    monkeypatch.setattr(engine, "_download_wake_models", fake_download)
    model, reason = engine._load_wake_model_blocking("hey_jarvis")
    assert model is None
    assert "could not be downloaded" in reason
    assert "install.bat" in reason


def test_no_download_when_model_loads(monkeypatch):
    def boom():
        raise AssertionError("download_models must not run when loading works")

    monkeypatch.setattr(engine, "_download_wake_models", boom)
    model, reason = engine._load_wake_model_blocking("hey_jarvis")
    assert model is not None and reason == ""
    assert RecordingModel.constructed_with == [["hey_jarvis"]]


def test_empty_ref_passes_none_through():
    model, reason = engine._load_wake_model_blocking("")
    assert model is not None and reason == ""
    assert RecordingModel.constructed_with == [None]


def test_missing_custom_file_has_clear_reason(tmp_path):
    model, reason = engine._load_wake_model_blocking(str(tmp_path / "nope.onnx"))
    assert model is None
    assert "not found" in reason
    assert RecordingModel.constructed_with == []  # never even constructed


def test_existing_custom_file_loads(tmp_path):
    p = tmp_path / "chat.onnx"
    p.write_bytes(b"onnx")
    model, reason = engine._load_wake_model_blocking(str(p))
    assert model is not None and reason == ""
    assert RecordingModel.constructed_with == [[str(p)]]


def test_still_failing_after_download_is_explained(monkeypatch):
    RecordingModel.fail_until_downloaded = True
    monkeypatch.setattr(engine, "_download_wake_models", lambda: None)  # "succeeds"
    model, reason = engine._load_wake_model_blocking("hey_jarvis")
    assert model is None
    assert "after downloading" in reason
