"""Brain routing in the gateway: missing prerequisites fall back to Google
with the reason logged, and OpenAI failures mark the credential pill."""

from __future__ import annotations

from datetime import timedelta

from apps.live_gateway.gateway import LiveGateway
from apps.tool_service.schemas import TOOL_DECLARATIONS
from chat_core.models.credentials import utcnow
from chat_core.models.state import StateMachine
from integrations.gemini.errors import (
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
    GeminiFailure,
)


async def dummy_tools(call_id, name, args):
    return {}


def make_gateway(settings, db, store, bus):
    state = StateMachine(bus)
    return LiveGateway(settings, db, store, bus, state, TOOL_DECLARATIONS, dummy_tools)


async def last_log(db) -> str:
    row = await db.fetchone("SELECT message FROM events_log ORDER BY id DESC LIMIT 1")
    return row["message"] if row else ""


async def test_openai_brain_without_key_falls_back(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    settings.voice_brain = "openai_live"
    assert await gw._run_openai_live() is False
    assert "no usable OpenAI key" in await last_log(db)


async def test_openai_brain_skips_invalid_keys(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    cred = await store.add("openai", "sk-testkey123456", project_label="me")
    await store.set_status(cred.id, "invalid", INVALID)
    assert await gw._run_openai_live() is False
    assert "no usable OpenAI key" in await last_log(db)


async def test_openai_brain_skips_backed_off_keys(settings, db, store, bus):
    """A key inside its backoff window must not be hammered on every wake."""
    gw = make_gateway(settings, db, store, bus)
    cred = await store.add("openai", "sk-testkey555555", project_label="me")
    await store.set_status(cred.id, "unavailable", UNAVAILABLE,
                           utcnow() + timedelta(hours=1))
    assert await gw._run_openai_live() is False
    assert "no usable OpenAI key" in await last_log(db)


async def test_relay_brain_needs_url_then_password(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    settings.voice_brain = "relay"
    settings.relay_url = ""
    assert await gw._run_relay() is False
    assert "no relay address" in await last_log(db)

    settings.relay_url = "https://myrelay.replit.app"
    assert await gw._run_relay() is False
    assert "no relay password" in await last_log(db)


async def test_openai_failures_mark_credentials(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)

    cred = await store.add("openai", "sk-testkey100001", project_label="me")
    await gw._note_openai_failure(cred, GeminiFailure(INVALID, "bad key"))
    assert (await store.get(cred.id)).status == "invalid"

    cred2 = await store.add("openai", "sk-testkey200002", project_label="me")
    await gw._note_openai_failure(cred2, GeminiFailure(QUOTA_EXHAUSTED, "spent"))
    got = await store.get(cred2.id)
    assert got.status == "exhausted"
    assert got.retry_after is not None

    cred3 = await store.add("openai", "sk-testkey300003", project_label="me")
    await gw._note_openai_failure(cred3, GeminiFailure(RATE_LIMITED, "slow down"))
    assert (await store.get(cred3.id)).status == "unavailable"

    cred4 = await store.add("openai", "sk-testkey400004", project_label="me")
    await gw._note_openai_failure(cred4, GeminiFailure(UNAVAILABLE, "server error"))
    assert (await store.get(cred4.id)).status == "unavailable"
