import asyncio

import pytest

from apps.tool_service.timers import TimerError, TimerManager
from chat_core.models.credentials import iso, utcnow
from datetime import timedelta


async def test_validation(db, bus):
    tm = TimerManager(db, bus)
    with pytest.raises(TimerError):
        await tm.start_timer(0)
    with pytest.raises(TimerError):
        await tm.start_timer(13 * 3600)
    with pytest.raises(TimerError):
        await tm.start_timer("soon")


async def test_timer_fires(db, bus):
    tm = TimerManager(db, bus)
    fired = bus.subscribe("timer_fired")
    await tm.start()
    try:
        await tm.start_timer(1, "egg")
        ev = await asyncio.wait_for(fired.get(), timeout=5)
        assert ev.data["label"] == "egg"
        assert await tm.list_timers() == []
    finally:
        await tm.stop()


async def test_pause_resume_cancel(db, bus):
    tm = TimerManager(db, bus)
    started = await tm.start_timer(600, "kitchen")
    paused = await tm.pause_timer("kitchen")
    assert paused["status"] == "paused"
    assert 590 <= paused["remaining_seconds"] <= 600

    resumed = await tm.resume_timer(started["id"])
    assert resumed["status"] == "running"

    cancelled = await tm.cancel_timer("kitchen")
    assert cancelled["status"] == "cancelled"
    assert await tm.list_timers() == []


async def test_missed_timer_surfaced_on_restart(db, bus):
    # simulate a timer that expired while the machine was off
    await db.execute(
        "INSERT INTO timers (id, label, duration_seconds, deadline, status, created_at) "
        "VALUES ('t_old', 'laundry', 60, ?, 'running', ?)",
        (iso(utcnow() - timedelta(minutes=10)), iso(utcnow() - timedelta(minutes=11))),
    )
    missed = bus.subscribe("timer_missed")
    tm = TimerManager(db, bus)
    await tm.start()
    try:
        ev = missed.get_nowait()
        assert ev.data["label"] == "laundry"
        row = await db.fetchone("SELECT status FROM timers WHERE id='t_old'")
        assert row["status"] == "missed"
    finally:
        await tm.stop()


async def test_persistence_across_manager_instances(db, bus):
    tm1 = TimerManager(db, bus)
    await tm1.start_timer(300, "tea")
    # "restart": a brand-new manager sees the same timer from SQLite
    tm2 = TimerManager(db, bus)
    timers = await tm2.list_timers()
    assert len(timers) == 1
    assert timers[0]["label"] == "tea"
    assert 290 <= timers[0]["remaining_seconds"] <= 300
