"""Cross-language contract fixture for the Chat YouTube Companion protocol.

Reads the extension's common.js directly from the repository and asserts that
every action name used by the Python bridge (apps/tool_service/companion_bridge.py)
is present in the JS COMPANION_ACTIONS array — and vice-versa.

This test runs on every `pytest` invocation.  A mismatch causes CI to fail
immediately so that drift between Python constants and the extension's JS
action list is caught before it reaches integration.

No Node.js required: the test parses the JS array with a regex (the array is
a simple one-per-line string literal, maintained by convention).

The authoritative source for the action list is:
    deployment/chrome_extension/common.js  (COMPANION_ACTIONS)

Python constants in companion_bridge.py must stay in sync with it.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

# ── Paths ─────────────────────────────────────────────────────────────────────
REPO_ROOT      = Path(__file__).parent.parent
COMMON_JS      = REPO_ROOT / "deployment/chrome_extension/common.js"
CONTRACT_JS    = REPO_ROOT / "deployment/chrome_extension/harness/contract_tests.js"


# ── Parse helpers ─────────────────────────────────────────────────────────────

def _parse_companion_actions_from_common_js() -> frozenset[str]:
    """Extract string literals from COMPANION_ACTIONS = Object.freeze([...]) in common.js.

    Returns a frozenset of action strings.
    Raises ValueError if the array cannot be found.
    """
    text = COMMON_JS.read_text(encoding="utf-8")
    # Find the COMPANION_ACTIONS array block (handles multi-line).
    m = re.search(
        r"COMPANION_ACTIONS\s*=\s*Object\.freeze\(\s*\[([^\]]*)\]",
        text,
        re.DOTALL,
    )
    if not m:
        raise ValueError(f"COMPANION_ACTIONS array not found in {COMMON_JS}")
    inner = m.group(1)
    return frozenset(re.findall(r'"([^"]+)"', inner))


def _parse_ad_blocked_from_common_js() -> frozenset[str]:
    """Return the set of actions blocked during an ad, per common.js.

    Handles two forms of the AD_BLOCKED_ACTIONS declaration:

      * an explicit literal list:
            AD_BLOCKED_ACTIONS = Object.freeze(new Set(["a", "b", ...]))
      * derivation from the full action list (block everything):
            AD_BLOCKED_ACTIONS = Object.freeze(new Set(COMPANION_ACTIONS))
    """
    text = COMMON_JS.read_text(encoding="utf-8")
    # Form 1: explicit literal array.
    m = re.search(
        r"AD_BLOCKED_ACTIONS\s*=\s*Object\.freeze\(\s*new\s+Set\(\s*\[([^\]]*)\]",
        text,
        re.DOTALL,
    )
    if m:
        return frozenset(re.findall(r'"([^"]+)"', m.group(1)))
    # Form 2: derived from COMPANION_ACTIONS (block everything).
    m = re.search(
        r"AD_BLOCKED_ACTIONS\s*=\s*Object\.freeze\(\s*new\s+Set\(\s*COMPANION_ACTIONS\s*\)",
        text,
        re.DOTALL,
    )
    if m:
        return _parse_companion_actions_from_common_js()
    raise ValueError(f"AD_BLOCKED_ACTIONS not found in {COMMON_JS}")


# ── Tests ─────────────────────────────────────────────────────────────────────

def test_common_js_exists():
    """The extension's common.js must be present in the repo."""
    assert COMMON_JS.exists(), (
        f"Extension file not found: {COMMON_JS}\n"
        "The cross-language contract test requires the extension source to be in "
        "deployment/chrome_extension/common.js"
    )


def test_all_companion_actions_matches_js():
    """ALL_COMPANION_ACTIONS in companion_bridge.py must exactly match common.js.

    This is the canonical drift-detection assertion: adding a Python constant
    without updating common.js will fail CI here, and vice-versa.
    """
    if not COMMON_JS.exists():
        pytest.skip("common.js not present — skipping contract check")
    js_actions = _parse_companion_actions_from_common_js()
    from apps.tool_service.companion_bridge import ALL_COMPANION_ACTIONS
    missing_from_python = js_actions - ALL_COMPANION_ACTIONS
    missing_from_js     = ALL_COMPANION_ACTIONS - js_actions
    assert not missing_from_python and not missing_from_js, (
        f"ALL_COMPANION_ACTIONS ↔ common.js COMPANION_ACTIONS mismatch.\n"
        f"  In JS only (need to add to Python): {sorted(missing_from_python)}\n"
        f"  In Python only (need to add to JS): {sorted(missing_from_js)}\n"
        f"  JS: {sorted(js_actions)}\n"
        f"  Python: {sorted(ALL_COMPANION_ACTIONS)}"
    )


def test_python_navigation_actions_in_js():
    """navigate_video and navigate_playlist must be in common.js COMPANION_ACTIONS."""
    if not COMMON_JS.exists():
        pytest.skip("common.js not present")
    js_actions = _parse_companion_actions_from_common_js()
    from apps.tool_service.companion_bridge import CMD_NAVIGATE_VIDEO, CMD_NAVIGATE_PLAYLIST
    assert CMD_NAVIGATE_VIDEO in js_actions, (
        f"CMD_NAVIGATE_VIDEO='{CMD_NAVIGATE_VIDEO}' not in common.js COMPANION_ACTIONS"
    )
    assert CMD_NAVIGATE_PLAYLIST in js_actions, (
        f"CMD_NAVIGATE_PLAYLIST='{CMD_NAVIGATE_PLAYLIST}' not in common.js COMPANION_ACTIONS"
    )


def test_python_transport_actions_in_js():
    """All Python transport action constants must appear in common.js COMPANION_ACTIONS."""
    if not COMMON_JS.exists():
        pytest.skip("common.js not present")
    js_actions = _parse_companion_actions_from_common_js()
    from apps.tool_service.companion_bridge import (
        CMD_PAUSE, CMD_STOP, CMD_SEEK, CMD_SET_VOLUME,
        CMD_MUTE, CMD_UNMUTE, CMD_DUCK, CMD_RESTORE,
    )
    for name, action in [
        ("CMD_PAUSE", CMD_PAUSE), ("CMD_STOP", CMD_STOP),
        ("CMD_SEEK", CMD_SEEK), ("CMD_SET_VOLUME", CMD_SET_VOLUME),
        ("CMD_MUTE", CMD_MUTE), ("CMD_UNMUTE", CMD_UNMUTE),
        ("CMD_DUCK", CMD_DUCK), ("CMD_RESTORE", CMD_RESTORE),
    ]:
        assert action in js_actions, f"{name}='{action}' not in common.js COMPANION_ACTIONS"


def test_ad_blocked_is_superset_of_js():
    """_AD_BLOCKED_ACTIONS must be a SUPERSET of common.js AD_BLOCKED_ACTIONS.

    The server enforces a stricter ad policy than the extension: it blocks
    EVERY companion action during an ad (see below), which necessarily includes
    everything the extension blocks.  It must never block LESS than the
    extension, so every JS-blocked action must also be Python-blocked.
    """
    if not COMMON_JS.exists():
        pytest.skip("common.js not present")
    js_blocked = _parse_ad_blocked_from_common_js()
    from apps.tool_service.companion_bridge import _AD_BLOCKED_ACTIONS
    missing_from_python = js_blocked - _AD_BLOCKED_ACTIONS
    assert not missing_from_python, (
        f"_AD_BLOCKED_ACTIONS must be a superset of common.js AD_BLOCKED_ACTIONS.\n"
        f"  Blocked in JS but NOT in Python: {sorted(missing_from_python)}"
    )


def test_ad_blocked_equals_all_companion_actions():
    """The server blocks EVERY companion action during an ad.

    _AD_BLOCKED_ACTIONS must equal ALL_COMPANION_ACTIONS exactly: navigation,
    transport, next/previous, volume/mute, and duck/restore are ALL rejected
    while an ad is playing.
    """
    from apps.tool_service.companion_bridge import (
        _AD_BLOCKED_ACTIONS, ALL_COMPANION_ACTIONS,
    )
    assert _AD_BLOCKED_ACTIONS == ALL_COMPANION_ACTIONS, (
        "_AD_BLOCKED_ACTIONS must equal ALL_COMPANION_ACTIONS (block everything "
        "during an ad).\n"
        f"  Not blocked: {sorted(ALL_COMPANION_ACTIONS - _AD_BLOCKED_ACTIONS)}"
    )


def test_navigate_video_constant_value():
    """CMD_NAVIGATE_VIDEO must equal the string 'navigate_video'."""
    from apps.tool_service.companion_bridge import CMD_NAVIGATE_VIDEO
    assert CMD_NAVIGATE_VIDEO == "navigate_video"


def test_navigate_playlist_constant_value():
    """CMD_NAVIGATE_PLAYLIST must equal the string 'navigate_playlist'."""
    from apps.tool_service.companion_bridge import CMD_NAVIGATE_PLAYLIST
    assert CMD_NAVIGATE_PLAYLIST == "navigate_playlist"


def test_ad_blocked_includes_duck_restore_and_skip():
    """duck, restore, next and previous must ALSO be blocked during an ad.

    The server refuses to touch the player at all while an ad is playing, so
    even the "harmless" volume ops and skip ops are rejected.
    """
    from apps.tool_service.companion_bridge import (
        _AD_BLOCKED_ACTIONS, CMD_DUCK, CMD_RESTORE, CMD_NEXT, CMD_PREVIOUS,
    )
    for action in (CMD_DUCK, CMD_RESTORE, CMD_NEXT, CMD_PREVIOUS):
        assert action in _AD_BLOCKED_ACTIONS, f"'{action}' must be ad-blocked"


def test_ad_blocked_includes_navigation_and_transport():
    """navigate_video/playlist, play, pause, stop, seek, restart, set_volume,
    adjust_volume, mute, unmute must all be blocked during an ad."""
    from apps.tool_service.companion_bridge import (
        _AD_BLOCKED_ACTIONS,
        CMD_NAVIGATE_VIDEO, CMD_NAVIGATE_PLAYLIST,
        CMD_PLAY, CMD_PAUSE, CMD_STOP, CMD_SEEK, CMD_RESTART,
        CMD_SET_VOLUME, CMD_ADJUST_VOLUME, CMD_MUTE, CMD_UNMUTE,
    )
    for action in (
        CMD_NAVIGATE_VIDEO, CMD_NAVIGATE_PLAYLIST,
        CMD_PLAY, CMD_PAUSE, CMD_STOP, CMD_SEEK, CMD_RESTART,
        CMD_SET_VOLUME, CMD_ADJUST_VOLUME, CMD_MUTE, CMD_UNMUTE,
    ):
        assert action in _AD_BLOCKED_ACTIONS, f"'{action}' must be in _AD_BLOCKED_ACTIONS"


def test_node_contract_tests_run():
    """Execute the JS contract harness via Node.js.

    The harness (deployment/chrome_extension/harness/contract_tests.js) must
    pass cleanly: its process exit code must be exactly 0.  Any non-zero exit
    is a failure and the full harness output is shown for diagnosis.

    Skipped only when Node.js is unavailable or the harness file is absent.
    """
    import shutil
    import subprocess

    node = shutil.which("node")
    if node is None:
        pytest.skip("node not available — skipping JS contract execution")
    if not CONTRACT_JS.exists():
        pytest.skip("contract_tests.js not present")

    result = subprocess.run(
        [node, str(CONTRACT_JS)],
        capture_output=True,
        text=True,
        timeout=15,
        cwd=str(REPO_ROOT),
    )
    assert result.returncode == 0, (
        f"JS contract harness FAILED (exit {result.returncode}):\n"
        f"{result.stdout}\n{result.stderr}"
    )


def test_settings_uses_server_reported_companion_bridge_address():
    """The page must never guess the bridge address or hide a TLS problem.

    A browser extension cannot approve Chat's self-signed certificate, so the
    server decides the address (the plain-ws bridge port when it is running)
    and flags the wss fallback as blocked rather than offering it silently.
    """
    app_source = (REPO_ROOT / "apps/dashboard/app.py").read_text(
        encoding="utf-8"
    )
    template = (
        REPO_ROOT / "apps/dashboard/templates/settings.html"
    ).read_text(encoding="utf-8")
    assert '"bridge_base"' in app_source
    assert "bridge_tls_blocked" in app_source
    assert "companion_bridge_port" in app_source
    assert "setBridgeUrl(r.bridge_base, r.bridge_tls_blocked)" in template
    assert "ws://127.0.0.1:" not in template
    for marker in ("🟢", "🔵", "🟡", "⚪"):
        assert marker not in template
