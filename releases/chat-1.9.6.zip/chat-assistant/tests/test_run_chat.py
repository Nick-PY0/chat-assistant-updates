from __future__ import annotations

import asyncio
import socket
import sys

import pytest

from run_chat import _acquire_windows_mutex, dashboard_port_available


def test_dashboard_port_available_detects_listener():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        port = listener.getsockname()[1]
        assert dashboard_port_available("127.0.0.1", port) is False


def test_dashboard_port_available_accepts_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    assert dashboard_port_available("127.0.0.1", port) is True


def test_mutex_returns_true_on_non_windows(monkeypatch):
    """On non-Windows the mutex acquisition always succeeds (no-op)."""
    if sys.platform == "win32":
        # Skip this particular assertion on the real Windows path
        return
    import run_chat
    run_chat._WIN_MUTEX = None
    result = _acquire_windows_mutex()
    assert result is True


def test_verify_chat_on_port_returns_false_on_wrong_service(monkeypatch):
    """_verify_chat_on_port should return False when the response is not Chat."""
    import run_chat

    def fake_urlopen(url, timeout=None, context=None):
        import io
        import json

        class FakeResp:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def read(self):
                return json.dumps({"app": "not-chat"}).encode()

        return FakeResp()

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    assert run_chat._verify_chat_on_port("127.0.0.1", 9999) is False


def test_verify_chat_on_port_returns_true_for_chat(monkeypatch):
    """_verify_chat_on_port returns True when the response identifies as chat-assistant."""
    import run_chat
    import json

    def fake_urlopen(url, timeout=None, context=None):
        class FakeResp:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def read(self):
                return json.dumps({"app": "chat-assistant"}).encode()

        return FakeResp()

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    assert run_chat._verify_chat_on_port("127.0.0.1", 9999) is True


@pytest.mark.asyncio
async def test_windows_disconnect_handler_ignores_only_expected_peer_reset(monkeypatch):
    import run_chat

    loop = asyncio.get_running_loop()
    old = loop.get_exception_handler()
    forwarded = []
    loop.set_exception_handler(lambda _loop, context: forwarded.append(context))
    monkeypatch.setattr(run_chat.sys, "platform", "win32")
    try:
        run_chat._install_windows_disconnect_handler()
        handler = loop.get_exception_handler()
        assert handler is not None

        expected = ConnectionResetError(10054, "remote host closed connection")
        expected.winerror = 10054
        handler(loop, {"exception": expected})
        assert forwarded == []

        handler(loop, {"exception": ValueError("keep reporting this")})
        assert len(forwarded) == 1
        assert isinstance(forwarded[0]["exception"], ValueError)
        assert str(forwarded[0]["exception"]) == "keep reporting this"
    finally:
        loop.set_exception_handler(old)
