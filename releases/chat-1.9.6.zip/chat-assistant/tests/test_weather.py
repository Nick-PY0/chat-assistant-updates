"""Weather: WMO mapping, forecast normalization, cache, tool wiring."""

import pytest

from apps.tool_service.weather_tool import WeatherTool
from integrations.weather import WeatherClient, WeatherError
from integrations.weather.client import wmo_text

PAYLOAD = {
    "current": {
        "temperature_2m": 29.6,
        "apparent_temperature": 33.1,
        "relative_humidity_2m": 74,
        "weather_code": 2,
        "wind_speed_10m": 14.2,
    },
    "daily": {
        "time": ["2026-08-18", "2026-08-19"],
        "temperature_2m_max": [31.0, 30.2],
        "temperature_2m_min": [24.1, 23.8],
        "weather_code": [2, 80],
        "precipitation_probability_max": [35, 70],
    },
}


def test_wmo_text():
    assert wmo_text(0) == "clear skies"
    assert wmo_text(95) == "a thunderstorm"
    assert wmo_text(999) == "changing conditions"
    assert wmo_text("nope") == "changing conditions"


async def test_forecast_normalized_and_cached(monkeypatch):
    c = WeatherClient()
    calls = []

    async def fake_get(url, params):
        calls.append(params)
        return PAYLOAD

    monkeypatch.setattr(c, "_get", fake_get)

    data = await c.forecast(6.8, -58.16, "celsius")
    assert data["unit_symbol"] == "°C"
    assert data["current"]["temp"] == 29.6
    assert data["current"]["text"] == "partly cloudy"
    assert data["today"]["high"] == 31.0
    assert data["tomorrow"]["text"] == "light showers"
    assert data["tomorrow"]["rain_chance"] == 70

    await c.forecast(6.8, -58.16, "celsius")
    assert len(calls) == 1  # cached

    f = await c.forecast(6.8, -58.16, "fahrenheit")
    assert len(calls) == 2  # different units -> separate entry
    assert f["unit_symbol"] == "°F"
    assert calls[1]["temperature_unit"] == "fahrenheit"


async def test_geocode_formatting(monkeypatch):
    c = WeatherClient()

    async def fake_get(url, params):
        return {
            "results": [
                {
                    "name": "Georgetown",
                    "admin1": "Demerara-Mahaica",
                    "country": "Guyana",
                    "latitude": 6.8,
                    "longitude": -58.16,
                }
            ]
        }

    monkeypatch.setattr(c, "_get", fake_get)
    out = await c.geocode("georgetown")
    assert out == [
        {"name": "Georgetown (Demerara-Mahaica, Guyana)", "lat": 6.8, "lon": -58.16}
    ]
    with pytest.raises(WeatherError):
        await c.geocode("x")  # too short, rejected before any network call


def test_summary_sentences():
    data = {
        "units": "celsius",
        "unit_symbol": "°C",
        "current": {"temp": 29.6, "text": "partly cloudy"},
        "today": {"text": "partly cloudy", "high": 31.0, "low": 24.1, "rain_chance": 35},
        "tomorrow": {"text": "light showers", "high": 30.2, "low": 23.8, "rain_chance": 70},
    }
    s = WeatherClient.summary_sentence(data, "today", "Georgetown")
    assert "It's 30 degrees" in s and "in Georgetown" in s and "high 31" in s

    s = WeatherClient.summary_sentence(data, "tomorrow", "Georgetown")
    assert s.startswith("Tomorrow in Georgetown") and "rain chance 70 percent" in s


async def test_weather_tool_requires_location(settings):
    tool = WeatherTool(settings)
    with pytest.raises(WeatherError):
        await tool.get()


async def test_weather_tool_summary(settings, monkeypatch):
    settings.location_name = "Georgetown (Demerara-Mahaica, Guyana)"
    settings.location_lat = 6.8
    settings.location_lon = -58.16
    tool = WeatherTool(settings)
    assert tool.spoken_location() == "Georgetown"

    async def fake_forecast(lat, lon, units):
        assert (lat, lon, units) == (6.8, -58.16, "celsius")
        return {
            "units": "celsius",
            "unit_symbol": "°C",
            "current": {"temp": 29.6, "text": "partly cloudy"},
            "today": {"text": "partly cloudy", "high": 31.0, "low": 24.1, "rain_chance": 35},
            "tomorrow": {"text": "light showers", "high": 30.2, "low": 23.8, "rain_chance": 70},
        }

    monkeypatch.setattr(tool.client, "forecast", fake_forecast)
    got = await tool.get("tomorrow")
    assert got["day"] == "tomorrow"
    assert "Tomorrow in Georgetown" in got["summary"]
