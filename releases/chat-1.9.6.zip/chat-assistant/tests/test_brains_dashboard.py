"""Dashboard support for the brains: settings fields and provider cards."""

from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_ok(secret, timeout=10.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_ok)
    monkeypatch.setattr(dashboard_module, "validate_openai_key", fake_ok)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def login(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    token = client.cookies.get(COOKIE)
    return {"x-csrf": client.app.state.sessions.csrf_for(token)}


async def test_brain_settings_roundtrip(client, rt):
    headers = await login(client)
    r = await client.post("/api/settings", json={
        "voice_brain": "relay",
        "relay_url": "https://myrelay.replit.app",
        "relay_chat_model": "gpt-5.6-sol",
        "relay_command_model": "gpt-5-mini",
        "relay_voice": "nova",
        "relay_daily_request_cap": 50,
        "openai_live_model": "gpt-realtime",
        "openai_voice": "echo",
    }, headers=headers)
    assert r.status_code == 200
    assert rt.settings.voice_brain == "relay"
    assert rt.settings.relay_url == "https://myrelay.replit.app"
    assert rt.settings.relay_chat_model == "gpt-5.6-sol"
    assert rt.settings.relay_daily_request_cap == 50
    assert rt.settings.openai_voice == "echo"


async def test_relay_url_must_be_https(client, rt):
    headers = await login(client)
    r = await client.post("/api/settings",
                          json={"relay_url": "http://sketchy.example"},
                          headers=headers)
    assert r.status_code == 400
    assert rt.settings.relay_url != "http://sketchy.example"
    # a bare address is quietly upgraded to https
    r2 = await client.post("/api/settings",
                           json={"relay_url": "myrelay.replit.app"},
                           headers=headers)
    assert r2.status_code == 200
    assert rt.settings.relay_url == "https://myrelay.replit.app"


async def test_add_openai_key_and_list_it(client, rt):
    headers = await login(client)
    r = await client.post(
        "/api/credentials",
        json={"provider": "openai", "secret": "sk-proj-abc123def456"},
        headers=headers)
    assert r.status_code == 200
    listing = (await client.get("/api/credentials")).json()
    assert len(listing["openai"]) == 1
    assert listing["openai"][0]["status"] in ("standby", "active")
    # secrets never come back
    assert "sk-proj" not in str(listing)


async def test_add_relay_password_without_url_warns(client, rt):
    headers = await login(client)
    rt.settings.relay_url = ""
    r = await client.post(
        "/api/credentials",
        json={"provider": "relay", "secret": "family-password-1"},
        headers=headers)
    assert r.status_code == 200
    assert "Settings" in r.json().get("warning", "")
    listing = (await client.get("/api/credentials")).json()
    assert len(listing["relay"]) == 1


async def test_relay_password_is_checked_when_url_is_set(client, rt, monkeypatch):
    headers = await login(client)
    rt.settings.relay_url = "https://myrelay.replit.app"

    class FakeRelay:
        def __init__(self, url, secret, **kw):
            self.secret = secret

        async def health(self):
            if self.secret != "right-password":
                raise dashboard_module.RelayError(
                    "the relay refused the password (check Providers -> Relay).")

    monkeypatch.setattr(dashboard_module, "RelayClient", FakeRelay)
    r = await client.post(
        "/api/credentials",
        json={"provider": "relay", "secret": "wrong-password"},
        headers=headers)
    assert r.status_code == 400
    r2 = await client.post(
        "/api/credentials",
        json={"provider": "relay", "secret": "right-password"},
        headers=headers)
    assert r2.status_code == 200
    assert not r2.json().get("warning")


async def test_unknown_provider_rejected(client):
    headers = await login(client)
    r = await client.post(
        "/api/credentials",
        json={"provider": "anthropic", "secret": "sk-ant-xxxxxxxx"},
        headers=headers)
    assert r.status_code == 400
