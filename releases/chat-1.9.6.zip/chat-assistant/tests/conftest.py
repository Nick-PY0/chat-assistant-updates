from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from chat_core.config import Settings  # noqa: E402
from chat_core.events import EventBus  # noqa: E402
from chat_core.models.credentials import CredentialStore  # noqa: E402
from chat_core.models.db import Database  # noqa: E402
from chat_core.security.vault import Vault  # noqa: E402


@pytest.fixture
def settings(tmp_path) -> Settings:
    s = Settings()
    s.data_dir = str(tmp_path)
    s.low_power = False
    s.unavailable_retry_seconds = 0
    return s


@pytest.fixture
async def db(settings):
    database = Database(settings.db_path)
    await database.open()
    yield database
    await database.close()


@pytest.fixture
def vault() -> Vault:
    return Vault(b"m" * 32)


@pytest.fixture
def bus() -> EventBus:
    return EventBus()


@pytest.fixture
async def store(db, vault) -> CredentialStore:
    return CredentialStore(db, vault)
