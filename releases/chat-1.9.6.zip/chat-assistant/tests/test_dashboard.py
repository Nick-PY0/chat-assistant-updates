"""Dashboard security + API behavior via in-process ASGI transport."""

from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def do_setup(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    assert client.cookies.get(COOKIE)


async def test_first_run_forces_setup(client):
    resp = await client.get("/")
    assert resp.status_code == 303
    assert resp.headers["location"] == "/setup"


async def test_setup_rejects_cross_site_posts(client):
    """A hostile web page must not be able to claim an unclaimed dashboard."""
    resp = await client.post(
        "/setup",
        data={"password": "attacker-pass1", "confirm": "attacker-pass1"},
        headers={"origin": "http://evil.example"},
    )
    assert resp.status_code == 403

    resp = await client.post(
        "/setup",
        data={"password": "attacker-pass1", "confirm": "attacker-pass1"},
        headers={"sec-fetch-site": "cross-site"},
    )
    assert resp.status_code == 403

    # same-origin browser post still works
    resp = await client.post(
        "/setup",
        data={"password": "legit-pass-123", "confirm": "legit-pass-123"},
        headers={"origin": "http://test", "host": "test", "sec-fetch-site": "same-origin"},
    )
    assert resp.status_code == 303


async def test_login_rejects_cross_site_posts(client):
    await do_setup(client)
    client.cookies.delete(COOKIE)
    resp = await client.post(
        "/login",
        data={"password": "hunter2secure"},
        headers={"origin": "http://evil.example"},
    )
    assert resp.status_code == 403


async def test_logout_requires_csrf(client):
    await do_setup(client)
    resp = await client.post("/logout", data={"_csrf": "forged"})
    assert resp.status_code == 403
    resp = await client.post("/logout", data={"_csrf": await csrf_of(client)})
    assert resp.status_code == 303


async def test_api_requires_auth(client):
    resp = await client.get("/api/state")
    assert resp.status_code == 401


async def test_setup_then_login_flow(client):
    await do_setup(client)
    resp = await client.get("/")
    assert resp.status_code == 200

    # sign out, wrong password rejected, right password accepted
    client.cookies.delete(COOKIE)
    resp = await client.post("/login", data={"password": "wrong-password"})
    assert resp.status_code == 401
    resp = await client.post("/login", data={"password": "hunter2secure"})
    assert resp.status_code == 303


async def test_login_rate_limit(client):
    await do_setup(client)
    client.cookies.delete(COOKIE)
    for _ in range(5):
        await client.post("/login", data={"password": "bad-guess-123"})
    resp = await client.post("/login", data={"password": "bad-guess-123"})
    assert resp.status_code == 429


async def test_csrf_required_on_writes(client):
    await do_setup(client)
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": "AIzaExampleKey001"},
        headers={"x-csrf": "forged"},
    )
    assert resp.status_code == 403


async def test_add_credential_returns_only_mask(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    secret = "AIzaSyRealSecretKey12345"
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": secret, "project_label": "proj-a"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert secret not in resp.text
    assert body["credential"]["masked_suffix"].endswith("2345")

    listing = await client.get("/api/credentials")
    assert secret not in listing.text
    projects = listing.json()["projects"]
    assert len(projects) == 1
    assert projects[0]["label"] == "proj-a"


async def test_credential_lifecycle_actions(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": "AIzaKeyLifecycle1"},
        headers={"x-csrf": csrf},
    )
    cred_id = resp.json()["credential"]["id"]

    for action, expected in (("disable", "disabled"), ("enable", "standby")):
        resp = await client.post(
            f"/api/credentials/{cred_id}/action", json={"action": action}, headers={"x-csrf": csrf}
        )
        assert resp.status_code == 200
        listing = (await client.get("/api/credentials")).json()
        assert listing["projects"][0]["keys"][0]["status"] == expected

    resp = await client.post(
        f"/api/credentials/{cred_id}/action", json={"action": "delete"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200
    assert (await client.get("/api/credentials")).json()["projects"] == []


async def test_timers_and_command_box(client):
    await do_setup(client)
    csrf = await csrf_of(client)

    resp = await client.post(
        "/api/command", json={"text": "set a tea timer for 9 minutes"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200
    assert resp.json()["command"]["tool"] == "start_timer"

    timers = (await client.get("/api/timers")).json()["timers"]
    assert len(timers) == 1 and timers[0]["label"] == "tea"

    resp = await client.post(
        f"/api/timers/{timers[0]['id']}/cancel", json={}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200

    resp = await client.post(
        "/api/command", json={"text": "order me a pizza"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 400


async def test_mute_toggle_persists(client, rt):
    await do_setup(client)
    csrf = await csrf_of(client)
    resp = await client.post("/api/mute", json={"muted": True}, headers={"x-csrf": csrf})
    assert resp.json()["muted"] is True
    assert await rt.db.get_setting("muted") == "1"
    state = (await client.get("/api/state")).json()
    assert state["state"]["state"] == "MUTED"


async def test_password_change(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    resp = await client.post(
        "/api/password",
        json={"current": "wrong", "new": "newpassword99"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 403
    resp = await client.post(
        "/api/password",
        json={"current": "hunter2secure", "new": "newpassword99"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 200
    client.cookies.delete(COOKIE)
    resp = await client.post("/login", data={"password": "newpassword99"})
    assert resp.status_code == 303
