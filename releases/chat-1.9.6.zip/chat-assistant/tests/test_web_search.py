import httpx
import pytest

from integrations.web_search import WebSearchClient, WebSearchError


RSS = b"""<?xml version='1.0'?><rss><channel>
<item><title>First &amp; best</title><link>https://example.com/one</link>
<description><![CDATA[<b>Useful</b> summary]]></description>
<pubDate>Wed, 19 Aug 2026 01:00:00 GMT</pubDate><source>Example</source></item>
<item><title>Second</title><link>https://example.net/two</link></item>
</channel></rss>"""


@pytest.mark.asyncio
async def test_web_search_is_fixed_endpoint_and_parses_rss():
    seen = {}

    async def handler(request):
        seen["url"] = str(request.url)
        return httpx.Response(200, content=RSS)

    client = WebSearchClient(transport=httpx.MockTransport(handler))
    data = await client.search("  local   weather ", max_results=1)
    assert seen["url"].startswith("https://www.bing.com/search?")
    assert "q=local+weather" in seen["url"]
    assert data["query"] == "local weather"
    assert data["results"] == [{
        "title": "First & best",
        "url": "https://example.com/one",
        "snippet": "Useful summary",
        "source": "Example",
        "published": "Wed, 19 Aug 2026 01:00:00 GMT",
    }]


@pytest.mark.asyncio
async def test_news_supports_top_headlines_without_query():
    seen = {}

    async def handler(request):
        seen["url"] = str(request.url)
        return httpx.Response(200, content=RSS)

    data = await WebSearchClient(transport=httpx.MockTransport(handler)).news()
    assert seen["url"].startswith("https://news.google.com/rss?")
    assert data["query"] == "top headlines"
    assert len(data["results"]) == 2


@pytest.mark.asyncio
async def test_search_rejects_empty_or_oversized_queries():
    client = WebSearchClient()
    with pytest.raises(WebSearchError):
        await client.search("   ")
    with pytest.raises(WebSearchError):
        await client.search("x" * 241)
