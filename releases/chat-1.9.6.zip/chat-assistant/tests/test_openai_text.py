import json

import httpx
import pytest

from integrations.openai_text import (
    OpenAIResponsesClient,
    OpenAITextError,
    response_result,
    to_responses_tools,
)


@pytest.mark.asyncio
async def test_responses_client_posts_supported_payload():
    seen = {}

    async def handler(request):
        seen["authorization"] = request.headers.get("authorization")
        seen["body"] = json.loads(request.content)
        return httpx.Response(200, json={"id": "resp_1", "output": []})

    client = OpenAIResponsesClient("secret", transport=httpx.MockTransport(handler))
    result = await client.create({"model": "gpt-5-mini", "input": "hello"})
    assert result["id"] == "resp_1"
    assert seen == {
        "authorization": "Bearer secret",
        "body": {"model": "gpt-5-mini", "input": "hello"},
    }


def test_response_result_extracts_text_calls_and_unique_sources():
    data = {
        "id": "resp_2",
        "model": "gpt-5-mini",
        "status": "completed",
        "usage": {"input_tokens": 12, "output_tokens": 4},
        "output": [
            {"type": "message", "content": [{
                "type": "output_text",
                "text": "Answer",
                "annotations": [
                    {"type": "url_citation", "title": "Example", "url": "https://example.com"},
                    {"type": "url_citation", "title": "Again", "url": "https://example.com"},
                ],
            }]},
            {"type": "function_call", "call_id": "c1", "name": "get_current_time", "arguments": "{}"},
        ],
    }
    result = response_result(data)
    assert result["text"] == "Answer"
    assert result["tool_calls"] == [{"call_id": "c1", "name": "get_current_time", "arguments": {}}]
    assert result["sources"] == [{"title": "Example", "url": "https://example.com"}]


@pytest.mark.asyncio
async def test_responses_client_surfaces_api_message():
    async def handler(request):
        return httpx.Response(400, json={"error": {"message": "bad request"}})

    client = OpenAIResponsesClient("secret", transport=httpx.MockTransport(handler))
    with pytest.raises(OpenAITextError, match="bad request"):
        await client.create({})


def test_tool_schema_conversion_lowers_json_schema_types():
    tools = to_responses_tools([{
        "name": "search_web",
        "description": "Search",
        "parameters": {
            "type": "OBJECT",
            "properties": {"query": {"type": "STRING"}},
            "required": ["query"],
        },
    }])
    assert tools == [{
        "type": "function",
        "name": "search_web",
        "description": "Search",
        "parameters": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
        "strict": False,
    }]
