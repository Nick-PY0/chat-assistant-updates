"""The user's rotation policy: every key participates, same-label keys share
one quota group, exhaustion moves to the next project immediately."""

from datetime import timedelta

import pytest

from apps.live_gateway.rotation import NoEligibleKey, RotationPolicy
from chat_core.models.credentials import utcnow


@pytest.fixture
async def keys(store):
    k1 = await store.add("gemini", "AIzaKeyOne0001", project_label="p1")  # auto-active
    k2 = await store.add("gemini", "AIzaKeyTwo0002", project_label="p1")  # same quota group
    k3 = await store.add("gemini", "AIzaKeyThree03", project_label="p2")
    return k1, k2, k3


async def test_first_key_is_active_and_sticky(store, keys):
    k1, _, _ = keys
    policy = RotationPolicy(store)
    picked = await policy.pick()
    assert picked.id == k1.id
    assert picked.status == "active"


async def test_same_project_keys_share_one_group(store, keys):
    k1, k2, k3 = keys
    assert k1.project_fingerprint == k2.project_fingerprint
    assert k1.project_fingerprint != k3.project_fingerprint


async def test_quota_exhaustion_blocks_group_and_rotates_project(store, keys):
    k1, k2, k3 = keys
    policy = RotationPolicy(store)
    retry = utcnow() + timedelta(hours=6)
    blocked = await store.mark_project_exhausted(k1.project_fingerprint, retry)
    assert blocked == 2  # both same-label keys blocked together

    picked = await policy.pick()
    assert picked.id == k3.id  # rotation jumped to the other project


async def test_unlabeled_keys_are_their_own_groups(store):
    a = await store.add("gemini", "AIzaSoloA00001")
    b = await store.add("gemini", "AIzaSoloB00002")
    assert a.project_fingerprint != b.project_fingerprint


async def test_all_blocked_raises_with_earliest_retry(store, keys):
    k1, k2, k3 = keys
    policy = RotationPolicy(store)
    early = utcnow() + timedelta(hours=2)
    late = utcnow() + timedelta(hours=9)
    await store.mark_project_exhausted(k1.project_fingerprint, late)
    await store.mark_project_exhausted(k3.project_fingerprint, early)
    with pytest.raises(NoEligibleKey) as exc:
        await policy.pick()
    assert exc.value.earliest_retry is not None
    assert abs((exc.value.earliest_retry - early).total_seconds()) < 2


async def test_invalid_and_disabled_never_selected(store, keys):
    k1, k2, k3 = keys
    policy = RotationPolicy(store)
    await store.set_status(k1.id, "invalid", "invalid")
    await store.set_status(k2.id, "disabled")
    picked = await policy.pick()
    assert picked.id == k3.id
    await store.set_status(k3.id, "invalid", "invalid")
    with pytest.raises(NoEligibleKey):
        await policy.pick()


async def test_release_expired_blocks(store, keys):
    k1, k2, k3 = keys
    await store.mark_project_exhausted(k1.project_fingerprint, utcnow() - timedelta(minutes=1))
    released = await store.release_expired_blocks()
    assert set(released) == {k1.id, k2.id}
    fresh = await store.get(k1.id)
    assert fresh.status == "standby"
    assert fresh.retry_after is None


async def test_make_active_promotes_single_key(store, keys):
    k1, k2, k3 = keys
    policy = RotationPolicy(store)
    await policy.promote(k3.id)
    assert (await store.get(k3.id)).status == "active"
    assert (await store.get(k1.id)).status == "standby"
    picked = await policy.pick()
    assert picked.id == k3.id


async def test_preferred_key_wins_when_eligible(store, keys):
    k1, k2, k3 = keys
    policy = RotationPolicy(store)
    picked = await policy.pick(prefer_id=k2.id)
    assert picked.id == k2.id
    # but a blocked preferred key cannot be forced
    await store.set_status(k2.id, "invalid", "invalid")
    picked = await policy.pick(prefer_id=k2.id)
    assert picked.id != k2.id
