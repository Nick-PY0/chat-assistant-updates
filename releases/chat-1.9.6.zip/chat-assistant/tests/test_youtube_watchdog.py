"""Regression tests: YouTube owner watchdog expires dead media owners.

Verifies that:
1. When the watchdog fires after OWNER_LEASE_SECONDS, on_playing(False) is called
   and owner is cleared even without any API call.
2. The watchdog task is properly cancelled by stop_watchdog().
3. The watchdog does not fire prematurely (before lease expiry).
"""

from __future__ import annotations

import asyncio
import time

import pytest

from apps.tool_service.youtube_tool import YouTubeTool, OWNER_LEASE_SECONDS
from chat_core.events import EventBus


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _make_tool(bus: EventBus, interval: float = 0.05) -> tuple[YouTubeTool, list[bool]]:
    """Create a YouTubeTool with playing-state log and a fast watchdog interval."""
    playing_log: list[bool] = []

    def on_playing(playing: bool) -> None:
        playing_log.append(playing)

    tool = YouTubeTool(bus=bus, credentials=None, on_playing=on_playing)
    return tool, playing_log


# ---------------------------------------------------------------------------
# Test 1: watchdog expires owner after lease timeout (deterministic)
# ---------------------------------------------------------------------------

async def test_watchdog_expires_owner_after_lease(bus: EventBus):
    """The watchdog task proactively fires on_playing(False) when the owner's
    heartbeat has not been seen for OWNER_LEASE_SECONDS."""
    tool, playing_log = _make_tool(bus, interval=0.05)

    # Simulate an owner claiming the player.
    tool.owner_id = "page-abc"
    tool.owner_label = "Test Tab"
    tool.status = "playing"
    # Back-date the last-seen timestamp so the lease is already expired.
    tool._owner_seen = time.monotonic() - (OWNER_LEASE_SECONDS + 1)

    tool.start_watchdog(interval=0.05)
    # Wait for at least one watchdog tick.
    await asyncio.sleep(0.15)
    await tool.stop_watchdog()

    assert tool.owner_id == "", f"Expected owner cleared; got '{tool.owner_id}'"
    assert False in playing_log, "Expected on_playing(False) to have been called"


# ---------------------------------------------------------------------------
# Test 2: watchdog does NOT fire before lease expires
# ---------------------------------------------------------------------------

async def test_watchdog_does_not_expire_fresh_owner(bus: EventBus):
    """A freshly claimed owner (heartbeat just set) is not expired by the watchdog."""
    tool, playing_log = _make_tool(bus, interval=0.05)

    tool.owner_id = "page-fresh"
    tool.owner_label = "Fresh Tab"
    tool.status = "playing"
    tool._owner_seen = time.monotonic()  # just now

    tool.start_watchdog(interval=0.05)
    await asyncio.sleep(0.15)
    await tool.stop_watchdog()

    assert tool.owner_id == "page-fresh", (
        "Fresh owner should not be expired by the watchdog"
    )
    assert True not in playing_log or playing_log == [], (
        "on_playing(False) should not be called for a fresh owner"
    )


# ---------------------------------------------------------------------------
# Test 3: stop_watchdog() cancels the task cleanly
# ---------------------------------------------------------------------------

async def test_stop_watchdog_cancels_task(bus: EventBus):
    """stop_watchdog returns without error and the task is cleaned up."""
    tool, _ = _make_tool(bus)
    tool.start_watchdog(interval=0.05)

    task = tool._watchdog_task
    assert task is not None
    assert not task.done()

    await tool.stop_watchdog()

    assert task.done()
    assert tool._watchdog_task is None


# ---------------------------------------------------------------------------
# Test 4: duplicate start_watchdog is idempotent
# ---------------------------------------------------------------------------

async def test_start_watchdog_is_idempotent(bus: EventBus):
    """Calling start_watchdog twice does not create a second task."""
    tool, _ = _make_tool(bus)
    tool.start_watchdog(interval=0.05)
    first_task = tool._watchdog_task

    tool.start_watchdog(interval=0.05)  # second call must be a no-op
    assert tool._watchdog_task is first_task, (
        "start_watchdog() must be idempotent; it created a second task"
    )

    await tool.stop_watchdog()


# ---------------------------------------------------------------------------
# Test 5: mic gate (on_playing) is notified of expiry
# ---------------------------------------------------------------------------

async def test_watchdog_notifies_on_playing_callback_on_expiry(bus: EventBus):
    """The on_playing callback (wired to Runtime.set_media_playing → audio gate)
    is called with False when the watchdog expires the owner, ensuring the mic
    gate un-gates even when the player page simply closed without sending pagehide."""
    tool, playing_log = _make_tool(bus, interval=0.05)

    # Owner exists and is expired.
    tool.owner_id = "crashed-tab"
    tool._owner_seen = time.monotonic() - (OWNER_LEASE_SECONDS + 5)
    tool.status = "playing"

    tool.start_watchdog(interval=0.05)
    await asyncio.sleep(0.2)
    await tool.stop_watchdog()

    assert playing_log.count(False) >= 1, (
        "Expected at least one on_playing(False) call after watchdog expiry"
    )
    assert tool.owner_id == ""
