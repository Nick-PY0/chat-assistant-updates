"""Tests for the /voice-controller page and /api/providers/summary endpoint."""

from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def signed_in(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    return {"x-csrf": await csrf_of(client)}


# ---- /voice-controller page ------------------------------------------------

async def test_voice_controller_page_requires_auth(client):
    """The voice-controller page must redirect to login when not signed in."""
    resp = await client.get("/voice-controller")
    assert resp.status_code == 303
    assert "/login" in resp.headers["location"] or "/setup" in resp.headers["location"]


async def test_voice_controller_page_renders(client):
    """After signing in the page must render with the JS bundle."""
    await signed_in(client)
    resp = await client.get("/voice-controller")
    assert resp.status_code == 200
    body = resp.text
    assert "voice_controller.js" in body
    assert "Listen for Hey Jarvis" in body
    # must contain CSRF meta tag
    assert 'name="csrf"' in body


async def test_voice_controller_page_has_no_nav_links(client):
    """The voice-controller page is a lightweight standalone window (no sidebar nav)."""
    await signed_in(client)
    resp = await client.get("/voice-controller")
    body = resp.text
    # Should not include the full sidebar navigation
    assert 'href="/credentials"' not in body
    assert 'href="/logs"' not in body


# ---- /api/providers/summary ------------------------------------------------

async def test_providers_summary_requires_auth(client):
    resp = await client.get("/api/providers/summary")
    assert resp.status_code == 401


async def test_providers_summary_structure(client, rt):
    """The providers summary must return all expected sections."""
    await signed_in(client)
    resp = await client.get("/api/providers/summary")
    assert resp.status_code == 200
    data = resp.json()
    assert "gemini" in data
    assert "openai_live" in data
    assert "relay" in data
    assert "voice_pipeline" in data
    assert "typed_chat" in data
    assert "remote_mic" in data
    assert "media_player" in data


async def test_providers_summary_no_secrets(client, rt):
    """Secrets must never appear in the providers summary."""
    await signed_in(client)
    # Add a fake credential to ensure nothing leaks
    hdrs = {"x-csrf": await csrf_of(client)}
    # We don't add a real key; just verify the summary does not expose fields
    resp = await client.get("/api/providers/summary")
    body = resp.text
    assert "secret" not in body.lower()
    assert "password" not in body.lower()
    assert "AIza" not in body  # typical Gemini key prefix


async def test_providers_summary_gemini_counts(client, rt):
    """eligible_keys and total_keys must be integers >= 0."""
    await signed_in(client)
    data = (await client.get("/api/providers/summary")).json()
    assert isinstance(data["gemini"]["total_keys"], int)
    assert data["gemini"]["total_keys"] >= 0
    assert isinstance(data["gemini"]["eligible_keys"], int)
    assert data["gemini"]["eligible_keys"] >= 0


async def test_providers_summary_typed_chat_fields(client, rt):
    """typed_chat section must include provider and model names."""
    await signed_in(client)
    data = (await client.get("/api/providers/summary")).json()
    tc = data["typed_chat"]
    assert "provider" in tc
    assert "model" in tc
    assert "ok" in tc


async def test_providers_summary_relay_address_masked_when_empty(client, rt):
    """When no relay URL is configured, address must be null, not an empty string."""
    await signed_in(client)
    rt.settings.relay_url = ""
    data = (await client.get("/api/providers/summary")).json()
    assert data["relay"]["address"] is None


# ---- base.html voice-controller button ------------------------------------

async def test_base_has_voice_controller_button(client):
    """Every authenticated page must include the Talk-on-this-device button."""
    await signed_in(client)
    resp = await client.get("/")  # status page uses base.html
    assert resp.status_code == 200
    assert "voice-ctrl-btn" in resp.text
    assert "Talk on this device" in resp.text


# ---- settings page simplification ----------------------------------------

async def test_settings_has_advanced_details(client):
    """Settings page must have a collapsed details block for advanced options."""
    await signed_in(client)
    resp = await client.get("/settings")
    assert resp.status_code == 200
    body = resp.text
    assert "<details" in body
    assert "Advanced settings" in body


async def test_settings_typed_provider_selector(client):
    """Settings page must include the typed-chat provider selector."""
    await signed_in(client)
    resp = await client.get("/settings")
    assert "s-typed-provider" in resp.text


async def test_settings_primary_fields_visible(client):
    """Key user-facing fields must be outside the advanced block (appear before it)."""
    await signed_in(client)
    resp = await client.get("/settings")
    body = resp.text
    # Voice brain and relay URL must appear before the advanced details block
    brain_pos = body.find("s-brain")
    relay_pos = body.find("s-relay-url")
    details_pos = body.find("<details")
    assert brain_pos < details_pos, "Voice brain selector must appear before advanced block"
    assert relay_pos < details_pos, "Relay URL must appear before advanced block"


# ---- chat.html branding ---------------------------------------------------

async def test_chat_page_no_jarvis_branding(client):
    """The chat page must not use 'Jarvis' as a product name."""
    await signed_in(client)
    resp = await client.get("/chat")
    body = resp.text
    # 'Jarvis' must not appear as a label or placeholder
    # (The aria-label and placeholder should say 'Chat')
    assert 'aria-label="Jarvis' not in body
    assert 'placeholder="Message Jarvis"' not in body
