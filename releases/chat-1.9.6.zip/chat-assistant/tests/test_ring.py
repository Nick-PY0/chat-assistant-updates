"""Alarm ring generator: format, loudness, caching, volume clamp."""

import array

from apps.audio.ring import RING_RATE, build_ring_cycle


def test_ring_cycle_shape_and_loudness():
    pcm = build_ring_cycle(1.0)
    assert len(pcm) == RING_RATE * 2 * 2  # 2 seconds of 16-bit mono
    samples = array.array("h", pcm)
    peak = max(abs(s) for s in samples)
    assert 10000 < peak <= 32767  # audibly loud, never clipping past int16


def test_ring_cycle_cached_and_clamped():
    assert build_ring_cycle(1.0) is build_ring_cycle(1.0)  # cache hit
    assert build_ring_cycle(0.05) == build_ring_cycle(0.2)  # clamped to floor
    quiet = array.array("h", build_ring_cycle(0.2))
    loud = array.array("h", build_ring_cycle(1.0))
    assert max(abs(s) for s in quiet) < max(abs(s) for s in loud)
