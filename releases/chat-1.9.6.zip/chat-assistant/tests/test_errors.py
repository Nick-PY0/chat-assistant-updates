from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from integrations.gemini.errors import (
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
    classify,
    next_quota_reset,
)


def test_auth_failures_are_invalid():
    assert classify(401, "").code == INVALID
    assert classify(403, "permission denied").code == INVALID
    assert classify(400, "API key not valid. Please pass a valid API key.").code == INVALID


def test_short_rate_limit_backs_off_briefly():
    body = (
        '{"error": {"code": 429, "status": "RESOURCE_EXHAUSTED", "details": ['
        '{"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": "7s"}]}}'
    )
    now = datetime.now(timezone.utc)
    failure = classify(429, body, now=now)
    assert failure.code == RATE_LIMITED
    assert failure.retry_after is not None
    assert timedelta(seconds=0) < failure.retry_after - now < timedelta(seconds=60)


def test_daily_quota_blocks_until_midnight_pacific():
    body = (
        '{"error": {"code": 429, "status": "RESOURCE_EXHAUSTED", "message": '
        '"You exceeded your current quota. Limit: GenerateRequestsPerDay"}}'
    )
    failure = classify(429, body)
    assert failure.code == QUOTA_EXHAUSTED
    assert failure.retry_after is not None
    pt = failure.retry_after.astimezone(ZoneInfo("America/Los_Angeles"))
    assert (pt.hour, pt.minute) == (0, 5)  # midnight PT + 300s jitter
    assert failure.retry_after > datetime.now(timezone.utc)


def test_server_errors_are_unavailable():
    assert classify(503, "backend error").code == UNAVAILABLE
    assert classify(None, "connection refused").code == UNAVAILABLE


def test_next_quota_reset_is_future_and_pacific_midnight():
    reset = next_quota_reset(jitter_seconds=0)
    assert reset > datetime.now(timezone.utc)
    pt = reset.astimezone(ZoneInfo("America/Los_Angeles"))
    assert (pt.hour, pt.minute, pt.second) == (0, 0, 0)
