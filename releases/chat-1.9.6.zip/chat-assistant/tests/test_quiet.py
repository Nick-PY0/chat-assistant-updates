"""Quiet mode: announcement gating, persistence, ring suppression."""

import asyncio

import pytest

from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
def spoken(rt, monkeypatch):
    calls = []
    monkeypatch.setattr(rt.announcer, "announce", lambda key: calls.append(key))
    return calls


async def test_announce_gating(rt, spoken):
    rt.quiet = True
    rt._announce("timer_missed", cooldown=0)  # unprompted -> swallowed
    assert spoken == []
    rt._announce("ok", cooldown=0)  # direct response -> audible
    assert spoken == ["ok"]

    rt._announce("timer_done", cooldown=0)  # scheduled by the user -> rings
    assert spoken == ["ok", "timer_done"]

    rt.settings.quiet_override_alarms = False
    rt._announce("timer_done", cooldown=0)  # override off -> silent too
    assert spoken == ["ok", "timer_done"]


async def test_set_quiet_confirms_and_persists(rt, spoken):
    await rt.set_quiet(True)
    assert rt.quiet is True
    assert spoken == ["quiet_on"]  # confirmed out loud before going quiet
    assert await rt.db.get_setting("quiet_mode") == "1"

    await rt.set_quiet(True)  # no change -> no repeat announcement
    assert spoken == ["quiet_on"]

    await rt.set_quiet(False)
    assert spoken == ["quiet_on", "quiet_off"]
    assert await rt.db.get_setting("quiet_mode") == "0"


async def test_quiet_restored_on_restart(settings):
    r1 = Runtime(settings)
    await r1.start(voice=False, cloud=False, monitoring=False)
    r1.announcer.announce = lambda key: None
    await r1.set_quiet(True)
    await r1.stop()

    r2 = Runtime(settings)
    await r2.start(voice=False, cloud=False, monitoring=False)
    try:
        assert r2.quiet is True
    finally:
        await r2.stop()


async def test_ring_suppressed_only_without_override(rt, spoken):
    rt.quiet = True
    rt.settings.quiet_override_alarms = False
    await rt._begin_ring({"id": "r_x", "kind": "alarm", "message": ""})
    assert rt.ringing is None and rt._ring_task is None

    rt.settings.quiet_override_alarms = True
    await rt._begin_ring({"id": "r_x", "kind": "alarm", "message": ""})
    assert rt.ringing is not None
    rt.stop_output()  # dismiss immediately
    await asyncio.wait_for(rt._ring_task, timeout=10)
    assert rt.ringing is None


async def test_voice_commands(rt, spoken):
    got = await rt.handle_local_utterance("be quiet")  # stays a plain stop
    assert got == {"stopped": True}
    assert rt.quiet is False

    await rt.handle_local_utterance("quiet mode on")
    assert rt.quiet is True
    await rt.handle_local_utterance("you can talk now")
    assert rt.quiet is False


async def test_simultaneous_rings_queue(rt):
    """Two reminders due at once: the second rings after the first is
    dismissed instead of being silently dropped."""
    import asyncio

    await rt._begin_ring({"id": "a", "kind": "alarm", "message": ""})
    await rt._begin_ring({"id": "b", "kind": "alarm", "message": ""})
    for _ in range(100):
        if rt.ringing and rt.ringing["id"] == "a":
            break
        await asyncio.sleep(0.02)
    assert rt.ringing and rt.ringing["id"] == "a"
    assert len(rt._ring_pending) == 1

    rt.stop_output()  # dismiss the first
    for _ in range(200):
        if rt.ringing and rt.ringing["id"] == "b":
            break
        await asyncio.sleep(0.02)
    assert rt.ringing and rt.ringing["id"] == "b"

    rt.stop_output()  # each ring needs its own dismissal
    await asyncio.wait_for(rt._ring_task, timeout=5)
    assert rt.ringing is None and not rt._ring_pending
