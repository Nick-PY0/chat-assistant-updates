"""Chat must gate the microphone for *audible* media only.

The microphone gate exists to reject music leaking from the speakers.  A muted
player, a zero-volume player and a paused player make no sound, so gating for
them only makes Chat deaf to the person talking to it.
"""

from __future__ import annotations

import pytest

from apps.tool_service.youtube_tool import YouTubeTool

VIDEO_A = "dQw4w9WgXcQ"


class FakeCompanion:
    """Connected companion double that acks every command."""

    TARGET_ID = "browser_companion"

    def __init__(self) -> None:
        self.connected = True
        self.commands: list[dict] = []
        self._session = 0
        self.ad_playing = False

    def bump_session(self) -> int:
        self._session += 1
        return self._session

    @property
    def session(self) -> int:
        return self._session

    async def send_command(self, action, **args):
        self.commands.append({"action": action, **args})
        return {"ok": True, "error": ""}


def make_tool(bus, store):
    """A companion-backed tool recording every audibility report."""
    audible: list[bool] = []
    yt = YouTubeTool(bus, store, on_playing=audible.append, open_browser=lambda u: None)
    yt.register_companion(FakeCompanion())
    return yt, audible


@pytest.mark.asyncio
async def test_muting_the_song_reopens_the_microphone(bus, store):
    """The user-reported bug: mute the music, then talk to Chat."""
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    assert audible[-1] is True

    await yt.set_muted(True)
    assert audible[-1] is False, "a muted song must not keep the microphone gated"


@pytest.mark.asyncio
async def test_unmuting_restores_playback_protection(bus, store):
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    await yt.set_muted(True)
    await yt.set_muted(False)
    assert audible[-1] is True


@pytest.mark.asyncio
async def test_zero_volume_counts_as_silence(bus, store):
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    await yt.set_volume(0)
    assert audible[-1] is False
    await yt.set_volume(60)
    assert audible[-1] is True


@pytest.mark.asyncio
async def test_ducking_for_voice_focus_still_counts_as_audible(bus, store):
    """A ducked song is quieter but still playing: keep protecting the mic."""
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    await yt.voice_focus_duck()
    assert audible[-1] is True


@pytest.mark.asyncio
async def test_pausing_reports_silence(bus, store):
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    await yt.pause_media()
    assert audible[-1] is False


@pytest.mark.asyncio
async def test_browser_reported_mute_reopens_the_microphone(bus, store):
    """Mute pressed in YouTube itself, reported over the companion bridge."""
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    yt._ingest_companion_state(
        {"status": "playing", "video_id": VIDEO_A, "muted": True, "volume": 70}
    )
    assert audible[-1] is False

    yt._ingest_companion_state(
        {"status": "playing", "video_id": VIDEO_A, "muted": False, "volume": 70}
    )
    assert audible[-1] is True


@pytest.mark.asyncio
async def test_browser_reported_zero_volume_reopens_the_microphone(bus, store):
    yt, audible = make_tool(bus, store)
    await yt.play(VIDEO_A)
    yt._ingest_companion_state(
        {"status": "playing", "video_id": VIDEO_A, "muted": False, "volume": 0}
    )
    assert audible[-1] is False
