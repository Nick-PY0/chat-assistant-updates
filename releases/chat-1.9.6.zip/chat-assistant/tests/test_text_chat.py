from __future__ import annotations

import json

import pytest

from apps.live_gateway.openai_text_brain import NoOpenAITextCredential
from apps.live_gateway.text_chat import TextChatError, TextChatService
from apps.tool_service.schemas import TOOL_DECLARATIONS


class StubClient:
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = []

    async def ask(self, messages, tools, model, max_tokens=2400):
        self.calls.append((messages, tools, model, max_tokens))
        return self.replies.pop(0)


class StubOpenAIBrain:
    def __init__(self, reply="OpenAI answer"):
        self.reply = reply
        self.calls = []

    async def ask(self, messages, model):
        self.calls.append((messages, model))
        return self.reply, model


def make_service(settings, db, store, client, tool_handler):
    settings.relay_daily_request_cap = 0
    settings.typed_chat_provider = "relay"
    service = TextChatService(
        settings, db, store, TOOL_DECLARATIONS, tool_handler
    )
    service.openai_brain = None

    async def get_client():
        return client

    service._client = get_client
    return service


async def test_typed_chat_keeps_history(settings, db, store):
    client = StubClient([
        {"reply": "First answer", "tool_calls": [], "usage": {}, "model": "gpt-5-mini"},
        {"reply": "Second answer", "tool_calls": [], "usage": {}, "model": "gpt-5-mini"},
    ])

    async def tools(*_):
        return {}

    service = make_service(settings, db, store, client, tools)
    first = await service.ask("hello")
    second = await service.ask("what did I just say?", first["conversation_id"])
    history = client.calls[1][0]
    assert [m["role"] for m in history[-3:]] == ["user", "assistant", "user"]
    assert second["reply"] == "Second answer"


async def test_typed_chat_runs_allowlisted_tool(settings, db, store):
    client = StubClient([
        {"reply": "", "tool_calls": [{
            "id": "call-1", "function": {
                "name": "start_timer", "arguments": json.dumps({"duration_seconds": 60})
            }
        }], "usage": {}},
        {"reply": "Timer started.", "tool_calls": [], "usage": {}},
    ])
    calls = []

    async def tools(call_id, name, args):
        calls.append((call_id, name, args))
        return {"status": "started"}

    service = make_service(settings, db, store, client, tools)
    result = await service.ask("set a timer for one minute")
    assert result["reply"] == "Timer started."
    assert calls == [("call-1", "start_timer", {"duration_seconds": 60})]
    tool_messages = [m for m in client.calls[1][0] if m.get("role") == "tool"]
    assert json.loads(tool_messages[0]["content"]) == {"status": "started"}


async def test_typed_chat_rejects_blank(settings, db, store):
    service = make_service(settings, db, store, StubClient([]), lambda *_: None)
    with pytest.raises(TextChatError, match="Type a message"):
        await service.ask("   ")


async def test_openai_route_uses_only_dedicated_openai_model(settings, db, store):
    relay = StubClient([])

    async def tools(*_):
        return {}

    service = make_service(settings, db, store, relay, tools)
    service.settings.typed_chat_provider = "openai"
    service.settings.openai_text_model = "gpt-5-mini"
    service.settings.relay_chat_model = "relay-only-model"
    service.settings.relay_command_model = "relay-command-model"
    brain = StubOpenAIBrain()
    service.openai_brain = brain

    result = await service.ask("search the news")

    assert result["model"] == "gpt-5-mini"
    assert brain.calls[0][1] == "gpt-5-mini"
    assert relay.calls == []


async def test_relay_route_does_not_switch_when_openai_brain_exists(settings, db, store):
    relay = StubClient([{
        "reply": "Relay answer", "tool_calls": [], "usage": {}, "model": "relay-model",
    }])

    async def tools(*_):
        return {}

    service = make_service(settings, db, store, relay, tools)
    service.settings.relay_chat_model = "relay-model"
    brain = StubOpenAIBrain()
    service.openai_brain = brain

    result = await service.ask("tell me something")

    assert result["reply"] == "Relay answer"
    assert relay.calls[0][2] == "relay-model"
    assert brain.calls == []


async def test_openai_missing_key_never_falls_back_to_relay(settings, db, store):
    relay = StubClient([{
        "reply": "must not be used", "tool_calls": [], "usage": {}, "model": "relay-model",
    }])

    async def tools(*_):
        return {}

    class MissingKeyBrain:
        async def ask(self, messages, model):
            raise NoOpenAITextCredential("Save an OpenAI key for typed chat.")

    service = make_service(settings, db, store, relay, tools)
    service.settings.typed_chat_provider = "openai"
    service.openai_brain = MissingKeyBrain()

    with pytest.raises(TextChatError, match="Save an OpenAI key"):
        await service.ask("hello")
    assert relay.calls == []
