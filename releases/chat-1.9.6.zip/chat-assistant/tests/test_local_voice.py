"""Offline voice command handling end-to-end (transcriber faked): the text
path from 'vosk heard something' to tools + announcements."""

from __future__ import annotations

import pytest

from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    announced: list[str] = []
    runtime.announcer.announce = lambda key: announced.append(key)
    runtime.test_announced = announced
    yield runtime
    await runtime.stop()


async def test_timer_command_works_offline(rt):
    result = await rt.handle_local_utterance("set a timer for two minutes")
    assert result and "error" not in result
    assert rt.test_announced == ["ok"]
    timers = await rt.timers.list_timers()
    assert len(timers) == 1


async def test_gibberish_gets_refusal(rt):
    result = await rt.handle_local_utterance("please write me a poem about clouds")
    assert result is None
    assert rt.test_announced == ["not_understood"]


async def test_empty_transcription_gets_refusal(rt):
    result = await rt.handle_local_utterance("")
    assert result is None
    assert rt.test_announced == ["not_understood"]


async def test_remember_and_forget_offline(rt):
    r = await rt.handle_local_utterance("remember that I parked on level 3")
    assert r and r["remembered"] == "I parked on level 3".lower() or "parked" in r["remembered"]
    assert rt.test_announced[-1] == "ok"

    r2 = await rt.handle_local_utterance("what do you remember about parking")
    assert r2 is not None
    assert rt.test_announced[-1] == "see_dashboard"

    r3 = await rt.handle_local_utterance("forget about level 3")
    assert r3 and r3["forgotten"] == 1
    assert rt.test_announced[-1] == "ok"


async def test_stop_command_silences_without_announcement(rt):
    result = await rt.handle_local_utterance("stop")
    assert result == {"stopped": True}
    assert rt.test_announced == []  # stopping must not trigger speech


async def test_failed_tool_announces_refusal(rt):
    # lights are configured but no Govee key exists -> tool returns an error
    result = await rt.handle_local_utterance("turn on the desk light")
    assert result and "error" in result
    assert rt.test_announced == ["not_understood"]


async def test_concurrent_reloads_leave_exactly_one_audio_consumer(rt):
    """Rapid settings saves fire overlapping reload_audio calls; the lock
    must serialize them so only ONE pump/engine survives."""
    import asyncio
    from types import SimpleNamespace

    rt.gateway = SimpleNamespace(audio_out=asyncio.Queue())  # enables wiring
    try:
        await asyncio.gather(*(rt.reload_audio() for _ in range(5)))
        pumps = [t for t in rt._tasks if t.get_name() == "audio-pump" and not t.done()]
        assert len(pumps) == 1
    finally:
        rt.gateway = None  # fixture teardown must not call gateway.stop()
