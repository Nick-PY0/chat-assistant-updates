"""Audio fan-out to dashboard listeners."""

from __future__ import annotations

from apps.audio.broadcast import AudioBroadcast, resample_pcm16


def test_publish_reaches_all_subscribers():
    b = AudioBroadcast()
    q1, q2 = b.subscribe(), b.subscribe()
    assert b.listener_count == 2
    b.publish(b"\x01\x02")
    assert q1.get_nowait() == ("pcm", b"\x01\x02")
    assert q2.get_nowait() == ("pcm", b"\x01\x02")
    b.unsubscribe(q1)
    assert b.listener_count == 1


def test_slow_listener_drops_oldest_not_newest():
    b = AudioBroadcast()
    q = b.subscribe(maxsize=2)
    b.publish(b"a")
    b.publish(b"b")
    b.publish(b"c")  # q full -> "a" dropped
    assert q.get_nowait() == ("pcm", b"b")
    assert q.get_nowait() == ("pcm", b"c")


def test_clear_flushes_and_sends_sentinel():
    b = AudioBroadcast()
    q = b.subscribe()
    b.publish(b"a")
    b.publish(b"b")
    b.clear()
    assert q.qsize() == 1
    assert q.get_nowait() == ("clear", b"")


def test_resample_changes_length_proportionally():
    pcm = b"\x00\x01" * 220  # 220 samples
    out = resample_pcm16(pcm, 22050, 24000)
    assert len(out) % 2 == 0
    assert abs(len(out) // 2 - 239) <= 2  # 220 * 24000/22050 ~ 239
    assert resample_pcm16(pcm, 24000, 24000) == pcm
    assert resample_pcm16(b"", 22050, 24000) == b""
