"""Failure handling in the gateway: what each Gemini failure does to the
credential pool (without any real network)."""

from datetime import timedelta

from apps.live_gateway.gateway import LiveGateway
from apps.tool_service.schemas import TOOL_DECLARATIONS
from chat_core.models.credentials import utcnow
from chat_core.models.state import StateMachine
from integrations.gemini.errors import (
    INVALID,
    QUOTA_EXHAUSTED,
    RATE_LIMITED,
    UNAVAILABLE,
    GeminiFailure,
    next_quota_reset,
)


async def dummy_tools(call_id, name, args):
    return {}


def make_gateway(settings, db, store, bus, rate_limit_threshold: int = 1):
    state = StateMachine(bus)
    settings.rate_limit_rotate_after_failures = rate_limit_threshold
    return LiveGateway(settings, db, store, bus, state, TOOL_DECLARATIONS, dummy_tools)


async def test_auth_failure_marks_invalid_and_excludes_key(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    cred = await store.add("gemini", "AIzaBadKey000001", project_label="p1")
    action = await gw._apply_failure(cred, GeminiFailure(INVALID, "API key not valid"))
    assert action.exclude_key is True
    assert action.avoid_project is False
    assert (await store.get(cred.id)).status == "invalid"


async def test_quota_failure_blocks_whole_project(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    a = await store.add("gemini", "AIzaKeyA0000001", project_label="proj")
    b = await store.add("gemini", "AIzaKeyB0000002", project_label="proj")
    alerts = bus.subscribe("credential_alert")
    action = await gw._apply_failure(
        a, GeminiFailure(QUOTA_EXHAUSTED, "daily quota", retry_after=utcnow() + timedelta(hours=5))
    )
    assert action.exclude_key is True
    assert action.avoid_project is True
    assert (await store.get(a.id)).status == "exhausted"
    assert (await store.get(b.id)).status == "exhausted"
    ev = alerts.get_nowait()
    assert ev.data["keys_blocked"] == 2


async def test_quota_block_always_uses_configured_pacific_reset(settings, db, store, bus):
    """A provider-supplied retry timestamp must NOT override the documented
    midnight-Pacific + jitter reset policy."""
    gw = make_gateway(settings, db, store, bus)
    cred = await store.add("gemini", "AIzaKeyQ0000009", project_label="p1")
    bogus_retry = utcnow() + timedelta(minutes=3)  # attacker/provider says "soon"
    await gw._apply_failure(
        cred, GeminiFailure(QUOTA_EXHAUSTED, "daily quota", retry_after=bogus_retry)
    )
    stored = (await store.get(cred.id)).retry_after
    expected = next_quota_reset(
        settings.quota_reset_timezone, settings.quota_reset_jitter_seconds
    )
    assert abs((stored - expected).total_seconds()) < 5
    assert abs((stored - bogus_retry).total_seconds()) > 60


async def test_first_rate_limit_retries_same_key(settings, db, store, bus):
    """Short-window 429: back off briefly and KEEP the same key until the
    strike threshold is reached; only then rotate."""
    gw = make_gateway(settings, db, store, bus, rate_limit_threshold=2)
    cred = await store.add("gemini", "AIzaKeyC0000003", project_label="p1")

    first = await gw._apply_failure(
        cred, GeminiFailure(RATE_LIMITED, "slow down", retry_after=utcnow() + timedelta(seconds=1))
    )
    assert first.exclude_key is False          # same key is retried
    assert (await store.get(cred.id)).status == "active"  # untouched

    second = await gw._apply_failure(
        cred, GeminiFailure(RATE_LIMITED, "slow down", retry_after=utcnow() + timedelta(seconds=30))
    )
    assert second.exclude_key is True          # threshold hit -> rotate
    fresh = await store.get(cred.id)
    assert fresh.status == "unavailable"
    assert fresh.retry_after is not None


async def test_unavailable_gets_bounded_backoff(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    cred = await store.add("gemini", "AIzaKeyD0000004", project_label="p1")
    action = await gw._apply_failure(cred, GeminiFailure(UNAVAILABLE, "503"))
    assert action.exclude_key is True
    assert action.avoid_project is False
    fresh = await store.get(cred.id)
    assert fresh.status == "unavailable"
    assert fresh.retry_after is not None


async def test_local_only_records_retry_schedule(settings, db, store, bus):
    gw = make_gateway(settings, db, store, bus)
    events = bus.subscribe("local_only")
    retry = utcnow() + timedelta(hours=3)
    await store.add("gemini", "AIzaKeyE0000005", project_label="p1")
    await store.mark_project_exhausted(
        (await store.list(provider="gemini"))[0].project_fingerprint, retry
    )
    await gw._enter_local_only(retry)
    ev = events.get_nowait()
    assert ev.data["quota"] is True
    stored = await db.get_setting("quota_retry_at")
    assert stored == retry.isoformat()
