"""Durable alarm ringing: restart recovery, snooze, idempotent dismiss.

These tests exercise the core contract:
  * active_ring DB row is written when a ring starts
  * the ring loops forever (no deadline) until explicitly stopped
  * dismiss is idempotent (callable twice without error)
  * snooze persists snoozed_until in DB; ring row is NOT cleared
  * process restart resumes ringing from the persisted row
  * snooze-then-restart waits for the snooze, then rings
  * browser disconnect (stop_output from non-ring path) never sets
    ring to None while still ringing
  * /api/reminders/dismiss and /api/reminders/snooze are authenticated
"""

from __future__ import annotations

import asyncio
from datetime import timedelta

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.models.credentials import iso, utcnow
from chat_core.runtime import Runtime


# ---------------------------------------------------------------------------
# helpers / fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    # Silence audio side-effects
    monkeypatch.setattr(runtime.announcer, "announce", lambda key: None)
    monkeypatch.setattr(runtime, "_play_alert", lambda pcm, rate: None)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def signed_in(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    token = client.cookies.get(COOKIE)
    return {"x-csrf": client.app.state.sessions.csrf_for(token)}


RING_DATA = {"id": "r_test", "kind": "alarm", "message": "wake up"}


# ---------------------------------------------------------------------------
# ring loop is infinite (no deadline) -- ring stays active until stopped
# ---------------------------------------------------------------------------

async def test_ring_loops_indefinitely_until_stop(rt):
    """Ring must keep running past the old alarm_ring_seconds deadline."""
    rt.settings.alarm_ring_seconds = 5  # would have timed out previously
    await rt._begin_ring(RING_DATA)
    # Give the loop a moment to start
    await asyncio.sleep(0.05)
    assert rt.ringing is not None, "ring should still be active"
    assert rt._ring_task is not None and not rt._ring_task.done()
    # Now dismiss it
    rt.stop_output()
    await asyncio.wait_for(rt._ring_task, timeout=5)
    assert rt.ringing is None


# ---------------------------------------------------------------------------
# DB persistence
# ---------------------------------------------------------------------------

async def test_ring_persisted_to_db_on_start(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is not None
    assert row["reminder_id"] == "r_test"
    assert row["kind"] == "alarm"
    assert row["message"] == "wake up"
    assert row["snoozed_until"] is None
    rt.stop_output()
    await asyncio.wait_for(rt._ring_task, timeout=5)


async def test_dismiss_clears_db_row(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    await rt.dismiss_ring()
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is None


async def test_stop_output_clears_db_row(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    rt.stop_output()
    await asyncio.sleep(0.1)  # let fire-and-forget task run
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is None


# ---------------------------------------------------------------------------
# Process restart recovery
# ---------------------------------------------------------------------------

async def test_restart_resumes_ring(settings, monkeypatch):
    """A runtime that crashed mid-ring resumes it on restart."""
    # Runtime 1: start a ring, then simulate a crash (stop() without dismiss)
    r1 = Runtime(settings)
    await r1.start(voice=False, cloud=False, monitoring=False)
    monkeypatch.setattr(r1.announcer, "announce", lambda key: None)
    monkeypatch.setattr(r1, "_play_alert", lambda pcm, rate: None)
    await r1._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    # Verify row persisted
    row = await r1.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is not None
    # Graceful stop (without dismiss): row should remain
    await r1.stop()
    # Verify row still in DB after graceful stop
    r1_db = Runtime(settings)
    await r1_db.db.open()
    row_after = await r1_db.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    await r1_db.db.close()
    assert row_after is not None, "ring row must persist across graceful stop"

    # Runtime 2: should resume the ring automatically
    r2 = Runtime(settings)
    await r2.start(voice=False, cloud=False, monitoring=False)
    monkeypatch.setattr(r2.announcer, "announce", lambda key: None)
    monkeypatch.setattr(r2, "_play_alert", lambda pcm, rate: None)
    try:
        await asyncio.sleep(0.1)
        assert r2.ringing is not None, "runtime2 should be ringing after restore"
        assert r2.ringing["message"] == "wake up"
    finally:
        await r2.dismiss_ring()
        await r2.stop()


# ---------------------------------------------------------------------------
# Snooze
# ---------------------------------------------------------------------------

async def test_snooze_returns_true_when_ringing(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    result = await rt.snooze_ring(minutes=1)
    assert result is True


async def test_snooze_returns_false_when_not_ringing(rt):
    result = await rt.snooze_ring()
    assert result is False


async def test_snooze_persists_snoozed_until_in_db(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    await rt.snooze_ring(minutes=10)
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is not None, "ring row must stay in DB after snooze"
    assert row["snoozed_until"] is not None, "snoozed_until must be set"


async def test_snooze_stops_audio_and_clears_ringing_attr(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    await rt.snooze_ring(minutes=10)
    assert rt.ringing is None


async def test_snooze_then_resumes(settings, monkeypatch):
    """After snooze the ring resumes after the snooze period."""
    rt = Runtime(settings)
    await rt.start(voice=False, cloud=False, monitoring=False)
    monkeypatch.setattr(rt.announcer, "announce", lambda key: None)
    monkeypatch.setattr(rt, "_play_alert", lambda pcm, rate: None)
    try:
        await rt._begin_ring(RING_DATA)
        await asyncio.sleep(0.05)
        # Snooze for a very short time (minimum enforced at 60s, so patch it)
        rt.SNOOZE_SECONDS = 0  # override for test speed
        # Call with explicit very short wait via internal path
        from chat_core.models.credentials import iso, utcnow
        snooze_until = utcnow() + timedelta(seconds=1)
        await rt.db.execute(
            "UPDATE active_ring SET snoozed_until=? WHERE id='current'",
            (iso(snooze_until),),
        )
        rt._ring_stop.set()
        if rt._ring_task is not None:
            await asyncio.gather(rt._ring_task, return_exceptions=True)
        rt.ringing = None
        # Schedule resume manually (bypass the 60s minimum)
        row_data = {"reminder_id": RING_DATA["id"], "kind": RING_DATA["kind"],
                    "message": RING_DATA["message"]}
        asyncio.create_task(rt._snooze_resume_after(row_data, 0.5))
        # Wait for snooze to expire and ring to resume
        for _ in range(40):
            if rt.ringing is not None:
                break
            await asyncio.sleep(0.05)
        assert rt.ringing is not None, "ring should resume after snooze"
    finally:
        await rt.dismiss_ring()
        await rt.stop()


# ---------------------------------------------------------------------------
# Idempotent dismiss
# ---------------------------------------------------------------------------

async def test_dismiss_idempotent_no_ring(rt):
    """dismiss_ring when nothing rings must not raise."""
    result = await rt.dismiss_ring()
    assert result is False


async def test_dismiss_idempotent_double_call(rt):
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    first = await rt.dismiss_ring()
    second = await rt.dismiss_ring()
    assert first is True
    assert second is False


# ---------------------------------------------------------------------------
# Dashboard API endpoints (authenticated)
# ---------------------------------------------------------------------------

async def test_dismiss_endpoint_requires_auth(client):
    resp = await client.post("/api/reminders/dismiss", json={})
    assert resp.status_code == 401


async def test_snooze_endpoint_requires_auth(client):
    resp = await client.post("/api/reminders/snooze", json={})
    assert resp.status_code == 401


async def test_dismiss_endpoint_authenticated(client, rt, monkeypatch):
    monkeypatch.setattr(rt, "_play_alert", lambda pcm, rate: None)
    hdrs = await signed_in(client)
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    resp = await client.post("/api/reminders/dismiss", json={}, headers=hdrs)
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True
    assert body["dismissed"] is True
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is None


async def test_dismiss_endpoint_idempotent(client, rt):
    hdrs = await signed_in(client)
    # Call dismiss when nothing is ringing
    resp = await client.post("/api/reminders/dismiss", json={}, headers=hdrs)
    assert resp.status_code == 200
    assert resp.json()["dismissed"] is False


async def test_snooze_endpoint_authenticated(client, rt, monkeypatch):
    monkeypatch.setattr(rt, "_play_alert", lambda pcm, rate: None)
    hdrs = await signed_in(client)
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    resp = await client.post("/api/reminders/snooze", json={}, headers=hdrs)
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True
    assert body["snoozed"] is True
    row = await rt.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
    assert row is not None
    assert row["snoozed_until"] is not None


async def test_snooze_endpoint_custom_minutes(client, rt, monkeypatch):
    monkeypatch.setattr(rt, "_play_alert", lambda pcm, rate: None)
    hdrs = await signed_in(client)
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    resp = await client.post("/api/reminders/snooze", json={"minutes": 5}, headers=hdrs)
    assert resp.status_code == 200
    assert resp.json()["snoozed"] is True


async def test_snooze_endpoint_idempotent_when_not_ringing(client, rt):
    hdrs = await signed_in(client)
    resp = await client.post("/api/reminders/snooze", json={}, headers=hdrs)
    assert resp.status_code == 200
    assert resp.json()["snoozed"] is False


async def test_snooze_endpoint_bad_minutes(client, rt):
    hdrs = await signed_in(client)
    resp = await client.post("/api/reminders/snooze", json={"minutes": "bad"}, headers=hdrs)
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Restart + snoozed state recovery
# ---------------------------------------------------------------------------

async def test_restart_with_snoozed_ring_waits(settings, monkeypatch):
    """If a ring was snoozed and the process restarts, the new runtime must
    wait for the snooze deadline, not ring immediately."""
    # Directly insert a snoozed ring row into the DB
    rt_tmp = Runtime(settings)
    await rt_tmp.db.open()
    snooze_until = utcnow() + timedelta(seconds=60)
    await rt_tmp.db.execute(
        "INSERT INTO active_ring (id, reminder_id, kind, message, started_at, snoozed_until) "
        "VALUES ('current', 'r_snooze', 'reminder', 'stretch', ?, ?)",
        (iso(utcnow()), iso(snooze_until)),
    )
    await rt_tmp.db.close()

    # Start a new runtime; it should NOT ring immediately
    r2 = Runtime(settings)
    await r2.start(voice=False, cloud=False, monitoring=False)
    monkeypatch.setattr(r2.announcer, "announce", lambda key: None)
    monkeypatch.setattr(r2, "_play_alert", lambda pcm, rate: None)
    try:
        await asyncio.sleep(0.1)
        assert r2.ringing is None, "must not ring while snooze is still active"
        # Row should still be in DB
        row = await r2.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
        assert row is not None
    finally:
        # Clean up without ringing
        await r2.db.execute("DELETE FROM active_ring WHERE id='current'")
        await r2.stop()


# ---------------------------------------------------------------------------
# Browser disconnect does not dismiss ring
# ---------------------------------------------------------------------------

async def test_browser_disconnect_does_not_dismiss(rt, monkeypatch):
    """Closing the SSE stream or websocket must not stop the ring.
    stop_output is NOT called by the SSE generator; this test confirms
    the ring keeps going after an SSE client disconnects."""
    monkeypatch.setattr(rt, "_play_alert", lambda pcm, rate: None)
    await rt._begin_ring(RING_DATA)
    await asyncio.sleep(0.05)
    assert rt.ringing is not None

    # Simulate the SSE stream's finally block (bus.unsubscribe only, no stop_output)
    q = rt.bus.subscribe("reminders_changed")
    rt.bus.unsubscribe(q)  # what the SSE stream does on disconnect

    await asyncio.sleep(0.05)
    assert rt.ringing is not None, "ring must survive browser disconnect"
    rt.stop_output()
    await asyncio.wait_for(rt._ring_task, timeout=5)
