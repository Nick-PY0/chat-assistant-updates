import json
from types import SimpleNamespace

import pytest

from apps.live_gateway.openai_text_brain import OpenAITextBrain, _responses_input


def test_responses_input_converts_data_image_only():
    result = _responses_input([
        {"role": "assistant", "content": "hello"},
        {"role": "user", "content": [
            {"type": "text", "text": "what is this?"},
            {"type": "image_url", "image_url": {"url": "data:image/png;base64,AAA="}},
            {"type": "image_url", "image_url": {"url": "https://untrusted.example/x.png"}},
        ]},
    ])
    assert result[0] == {"role": "assistant", "content": "hello"}
    assert result[1]["content"] == [
        {"type": "input_text", "text": "what is this?"},
        {"type": "input_image", "image_url": "data:image/png;base64,AAA=", "detail": "auto"},
    ]


@pytest.mark.asyncio
async def test_brain_runs_responses_function_loop(db):
    class Store:
        async def list(self, provider=None):
            return [SimpleNamespace(id="key-1", status="active", retry_after=None)]

        async def get_secret(self, credential_id):
            return "secret"

    class Client:
        def __init__(self, key):
            self.requests = []

        async def create(self, payload):
            self.requests.append(payload)
            if len(self.requests) == 1:
                return {
                    "id": "resp_1", "model": "gpt-5-mini", "status": "completed",
                    "usage": {"input_tokens": 4, "output_tokens": 2},
                    "output": [{"type": "function_call", "call_id": "c1",
                                "name": "get_current_time", "arguments": "{}"}],
                }
            return {
                "id": "resp_2", "model": "gpt-5-mini", "status": "completed",
                "usage": {"input_tokens": 8, "output_tokens": 3},
                "output": [{"type": "message", "content": [{
                    "type": "output_text", "text": "It is 10:30 PM.", "annotations": []
                }]}],
            }

    made = []
    def factory(key):
        made.append(Client(key))
        return made[-1]

    calls = []
    async def tool_handler(call_id, name, args):
        calls.append((call_id, name, args))
        return {"local_time": "10:30 PM"}

    settings = SimpleNamespace(system_prompt="You are Jarvis.")
    brain = OpenAITextBrain(
        settings, db, Store(),
        [{"name": "get_current_time", "parameters": {"type": "OBJECT", "properties": {}}}],
        tool_handler, client_factory=factory,
    )
    reply, model = await brain.ask([{"role": "user", "content": "time?"}], "gpt-5-mini")
    assert (reply, model) == ("It is 10:30 PM.", "gpt-5-mini")
    assert calls == [("c1", "get_current_time", {})]
    assert made[0].requests[1]["previous_response_id"] == "resp_1"
    assert json.loads(made[0].requests[1]["input"][0]["output"]) == {"local_time": "10:30 PM"}
