"""Tests for the YouTube / media-control tools.

All tests use mocks – no browser window is opened and no media keys are sent.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

from apps.tool_service.media_tool import (
    MediaError,
    build_youtube_url,
    media_control,
    play_youtube,
    seek_youtube_url,
    send_media_key,
    validate_direct_url,
)
from apps.tool_service.local_grammar import parse
from apps.tool_service.schemas import TOOL_DECLARATIONS


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fake_open(calls: list) -> callable:
    """Return a browser-open stub that records the URL it received."""
    def _open(url: str) -> None:
        calls.append(url)
    return _open


def _fake_send_key(calls: list) -> callable:
    """Return a SendInput stub that records the VK code it received."""
    def _send(vk: int) -> None:
        calls.append(vk)
    return _send


# ---------------------------------------------------------------------------
# URL building
# ---------------------------------------------------------------------------

class TestBuildYoutubeUrl:
    def test_search_query_is_encoded(self):
        url = build_youtube_url("Blinding Lights The Weeknd")
        assert url.startswith("https://www.youtube.com/results?search_query=")
        assert "Blinding+Lights" in url or "Blinding%20Lights" in url

    def test_video_id_produces_watch_url(self):
        url = build_youtube_url("", video_id="dQw4w9WgXcQ")
        assert url == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

    def test_invalid_video_id_falls_back_to_search(self):
        # 11-char rule not met → falls back to empty search
        url = build_youtube_url("fallback", video_id="TOOSHORT")
        assert "results" in url

    def test_special_characters_in_query_are_encoded(self):
        url = build_youtube_url("Guns N' Roses – Paradise City")
        assert "youtube.com/results" in url
        assert " " not in url  # no raw spaces in URL

    def test_empty_query_produces_search_url(self):
        url = build_youtube_url("")
        assert "youtube.com/results" in url


class TestValidateDirectUrl:
    def test_valid_youtube_url_passes(self):
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        assert validate_direct_url(url) == url

    def test_valid_youtu_be_url_passes(self):
        url = "https://youtu.be/dQw4w9WgXcQ"
        assert validate_direct_url(url) == url

    def test_non_youtube_domain_is_rejected(self):
        with pytest.raises(MediaError, match="youtube.com / youtu.be"):
            validate_direct_url("https://vimeo.com/12345")

    def test_javascript_uri_is_rejected(self):
        with pytest.raises(MediaError):
            validate_direct_url("javascript:alert(1)")

    def test_data_uri_is_rejected(self):
        with pytest.raises(MediaError):
            validate_direct_url("data:text/html,<h1>hi</h1>")

    def test_http_youtube_still_accepted(self):
        url = "http://www.youtube.com/watch?v=abc12345678"
        assert validate_direct_url(url) == url

    def test_arbitrary_subdomain_rejected(self):
        with pytest.raises(MediaError):
            validate_direct_url("https://evil.youtube.com.badsite.io/watch?v=x")


# ---------------------------------------------------------------------------
# play_youtube
# ---------------------------------------------------------------------------

class TestPlayYoutube:
    def test_opens_search_url_for_query(self):
        calls: list[str] = []
        result = play_youtube(query="Blinding Lights The Weeknd", _open_browser_fn=_fake_open(calls))
        assert len(calls) == 1
        assert "Blinding" in calls[0]
        assert result["opened_url"] == calls[0]

    def test_opens_watch_url_for_video_id(self):
        calls: list[str] = []
        result = play_youtube(video_id="dQw4w9WgXcQ", _open_browser_fn=_fake_open(calls))
        assert calls[0] == "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        assert result["opened_url"] == calls[0]

    def test_opens_supplied_url_directly(self):
        calls: list[str] = []
        target = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        result = play_youtube(url=target, _open_browser_fn=_fake_open(calls))
        assert calls[0] == target

    def test_rejects_non_youtube_url(self):
        with pytest.raises(MediaError):
            play_youtube(url="https://vimeo.com/42", _open_browser_fn=lambda u: None)

    def test_requires_at_least_one_argument(self):
        with pytest.raises(MediaError, match="query"):
            play_youtube(_open_browser_fn=lambda u: None)

    def test_browser_receives_encoded_url_no_spaces(self):
        calls: list[str] = []
        play_youtube(query="AC/DC Back in Black", _open_browser_fn=_fake_open(calls))
        assert " " not in calls[0]

    def test_query_takes_priority_over_video_id(self):
        """video_id is ignored when url takes priority; query is used when video_id is absent."""
        calls: list[str] = []
        play_youtube(query="The Weeknd", _open_browser_fn=_fake_open(calls))
        assert "results" in calls[0]


# ---------------------------------------------------------------------------
# send_media_key / media_control
# ---------------------------------------------------------------------------

class TestMediaControl:
    def _run(self, action: str) -> tuple[dict, list[int]]:
        key_calls: list[int] = []
        result = send_media_key(action, _send_key_fn=_fake_send_key(key_calls))
        return result, key_calls

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_play_sends_play_pause_key_windows(self):
        result, calls = self._run("play")
        assert result["sent"] is True
        assert calls == [0xB3]  # VK_MEDIA_PLAY_PAUSE

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_pause_sends_play_pause_key_windows(self):
        _, calls = self._run("pause")
        assert calls == [0xB3]

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_stop_sends_stop_key_windows(self):
        _, calls = self._run("stop")
        assert calls == [0xB2]  # VK_MEDIA_STOP

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_next_track_windows(self):
        _, calls = self._run("next")
        assert calls == [0xB0]  # VK_MEDIA_NEXT_TRACK

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_previous_track_windows(self):
        _, calls = self._run("previous")
        assert calls == [0xB1]  # VK_MEDIA_PREV_TRACK

    @pytest.mark.skipif(sys.platform != "win32", reason="media keys only on Windows")
    def test_aliases_prev_and_back(self):
        for alias in ("prev", "back", "prev_track"):
            _, calls = self._run(alias)
            assert calls == [0xB1]

    def test_unknown_action_raises_media_error(self):
        with pytest.raises(MediaError, match="Unknown media action"):
            send_media_key("volume_up", _send_key_fn=lambda v: None)

    def test_non_windows_raises_media_error(self):
        """On non-Windows the function must raise MediaError, never crash silently."""
        with patch.object(sys, "platform", "linux"):
            with pytest.raises(MediaError, match="Windows"):
                send_media_key("play", _send_key_fn=lambda v: None)

    def test_media_control_alias_works(self):
        """media_control() is the service-layer alias for send_media_key()."""
        key_calls: list[int] = []
        with patch.object(sys, "platform", "win32"):
            result = media_control("next", _send_key_fn=_fake_send_key(key_calls))
        assert result["sent"] is True
        assert key_calls == [0xB0]


# ---------------------------------------------------------------------------
# seek_youtube_url
# ---------------------------------------------------------------------------

class TestSeekYoutubeUrl:
    def test_appends_fragment_to_watch_url(self):
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        result = seek_youtube_url(url, 90)
        assert result == "https://www.youtube.com/watch?v=dQw4w9WgXcQ#t=90s"

    def test_replaces_existing_fragment(self):
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ#t=10s"
        result = seek_youtube_url(url, 120)
        assert result.endswith("#t=120s")
        assert result.count("#") == 1

    def test_zero_seconds(self):
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        result = seek_youtube_url(url, 0)
        assert result.endswith("#t=0s")

    def test_negative_clamps_to_zero(self):
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        result = seek_youtube_url(url, -5)
        assert result.endswith("#t=0s")

    def test_rejects_non_youtube_url(self):
        with pytest.raises(MediaError):
            seek_youtube_url("https://vimeo.com/42", 30)

    def test_rejects_non_watch_url(self):
        with pytest.raises(MediaError, match="watch"):
            seek_youtube_url("https://www.youtube.com/results?search_query=test", 30)


# ---------------------------------------------------------------------------
# Local grammar
# ---------------------------------------------------------------------------

class TestYoutubeGrammar:
    def test_play_on_youtube(self):
        cmd = parse("play Blinding Lights on YouTube")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"
        # grammar normalises to lowercase
        assert "blinding lights" in cmd["args"]["query"]

    def test_play_on_yt_alias(self):
        cmd = parse("play Bohemian Rhapsody on yt")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"
        assert "bohemian rhapsody" in cmd["args"]["query"]

    def test_search_youtube_for(self):
        cmd = parse("search YouTube for lo-fi beats")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"
        assert "lo-fi beats" in cmd["args"]["query"]

    def test_play_song_name_alone(self):
        cmd = parse("play Stairway to Heaven")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"
        assert "stairway to heaven" in cmd["args"]["query"]

    def test_open_youtube(self):
        cmd = parse("open youtube")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"

    def test_case_insensitive(self):
        cmd = parse("Play Blinding Lights on YouTube")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"

    def test_with_wake_word(self):
        cmd = parse("hey chat play Blinding Lights on YouTube")
        assert cmd is not None
        assert cmd["tool"] == "play_youtube"


class TestMediaControlGrammar:
    def test_pause(self):
        assert parse("pause") == {"tool": "pause_youtube", "args": {}}

    def test_pause_music(self):
        assert parse("pause music") == {"tool": "pause_youtube", "args": {}}

    def test_resume(self):
        cmd = parse("resume")
        assert cmd == {"tool": "play_youtube", "args": {}}

    def test_next_song(self):
        cmd = parse("next song")
        assert cmd == {"tool": "next_youtube", "args": {}}

    def test_next_track(self):
        cmd = parse("next track")
        assert cmd == {"tool": "next_youtube", "args": {}}

    def test_previous_song(self):
        cmd = parse("previous song")
        assert cmd == {"tool": "previous_youtube", "args": {}}

    def test_skip(self):
        cmd = parse("skip")
        assert cmd == {"tool": "next_youtube", "args": {}}

    def test_stop_music(self):
        cmd = parse("stop the music")
        assert cmd == {"tool": "stop_youtube", "args": {}}

    def test_stop_playing(self):
        cmd = parse("stop playing")
        assert cmd == {"tool": "stop_youtube", "args": {}}

    def test_play_pause_toggle(self):
        cmd = parse("play/pause")
        assert cmd == {"tool": "media_control", "args": {"action": "play_pause"}}

    def test_stop_speech_not_media_stop(self):
        """'stop' alone must still map to stop_output (speech stop), not media stop."""
        cmd = parse("stop")
        assert cmd is not None
        assert cmd["tool"] == "stop_output"

    def test_back(self):
        cmd = parse("back")
        assert cmd == {"tool": "previous_youtube", "args": {}}


# ---------------------------------------------------------------------------
# Tool declarations present in TOOL_DECLARATIONS
# ---------------------------------------------------------------------------

class TestToolDeclarations:
    def _find(self, name: str) -> dict | None:
        return next((t for t in TOOL_DECLARATIONS if t["name"] == name), None)

    def test_play_youtube_declared(self):
        decl = self._find("play_youtube")
        assert decl is not None
        props = decl["parameters"]["properties"]
        assert "query" in props
        assert "video_id" in props
        assert "url" in props

    def test_media_control_declared(self):
        decl = self._find("media_control")
        assert decl is not None
        assert "action" in decl["parameters"]["properties"]
        assert "action" in decl["parameters"]["required"]


# ---------------------------------------------------------------------------
# ToolService integration (mocked – no real browser / keys)
# ---------------------------------------------------------------------------

@pytest.fixture
async def media_tools(db, bus, store):
    from apps.tool_service.service import ToolService
    from apps.tool_service.timers import TimerManager

    timers = TimerManager(db, bus)
    return ToolService(db, bus, timers, store)


class TestToolServiceMedia:
    async def test_play_youtube_without_player_returns_error(self, media_tools):
        """play_youtube with no YouTubeTool wired returns an error — never opens a browser."""
        opened: list[str] = []
        import apps.tool_service.media_tool as mt
        with patch.object(mt, "_open_browser_real", side_effect=lambda u: opened.append(u)):
            result = await media_tools.dispatch("", "play_youtube", {"query": "Blinding Lights"})
        assert "error" in result
        assert "Media player" in result["error"] or "not available" in result["error"]
        assert len(opened) == 0, "webbrowser.open must never be called from play_youtube dispatch"

    async def test_play_youtube_url_without_player_returns_error(self, media_tools):
        """URL path also returns error and never opens browser when no YouTubeTool wired."""
        opened: list[str] = []
        import apps.tool_service.media_tool as mt
        with patch.object(mt, "_open_browser_real", side_effect=lambda u: opened.append(u)):
            result = await media_tools.dispatch(
                "", "play_youtube", {"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"}
            )
        assert "error" in result
        assert len(opened) == 0, "webbrowser.open must never be called from play_youtube dispatch"

    async def test_play_youtube_rejects_vimeo_via_service(self, media_tools):
        result = await media_tools.dispatch("", "play_youtube", {"url": "https://vimeo.com/1"})
        assert "error" in result

    async def test_media_control_bad_action_via_service(self, media_tools):
        result = await media_tools.dispatch("", "media_control", {"action": "volume_up"})
        assert "error" in result

    async def test_media_control_missing_action_via_service(self, media_tools):
        result = await media_tools.dispatch("", "media_control", {})
        assert "error" in result

    async def test_media_control_non_windows_error(self, media_tools):
        with patch.object(sys, "platform", "linux"):
            result = await media_tools.dispatch("", "media_control", {"action": "play"})
        assert "error" in result
        assert "Windows" in result["error"]

    async def test_media_control_windows_mock(self, media_tools):
        key_calls: list[int] = []
        import apps.tool_service.media_tool as mt
        with (
            patch.object(sys, "platform", "win32"),
            patch.object(mt, "_send_media_key_windows", side_effect=_fake_send_key(key_calls)),
        ):
            result = await media_tools.dispatch("", "media_control", {"action": "next"})
        assert "error" not in result
        assert result["sent"] is True
        assert key_calls == [0xB0]
