from __future__ import annotations

import asyncio
import base64

import httpx
import pytest

from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.text_chat import TextChatError, TextChatService
from apps.tool_service.schemas import TOOL_DECLARATIONS
from chat_core.runtime import Runtime


PNG_1X1 = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUB"
    "AScY42YAAAAASUVORK5CYII="
)


class StubClient:
    def __init__(self, *, blocked: bool = False):
        self.calls: list[list[dict]] = []
        self.started = asyncio.Event()
        self.release = asyncio.Event()
        if not blocked:
            self.release.set()

    async def ask(self, messages, tools, model, max_tokens=2400):
        self.calls.append(messages)
        self.started.set()
        await self.release.wait()
        return {
            "reply": f"answer {len(self.calls)}",
            "tool_calls": [],
            "usage": {},
            "model": "test-model",
        }


class StubOpenAIBrain:
    def __init__(self):
        self.calls: list[list[dict]] = []

    async def ask(self, messages, model):
        self.calls.append(messages)
        return f"answer {len(self.calls)}", model


def make_service(settings, db, store, client):
    settings.relay_daily_request_cap = 0
    settings.typed_chat_provider = "relay"

    async def tools(*_):
        return {}

    service = TextChatService(settings, db, store, TOOL_DECLARATIONS, tools)
    service.openai_brain = None

    async def get_client():
        return client

    service._client = get_client
    return service


async def test_turn_is_durable_before_background_reply_and_idempotent(settings, db, store):
    client = StubClient(blocked=True)
    service = make_service(settings, db, store, client)

    turn = await service.start_turn("hello", request_id="same-request")
    await asyncio.wait_for(client.started.wait(), 1)
    assert turn["status"] == "pending"
    assert [message["role"] for message in turn["messages"]] == ["user", "assistant"]

    retry = await service.start_turn(
        "this duplicate body is ignored",
        turn["conversation_id"],
        request_id="same-request",
    )
    assert [message["id"] for message in retry["messages"]] == [
        message["id"] for message in turn["messages"]
    ]

    persisted = await service.get_conversation(turn["conversation_id"])
    assert persisted is not None
    assert persisted["messages"][1]["status"] == "pending"

    client.release.set()
    finished = await asyncio.wait_for(
        service.wait_turn(turn["conversation_id"], "same-request"), 1
    )
    assert finished["status"] == "completed"
    assert len(client.calls) == 1


async def test_conversation_crud_is_sorted_and_persisted(settings, db, store):
    service = make_service(settings, db, store, StubClient())
    first = await service.create_conversation("First")
    second = await service.create_conversation("Second")
    await asyncio.sleep(0.003)
    renamed = await service.rename_conversation(first["id"], "  Important   chat  ")
    assert renamed is not None and renamed["title"] == "Important chat"

    listing = await service.list_conversations()
    assert [item["id"] for item in listing[:2]] == [first["id"], second["id"]]
    assert await service.delete_conversation(second["id"]) is True
    assert await service.get_conversation(second["id"]) is None
    assert await service.delete_conversation(second["id"]) is False


async def test_verified_image_is_persisted_and_sent_without_exposing_path(settings, db, store):
    client = StubClient()
    service = make_service(settings, db, store, client)
    settings.typed_chat_provider = "openai"
    brain = StubOpenAIBrain()
    service.openai_brain = brain
    attachments = await service.store_attachments([
        ("..\\camera.png", "image/png", PNG_1X1),
    ])
    stored_path = attachments[0].storage_path
    turn = await service.start_turn("what is this?", attachments=attachments)
    await service.wait_turn(turn["conversation_id"], turn["request_id"])

    user_message = brain.calls[0][-1]
    assert isinstance(user_message["content"], list)
    assert user_message["content"][1]["image_url"]["url"].startswith("data:image/png;base64,")

    conversation = await service.get_conversation(turn["conversation_id"])
    assert conversation is not None
    public_attachment = conversation["messages"][0]["attachments"][0]
    assert public_attachment["original_name"] == "camera.png"
    assert "storage_path" not in public_attachment
    found = await service.attachment_file(public_attachment["id"])
    assert found is not None and str(found[0]) == stored_path

    assert await service.delete_conversation(turn["conversation_id"])
    assert not found[0].exists()

    with pytest.raises(TextChatError, match="JPEG, PNG"):
        await service.store_attachments([("fake.png", "image/png", b"not an image")])


async def test_relay_provider_rejects_images_with_clear_openai_guidance(settings, db, store):
    client = StubClient()
    service = make_service(settings, db, store, client)
    attachments = await service.store_attachments([
        ("camera.png", "image/png", PNG_1X1),
    ])

    turn = await service.start_turn("what is this?", attachments=attachments)
    finished = await service.wait_turn(turn["conversation_id"], turn["request_id"])
    assistant = next(
        message for message in finished["messages"] if message["role"] == "assistant"
    )

    assert assistant["status"] == "error"
    assert "Image questions require the OpenAI typed-chat provider" in assistant["error"]
    assert client.calls == []


async def test_history_sends_only_four_newest_images(settings, db, store):
    client = StubClient()
    service = make_service(settings, db, store, client)
    settings.typed_chat_provider = "openai"
    brain = StubOpenAIBrain()
    service.openai_brain = brain
    conversation = await service.create_conversation()
    for number in range(5):
        attachments = await service.store_attachments([
            (f"{number}.png", "image/png", PNG_1X1),
        ])
        turn = await service.start_turn(
            f"image {number}", conversation["id"], attachments=attachments
        )
        await service.wait_turn(conversation["id"], turn["request_id"])

    image_parts = [
        part
        for message in brain.calls[-1]
        if isinstance(message.get("content"), list)
        for part in message["content"]
        if part.get("type") == "image_url"
    ]
    assert len(image_parts) == 4
    assert any(
        "omitted from this request" in str(message.get("content"))
        for message in brain.calls[-1]
    )
    await service.delete_conversation(conversation["id"])


@pytest.fixture
async def dashboard(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    settings.typed_chat_provider = "openai"
    runtime.text_chat.openai_brain = StubOpenAIBrain()
    app = create_app(runtime)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        client.app = app
        response = await client.post(
            "/setup", data={"password": "hunter2secure", "confirm": "hunter2secure"}
        )
        assert response.status_code == 303
        token = client.cookies.get(COOKIE)
        headers = {"x-csrf": app.state.sessions.csrf_for(token)}
        yield runtime, client, headers
    await runtime.stop()


async def test_durable_chat_api_contract_and_multipart_image(dashboard):
    runtime, client, headers = dashboard
    created = await client.post(
        "/api/chat/conversations", json={"title": "Photos"}, headers=headers
    )
    assert created.status_code == 201
    conversation_id = created.json()["conversation"]["id"]

    started = await client.post(
        f"/api/chat/conversations/{conversation_id}/turns",
        data={"text": "what is shown?", "request_id": "photo-request"},
        files={"images": ("pixel.png", PNG_1X1, "image/png")},
        headers=headers,
    )
    assert started.status_code == 202
    assert started.json()["status"] in ("pending", "completed")
    await runtime.text_chat.wait_turn(conversation_id, "photo-request")

    detail = await client.get(f"/api/chat/conversations/{conversation_id}")
    assert detail.status_code == 200
    messages = detail.json()["conversation"]["messages"]
    attachment_url = messages[0]["attachments"][0]["url"]
    image = await client.get(attachment_url)
    assert image.status_code == 200
    assert image.headers["content-type"].startswith("image/png")
    assert image.headers["content-disposition"] == "inline"
    assert image.headers["x-content-type-options"] == "nosniff"

    renamed = await client.post(
        f"/api/chat/conversations/{conversation_id}/rename",
        json={"title": "A tiny picture"},
        headers=headers,
    )
    assert renamed.json()["conversation"]["title"] == "A tiny picture"
    listing = (await client.get("/api/chat/conversations")).json()["conversations"]
    assert listing[0]["id"] == conversation_id

    deleted = await client.delete(
        f"/api/chat/conversations/{conversation_id}", headers=headers
    )
    assert deleted.status_code == 200
    assert (await client.get(attachment_url)).status_code == 404
