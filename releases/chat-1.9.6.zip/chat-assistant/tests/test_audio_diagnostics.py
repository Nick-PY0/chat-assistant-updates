from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from apps.audio import engine as engine_module
from apps.audio.engine import AudioEngine
from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.state import StateMachine


def _engine(bus: EventBus) -> AudioEngine:
    return AudioEngine(
        Settings(),
        bus,
        StateMachine(bus),
        asyncio.Queue(),
        asyncio.Queue(),
        lambda: None,
        lambda: None,
    )


@pytest.mark.asyncio
async def test_microphone_stream_error_keeps_the_real_reason(monkeypatch):
    """A generic ValueError must not hide which audio device needs fixing."""

    class BrokenAudio:
        @staticmethod
        def query_devices():
            return [
                {"max_input_channels": 1, "max_output_channels": 1},
            ]

        @staticmethod
        def RawInputStream(**_kwargs):
            raise ValueError("Invalid device [PaErrorCode -9996]")

    bus = EventBus()
    events = bus.subscribe("audio_status")
    audio = _engine(bus)
    audio._stop.set()
    monkeypatch.setattr(engine_module, "sd", BrokenAudio, raising=False)
    monkeypatch.setattr(engine_module, "_AUDIO_OK", True)
    monkeypatch.setattr(engine_module, "_WAKE_OK", True)
    monkeypatch.setattr(engine_module, "_load_wake_model_blocking", lambda _model: (object(), ""))

    await audio.run()

    observed = []
    while not events.empty():
        observed.append(events.get_nowait().data)
    failed = next(event for event in observed if event["available"] is False)
    assert failed["reason"] == "microphone stream failed: Invalid device [PaErrorCode -9996]"