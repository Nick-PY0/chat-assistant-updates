"""Local tool service: validates and executes allowlisted tool calls from
Gemini, the local grammar, or the dashboard command box. Records sanitized
outcomes only -- never spoken content."""

from __future__ import annotations

import asyncio
import json
import logging
import re
import uuid
from typing import Callable

from chat_core.events import EventBus
from chat_core.identifiers import provider_secret_key
from chat_core.models.credentials import CredentialStore, iso, utcnow
from chat_core.models.db import Database
from apps.tool_service.media_tool import MediaError, media_control
from apps.tool_service.reminders import ReminderError, ReminderManager
from apps.tool_service.timers import TimerError, TimerManager
from integrations.govee.client import (
    GoveeClient,
    GoveeError,
    canonical_color,
    validate_percentage,
)
from integrations.lg_webos import WebOSTVError
from integrations.weather import WeatherError
from integrations.web_search import WebSearchError
from integrations.youtube import YouTubeAPIError
from apps.tool_service.youtube_tool import YouTubeError
from apps.tool_service.music_tool import MusicError
from chat_core.music import LocalMusicLibraryError
from integrations.spotify import SpotifyError
from integrations.google_calendar import GoogleCalendarError
from integrations.relay.client import RelayError
from apps.tool_service.calendar_tool import CalendarToolError
from apps.tool_service.routines import RoutineError
from apps.tool_service.expert_tool import ExpertError

log = logging.getLogger("tools")

CONFIRM_TIMER_SECONDS = 4 * 3600
MAX_MEMORIES = 500
MAX_MEMORY_CHARS = 500


class ToolError(Exception):
    """Invalid arguments for a local tool (safe to show the user)."""


class ToolService:
    def __init__(
        self,
        db: Database,
        bus: EventBus,
        timers: TimerManager,
        credentials: CredentialStore,
        on_stop: Callable[[], None] | None = None,
        reminders: ReminderManager | None = None,
        weather=None,      # object with async get(day) -> dict
        web=None,          # read-only current-time, search, and news tools
        youtube=None,      # official YouTube search + dashboard player controller
        music=None,        # room-aware Spotify/YouTube/local coordinator
        tv=None,           # optional LG webOS TV manager (allowlisted commands only)
        calendar=None,     # Google Calendar manager (cache reads + reviewed writes)
        briefing=None,     # shared calendar/weather/news briefing builder
        routines=None,     # bounded versioned routine manager
        on_quiet=None,     # async callable(enabled: bool)
        on_end_session: Callable[[], None] | None = None,
        experts=None,        # bounded Relay-backed read-only consultations
    ) -> None:
        self.db = db
        self.bus = bus
        self.timers = timers
        self.credentials = credentials
        self.on_stop = on_stop
        self.reminders = reminders
        self.weather = weather
        self.web = web
        self.youtube = youtube
        self.music = music
        self.tv = tv
        self.calendar = calendar
        self.briefing = briefing
        self.routines = routines
        self.on_quiet = on_quiet
        self.on_end_session = on_end_session
        self.experts = experts
        self._devices_cache: list[dict] = []
        self._devices_refresh_lock = asyncio.Lock()
        self._devices_refresh_task: asyncio.Task | None = None

    # ------------------------------------------------------------------
    async def _govee(self) -> GoveeClient | None:
        for cred in await self.credentials.list(provider="govee"):
            if cred.status in ("active", "standby"):
                try:
                    key = await self.credentials.get_secret(cred.id)
                except KeyError:
                    continue
                return GoveeClient(key)
        return None

    @staticmethod
    def _device_row(row) -> dict:
        return {
            "catalog_ref": row["id"],
            "device": row["provider_identity"],
            "sku": row["provider_sku"],
            "name": row["canonical_name"],
            "aliases": json.loads(row["aliases_json"] or "[]"),
            "room": row["room"],
            "enabled": bool(row["enabled"]),
            "capabilities": json.loads(row["capabilities_json"] or "[]"),
            "last_seen": row["last_seen"],
            "stale": bool(row["stale"]),
        }

    async def _load_device_catalog(self) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM device_catalog WHERE provider='govee' ORDER BY canonical_name, id"
        )
        return self._sanitize_device_metadata([self._device_row(row) for row in rows])

    @staticmethod
    def _sanitize_device_metadata(devices: list[dict]) -> list[dict]:
        """Remove provider-secret collisions while retaining private routing."""
        secret_keys = {
            provider_secret_key(value)
            for item in devices
            for value in (item.get("device"), item.get("sku"))
            if provider_secret_key(value)
        }
        sanitized = []
        for index, original in enumerate(devices, 1):
            item = dict(original)
            name = str(item.get("name") or "").strip()
            if not name or provider_secret_key(name) in secret_keys:
                name = f"Govee light {index}"
                suffix = index
                while provider_secret_key(name) in secret_keys:
                    suffix += 1
                    name = f"Govee light {suffix}"
            item["name"] = name
            item["aliases"] = [
                str(alias).strip()
                for alias in (item.get("aliases") or [])
                if str(alias).strip()
                and provider_secret_key(alias) not in secret_keys
            ]
            room = str(item.get("room") or "").strip()
            item["room"] = (
                room if room and provider_secret_key(room) not in secret_keys else None
            )
            sanitized.append(item)
        return sanitized

    @staticmethod
    def _public_device(device: dict) -> dict:
        capabilities = sorted(set(device.get("capabilities") or []))
        action_map = {
            "powerSwitch": "power",
            "brightness": "brightness",
            "colorRgb": "color",
            "lightScene": "scene",
        }
        return {
            "name": device["name"],
            "aliases": list(device.get("aliases") or []),
            "room": device.get("room"),
            "capabilities": capabilities,
            "actions": [action_map[item] for item in capabilities if item in action_map],
            "enabled": bool(device.get("enabled", True)),
            "stale": bool(device.get("stale", False)),
            "last_seen": device.get("last_seen"),
        }

    async def _discover_govee(self) -> list[dict]:
        client = await self._govee()
        if client is None:
            raise GoveeError("Govee is not configured")
        discovered = await client.list_devices()
        seen_at = iso(utcnow())
        async with self.db.transaction() as conn:
            await conn.execute("UPDATE device_catalog SET stale=1 WHERE provider='govee'")
            for item in discovered:
                await conn.execute(
                    "INSERT INTO device_catalog "
                    "(id, provider, provider_identity, provider_sku, canonical_name, "
                    "capabilities_json, last_seen, stale) VALUES (?, 'govee', ?, ?, ?, ?, ?, 0) "
                    "ON CONFLICT(provider, provider_identity) DO UPDATE SET "
                    "provider_sku=excluded.provider_sku, "
                    "capabilities_json=excluded.capabilities_json, "
                    "last_seen=excluded.last_seen, stale=0",
                    (
                        uuid.uuid4().hex,
                        item["device"],
                        item["sku"],
                        str(item.get("name") or "Govee light"),
                        json.dumps(sorted(set(item.get("capabilities") or []))),
                        seen_at,
                    ),
                )
        self._devices_cache = await self._load_device_catalog()
        return self._devices_cache

    async def _force_device_refresh(self) -> list[dict]:
        # All callers arriving while discovery is in flight await that same
        # task; a later explicit refresh starts a new discovery.
        async with self._devices_refresh_lock:
            task = self._devices_refresh_task
            if task is None:
                task = asyncio.create_task(self._discover_govee())
                self._devices_refresh_task = task
        try:
            return await asyncio.shield(task)
        except GoveeError:
            raise
        except Exception as exc:
            raise GoveeError("Govee discovery failed") from exc
        finally:
            async with self._devices_refresh_lock:
                if self._devices_refresh_task is task and task.done():
                    self._devices_refresh_task = None

    async def devices(self, refresh: bool = False) -> list[dict]:
        if self._devices_cache:
            self._devices_cache = self._sanitize_device_metadata(self._devices_cache)
        if refresh:
            if not self._devices_cache:
                self._devices_cache = await self._load_device_catalog()
            await self._force_device_refresh()
        elif not self._devices_cache:
            self._devices_cache = await self._load_device_catalog()
            if not self._devices_cache:
                client = await self._govee()
                if client is not None:
                    await self._force_device_refresh()
        self._devices_cache = self._sanitize_device_metadata(self._devices_cache)
        return [self._public_device(item) for item in self._devices_cache]

    async def update_device_metadata(
        self, catalog_ref: str, *, aliases: list[str] | None = None, room: str | None = None
    ) -> dict:
        """Edit user metadata by opaque catalog row reference, never provider id."""
        ref = str(catalog_ref or "").strip()
        if not ref:
            raise GoveeError("catalog reference is required")
        updates: list[str] = []
        values: list[object] = []
        if aliases is not None:
            if not isinstance(aliases, list) or len(aliases) > 20:
                raise GoveeError("aliases must be a list of at most 20 names")
            clean = []
            for alias in aliases:
                value = " ".join(str(alias).split()).strip()
                if not value or len(value) > 80:
                    raise GoveeError("each alias must be between 1 and 80 characters")
                if value not in clean:
                    clean.append(value)
            updates.append("aliases_json=?")
            values.append(json.dumps(clean))
        if room is not None:
            clean_room = " ".join(str(room).split()).strip()
            if len(clean_room) > 80:
                raise GoveeError("room must be at most 80 characters")
            updates.append("room=?")
            values.append(clean_room or None)
        if not updates:
            raise GoveeError("provide aliases or room")
        secret_rows = await self.db.fetchall(
            "SELECT provider_identity, provider_sku FROM device_catalog"
        )
        secret_keys = {
            provider_secret_key(value)
            for row in secret_rows
            for value in (row["provider_identity"], row["provider_sku"])
            if provider_secret_key(value)
        }
        metadata_values = []
        if aliases is not None:
            metadata_values.extend(clean)
        if room is not None and clean_room:
            metadata_values.append(clean_room)
        if any(provider_secret_key(value) in secret_keys for value in metadata_values):
            raise GoveeError("aliases and room names cannot match private provider identifiers")
        values.append(ref)
        changed = await self.db.execute(
            f"UPDATE device_catalog SET {', '.join(updates)} WHERE id=?",
            tuple(values),
        )
        if not changed:
            raise GoveeError("device catalog entry not found")
        self._devices_cache = await self._load_device_catalog()
        item = next(item for item in self._devices_cache if item["catalog_ref"] == ref)
        return self._public_device(item)

    @staticmethod
    def _normalize_device_name(value: str) -> str:
        words = re.findall(r"[a-z0-9]+", str(value or "").lower())
        ignored = {"a", "an", "the", "light", "lights", "lamp", "lamps", "bulb", "bulbs"}
        normalized = []
        for word in words:
            if word in ignored:
                continue
            if len(word) > 3 and word.endswith("s"):
                word = word[:-1]
            normalized.append(word)
        return " ".join(normalized)

    async def _resolve_device(self, name: str) -> dict:
        requested = self._normalize_device_name(name)
        if not requested:
            raise GoveeError("device name required")
        if not self._devices_cache:
            await self.devices()
        self._devices_cache = self._sanitize_device_metadata(self._devices_cache)
        devices = [
            item for item in self._devices_cache
            if item.get("enabled", True) and not item.get("stale", False)
        ]
        if not devices:
            raise GoveeError("no Govee devices available (is a Govee API key saved?)")
        matches = []
        for device in devices:
            labels = [device["name"], *(device.get("aliases") or [])]
            room = device.get("room")
            if room:
                labels += [room, *(f"{room} {label}" for label in list(labels))]
            if requested in {self._normalize_device_name(label) for label in labels}:
                matches.append(device)
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            choices = ", ".join(sorted(item["name"] for item in matches))
            raise GoveeError(f"'{name}' is ambiguous; choose one of: {choices}")
        available = ", ".join(sorted(item["name"] for item in devices))
        raise GoveeError(f"no light named '{name}'; available lights: {available}")

    @staticmethod
    def _require_capability(device: dict, capability: str, action: str) -> None:
        # A missing key is retained solely for compatibility with old in-memory
        # test/adaptor records. Durable discovered rows always contain the key.
        if "capabilities" in device and capability not in (device.get("capabilities") or []):
            raise GoveeError(f"{device['name']} does not support {action}")

    async def _govee_command_client(self) -> GoveeClient:
        client = await self._govee()
        if client is None:
            raise GoveeError("Govee is not configured")
        return client

    @staticmethod
    def _public_govee_state(response: object) -> dict:
        """Project a Govee state response onto a closed, public schema.

        Cloud responses include routing identity and request metadata beside
        state capabilities. Nothing is copied wholesale: only values from four
        recognized capability instances can enter the result.
        """
        if not isinstance(response, dict):
            return {"available": False, "state": "unknown"}
        payload = response.get("payload")
        containers = [payload, response] if isinstance(payload, dict) else [response]
        capabilities = None
        for container in containers:
            candidate = container.get("capabilities")
            if isinstance(candidate, list):
                capabilities = candidate
                break
        if capabilities is None:
            return {"available": False, "state": "unknown"}

        public: dict[str, object] = {}
        for capability in capabilities:
            if not isinstance(capability, dict):
                continue
            instance = capability.get("instance")
            state = capability.get("state")
            if isinstance(state, dict):
                value = state.get("value")
            elif state is not None:
                value = state
            else:
                value = capability.get("value")

            if instance == "powerSwitch":
                if value is True or value == 1 or (
                    isinstance(value, str) and value.lower() == "on"
                ):
                    public["power"] = "on"
                elif value is False or value == 0 or (
                    isinstance(value, str) and value.lower() == "off"
                ):
                    public["power"] = "off"
            elif instance == "brightness":
                if (
                    isinstance(value, int)
                    and not isinstance(value, bool)
                    and 0 <= value <= 100
                ):
                    public["brightness"] = value
            elif instance == "colorRgb":
                rgb = None
                if (
                    isinstance(value, int)
                    and not isinstance(value, bool)
                    and 0 <= value <= 0xFFFFFF
                ):
                    rgb = value
                elif isinstance(value, dict):
                    channels = (value.get("r"), value.get("g"), value.get("b"))
                    if all(
                        isinstance(channel, int)
                        and not isinstance(channel, bool)
                        and 0 <= channel <= 255
                        for channel in channels
                    ):
                        rgb = (channels[0] << 16) | (channels[1] << 8) | channels[2]
                if rgb is not None:
                    public["color"] = f"#{rgb:06X}"
            elif instance == "lightScene":
                if (
                    isinstance(value, str)
                    and 0 < len(value.strip()) <= 60
                    and all(char.isprintable() for char in value)
                ):
                    public["scene"] = value.strip()

        if not public:
            return {"available": False, "state": "unknown"}
        return {"available": True, **public}

    async def _refresh_devices(self) -> dict:
        async def lights_result() -> dict:
            try:
                lights = await self.devices(refresh=True)
                return {"ok": True, "devices": lights, "count": len(lights)}
            except GoveeError as exc:
                self._devices_cache = self._sanitize_device_metadata(self._devices_cache)
                return {
                    "ok": False,
                    "error": str(exc),
                    "devices": [self._public_device(item) for item in self._devices_cache],
                }
            except Exception:
                log.warning("Govee catalog refresh failed safely", exc_info=True)
                self._devices_cache = self._sanitize_device_metadata(self._devices_cache)
                return {
                    "ok": False,
                    "error": "light refresh failed",
                    "devices": [self._public_device(item) for item in self._devices_cache],
                }

        async def tv_result() -> dict:
            if self.tv is None:
                return {"ok": True, "available": False, "status": "unconfigured"}
            try:
                status = await self.tv.refresh()
                # refresh() returns the dashboard snapshot. Narrow it further
                # for an assistant tool: omit host, inputs and every native id.
                public = {
                    key: status.get(key)
                    for key in (
                        "enabled", "configured", "name", "paired", "connected",
                        "lifecycle", "can_command", "power", "power_confirmed",
                        "volume", "muted", "app", "model", "wol_ready",
                        "last_seen_at",
                    )
                    if key in status
                }
                return {"ok": True, "available": True, "status": public}
            except WebOSTVError as exc:
                # Offline is an expected device state, represented separately
                # rather than failing the combined refresh tool.
                return {"ok": True, "available": True, "status": "offline", "message": str(exc)}
            except Exception:
                log.warning("TV refresh failed safely", exc_info=True)
                return {"ok": False, "available": True, "error": "TV refresh failed"}

        lights, tv = await asyncio.gather(lights_result(), tv_result())
        return {"lights": lights, "tv": tv}

    # ------------------------------------------------------------------
    async def dispatch(self, call_id: str, name: str, args: dict) -> dict:
        """Single entry point for every tool call. Validates against the
        allowlist and returns a JSON-safe result dict."""
        try:
            result = await self._dispatch_inner(name, args or {})
            await self.db.usage(None, f"tool:{name}", "ok")
            return result
        except (
            TimerError, GoveeError, ToolError, ReminderError, WeatherError, WebSearchError,
            MediaError, YouTubeError, YouTubeAPIError, WebOSTVError,
            GoogleCalendarError, CalendarToolError, MusicError, SpotifyError,
            LocalMusicLibraryError, RoutineError, ValueError, LookupError,
            ExpertError, RelayError,
        ) as exc:
            await self.db.usage(None, f"tool:{name}", f"rejected: {exc}")
            return {"error": str(exc)}
        except Exception as exc:  # sanitized failure
            log.warning("tool %s failed: %s", name, type(exc).__name__)
            await self.db.usage(None, f"tool:{name}", f"failed: {type(exc).__name__}")
            return {"error": "tool execution failed"}

    async def _dispatch_inner(self, name: str, args: dict) -> dict:
        if name in ("ask_chatgpt", "ask_claude"):
            if self.experts is None:
                raise ExpertError("expert tools are unavailable")
            provider = "chatgpt" if name == "ask_chatgpt" else "claude"
            return await self.experts.ask(
                provider, args.get("query"), args.get("model", "auto")
            )

        if name == "start_timer":
            seconds = args.get("duration_seconds")
            confirmed = bool(args.get("confirmed"))
            try:
                seconds_int = int(seconds)
            except (TypeError, ValueError) as exc:
                raise TimerError("duration must be a number of seconds") from exc
            if seconds_int > CONFIRM_TIMER_SECONDS and not confirmed:
                return {
                    "needs_confirmation": True,
                    "message": f"That's over {CONFIRM_TIMER_SECONDS // 3600} hours. Ask the user to confirm, then retry with confirmed=true.",
                }
            return await self.timers.start_timer(seconds_int, args.get("label", ""))

        if name == "list_timers":
            return {"timers": await self.timers.list_timers()}

        if name == "cancel_timer":
            return await self.timers.cancel_timer(args.get("timer_id", ""))

        if name == "pause_timer":
            return await self.timers.pause_timer(args.get("timer_id", ""))

        if name == "resume_timer":
            return await self.timers.resume_timer(args.get("timer_id", ""))

        if name == "set_govee_power":
            state = str(args.get("state", "")).strip().lower()
            if state not in ("on", "off"):
                raise GoveeError("state must be 'on' or 'off'")
            device = await self._resolve_device(args.get("device", ""))
            self._require_capability(device, "powerSwitch", "power control")
            client = await self._govee_command_client()
            await client.set_power(device["sku"], device["device"], state == "on")
            return {"device": device["name"], "power": state}

        if name == "set_govee_brightness":
            pct = validate_percentage(args.get("percentage"))
            device = await self._resolve_device(args.get("device", ""))
            self._require_capability(device, "brightness", "brightness control")
            client = await self._govee_command_client()
            await client.set_brightness(device["sku"], device["device"], pct)
            return {"device": device["name"], "brightness": pct}

        if name == "set_govee_color":
            color = canonical_color(args.get("color"))
            device = await self._resolve_device(args.get("device", ""))
            self._require_capability(device, "colorRgb", "color control")
            client = await self._govee_command_client()
            await client.set_color(device["sku"], device["device"], color)
            return {"device": device["name"], "color": color}

        if name == "activate_govee_scene":
            device = await self._resolve_device(args.get("device", ""))
            self._require_capability(device, "lightScene", "scenes")
            client = await self._govee_command_client()
            scene = str(args.get("scene", "")).strip()
            if not scene or len(scene) > 60:
                raise GoveeError("invalid scene name")
            await client.activate_scene(device["sku"], device["device"], scene)
            return {"device": device["name"], "scene": scene}

        if name == "get_govee_status":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee_command_client()
            state = await client.get_state(device["sku"], device["device"])
            return {"device": device["name"], "state": self._public_govee_state(state)}

        if name == "configure_light":
            # The caller identifies an already-known light by its human-facing
            # name/alias/room. Provider ids and catalog refs are intentionally
            # not accepted by this tool.
            device = await self._resolve_device(args.get("device", ""))
            aliases = args.get("aliases") if "aliases" in args else None
            room = args.get("room") if "room" in args else None
            if aliases is None and room is None:
                raise GoveeError("provide aliases or room to configure")
            catalog_ref = device.get("catalog_ref")
            if not catalog_ref:
                raise GoveeError("light metadata is not available until device discovery completes")
            return await self.update_device_metadata(
                catalog_ref,
                aliases=aliases,
                room=room,
            )

        if name == "refresh_devices":
            return await self._refresh_devices()

        if name in ("stop_speaking", "stop_output"):
            if self.on_stop:
                self.on_stop()
            return {"stopped": True}

        if name == "end_voice_session":
            if self.on_stop:
                self.on_stop()
            if self.on_end_session:
                self.on_end_session()
            return {"stopped": True, "session_ended": True}

        if name == "set_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return await self.reminders.set_reminder(
                message=str(args.get("message", "")),
                hour=args.get("hour"),
                minute=args.get("minute", 0),
                ampm=str(args.get("ampm", "")),
                day=str(args.get("day", "")),
                kind=str(args.get("kind", "reminder")),
                at_local=str(args.get("at_local", "")),
            )

        if name == "list_reminders":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return {"reminders": await self.reminders.list_reminders()}

        if name == "cancel_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            ref = str(args.get("ref", "") or args.get("reminder_id", ""))
            return await self.reminders.cancel_reminder(ref)

        if name == "get_weather":
            if self.weather is None:
                raise ToolError("weather is not available")
            return await self.weather.get(str(args.get("day", "today")))

        if name == "get_current_time":
            if self.web is None:
                raise ToolError("current time is not available")
            return self.web.current_time()

        if name == "search_web":
            if self.web is None:
                raise ToolError("web search is not available")
            return await self.web.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "get_latest_news":
            if self.web is None:
                raise ToolError("news search is not available")
            return await self.web.news(
                args.get("query", ""), args.get("max_results", 6)
            )

        if name == "set_quiet_mode":
            if self.on_quiet is None:
                raise ToolError("quiet mode is not available")
            enabled = bool(args.get("enabled"))
            await self.on_quiet(enabled)
            return {"quiet": enabled}

        if name == "get_briefing":
            if self.briefing is None:
                raise ToolError("briefings are not available")
            sections = args.get("sections")
            return await self.briefing.run_briefing(sections)

        if name == "list_routines":
            if self.routines is None:
                raise ToolError("routines are not available")
            routines = await self.routines.list_routines()
            public = [
                {
                    "id": item["id"],
                    "name": item["name"],
                    "aliases": item["aliases"],
                    "enabled": item["enabled"],
                    "complete": not item["template_draft"],
                }
                for item in routines
            ]
            names = [item["name"] for item in public if item["enabled"] and item["complete"]]
            return {
                "routines": public,
                "summary": (
                    "Available routines: " + ", ".join(names)
                    if names else "There are no enabled, complete routines."
                ),
            }

        if name == "run_routine":
            if self.routines is None:
                raise ToolError("routines are not available")
            ref = str(args.get("routine", "")).strip()
            if not ref:
                raise RoutineError("routine name is required")
            result = await self.routines.run(ref, source=str(args.get("source", "assistant")))
            return {**result, "summary": result["summary"]}

        if name == "list_calendar_events":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            return await self.calendar.upcoming(
                days=args.get("days", 14), limit=args.get("limit", 20)
            )

        if name == "get_next_meeting":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            return await self.calendar.next_meeting()

        if name == "create_calendar_event":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            draft_id = str(args.get("draft_id", "")).strip()
            if draft_id:
                result = await self.calendar.confirm_appointment(
                    draft_id, bool(args.get("confirmed"))
                )
                event = result.get("event") or {}
                result["summary"] = (
                    f"Created {event.get('title', 'the appointment')} "
                    f"for {event.get('start_at', 'the confirmed time')}."
                )
                return result
            if bool(args.get("confirmed")):
                raise CalendarToolError("review the appointment before confirming it")
            result = await self.calendar.review_appointment(
                title=str(args.get("title", "")),
                start_local=str(args.get("start_local", "")),
                duration_minutes=args.get("duration_minutes"),
                calendar_id=str(args.get("calendar_id", "")).strip() or None,
                timezone_name=str(args.get("timezone", "")).strip() or None,
            )
            draft = result["draft"]
            result.update({
                "needs_confirmation": True,
                "summary": (
                    f"Please confirm: {draft['title']} on {draft['when']} "
                    f"in {draft['calendar_name']}."
                ),
            })
            return result

        if name == "confirm_calendar_event":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            draft_id = str(args.get("draft_id", "")).strip()
            if not draft_id:
                raise CalendarToolError("there is no reviewed appointment to confirm")
            result = await self.calendar.confirm_appointment(draft_id, True)
            event = result.get("event") or {}
            result["summary"] = (
                f"Created {event.get('title', 'the appointment')} "
                f"for {event.get('start_at', 'the confirmed time')}."
            )
            return result

        if name == "search_music":
            if self.music is None:
                raise ToolError("music is not available")
            return {
                "results": await self.music.search(
                    args.get("query", ""),
                    provider=args.get("provider", "auto"),
                    kind=args.get("kind", "any"),
                    max_results=args.get("max_results", 10),
                )
            }

        if name == "play_music":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.play(
                item_id=str(args.get("item_id", "")).strip() or None,
                query=str(args.get("query", "")).strip() or None,
                provider=str(args.get("provider", "")).strip() or None,
                room=str(args.get("room", "")).strip() or None,
                favorites=bool(args.get("favorites")),
                playlist_name=str(args.get("playlist_name", "")).strip() or None,
                provider_playlist_id=(
                    str(args.get("provider_playlist_id", "")).strip() or None
                ),
            )

        if name == "control_music":
            if self.music is None:
                raise ToolError("music is not available")
            action = str(args.get("action", "")).strip().lower()
            if action == "mute":
                return await self.music.mute(
                    True, room=str(args.get("room", "")).strip() or None
                )
            if action == "unmute":
                return await self.music.mute(
                    False, room=str(args.get("room", "")).strip() or None
                )
            return await self.music.control(
                action, room=str(args.get("room", "")).strip() or None
            )

        if name == "seek_music":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.seek(
                args.get("offset_seconds"),
                room=str(args.get("room", "")).strip() or None,
            )

        if name == "set_music_volume":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.set_volume(
                percentage=args.get("percentage"),
                delta=args.get("delta"),
                room=str(args.get("room", "")).strip() or None,
            )

        if name == "manage_music_queue":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_queue(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            return {"queue": result} if isinstance(result, list) else result

        if name == "manage_music_favorites":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_favorites(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"favorites": result} if action in {"list", "get"} else result

        if name == "manage_music_playlist":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_playlist(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"playlists": result} if action in {"list", "all"} else result

        if name == "configure_music_room":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.configure_room(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"rooms": result} if action in {"list", "rooms"} else result

        if name == "search_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "play_youtube":
            # All production play_youtube requests route through YouTubeTool.
            # If a Media page owns the lease, the official embedded player runs
            # the video.  If no embedded owner is available, YouTubeTool opens
            # the selected canonical https watch URL in the host computer's
            # default browser (webbrowser.open_new_tab) — never a shell command,
            # never an arbitrary URL.  The 101/150 embed-error fallback is a
            # separate authenticated CSRF-protected endpoint on the Media page.
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            video = str(args.get("video", "") or args.get("video_id", "")).strip()
            query = str(args.get("query", "")).strip()
            url = str(args.get("url", "")).strip()
            title = str(args.get("title", "")).strip()
            playlist_url = str(args.get("playlist_url", "")).strip()
            playlist_id = str(args.get("playlist_id", "")).strip()
            playlist_query = str(args.get("playlist_query", "")).strip()
            # Playlist request takes precedence over ordinary video args.
            if playlist_url or playlist_id or playlist_query:
                return await self.youtube.play_playlist(
                    playlist_id=playlist_id,
                    playlist_url=playlist_url,
                    query=playlist_query,
                    title=title,
                )
            if url:
                return await self.youtube.play_url(url, title)
            if query:
                return await self.youtube.play_query(query, title)
            # Direct video_id / resume
            return await self.youtube.play(video, title)

        if name == "play_playlist":
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            return await self.youtube.play_playlist(
                playlist_id=str(args.get("playlist_id", "")).strip(),
                playlist_url=str(args.get("playlist_url", "")).strip(),
                query=str(args.get("playlist_query", "") or args.get("query", "")).strip(),
                title=str(args.get("title", "")).strip(),
            )

        if name == "pause_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.pause_media()

        if name == "stop_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.stop_media()

        if name == "seek_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.seek_media(args.get("offset_seconds"))

        if name == "restart_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.restart_media()

        if name == "set_youtube_volume":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            if "delta" in args and args.get("percentage") is None:
                return await self.youtube.adjust_volume(args.get("delta"))
            if args.get("percentage") is not None:
                return await self.youtube.set_volume(args.get("percentage"))
            if args.get("delta") is not None:
                return await self.youtube.adjust_volume(args.get("delta"))
            raise ToolError("provide a volume percentage or a relative change")

        if name == "mute_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.set_muted(True)

        if name == "unmute_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.set_muted(False)

        if name == "next_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.next()

        if name == "previous_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.previous()

        if name == "media_control":
            action = str(args.get("action", "")).strip()
            if not action:
                raise MediaError("action is required (play, pause, stop, next, previous)")
            return media_control(action)

        if name == "remember_fact":
            return await self.remember(str(args.get("content", "")), source=str(args.get("source", "voice")))

        if name == "recall_memories":
            return await self.recall(str(args.get("query", "")))

        if name == "forget_memory":
            return await self.forget(str(args.get("query", "")))

        if name.startswith("tv_"):
            return await self._dispatch_tv(name, args)

        raise GoveeError(f"unknown tool: {name}")  # not on the allowlist

    async def _dispatch_tv(self, name: str, args: dict) -> dict:
        """LG TV tools.  Every action is a narrow allowlisted method on the
        manager -- raw webOS URIs or payloads are impossible from here."""
        tv = self.tv
        if tv is None:
            raise ToolError("TV control is not available")

        if name == "tv_power":
            state = str(args.get("state", "")).strip().lower()
            if state == "on":
                return await tv.power_on()
            if state == "off":
                return await tv.power_off()
            raise WebOSTVError("state must be 'on' or 'off'")

        if name == "tv_set_volume":
            percentage = args.get("percentage")
            delta = args.get("delta")
            return await tv.set_volume(percentage=percentage, delta=delta)

        if name == "tv_mute":
            muted = args.get("muted")
            if not isinstance(muted, bool):
                raise WebOSTVError("muted must be true or false")
            return await tv.set_mute(muted)

        if name == "tv_media":
            return await tv.media(str(args.get("action", "")))

        if name == "tv_button":
            return await tv.button(str(args.get("button", "")))

        if name == "tv_type_text":
            text = args.get("text")
            if not isinstance(text, str) or not text.strip():
                raise WebOSTVError("text is required")
            return await tv.type_text(
                text,
                submit=bool(args.get("submit")),
                youtube_grid_ready=bool(args.get("youtube_grid_ready")),
            )

        if name == "tv_search_content":
            query = args.get("query")
            if not isinstance(query, str) or not query.strip():
                raise WebOSTVError("query is required")
            return await tv.search_content(str(args.get("app", "")), query)

        if name == "tv_set_input":
            return await tv.set_input(str(args.get("input", "")))

        if name == "tv_launch_app":
            return await tv.launch_app(str(args.get("app", "")))

        if name == "tv_search_apps":
            return tv.search_apps(str(args.get("query", "")))

        if name == "tv_status":
            return tv.status()

        raise GoveeError(f"unknown tool: {name}")  # not on the allowlist

    # -- persistent memory -------------------------------------------------
    async def remember(self, content: str, source: str = "voice") -> dict:
        content = " ".join(content.split()).strip()
        if not content:
            raise ToolError("nothing to remember")
        if len(content) > MAX_MEMORY_CHARS:
            content = content[:MAX_MEMORY_CHARS]
        mem_id = uuid.uuid4().hex[:12]
        await self.db.execute(
            "INSERT INTO memories (id, content, source, created_at) VALUES (?, ?, ?, ?)",
            (mem_id, content, source[:20], iso(utcnow())),
        )
        # cap total memories: oldest fall off
        await self.db.execute(
            "DELETE FROM memories WHERE id NOT IN "
            "(SELECT id FROM memories ORDER BY created_at DESC, id DESC LIMIT ?)",
            (MAX_MEMORIES,),
        )
        self.bus.publish("memories_changed", action="added")
        return {"remembered": content, "id": mem_id}

    async def recall(self, query: str = "", limit: int = 20) -> dict:
        query = " ".join(query.split()).strip()
        if query:
            words = [w for w in query.lower().split() if len(w) > 1][:8]
            if words:
                clause = " OR ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content, created_at FROM memories WHERE {clause} "
                    "ORDER BY created_at DESC, id DESC LIMIT ?",
                    tuple(f"%{w}%" for w in words) + (limit,),
                )
            else:
                rows = []
        else:
            rows = await self.db.fetchall(
                "SELECT id, content, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT ?",
                (limit,),
            )
        memories = [dict(r) for r in rows]
        return {"memories": memories, "count": len(memories)}

    async def forget(self, query: str) -> dict:
        query = " ".join(query.split()).strip()
        if not query:
            raise ToolError("say what to forget")
        rows = await self.db.fetchall(
            "SELECT id, content FROM memories WHERE LOWER(content) LIKE ?",
            (f"%{query.lower()}%",),
        )
        if not rows:
            # fall back to all-words match so "forget the parking spot" works
            words = [w for w in query.lower().split() if len(w) > 2][:8]
            if words:
                clause = " AND ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content FROM memories WHERE {clause}",
                    tuple(f"%{w}%" for w in words),
                )
        if not rows:
            return {"forgotten": 0, "items": []}
        ids = [r["id"] for r in rows]
        marks = ",".join("?" for _ in ids)
        await self.db.execute(f"DELETE FROM memories WHERE id IN ({marks})", tuple(ids))
        self.bus.publish("memories_changed", action="forgot")
        return {"forgotten": len(ids), "items": [r["content"] for r in rows]}
