"""Walkie-talkie voice sessions through the owner's relay.

One turn = record the sentence, write it down, ask the chosen model (running
any tools it requests), and speak the answer back. Slower and less fluid than
the live lines, but it rides Replit credits instead of a Google or OpenAI
account, and it can switch models per task.

The conversation lives entirely on the laptop: the relay sees one turn at a
time and keeps nothing.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import math

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from chat_core.pcm import resample_linear, rms16
from integrations.relay.client import RelayClient, RelayError, classify_turn, select_models
from apps.live_gateway.prompts import (
    PROMPT_TOOLS_SUFFIX,
    direct_expert_reply,
    is_voice_goodbye_phrase,
    is_voice_stop_phrase,
)
from apps.live_gateway.context import AssistantContextBuilder

log = logging.getLogger("relay.session")

MIC_RATE = 16000
OUT_RATE = 24000
CHUNK_SECONDS = 0.08           # what the mic loop delivers
MAX_TOOL_HOPS = 4              # tool-call round trips per turn
HISTORY_LIMIT = 16             # messages kept between turns (cost control)
def to_chat_tools(declarations: list[dict]) -> list[dict]:
    """Gemini-style tool schemas -> chat-completions `tools` array."""

    def fix_types(node):
        if isinstance(node, dict):
            return {
                key: (value.lower() if key == "type" and isinstance(value, str)
                      else fix_types(value))
                for key, value in node.items()
            }
        if isinstance(node, list):
            return [fix_types(item) for item in node]
        return node

    return [{
        "type": "function",
        "function": {
            "name": decl.get("name", ""),
            "description": decl.get("description", ""),
            "parameters": fix_types(decl.get("parameters") or {"type": "object", "properties": {}}),
        },
    } for decl in declarations]


class _CapReached(Exception):
    """Raised the moment the daily spend guard trips, even mid-turn."""


class RelayVoiceSession:
    """One conversation (possibly several back-and-forth turns)."""

    def __init__(
        self,
        client: RelayClient,
        settings: Settings,
        db: Database,
        bus: EventBus,
        state: StateMachine,
        tool_declarations: list[dict],
        tool_handler,
        audio_in: asyncio.Queue,
        audio_out: asyncio.Queue,
        on_speaking_change=None,
        on_activity=None,
        inactivity_timeout: float | None = None,
        initial_idle_seconds: float = 0.0,
        session_id: str | None = None,
        context: str | None = None,
    ) -> None:
        self.client = client
        self.settings = settings
        self.db = db
        self.bus = bus
        self.state = state
        self.tools = to_chat_tools(tool_declarations)
        self.tool_handler = tool_handler
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.on_speaking_change = on_speaking_change
        self.on_activity = on_activity
        self.inactivity_timeout = float(
            settings.inactivity_timeout_seconds
            if inactivity_timeout is None else inactivity_timeout
        )

        self._session_id = session_id  # for transcript persistence
        self._context = context

        self._closing = asyncio.Event()
        self._interrupted = asyncio.Event()
        self._history: list[dict] = []
        self._last_activity = time.monotonic() - max(0.0, float(initial_idle_seconds))
        self._close_reason = "stopped"

    # -- the interface the gateway expects ------------------------------
    async def close(self, reason: str = "stopped") -> None:
        self._close_reason = reason
        self._closing.set()

    def _mark_activity(self) -> None:
        self._last_activity = time.monotonic()
        if self.on_activity:
            self.on_activity()

    def _drain_output(self) -> None:
        """Called when the user talks over playback."""
        self._interrupted.set()
        try:
            while True:
                self.audio_out.get_nowait()
        except asyncio.QueueEmpty:
            pass
        # Also drop the mic audio that piled up behind the playback, so the
        # next capture starts from silence instead of stale sound.
        self._drain_input()

    def _drain_input(self) -> None:
        try:
            while True:
                self.audio_in.get_nowait()
        except asyncio.QueueEmpty:
            pass

    # -- helpers ---------------------------------------------------------
    def _silence_floor(self) -> float:
        return max(500.0, self.settings.interrupt_rms_threshold / 2)

    async def _over_daily_cap(self) -> bool:
        cap = int(getattr(self.settings, "relay_daily_request_cap", 0) or 0)
        if cap <= 0:
            return False
        row = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM usage_log "
            "WHERE event LIKE 'relay:%' AND ts >= date('now')",
        )
        return bool(row and row["n"] >= cap)

    async def _require_spend(self) -> None:
        """Checked before EVERY paid relay call, not just at turn start --
        a single turn can be transcribe + several asks + speak."""
        if await self._over_daily_cap():
            raise _CapReached()

    async def _capture_utterance(self) -> bytes | None:
        """Record one sentence from the mic queue. None = nobody spoke."""
        floor = self._silence_floor()
        chunks: list[bytes] = []
        silent = 0
        heard_any = False
        last_chunk = time.monotonic()
        while not self._closing.is_set():
            try:
                chunk = await asyncio.wait_for(self.audio_in.get(), timeout=0.5)
            except asyncio.TimeoutError:
                if (
                    not heard_any
                    and time.monotonic() - self._last_activity > self.inactivity_timeout
                ):
                    return None
                if heard_any and time.monotonic() - last_chunk > 2.0:
                    break  # mic feed hiccup mid-sentence; use what we have
                continue
            last_chunk = time.monotonic()
            loud = rms16(chunk) >= floor
            if not heard_any:
                if time.monotonic() - self._last_activity > self.inactivity_timeout:
                    return None
                if not loud:
                    continue  # still waiting for the first word
                heard_any = True
            chunks.append(chunk)
            silent = silent + 1 if not loud else 0
            long_enough = len(chunks) >= 8
            pause_chunks = max(10, math.ceil(
                getattr(self.settings, "speech_pause_ms", 1600) / 1000 / CHUNK_SECONDS
            ))
            if long_enough and silent >= pause_chunks:
                break
            if len(chunks) >= int(60 / CHUNK_SECONDS):    # allow long questions
                break
        if self._closing.is_set() or not chunks:
            return None
        return b"".join(chunks)

    async def _model_route(self, text: str) -> list[str]:
        if not hasattr(self.client, "discover_models"):
            # Compatibility for third-party client implementations. The server
            # still allowlists this value and applies its own default.
            return [
                self.settings.relay_command_model
                if classify_turn(text) == "command"
                else self.settings.relay_chat_model
            ]
        discovery = await self.client.discover_models()
        route = select_models(
            discovery,
            text,
            needs_tools=bool(self.tools),
            configured_command=self.settings.relay_command_model,
            configured_chat=self.settings.relay_chat_model,
        )
        if not route:
            raise RelayError("the relay advertises no compatible text model.")
        return route

    def _trace(self, event: dict) -> None:
        emit = getattr(self.client, "emit_event", None)
        if emit:
            emit(event)

    async def _think(self, text: str) -> str:
        """One ask() exchange, running tools until the model settles."""
        route = await self._model_route(text)
        route_index = 0
        model = route[route_index]
        self._trace({"event": "model", "classification": classify_turn(text),
                     "model": model, "fallbacks": route[1:], "duration_ms": 0.0})
        self._history.append({"role": "user", "content": text})
        context = self._context
        if context is None:
            context = (await AssistantContextBuilder(self.db).for_voice_session()).text
            self._context = context
        messages = [{"role": "system", "content": self.settings.system_prompt
                     + PROMPT_TOOLS_SUFFIX
                      + context
                      + " Reply in one or two short spoken sentences."}]
        messages += self._history[-HISTORY_LIMIT:]
        tools_used = 0

        for _hop in range(MAX_TOOL_HOPS):
            while True:
                await self._require_spend()
                try:
                    data = await self.client.ask(messages, self.tools, model)
                    break
                except RelayError as exc:
                    route_index += 1
                    if route_index >= len(route):
                        raise
                    previous = model
                    model = route[route_index]
                    await self.db.log(
                        "WARNING", "relay",
                        f"{previous} failed ({type(exc).__name__}); retrying with "
                        f"advertised compatible model {model}",
                    )
            usage = data.get("usage") or {}
            await self.db.usage(None, "relay:ask", f"{data.get('model', model)} "
                                f"in={usage.get('prompt_tokens', '?')} out={usage.get('completion_tokens', '?')}")
            calls = data.get("tool_calls") or []
            reply = str(data.get("reply") or "").strip()
            if not calls:
                if not reply:  # e.g. a reasoning model spent its whole budget thinking
                    reply = "Sorry, I came up empty on that one. Try asking again."
                self._history.append({"role": "assistant", "content": reply})
                if self._session_id and reply:
                    await self.db.add_transcript(self._session_id, "assistant", reply)
                return reply
            # The model wants tools: run them, then let it finish the thought.
            messages.append({"role": "assistant", "content": reply or None,
                             "tool_calls": calls})
            tools_used += len(calls)
            for call in calls:
                fn = call.get("function") or {}
                name = str(fn.get("name", ""))
                call_id = str(call.get("id", ""))
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except ValueError:
                    args = {}
                try:
                    tool_started = time.monotonic()
                    result = await self.tool_handler(call_id, name, args)
                except Exception as exc:  # sanitized, like the live brains
                    result = {"error": type(exc).__name__}
                finally:
                    self._trace({
                        "event": "tool", "tool": name,
                        "duration_ms": round((time.monotonic() - tool_started) * 1000, 1),
                    })
                messages.append({"role": "tool", "tool_call_id": call_id,
                                 "content": json.dumps(result)})
                direct = direct_expert_reply(
                    text, name, result, tool_call_count=tools_used
                )
                if direct is not None:
                    self._history.append({"role": "assistant", "content": direct})
                    if self._session_id:
                        await self.db.add_transcript(
                            self._session_id, "assistant", direct
                        )
                    return direct
                if name == "end_voice_session" or result.get("session_ended"):
                    self._close_reason = "stopped"
                    self._closing.set()
                    return ""
                if name == "stop_speaking":
                    # Interrupt only: flush any pending output and keep the
                    # conversation alive so the next turn needs no wake word.
                    self._drain_output()
                    return ""
        self._history.append({"role": "assistant", "content": "(tool loop cut short)"})
        return "I got stuck using my tools on that one."

    async def _speak(self, text: str) -> bool:
        if not text:
            return False
        await self._require_spend()
        pcm, rate = await self.client.speak(text, getattr(self.settings, "relay_voice", "alloy"))
        await self.db.usage(None, "relay:speak", f"{len(text)} chars")
        if rate != OUT_RATE:
            pcm = resample_linear(pcm, rate, OUT_RATE)
        self._interrupted.clear()
        if self.on_speaking_change:
            self.on_speaking_change(True)
        try:
            step = OUT_RATE * 2 // 5  # 200 ms slices keep interruption snappy
            for i in range(0, len(pcm), step):
                if self._interrupted.is_set() or self._closing.is_set():
                    break
                try:
                    self.audio_out.put_nowait(pcm[i:i + step])
                except asyncio.QueueFull:
                    await asyncio.sleep(0.2)
            # wait roughly until playback finishes (or the user cuts in)
            seconds = len(pcm) / 2 / OUT_RATE
            waited = 0.0
            while waited < seconds and not self._interrupted.is_set() and not self._closing.is_set():
                await asyncio.sleep(0.1)
                waited += 0.1
        finally:
            if self.on_speaking_change:
                self.on_speaking_change(False)
        return self._interrupted.is_set()

    # -- main ------------------------------------------------------------
    async def run(self) -> str:
        """Converse until silence or shutdown. Raises RelayError on trouble."""
        await self.client.health()  # fail fast with a clear sentence
        try:
            while not self._closing.is_set():
                await self._require_spend()
                self.state.set(ChatState.LISTENING, "relay: listening")
                pcm = await self._capture_utterance()
                if pcm is None:
                    return "inactivity"
                self.state.set(ChatState.LISTENING, "relay: writing it down")
                await self._require_spend()
                text = await self.client.transcribe(pcm)
                await self.db.usage(None, "relay:transcribe", f"{len(pcm) // 2 // MIC_RATE}s")
                if not text:
                    continue  # heard noise, not words; keep listening
                self._mark_activity()
                if self._session_id:
                    await self.db.add_transcript(self._session_id, "user", text)
                # A goodbye ends the whole conversation; a bare stop only flushes
                # output and keeps this walkie-talkie loop listening for the next
                # turn (no wake word needed).
                if is_voice_goodbye_phrase(text):
                    result = await self.tool_handler("", "end_voice_session", {})
                    if result.get("session_ended"):
                        self._close_reason = "stopped"
                        self._closing.set()
                        return "stopped"
                if is_voice_stop_phrase(text):
                    await self.tool_handler("", "stop_speaking", {})
                    self._drain_output()
                    continue  # keep listening; the conversation stays open
                self.state.set(ChatState.LISTENING, "relay: thinking")
                reply = await self._think(text)
                self.state.set(ChatState.SPEAKING, "relay: speaking")
                interrupted = await self._speak(reply)
                if reply:
                    self._mark_activity()
                # Playback is done: whatever the mic queued up meanwhile is
                # echo and room noise, not the next question.
                if not interrupted:
                    self._drain_input()
            return self._close_reason
        except _CapReached:
            await self.db.log(
                "WARNING", "relay",
                "daily relay limit reached; staying quiet until tomorrow "
                "(raise it in Settings -> Brain if this is too strict)")
            return "daily relay limit reached"
