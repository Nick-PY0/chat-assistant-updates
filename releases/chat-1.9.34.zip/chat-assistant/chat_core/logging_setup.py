"""Quiet-by-default logging.

In low-power mode the console shows only warnings and errors, keeping the
console window ("the black screen") calm and the CPU idle. Full detail is
always available on the dashboard Logs page, sourced from SQLite.
Exception text is sanitized so secrets can never leak into logs.
"""

from __future__ import annotations

import logging
import re

_SECRET_RE = re.compile(
    r"(key=)[A-Za-z0-9_\-]{8,}|AIza[A-Za-z0-9_\-]{10,}|"
    r"\b(?:sk-[A-Za-z0-9_-]{16,}|AKIA[A-Z0-9]{16}|"
    r"gh[pousr]_[A-Za-z0-9]{20,}|xox[baprs]-[A-Za-z0-9-]{16,})\b"
)

# High-confidence shapes used at network egress boundaries. Labels require a
# supplied value, so benign questions such as "how do API keys work?" pass.
_SUPPLIED_SECRET_RE = re.compile(
    r"""(?ix)
    (?:\b(?:my\s+)?(?:api[\s_-]*key|password|passphrase|access[\s_-]*token|
        auth(?:entication)?[\s_-]*token|device[\s_-]*id|client[\s_-]*secret)
        \s*(?:is|=|:)\s*["']?
        (?!(?:used|needed|required|credential|concept|identifier|sensitive|
            unique|important|provided|stored|rotated|hashed|encrypted|redacted|
            how|what)\b)
        [^\s"',;]{3,})
    |(?:\buse\s+(?:this\s+|the\s+)?token\s+["']?[A-Za-z0-9._~+/\-=]{8,})
    |(?:\bbearer\s+[A-Za-z0-9._~+/\-=]{8,})
    |(?:-----BEGIN\s+(?:[A-Z0-9]+\s+)?PRIVATE\s+KEY-----)
    |(?:\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b)
    |(?:\b(?:sk-[A-Za-z0-9_-]{16,}|AIza[A-Za-z0-9_-]{20,}|
        AKIA[A-Z0-9]{16}|gh[pousr]_[A-Za-z0-9]{20,}|
        xox[baprs]-[A-Za-z0-9-]{16,}|ya29\.[A-Za-z0-9_-]{16,})\b)
    |(?:(?:https?|postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)://
        [^/\s:@]+:[^/\s@]+@)
    |(?:\b(?:server|host)\s*=[^;\s]+;\s*
        (?:user(?:\s+id)?|uid)\s*=[^;]+;\s*
        (?:password|pwd)\s*=[^;\s]+)
    """
)


def sanitize(text: str) -> str:
    return _SECRET_RE.sub(r"\1[redacted]", text)


def contains_supplied_secret(text: str) -> bool:
    """Whether text contains a high-confidence credential/private-id value."""
    return bool(_SUPPLIED_SECRET_RE.search(str(text or "")))


class SanitizingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return sanitize(super().format(record))


def setup_logging(level: str = "WARNING") -> None:
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.WARNING))
    handler = logging.StreamHandler()
    handler.setFormatter(SanitizingFormatter("%(asctime)s %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
    root.handlers[:] = [handler]
    for noisy in ("uvicorn.access", "websockets", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
