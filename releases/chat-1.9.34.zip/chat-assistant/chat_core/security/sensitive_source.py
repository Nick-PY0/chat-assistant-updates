"""Conservative checks for credential material in publishable source files.

These checks are intentionally stricter than log redaction. A false positive
asks the owner to move configuration to environment storage; a false negative
could put a credential into a Git commit or immutable public release.
"""

from __future__ import annotations

import re
from pathlib import PurePosixPath

_ASSIGNMENT_RE = re.compile(
    r"""(?imx)
    (?=
        (?:^|[\s{,(])(?:export\s+)?
        ["']?(?P<name>[A-Za-z_][A-Za-z0-9_.-]*)["']?
        \s*(?:=|:)\s*
        (?P<value>[^\r\n]+)
    )
    """
)
_TOKEN_VALUE_RE = re.compile(
    r"""(?ix)
    (?:-----BEGIN\s+(?:[A-Z0-9]+\s+)?PRIVATE\s+KEY-----)
    |(?:\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b)
    |(?:\b(?:sk-[A-Za-z0-9_-]{16,}|AIza[A-Za-z0-9_-]{20,}|
        AKIA[A-Z0-9]{16}|gh[pousr]_[A-Za-z0-9]{20,}|
        xox[baprs]-[A-Za-z0-9-]{16,}|ya29\.[A-Za-z0-9_-]{16,})\b)
    |(?:(?:https?|postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis)://
        [^/\s:@]+:[^/\s@]+@)
    """
)
_SENSITIVE_SUFFIX_RE = re.compile(
    r"""(?ix)
    (?:^|_)
    (?:
        api_?key|access_?key|secret|password|passwd|passphrase|
        access_?token|auth_?token|refresh_?token|client_?secret|
        private_?key|signing_?key|relay_?key|credential
    )
    (?:$|_(?:value|hash|ciphertext|encrypted|raw))
    """
)
_SAFE_VALUE_MARKERS = {
    "example",
    "placeholder",
    "change-me",
    "changeme",
    "replace-me",
    "replace_me",
    "redacted",
    "dummy",
    "fake",
    "your-key",
    "your_key",
    "your-token",
    "your_token",
    "not-set",
    "not_set",
}
_SAFE_EXPRESSION_PREFIXES = (
    "os.environ",
    "os.getenv",
    "getenv(",
    "process.env",
    "settings.",
    "config.",
    "re.compile(",
    "secrets.",
    "secret(",
    "field(",
)
_SENSITIVE_FILENAMES = {
    ".env",
    ".npmrc",
    "credentials.json",
    "secrets.json",
    "service-account.json",
    "service_account.json",
    "master.key",
    "authorized_keys",
    "id_rsa",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
}
_SENSITIVE_SUFFIXES = {
    ".pem", ".key", ".p12", ".pfx", ".jks", ".keystore",
    ".gpg", ".asc", ".der",
}
_SENSITIVE_DIRECTORIES = {".ssh", ".aws", ".azure", ".gnupg"}
_CODE_REFERENCE_SUFFIXES = {
    ".c", ".cc", ".cpp", ".go", ".h", ".hpp", ".java", ".js", ".jsx",
    ".kt", ".mjs", ".php", ".pl", ".py", ".rb", ".rs", ".swift",
    ".ts", ".tsx",
}


def is_sensitive_source_path(path: str) -> bool:
    """Whether a repository-relative path is reserved for credential material."""
    pure = PurePosixPath(str(path or "").replace("\\", "/"))
    parts = tuple(part.casefold() for part in pure.parts)
    if any(part in _SENSITIVE_DIRECTORIES for part in parts):
        return True
    name = pure.name.casefold()
    if name in _SENSITIVE_FILENAMES:
        return True
    if name.startswith(".env.") and name != ".env.example":
        return True
    if PurePosixPath(name).suffix in _SENSITIVE_SUFFIXES:
        return True
    return "signing_key" in name or "private_key" in name


def contains_sensitive_source(text: str, *, path: str = "") -> bool:
    """Detect provider tokens and conservative credential assignments."""
    value = str(text or "")
    code_references = PurePosixPath(path.casefold()).suffix in _CODE_REFERENCE_SUFFIXES
    if _TOKEN_VALUE_RE.search(value):
        return True
    for match in _ASSIGNMENT_RE.finditer(value):
        name = match.group("name").casefold().replace("-", "_").replace(".", "_")
        if not _SENSITIVE_SUFFIX_RE.search(name):
            continue
        raw = match.group("value").strip().rstrip(",;").strip()
        if not raw or raw.casefold() in {"none", "null", "false", '""', "''"}:
            continue
        lowered = raw.casefold()
        if any(marker in lowered for marker in _SAFE_VALUE_MARKERS):
            continue
        unquoted = raw
        quoted_literal = False
        if unquoted and unquoted[0] in {'"', "'"}:
            closing = unquoted.find(unquoted[0], 1)
            if closing > 0:
                unquoted = unquoted[1:closing].strip()
                quoted_literal = True
        expression = unquoted.casefold()
        if re.fullmatch(r"<[A-Za-z0-9_. -]{1,100}>", unquoted):
            continue
        if expression.startswith(_SAFE_EXPRESSION_PREFIXES):
            continue
        if re.fullmatch(r"[A-Z][A-Z0-9_]{5,}", unquoted):
            continue
        if code_references and re.fullmatch(
            r"[A-Za-z_][A-Za-z0-9_.]*", unquoted
        ):
            continue
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", unquoted):
            referenced = unquoted.casefold().replace(".", "_")
            if _SENSITIVE_SUFFIX_RE.search(referenced):
                continue
        if (
            len(unquoted) >= 6
            and (
                quoted_literal
                or re.fullmatch(r"[A-Za-z0-9._~+/\-=]{6,}", unquoted)
            )
        ):
            return True
    return False