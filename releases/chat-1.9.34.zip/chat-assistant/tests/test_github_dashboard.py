from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def github_client(settings, monkeypatch):
    settings.relay_url = ""

    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    app = create_app(runtime)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test"
    ) as client:
        client.app = app
        yield client
    await runtime.stop()


async def setup(github_client) -> str:
    response = await github_client.post(
        "/setup",
        data={"password": "hunter2secure", "confirm": "hunter2secure"},
    )
    assert response.status_code == 303
    token = github_client.cookies.get(COOKIE)
    return github_client.app.state.sessions.csrf_for(token)


async def test_github_page_stays_behind_dashboard_auth(github_client):
    response = await github_client.get("/github")
    assert response.status_code == 303
    assert response.headers["location"] == "/setup"

    await setup(github_client)
    response = await github_client.get("/github")
    assert response.status_code == 200
    assert "GitHub Sync & Publish" in response.text
    assert "separate operator-only publishing credential" in response.text


async def test_github_status_never_exposes_credentials(github_client):
    await setup(github_client)
    response = await github_client.get("/api/github/status")
    assert response.status_code == 200
    body = response.json()
    assert body["available"] is False
    assert body["authenticated"] is False
    assert body["release_permissions"] == "separate"
    assert "secret" not in response.text.casefold()
    assert "token" not in response.text.casefold()


async def test_github_writes_require_csrf(github_client):
    await setup(github_client)
    response = await github_client.post(
        "/api/github/config",
        json={"repository": "owner/fork", "branch": "main"},
        headers={"x-csrf": "forged"},
    )
    assert response.status_code == 403