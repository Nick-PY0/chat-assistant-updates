from __future__ import annotations

import base64
import hashlib
from pathlib import Path

import pytest
import httpx

from integrations.github_publish import (
    GitHubBrokerClient,
    GitHubBrokerError,
    GitHubPublishError,
    GitHubPublishService,
)

HEAD_A = "a" * 40
HEAD_B = "b" * 40
HEAD_C = "c" * 40


class MemoryBroker:
    def __init__(self, files: dict[str, bytes] | None = None) -> None:
        self.files = dict(files or {})
        self.head = HEAD_A
        self.commits: list[dict] = []
        self.fail_commit = False

    async def status(self):
        return {"login": "connected-owner"}

    async def snapshot(self, repository, branch, paths):
        return {
            "repository": {"owner": repository.split("/")[0], "name": repository.split("/")[1]},
            "branch": branch,
            "head": self.head,
            "files": [
                {
                    "path": path,
                    "exists": path in self.files,
                    "blobSha": (
                        hashlib.sha1(self.files[path]).hexdigest()
                        if path in self.files
                        else None
                    ),
                    "content": (
                        base64.b64encode(self.files[path]).decode()
                        if path in self.files
                        else ""
                    ),
                }
                for path in paths
            ],
        }

    async def commit(
        self, repository, branch, expected_head, message, files
    ):
        if self.fail_commit or expected_head != self.head:
            raise GitHubBrokerError(
                "The repository changed; retry from a fresh snapshot.",
                status=409,
            )
        self.commits.append(
            {
                "repository": repository,
                "branch": branch,
                "expected_head": expected_head,
                "message": message,
                "files": files,
            }
        )
        for file in files:
            self.files[file["path"]] = base64.b64decode(file["content"])
        self.head = HEAD_C
        return {
            "repository": repository,
            "branch": branch,
            "previousHead": expected_head,
            "commit": self.head,
        }


def make_service(
    root: Path,
    data: Path,
    broker: MemoryBroker,
    *,
    protected: set[str] | None = None,
) -> GitHubPublishService:
    async def factory():
        return broker

    return GitHubPublishService(
        root,
        data,
        factory,
        protected_repositories=lambda: protected or set(),
    )


def write(root: Path, path: str, value: bytes) -> None:
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(value)


async def test_publish_review_commits_exact_reviewed_bytes(tmp_path: Path):
    root = tmp_path / "chat"
    data = tmp_path / "data"
    root.mkdir()
    write(root, "chat_core/feature.py", b"enabled = True\n")
    broker = MemoryBroker({"src/chat_core/feature.py": b"enabled = False\n"})
    service = make_service(root, data, broker)
    config = service.validate_config("owner/fork", "feature/safe", "src")

    review = await service.review(
        owner="session-a",
        direction="publish",
        config=config,
        paths=["chat_core/feature.py"],
    )
    assert review["repository"] == "owner/fork"
    assert review["branch"] == "feature/safe"
    assert review["head"] == HEAD_A
    assert review["changes"][0]["status"] == "modified"
    assert "+enabled = True" in review["changes"][0]["diff"]

    result = await service.publish(
        owner="session-a",
        review_id=review["review_id"],
        message="Enable feature",
        confirm_repository="owner/fork",
        confirm_branch="feature/safe",
    )
    assert result["commit"] == HEAD_C
    assert broker.files["src/chat_core/feature.py"] == b"enabled = True\n"
    assert broker.commits[0]["expected_head"] == HEAD_A


async def test_remote_conflict_refuses_publish_without_overwrite(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "feature.py", b"local = 2\n")
    broker = MemoryBroker({"feature.py": b"remote = 1\n"})
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session", direction="publish", config=config, paths=["feature.py"]
    )
    broker.fail_commit = True

    with pytest.raises(GitHubPublishError, match="repository changed") as caught:
        await service.publish(
            owner="session",
            review_id=review["review_id"],
            message="Update feature",
            confirm_repository="owner/fork",
            confirm_branch="main",
        )
    assert caught.value.status == 409
    assert broker.files["feature.py"] == b"remote = 1\n"
    assert broker.commits == []


async def test_local_edit_after_review_refuses_publish(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "feature.py", b"value = 2\n")
    broker = MemoryBroker({"feature.py": b"value = 1\n"})
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session", direction="publish", config=config, paths=["feature.py"]
    )
    write(root, "feature.py", b"value = 3\n")

    with pytest.raises(GitHubPublishError, match="changed after review") as caught:
        await service.publish(
            owner="session",
            review_id=review["review_id"],
            message="Update feature",
            confirm_repository="owner/fork",
            confirm_branch="main",
        )
    assert caught.value.status == 409
    assert broker.commits == []


async def test_secret_content_is_refused_without_echoing_secret(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    token = "ghp_" + "A" * 30
    write(root, "feature.py", f'TOKEN = "{token}"\n'.encode())
    service = make_service(root, tmp_path / "data", MemoryBroker())
    config = service.validate_config("owner/fork", "main")

    with pytest.raises(GitHubPublishError) as caught:
        await service.review(
            owner="session",
            direction="publish",
            config=config,
            paths=["feature.py"],
        )
    assert "credential" in str(caught.value)
    assert token not in str(caught.value)


@pytest.mark.parametrize(
    "source",
    [
        'OPENAI_API_KEY = "{value}"\n',
        'client = OpenAI(api_key="{value}")\n',
        'config = {{"password": "{value}"}}\n',
    ],
)
async def test_generic_api_key_assignment_is_refused(
    tmp_path: Path, source: str
):
    root = tmp_path / "chat"
    root.mkdir()
    value = "arbitrary-value-that-is-not-provider-shaped"
    write(root, "feature.py", source.format(value=value).encode())
    service = make_service(root, tmp_path / "data", MemoryBroker())
    config = service.validate_config("owner/fork", "main")

    with pytest.raises(GitHubPublishError) as caught:
        await service.review(
            owner="session",
            direction="publish",
            config=config,
            paths=["feature.py"],
        )
    assert "credential" in str(caught.value)
    assert value not in str(caught.value)


async def test_sync_conflict_keeps_local_file_and_creates_no_checkpoint(
    tmp_path: Path,
):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "feature.py", b"value = 'local'\n")
    broker = MemoryBroker({"feature.py": b"value = 'remote'\n"})
    data = tmp_path / "data"
    service = make_service(root, data, broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session", direction="sync", config=config, paths=["feature.py"]
    )
    broker.head = HEAD_B

    with pytest.raises(GitHubPublishError, match="repository changed") as caught:
        await service.sync(
            owner="session",
            review_id=review["review_id"],
            confirm_repository="owner/fork",
            confirm_branch="main",
        )
    assert caught.value.status == 409
    assert (root / "feature.py").read_bytes() == b"value = 'local'\n"
    assert service.latest_checkpoint() is None


async def test_sync_checkpoint_round_trip_and_restore(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "feature.py", b"value = 'local'\n")
    broker = MemoryBroker({"feature.py": b"value = 'remote'\n"})
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session", direction="sync", config=config, paths=["feature.py"]
    )
    result = await service.sync(
        owner="session",
        review_id=review["review_id"],
        confirm_repository="owner/fork",
        confirm_branch="main",
    )
    assert (root / "feature.py").read_bytes() == b"value = 'remote'\n"
    assert service.latest_checkpoint() == result["checkpoint_id"]

    restored = service.restore(result["checkpoint_id"])
    assert restored["files"] == ["feature.py"]
    assert (root / "feature.py").read_bytes() == b"value = 'local'\n"
    assert service.latest_checkpoint() is None


async def test_restore_refuses_to_overwrite_newer_local_work(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "feature.py", b"before = True\n")
    broker = MemoryBroker({"feature.py": b"after = True\n"})
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session", direction="sync", config=config, paths=["feature.py"]
    )
    result = await service.sync(
        owner="session",
        review_id=review["review_id"],
        confirm_repository="owner/fork",
        confirm_branch="main",
    )
    write(root, "feature.py", b"newer = True\n")

    with pytest.raises(GitHubPublishError, match="newer local work") as caught:
        service.restore(result["checkpoint_id"])
    assert caught.value.status == 409
    assert (root / "feature.py").read_bytes() == b"newer = True\n"


async def test_failed_multifile_sync_reverses_all_earlier_writes(
    tmp_path: Path, monkeypatch
):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "one.py", b"one = 'before'\n")
    write(root, "two.py", b"two = 'before'\n")
    broker = MemoryBroker(
        {"one.py": b"one = 'after'\n", "two.py": b"two = 'after'\n"}
    )
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session",
        direction="sync",
        config=config,
        paths=["one.py", "two.py"],
    )

    import integrations.github_publish.service as service_module

    original_replace = service_module.os.replace
    staged_replaces = 0

    def fail_second_staged(source, target):
        nonlocal staged_replaces
        if ".github-stage-" in str(source):
            staged_replaces += 1
            if staged_replaces == 2:
                raise OSError("simulated second-file failure")
        return original_replace(source, target)

    monkeypatch.setattr(service_module.os, "replace", fail_second_staged)
    with pytest.raises(GitHubPublishError, match="earlier file changes"):
        await service.sync(
            owner="session",
            review_id=review["review_id"],
            confirm_repository="owner/fork",
            confirm_branch="main",
        )
    assert (root / "one.py").read_bytes() == b"one = 'before'\n"
    assert (root / "two.py").read_bytes() == b"two = 'before'\n"
    assert service.latest_checkpoint() is None


async def test_failed_multifile_restore_keeps_complete_synced_state(
    tmp_path: Path, monkeypatch
):
    root = tmp_path / "chat"
    root.mkdir()
    write(root, "one.py", b"one = 'before'\n")
    write(root, "two.py", b"two = 'before'\n")
    broker = MemoryBroker(
        {"one.py": b"one = 'after'\n", "two.py": b"two = 'after'\n"}
    )
    service = make_service(root, tmp_path / "data", broker)
    config = service.validate_config("owner/fork", "main")
    review = await service.review(
        owner="session",
        direction="sync",
        config=config,
        paths=["one.py", "two.py"],
    )
    result = await service.sync(
        owner="session",
        review_id=review["review_id"],
        confirm_repository="owner/fork",
        confirm_branch="main",
    )

    import integrations.github_publish.service as service_module

    original_replace = service_module.os.replace
    staged_replaces = 0

    def fail_second_staged(source, target):
        nonlocal staged_replaces
        if ".github-stage-" in str(source):
            staged_replaces += 1
            if staged_replaces == 2:
                raise OSError("simulated restore failure")
        return original_replace(source, target)

    monkeypatch.setattr(service_module.os, "replace", fail_second_staged)
    with pytest.raises(GitHubPublishError, match="earlier restore changes"):
        service.restore(result["checkpoint_id"])
    assert (root / "one.py").read_bytes() == b"one = 'after'\n"
    assert (root / "two.py").read_bytes() == b"two = 'after'\n"
    assert service.latest_checkpoint() == result["checkpoint_id"]


def test_release_repository_and_release_paths_are_separated(tmp_path: Path):
    root = tmp_path / "chat"
    root.mkdir()
    service = make_service(
        root,
        tmp_path / "data",
        MemoryBroker(),
        protected={"official/updates"},
    )
    with pytest.raises(GitHubPublishError, match="updates repository"):
        service.validate_config("official/updates", "main")
    with pytest.raises(GitHubPublishError, match="releases folder"):
        service.validate_config("owner/fork", "main", "releases")
    with pytest.raises(GitHubPublishError, match="Credential"):
        service._validate_repo_path("deployment/release/signing_key.pem")
    with pytest.raises(GitHubPublishError, match="Credential"):
        service._validate_repo_path("config/credentials.json")


async def test_broker_error_redacts_credentials():
    token = "ghp_" + "B" * 30

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["x-chat-relay-key"] == "relay-password"
        return httpx.Response(502, json={"error": f"upstream echoed {token}"})

    client = GitHubBrokerClient(
        "https://relay.test",
        "relay-password",
        transport=httpx.MockTransport(handler),
    )
    with pytest.raises(GitHubBrokerError) as caught:
        await client.status()
    assert token not in str(caught.value)
    assert "[redacted]" in str(caught.value)