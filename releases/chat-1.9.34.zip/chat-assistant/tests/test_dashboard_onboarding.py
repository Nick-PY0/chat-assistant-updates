"""Tests for onboarding endpoints: /ca-cert.pem (loopback-only), /mobile-setup
(loopback vs LAN rendering, fingerprint), /api/healthz, and /api/startup/* controls."""

from __future__ import annotations

import datetime
import sys
from pathlib import Path

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


def _make_app(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None
    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    return create_app(rt)


@pytest.fixture
async def client(rt, monkeypatch):
    """Loopback client (default: ASGITransport reports 127.0.0.1)."""
    app = _make_app(rt, monkeypatch)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


@pytest.fixture
async def lan_client(rt, monkeypatch):
    """LAN client — transport reports a non-loopback IP (192.168.1.100)."""
    app = _make_app(rt, monkeypatch)
    transport = httpx.ASGITransport(app=app, client=("192.168.1.100", 50000))
    async with httpx.AsyncClient(transport=transport, base_url="http://192.168.1.100") as c:
        c.app = app
        yield c


async def login(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    token = client.cookies.get(COOKIE)
    return {"x-csrf": client.app.state.sessions.csrf_for(token)}


def _write_real_ca_cert(data_path: Path) -> str:
    """Generate a real CA cert into data_path and return its expected fingerprint."""
    from deployment.windows import make_cert
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes

    NOW = datetime.datetime(2026, 8, 19, 12, 0, tzinfo=datetime.timezone.utc)
    paths = make_cert.create_certificates(
        data_path,
        hostname="chat-test",
        ip_addresses=[],
        now=NOW,
    )
    # Compute expected fingerprint
    data = paths.ca_certificate.read_bytes()
    cert = x509.load_pem_x509_certificate(data)
    digest = cert.fingerprint(hashes.SHA256())
    return ":".join(f"{b:02X}" for b in digest)


# ---------------------------------------------------------------------------
# /api/healthz
# ---------------------------------------------------------------------------

async def test_healthz_is_public_and_identifies_chat(client):
    """No auth required; response identifies this as chat-assistant."""
    resp = await client.get("/api/healthz")
    assert resp.status_code == 200
    data = resp.json()
    assert data["app"] == "chat-assistant"
    assert "version" in data


async def test_healthz_accessible_from_lan(lan_client):
    """Health identity endpoint is also available from LAN (no secrets exposed)."""
    resp = await lan_client.get("/api/healthz")
    assert resp.status_code == 200
    assert resp.json()["app"] == "chat-assistant"


# ---------------------------------------------------------------------------
# /ca-cert.pem — loopback restriction
# ---------------------------------------------------------------------------

async def test_ca_cert_404_before_certificate_is_generated(client):
    """Loopback request, no cert file yet → 404."""
    resp = await client.get("/ca-cert.pem")
    assert resp.status_code == 404


async def test_ca_cert_served_to_loopback(client, rt):
    """Loopback request with cert file present → 200 with correct content."""
    public = rt.settings.data_path / "ca-cert.pem"
    private = rt.settings.data_path / "ca-key.pem"
    public.write_text("PUBLIC CERT DATA", encoding="ascii")
    private.write_text("PRIVATE KEY DATA", encoding="ascii")

    response = await client.get("/ca-cert.pem")
    assert response.status_code == 200
    assert response.content == b"PUBLIC CERT DATA"
    # Private key must NEVER appear in the response
    assert b"PRIVATE KEY DATA" not in response.content
    assert response.headers["x-content-type-options"] == "nosniff"
    assert "no-store" in response.headers.get("cache-control", "")


async def test_ca_cert_blocked_from_lan(lan_client, rt):
    """LAN request must be rejected with 403 even when cert file exists."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("PUBLIC CERT DATA", encoding="ascii")

    response = await lan_client.get("/ca-cert.pem")
    assert response.status_code == 403
    body = response.json()
    assert "error" in body
    # Error must mention the restriction and suggest out-of-band transfer
    assert "computer" in body["error"].lower() or "loopback" in body["error"].lower() or "127" in body["error"]


async def test_ca_cert_lan_403_even_without_file(lan_client):
    """LAN request gets 403 regardless of whether the cert file exists."""
    response = await lan_client.get("/ca-cert.pem")
    assert response.status_code == 403


async def test_ca_cert_download_name_is_chat_branded(client, rt):
    """Filename in Content-Disposition must be Chat-branded, not Jarvis."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    response = await client.get("/ca-cert.pem")
    assert response.status_code == 200
    cd = response.headers.get("content-disposition", "")
    assert "chat-assistant" in cd.lower() or "chat" in cd.lower()
    assert "jarvis" not in cd.lower()


async def test_ca_cert_never_serves_private_key(client, rt):
    """Requesting /ca-key.pem must 404 (it is not a defined route)."""
    resp = await client.get("/ca-key.pem")
    assert resp.status_code == 404


async def test_ca_cert_private_key_unreachable_from_lan(lan_client):
    """LAN client cannot reach the private key path either."""
    resp = await lan_client.get("/ca-key.pem")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# /mobile-setup — page accessibility and branding
# ---------------------------------------------------------------------------

async def test_mobile_setup_accessible_without_login_from_loopback(client):
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "Mobile HTTPS setup" in resp.text


async def test_mobile_setup_loopback_binding_shows_phone_access_off(client, rt):
    rt.settings.dashboard_host = "127.0.0.1"
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "PHONE ACCESS IS OFF" in resp.text
    assert "Settings" in resp.text
    assert "restart Chat" in resp.text


async def test_mobile_setup_lan_binding_distinguishes_connection_errors(client, rt):
    rt.settings.dashboard_host = "0.0.0.0"
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "timeout means" in resp.text
    assert "allow_lan_access.bat" in resp.text
    assert "certificate/privacy error means the phone reached Chat" in resp.text


async def test_mobile_setup_accessible_without_login_from_lan(lan_client):
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "Mobile HTTPS setup" in resp.text


async def test_mobile_setup_branding_is_chat_not_jarvis(client):
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "Jarvis" not in resp.text


async def test_mobile_setup_lan_branding_is_chat_not_jarvis(lan_client):
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    assert "Jarvis" not in resp.text


# ---------------------------------------------------------------------------
# /mobile-setup — no CA yet
# ---------------------------------------------------------------------------

async def test_mobile_setup_no_ca_loopback_shows_generation_instructions(client, rt):
    """When CA not yet generated, loopback view tells owner how to generate it."""
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text
    assert "make_cert" in text or "ca-cert" in text.lower()
    # Must NOT show the download link
    assert 'href="/ca-cert.pem"' not in text


async def test_mobile_setup_no_ca_lan_shows_generation_instructions(lan_client, rt):
    """When CA not yet generated, LAN view tells user to go to the server first."""
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text
    assert "make_cert" in text or "ca-cert" in text.lower()
    assert 'href="/ca-cert.pem"' not in text


# ---------------------------------------------------------------------------
# /mobile-setup — loopback view with CA present
# ---------------------------------------------------------------------------

async def test_mobile_setup_loopback_shows_download_button_when_ca_exists(client, rt):
    """Loopback view must show the download link for the CA cert."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    assert 'href="/ca-cert.pem"' in resp.text


async def test_mobile_setup_loopback_shows_fingerprint_for_real_cert(client, rt):
    """Loopback view must display the SHA-256 fingerprint of the actual CA cert."""
    expected_fp = _write_real_ca_cert(rt.settings.data_path)
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text
    # Fingerprint appears as colon-separated hex in the page
    # Check at least the first few bytes are present
    first_chunk = expected_fp[:14]  # e.g. "AA:BB:CC:DD:EE"
    assert first_chunk in text, f"Fingerprint chunk '{first_chunk}' not found in page"


async def test_mobile_setup_loopback_mentions_out_of_band_transfer(client, rt):
    """Loopback view must instruct the owner to transfer the file out-of-band."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text.lower()
    # Must mention a safe transfer method
    assert "usb" in text or "airdrop" in text or "trusted" in text


async def test_mobile_setup_loopback_warns_against_bypassing(client, rt):
    """Loopback view must warn against bypassing certificate warnings."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text.lower()
    assert "bypass" in text or "warning" in text or "do not" in text


# ---------------------------------------------------------------------------
# /mobile-setup — LAN view with CA present (no download link)
# ---------------------------------------------------------------------------

async def test_mobile_setup_lan_does_not_show_download_link(lan_client, rt):
    """LAN view must NOT offer the download link — security requirement."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    assert 'href="/ca-cert.pem"' not in resp.text


async def test_mobile_setup_lan_shows_fingerprint_for_real_cert(lan_client, rt):
    """LAN view must display the fingerprint so the user can verify the file."""
    expected_fp = _write_real_ca_cert(rt.settings.data_path)
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    first_chunk = expected_fp[:14]
    assert first_chunk in resp.text, (
        f"Fingerprint chunk '{first_chunk}' not found in LAN page. "
        "LAN page must show fingerprint even without download link."
    )


async def test_mobile_setup_lan_instructs_go_to_server(lan_client, rt):
    """LAN view must tell the user to go to the Chat computer first."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text.lower()
    # Should mention the Chat computer / local address
    assert "127.0.0.1" in text or "chat computer" in text or "home server" in text


async def test_mobile_setup_lan_warns_against_bypassing(lan_client, rt):
    """LAN view must also warn against bypassing certificate warnings."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("CERT", encoding="ascii")
    resp = await lan_client.get("/mobile-setup")
    assert resp.status_code == 200
    text = resp.text.lower()
    assert "bypass" in text or "warning" in text or "do not" in text


# ---------------------------------------------------------------------------
# Fingerprint integrity — tampered cert gets a different fingerprint
# ---------------------------------------------------------------------------

async def test_fingerprint_changes_when_cert_changes(client, rt):
    """Two different CA certs must produce different fingerprints on the page."""
    import time as _time

    NOW1 = datetime.datetime(2026, 8, 19, 12, 0, tzinfo=datetime.timezone.utc)
    NOW2 = datetime.datetime(2027, 1, 1, 0, 0, tzinfo=datetime.timezone.utc)

    from deployment.windows import make_cert

    fp1 = _write_real_ca_cert(rt.settings.data_path)
    resp1 = await client.get("/mobile-setup")
    assert fp1[:14] in resp1.text

    # Re-generate with a different time so a NEW CA is created
    # Force CA regeneration by deleting the existing one
    (rt.settings.data_path / "ca-cert.pem").unlink()
    (rt.settings.data_path / "ca-key.pem").unlink()

    paths2 = make_cert.create_certificates(
        rt.settings.data_path,
        hostname="chat-test",
        ip_addresses=[],
        now=NOW2,
    )
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    cert2 = x509.load_pem_x509_certificate(paths2.ca_certificate.read_bytes())
    digest2 = cert2.fingerprint(hashes.SHA256())
    fp2 = ":".join(f"{b:02X}" for b in digest2)

    assert fp1 != fp2, "Different CA certs must produce different fingerprints"

    resp2 = await client.get("/mobile-setup")
    assert fp2[:14] in resp2.text
    # Old fingerprint must not appear on page (would indicate stale data)
    assert fp1[:14] not in resp2.text


async def test_fingerprint_none_for_non_cert_file(client, rt):
    """If the CA file is not a valid certificate, no fingerprint is shown."""
    public = rt.settings.data_path / "ca-cert.pem"
    public.write_text("this is not a valid pem certificate", encoding="ascii")
    resp = await client.get("/mobile-setup")
    assert resp.status_code == 200
    # Page should not crash; fingerprint block may be absent or empty
    text = resp.text
    # No colon-separated hex fingerprint should appear
    import re
    fp_pattern = re.compile(r"[0-9A-F]{2}(?::[0-9A-F]{2}){15,}", re.IGNORECASE)
    assert not fp_pattern.search(text), "No fingerprint should appear for an invalid cert file"


# ---------------------------------------------------------------------------
# Login page links to mobile-setup
# ---------------------------------------------------------------------------

async def test_login_page_links_to_mobile_setup(client):
    await client.post("/setup", data={"password": "hunter2secure", "confirm": "hunter2secure"})
    client.cookies.delete(COOKIE)
    resp = await client.get("/login")
    assert resp.status_code == 200
    assert "mobile-setup" in resp.text


# ---------------------------------------------------------------------------
# /api/startup/*
# ---------------------------------------------------------------------------

async def test_startup_status_requires_auth(client):
    resp = await client.get("/api/startup/status")
    assert resp.status_code == 401


async def test_startup_enable_requires_auth(client):
    resp = await client.post("/api/startup/enable", json={})
    assert resp.status_code == 401


async def test_startup_disable_requires_auth(client):
    resp = await client.post("/api/startup/disable", json={})
    assert resp.status_code == 401


async def test_startup_status_returns_supported_flag(client, rt, monkeypatch):
    headers = await login(client)
    import deployment.windows.startup_helper as sh
    monkeypatch.setattr(sh, "_get_status", lambda: {"enabled": False, "supported": False, "error": "not Windows"})
    resp = await client.get("/api/startup/status", headers=headers)
    assert resp.status_code == 200
    data = resp.json()
    assert "supported" in data
    assert "enabled" in data


async def test_startup_enable_loopback_guard_present_in_source():
    """The loopback restriction for startup enable must exist in the source."""
    import apps.dashboard.app as app_mod
    source = open(app_mod.__file__).read()
    assert "is_loopback" in source, "loopback guard must exist in api_startup_enable"


async def test_startup_enable_on_non_windows_fails_gracefully(client, rt, monkeypatch):
    headers = await login(client)
    import deployment.windows.startup_helper as sh

    monkeypatch.setattr(sh, "enable", lambda: 1)  # simulate failure
    resp = await client.post("/api/startup/enable", json={}, headers=headers)
    assert resp.status_code == 500


async def test_startup_enable_rejected_from_lan(lan_client, rt, monkeypatch):
    """LAN clients must be rejected from startup enable even when authenticated."""
    # Set up via loopback first, then attempt enable from LAN client
    # We can't share session cookies between transports easily, so test the
    # loopback guard by patching enable to return success and checking 403
    import deployment.windows.startup_helper as sh
    monkeypatch.setattr(sh, "enable", lambda: 0)

    # Create a separate loopback client to do setup, then test LAN client
    import apps.dashboard.app as app_mod
    app = lan_client.app

    # Manually inject a valid session into the LAN client's cookie jar
    # by calling setup through the same app but as loopback
    loopback_transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=loopback_transport, base_url="http://test") as lb:
        lb.cookies = lan_client.cookies  # share cookie jar
        resp = await lb.post("/setup", data={"password": "hunter2secure", "confirm": "hunter2secure"})
        assert resp.status_code == 303
        # Copy cookies back
        for k, v in lb.cookies.items():
            lan_client.cookies.set(k, v)

    token = lan_client.cookies.get(COOKIE)
    csrf = app.state.sessions.csrf_for(token)
    headers = {"x-csrf": csrf}

    resp = await lan_client.post("/api/startup/enable", json={}, headers=headers)
    assert resp.status_code == 403
