"""Safe review, publish, sync, and rollback orchestration.

Only bounded UTF-8 source files are accepted.  Every write is tied to an
expiring review ticket and to the exact repository, branch, remote head, and
local file fingerprints the owner reviewed.
"""

from __future__ import annotations

import asyncio
import base64
import difflib
import hashlib
import json
import os
import re
import secrets
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Awaitable, Callable

from chat_core.logging_setup import contains_supplied_secret, sanitize
from chat_core.security.sensitive_source import (
    contains_sensitive_source,
    is_sensitive_source_path,
)
from integrations.github_publish.client import GitHubBrokerClient, GitHubBrokerError

MAX_FILES = 12
MAX_FILE_BYTES = 128 * 1024
MAX_TOTAL_BYTES = 512 * 1024
MAX_DIFF_BYTES = 512 * 1024
REVIEW_TTL_SECONDS = 10 * 60

_REPOSITORY_RE = re.compile(
    r"^[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98})/"
    r"[A-Za-z0-9](?:[A-Za-z0-9_.-]{0,98})$"
)
_BRANCH_RE = re.compile(
    r"^(?!/)(?!.*//)(?!.*\.\.)(?!.*@\{)(?!.*[~^:?*\[\]\\])"
    r"[A-Za-z0-9._/-]{1,160}(?<![/.])$"
)
_CHECKPOINT_RE = re.compile(r"^[0-9]{8}T[0-9]{6}Z-[a-f0-9]{12}$")
_SOURCE_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".css", ".csv", ".go", ".h", ".hpp", ".html",
    ".java", ".js", ".json", ".jsx", ".kt", ".less", ".md", ".mjs", ".php",
    ".pl", ".properties", ".proto", ".py", ".rb", ".rs", ".scss", ".sh",
    ".sql", ".svelte", ".swift", ".toml", ".ts", ".tsx", ".txt", ".vue",
    ".xml", ".yaml", ".yml",
}
_SOURCE_FILENAMES = {
    ".editorconfig", ".env.example", ".gitignore",
    "dockerfile", "gemfile", "makefile", "procfile",
}
_PROTECTED_PARTS = {
    ".git", ".github", ".venv", "venv", "__pycache__", ".pytest_cache", "node_modules",
    "releases",
}


class GitHubPublishError(RuntimeError):
    """A safe, user-displayable publishing or sync refusal."""

    def __init__(self, message: str, *, status: int = 400) -> None:
        super().__init__(sanitize(str(message or "GitHub operation refused.")))
        self.status = status


@dataclass(frozen=True)
class GitHubPublishConfig:
    repository: str
    branch: str
    remote_prefix: str = ""

    def public(self) -> dict:
        return {
            "repository": self.repository,
            "branch": self.branch,
            "remote_prefix": self.remote_prefix,
        }


@dataclass
class _Review:
    review_id: str
    owner: str
    direction: str
    config: GitHubPublishConfig
    head: str
    created_at: float
    changes: list[dict]


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _decode_remote(value: str, *, path: str) -> bytes:
    try:
        data = base64.b64decode(value, validate=True)
    except (ValueError, TypeError) as exc:
        raise GitHubPublishError(
            f"GitHub returned unreadable content for {path}.", status=502
        ) from exc
    if len(data) > MAX_FILE_BYTES:
        raise GitHubPublishError(f"{path} is larger than 128 KiB.", status=413)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise GitHubPublishError(f"{path} is not UTF-8 text.") from exc
    if "\0" in text:
        raise GitHubPublishError(f"{path} is not a text source file.")
    return data


def _assert_no_secret(path: str, data: bytes) -> None:
    text = data.decode("utf-8")
    if contains_sensitive_source(text, path=path):
        raise GitHubPublishError(
            f"{path} appears to contain a credential or private key. "
            "It was not included in the review."
        )


def _unified_diff(path: str, before: bytes, after: bytes) -> tuple[str, int, int]:
    before_text = before.decode("utf-8")
    after_text = after.decode("utf-8")
    lines = list(
        difflib.unified_diff(
            before_text.splitlines(keepends=True),
            after_text.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            n=3,
        )
    )
    diff = sanitize("".join(lines))
    additions = sum(
        1 for line in lines if line.startswith("+") and not line.startswith("+++")
    )
    deletions = sum(
        1 for line in lines if line.startswith("-") and not line.startswith("---")
    )
    return diff, additions, deletions


class GitHubPublishService:
    def __init__(
        self,
        app_root: Path,
        data_path: Path,
        client_factory: Callable[[], Awaitable[GitHubBrokerClient]],
        *,
        protected_repositories: Callable[[], set[str]] | None = None,
    ) -> None:
        self.app_root = Path(app_root).resolve()
        self.checkpoints_dir = Path(data_path) / "github-sync-checkpoints"
        self._client_factory = client_factory
        self._protected_repositories = protected_repositories or (lambda: set())
        self._reviews: dict[str, _Review] = {}
        self._review_lock = asyncio.Lock()

    def validate_config(
        self, repository: str, branch: str, remote_prefix: str = ""
    ) -> GitHubPublishConfig:
        repository = str(repository or "").strip()
        branch = str(branch or "").strip()
        prefix = str(remote_prefix or "").strip().strip("/")
        if contains_supplied_secret(
            f"repository={repository}\nbranch={branch}\nprefix={prefix}"
        ):
            raise GitHubPublishError(
                "Repository settings appear to contain a credential."
            )
        if not _REPOSITORY_RE.fullmatch(repository):
            raise GitHubPublishError(
                "Repository must look like owner/name using GitHub-safe characters."
            )
        if not _BRANCH_RE.fullmatch(branch):
            raise GitHubPublishError("Branch name is invalid.")
        if repository.casefold() in {
            value.casefold() for value in self._protected_repositories()
        }:
            raise GitHubPublishError(
                "The dashboard cannot target the configured updates repository. "
                "Release publishing uses separate permission."
            )
        if prefix:
            lower = prefix.casefold()
            if lower == "releases" or lower.startswith("releases/"):
                raise GitHubPublishError(
                    "The releases folder is reserved for the separate release publisher."
                )
            self._validate_repo_path(prefix, allow_prefix=True)
        return GitHubPublishConfig(repository, branch, prefix)

    @staticmethod
    def config_from_json(raw: str | None) -> GitHubPublishConfig | None:
        if not raw:
            return None
        try:
            data = json.loads(raw)
        except (TypeError, json.JSONDecodeError):
            return None
        if not isinstance(data, dict):
            return None
        repository = data.get("repository")
        branch = data.get("branch")
        prefix = data.get("remote_prefix", "")
        if not all(isinstance(value, str) for value in (repository, branch, prefix)):
            return None
        return GitHubPublishConfig(repository, branch, prefix)

    async def broker_status(self) -> dict:
        client = await self._client_factory()
        return await client.status()

    async def verify_config(self, config: GitHubPublishConfig) -> str:
        client = await self._client_factory()
        snapshot = await client.snapshot(config.repository, config.branch, [])
        return self._head(snapshot)

    async def review(
        self,
        *,
        owner: str,
        direction: str,
        config: GitHubPublishConfig,
        paths: list[str],
    ) -> dict:
        config = self.validate_config(
            config.repository, config.branch, config.remote_prefix
        )
        if direction not in {"publish", "sync"}:
            raise GitHubPublishError("Direction must be publish or sync.")
        local_paths = self._validate_paths(paths)
        remote_paths = [self._remote_path(config, path) for path in local_paths]
        client = await self._client_factory()
        try:
            snapshot = await client.snapshot(
                config.repository, config.branch, remote_paths
            )
        except GitHubBrokerError as exc:
            raise GitHubPublishError(str(exc), status=exc.status) from exc
        head = self._head(snapshot)
        remote_files = snapshot.get("files")
        if not isinstance(remote_files, list) or len(remote_files) != len(local_paths):
            raise GitHubPublishError(
                "GitHub returned an incomplete file snapshot.", status=502
            )

        changes: list[dict] = []
        total = 0
        total_diff = 0
        for local_path, remote_path, remote in zip(
            local_paths, remote_paths, remote_files, strict=True
        ):
            if not isinstance(remote, dict) or remote.get("path") != remote_path:
                raise GitHubPublishError(
                    "GitHub returned an unexpected file snapshot.", status=502
                )
            remote_exists = remote.get("exists") is True
            remote_data = (
                _decode_remote(str(remote.get("content", "")), path=local_path)
                if remote_exists
                else b""
            )
            local_data = self._read_local(
                local_path, required=(direction == "publish")
            )
            if direction == "sync" and not remote_exists:
                raise GitHubPublishError(
                    f"{local_path} does not exist on GitHub. "
                    "Sync never deletes local files."
                )
            if local_data is not None:
                _assert_no_secret(local_path, local_data)
                total += len(local_data)
            if remote_exists:
                _assert_no_secret(local_path, remote_data)
                total += len(remote_data)
            if total > MAX_TOTAL_BYTES * 2:
                raise GitHubPublishError(
                    "The requested review is too large.", status=413
                )
            local_bytes = local_data or b""
            before, after = (
                (remote_data, local_bytes)
                if direction == "publish"
                else (local_bytes, remote_data)
            )
            if before == after:
                continue
            diff, additions, deletions = _unified_diff(local_path, before, after)
            total_diff += len(diff.encode("utf-8"))
            if total_diff > MAX_DIFF_BYTES:
                raise GitHubPublishError(
                    "The combined diff is too large to review safely.", status=413
                )
            changes.append(
                {
                    "path": local_path,
                    "remote_path": remote_path,
                    "status": (
                        "added"
                        if (direction == "publish" and not remote_exists)
                        or (direction == "sync" and local_data is None)
                        else "modified"
                    ),
                    "diff": diff,
                    "additions": additions,
                    "deletions": deletions,
                    "local_sha": _sha256(local_bytes) if local_data is not None else None,
                    "desired": base64.b64encode(after).decode("ascii"),
                    "remote_sha": str(remote.get("blobSha") or ""),
                }
            )

        review_id = secrets.token_urlsafe(18)
        review = _Review(
            review_id=review_id,
            owner=owner,
            direction=direction,
            config=config,
            head=head,
            created_at=asyncio.get_running_loop().time(),
            changes=changes,
        )
        async with self._review_lock:
            self._purge_reviews()
            self._reviews[review_id] = review
        return {
            "review_id": review_id,
            "direction": direction,
            "repository": config.repository,
            "branch": config.branch,
            "head": head,
            "changes": [
                {
                    key: change[key]
                    for key in (
                        "path", "status", "diff", "additions", "deletions"
                    )
                }
                for change in changes
            ],
            "expires_in_seconds": REVIEW_TTL_SECONDS,
        }

    async def publish(
        self,
        *,
        owner: str,
        review_id: str,
        message: str,
        confirm_repository: str,
        confirm_branch: str,
    ) -> dict:
        review = await self._consume_review(
            owner, review_id, "publish", confirm_repository, confirm_branch
        )
        if not review.changes:
            raise GitHubPublishError("There are no reviewed changes to publish.")
        message = " ".join(str(message or "").split())
        if not message or len(message) > 120:
            raise GitHubPublishError("Commit message must be 1-120 characters.")
        if contains_supplied_secret(message):
            raise GitHubPublishError("Commit message appears to contain a credential.")
        files = []
        for change in review.changes:
            current = self._read_local(change["path"], required=True)
            assert current is not None
            if _sha256(current) != change["local_sha"]:
                raise GitHubPublishError(
                    f"{change['path']} changed after review. Review it again.",
                    status=409,
                )
            files.append(
                {"path": change["remote_path"], "content": change["desired"]}
            )
        client = await self._client_factory()
        try:
            result = await client.commit(
                review.config.repository,
                review.config.branch,
                review.head,
                message,
                files,
            )
        except GitHubBrokerError as exc:
            raise GitHubPublishError(str(exc), status=exc.status) from exc
        commit = result.get("commit")
        if not isinstance(commit, str) or not re.fullmatch(r"[0-9a-f]{40}", commit):
            raise GitHubPublishError(
                "GitHub did not confirm the new commit.", status=502
            )
        return {
            "ok": True,
            "commit": commit,
            "repository": review.config.repository,
            "branch": review.config.branch,
        }

    async def sync(
        self,
        *,
        owner: str,
        review_id: str,
        confirm_repository: str,
        confirm_branch: str,
    ) -> dict:
        review = await self._consume_review(
            owner, review_id, "sync", confirm_repository, confirm_branch
        )
        if not review.changes:
            raise GitHubPublishError("There are no reviewed changes to sync.")
        remote_paths = [change["remote_path"] for change in review.changes]
        client = await self._client_factory()
        try:
            fresh = await client.snapshot(
                review.config.repository, review.config.branch, remote_paths
            )
        except GitHubBrokerError as exc:
            raise GitHubPublishError(str(exc), status=exc.status) from exc
        if self._head(fresh) != review.head:
            raise GitHubPublishError(
                "The repository changed after review. Sync was refused.",
                status=409,
            )
        fresh_files = fresh.get("files")
        if not isinstance(fresh_files, list) or len(fresh_files) != len(review.changes):
            raise GitHubPublishError(
                "GitHub returned an incomplete file snapshot.", status=502
            )

        desired: dict[str, bytes] = {}
        for change, remote in zip(review.changes, fresh_files, strict=True):
            current = self._read_local(change["path"], required=False)
            current_sha = _sha256(current) if current is not None else None
            if current_sha != change["local_sha"]:
                raise GitHubPublishError(
                    f"{change['path']} changed after review. Sync was refused.",
                    status=409,
                )
            if not isinstance(remote, dict) or remote.get("exists") is not True:
                raise GitHubPublishError(
                    f"{change['path']} disappeared from GitHub. Sync was refused.",
                    status=409,
                )
            data = _decode_remote(
                str(remote.get("content", "")), path=change["path"]
            )
            _assert_no_secret(change["path"], data)
            if base64.b64encode(data).decode("ascii") != change["desired"]:
                raise GitHubPublishError(
                    f"{change['path']} changed on GitHub after review.",
                    status=409,
                )
            desired[change["path"]] = data

        checkpoint_id = self._create_checkpoint(desired)
        try:
            self._apply_transaction(desired)
        except OSError as exc:
            self._mark_checkpoint(checkpoint_id, "aborted_at")
            raise GitHubPublishError(
                f"Sync failed locally ({type(exc).__name__}); "
                "all earlier file changes were reversed.",
                status=500,
            ) from exc
        return {
            "ok": True,
            "checkpoint_id": checkpoint_id,
            "files": list(desired),
        }

    def restore(self, checkpoint_id: str) -> dict:
        files = self._restore_checkpoint(str(checkpoint_id or ""))
        return {"ok": True, "files": files}

    def latest_checkpoint(self) -> str | None:
        if not self.checkpoints_dir.exists():
            return None
        for directory in sorted(self.checkpoints_dir.iterdir(), reverse=True):
            if not directory.is_dir() or not _CHECKPOINT_RE.fullmatch(directory.name):
                continue
            try:
                manifest = json.loads((directory / "manifest.json").read_text())
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(manifest, dict) and not manifest.get("restored_at"):
                if manifest.get("aborted_at"):
                    continue
                return directory.name
        return None

    async def _consume_review(
        self,
        owner: str,
        review_id: str,
        direction: str,
        confirm_repository: str,
        confirm_branch: str,
    ) -> _Review:
        async with self._review_lock:
            self._purge_reviews()
            review = self._reviews.get(str(review_id or ""))
        if review is None or review.owner != owner:
            raise GitHubPublishError(
                "That review expired or was already used. Review again.",
                status=409,
            )
        if review.direction != direction:
            raise GitHubPublishError("Review direction does not match this action.")
        if (
            confirm_repository != review.config.repository
            or confirm_branch != review.config.branch
        ):
            raise GitHubPublishError(
                "Repository or branch confirmation does not match the review.",
                status=409,
            )
        async with self._review_lock:
            current = self._reviews.get(review.review_id)
            if current is not review:
                raise GitHubPublishError(
                    "That review was already used. Review again.",
                    status=409,
                )
            self._reviews.pop(review.review_id, None)
        return review

    def _purge_reviews(self) -> None:
        now = asyncio.get_running_loop().time()
        expired = [
            review_id
            for review_id, review in self._reviews.items()
            if now - review.created_at > REVIEW_TTL_SECONDS
        ]
        for review_id in expired:
            self._reviews.pop(review_id, None)

    @staticmethod
    def _head(snapshot: dict) -> str:
        head = snapshot.get("head")
        if not isinstance(head, str) or not re.fullmatch(r"[0-9a-f]{40}", head):
            raise GitHubPublishError(
                "GitHub returned an invalid branch head.", status=502
            )
        return head

    def _validate_paths(self, paths: list[str]) -> list[str]:
        if not isinstance(paths, list) or not 1 <= len(paths) <= MAX_FILES:
            raise GitHubPublishError("Choose between 1 and 12 source files.")
        clean: list[str] = []
        seen: set[str] = set()
        for raw in paths:
            if not isinstance(raw, str):
                raise GitHubPublishError("Every path must be text.")
            path = raw.strip()
            self._validate_repo_path(path)
            if path in seen:
                raise GitHubPublishError("File paths must be unique.")
            seen.add(path)
            clean.append(path)
        return clean

    def _validate_repo_path(self, path: str, *, allow_prefix: bool = False) -> None:
        if contains_supplied_secret(f"path={path}"):
            raise GitHubPublishError("Source path appears to contain a credential.")
        if (
            not path
            or len(path) > 220
            or path.startswith("/")
            or path.endswith("/")
            or "\\" in path
            or "\0" in path
        ):
            raise GitHubPublishError("Invalid source path.")
        pure = PurePosixPath(path)
        if any(part in {"", ".", ".."} for part in pure.parts):
            raise GitHubPublishError("Invalid source path.")
        if is_sensitive_source_path(path):
            raise GitHubPublishError(
                "Credential and private-key paths cannot be published or synced."
            )
        lower_parts = tuple(part.casefold() for part in pure.parts)
        if any(part in _PROTECTED_PARTS for part in lower_parts):
            raise GitHubPublishError("That path is not eligible for source sync.")
        lower = path.casefold()
        if (
            lower == "latest.json"
            or lower.startswith("deployment/release/")
            or "signing_key" in lower
            or lower.endswith((".pem", ".key", ".p12", ".pfx"))
        ):
            raise GitHubPublishError("That path is protected from source sync.")
        if allow_prefix:
            return
        name = pure.name.casefold()
        suffix = PurePosixPath(name).suffix
        if suffix not in _SOURCE_EXTENSIONS and name not in _SOURCE_FILENAMES:
            raise GitHubPublishError("Only text source files can be reviewed.")

    def _remote_path(self, config: GitHubPublishConfig, local_path: str) -> str:
        return (
            f"{config.remote_prefix}/{local_path}"
            if config.remote_prefix
            else local_path
        )

    def _local_target(self, path: str) -> Path:
        self._validate_repo_path(path)
        target = self.app_root.joinpath(*PurePosixPath(path).parts)
        current = self.app_root
        for part in PurePosixPath(path).parts:
            current /= part
            if current.is_symlink():
                raise GitHubPublishError(f"{path} passes through a symbolic link.")
        try:
            target.resolve(strict=False).relative_to(self.app_root)
        except ValueError as exc:
            raise GitHubPublishError("Source path escapes the Chat folder.") from exc
        return target

    def _read_local(self, path: str, *, required: bool) -> bytes | None:
        target = self._local_target(path)
        if not target.exists():
            if required:
                raise GitHubPublishError(f"{path} does not exist locally.")
            return None
        if not target.is_file() or target.is_symlink():
            raise GitHubPublishError(f"{path} is not a regular source file.")
        try:
            data = target.read_bytes()
        except OSError as exc:
            raise GitHubPublishError(
                f"{path} could not be read ({type(exc).__name__})."
            ) from exc
        if len(data) > MAX_FILE_BYTES:
            raise GitHubPublishError(f"{path} is larger than 128 KiB.", status=413)
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise GitHubPublishError(f"{path} is not UTF-8 text.") from exc
        if "\0" in text:
            raise GitHubPublishError(f"{path} is not a text source file.")
        return data

    def _create_checkpoint(self, desired: dict[str, bytes]) -> str:
        now = datetime.now(UTC)
        checkpoint_id = now.strftime("%Y%m%dT%H%M%SZ-") + secrets.token_hex(6)
        directory = self.checkpoints_dir / checkpoint_id
        files_dir = directory / "files"
        files_dir.mkdir(parents=True, exist_ok=False)
        entries = []
        try:
            for index, (path, after) in enumerate(desired.items()):
                before = self._read_local(path, required=False)
                backup_name = f"{index:02d}.bin" if before is not None else None
                if backup_name:
                    (files_dir / backup_name).write_bytes(before)
                entries.append(
                    {
                        "path": path,
                        "existed": before is not None,
                        "before_sha": _sha256(before) if before is not None else None,
                        "after_sha": _sha256(after),
                        "backup": backup_name,
                    }
                )
            manifest = {
                "id": checkpoint_id,
                "created_at": now.isoformat(),
                "entries": entries,
            }
            self._write_json_atomic(directory / "manifest.json", manifest)
        except BaseException:
            import shutil
            shutil.rmtree(directory, ignore_errors=True)
            raise
        return checkpoint_id

    def _restore_checkpoint(self, checkpoint_id: str) -> list[str]:
        if not _CHECKPOINT_RE.fullmatch(checkpoint_id):
            raise GitHubPublishError("Invalid checkpoint.")
        directory = self.checkpoints_dir / checkpoint_id
        manifest_path = directory / "manifest.json"
        try:
            manifest = json.loads(manifest_path.read_text())
        except (OSError, json.JSONDecodeError) as exc:
            raise GitHubPublishError("Checkpoint could not be read.", status=404) from exc
        if (
            not isinstance(manifest, dict)
            or manifest.get("id") != checkpoint_id
            or not isinstance(manifest.get("entries"), list)
        ):
            raise GitHubPublishError("Checkpoint is invalid.", status=500)
        if manifest.get("restored_at"):
            raise GitHubPublishError("Checkpoint was already restored.", status=409)

        entries = manifest["entries"]
        replacements: dict[str, bytes | None] = {}
        for entry in entries:
            self._validate_checkpoint_entry(entry)
            path = entry["path"]
            current = self._read_local(path, required=False)
            if current is None or _sha256(current) != entry["after_sha"]:
                raise GitHubPublishError(
                    f"{path} changed after sync. "
                    "Restore was refused to protect newer local work.",
                    status=409,
                )
            if entry["existed"]:
                backup = directory / "files" / entry["backup"]
                try:
                    data = backup.read_bytes()
                except OSError as exc:
                    raise GitHubPublishError(
                        "Checkpoint backup is incomplete.", status=500
                    ) from exc
                if _sha256(data) != entry["before_sha"]:
                    raise GitHubPublishError(
                        "Checkpoint backup fingerprint does not match.", status=500
                    )
                replacements[path] = data
            else:
                replacements[path] = None
        try:
            self._apply_transaction(replacements)
        except OSError as exc:
            raise GitHubPublishError(
                f"Checkpoint restore failed ({type(exc).__name__}); "
                "all earlier restore changes were reversed.",
                status=500,
            ) from exc
        manifest["restored_at"] = datetime.now(UTC).isoformat()
        self._write_json_atomic(manifest_path, manifest)
        return list(replacements)

    def _validate_checkpoint_entry(self, entry: object) -> None:
        if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
            raise GitHubPublishError("Checkpoint is invalid.", status=500)
        self._validate_repo_path(entry["path"])
        if not isinstance(entry.get("after_sha"), str) or not re.fullmatch(
            r"[0-9a-f]{64}", entry["after_sha"]
        ):
            raise GitHubPublishError("Checkpoint is invalid.", status=500)
        if entry.get("existed") is True:
            if (
                not isinstance(entry.get("backup"), str)
                or not re.fullmatch(r"[0-9]{2}\.bin", entry["backup"])
                or not isinstance(entry.get("before_sha"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", entry["before_sha"])
            ):
                raise GitHubPublishError("Checkpoint is invalid.", status=500)
        elif entry.get("existed") is not False:
            raise GitHubPublishError("Checkpoint is invalid.", status=500)

    def _atomic_write(self, path: str, data: bytes) -> None:
        target = self._local_target(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        mode = target.stat().st_mode & 0o777 if target.exists() else 0o644
        temporary = target.with_name(
            f".{target.name}.github-sync-{secrets.token_hex(6)}.tmp"
        )
        try:
            temporary.write_bytes(data)
            try:
                temporary.chmod(mode)
            except OSError:
                pass
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)

    def _mark_checkpoint(self, checkpoint_id: str, field: str) -> None:
        manifest_path = self.checkpoints_dir / checkpoint_id / "manifest.json"
        try:
            manifest = json.loads(manifest_path.read_text())
            if not isinstance(manifest, dict) or manifest.get("id") != checkpoint_id:
                raise ValueError("invalid checkpoint")
            manifest[field] = datetime.now(UTC).isoformat()
            self._write_json_atomic(manifest_path, manifest)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise GitHubPublishError(
                "Local changes were reversed, but the checkpoint state "
                "could not be finalized.",
                status=500,
            ) from exc

    def _apply_transaction(self, replacements: dict[str, bytes | None]) -> None:
        """Stage all writes and compensate every earlier mutation on failure."""
        originals: dict[str, bytes | None] = {}
        staged: dict[str, Path] = {}
        applied: list[str] = []
        try:
            for path, replacement in replacements.items():
                originals[path] = self._read_local(path, required=False)
                if replacement is None:
                    continue
                target = self._local_target(path)
                target.parent.mkdir(parents=True, exist_ok=True)
                mode = target.stat().st_mode & 0o777 if target.exists() else 0o644
                temporary = target.with_name(
                    f".{target.name}.github-stage-{secrets.token_hex(6)}.tmp"
                )
                temporary.write_bytes(replacement)
                try:
                    temporary.chmod(mode)
                except OSError:
                    pass
                staged[path] = temporary
            for path, replacement in replacements.items():
                target = self._local_target(path)
                if replacement is None:
                    target.unlink(missing_ok=True)
                else:
                    os.replace(staged[path], target)
                applied.append(path)
        except OSError as exc:
            compensation_errors: list[OSError] = []
            for path in reversed(applied):
                try:
                    original = originals[path]
                    if original is None:
                        self._local_target(path).unlink(missing_ok=True)
                    else:
                        self._atomic_write(path, original)
                except OSError as recovery_exc:
                    compensation_errors.append(recovery_exc)
            if compensation_errors:
                raise GitHubPublishError(
                    "Local file transaction and automatic compensation both failed. "
                    "Use the saved checkpoint for manual recovery.",
                    status=500,
                ) from exc
            raise
        finally:
            for temporary in staged.values():
                temporary.unlink(missing_ok=True)

    @staticmethod
    def _write_json_atomic(path: Path, data: dict) -> None:
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")
        os.replace(temporary, path)