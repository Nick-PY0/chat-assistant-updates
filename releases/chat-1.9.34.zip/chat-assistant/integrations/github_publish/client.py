"""Thin async client for the credential-isolated GitHub broker.

The broker owns the Replit GitHub OAuth connection.  This client knows only the
existing encrypted Relay password, so neither a GitHub token nor refresh logic
ever enters the desktop app or dashboard.
"""

from __future__ import annotations

from typing import Any

import httpx

from chat_core.logging_setup import sanitize


class GitHubBrokerError(RuntimeError):
    """A safe, user-displayable broker failure."""

    def __init__(self, message: str, *, status: int = 502) -> None:
        super().__init__(sanitize(str(message or "GitHub request failed.")))
        self.status = status


class GitHubBrokerClient:
    """Call the narrow GitHub source endpoints on the owner's Relay."""

    def __init__(
        self,
        base_url: str,
        secret: str,
        *,
        timeout: float = 45.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        base = str(base_url or "").strip().rstrip("/")
        if base and not base.startswith(("http://", "https://")):
            base = "https://" + base
        if base.startswith("http://"):
            raise GitHubBrokerError(
                "The Relay address must use https:// so its password stays private.",
                status=400,
            )
        if base and not base.endswith("/api"):
            base += "/api"
        self.base = base
        self._secret = str(secret or "")
        self._timeout = timeout
        self._transport = transport

    async def _request(
        self, method: str, path: str, payload: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        if not self.base:
            raise GitHubBrokerError(
                "No Relay address is set. Configure it under Providers first.",
                status=503,
            )
        try:
            async with httpx.AsyncClient(
                timeout=self._timeout, transport=self._transport
            ) as client:
                response = await client.request(
                    method,
                    self.base + path,
                    json=payload,
                    headers={"x-chat-relay-key": self._secret},
                )
        except httpx.HTTPError as exc:
            raise GitHubBrokerError(
                f"The GitHub broker could not be reached ({type(exc).__name__}).",
                status=503,
            ) from exc

        try:
            data = response.json()
        except ValueError:
            data = {}
        if not isinstance(data, dict):
            data = {}
        if response.status_code >= 400:
            message = str(
                data.get("error")
                or f"The GitHub broker returned HTTP {response.status_code}."
            )
            raise GitHubBrokerError(message, status=response.status_code)
        return data

    async def status(self) -> dict[str, Any]:
        return await self._request("GET", "/github/status")

    async def snapshot(
        self, repository: str, branch: str, paths: list[str]
    ) -> dict[str, Any]:
        owner, name = repository.split("/", 1)
        return await self._request(
            "POST",
            "/github/snapshot",
            {
                "repository": {"owner": owner, "name": name},
                "branch": branch,
                "paths": paths,
            },
        )

    async def commit(
        self,
        repository: str,
        branch: str,
        expected_head: str,
        message: str,
        files: list[dict[str, str]],
    ) -> dict[str, Any]:
        owner, name = repository.split("/", 1)
        return await self._request(
            "POST",
            "/github/commit",
            {
                "repository": {"owner": owner, "name": name},
                "branch": branch,
                "expectedHead": expected_head,
                "message": message,
                "files": files,
            },
        )