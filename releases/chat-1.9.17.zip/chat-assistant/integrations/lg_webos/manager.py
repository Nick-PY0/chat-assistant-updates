"""Lifecycle manager for the optional LG webOS TV integration.

One TV (single row 'default' in lg_webos_devices), local network only.

Responsibilities:
  * configuration (enable toggle, host, optional MAC for Wake-on-LAN)
  * pairing: on-screen PROMPT approval; the returned client key is encrypted
    with the vault (context ``lg_webos:pairing``) before it touches disk and
    is never logged, never returned by any API, and never shown in the UI
  * a reconnect loop with backoff while the feature is enabled and paired
  * safe state caching (volume/mute/app/inputs/apps) with generation fencing
    so events from a dead connection can never clobber a live one
  * the narrow command surface used by tools, voice grammar, and dashboard

The MAC address is write-only: accepted from the user, stored, used for WoL,
and exposed only as the boolean ``wol_ready``.
"""

from __future__ import annotations

import asyncio
import contextlib
import difflib
import json
import logging
import time
from typing import Any, Callable

from chat_core.events import EventBus
from chat_core.models.db import Database
from chat_core.security.vault import Vault
from .client import (
    SSAPClient,
    SSAPError,
    SSAPNotSupported,
    SSAPPairingRejected,
)
from .protocol import (
    BUTTONS,
    MEDIA_ACTIONS,
    URI_FOREGROUND_APP,
    URI_GET_VOLUME,
    URI_INPUT_LIST,
    URI_INSERT_TEXT,
    URI_LAUNCH_APP,
    URI_LIST_APPS,
    URI_POWER_STATE,
    URI_REGISTER_REMOTE_KEYBOARD,
    URI_SEND_ENTER,
    URI_SET_MUTE,
    URI_SET_VOLUME,
    URI_SWITCH_INPUT,
    URI_SYSTEM_INFO,
    URI_TURN_OFF,
    clamp_volume,
    normalize_mac,
    valid_app_id,
    valid_host,
)
from .wol import WoLError, send_wol
from . import discovery as ssdp

log = logging.getLogger("lg_webos")

DEVICE_ID = "default"
KEY_SETTING = "lg_webos_client_key"
KEY_CONTEXT = "lg_webos:pairing"
RECONNECT_DELAYS = (2.0, 5.0, 10.0, 20.0, 40.0, 60.0)
STATE_WRITE_MIN_INTERVAL = 5.0  # seconds between last_state_json writes
TEXT_MAX_CHARS = 120  # hard cap for one type_text call (search boxes are short)


class WebOSTVError(Exception):
    """TV integration error with a message safe to show the user."""


def _now_iso() -> str:
    from chat_core.models.credentials import iso, utcnow

    return iso(utcnow())


class WebOSManager:
    def __init__(
        self,
        db: Database,
        bus: EventBus,
        vault: Vault,
        settings=None,
        connect_factory: Callable | None = None,
        wol_sender: Callable | None = None,
        discover_fn: Callable | None = None,
        reconnect_delays: tuple[float, ...] = RECONNECT_DELAYS,
    ) -> None:
        self.db = db
        self.bus = bus
        self.vault = vault
        self.settings = settings
        self._connect_factory = connect_factory
        self._wol_sender = wol_sender or send_wol
        self._discover_fn = discover_fn or ssdp.discover
        self._reconnect_delays = reconnect_delays

        # config (mirrors the DB row; _mac is private and never surfaced)
        self.enabled = False
        self.paired = False
        self.host = ""
        self.name = "LG TV"
        self._mac = ""

        # live state
        self._client: SSAPClient | None = None
        self._connected = False
        self._generation = 0  # bumped on every stop/start/pair/unpair
        self._loop_task: asyncio.Task | None = None
        self._pair_task: asyncio.Task | None = None
        self._stopping = False
        self._prefer_tls: bool | None = None

        self._state: dict[str, Any] = {}  # volume, muted, power, foreground, model
        self._apps: list[dict] = []
        self._apps_fresh = False
        self._inputs: list[dict] = []
        self._caps: dict[str, bool] = {}
        self._last_error = ""
        self._last_seen_at: str | None = None
        self._pairing_status = "idle"  # idle|connecting|prompt|paired|failed
        self._pairing_error = ""
        self._last_state_write = 0.0
        self._keyboard_client: SSAPClient | None = None

    # -- lifecycle ---------------------------------------------------------
    async def start(self) -> None:
        row = await self.db.fetchone("SELECT * FROM lg_webos_devices WHERE id=?", (DEVICE_ID,))
        if row is not None:
            self.name = row["name"] or "LG TV"
            self.host = row["host"] or ""
            self._mac = row["mac_address"] or ""
            self.enabled = bool(row["enabled"])
            self.paired = bool(row["paired"])
            self._last_seen_at = row["last_seen_at"]
            try:
                cached = json.loads(row["last_state_json"] or "{}")
            except ValueError:
                cached = {}
            self._state = dict(cached.get("state") or {})
            self._apps = list(cached.get("apps") or [])
            self._apps_fresh = False  # persisted app lists are always stale
        if self.enabled and self.paired and self.host:
            self._spawn_loop()

    async def stop(self) -> None:
        self._stopping = True
        self._generation += 1
        for task in (self._pair_task, self._loop_task):
            if task is not None:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        self._pair_task = None
        self._loop_task = None
        await self._close_client()

    async def _close_client(self) -> None:
        client, self._client = self._client, None
        self._connected = False
        self._keyboard_client = None
        if client is not None:
            await client.close()

    # -- configuration -------------------------------------------------------
    async def configure(
        self,
        name: str | None = None,
        host: str | None = None,
        mac: str | None = None,
        enabled: bool | None = None,
    ) -> dict:
        """Apply a partial config change, persist, and (re)start as needed."""
        if name is not None:
            name = " ".join(str(name).split())[:60]
            if name:
                self.name = name
        if host is not None:
            host = str(host).strip()
            if host and not valid_host(host):
                raise WebOSTVError("that TV address doesn't look valid (use an IP like 192.168.1.50)")
            if host != self.host:
                # same pairing key usually survives an IP change (it belongs
                # to the TV, not the address), so keep `paired`.
                self.host = host
                self._prefer_tls = None
        if mac is not None:
            raw = str(mac).strip()
            if raw == "":
                self._mac = ""
            else:
                normalized = normalize_mac(raw)
                if normalized is None:
                    raise WebOSTVError("that MAC address doesn't look valid (expected AA:BB:CC:DD:EE:FF)")
                self._mac = normalized
        if enabled is not None:
            self.enabled = bool(enabled)
        if self.enabled and not self.host:
            self.enabled = False
            await self._persist_row()
            raise WebOSTVError("enter the TV's IP address (or use Discover) before enabling")
        await self._persist_row()

        # apply the new config to the running loop (and abort any pairing
        # attempt against the old config -- its generation is now stale)
        self._generation += 1
        for task in (self._pair_task, self._loop_task):
            if task is not None:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        self._pair_task = None
        self._loop_task = None
        if self._pairing_status in ("connecting", "prompt"):
            self._pairing_status = "idle"
            self._pairing_error = ""
        await self._close_client()
        self._last_error = ""
        if self.enabled and self.paired and self.host:
            self._spawn_loop()
        self._publish()
        return self.snapshot()

    async def discover(self) -> list[dict]:
        """SSDP scan; works before enabling so users can find the TV first."""
        try:
            found = await self._discover_fn()
        except Exception:  # noqa: BLE001 - a scan failure is a result, not a crash
            raise WebOSTVError("network discovery failed; enter the TV's IP address manually") from None
        return [
            {"host": item.get("host", ""), "name": str(item.get("name") or "LG TV")[:60]}
            for item in found
            if valid_host(str(item.get("host", "")))
        ]

    # -- pairing ---------------------------------------------------------------
    async def start_pairing(self) -> dict:
        """Kick off pairing; progress is polled via snapshot()['pairing']."""
        if not self.host:
            raise WebOSTVError("enter the TV's IP address (or use Discover) first")
        if not self.enabled:
            raise WebOSTVError("turn the TV feature on before pairing")
        if self._pairing_status in ("connecting", "prompt"):
            return {"status": self._pairing_status}
        # fence out any existing connection work
        self._generation += 1
        generation = self._generation
        if self._loop_task is not None:
            self._loop_task.cancel()
            await asyncio.gather(self._loop_task, return_exceptions=True)
            self._loop_task = None
        await self._close_client()
        self._pairing_status = "connecting"
        self._pairing_error = ""
        self._publish()
        self._pair_task = asyncio.create_task(self._pair(generation), name="lg-pair")
        return {"status": "connecting"}

    async def _pair(self, generation: int) -> None:
        """Register with the TV.  If a previously stored key turns out to be
        revoked, drop it and retry exactly once with a fresh on-screen
        prompt -- Pair must always be a working recovery action."""
        for use_stored in (True, False):
            client = self._make_client()
            stored: str | None = None
            try:
                await client.connect(self._prefer_tls)
                self._prefer_tls = client.used_tls

                def on_prompt() -> None:
                    if generation == self._generation:
                        self._pairing_status = "prompt"
                        self._publish()

                stored = await self._load_key() if use_stored else None
                key = await client.register(stored, on_prompt=on_prompt)
                if generation != self._generation:  # unpaired/reconfigured mid-flight
                    await client.close()
                    return
                await self._store_key(key)
                self.paired = True
                self._pairing_status = "paired"
                self._pairing_error = ""
                await self._persist_row()
                await self.db.log("INFO", "lg_tv", "paired with the TV (approved on screen)")
                await client.close()
                if self.enabled and self.host:
                    self._spawn_loop()
                return
            except SSAPPairingRejected as exc:
                await client.close()
                if generation != self._generation:
                    return
                if use_stored and stored is not None:
                    # the TV revoked the saved key: it is worthless now, so
                    # forget it and loop once more for a fresh prompt
                    await self.db.delete_setting(KEY_SETTING)
                    self.paired = False
                    await self._persist_row()
                    await self.db.log(
                        "WARNING", "lg_tv", "stored pairing rejected; asking for a fresh approval"
                    )
                    self._publish()
                    continue
                self._pairing_status = "failed"
                self._pairing_error = str(exc)
                await self.db.log("WARNING", "lg_tv", "pairing declined on the TV")
                return
            except (SSAPError, OSError) as exc:
                await client.close()
                if generation == self._generation:
                    self._pairing_status = "failed"
                    self._pairing_error = str(exc)[:160]
                return
            except asyncio.CancelledError:
                await client.close()
                raise
            finally:
                if generation == self._generation:
                    self._publish()

    async def unpair(self) -> dict:
        """Forget the pairing key and stop the connection (config stays)."""
        self._generation += 1
        for task in (self._pair_task, self._loop_task):
            if task is not None:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        self._pair_task = None
        self._loop_task = None
        await self._close_client()
        await self.db.delete_setting(KEY_SETTING)
        self.paired = False
        self._pairing_status = "idle"
        self._pairing_error = ""
        self._last_error = ""
        await self._persist_row()
        await self.db.log("INFO", "lg_tv", "TV pairing removed")
        self._publish()
        return self.snapshot()

    async def _store_key(self, key: str) -> None:
        blob = self.vault.encrypt(key, KEY_CONTEXT)
        await self.db.set_setting(KEY_SETTING, blob.hex())

    async def _load_key(self) -> str | None:
        stored = await self.db.get_setting(KEY_SETTING)
        if not stored:
            return None
        try:
            return self.vault.decrypt(bytes.fromhex(stored), KEY_CONTEXT)
        except Exception:  # noqa: BLE001 - wrong master secret / corrupt blob
            return None

    # -- connection loop -------------------------------------------------------
    def _make_client(self) -> SSAPClient:
        return SSAPClient(self.host, connect_factory=self._connect_factory)

    def _spawn_loop(self) -> None:
        self._generation += 1
        self._loop_task = asyncio.create_task(self._run(self._generation), name="lg-tv")

    async def _run(self, generation: int) -> None:
        attempt = 0
        while not self._stopping and generation == self._generation:
            client = self._make_client()
            try:
                await client.connect(self._prefer_tls)
                self._prefer_tls = client.used_tls
                key = await self._load_key()
                if not key:
                    raise WebOSTVError("not paired")
                await client.register(key, timeout=15.0)
            except SSAPPairingRejected:
                # the TV forgot us (user removed the app permission): the
                # saved key is worthless, so drop it too -- Pair on the
                # dashboard then starts a clean on-screen approval
                await client.close()
                if generation != self._generation:
                    return
                await self.db.delete_setting(KEY_SETTING)
                self.paired = False
                self._pairing_status = "idle"
                self._pairing_error = ""
                self._last_error = "the TV no longer accepts the saved pairing; re-pair from the dashboard"
                await self._persist_row()
                await self.db.log("WARNING", "lg_tv", "stored pairing rejected by the TV; re-pair needed")
                self._publish()
                return
            except (SSAPError, WebOSTVError, OSError) as exc:
                await client.close()
                if generation != self._generation:
                    return
                self._last_error = str(exc)[:160]
                self._publish()
                delay = self._reconnect_delays[min(attempt, len(self._reconnect_delays) - 1)]
                attempt += 1
                try:
                    await asyncio.sleep(delay)
                except asyncio.CancelledError:
                    await client.close()
                    raise
                continue
            except asyncio.CancelledError:
                await client.close()
                raise

            if generation != self._generation:
                await client.close()
                return
            # connected + registered
            attempt = 0
            self._client = client
            self._connected = True
            self._last_error = ""
            self._last_seen_at = _now_iso()
            await self.db.log("INFO", "lg_tv", "connected to the TV")
            await self._after_connect(client, generation)
            self._publish()
            await self._persist_state(force=True)

            await client.closed.wait()
            if generation != self._generation:
                return
            self._connected = False
            self._client = None
            self._keyboard_client = None
            self._last_error = "connection lost (TV off or unreachable)"
            self._apps_fresh = False
            await self.db.log("INFO", "lg_tv", "TV connection lost")
            self._publish()
            await self._persist_state(force=True)

    async def _after_connect(self, client: SSAPClient, generation: int) -> None:
        """Populate caches and subscriptions; every step tolerates absence."""
        async def probe(uri: str, apply: Callable[[dict], None], cap: str | None = None) -> None:
            try:
                payload = await client.request(uri)
                if generation == self._generation and self._client is client:
                    apply(payload)
                if cap:
                    self._caps[cap] = True
            except SSAPNotSupported:
                if cap:
                    self._caps[cap] = False
            except SSAPError:
                pass  # transient failure; state stays cached

        def apply_info(p: dict) -> None:
            model = str(p.get("modelName") or "")
            if model:
                self._state["model"] = model

        def apply_volume(p: dict) -> None:
            self._apply_volume_payload(p)

        def apply_foreground(p: dict) -> None:
            self._apply_foreground_payload(p)

        def apply_power(p: dict) -> None:
            self._state["power"] = str(p.get("state") or "on").lower()

        def apply_inputs(p: dict) -> None:
            self._inputs = [
                {"id": str(d.get("id") or ""), "label": str(d.get("label") or d.get("id") or "")[:60]}
                for d in (p.get("devices") or [])
                if d.get("id")
            ]

        def apply_apps(p: dict) -> None:
            self._apply_apps_payload(p)

        await probe(URI_SYSTEM_INFO, apply_info)
        await probe(URI_GET_VOLUME, apply_volume)
        await probe(URI_FOREGROUND_APP, apply_foreground)
        await probe(URI_POWER_STATE, apply_power, cap="power_state")
        if "power" not in self._state:
            self._state["power"] = "on"  # it answered the socket; it is on
        await probe(URI_INPUT_LIST, apply_inputs, cap="inputs")
        await probe(URI_LIST_APPS, apply_apps)

        # live updates (fenced: stale connections must never write state)
        def fenced(apply: Callable[[dict], None]) -> Callable[[dict], None]:
            def handler(payload: dict) -> None:
                if generation == self._generation and self._client is client:
                    apply(payload)
                    self._publish()
                    self._schedule_state_write()
            return handler

        with contextlib.suppress(SSAPError):
            await client.subscribe(URI_GET_VOLUME, fenced(apply_volume))
        with contextlib.suppress(SSAPError):
            await client.subscribe(URI_FOREGROUND_APP, fenced(apply_foreground))
        if self._caps.get("power_state"):
            with contextlib.suppress(SSAPError):
                await client.subscribe(URI_POWER_STATE, fenced(apply_power))
        # LG's second-screen text protocol requires a remote-keyboard
        # registration subscription before insertText. Some apps accept
        # insertText without it, but YouTube silently ignores the request.
        with contextlib.suppress(SSAPError):
            await self._ensure_remote_keyboard(client)

    async def _ensure_remote_keyboard(self, client: SSAPClient) -> None:
        """Register this connection as the TV's active remote keyboard.

        The subscription is intentionally kept for the connection lifetime so
        it follows focus changes as the user opens or closes app text fields.
        Keyboard status is not persisted or exposed.
        """
        if self._keyboard_client is client:
            return
        await client.subscribe(URI_REGISTER_REMOTE_KEYBOARD, lambda _payload: None)
        self._keyboard_client = client

    # -- state helpers ----------------------------------------------------------
    def _apply_volume_payload(self, p: dict) -> None:
        status = p.get("volumeStatus") if isinstance(p.get("volumeStatus"), dict) else p
        vol = status.get("volume")
        mute = status.get("muteStatus", status.get("mute", status.get("muted")))
        if isinstance(vol, (int, float)):
            self._state["volume"] = int(vol)
        if isinstance(mute, bool):
            self._state["muted"] = mute

    def _apply_foreground_payload(self, p: dict) -> None:
        app_id = str(p.get("appId") or "")
        self._state["app_id"] = app_id
        self._state["app_title"] = self._app_title(app_id) if app_id else ""

    def _apply_apps_payload(self, p: dict) -> None:
        apps = []
        for a in p.get("apps") or []:
            app_id = str(a.get("id") or "")
            title = str(a.get("title") or "").strip()
            if app_id and title and valid_app_id(app_id):
                apps.append({"id": app_id, "title": title[:80]})
        if apps:
            self._apps = apps
            self._apps_fresh = True
            if self._state.get("app_id"):
                self._state["app_title"] = self._app_title(self._state["app_id"])

    def _app_title(self, app_id: str) -> str:
        for app in self._apps:
            if app["id"] == app_id:
                return app["title"]
        return app_id

    def _publish(self) -> None:
        with contextlib.suppress(Exception):
            self.bus.publish("tv", **self._public_state())

    def _schedule_state_write(self) -> None:
        with contextlib.suppress(RuntimeError):
            asyncio.get_running_loop().create_task(self._persist_state())

    async def _persist_state(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_state_write < STATE_WRITE_MIN_INTERVAL:
            return
        self._last_state_write = now
        blob = json.dumps({"state": self._state, "apps": self._apps})
        if self._connected:
            self._last_seen_at = _now_iso()
        await self.db.execute(
            "UPDATE lg_webos_devices SET last_state_json=?, last_seen_at=?, updated_at=? WHERE id=?",
            (blob, self._last_seen_at, _now_iso(), DEVICE_ID),
        )

    async def _persist_row(self) -> None:
        await self.db.execute(
            "INSERT INTO lg_webos_devices (id, name, host, mac_address, enabled, paired, last_state_json, last_seen_at, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, host=excluded.host, mac_address=excluded.mac_address, "
            "enabled=excluded.enabled, paired=excluded.paired, updated_at=excluded.updated_at",
            (
                DEVICE_ID,
                self.name,
                self.host,
                self._mac,
                1 if self.enabled else 0,
                1 if self.paired else 0,
                json.dumps({"state": self._state, "apps": self._apps}),
                self._last_seen_at,
                _now_iso(),
                _now_iso(),
            ),
        )

    # -- guarded command surface -------------------------------------------------
    def _require_enabled(self) -> None:
        if not self.enabled:
            raise WebOSTVError("TV control is turned off; enable it on the Devices page")

    def _require_connected(self) -> SSAPClient:
        self._require_enabled()
        if not self.paired:
            raise WebOSTVError("the TV isn't paired yet; pair it from the Devices page")
        client = self._client
        if client is None or not self._connected:
            hint = " You can try 'turn on the tv' to wake it." if self._mac else ""
            raise WebOSTVError(f"the TV is offline (off or unreachable).{hint}")
        return client

    async def _req(self, client: SSAPClient, uri: str, payload: dict | None = None) -> dict:
        """One allowlisted request with every transport/TV failure translated
        into the integration's public error type. Nothing below WebOSTVError
        may escape the command surface -- callers (tools, dashboard, voice)
        only handle WebOSTVError."""
        try:
            return await client.request(uri, payload)
        except SSAPNotSupported:
            raise WebOSTVError("the TV doesn't support that command") from None
        except SSAPError as exc:
            err = WebOSTVError(str(exc))
            # Preserve the "this message embeds TV-supplied text" marker so
            # sensitive operations (text entry) can sanitize their failures.
            err.device_detail = getattr(exc, "device_detail", False)
            raise err from None

    async def power_off(self) -> dict:
        client = self._require_connected()
        await self._req(client, URI_TURN_OFF)
        self._state["power"] = "off"
        self._publish()
        return {"message": "TV turning off."}

    async def power_on(self) -> dict:
        self._require_enabled()
        # A WebSocket can remain alive briefly after turn-off, so transport
        # connectivity alone is not proof that the panel is powered on.
        power = str(self._state.get("power", "")).strip().lower()
        if self._connected and power in {"on", "active"}:
            return {"message": "The TV is already on."}
        if not self._mac:
            raise WebOSTVError(
                "power-on needs the TV's MAC address for Wake-on-LAN; add it on the Devices page"
            )
        try:
            await self._wol_sender(self._mac, self.host)
        except WoLError as exc:
            raise WebOSTVError(str(exc)) from None
        except OSError:
            # a raw socket error may still escape an injected sender; it is
            # the same ordinary network failure, so same safe error type
            raise WebOSTVError("could not send the wake signal on this network") from None
        await self.db.log("INFO", "lg_tv", "wake signal sent to the TV")
        return {
            "message": (
                "Wake signal sent. If the TV supports network standby it should turn on "
                "within a few seconds; otherwise use the TV remote."
            )
        }

    async def set_volume(self, percentage=None, delta=None) -> dict:
        client = self._require_connected()
        if percentage is None and delta is None:
            raise WebOSTVError("provide a volume level or a change amount")
        if percentage is not None:
            try:
                target = clamp_volume(percentage)
            except (TypeError, ValueError):
                raise WebOSTVError("the volume level must be a number between 0 and 100") from None
        else:
            try:
                step = int(delta)
            except (TypeError, ValueError):
                raise WebOSTVError("volume change must be a number") from None
            current = self._state.get("volume")
            if not isinstance(current, int):
                payload = await self._req(client, URI_GET_VOLUME)
                self._apply_volume_payload(payload)
                current = self._state.get("volume")
            if not isinstance(current, int):
                raise WebOSTVError("could not read the current TV volume")
            target = max(0, min(100, current + step))
        await self._req(client, URI_SET_VOLUME, {"volume": target})
        self._state["volume"] = target
        self._publish()
        return {"volume": target}

    async def set_mute(self, muted: bool) -> dict:
        client = self._require_connected()
        await self._req(client, URI_SET_MUTE, {"mute": bool(muted)})
        self._state["muted"] = bool(muted)
        self._publish()
        return {"muted": bool(muted)}

    async def media(self, action: str) -> dict:
        client = self._require_connected()
        uri = MEDIA_ACTIONS.get(str(action or "").strip().lower())
        if uri is None:
            allowed = ", ".join(sorted(MEDIA_ACTIONS))
            raise WebOSTVError(f"media action must be one of: {allowed}")
        await self._req(client, uri)
        return {"action": action}

    async def button(self, name: str) -> dict:
        client = self._require_connected()
        key = str(name or "").strip().lower().replace(" ", "_")
        if key not in BUTTONS:
            allowed = ", ".join(sorted(BUTTONS))
            raise WebOSTVError(f"button must be one of: {allowed}")
        try:
            await client.button(key)
        except SSAPError as exc:
            raise WebOSTVError(str(exc)) from None
        return {"pressed": key}

    async def type_text(self, text: str, submit: bool = False) -> dict:
        """Type into whatever text field is focused on the TV (search boxes,
        login forms the user opened, ...).  The TV's IME simply ignores text
        when no field is focused, so this cannot press buttons or navigate.

        Bounds: plain printable text only, hard length cap, no control
        characters.  The text itself is never logged, persisted, or echoed
        back -- the result only reports how many characters were sent.
        """
        client = self._require_connected()
        if not isinstance(text, str):
            raise WebOSTVError("TV text must be a string")
        cleaned = text.strip()
        if not cleaned:
            raise WebOSTVError("there is no text to type")
        if len(cleaned) > TEXT_MAX_CHARS:
            raise WebOSTVError(
                f"TV text is limited to {TEXT_MAX_CHARS} characters"
            )
        if any(ord(ch) < 32 or ord(ch) == 127 for ch in cleaned):
            raise WebOSTVError(
                "TV text cannot contain line breaks or control characters"
            )
        try:
            await self._ensure_remote_keyboard(client)
            await self._req(client, URI_INSERT_TEXT, {"text": cleaned, "replace": 0})
            if submit:
                await self._req(client, URI_SEND_ENTER)
        except WebOSTVError as exc:
            low = str(exc).lower()
            if "permission" in low or "401" in low or "insufficient" in low:
                # TVs paired before keyboard permission was requested must be
                # re-paired once so the user can approve the extra permission.
                raise WebOSTVError(
                    "the TV refused text input -- remove the pairing on the "
                    "Devices page and pair again to grant keyboard access"
                ) from None
            if getattr(exc, "device_detail", False):
                # The TV's own error text could echo what was typed; text-entry
                # failures must always use fixed wording (never device detail).
                raise WebOSTVError(
                    "the TV rejected the text input; nothing may have been typed"
                ) from None
            raise  # local, fixed-wording errors (offline, unsupported, ...)
        return {"typed": len(cleaned), "submitted": bool(submit)}

    async def list_inputs(self) -> dict:
        self._require_connected()
        if not self._caps.get("inputs", True):
            raise WebOSTVError("this TV does not report its inputs")
        return {"inputs": list(self._inputs)}

    async def set_input(self, query: str) -> dict:
        client = self._require_connected()
        if not self._inputs:
            with contextlib.suppress(SSAPError):
                payload = await client.request(URI_INPUT_LIST)
                self._inputs = [
                    {"id": str(d.get("id") or ""), "label": str(d.get("label") or d.get("id") or "")[:60]}
                    for d in (payload.get("devices") or [])
                    if d.get("id")
                ]
        if not self._inputs:
            raise WebOSTVError("this TV does not report switchable inputs")
        needle = " ".join(str(query or "").lower().split())
        if not needle:
            raise WebOSTVError("say which input, e.g. 'HDMI 1'")
        compact = needle.replace(" ", "").replace("-", "_")
        matches = [
            i for i in self._inputs
            if needle == i["label"].lower()
            or compact == i["id"].lower()
            or needle in i["label"].lower()
            or compact in i["id"].lower().replace("-", "_")
        ]
        if not matches:
            labels = ", ".join(i["label"] for i in self._inputs[:8])
            raise WebOSTVError(f"no input matches '{query}'. Available: {labels}")
        if len(matches) > 1:
            labels = ", ".join(i["label"] for i in matches[:8])
            raise WebOSTVError(f"'{query}' matches several inputs: {labels}")
        await self._req(client, URI_SWITCH_INPUT, {"inputId": matches[0]["id"]})
        return {"input": matches[0]["label"]}

    # -- installed apps ------------------------------------------------------------
    async def refresh_apps(self) -> dict:
        client = self._require_connected()
        payload = await self._req(client, URI_LIST_APPS)
        self._apply_apps_payload(payload)
        await self._persist_state(force=True)
        self._publish()
        return {"count": len(self._apps)}

    def search_apps(self, query: str = "", limit: int = 12) -> dict:
        """Search the cached installed-app list (works offline, marked stale)."""
        self._require_enabled()
        apps = list(self._apps)
        if not apps:
            raise WebOSTVError(
                "no app list from the TV yet; connect to the TV once to load its apps"
            )
        needle = " ".join(str(query or "").lower().split())
        if needle:
            exact = [a for a in apps if a["title"].lower() == needle]
            contains = [a for a in apps if needle in a["title"].lower() and a not in exact]
            close_titles = difflib.get_close_matches(
                needle, [a["title"].lower() for a in apps], n=limit, cutoff=0.6
            )
            fuzzy = [
                a for a in apps
                if a["title"].lower() in close_titles and a not in exact and a not in contains
            ]
            apps = (exact + contains + fuzzy)[: max(1, min(int(limit), 30))]
        else:
            apps = sorted(apps, key=lambda a: a["title"].lower())[: max(1, min(int(limit), 30))]
        return {"apps": apps, "stale": not self._apps_fresh, "installed_count": len(self._apps)}

    def _resolve_app(self, query: str) -> dict:
        needle = " ".join(str(query or "").lower().split())
        if not needle:
            raise WebOSTVError("say which app to open")
        if not self._apps:
            raise WebOSTVError("no app list from the TV yet; try again once the TV is connected")
        exact = [a for a in self._apps if a["title"].lower() == needle]
        if len(exact) == 1:
            return exact[0]
        by_id = [a for a in self._apps if a["id"].lower() == needle]
        if len(by_id) == 1:
            return by_id[0]
        contains = [a for a in self._apps if needle in a["title"].lower()]
        if len(contains) == 1:
            return contains[0]
        if len(contains) > 1:
            titles = ", ".join(a["title"] for a in contains[:6])
            raise WebOSTVError(f"'{query}' matches several TV apps: {titles}. Be more specific.")
        close = difflib.get_close_matches(needle, [a["title"].lower() for a in self._apps], n=3, cutoff=0.75)
        if len(close) == 1:
            for a in self._apps:
                if a["title"].lower() == close[0]:
                    return a
        hints = difflib.get_close_matches(needle, [a["title"] for a in self._apps], n=3, cutoff=0.4)
        hint = f" Did you mean: {', '.join(hints)}?" if hints else ""
        raise WebOSTVError(f"'{query}' isn't installed on the TV.{hint}")

    async def launch_app(self, query: str) -> dict:
        client = self._require_connected()
        app = self._resolve_app(query)
        if not valid_app_id(app["id"]):
            raise WebOSTVError("that app has an invalid identifier")
        await self._req(client, URI_LAUNCH_APP, {"id": app["id"]})
        self._state["app_id"] = app["id"]
        self._state["app_title"] = app["title"]
        self._publish()
        return {"launched": app["title"]}

    # -- read-only views ----------------------------------------------------------
    def status(self) -> dict:
        """Compact status for voice/typed answers.  Never includes secrets."""
        if not self.enabled:
            return {"enabled": False, "message": "TV control is turned off."}
        if not self.paired:
            return {"enabled": True, "paired": False, "message": "The TV isn't paired yet."}
        if not self._connected:
            msg = "The TV is offline (off or unreachable)."
            if self._mac:
                msg += " Say 'turn on the tv' to try waking it."
            return {"enabled": True, "paired": True, "connected": False, "message": msg}
        out = {
            "enabled": True,
            "paired": True,
            "connected": True,
            "power": self._state.get("power", "on"),
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or self._state.get("app_id") or "",
            "name": self.name,
        }
        if self._state.get("model"):
            out["model"] = self._state["model"]
        return out

    def _public_state(self) -> dict:
        return {
            "enabled": self.enabled,
            "paired": self.paired,
            "connected": self._connected,
            "power": self._state.get("power", ""),
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or "",
            "pairing": self._pairing_status,
        }

    def snapshot(self) -> dict:
        """Full dashboard view.  The MAC and pairing key are never included."""
        return {
            "enabled": self.enabled,
            "configured": bool(self.host),
            "host": self.host,
            "name": self.name,
            "paired": self.paired,
            "connected": self._connected,
            "pairing": {"status": self._pairing_status, "error": self._pairing_error},
            "power": self._state.get("power", ""),
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or "",
            "model": self._state.get("model", ""),
            "app_count": len(self._apps),
            "apps_stale": not self._apps_fresh,
            "inputs": list(self._inputs),
            "wol_ready": bool(self._mac),
            "last_error": self._last_error,
            "last_seen_at": self._last_seen_at,
        }
