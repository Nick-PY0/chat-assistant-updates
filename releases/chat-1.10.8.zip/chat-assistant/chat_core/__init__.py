"""Nexa core package startup.

Keep the dependency bridge before imports of any application modules.  A
1.9.23 launcher continues in-process after copying 1.9.24 over itself, so this
is the first updated code it executes.
"""

from pathlib import Path

from startup_dependencies import (
    DependencySyncError,
    ensure_legacy_update_dependencies,
)


try:
    ensure_legacy_update_dependencies(Path(__file__).resolve().parents[1] / "requirements.txt")
except DependencySyncError as exc:
    print(
        "Nexa was updated, but its Python dependencies could not be installed "
        f"({exc}).\n"
        "Close Nexa, check your internet connection, then run "
        f'"{Path(__file__).resolve().parents[1] / "run_chat.bat"}" again.'
    )
    raise SystemExit(1) from exc
