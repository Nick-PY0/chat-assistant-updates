"""Local status announcements that never depend on Gemini.

Plays pre-generated WAV files from assets/announcements/ when available
(generate them once with deployment/windows/generate_announcements.py,
which uses the OS's offline text-to-speech). Falls back to a console
notice + terminal bell when no audio path exists.
"""

from __future__ import annotations

import logging

from chat_core.paths import resource_root

log = logging.getLogger("announce")

ASSETS = resource_root() / "assets" / "announcements"

MESSAGES = {
    "ok": "Done.",
    "not_understood": (
        "That's not something I can do offline. "
        "I can set timers and control lights."
    ),
    "quota_exhausted": (
        "My Gemini voice quota has been exhausted. "
        "Local timers and light controls are still available."
    ),
    "service_unavailable": (
        "The voice service is currently unavailable. "
        "I can still manage local timers and supported room controls."
    ),
    "local_mode": "Local mode. Timers and lights only.",
    "timer_done": "Your timer is done.",
    "timer_missed": "A timer finished while I was off.",
    "muted": "Microphone muted.",
    "unmuted": "Microphone active.",
    "quiet_on": "Quiet mode. I'll keep my announcements to myself. Alarms still ring.",
    "quiet_off": "Quiet mode off.",
    "reminder_missed": "A reminder went off while I was away. It's on the dashboard.",
    "reminder_fallback": "You have a reminder. The message is on the dashboard.",
}


class Announcer:
    """Plays canned messages through the audio engine's speaker queue."""

    def __init__(self, play_wav_bytes=None) -> None:
        # play_wav_bytes: callable(pcm_bytes, sample_rate) -> None, provided
        # by the audio engine when a speaker exists.
        self.play_wav_bytes = play_wav_bytes

    def announce(self, key: str) -> None:
        text = MESSAGES.get(key, key)
        wav = ASSETS / f"{key}.wav"
        if self.play_wav_bytes and wav.exists():
            try:
                import wave

                with wave.open(str(wav), "rb") as w:
                    pcm = w.readframes(w.getnframes())
                    self.play_wav_bytes(pcm, w.getframerate())
                return
            except Exception as exc:  # fall through to console
                log.debug("announcement playback failed: %s", type(exc).__name__)
        # Console fallback -- also rings the terminal bell.
        print(f"\a[Nexa] {text}")
