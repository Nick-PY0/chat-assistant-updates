"""Audio engine: wake word, microphone streaming, playback, interruption.

Heavy dependencies (sounddevice, numpy, openwakeword) are OPTIONAL. When
they're missing -- e.g. running on a machine without audio or before
`pip install -r requirements-voice.txt` -- the engine reports
voice_available=False and the rest of Chat (dashboard, timers, lights,
rotation) runs normally. This keeps the default install tiny and the
process light, per the user's requirement.

Design rules honored here:
  * No network, database, logging, or health work inside audio callbacks.
  * Bounded buffers everywhere.
  * Local VAD stays active while Chat speaks; crossing the threshold
    clears queued playback and signals interruption.
  * Wake-word detection keeps running after the cloud session closes.
"""

from __future__ import annotations

import asyncio
import logging
import queue as thread_queue
import time
from typing import Callable

from apps.audio.mic_gate import PlaybackAwareMicGate
from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.state import ChatState, StateMachine

log = logging.getLogger("audio")

try:  # optional voice stack
    import numpy as np  # type: ignore
    import sounddevice as sd  # type: ignore

    _AUDIO_OK = True
except Exception:  # pragma: no cover - environment dependent
    _AUDIO_OK = False

try:  # optional wake word
    class _RuntimeFallbackNoise(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            return "Tried to import the tflite runtime" not in record.getMessage()

    _root_logger = logging.getLogger()
    _runtime_filter = _RuntimeFallbackNoise()
    _root_logger.addFilter(_runtime_filter)
    try:
        from openwakeword.model import Model as WakeModel  # type: ignore
    finally:
        _root_logger.removeFilter(_runtime_filter)

    _WAKE_OK = True
except Exception:  # pragma: no cover
    _WAKE_OK = False

IN_RATE = 16000
OUT_RATE = 24000
CHUNK = 1280  # 80 ms at 16 kHz
# openWakeWord processes audio internally in 80 ms frames and documents that
# passing a longer multiple reduces CPU at the cost of detection latency.  Two
# frames is a conservative low-power tradeoff: fewer Python/ONNX calls while
# adding at most one frame (80 ms) before a wake score is returned.
LOW_POWER_WAKE_BATCH_CHUNKS = 2
REMOTE_WAKE_STREAM_GRACE_SECONDS = 0.4


def _short(exc: Exception) -> str:
    s = str(exc).strip() or type(exc).__name__
    return s.splitlines()[0][:200]


def _download_wake_models() -> None:  # pragma: no cover - network download
    """openwakeword ships its CODE on pip but not its MODEL FILES; this
    fetches them once (a few small .onnx files) into the package folder."""
    import openwakeword.utils  # type: ignore

    openwakeword.utils.download_models()


_OWW_TFLITE_MSG = "Tried to import the tflite runtime"


def _load_wake_model_blocking(model_ref: str | None) -> tuple[object | None, str]:
    """Load the wake model (runs in a worker thread). Returns (model, "")
    on success or (None, plain-language reason) on failure -- never raises.

    A fresh laptop install fails the first construction with ValueError
    because the model files were never downloaded (install.bat used to skip
    that step entirely); we download them and retry once.
    """
    from pathlib import Path

    class _TfliteNoise(logging.Filter):
        def filter(self, record: logging.LogRecord) -> bool:
            return _OWW_TFLITE_MSG not in record.getMessage()

    _f = _TfliteNoise()
    _root = logging.getLogger()

    custom = bool(model_ref) and (
        "/" in model_ref or "\\" in model_ref or model_ref.endswith((".onnx", ".tflite"))
    )
    if custom:
        if not Path(model_ref).exists():
            return None, f"custom wake word model file not found: {model_ref}"
        try:
            _root.addFilter(_f)
            try:
                return WakeModel(wakeword_models=[model_ref]), ""
            finally:
                _root.removeFilter(_f)
        except Exception as exc:
            return None, f"could not load the custom wake word model: {_short(exc)}"

    kwargs = {"wakeword_models": [model_ref] if model_ref else None}
    try:
        _root.addFilter(_f)
        try:
            return WakeModel(**kwargs), ""
        finally:
            _root.removeFilter(_f)
    except Exception:
        pass  # most likely: model files not downloaded yet -- fix and retry
    try:
        _download_wake_models()
    except Exception as exc:
        return None, (
            "the wake word model files are missing and could not be downloaded "
            f"({type(exc).__name__}) -- connect to the internet and restart "
            "Nexa, or re-run deployment\\windows\\install.bat"
        )
    try:
        _root.addFilter(_f)
        try:
            return WakeModel(**kwargs), ""
        finally:
            _root.removeFilter(_f)
    except Exception as exc:
        return None, (
            f"wake word model failed to load even after downloading its files: {_short(exc)}"
        )


class AudioEngine:
    def __init__(
        self,
        settings: Settings,
        bus: EventBus,
        state: StateMachine,
        audio_in: asyncio.Queue[bytes],
        audio_out: asyncio.Queue[bytes],
        on_wake: Callable[[], None],
        on_interrupt: Callable[[], None],
        broadcast=None,          # AudioBroadcast: dashboard/phone listeners
        transcriber=None,        # LocalTranscriber for offline commands
        on_local_command=None,   # async callable(text) in LOCAL_ONLY mode
        on_voice_duck=None,      # async () → bool: duck companion on gate open
        on_voice_pause=None,     # async () → bool: pause companion on confirmed wake
        on_voice_restore=None,   # async () → bool: restore companion on session end
    ) -> None:
        self.settings = settings
        self.bus = bus
        self.state = state
        self.audio_in = audio_in
        self.audio_out = audio_out
        self.on_wake = on_wake
        self.on_interrupt = on_interrupt
        self.broadcast = broadcast
        self.transcriber = transcriber
        self.on_local_command = on_local_command
        # Optional async voice-focus callbacks for companion playback.
        # All three are best-effort: failures are logged and never propagated.
        self._on_voice_duck    = on_voice_duck
        self._on_voice_pause   = on_voice_pause
        self._on_voice_restore = on_voice_restore

        self.voice_available = False
        self.unavailable_reason = ""
        self._stop = asyncio.Event()
        self._mic_q: "thread_queue.Queue[bytes]" = thread_queue.Queue(maxsize=64)
        self._spk_q: "thread_queue.Queue[bytes]" = thread_queue.Queue(maxsize=256)
        self._wake_model = None
        self._in_stream = None
        self._out_stream = None
        self._capture: list[bytes] | None = None   # local-utterance recording
        self._capture_silent = 0
        self._wake_batch: list[bytes] = []
        self.remote_mic_active = False
        self._interrupt_loud_chunks = 0
        self._media_mic_gate = PlaybackAwareMicGate(
            max(900.0, self.settings.interrupt_rms_threshold * 1.25),
            onset_seconds=0.24,
            release_seconds=0.88,
            preroll_seconds=0.32,
            calibration_seconds=0.32,
        )
        # Serialise remote-wake access: the local sleeping mic must not run
        # the shared wake model concurrently with a remote browser.
        self._remote_wake_lock = asyncio.Lock()
        self._wake_source: str | None = None
        self._remote_wake_last_frame = 0.0
        self._wake_prediction_count = 0
        self._wake_last_score = 0.0
        self._wake_peak_score = 0.0
        self._wake_diagnostic_threshold = float(self.settings.wake_threshold)
        self._wake_consecutive_errors = 0
        self._wake_last_error = ""

    @property
    def media_playing(self) -> bool:
        return self._media_mic_gate.media_playing

    def set_media_playing(self, playing: bool) -> None:
        """Suppress speaker-media residue while keeping wake/speech live."""
        self._media_mic_gate.set_media_playing(playing)

    # ------------------------------------------------------------------
    # Voice-focus helpers (local mic path)
    # ------------------------------------------------------------------

    async def _fire_voice_duck(self) -> None:
        """Best-effort: duck companion volume on confirmed user-speech onset.

        Only fires when ``_media_mic_gate.is_open`` transitions True (the gate
        accepted a sustained speech onset — not raw RMS, not a brief transient).
        Never fires while the assistant is playing (the gate gates that out).
        Errors are swallowed: a missed duck never affects the wake path.
        """
        if self._on_voice_duck is None:
            return
        if self._media_mic_gate.assistant_playing:
            return
        try:
            await self._on_voice_duck()
        except Exception as exc:
            log.debug("voice_duck callback failed: %s", exc)

    async def _fire_voice_pause(self) -> None:
        """Best-effort: pause companion on a confirmed wake or session start.

        Only called after ``_fire_voice_duck`` and a confirmed wake hit or
        external session bind — never on raw audio without a confirmed wake.
        Errors are swallowed.
        """
        if self._on_voice_pause is None:
            return
        if self._media_mic_gate.assistant_playing:
            return
        try:
            await self._on_voice_pause()
        except Exception as exc:
            log.debug("voice_pause callback failed: %s", exc)

    async def _fire_voice_restore(self) -> None:
        """Best-effort: restore companion volume/state when session ends.

        Only restores if the YouTubeTool owns the duck (``_voice_ducked=True``);
        that flag is cleared by explicit user commands, so restore is a no-op if
        the user gave an explicit media command during the session.
        Errors are swallowed.
        """
        if self._on_voice_restore is None:
            return
        try:
            await self._on_voice_restore()
        except Exception as exc:
            log.debug("voice_restore callback failed: %s", exc)

    # ------------------------------------------------------------------
    def probe(self) -> None:
        if not self.settings.voice_enabled:
            self.unavailable_reason = "voice disabled in settings"
            return
        if not _AUDIO_OK:
            self.unavailable_reason = (
                "audio packages not installed (pip install -r requirements-voice.txt)"
            )
            return
        try:
            devices = sd.query_devices()
        except Exception as exc:
            self.unavailable_reason = f"no audio backend: {_short(exc)}"
            return
        has_input = any(d.get("max_input_channels", 0) > 0 for d in devices)
        has_output = any(d.get("max_output_channels", 0) > 0 for d in devices)
        if not has_input or not has_output:
            self.unavailable_reason = "no microphone/speaker detected"
            return
        if not _WAKE_OK:
            self.unavailable_reason = "openwakeword not installed"
            return
        self.voice_available = True

    def list_devices(self) -> list[dict]:
        if not _AUDIO_OK:
            return []
        try:
            return [
                {
                    "index": i,
                    "name": d.get("name"),
                    "inputs": d.get("max_input_channels", 0),
                    "outputs": d.get("max_output_channels", 0),
                }
                for i, d in enumerate(sd.query_devices())
            ]
        except Exception:
            return []

    # ------------------------------------------------------------------
    async def run(self) -> None:
        self.probe()
        if not self.voice_available:
            log.warning("voice pipeline disabled: %s", self.unavailable_reason)
            self.bus.publish("audio_status", available=False, reason=self.unavailable_reason)
            # No sound card is needed for phone listening: keep draining
            # Gemini audio into the dashboard stream; otherwise stay dormant.
            while not self._stop.is_set():
                try:
                    pcm = await asyncio.wait_for(self.audio_out.get(), timeout=0.5)
                except asyncio.TimeoutError:
                    continue
                if self.broadcast is not None:
                    self.broadcast.publish(pcm)
            return

        self.bus.publish("audio_status", available=True, reason="")
        model_ref = self.settings.wake_word_model
        # Model load takes seconds -- keep it off the event loop so the
        # dashboard (same process) stays responsive during startup. The
        # helper also downloads the model FILES on first use: this is what
        # the old "wake model load failed (ValueError)" actually was.
        self._wake_model, load_error = await asyncio.to_thread(
            _load_wake_model_blocking, model_ref
        )
        if self._wake_model is None:
            log.error("wake word unavailable: %s; voice disabled", load_error)
            self.bus.publish("audio_status", available=False, reason=load_error)
            await self._stop.wait()
            return

        def mic_callback(indata, frames, t, status) -> None:
            # Audio callback: copy bytes into a bounded thread queue. Nothing else.
            try:
                self._mic_q.put_nowait(bytes(indata))
            except thread_queue.Full:
                pass

        def spk_callback(outdata, frames, t, status) -> None:
            needed = len(outdata)
            buf = b""
            while len(buf) < needed:
                try:
                    buf += self._spk_q.get_nowait()
                except thread_queue.Empty:
                    break
            if len(buf) < needed:
                buf += b"\x00" * (needed - len(buf))
            elif len(buf) > needed:
                # push the remainder back (front of queue order is close enough here)
                try:
                    self._spk_q.put_nowait(buf[needed:])
                except thread_queue.Full:
                    pass
                buf = buf[:needed]
            outdata[:] = buf

        in_kwargs: dict = dict(samplerate=IN_RATE, channels=1, dtype="int16", blocksize=CHUNK, callback=mic_callback)
        out_kwargs: dict = dict(samplerate=OUT_RATE, channels=1, dtype="int16", blocksize=0, callback=spk_callback)
        if self.settings.mic_device:
            in_kwargs["device"] = self.settings.mic_device
        if self.settings.speaker_device:
            out_kwargs["device"] = self.settings.speaker_device

        try:
            self._in_stream = sd.RawInputStream(**in_kwargs)
            self._in_stream.start()
        except Exception as exc:
            reason = f"microphone stream failed: {_short(exc)}"
            log.error("audio %s", reason)
            self.bus.publish("audio_status", available=False, reason=reason)
            try:
                if self._in_stream is not None:
                    self._in_stream.close()
            except Exception:
                pass
            self._in_stream = None
            await self._stop.wait()
            return

        try:
            self._out_stream = sd.RawOutputStream(**out_kwargs)
            self._out_stream.start()
        except Exception as exc:
            reason = f"speaker stream failed: {_short(exc)}"
            log.error("audio %s", reason)
            self.bus.publish("audio_status", available=False, reason=reason)
            for stream in (self._out_stream, self._in_stream):
                try:
                    if stream is not None:
                        stream.stop()
                        stream.close()
                except Exception:
                    pass
            self._out_stream = None
            self._in_stream = None
            await self._stop.wait()
            return

        pump = asyncio.create_task(self._playback_pump(), name="audio-playback-pump")
        try:
            await self._mic_loop()
        finally:
            pump.cancel()
            await asyncio.gather(pump, return_exceptions=True)
            for stream in (self._in_stream, self._out_stream):
                try:
                    stream.stop(); stream.close()
                except Exception:
                    pass

    async def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------------
    async def _playback_pump(self) -> None:
        """Move Gemini PCM from the asyncio queue into the speaker's thread
        queue and the dashboard/phone stream, honoring the output route."""
        while not self._stop.is_set():
            try:
                pcm = await asyncio.wait_for(self.audio_out.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            if self.broadcast is not None:
                self.broadcast.publish(pcm)
            if self.settings.audio_output_route == "phone":
                continue  # this computer stays silent by choice
            try:
                self._spk_q.put_nowait(pcm)
            except thread_queue.Full:
                pass

    def clear_playback(self) -> None:
        while True:
            try:
                self._spk_q.get_nowait()
            except thread_queue.Empty:
                break
        if self.broadcast is not None:
            self.broadcast.clear()

    def play_wav_bytes(self, pcm: bytes, rate: int, force_speaker: bool = False) -> None:
        """Used by the announcer for canned local messages. force_speaker
        makes alarms audible even when output is routed to the phone."""
        # normalize to OUT_RATE
        if rate != OUT_RATE:
            if _AUDIO_OK:
                arr = np.frombuffer(pcm, dtype=np.int16)
                idx = np.linspace(0, len(arr) - 1, int(len(arr) * OUT_RATE / max(rate, 1))).astype(np.int64)
                pcm = arr[idx].tobytes()
            else:
                from apps.audio.broadcast import resample_pcm16

                pcm = resample_pcm16(pcm, rate, OUT_RATE)
        if self.broadcast is not None:
            self.broadcast.publish(pcm)
        if not self.voice_available:
            return
        if self.settings.audio_output_route == "phone" and not force_speaker:
            return
        for i in range(0, len(pcm), 4800):
            try:
                self._spk_q.put_nowait(pcm[i : i + 4800])
            except thread_queue.Full:
                return

    @property
    def remote_wake_available(self) -> bool:
        """True when a remote device can use server-side wake detection."""
        return (
            self._wake_model is not None
            and _AUDIO_OK
            and self._wake_consecutive_errors < 3
        )

    def wake_diagnostics(self) -> dict:
        """Small, non-audio snapshot for the remote controller/status UI."""
        self._sync_wake_diagnostic_threshold()
        return {
            "source": self._wake_source or "",
            "predictions": self._wake_prediction_count,
            "last_score": round(self._wake_last_score, 4),
            "peak_score": round(self._wake_peak_score, 4),
            "threshold": float(self.settings.wake_threshold),
            "consecutive_errors": self._wake_consecutive_errors,
            "error": self._wake_last_error,
        }

    def _sync_wake_diagnostic_threshold(self) -> None:
        """Keep score telemetry inside one sensitivity-setting epoch."""
        threshold = float(self.settings.wake_threshold)
        if threshold == self._wake_diagnostic_threshold:
            return
        self._wake_diagnostic_threshold = threshold
        self._wake_prediction_count = 0
        self._wake_last_score = 0.0
        self._wake_peak_score = 0.0

    def _remote_wake_streaming(self) -> bool:
        """True only while the attached browser is actually sending PCM."""
        return (
            self.remote_mic_active
            and self._remote_wake_last_frame > 0.0
            and time.monotonic() - self._remote_wake_last_frame
            < REMOTE_WAKE_STREAM_GRACE_SECONDS
        )

    def _select_wake_source_locked(self, source: str) -> bool:
        """Switch the stateful model between host and phone audio cleanly."""
        if self._wake_source == source:
            return True
        self._wake_batch.clear()
        self._wake_prediction_count = 0
        self._wake_last_score = 0.0
        self._wake_peak_score = 0.0
        model = self._wake_model
        if model is not None and self._wake_source is not None:
            try:
                model.reset()
            except Exception:
                return False
        self._wake_source = source
        return True

    async def reset_remote_wake(self) -> None:
        """Start the remote wake detector from a clean utterance boundary.

        A conversation pauses wake inference while the model still owns
        rolling feature state from before that conversation.  In particular,
        a manual start followed by Goodbye could resume against stale context
        and miss the first "Hey Jarvis".  Model reset and every prediction
        share one lock, so an ownership handoff can never reset OpenWakeWord's
        rolling state while a host prediction is still running.
        """
        async with self._remote_wake_lock:
            self._wake_batch.clear()
            self._wake_source = None
            self._wake_prediction_count = 0
            self._wake_last_score = 0.0
            self._wake_peak_score = 0.0
            model = self._wake_model
            if model is not None:
                try:
                    model.reset()
                except Exception:
                    pass

    async def _predict_wake_model(self, arr) -> dict:
        """Run model prediction without releasing ownership on cancellation.

        ``asyncio.to_thread`` cannot stop a worker already executing.  Audio
        reload cancels the engine task; without shielding and then joining the
        worker, the surrounding model lock would be released while predict()
        continued in the thread, allowing a new engine owner to reset the same
        model concurrently.
        """
        self._sync_wake_diagnostic_threshold()
        worker = asyncio.create_task(
            asyncio.to_thread(self._wake_model.predict, arr)
        )
        try:
            scores = await asyncio.shield(worker)
        except asyncio.CancelledError:
            try:
                await worker
            except Exception:
                pass
            raise
        except Exception as exc:
            self._wake_consecutive_errors += 1
            self._wake_last_error = _short(exc)
            if self._wake_consecutive_errors in (1, 3):
                log.warning(
                    "wake inference failed (%s consecutive): %s",
                    self._wake_consecutive_errors,
                    self._wake_last_error,
                )
            raise
        self._wake_prediction_count += 1
        self._wake_consecutive_errors = 0
        self._wake_last_error = ""
        numeric_scores = []
        for value in (scores or {}).values():
            try:
                numeric_scores.append(float(value))
            except (TypeError, ValueError):
                continue
        self._wake_last_score = max(numeric_scores, default=0.0)
        self._wake_peak_score = max(self._wake_peak_score, self._wake_last_score)
        return scores

    async def run_remote_wake(self, chunk: bytes) -> bool:
        """Run one 1280-sample (80 ms at 16 kHz) chunk through the wake model.

        Called from the /ws/remote-audio handler while the socket is in
        wake-listening mode (before a session starts).  Returns True on a
        wake-word hit.

        Contract:
          * chunk MUST be exactly CHUNK * 2 (2560) bytes of PCM16 mono 16 kHz.
          * Inference runs off the event loop via asyncio.to_thread.
          * The remote-wake lock prevents concurrent use between this path
            and the local sleeping-mic wake detector; the local loop already
            skips wake detection when remote_mic_active is True.
          * Mute and stop checks are re-evaluated after the off-loop call.
          * The low-power batch is respected: in low_power mode two chunks
            are accumulated before inference is triggered.
          * The model is reset on a hit so the next wake starts clean.
        """
        if self._wake_model is None or not _AUDIO_OK:
            return False
        if self._stop.is_set() or self.state.muted:
            return False
        self._remote_wake_last_frame = time.monotonic()

        async with self._remote_wake_lock:
            if not self._select_wake_source_locked("remote"):
                return False
            wake_input = self._prepare_wake_input(chunk)
            if wake_input is None:
                return False
            arr = np.frombuffer(wake_input, dtype=np.int16)
            try:
                scores = await self._predict_wake_model(arr)
            except Exception:
                return False
            # Re-check the gate after off-loop inference, but keep ownership
            # through reset. OpenWakeWord's reset mutates the same rolling
            # state as predict and may never overlap another model operation.
            if not self._wake_gate_open():
                return False
            if scores and max(scores.values()) >= self.settings.wake_threshold:
                try:
                    self._wake_model.reset()
                except Exception:
                    return False
                return True
        return False

    async def _run_host_wake_predict(self, chunk: bytes) -> dict | None:
        """Run one sleeping-host prediction under shared model ownership.

        ``None`` means no usable host result: remote ownership won, low-power
        batching needs another chunk, or prediction failed.  Rechecking
        ``remote_mic_active`` after off-thread inference discards a host score
        when a phone took ownership while predict() was already running.
        """
        async with self._remote_wake_lock:
            if self._remote_wake_streaming():
                self._wake_batch.clear()
                return None
            if not self._select_wake_source_locked("host"):
                return None
            wake_input = self._prepare_wake_input(chunk)
            if wake_input is None:
                return None
            arr = np.frombuffer(wake_input, dtype=np.int16)
            try:
                scores = await self._predict_wake_model(arr)
            except Exception:
                return None
        if self._remote_wake_streaming():
            return None
        return scores

    async def _mic_loop(self) -> None:
        """Wake-word detection + streaming + interruption VAD.

        Voice-focus companion integration
        ----------------------------------
        When voice-focus callbacks are injected (on_voice_duck / on_voice_pause
        / on_voice_restore), this loop calls them at the correct gate transitions:

        * **Duck**: fires when the PlaybackAwareMicGate transitions ``is_open``
          from False → True during an active conversation session.  The gate's
          onset logic (sustained speech above the calibrated noise floor) acts
          as the acceptance criterion — not raw RMS.  Never fires while the
          assistant is playing.

        * **Pause**: fires once on a confirmed wake hit or session start (same
          two places ``on_wake()`` is called or a session is bound externally).
          Pause comes after duck so the volume is already low when Jarvis starts
          speaking.

        * **Restore**: fires when a session ends (session_active transitions
          True → False).  Restore is a no-op inside YouTubeTool when the user
          gave an explicit media command during the session (``_voice_ducked``
          is False in that case).

        All three are best-effort; errors are logged and never propagate back
        here.  Wake listening stays active throughout.
        """
        wake_scores_needed = 1
        session_was_active = False
        gate_was_open = False
        while not self._stop.is_set():
            try:
                chunk = await asyncio.to_thread(self._mic_q.get, True, 0.5)
            except thread_queue.Empty:
                continue

            if self.state.muted:
                self._capture = None  # muting aborts any local recording
                self._wake_batch.clear()
                continue  # capture blocked by the emergency control

            st = self.state.raw_state

            # Recording a local-only utterance for offline transcription?
            if self._capture is not None:
                self._wake_batch.clear()
                finished = self._capture_step(chunk)
                if finished is not None:
                    asyncio.create_task(self._finish_local_capture(b"".join(finished)))
                continue

            session_active = st in (ChatState.LISTENING, ChatState.SPEAKING, ChatState.CONNECTING)
            if session_was_active and not session_active:
                # Session just ended: restore companion and reset gate.
                self._media_mic_gate.close_utterance()
                gate_was_open = False
                asyncio.create_task(self._fire_voice_restore())
            session_was_active = session_active

            if session_active:
                # Never carry sleeping-state audio into a live provider
                # session if the state changed between microphone callbacks.
                self._wake_batch.clear()
                # A logged-in dashboard device can temporarily be the mic.
                # Do not mix the computer's room audio into that conversation.
                if self.remote_mic_active:
                    continue
                # Keep the physical mic gate synchronized with model playback.
                # The setter is edge-triggered, so repeated frames do not reset
                # calibration while the same speaking state continues.
                self._media_mic_gate.set_assistant_playing(st == ChatState.SPEAKING)
                prev_open = gate_was_open
                gated_chunks = self._media_mic_gate.feed(chunk)
                gate_was_open = self._media_mic_gate.is_open
                # Voice-focus duck: gate just opened (transition closed→open).
                if not prev_open and gate_was_open and not self._media_mic_gate.assistant_playing:
                    asyncio.create_task(self._fire_voice_duck())
                for session_chunk in gated_chunks:
                    if st == ChatState.SPEAKING:
                        if self._rms(session_chunk) > self.settings.interrupt_rms_threshold:
                            self._interrupt_loud_chunks += 1
                        else:
                            self._interrupt_loud_chunks = 0
                        # Require sustained speech (~240 ms), not a click or a
                        # single speaker-echo spike, before interrupting.
                        if self._interrupt_loud_chunks >= 3:
                            self.clear_playback()
                            self.on_interrupt()
                            self._interrupt_loud_chunks = 0
                            break
                        # While assistant output is active, microphone audio is
                        # only a local barge-in signal. Forwarding it to the live
                        # provider lets speaker leakage become a fake user turn
                        # and can make the model interrupt its own response.
                        continue
                    else:
                        self._interrupt_loud_chunks = 0
                    # Buffer speech even while the provider connects. Otherwise
                    # the first words after "Hey Jarvis" disappear on a slow
                    # network connection.
                    self._offer(self.audio_in, session_chunk)
                continue

            # Sleeping / local-only: run the wake detector.
            # Skip if the remote mic is active: run_remote_wake() owns the
            # model for that browser and runs it on incoming PCM instead.
            if self._remote_wake_streaming():
                self._wake_batch.clear()
                continue

            gate_was_open = False  # not in a session; reset gate tracking

            if self._wake_model is not None and _AUDIO_OK:
                scores = await self._run_host_wake_predict(chunk)
                if scores is None:
                    continue
                if scores and max(scores.values()) >= self.settings.wake_threshold:
                    if not self._wake_gate_open():
                        continue
                    st = self.state.raw_state  # refresh: may have changed during inference
                    wake_scores_needed -= 1
                    if wake_scores_needed <= 0:
                        wake_scores_needed = 1
                        self._wake_model.reset()
                        local_capture = (
                            st == ChatState.LOCAL_ONLY
                            and self.transcriber is not None
                            and getattr(self.transcriber, "available", False)
                            and self.on_local_command is not None
                        )
                        self.bus.publish(
                            "wake_word", mode="capture" if local_capture else "cloud"
                        )
                        if local_capture:
                            # offline: record the utterance, transcribe locally
                            self._capture = []
                            self._capture_silent = 0
                        else:
                            # Wake confirmed: duck then pause companion.
                            asyncio.create_task(self._fire_voice_duck())
                            asyncio.create_task(self._fire_voice_pause())
                            self.on_wake()

    def _prepare_wake_input(self, chunk: bytes) -> bytes | None:
        """Return audio ready for one wake-model call.

        Active voice streaming never comes through this helper.  In the
        low-power profile, combine two 80 ms callback blocks so openWakeWord
        can calculate their shared features in one call.  Its predictor still
        scores both internal frames and returns their maximum, preserving the
        normal detection threshold with only an extra <=80 ms scheduling
        delay.  The non-low-power profile retains the original 80 ms cadence.
        """
        if not self.settings.low_power:
            self._wake_batch.clear()
            return chunk

        self._wake_batch.append(chunk)
        if len(self._wake_batch) < LOW_POWER_WAKE_BATCH_CHUNKS:
            return None
        ready = b"".join(self._wake_batch)
        self._wake_batch.clear()
        return ready

    def _wake_gate_open(self) -> bool:
        """May a wake hit act RIGHT NOW? Re-checked after inference: predict
        runs off-loop, so a mute click or a session start can land while it
        computes. The emergency mute must win that race."""
        if self._stop.is_set() or self.state.muted:
            return False
        return self.state.raw_state not in (
            ChatState.LISTENING,
            ChatState.SPEAKING,
            ChatState.CONNECTING,
        )

    def _capture_step(self, chunk: bytes) -> list[bytes] | None:
        """Accumulate one 80 ms chunk; returns the recording when done."""
        assert self._capture is not None
        self._capture.append(chunk)
        silence_floor = max(250, self.settings.interrupt_rms_threshold // 3)
        if self._rms(chunk) < silence_floor:
            self._capture_silent += 1
        else:
            self._capture_silent = 0
        long_enough = len(self._capture) >= 10            # ~0.8 s recorded
        ended = long_enough and self._capture_silent >= 10  # ~0.8 s of silence
        timed_out = len(self._capture) >= 100             # 8 s hard cap
        if ended or timed_out:
            captured = self._capture
            self._capture = None
            self._capture_silent = 0
            return captured
        return None

    async def _finish_local_capture(self, pcm: bytes) -> None:
        text = ""
        if self.transcriber is not None:
            try:
                text = await asyncio.to_thread(self.transcriber.transcribe, pcm, IN_RATE)
            except Exception as exc:
                log.warning("local transcription failed: %s", type(exc).__name__)
        if self.on_local_command is not None:
            try:
                await self.on_local_command(text)
            except Exception as exc:
                log.warning("local command handling failed: %s", type(exc).__name__)

    @staticmethod
    def _rms(chunk: bytes) -> float:
        if not _AUDIO_OK:
            return 0.0
        arr = np.frombuffer(chunk, dtype=np.int16)
        if arr.size == 0:
            return 0.0
        return float(np.sqrt(np.mean(arr.astype(np.float64) ** 2)))

    @staticmethod
    def _offer(q: asyncio.Queue, item: bytes) -> None:
        if q.full():
            try:
                q.get_nowait()
            except asyncio.QueueEmpty:
                pass
        try:
            q.put_nowait(item)
        except asyncio.QueueFull:
            pass
