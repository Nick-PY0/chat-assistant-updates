"""Automatic updates.

You publish new versions at a fixed "update link" (a small JSON manifest);
every Chat install checks it quietly, downloads the new zip, and stages it
in the data folder. The staged copy is applied by the launcher on the NEXT
start -- files are never swapped underneath a running process.

Manifest format (host it anywhere that serves raw files, e.g. a GitHub
repository or release):

    {
      "version": "1.2.0",
      "zip_url": "https://github.com/you/chat/releases/download/v1.2.0/chat-assistant.zip",
      "notes": "What changed (optional)",
      "sha256": "<hex fingerprint of the zip>",
      "sig": "<base64 Ed25519 signature over version + sha256 + notes>"
    }

The zip must contain the app folder (run_chat.py at the top level, or a
single wrapper folder around it; for exe builds, the folder with Chat.exe).

Updates are refused unless the manifest carries a valid signature from the
publisher's key (deployment/release/sign_manifest.py makes one). The
zip_url itself is deliberately NOT signed: the sha256 pins the exact bytes,
so mirroring the zip elsewhere is harmless while changing its content is
not. People hosting their own unsigned link can turn the requirement off
in Settings.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import inspect
import json
import logging
import os
import shutil
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any, Callable

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.db import Database
from chat_core.version import APP_VERSION, is_newer, parse_version
from apps.updater.state import atomic_write_state, load_state, now_iso

log = logging.getLogger("updater")

MAX_ZIP_BYTES = 300 * 1024 * 1024
CHECK_INTERVAL_SECONDS = 6 * 3600
FIRST_CHECK_DELAY_SECONDS = 45
MARKERS = ("run_chat.py", "Chat.exe")  # what a real Chat build contains
OPERATION_PHASES = {
    "checking",
    "downloading",
    "verifying",
    "extracting",
    "staged",
    "restarting",
    "applying",
    "complete",
    "failed",
    "rolled_back",
    "idle",
}
PROGRESS_WRITE_INTERVAL = 0.2

# The publisher's Ed25519 public key. The matching private key never leaves
# the machine that publishes releases; every install uses this to confirm an
# update really came from the publisher before staging a single byte.
UPDATE_PUBLIC_KEY_HEX = "5c8494033508642010da1e8978f9c86fb7ee12579d88e1d27ae9816b6fc9647f"


class Updater:
    def __init__(
        self,
        settings: Settings,
        db: Database,
        bus: EventBus,
        on_restart: Callable[[], Any] | None = None,
        *,
        restart_callback: Callable[[], Any] | None = None,
    ) -> None:
        self.settings = settings
        self.db = db
        self.bus = bus
        self.current_version = APP_VERSION
        self.latest_seen: str | None = None
        self.last_check: str | None = None
        self.last_error: str = ""
        self.on_restart = on_restart or restart_callback
        self._stop = asyncio.Event()
        self._checking = asyncio.Lock()
        self._operation_task: asyncio.Task | None = None
        self._progress_last_persist = 0.0
        self._progress_total: int | None = None
        self._state: dict[str, Any] = {}
        self._operation: dict[str, Any] | None = None
        self._failed_stage_target: str | None = None
        self._state_persisted = False
        self._load_persisted_state()

    # -- paths -----------------------------------------------------------
    @property
    def updates_dir(self) -> Path:
        return self.settings.data_path / "updates"

    @property
    def pending_dir(self) -> Path:
        return self.updates_dir / "pending"

    def pending_version(self) -> str | None:
        meta = self.updates_dir / "pending.json"
        if not meta.exists() or not self.pending_dir.exists():
            return None
        try:
            return str(json.loads(meta.read_text()).get("version")) or None
        except (json.JSONDecodeError, OSError):
            return None

    def _load_persisted_state(self) -> None:
        self._state = load_state(self.updates_dir)
        self.latest_seen = self._state.get("latest_seen")
        self.last_check = self._state.get("last_check")
        self.last_error = self._state.get("error", "")
        operation = self._state.get("operation")
        self._operation = dict(operation) if isinstance(operation, dict) else None
        if self._operation:
            phase = self._operation.get("phase")
            target = str(self._operation.get("target_version") or "").strip()
            # No asyncio task survives a hard process exit.  Do not let a
            # persisted in-flight network/extraction phase permanently trip
            # start_operation's dedupe guard; surface an interrupted failure
            # and let the next explicit request retry it.
            if phase in {"checking", "downloading", "verifying", "extracting"}:
                self._operation["phase"] = "failed"
                self._operation["message"] = "operation interrupted; retry available"
                self._operation["error"] = "update operation interrupted"
                self.last_error = self._operation["error"]
                self._persist_state()
            elif phase == "restarting":
                # A normal restart still has a pending tree for the launcher.
                # If it is gone and this process is not already the target
                # version, the restart intent cannot complete safely.
                if target and target != self.current_version and not self.pending_version():
                    self._operation["phase"] = "failed"
                    self._operation["message"] = "restart interrupted; retry available"
                    self._operation["error"] = "update restart was interrupted"
                    self.last_error = self._operation["error"]
                    self._persist_state()
            elif phase == "applying":
                # ``run_chat.py`` writes applying immediately before a source
                # swap.  A pending tree means the launcher can retry its
                # transaction; no tree plus a mismatched version means a hard
                # death occurred after intent was recorded.
                if target and target != self.current_version and not self.pending_version():
                    self._operation["phase"] = "failed"
                    self._operation["message"] = "application interrupted; retry available"
                    self._operation["error"] = "update application was interrupted"
                    self.last_error = self._operation["error"]
                    self._persist_state()
        if self._operation and self._operation.get("phase") in {"failed", "rolled_back"}:
            target = str(self._operation.get("target_version") or "").strip()
            error = str(self._operation.get("error") or "").lower()
            # Rollback/dependency failures intentionally block an endless
            # launcher retry loop.  Interrupted downloads are explicitly
            # retryable and therefore do not set this guard.
            if self._operation.get("phase") == "rolled_back" or "dependency" in error:
                self._failed_stage_target = target or None

    def _persist_state(self) -> bool:
        self._state.update(
            latest_seen=self.latest_seen,
            last_check=self.last_check,
            error=self.last_error,
            operation=self._operation,
        )
        try:
            atomic_write_state(self.updates_dir, self._state)
            self._state_persisted = True
            return True
        except Exception as exc:
            # A read-only data folder must not make an otherwise valid update
            # fail.  The in-memory status remains useful to the dashboard.
            self._state_persisted = False
            log.warning("could not persist updater state: %s", type(exc).__name__)
            return False

    def _new_operation(
        self,
        *,
        phase: str,
        target_version: str | None = None,
        automatic_restart: bool = False,
        message: str = "",
    ) -> dict[str, Any]:
        now = now_iso()
        self._operation = {
            "id": uuid.uuid4().hex,
            "phase": phase,
            "target_version": target_version,
            "bytes_received": 0,
            "total_bytes": None,
            "percent": None,
            "message": message,
            "error": "",
            "started_at": now,
            "updated_at": now,
            "automatic_restart": bool(automatic_restart),
        }
        self._state_persisted = bool(self._persist_state())
        return self._operation

    def _set_operation(
        self,
        phase: str,
        *,
        target_version: str | None = None,
        message: str | None = None,
        error: str | None = None,
        bytes_received: int | None = None,
        total_bytes: int | None = None,
        percent: float | None = None,
        persist: bool = True,
    ) -> None:
        if phase not in OPERATION_PHASES:
            raise ValueError(f"unknown updater operation phase: {phase}")
        if self._operation is None:
            self._new_operation(phase=phase, target_version=target_version)
        assert self._operation is not None
        self._operation["phase"] = phase
        if target_version is not None:
            self._operation["target_version"] = str(target_version)[:256]
        if message is not None:
            self._operation["message"] = str(message)[:4096]
        if error is not None:
            self._operation["error"] = str(error)[:4096]
        if bytes_received is not None:
            self._operation["bytes_received"] = max(0, int(bytes_received))
        if total_bytes is not None or phase == "downloading":
            self._operation["total_bytes"] = (
                None if total_bytes is None else max(0, int(total_bytes))
            )
            if phase == "downloading":
                self._progress_total = None
        if percent is not None or phase == "downloading":
            self._operation["percent"] = (
                None if percent is None else max(0.0, min(100.0, float(percent)))
            )
        self._operation["updated_at"] = now_iso()
        if persist:
            self._state_persisted = bool(self._persist_state())
        self.bus.publish("update_status", **self._operation)

    def _persist_progress(
        self, received: int, total: int | None, *, force: bool = False
    ) -> None:
        if self._operation is None:
            return
        percent = None if total in (None, 0) else min(100.0, received * 100.0 / total)
        self._operation["bytes_received"] = max(0, received)
        self._operation["total_bytes"] = total
        self._operation["percent"] = percent
        self._operation["updated_at"] = now_iso()
        now = time.monotonic()
        if force or now - self._progress_last_persist >= PROGRESS_WRITE_INTERVAL:
            self._progress_last_persist = now
            self._state_persisted = bool(self._persist_state())
            self.bus.publish("update_status", **self._operation)

    def status(self) -> dict:
        return {
            "current": self.current_version,
            "latest_seen": self.latest_seen,
            "pending": self.pending_version(),
            "last_check": self.last_check,
            "error": self.last_error,
            "auto_update": self.settings.auto_update,
            "configured": bool(self.settings.update_url.strip()),
            "operation": dict(self._operation) if self._operation else None,
        }

    # -- background loop ---------------------------------------------------
    async def run(self) -> None:
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=FIRST_CHECK_DELAY_SECONDS)
            return
        except asyncio.TimeoutError:
            pass
        while not self._stop.is_set():
            if self.settings.auto_update and self.settings.update_url.strip():
                try:
                    await self.start_operation(install=True)
                except Exception as exc:  # network problems are normal; stay quiet
                    log.debug("update check failed: %s", type(exc).__name__)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=CHECK_INTERVAL_SECONDS)
                return
            except asyncio.TimeoutError:
                continue

    async def stop(self) -> None:
        self._stop.set()
        task = self._operation_task
        if task is not None and not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            if self._operation and self._operation.get("phase") not in {
                "complete",
                "failed",
                "rolled_back",
            }:
                self._finish_operation("failed", error="update operation cancelled")

    async def start_operation(self, *, install: bool = False) -> dict:
        """Queue one update operation and return its current status.

        Work is deliberately scheduled rather than awaited.  This keeps a
        phone request responsive while a manifest or a large archive is being
        fetched.  A single task owns the operation lock, so simultaneous
        requests observe one operation instead of downloading the same zip.
        """
        if self._operation_task is not None and not self._operation_task.done():
            return self.status()
        if self._operation and self._operation.get("phase") in {
            "checking",
            "downloading",
            "verifying",
            "extracting",
            "restarting",
            "applying",
        }:
            return self.status()
        if install and self._failed_stage_target:
            if self.pending_version() == self._failed_stage_target:
                return self.status()
        automatic_restart = bool(install)
        self._new_operation(
            phase="checking", automatic_restart=automatic_restart
        )
        self._operation_task = asyncio.create_task(
            self._operation_worker(install), name="update-operation"
        )
        return self.status()

    async def _operation_worker(self, install: bool) -> None:
        try:
            await self._check_and_stage(
                automatic_restart=install, install=install, operation_owned=True
            )
        except asyncio.CancelledError:
            self._finish_operation("failed", error="update operation cancelled")
            raise
        except Exception as exc:
            message = str(exc) or f"update operation failed ({type(exc).__name__})"
            self.last_error = message
            self._finish_operation("failed", error=message)
            log.warning("update operation failed: %s", type(exc).__name__)

    def _finish_operation(
        self,
        phase: str,
        *,
        target_version: str | None = None,
        error: str = "",
        message: str = "",
    ) -> None:
        if error:
            self.last_error = error
        self._set_operation(
            phase,
            target_version=target_version,
            error=error,
            message=message,
            persist=True,
        )

    async def _call_restart(self) -> None:
        if self.on_restart is None:
            return
        result = self.on_restart()
        if inspect.isawaitable(result):
            await result

    # -- the check ---------------------------------------------------------
    async def check_now(self) -> dict:
        """Backward-compatible synchronous stage-only check.

        Older dashboard clients await this method and expect the zip to be
        staged before the response.  New clients use ``start_operation`` so a
        request never waits on the network.
        """
        task = self._operation_task
        if task is not None and not task.done():
            await asyncio.shield(task)
            return self.status()
        async with self._checking:
            if self._operation is None or self._operation.get("phase") not in {
                "checking",
                "downloading",
                "verifying",
                "extracting",
            }:
                self._new_operation(phase="checking", automatic_restart=False)
            await self._check_and_stage(operation_owned=True, install=False)
            return self.status()

    async def _check_and_stage(
        self,
        *,
        automatic_restart: bool = False,
        install: bool = False,
        operation_owned: bool = False,
    ) -> None:
        self.last_error = ""
        from chat_core.models.credentials import iso, utcnow

        self.last_check = iso(utcnow())
        self._persist_state()

        # A verified staged copy is the source of truth.  Installing it must
        # not redownload the same archive after a process/reconnect boundary.
        staged = self.pending_version()
        if install and staged and self._pending_is_safe_verified(staged):
            if self._failed_stage_target and staged == self._failed_stage_target:
                self._finish_operation(
                    "failed",
                    target_version=staged,
                    error="previous update apply failed; staged update was not retried",
                )
                return
            self.latest_seen = staged
            self._set_operation("staged", target_version=staged, message="update staged")
            await self._request_automatic_restart(staged)
            return

        self._set_operation("checking", message="checking for updates")
        url = self.settings.update_url.strip()
        if not url:
            self.last_error = "no update link configured"
            self._finish_operation("failed", error=self.last_error)
            return
        try:
            manifest = await self._http_get_json(url)
        except Exception as exc:
            self.last_error = f"could not fetch update link ({type(exc).__name__})"
            self._finish_operation("failed", error=self.last_error)
            return

        version = str(manifest.get("version", "")).strip()
        zip_url = str(manifest.get("zip_url", "")).strip()
        notes = str(manifest.get("notes", ""))[:500]
        self.latest_seen = version or None
        if not version or not zip_url:
            self.last_error = "update manifest is missing version/zip_url"
            self._finish_operation("failed", error=self.last_error)
            return
        if parse_version(version) is None:
            self.last_error = "update manifest has an invalid version"
            self._finish_operation(
                "failed", target_version=version, error=self.last_error
            )
            return
        if not is_newer(version, self.current_version):
            self._finish_operation("idle", target_version=version, message="already up to date")
            return
        if self.pending_version() == version:
            self._set_operation("staged", target_version=version, message="update staged")
            if install:
                await self._request_automatic_restart(version)
            return

        expected_sha = str(manifest.get("sha256", "")).strip().lower()
        if getattr(self.settings, "update_require_signature", True):
            problem = self._verify_manifest(manifest)
            if problem:
                self.last_error = problem
                await self._db_log("WARNING", f"refused update {version}: {problem}")
                self._finish_operation("failed", target_version=version, error=problem)
                return

        try:
            await self._download_and_stage(version, zip_url, notes, expected_sha)
        except ValueError as exc:
            self.last_error = str(exc) or "download failed"
            log.warning("staging %s refused: %s", version, exc)
            self._finish_operation("failed", target_version=version, error=self.last_error)
            return
        except Exception as exc:
            self.last_error = f"download failed ({type(exc).__name__})"
            log.warning("staging %s failed: %s", version, type(exc).__name__)
            self._finish_operation("failed", target_version=version, error=self.last_error)
            return

        await self._db_log("INFO", f"version {version} downloaded; restart to apply")
        if self._failed_stage_target and self._failed_stage_target != version:
            self._failed_stage_target = None
        self._set_operation("staged", target_version=version, message="update staged")
        self.bus.publish("update_status", staged=version)
        if install:
            await self._request_automatic_restart(version)

    async def _request_automatic_restart(self, version: str) -> None:
        self._set_operation(
            "restarting",
            target_version=version,
            message="restarting to apply update",
        )
        if not self._state_persisted:
            # Never shut down into an unrecorded restart intent.  The staged
            # tree is safe to keep, and a later explicit request can retry
            # once the data directory is writable again.
            self._finish_operation(
                "failed",
                target_version=version,
                error="could not persist restart intent; restart not attempted",
            )
            return
        await self._call_restart()

    async def _db_log(self, level: str, message: str) -> None:
        try:
            await self.db.log(level, "updater", message)
        except Exception:
            log.debug("could not write updater log", exc_info=True)

    def _pending_is_safe_verified(self, version: str) -> bool:
        """Validate an existing stage without requiring another download.

        ``pending.json`` is intentionally the old two-field layout so 1.9.23
        launchers can still consume it.  The archive has already passed hash,
        signature, zip-slip and marker checks before reaching this directory;
        repeat the cheap marker/version checks before an automatic restart.
        """
        try:
            metadata = json.loads(
                (self.updates_dir / "pending.json").read_text(encoding="utf-8")
            )
            if str(metadata.get("version", "")).strip() != str(version).strip():
                return False
        except (OSError, ValueError, TypeError):
            return False
        root = self.pending_dir
        if not root.is_dir() or not any((root / marker).exists() for marker in MARKERS):
            return False
        return True

    def mark_applying(self, version: str | None = None) -> None:
        """Called by the pre-import launcher immediately before source apply."""
        target = version or self.pending_version()
        self._set_operation("applying", target_version=target, message="applying update")

    def mark_rolled_back(self, version: str | None, error: str) -> None:
        self._finish_operation(
            "rolled_back", target_version=version, error=str(error)[:4096]
        )

    def mark_serving_ready(self) -> dict:
        """Finalize a restart only once the new process is actually booted."""
        operation = self._operation
        if not operation or operation.get("phase") not in {"restarting", "applying"}:
            return self.status()
        target = str(operation.get("target_version") or "").strip()
        if target and target != self.current_version:
            self._finish_operation(
                "failed",
                target_version=target,
                error=(
                    f"update version mismatch: expected {target}, "
                    f"running {self.current_version}"
                ),
            )
            return self.status()
        self._finish_operation(
            "complete", target_version=target or None, message="update is running"
        )
        return self.status()

    # -- signature checking -------------------------------------------------
    public_key_hex = UPDATE_PUBLIC_KEY_HEX  # class attr so tests can swap keys

    @staticmethod
    def manifest_payload(manifest: dict) -> bytes:
        """The exact bytes the publisher signs: version + zip sha256 + notes
        in one fixed JSON form (deployment/release/sign_manifest.py imports
        this, so both sides always agree). Signing the notes too means
        nobody who can edit the manifest file -- but not sign it -- can put
        their own words on the user's Updates card."""
        return json.dumps(
            {
                "notes": str(manifest.get("notes", "")),
                "sha256": str(manifest.get("sha256", "")).strip().lower(),
                "version": str(manifest.get("version", "")).strip(),
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")

    def _verify_manifest(self, manifest: dict) -> str:
        """Empty string when the signature is valid; otherwise the reason."""
        sha256 = str(manifest.get("sha256", "")).strip().lower()
        sig_b64 = str(manifest.get("sig", "")).strip()
        if not sha256 or not sig_b64:
            return "update is not signed (manifest has no sha256/sig)"
        try:
            signature = base64.b64decode(sig_b64, validate=True)
        except (ValueError, binascii.Error):
            return "update signature is unreadable"
        try:
            key = ed25519.Ed25519PublicKey.from_public_bytes(
                bytes.fromhex(self.public_key_hex)
            )
            key.verify(signature, self.manifest_payload(manifest))
        except InvalidSignature:
            return "update signature does not match -- refusing it"
        except (ValueError, TypeError):
            return "update signature could not be checked"
        return ""

    @staticmethod
    def _sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                digest.update(chunk)
        return digest.hexdigest()

    # -- helpers (small and overridable for tests) -------------------------
    async def _http_get_json(self, url: str) -> dict:
        async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            return resp.json()

    async def _http_download(self, url: str, dest: Path) -> None:
        async with httpx.AsyncClient(timeout=None, follow_redirects=True) as client:
            async with client.stream("GET", url) as resp:
                resp.raise_for_status()
                total_header = resp.headers.get("content-length")
                try:
                    total = int(total_header) if total_header else None
                except (TypeError, ValueError):
                    total = None
                if total is not None and (total < 0 or total > MAX_ZIP_BYTES):
                    raise ValueError("update zip too large")
                self._progress_total = total
                self._persist_progress(0, total, force=True)
                size = 0
                with dest.open("wb") as fh:
                    async for chunk in resp.aiter_bytes(65536):
                        size += len(chunk)
                        if size > MAX_ZIP_BYTES:
                            raise ValueError("update zip too large")
                        fh.write(chunk)
                        self._persist_progress(size, total)
                self._persist_progress(size, total, force=True)

    async def _download_and_stage(
        self, version: str, zip_url: str, notes: str, expected_sha: str = ""
    ) -> None:
        self.updates_dir.mkdir(parents=True, exist_ok=True)
        zip_path = self.updates_dir / "download.zip"
        extract_dir = self.updates_dir / "extract"
        staged_dir = self.updates_dir / ".pending-new"
        old_pending_dir = self.updates_dir / ".pending-old"
        old_meta = self.updates_dir / "pending.json"
        old_meta_bytes: bytes | None = None
        if old_meta.exists():
            try:
                old_meta_bytes = old_meta.read_bytes()
            except OSError:
                old_meta_bytes = None
        try:
            self._set_operation(
                "downloading",
                target_version=version,
                message="downloading update",
            )
            await self._http_download(zip_url, zip_path)
            # Test/custom transports may implement the legacy two-argument
            # downloader themselves.  Still expose an accurate final byte
            # count even when they do not call our progress hook.
            try:
                downloaded = zip_path.stat().st_size
            except OSError:
                downloaded = 0
            self._persist_progress(downloaded, self._progress_total, force=True)
            self._set_operation("verifying", target_version=version, message="verifying update")
            if expected_sha:
                actual = await asyncio.to_thread(self._sha256_file, zip_path)
                if actual != expected_sha:
                    raise ValueError(
                        "downloaded update does not match its signed fingerprint"
                    )
            self._set_operation("extracting", target_version=version, message="extracting update")
            await asyncio.to_thread(self._extract_safe, zip_path, extract_dir)
            root = self._find_app_root(extract_dir)
            if root is None:
                raise ValueError("zip does not look like a Chat build")
            if staged_dir.exists():
                await asyncio.to_thread(shutil.rmtree, staged_dir, True)
            # Move the completely extracted tree into a sibling first.  The
            # previous pending update is not touched until this point.
            await asyncio.to_thread(shutil.move, str(root), str(staged_dir))
            if old_pending_dir.exists():
                await asyncio.to_thread(shutil.rmtree, old_pending_dir, True)
            if self.pending_dir.exists():
                await asyncio.to_thread(os.replace, self.pending_dir, old_pending_dir)
            try:
                await asyncio.to_thread(os.replace, staged_dir, self.pending_dir)
                pending_payload = json.dumps(
                    {"version": version, "notes": notes},
                    separators=(",", ":"),
                ).encode("utf-8")
                await asyncio.to_thread(self._atomic_bytes, old_meta, pending_payload)
            except Exception:
                # Restore the old directory and metadata if committing the new
                # stage failed.  This is the important distinction from the
                # historic implementation, which deleted a good stage first.
                if self.pending_dir.exists():
                    await asyncio.to_thread(shutil.rmtree, self.pending_dir, True)
                if old_pending_dir.exists():
                    await asyncio.to_thread(os.replace, old_pending_dir, self.pending_dir)
                if old_meta_bytes is not None:
                    await asyncio.to_thread(self._atomic_bytes, old_meta, old_meta_bytes)
                else:
                    old_meta.unlink(missing_ok=True)
                raise
            if old_pending_dir.exists():
                await asyncio.to_thread(shutil.rmtree, old_pending_dir, True)
            # A previous frozen helper may have recorded a failed copy.  A
            # newly verified stage is a fresh transaction and clears that
            # one-shot recovery marker.
            (self.updates_dir / "apply-failed.marker").unlink(missing_ok=True)
        finally:
            zip_path.unlink(missing_ok=True)
            if extract_dir.exists():
                await asyncio.to_thread(shutil.rmtree, extract_dir, True)
            if staged_dir.exists():
                await asyncio.to_thread(shutil.rmtree, staged_dir, True)
            if old_pending_dir.exists():
                # A failed cleanup must not destroy the previous pending
                # version; leave it in place for the next safe startup.
                if not self.pending_dir.exists():
                    try:
                        await asyncio.to_thread(
                            os.replace, old_pending_dir, self.pending_dir
                        )
                    except OSError:
                        pass

    @staticmethod
    def _atomic_bytes(path: Path, payload: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temp.write_bytes(payload)
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)

    @staticmethod
    def _extract_safe(zip_path: Path, extract_dir: Path) -> None:
        """Extract with zip-slip protection: every member must resolve to a
        path INSIDE extract_dir. One bad member = the whole archive is
        rejected (a traversal attempt means the zip is not trustworthy)."""
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        extract_dir.mkdir(parents=True)
        base = extract_dir.resolve()
        expanded_size = 0
        with zipfile.ZipFile(zip_path) as zf:
            for member in zf.infolist():
                name = member.filename
                if not name or name.endswith("/"):
                    continue
                if member.file_size < 0 or member.file_size > MAX_ZIP_BYTES:
                    raise ValueError("update contents are too large")
                expanded_size += member.file_size
                if expanded_size > MAX_ZIP_BYTES:
                    raise ValueError("update contents are too large")
                target = (extract_dir / name).resolve()
                # NOTE: string prefixes are not enough (".../extract_evil"
                # starts with ".../extract"); compare path components.
                if base != target and base not in target.parents:
                    raise ValueError(f"unsafe path in update zip: {name!r}")
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member) as src, target.open("wb") as dst:
                    copied = 0
                    while True:
                        chunk = src.read(1 << 20)
                        if not chunk:
                            break
                        copied += len(chunk)
                        if copied > member.file_size or copied > MAX_ZIP_BYTES:
                            raise ValueError("update contents are too large")
                        dst.write(chunk)

    @staticmethod
    def _find_app_root(extract_dir: Path) -> Path | None:
        for marker in MARKERS:
            if (extract_dir / marker).exists():
                return extract_dir
        subdirs = [p for p in extract_dir.iterdir() if p.is_dir()]
        if len(subdirs) == 1:
            for marker in MARKERS:
                if (subdirs[0] / marker).exists():
                    return subdirs[0]
        return None
