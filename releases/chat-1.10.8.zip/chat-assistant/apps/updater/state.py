"""Small, private, crash-safe state store used by the updater and launcher.

This module intentionally has no application imports.  ``run_chat.py`` uses it
before importing the rest of Chat, while the in-process updater uses it for
progress and restart intent.  The file is deliberately bounded and contains
only status data (never URLs, credentials, or manifest payloads).
"""

from __future__ import annotations

import json
import math
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

STATE_FILENAME = "state.json"
MAX_STATE_BYTES = 64 * 1024
MAX_TEXT = 4096
PHASES = {
    "checking",
    "downloading",
    "verifying",
    "extracting",
    "staged",
    "restarting",
    "applying",
    "complete",
    "failed",
    "rolled_back",
    "idle",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _text(value: Any, limit: int = MAX_TEXT) -> str:
    # Status files are not logs.  Do not persist a manifest URL, query token,
    # or a credential accidentally included in an exception string.
    text = str(value or "")
    text = re.sub(r"https?://[^\s\"']+", "<redacted-url>", text, flags=re.I)
    return text[:limit]


def _operation(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    allowed = (
        "id",
        "phase",
        "target_version",
        "bytes_received",
        "total_bytes",
        "percent",
        "message",
        "error",
        "started_at",
        "updated_at",
        "automatic_restart",
    )
    result: dict[str, Any] = {}
    for key in allowed:
        if key not in value:
            continue
        item = value[key]
        if key in {"id", "phase", "target_version", "message", "error",
                   "started_at", "updated_at"}:
            result[key] = (
                None
                if key == "target_version" and item is None
                else _text(item)
            )
        elif key in {"bytes_received", "total_bytes"}:
            try:
                result[key] = None if item is None else max(0, int(item))
            except (TypeError, ValueError, OverflowError):
                result[key] = None
        elif key == "percent":
            try:
                percent = (
                    None
                    if item is None
                    else max(0.0, min(100.0, float(item)))
                )
                result[key] = percent if percent is None or math.isfinite(percent) else None
            except (TypeError, ValueError, OverflowError):
                result[key] = None
        elif key == "automatic_restart":
            result[key] = bool(item)
    result.setdefault("id", "")
    if result.get("phase") not in PHASES:
        result["phase"] = "idle"
    result.setdefault("target_version", None)
    result.setdefault("bytes_received", 0)
    result.setdefault("total_bytes", None)
    result.setdefault("percent", None)
    result.setdefault("message", "")
    result.setdefault("error", "")
    result.setdefault("started_at", "")
    result.setdefault("updated_at", "")
    result.setdefault("automatic_restart", False)
    return result


def sanitize_state(value: Any) -> dict[str, Any]:
    """Return a bounded, JSON-safe state object.

    Unknown keys are discarded so a future manifest field cannot accidentally
    turn the local state file into a cache of untrusted/secret data.
    """
    source = value if isinstance(value, dict) else {}
    operation = _operation(source.get("operation"))
    result: dict[str, Any] = {
        "latest_seen": _text(source.get("latest_seen"), 256) or None,
        "last_check": _text(source.get("last_check"), 128) or None,
        "error": _text(source.get("error")),
        "operation": operation,
    }
    if len(json.dumps(result, separators=(",", ":")).encode("utf-8")) > MAX_STATE_BYTES:
        result["error"] = result["error"][:512]
        if result["operation"]:
            result["operation"]["message"] = result["operation"].get("message", "")[:512]
            result["operation"]["error"] = result["operation"].get("error", "")[:512]
    return result


def load_state(updates_dir: Path) -> dict[str, Any]:
    """Load state, accepting an interrupted/legacy write as empty state."""
    path = updates_dir / STATE_FILENAME
    try:
        if path.stat().st_size > MAX_STATE_BYTES:
            return {}
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}
    return sanitize_state(value)


def atomic_write_state(updates_dir: Path, value: dict[str, Any]) -> None:
    """Atomically replace the bounded state file and fsync its directory."""
    updates_dir.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(
        sanitize_state(value), sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    if len(payload) > MAX_STATE_BYTES:
        raise ValueError("updater state is too large")
    fd, temp_name = tempfile.mkstemp(prefix=".state-", suffix=".tmp", dir=updates_dir)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temp_name, updates_dir / STATE_FILENAME)
        try:
            directory_fd = os.open(updates_dir, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            # Windows does not permit opening directories this way.  The
            # replace above is still atomic there.
            pass
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
