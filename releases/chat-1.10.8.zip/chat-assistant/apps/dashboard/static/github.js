document.addEventListener("DOMContentLoaded", () => {
  const el = (id) => document.getElementById(id);
  
  const authStatus = el("gh-auth-status");
  const unauthPanel = el("gh-unauth");
  const configPanel = el("gh-config-panel");
  const configForm = el("gh-config-form");
  const deskPanel = el("gh-desk");
  const deskTitle = el("gh-desk-title");
  const deskDesc = el("gh-desk-desc");
  const pathsInput = el("gh-paths");
  const reviewBtn = el("gh-review-btn");
  const deskError = el("gh-desk-error");
  
  const reviewPanel = el("gh-review");
  const revDir = el("gh-rev-dir");
  const revTarget = el("gh-rev-target");
  const diffContainer = el("gh-diff-container");
  const confirmCheck = el("gh-confirm-check");
  const confirmLabel = el("gh-confirm-label");
  const publishFields = el("gh-publish-fields");
  const commitMsg = el("gh-commit-msg");
  const execBtn = el("gh-exec-btn");
  const cancelBtn = el("gh-cancel-btn");
  const execError = el("gh-exec-error");
  
  const checkpointPanel = el("gh-checkpoint-panel");
  const checkpointIdSpan = el("gh-checkpoint-id");
  const restoreBtn = el("gh-restore-btn");
  const restoreError = el("gh-restore-error");

  let currentMode = "publish";
  let currentReview = null;

  async function loadStatus() {
    try {
      const st = await api("/api/github/status");
      if (!st.available) {
        authStatus.textContent = st.error
          ? "GitHub unavailable: " + st.error
          : "GitHub integration is unavailable.";
        authStatus.className = "status-pill unavailable";
        return;
      }
      if (!st.authenticated) {
        authStatus.textContent = "Not authenticated";
        authStatus.className = "status-pill disabled";
        unauthPanel.hidden = false;
        return;
      }
      authStatus.textContent = "Authenticated as " + st.login;
      authStatus.className = "status-pill active";
      
      configPanel.hidden = false;
      if (st.config) {
        el("gh-repo").value = st.config.repository;
        el("gh-branch").value = st.config.branch;
        el("gh-prefix").value = st.config.remote_prefix || "";
        deskPanel.hidden = false;
      }
      
      if (st.latest_checkpoint) {
        checkpointPanel.hidden = false;
        checkpointIdSpan.textContent = st.latest_checkpoint;
      } else {
        checkpointPanel.hidden = true;
      }
    } catch (e) {
      authStatus.textContent = "Error loading status";
      authStatus.className = "status-pill down";
    }
  }

  configForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = el("gh-config-save");
    const msg = el("gh-config-msg");
    btn.disabled = true;
    msg.textContent = "Saving...";
    msg.className = "note";
    try {
      const data = {
        repository: el("gh-repo").value.trim(),
        branch: el("gh-branch").value.trim(),
        remote_prefix: el("gh-prefix").value.trim()
      };
      await api("/api/github/config", "POST", data);
      msg.textContent = "Saved.";
      msg.className = "okmsg";
      await loadStatus();
    } catch (err) {
      msg.textContent = err.message;
      msg.className = "error";
    } finally {
      btn.disabled = false;
      setTimeout(() => { if (msg.textContent === "Saved.") msg.textContent = ""; }, 3000);
    }
  });

  document.querySelectorAll(".gh-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      if (reviewPanel.hidden === false) {
        if (!confirm("Discard current review?")) return;
        reviewPanel.hidden = true;
        deskPanel.hidden = false;
      }
      document.querySelectorAll(".gh-tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      currentMode = tab.dataset.mode;
      
      if (currentMode === "publish") {
        deskTitle.textContent = "Prepare Publish";
        deskDesc.textContent = "Enter up to 12 file paths to publish to your remote repository.";
        reviewBtn.textContent = "Review Changes";
      } else {
        deskTitle.textContent = "Prepare Sync";
        deskDesc.textContent = "Enter up to 12 file paths to pull from your remote repository.";
        reviewBtn.textContent = "Review Sync";
      }
      pathsInput.value = "";
      deskError.textContent = "";
    });
  });

  reviewBtn.addEventListener("click", async () => {
    const paths = pathsInput.value.split("\n").map(p => p.trim()).filter(Boolean);
    if (!paths.length) {
      deskError.textContent = "Please enter at least one file path.";
      return;
    }
    if (paths.length > 12) {
      deskError.textContent = "Maximum 12 files allowed per operation.";
      return;
    }
    
    reviewBtn.disabled = true;
    deskError.textContent = "";
    try {
      const rev = await api("/api/github/review", "POST", {
        direction: currentMode,
        paths: paths
      });
      currentReview = rev;
      showReview(rev);
    } catch (err) {
      if (err.message.includes("409") || err.message.toLowerCase().includes("conflict")) {
        deskError.textContent = "Conflict detected (409). You cannot publish or sync these paths because of diverging history. Force-pushes are not permitted.";
      } else {
        deskError.textContent = err.message;
      }
    } finally {
      reviewBtn.disabled = false;
    }
  });

  function showReview(rev) {
    deskPanel.hidden = true;
    reviewPanel.hidden = false;
    
    revDir.textContent = rev.direction;
    revTarget.textContent = `${rev.repository} @ ${rev.branch} (Head: ${rev.head ? rev.head.substring(0, 7) : "unknown"})`;
    
    diffContainer.replaceChildren();
    if (rev.changes.length === 0) {
      const p = document.createElement("p");
      p.className = "note";
      p.textContent = "No changes detected for the requested paths.";
      diffContainer.appendChild(p);
    }
    
    rev.changes.forEach(c => {
      const item = document.createElement("div");
      item.className = "gh-diff-item";
      
      const head = document.createElement("div");
      head.className = "gh-diff-header";
      
      const pName = document.createElement("span");
      pName.textContent = c.path;
      
      const st = document.createElement("span");
      st.className = `gh-diff-status ${c.status}`;
      st.textContent = c.status;
      
      head.appendChild(pName);
      head.appendChild(st);
      item.appendChild(head);
      
      if (c.diff) {
        const body = document.createElement("div");
        body.className = "gh-diff-body";
        const lines = c.diff.split("\n");
        for (const line of lines) {
          const lDiv = document.createElement("div");
          lDiv.className = "gh-diff-line";
          if (line.startsWith("+")) lDiv.classList.add("add");
          else if (line.startsWith("-")) lDiv.classList.add("del");
          lDiv.textContent = line || " ";
          body.appendChild(lDiv);
        }
        item.appendChild(body);
      }
      
      diffContainer.appendChild(item);
    });
    
    const hasChanges = rev.changes.length > 0;
    confirmCheck.checked = false;
    confirmCheck.disabled = !hasChanges;
    execBtn.disabled = true;
    execError.textContent = "";
    
    confirmLabel.textContent = hasChanges
      ? `I confirm I want to ${rev.direction} these changes.`
      : "There are no changes to execute.";
    
    if (rev.direction === "publish") {
      publishFields.hidden = false;
      commitMsg.value = `Update ${rev.changes.length} file(s)`;
      execBtn.textContent = "Publish Commit";
    } else {
      publishFields.hidden = true;
      execBtn.textContent = "Sync Files";
    }
  }

  confirmCheck.addEventListener("change", () => {
    execBtn.disabled = !confirmCheck.checked;
  });

  cancelBtn.addEventListener("click", () => {
    reviewPanel.hidden = true;
    deskPanel.hidden = false;
    currentReview = null;
  });

  execBtn.addEventListener("click", async () => {
    if (!currentReview || !confirmCheck.checked) return;
    
    execBtn.disabled = true;
    cancelBtn.disabled = true;
    execError.textContent = "";
    
    try {
      if (currentReview.direction === "publish") {
        await api("/api/github/publish", "POST", {
          review_id: currentReview.review_id,
          message: commitMsg.value.trim() || "Publish update",
          confirm_repository: currentReview.repository,
          confirm_branch: currentReview.branch
        });
      } else {
        await api("/api/github/sync", "POST", {
          review_id: currentReview.review_id,
          confirm_repository: currentReview.repository,
          confirm_branch: currentReview.branch
        });
      }
      
      alert(currentReview.direction === "publish"
        ? "Commit published successfully."
        : "Files synced successfully.");
      reviewPanel.hidden = true;
      deskPanel.hidden = false;
      pathsInput.value = "";
      await loadStatus();
    } catch (err) {
      execError.textContent = err.message;
    } finally {
      execBtn.disabled = false;
      cancelBtn.disabled = false;
    }
  });

  restoreBtn.addEventListener("click", async () => {
    const id = checkpointIdSpan.textContent;
    if (!id) return;
    if (!confirm(`Are you sure you want to restore checkpoint ${id}? This will overwrite current files.`)) return;
    
    restoreBtn.disabled = true;
    restoreError.textContent = "";
    try {
      await api("/api/github/restore", "POST", { checkpoint_id: id });
      alert("Checkpoint restored successfully.");
      await loadStatus();
    } catch (err) {
      restoreError.textContent = err.message;
    } finally {
      restoreBtn.disabled = false;
    }
  });

  loadStatus();
});