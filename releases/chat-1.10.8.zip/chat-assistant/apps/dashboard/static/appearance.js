(function() {
  const APPEARANCE_KEY = "nexa-appearance";
  const NEXA_THEME_KEY = "nexa-theme";
  const CLASSIC_THEME_KEY = "chat-theme";
  const MODES = ["nexa", "classic"];
  const THEMES = ["light", "dark"];
  const DEFAULT_MODE = "nexa";
  const DEFAULT_THEMES = { nexa: "dark", classic: "light" };

  // Keep the active values in memory as well as in storage.  Private browsing,
  // sandboxed iframes, and some hardened browsers can throw on both reads and
  // writes to localStorage.  Appearance is still useful for the current page
  // in those cases; it simply cannot be promised on the next page load.
  function normalizeMode(value) {
    return MODES.includes(value) ? value : DEFAULT_MODE;
  }

  function normalizeTheme(value, mode) {
    const normalizedMode = normalizeMode(mode);
    return THEMES.includes(value) ? value : DEFAULT_THEMES[normalizedMode];
  }

  function readStorage(key) {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function writeStorage(key, value) {
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (e) {
      return false;
    }
  }

  let activeMode = normalizeMode(readStorage(APPEARANCE_KEY));
  const activeThemes = {
    nexa: normalizeTheme(readStorage(NEXA_THEME_KEY), "nexa"),
    classic: normalizeTheme(readStorage(CLASSIC_THEME_KEY), "classic"),
  };

  function getAppearance() {
    return activeMode;
  }

  function getTheme(mode) {
    const normalizedMode = normalizeMode(mode === undefined ? activeMode : mode);
    return activeThemes[normalizedMode];
  }

  function applyAppearance() {
    const mode = activeMode;
    const theme = activeThemes[mode];
    
    document.documentElement.classList.toggle("nexa-mode", mode === "nexa");
    document.documentElement.classList.toggle("classic-mode", mode === "classic");
    document.documentElement.classList.toggle("dark", theme === "dark");
    
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      if (mode === "classic") {
        meta.content = theme === "dark" ? "#0a0e14" : "#f2f4f8";
      } else {
        meta.content = theme === "dark" ? "#030712" : "#f0f4f8";
      }
    }
    
    // Update any active UI toggles
    document.querySelectorAll('.nexa-mode-btn').forEach(btn => {
      btn.classList.toggle('active', mode === 'nexa');
    });
    document.querySelectorAll('.classic-mode-btn').forEach(btn => {
      btn.classList.toggle('active', mode === 'classic');
    });
    document.querySelectorAll('[data-appearance-mode], [data-mode]').forEach(btn => {
      const buttonMode = btn.dataset.appearanceMode || btn.dataset.mode;
      if (MODES.includes(buttonMode)) {
        btn.classList.toggle('active', buttonMode === mode);
        btn.setAttribute('aria-pressed', String(buttonMode === mode));
      }
    });
    document.querySelectorAll('[data-appearance-theme]').forEach(btn => {
      const buttonTheme = btn.dataset.appearanceTheme;
      if (THEMES.includes(buttonTheme)) {
        btn.classList.toggle('active', buttonTheme === theme);
        btn.setAttribute('aria-pressed', String(buttonTheme === theme));
      }
    });
  }

  window.__nexa_appearance = {
    mode: getAppearance,
    theme: getTheme,
    setMode: function(m) {
      activeMode = normalizeMode(m);
      // Persist only the normalized value. If this fails, activeMode remains
      // authoritative for this document and no false "saved" state is shown.
      writeStorage(APPEARANCE_KEY, activeMode);
      applyAppearance();
      return activeMode;
    },
    setTheme: function(t, mode) {
      const targetMode = normalizeMode(mode === undefined ? activeMode : mode);
      const theme = normalizeTheme(t, targetMode);
      activeThemes[targetMode] = theme;
      writeStorage(targetMode === "classic" ? CLASSIC_THEME_KEY : NEXA_THEME_KEY, theme);
      applyAppearance();
      return theme;
    },
    apply: applyAppearance
  };

  applyAppearance();

  // A storage event is delivered to other same-origin tabs.  Consume the
  // event directly rather than reading and re-writing storage: that keeps
  // tabs in sync without creating a write loop, and also handles a deleted
  // key by returning to that mode's safe default.
  window.addEventListener('storage', (event) => {
    if (event.key === null) {
      activeMode = normalizeMode(readStorage(APPEARANCE_KEY));
      activeThemes.nexa = normalizeTheme(readStorage(NEXA_THEME_KEY), "nexa");
      activeThemes.classic = normalizeTheme(readStorage(CLASSIC_THEME_KEY), "classic");
      applyAppearance();
      return;
    }
    if (event.key === APPEARANCE_KEY) {
      activeMode = normalizeMode(event.newValue);
      applyAppearance();
      return;
    }
    if (event.key === NEXA_THEME_KEY) {
      activeThemes.nexa = normalizeTheme(event.newValue, "nexa");
      applyAppearance();
      return;
    }
    if (event.key === CLASSIC_THEME_KEY) {
      activeThemes.classic = normalizeTheme(event.newValue, "classic");
      applyAppearance();
    }
  });

  // Floating switcher for logged-out or un-navigated views
  window.addEventListener('DOMContentLoaded', () => {
    // We only inject if there's no main app nav/shell AND no existing switcher.
    if (!document.querySelector('.nav') && !document.querySelector('.nexa-floating-switcher')) {
      const switcher = document.createElement('div');
      switcher.className = 'nexa-floating-switcher';
      switcher.innerHTML = `
         <button class="nexa-floating-btn" title="Appearance Settings" aria-label="Open appearance settings" type="button">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
        </button>
        <div class="nexa-floating-menu" hidden>
          <div class="nexa-fm-title">Appearance</div>
          <div class="nexa-fm-group">
             <button class="nexa-fm-btn mode-nexa" data-appearance-mode="nexa" type="button" aria-pressed="false" onclick="window.__nexa_appearance.setMode('nexa')">Nexa</button>
             <button class="nexa-fm-btn mode-classic" data-appearance-mode="classic" type="button" aria-pressed="false" onclick="window.__nexa_appearance.setMode('classic')">Classic</button>
           </div>
           <div class="nexa-fm-title" style="margin-top:12px">Colors</div>
           <div class="nexa-fm-group">
             <button class="nexa-fm-btn theme-light" data-appearance-theme="light" type="button" aria-pressed="false" onclick="window.__nexa_appearance.setTheme('light')">Light</button>
             <button class="nexa-fm-btn theme-dark" data-appearance-theme="dark" type="button" aria-pressed="false" onclick="window.__nexa_appearance.setTheme('dark')">Dark</button>
          </div>
        </div>
      `;
      document.body.appendChild(switcher);
       applyAppearance();

      const btn = switcher.querySelector('.nexa-floating-btn');
      const menu = switcher.querySelector('.nexa-floating-menu');
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.hidden = !menu.hidden;
      });
      document.addEventListener('click', (e) => {
        if (!switcher.contains(e.target)) menu.hidden = true;
      });
    }
  });
})();
