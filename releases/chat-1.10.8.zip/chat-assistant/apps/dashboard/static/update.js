document.addEventListener("DOMContentLoaded", () => {
  const checkBtn = document.getElementById("upd-check-btn");
  const installBtn = document.getElementById("upd-install-btn");
  const restartBtn = document.getElementById("upd-restart-btn");
  const statusText = document.getElementById("upd-status-text");
  const progContainer = document.getElementById("upd-progress-container");
  const phaseText = document.getElementById("upd-phase-text");
  const percentText = document.getElementById("upd-percent-text");
  const progBar = document.getElementById("upd-progress-bar");
  const errEl = document.getElementById("upd-error");

  if (!checkBtn) return;

  const storage = {
    get(key) { try { return localStorage.getItem(key); } catch(e) { return null; } },
    set(key, val) { try { localStorage.setItem(key, val); } catch(e) {} },
    remove(key) { try { localStorage.removeItem(key); } catch(e) {} }
  };

  let polling = false;
  let pollTimer = null;
  let activeOpId = storage.get("nexa_update_op") || null;
  
  const INDETERMINATE = ["idle", "checking", "verifying", "extracting", "staged", "restarting", "applying", "complete", "rolled_back", "failed"];

  async function saveSettingsFirst() {
    const updurl = document.getElementById("s-updurl");
    if (!updurl) return;
    const auto = document.getElementById("s-auto");
    const sigreq = document.getElementById("s-sigreq");
    
    await api("/api/settings", "POST", {
      update_url: updurl.value,
      auto_update: auto.value === "true",
      update_require_signature: sigreq.value === "true"
    });
  }

  function renderStatus(st) {
    if (!st) return;
    const currentVersion = document.getElementById("upd-current-version");
    if (currentVersion && typeof st.current === "string") {
      currentVersion.textContent = st.current;
    }
    
    if (st.operation && st.operation.phase !== "idle") {
      const op = st.operation;
      
      // Capture/rehydrate op ID and target
      if (op.id && op.id !== activeOpId) {
        activeOpId = op.id;
        storage.set("nexa_update_op", activeOpId);
      }

      if (op.phase === "staged" && !op.automatic_restart) {
        progContainer.style.display = "none";
        checkBtn.disabled = false;
        statusText.textContent = `Update ${op.target_version || st.pending || ''} ready to install`;
        statusText.style.color = "var(--accent)";
        installBtn.style.display = "";
        return;
      }
      
      progContainer.style.display = "block";
      phaseText.textContent = op.message || op.phase;
      
      if (op.error) {
        errEl.textContent = op.error;
        progBar.style.background = "var(--bad)";
        installBtn.style.display = "none";
        checkBtn.disabled = false;
        polling = false;
        return;
      } else {
        errEl.textContent = "";
        progBar.style.background = "var(--accent)";
      }

      if (op.phase === "downloading" && op.total_bytes > 0) {
        const pct = Math.floor((op.bytes_received / op.total_bytes) * 100);
        percentText.textContent = pct + "%";
        progBar.style.width = pct + "%";
        progBar.style.animation = "none";
      } else {
        percentText.textContent = "";
        progBar.style.width = "100%";
        if (INDETERMINATE.includes(op.phase) && op.phase !== "complete") {
          progBar.style.animation = "upd-pulse 1.5s infinite opacity";
        } else {
          progBar.style.animation = "none";
        }
      }
      
      checkBtn.disabled = true;
      installBtn.style.display = "none";
      
      if (op.phase === "failed" || op.phase === "rolled_back") {
        checkBtn.disabled = false;
        storage.remove("nexa_update_op");
        activeOpId = null;
      }
      
      // Check for completion
      if (op.phase === "complete" && st.current !== op.target_version) {
        statusText.textContent = "Update version could not be confirmed.";
        errEl.textContent = `Expected ${op.target_version || "the update version"}; Nexa is running ${st.current || "an unknown version"}.`;
        checkBtn.disabled = false;
        polling = false;
        return;
      }
      if (op.phase === "complete" && activeOpId === op.id && st.current === op.target_version) {
        statusText.textContent = `Successfully updated to ${st.current}`;
        statusText.style.color = "var(--good)";
        checkBtn.disabled = false;
        polling = false;
        storage.remove("nexa_update_op");
        activeOpId = null;
      }
      
    } else {
      progContainer.style.display = "none";
      checkBtn.disabled = false;
      
      if (st.pending && st.pending !== st.current) {
        statusText.textContent = `Update ${st.pending} available!`;
        statusText.style.color = "var(--accent)";
        installBtn.style.display = "";
      } else if (st.latest_seen) {
        statusText.textContent = `Up to date (${st.latest_seen})`;
        statusText.style.color = "var(--dim)";
        installBtn.style.display = "none";
      }
    }
  }

  async function pollStatus() {
    let backoff = 1000;
    polling = true;
    
    const runPoll = async () => {
      if (!polling) return;
      try {
        const st = await api("/api/update/status");
        renderStatus(st);
        
        const isBusy = st.operation && (
          ["checking", "downloading", "verifying", "extracting", "applying", "restarting"].includes(st.operation.phase) ||
          (st.operation.phase === "staged" && st.operation.automatic_restart)
        );
        
        if (isBusy) {
          backoff = 1000;
          pollTimer = setTimeout(runPoll, backoff);
        } else {
          polling = false;
        }
      } catch (e) {
        if (activeOpId) {
          phaseText.textContent = "Reconnecting...";
          progBar.style.width = "100%";
          progBar.style.animation = "upd-pulse 1s infinite";
        }
        backoff = Math.min(backoff * 1.5, 10000);
        pollTimer = setTimeout(runPoll, backoff);
      }
    };
    runPoll();
  }

  checkBtn.addEventListener("click", async () => {
    checkBtn.disabled = true;
    errEl.textContent = "";
    statusText.textContent = "Checking...";
    statusText.style.color = "var(--text)";
    
    try {
      await saveSettingsFirst();
      await api("/api/update/check", "POST", {});
      if (!polling) pollStatus();
    } catch (e) {
      if (e.message && e.message.includes("Admin session expired")) return;
      errEl.textContent = "Check failed: " + e.message;
      checkBtn.disabled = false;
    }
  });

  installBtn.addEventListener("click", async () => {
    if (!confirm("This will interrupt any active voice conversations and restart Nexa. Continue?")) {
      return;
    }
    
    installBtn.style.display = "none";
    checkBtn.disabled = true;
    errEl.textContent = "";
    statusText.textContent = "Installing...";
    
    try {
      await saveSettingsFirst();
      const st = await api("/api/update/install", "POST", {});
      if (st && st.operation) {
        activeOpId = st.operation.id;
        storage.set("nexa_update_op", activeOpId);
      }
      if (!polling) pollStatus();
    } catch (e) {
      if (e.message && e.message.includes("Admin session expired")) return;
      errEl.textContent = "Install failed: " + e.message;
      installBtn.style.display = "";
      checkBtn.disabled = false;
    }
  });
  
  if (restartBtn) {
    restartBtn.addEventListener("click", async () => {
      if (!confirm("Restart Nexa?")) return;
      try {
        await api("/api/restart", "POST", {});
        statusText.textContent = "Restarting...";
      } catch (e) {
        if (e.message && e.message.includes("Admin session expired")) return;
        errEl.textContent = "Restart failed: " + e.message;
      }
    });
  }

  api("/api/update/status").then(st => {
    renderStatus(st);
    if (st.operation && ["checking", "downloading", "verifying", "extracting", "staged", "restarting", "applying"].includes(st.operation.phase)) {
      if (!polling) pollStatus();
    }
  }).catch(e => {});

});