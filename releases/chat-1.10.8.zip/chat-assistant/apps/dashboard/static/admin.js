window.promptAdminUnlock = function() {
  return new Promise((resolve) => {
    const modal = document.getElementById("admin-reauth-modal");
    if (!modal) return resolve(false);
    modal.style.display = "flex";
    const pwd = document.getElementById("admin-reauth-pwd");
    const err = document.getElementById("admin-reauth-err");
    pwd.value = "";
    err.textContent = "";
    pwd.focus();
    
    const cleanup = () => {
      document.getElementById("admin-reauth-submit").onclick = null;
      document.getElementById("admin-reauth-cancel").onclick = null;
    };
    
    document.getElementById("admin-reauth-submit").onclick = async () => {
      err.textContent = "";
      try {
        const csrf = document.querySelector('meta[name="csrf"]')?.content || "";
        const resp = await fetch("/api/admin/unlock", {
          method: "POST",
          headers: {"Content-Type": "application/json", "x-csrf": csrf},
          body: JSON.stringify({password: pwd.value})
        });
        const data = await resp.json();
        if (!resp.ok) {
          throw new Error(data.error || "Unlock failed");
        }
        modal.style.display = "none";
        cleanup();
        
        if (window.checkAdminStatus) window.checkAdminStatus();
        
        resolve(true);
      } catch (e) {
        err.textContent = e.message;
      }
    };
    document.getElementById("admin-reauth-cancel").onclick = () => {
      modal.style.display = "none";
      cleanup();
      resolve(false);
    };
  });
};

document.addEventListener("DOMContentLoaded", () => {
  const statusBar = document.getElementById("admin-status-bar");
  const timer = document.getElementById("admin-timer");
  const lockBtn = document.getElementById("admin-lock-btn");
  
  window.checkAdminStatus = async function() {
    if (!statusBar) return;
    try {
      const st = await api("/api/admin/status");
      if (st.remote) {
        if (st.unlocked) {
          statusBar.style.display = "flex";
          timer.textContent = "Expires in " + (window.fmtSeconds ? window.fmtSeconds(st.ttl_seconds) : st.ttl_seconds + "s");
        } else {
          statusBar.style.display = "none";
        }
      }
    } catch (e) {
      // ignore
    }
  };
  
  if (lockBtn) {
    lockBtn.addEventListener("click", async () => {
      try {
        await api("/api/admin/lock", "POST", {});
        location.reload();
      } catch(e) {}
    });
  }
  
  if (statusBar) {
    window.checkAdminStatus();
    setInterval(window.checkAdminStatus, 30000);
  }
});