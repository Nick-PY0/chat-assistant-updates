// Loaded from <head> (see base.html): api() and the helpers below must exist
// BEFORE the per-page inline scripts run, because those execute while the
// page is still being parsed. Anything that touches page elements is wired
// in wirePageChrome(), which waits for the DOM to be ready.
const csrf = document.querySelector('meta[name="csrf"]')?.content || "";

// ---- theme (now coordinated with appearance.js) ----
const THEME_KEY = "chat-theme";
function normalizeTheme(name) {
  return name === "dark" ? "dark" : "light";
}
function applyTheme(name) {
  const theme = normalizeTheme(name);
  if (window.__nexa_appearance) {
    window.__nexa_appearance.setTheme(theme, window.__nexa_appearance.mode());
  } else {
    const dark = theme === "dark";
    document.documentElement.classList.toggle("dark", dark);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = dark ? "#0a0e14" : "#f2f4f8";
  }
}
function savedTheme() {
  if (window.__nexa_appearance) {
    return window.__nexa_appearance.theme(window.__nexa_appearance.mode());
  }
  try { return normalizeTheme(localStorage.getItem(THEME_KEY)); } catch (e) { return null; }
}
if (!window.__nexa_appearance) {
  applyTheme(savedTheme() || "light");
}

async function api(path, method = "GET", body = null) {
  const opts = { method, headers: { "x-csrf": csrf } };
  if (typeof AbortSignal !== "undefined" && AbortSignal.timeout)
    opts.signal = AbortSignal.timeout(20000); // never leave a button hanging forever
  if (body !== null) {
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  let resp;
  try {
    resp = await fetch(path, opts);
  } catch (e) {
    if (e && (e.name === "TimeoutError" || e.name === "AbortError"))
      throw new Error("No reply after 20 seconds -- Nexa may be busy. Try again.");
    throw new Error("Could not reach Nexa -- is it still running?");
  }
  let data = {};
  try { data = await resp.json(); } catch (e) { /* empty */ }
  if (!resp.ok) {
    const err = new Error(data.error || `HTTP ${resp.status}`);
    err.status = resp.status;
    err.code = data.code;
    if (err.code === "admin_unlock_required" && window.promptAdminUnlock) {
      window.promptAdminUnlock().then(unlocked => {
        if (unlocked) {
          const toast = document.createElement("div");
          toast.className = "okmsg";
          toast.style.position = "fixed";
          toast.style.bottom = "20px";
          toast.style.right = "20px";
          toast.style.background = "var(--panel)";
          toast.style.padding = "10px 20px";
          toast.style.borderRadius = "8px";
          toast.style.boxShadow = "var(--card-shadow)";
          toast.style.zIndex = "9999";
          toast.textContent = "Unlocked. Please try saving again.";
          document.body.appendChild(toast);
          setTimeout(() => toast.remove(), 4000);
        }
      });
      throw new Error("Admin session expired. Please unlock and try again.");
    }
    throw err;
  }
  return data;
}

function fmtSeconds(s) {
  s = Math.max(0, Math.floor(s));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h) return `${h}h ${m}m ${sec}s`;
  if (m) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function wireDashboardNavigation() {
  const toggle = document.getElementById("nav-toggle");
  const sidebar = document.getElementById("sidebar");
  const close = document.getElementById("nav-close");
  const scrim = document.getElementById("scrim");
  if (!toggle || !sidebar) return;

  const media = window.matchMedia?.("(max-width: 880px)");
  const isMobile = () => media ? media.matches : window.innerWidth <= 880;
  const isOpen = () => document.body.classList.contains("nav-open");
  const main = document.querySelector("main");
  const topbar = document.querySelector(".topbar");
  let returnFocus = null;
  let gesture = null;
  let suppressClickUntil = 0;

  function syncAccessibility() {
    const modal = isMobile() && isOpen();
    const hidden = isMobile() && !isOpen();
    toggle.setAttribute("aria-expanded", String(modal));
    toggle.setAttribute("aria-label", modal ? "Close menu" : "Open menu");
    sidebar.inert = hidden;
    if (hidden) sidebar.setAttribute("aria-hidden", "true");
    else sidebar.removeAttribute("aria-hidden");
    if (modal) {
      sidebar.setAttribute("role", "dialog");
      sidebar.setAttribute("aria-modal", "true");
    } else {
      sidebar.removeAttribute("role");
      sidebar.removeAttribute("aria-modal");
    }
    if (main) main.inert = modal;
    if (topbar) topbar.inert = modal;
  }

  function setOpen(open, restoreFocus = true) {
    open = Boolean(open && isMobile());
    if (open && !isOpen()) {
      returnFocus = document.activeElement;
      // Always show the first navigation links when reopening the drawer,
      // even after scrolling all the way down to its settings/actions.
      sidebar.scrollTop = 0;
    }
    document.body.classList.toggle("nav-open", open);
    syncAccessibility();
    if (open) (close || sidebar.querySelector("a"))?.focus({ preventScroll: true });
    else if (restoreFocus && returnFocus) {
      const target = returnFocus.isConnected ? returnFocus : toggle;
      target.focus({ preventScroll: true });
      returnFocus = null;
    }
  }

  toggle.addEventListener("click", () => setOpen(!isOpen()));
  close?.addEventListener("click", () => setOpen(false));
  scrim?.addEventListener("click", () => setOpen(false));
  sidebar.querySelectorAll("nav a").forEach((link) =>
    link.addEventListener("click", () => setOpen(false)));
  document.addEventListener("keydown", (event) => {
    if (!isMobile() || !isOpen()) return;
    if (event.key === "Escape") {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === "Tab") {
      const focusable = [...sidebar.querySelectorAll(
        'a[href], button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]'
      )].filter((el) => !el.hidden && el.getClientRects().length > 0);
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    }
  });
  window.addEventListener("resize", () => {
    if (!isMobile()) setOpen(false, false);
    else syncAccessibility();
  });

  // Passive touch listeners never cancel vertical scrolling. Opening only
  // starts at the left edge; closing requires a clearly horizontal swipe.
  document.addEventListener("touchstart", (event) => {
    gesture = null;
    if (!isMobile() || event.touches.length !== 1) return;
    if (event.target.closest?.("input, textarea, select, [contenteditable=true]")) return;
    const touch = event.touches[0];
    const open = isOpen();
    if (!open && touch.clientX > 24) return;
    if (open && !sidebar.contains(event.target) && event.target !== scrim) return;
    gesture = { x: touch.clientX, y: touch.clientY, id: touch.identifier, open };
  }, { passive: true });
  document.addEventListener("touchmove", (event) => {
    if (!gesture) return;
    const touch = [...event.touches].find((item) => item.identifier === gesture.id);
    if (!touch || event.touches.length !== 1 ||
        Math.abs(touch.clientY - gesture.y) > Math.max(12, Math.abs(touch.clientX - gesture.x))) {
      gesture = null;
    }
  }, { passive: true });
  document.addEventListener("touchend", (event) => {
    const start = gesture;
    gesture = null;
    if (!start || start.open !== isOpen()) return;
    const touch = [...event.changedTouches].find((item) => item.identifier === start.id);
    if (!touch) return;
    const dx = touch.clientX - start.x, dy = touch.clientY - start.y;
    if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.6) return;
    if ((!start.open && dx > 0) || (start.open && dx < 0)) {
      suppressClickUntil = Date.now() + 350;
      setOpen(!start.open);
    }
  }, { passive: true });
  document.addEventListener("touchcancel", () => { gesture = null; }, { passive: true });
  document.addEventListener("click", (event) => {
    if (event.detail && Date.now() < suppressClickUntil) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
  sidebar.setAttribute("aria-label", "Navigation");
  syncAccessibility();
}

function wirePageChrome() {
  // ---- light / dark toggle (its label is pure CSS: .theme-label) ----
  const themeBtn = document.getElementById("theme-btn");
  if (themeBtn) {
    themeBtn.addEventListener("click", () => {
      const next = document.documentElement.classList.contains("dark") ? "light" : "dark";
      if (window.__nexa_appearance) {
        window.__nexa_appearance.setTheme(next, window.__nexa_appearance.mode());
      } else {
        try { localStorage.setItem(THEME_KEY, next); } catch (e) { /* private mode */ }
        applyTheme(next);
      }
    });
  }

  // ---- phone navigation drawer ----
  wireDashboardNavigation();

  // ---- quiet mode toggle ----
  const quietBtn = document.getElementById("quiet-btn");
  function setQuietUI(on) {
    if (quietBtn) {
      quietBtn.classList.toggle("on", on);
      quietBtn.textContent = on ? "Quiet mode ON" : "Quiet mode";
    }
    document.dispatchEvent(new CustomEvent("chat-quiet", { detail: { quiet: on } }));
  }
  if (quietBtn) {
    quietBtn.addEventListener("click", async () => {
      try {
        const r = await api("/api/quiet", "POST", { quiet: !quietBtn.classList.contains("on") });
        setQuietUI(r.quiet);
      } catch (e) { alert(e.message); }
    });
  }

  // ---- ringing banner (shown on every page while an alarm rings) ----
  const ringBanner = document.getElementById("ring-banner");
  const ringText = document.getElementById("ring-text");
  function showRing(data) {
    if (!ringBanner) return;
    const kind = data.kind === "alarm" ? "ALARM" : "Reminder";
    ringText.textContent = data.message ? `${kind}: ${data.message}` : `${kind} is ringing`;
    ringBanner.hidden = false;
  }
  async function syncRing() {
    if (!ringBanner || ringBanner.hidden) return;
    try {
      const s = await api("/api/state");
      if (s.ringing) showRing(s.ringing);
      else ringBanner.hidden = true;
    } catch (e) { /* signed out */ }
  }
  const ringSnooze = document.getElementById("ring-snooze");
  if (ringSnooze) {
    ringSnooze.addEventListener("click", async () => {
      try { await api("/api/reminders/snooze", "POST", {}); } catch (e) { /* signed out */ }
      ringBanner.hidden = true;
    });
  }
  const ringDismiss = document.getElementById("ring-dismiss");
  if (ringDismiss) {
    ringDismiss.addEventListener("click", async () => {
      try { await api("/api/reminders/dismiss", "POST", {}); } catch (e) { /* signed out */ }
      ringBanner.hidden = true;
    });
  }

  // ---- mute button ----
  const muteBtn = document.getElementById("mute-btn");
  if (muteBtn) {
    muteBtn.addEventListener("click", async () => {
      const muted = !muteBtn.classList.contains("muted");
      try {
        await api("/api/mute", "POST", { muted });
        location.reload();
      } catch (e) { alert(e.message); }
    });
  }

  // ---- stop buttons (sidebar + phone topbar): silence Nexa immediately ----
  for (const id of ["stop-btn", "stop-btn-top"]) {
    const btn = document.getElementById(id);
    if (!btn) continue;
    btn.addEventListener("click", async () => {
      try {
        btn.disabled = true;
        await api("/api/stop", "POST", {});
      } catch (e) { /* signed out */ }
      setTimeout(() => { btn.disabled = false; }, 400);
    });
  }

  // ---- voice controller popup (owns the remote-mic lease) ----
  const voiceCtrlBtn = document.getElementById("voice-ctrl-btn");
  if (voiceCtrlBtn) {
    voiceCtrlBtn.addEventListener("click", () => {
      if (window.innerWidth <= 880 || window.__JARVIS_NATIVE_APP__ === true) {
        // The native wrapper emits this same event before blur/back/reload.
        // Dispatching before same-tab dashboard navigation gives any currently
        // active voice surface one synchronous, credential-free cleanup hook.
        window.dispatchEvent(new Event("jarvis:deactivate"));
        window.location.assign("/voice-controller");
      } else {
        // Open a named window so multiple clicks reuse/focus the same popup.
        const popup = window.open(
          "/voice-controller",
          "chat-voice-controller",
          "width=470,height=760,resizable=yes,scrollbars=yes"
        );
        if (popup) popup.focus();
      }
    });
  }

  // ---- live state via SSE ----
  const dots = [document.getElementById("state-dot"), document.getElementById("state-dot-top")].filter(Boolean);
  const label = document.getElementById("state-label");
  function startLiveEvents() {
    let es;
    try {
      es = new EventSource("/events");
    } catch (e) { return; /* SSE optional */ }
    es.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      if (msg.topic === "state") {
        dots.forEach((d) => { d.className = "brand-dot " + msg.state; });
        if (label) {
          if (msg.degraded_detail && msg.degraded_detail.length) {
            const parts = msg.degraded_detail.map((d) => d.reason || d.component);
            label.textContent = msg.state + " (degraded: " + parts.join(", ") + ")";
          } else if (msg.degraded && msg.degraded.length) {
            label.textContent = msg.state + " (degraded: " + msg.degraded.join(", ") + ")";
          } else {
            label.textContent = msg.state;
          }
        }
        document.dispatchEvent(new CustomEvent("chat-state", { detail: msg }));
      } else {
        if (msg.topic === "reminder_fired") showRing(msg);
        if (msg.topic === "reminders_changed") syncRing();
        if (msg.topic === "quiet_changed") setQuietUI(!!msg.quiet);
        document.dispatchEvent(new CustomEvent("chat-event", { detail: msg }));
      }
    };
  }
  // Connect only AFTER the page has fully loaded: a live stream opened during
  // load keeps some browsers showing "loading" forever (Esc seemed to fix it).
  if (dots.length) {
    if (document.readyState === "complete") setTimeout(startLiveEvents, 0);
    else window.addEventListener("load", () => setTimeout(startLiveEvents, 50));
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", wirePageChrome);
} else {
  wirePageChrome();
}
