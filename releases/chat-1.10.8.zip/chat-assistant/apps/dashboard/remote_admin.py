"""Remote owner-admin policy for the dashboard.

This is deliberately an exact, small policy rather than a prefix allowlist.
Broadcast transport policy and the dashboard authorization guard both consume
the same path-shaped contract, while the capability itself is checked by the
dashboard process.
"""

from __future__ import annotations

import re
from urllib.parse import unquote

REMOTE_ADMIN_SCOPE = "dashboard-remote-admin"
REMOTE_ADMIN_TTL_SECONDS = 15 * 60
ADMIN_CAPABILITY_COOKIE = "chat_admin_capability"

ADMIN_PAGES = frozenset({"/settings", "/credentials", "/providers", "/github"})

_ADMIN_API_METHODS = {
    "GET": frozenset({
        "/api/credentials",
        "/api/providers/summary",
        "/api/calendar/status",
        "/api/calendar/events",
        "/api/calendar/oauth/callback",
        "/api/spotify/status",
        "/api/spotify/oauth/callback",
        "/api/audio/devices",
        "/api/startup/status",
        "/api/companion/status",
        "/api/broadcast/status",
        "/api/experts",
        "/api/github/status",
        "/api/cloud-schedule/status",
    }),
    "POST": frozenset({
        "/api/admin/unlock",
        "/api/admin/lock",
        "/api/credentials",
        "/api/settings",
        "/api/calendar/oauth/start",
        "/api/calendar/disconnect",
        "/api/calendar/calendars",
        "/api/calendar/sync",
        "/api/calendar/appointments/review",
        "/api/calendar/appointments/confirm",
        "/api/calendar/preferences",
        "/api/spotify/oauth/start",
        "/api/spotify/disconnect",
        "/api/startup/enable",
        "/api/startup/disable",
        "/api/companion/pair",
        "/api/companion/rotate",
        "/api/companion/revoke",
        "/api/broadcast",
        "/api/experts",
        "/api/password",
        "/api/github/config",
        "/api/github/review",
        "/api/github/publish",
        "/api/github/sync",
        "/api/github/restore",
        "/api/update/check",
        "/api/update/install",
        "/api/restart",
        "/api/cloud-schedule",
        "/api/cloud-schedule/launch",
    }),
    "PUT": frozenset({"/api/experts"}),
    "PATCH": frozenset({"/api/experts"}),
}

_ADMIN_API_PATTERNS = {
    "POST": (
        re.compile(r"^/api/credentials/[A-Za-z0-9_-]+/action$"),
    ),
}

# The status endpoint is intentionally readable by an ordinary authenticated
# session so a reconnecting dashboard can render update state after expiry.
_STATUS_API = frozenset({"/api/admin/status", "/api/update/status"})


def _decoded_path(path: str) -> str | None:
    if not isinstance(path, str) or not path.startswith("/"):
        return None
    try:
        decoded = unquote(path)
    except Exception:
        return None
    # Reject traversal aliases instead of letting a gateway and Starlette
    # disagree.  Benign encoded spellings are still classified as the
    # canonical admin path, never silently treated as an ordinary endpoint.
    if "\\" in path or "//" in path:
        return None
    if any(part in {".", ".."} for part in decoded.split("/")):
        return None
    return decoded.rstrip("/") or "/"


def is_admin_page(path: str) -> bool:
    return _decoded_path(path) in ADMIN_PAGES


def is_admin_api(method: str, path: str) -> bool:
    """Whether an exact API operation requires remote owner step-up."""
    clean = _decoded_path(path)
    if clean is None or clean in _STATUS_API:
        return False
    if clean in _ADMIN_API_METHODS.get(method.upper(), ()):
        return clean not in {"/api/admin/unlock", "/api/admin/lock"}
    return any(
        pattern.fullmatch(clean)
        for pattern in _ADMIN_API_PATTERNS.get(method.upper(), ())
    )


def is_admin_path(method: str, path: str) -> bool:
    return is_admin_page(path) or is_admin_api(method, path)


def safe_page_target(path: str) -> str:
    """Return only an allowlisted internal page for the unlock redirect."""
    clean = _decoded_path(path)
    return clean if clean in ADMIN_PAGES else "/settings"