const { JSDOM } = require("jsdom");
const assert = require("assert");
const fs = require('fs');
const path = require('path');

async function runTests() {
  const dom = new JSDOM(`
    <!DOCTYPE html>
    <html>
      <head>
        <meta name="csrf" content="token">
      </head>
      <body>
        <div id="admin-reauth-modal" style="display:none;">
          <input type="password" id="admin-reauth-pwd">
          <button id="admin-reauth-submit">Unlock</button>
          <button id="admin-reauth-cancel">Cancel</button>
          <div id="admin-reauth-err"></div>
        </div>
        <input id="s-updurl" value="http://manifest">
        <select id="s-auto"><option value="true" selected>On</option></select>
        <select id="s-sigreq"><option value="true" selected>On</option></select>
        <button id="upd-check-btn">Check</button>
        <button id="upd-install-btn" style="display:none;">Install</button>
        <span id="upd-current-version">v1</span>
        <div id="upd-status-text"></div>
        <div id="upd-progress-container" style="display:none;">
          <span id="upd-phase-text"></span>
          <span id="upd-percent-text"></span>
          <div id="upd-progress-bar"></div>
          <div id="upd-error"></div>
        </div>
      </body>
    </html>
  `, { url: "http://localhost/", runScripts: "dangerously" });

  const window = dom.window;
  const document = window.document;
  global.window = window;
  global.document = document;
  
  // Simulate blocked storage
  let storageBlocked = false;
  global.localStorage = {
    store: {},
    getItem(k) { if (storageBlocked) throw new Error("Access denied"); return this.store[k] || null; },
    setItem(k, v) { if (storageBlocked) throw new Error("Access denied"); this.store[k] = v; },
    removeItem(k) { if (storageBlocked) throw new Error("Access denied"); delete this.store[k]; }
  };
  global.Response = Response;
  window.confirm = () => true;

  const mockFetch = async (url, opts = {}) => {
    opts.headers = opts.headers || {};
    if (url === "/api/settings") {
      const body = opts.body ? JSON.parse(opts.body) : {};
      if (body.dirty === "yes") {
        return new Response(JSON.stringify({error: "unlock required", code: "admin_unlock_required"}), {status: 403, headers: {"Content-Type": "application/json"}});
      }
      return new Response(JSON.stringify({success: true}), {status: 200, headers: {"Content-Type": "application/json"}});
    }
    if (url === "/api/admin/unlock") {
      const body = JSON.parse(opts.body);
      if (body.password === "correct") {
        return new Response(JSON.stringify({success: true}), {status: 200, headers: {"Content-Type": "application/json"}});
      }
      return new Response(JSON.stringify({error: "bad password"}), {status: 401, headers: {"Content-Type": "application/json"}});
    }
    if (url === "/api/update/check") {
      global.mockUpdateStatus = {current: "v1", pending: null, operation: {id: "op1", phase: "checking", target_version: null, automatic_restart: false}};
      return new Response(JSON.stringify(global.mockUpdateStatus), {status: 202, headers: {"Content-Type": "application/json"}});
    }
    if (url === "/api/update/install") {
      global.mockUpdateStatus = {current: "v1", pending: null, operation: {id: "op1", phase: "checking", target_version: null, automatic_restart: true}};
      return new Response(JSON.stringify(global.mockUpdateStatus), {status: 202, headers: {"Content-Type": "application/json"}});
    }
    if (url === "/api/update/status") {
      if (global.mockUpdateStatus === "throw") throw new TypeError("fetch failed");
      const state = global.mockUpdateStatus || {current: "v1", pending: null, operation: {phase: "idle"}};
      return new Response(JSON.stringify(state), {status: 200, headers: {"Content-Type": "application/json"}});
    }
    return new Response("Not Found", {status: 404});
  };

  global.fetch = mockFetch;
  window.fetch = mockFetch;

  const appJs = fs.readFileSync(path.join(__dirname, '../../apps/dashboard/static/app.js'), 'utf8');
  const adminJs = fs.readFileSync(path.join(__dirname, '../../apps/dashboard/static/admin.js'), 'utf8');
  const updateJs = fs.readFileSync(path.join(__dirname, '../../apps/dashboard/static/update.js'), 'utf8');

  window.EventSource = class { constructor() {} };

  const scriptEl = document.createElement("script");
  scriptEl.textContent = appJs + "\n" + adminJs + "\n" + updateJs;
  document.head.appendChild(scriptEl);

  await new Promise(r => setTimeout(r, 100)); // wait for initial polls

  // Dirty Preservation Test
  console.log("Test: Auth Expiry / Dirty Preservation");
  try {
    let savePromise = window.api("/api/settings", "POST", {dirty: "yes"}).catch(e => {
      assert.strictEqual(e.message, "Admin session expired. Please unlock and try again.");
    });
    await new Promise(r => setTimeout(r, 50));
    assert.strictEqual(document.getElementById("admin-reauth-modal").style.display, "flex");
    
    document.getElementById("admin-reauth-pwd").value = "wrong";
    await document.getElementById("admin-reauth-submit").onclick();
    await new Promise(r => setTimeout(r, 50));
    assert.strictEqual(document.getElementById("admin-reauth-err").textContent, "bad password");
    
    document.getElementById("admin-reauth-pwd").value = "correct";
    await document.getElementById("admin-reauth-submit").onclick();
    await new Promise(r => setTimeout(r, 50));
    assert.strictEqual(document.getElementById("admin-reauth-modal").style.display, "none");
    
    await savePromise;
    console.log("  OK");
  } catch (e) {
    console.error(e);
    process.exit(1);
  }

  // Update Progress & Null Initial Target -> Later Target
  console.log("Test: Null target initial -> later download target");
  try {
    document.getElementById("upd-check-btn").click();
    await new Promise(r => setTimeout(r, 50));
    global.mockUpdateStatus = {current: "v1", pending: "v2", operation: {id: "op1", phase: "staged"}};
    await new Promise(r => setTimeout(r, 1050));
    assert.notStrictEqual(window.getComputedStyle(document.getElementById("upd-install-btn")).display, "none");
    assert.strictEqual(document.getElementById("upd-install-btn").disabled, false);
    document.getElementById("upd-install-btn").click();
    await new Promise(r => setTimeout(r, 50));
    
    // Simulate polling
    global.mockUpdateStatus = {current: "v1", pending: "v2", operation: {id: "op1", phase: "downloading", target_version: "v2", bytes_received: 50, total_bytes: 100}};
    await new Promise(r => setTimeout(r, 1050)); // wait for poll
    assert.strictEqual(document.getElementById("upd-percent-text").textContent, "50%");
    console.log("  OK progress");
  } catch(e) {
    console.error(e); process.exit(1);
  }

  console.log("Test: Restart Disconnect -> Server Complete / Version Match");
  try {
    global.mockUpdateStatus = "throw";
    await new Promise(r => setTimeout(r, 1050)); // next poll throws
    assert.strictEqual(document.getElementById("upd-phase-text").textContent, "Reconnecting...");
    console.log("  OK disconnect handling");
    
    global.mockUpdateStatus = {current: "v2", pending: null, operation: {id: "op1", phase: "complete", target_version: "v2"}};
    await new Promise(r => setTimeout(r, 2000)); // next poll succeeds (backoff happens so wait longer)
    assert.strictEqual(document.getElementById("upd-status-text").textContent, "Successfully updated to v2");
    assert.strictEqual(document.getElementById("upd-current-version").textContent, "v2");
    console.log("  OK completion detected");
  } catch(e) {
    console.error(e); process.exit(1);
  }

  // Blocked storage test
  console.log("Test: Blocked storage");
  try {
    storageBlocked = true;
    document.getElementById("upd-check-btn").click();
    await new Promise(r => setTimeout(r, 50));
    global.mockUpdateStatus = {current: "v2", pending: "v3", operation: {id: "op2", phase: "downloading", target_version: "v3", bytes_received: 10, total_bytes: 100}};
    await new Promise(r => setTimeout(r, 1550));
    assert.strictEqual(document.getElementById("upd-phase-text").textContent, "downloading");
    
    global.mockUpdateStatus = {current: "v3", pending: null, operation: {id: "op2", phase: "complete", target_version: "v3"}};
    await new Promise(r => setTimeout(r, 1050));
    assert.strictEqual(document.getElementById("upd-status-text").textContent, "Successfully updated to v3");
    console.log("  OK blocked storage");
  } catch(e) {
    console.error(e); process.exit(1);
  }

  console.log("All JSDOM tests passed.");
  window.close();
}

runTests().catch(error => {
  console.error(error);
  process.exitCode = 1;
});