"""Check a disposable desktop through two independent cloud gateway workers.

Run broadcast_fixture.py first, then the loopback-only Node fixture worker.
The argument is that worker's port. This never enables the real desktop.
No password, cookie, CSRF token, or database credential is printed.
"""
from __future__ import annotations

import asyncio
import os
import re
import ssl
import sys

import httpx
from websockets.asyncio.client import connect
from websockets.exceptions import InvalidStatus

TEST_PASSWORD = "Broadcast-Test-Only-4927"
COOKIE = "chat_session"


async def websocket_checks(port: int, origin: str, cookie: str) -> None:
    async with connect(
        f"ws://127.0.0.1:{port}/ws/audio",
        origin=origin,
        additional_headers={"Cookie": cookie},
        open_timeout=15,
    ):
        pass
    try:
        async with connect(
            f"ws://127.0.0.1:{port}/ws/audio",
            origin=origin,
            open_timeout=15,
        ):
            raise AssertionError("Unauthenticated audio socket was accepted")
    except InvalidStatus as exc:
        assert exc.response.status_code == 403


def main() -> None:
    domain = os.environ.get("REPLIT_DEV_DOMAIN", "")
    if not domain.endswith(".replit.dev"):
        raise SystemExit("Requires the development domain and disposable fixture.")
    port = int(sys.argv[1])
    if not 1024 <= port <= 65535:
        raise SystemExit("Invalid loopback fixture port")
    origin = "https://" + domain
    common = {"timeout": 25, "headers": {"Origin": origin}, "follow_redirects": False}
    with (
        httpx.Client(base_url=origin, verify=ssl.create_default_context(), **common) as a,
        httpx.Client(base_url=f"http://127.0.0.1:{port}", **common) as b,
        httpx.Client(base_url=f"http://127.0.0.1:{port}", **common) as anonymous,
    ):
        response = b.post("/login", data={"password": TEST_PASSWORD})
        assert response.status_code == 303, f"login status {response.status_code}"
        assert response.headers.get("location") == "/dashboard"
        attributes = response.headers["set-cookie"].lower()
        assert "secure" in attributes and "httponly" in attributes and "samesite=strict" in attributes
        token = b.cookies.get(COOKIE)
        assert token, "No fixture session received"
        cookie = f"{COOKIE}={token}"
        a.headers["Cookie"] = b.headers["Cookie"] = cookie
        page = b.get("/dashboard")
        assert page.status_code == 200
        csrf_match = re.search(r'<meta name="csrf" content="([^"]+)">', page.text)
        assert csrf_match, "Dashboard CSRF tag missing"
        csrf = csrf_match.group(1)
        assert a.get("/api/state").status_code == 200
        assert b.get("/api/routines").status_code == 200
        assert anonymous.get("/api/state").status_code == 401
        assert b.get("/setup").status_code == 403
        assert b.get("/settings").status_code == 403
        assert b.post("/api/timers", json={"duration_seconds": 1800}).status_code == 403
        print("PASS cross-worker login, session, local-only routes and CSRF")

        a.headers["X-CSRF"] = b.headers["X-CSRF"] = csrf
        label = "AutoscaleCrossWorkerCheck"
        timer_id = None
        try:
            with b.stream("GET", "/events", timeout=20) as stream:
                assert stream.status_code == 200
                created = a.post("/api/timers", json={"duration_seconds": 1800, "label": label})
                assert created.status_code == 200
                for line in stream.iter_lines():
                    if line.startswith("data:"):
                        break
                else:
                    raise AssertionError("No SSE data received")
            timers = b.get("/api/timers").json()["timers"]
            timer = next(item for item in timers if item.get("label") == label)
            timer_id = timer["id"]
            for worker, action in [(b, "pause"), (a, "resume")]:
                assert worker.post(f"/api/timers/{timer_id}/{action}", json={}).status_code == 200
            assert b.post(f"/api/timers/{timer_id}/cancel", json={}).status_code == 200
            timer_id = None
            print("PASS cross-worker SSE and timer create/pause/resume/cancel")
            asyncio.run(websocket_checks(port, origin, cookie))
            assert a.get("/api/dashboard-status").json()["online"] is True
            print("PASS accepted and denied cross-worker WebSockets; desktop remains online")
        finally:
            if timer_id:
                a.post(f"/api/timers/{timer_id}/cancel", json={})

        assert b.post("/logout", data={"_csrf": csrf}).status_code == 303
        # Deliberately keep the old Cookie header to test revocation on BOTH workers.
        assert a.get("/api/state").status_code == 401
        assert b.get("/api/state").status_code == 401
        print("PASS logout revocation across both workers")


if __name__ == "__main__":
    main()