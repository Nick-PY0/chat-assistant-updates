const { JSDOM } = require("jsdom");
const assert = require("assert");
const fs = require('fs');
const path = require('path');

async function runTests() {
  console.log("Test: Staged phase -> Install visible, no endless polling");
  const updateJs = fs.readFileSync(path.join(__dirname, '../../apps/dashboard/static/update.js'), 'utf8');
  let dom = new JSDOM(`
    <html>
      <body>
        <input id="s-updurl" value="url">
        <select id="s-auto"><option value="true">On</option></select>
        <select id="s-sigreq"><option value="true">On</option></select>
        <button id="upd-check-btn"></button>
        <button id="upd-install-btn" style="display:none;"></button>
        <button id="upd-restart-btn"></button>
        <div id="upd-status-text"></div>
        <div id="upd-progress-container" style="display:none;">
          <span id="upd-phase-text"></span>
          <span id="upd-percent-text"></span>
          <div id="upd-progress-bar"></div>
          <div id="upd-error"></div>
        </div>
      </body>
    </html>
  `, { url: "http://localhost/" });

  let window = dom.window;
  let document = window.document;
  global.window = window;
  global.document = document;
  global.localStorage = { getItem() { return null; }, setItem() {}, removeItem() {} };
  
  let polledCount = 0;
  window.api = async (url, method, body) => {
    if (url === "/api/settings") {
      assert.strictEqual(body.update_url, "url");
      assert.strictEqual(body.auto_update, true);
      assert.strictEqual(body.update_require_signature, true);
      assert.strictEqual(body.update_manifest_url, undefined);
      return {};
    }
    if (url === "/api/update/status") {
      polledCount++;
      return { operation: { phase: "staged", automatic_restart: false, target_version: "v2" } };
    }
  };
  global.api = window.api;
  
  eval(updateJs);
  document.dispatchEvent(new window.Event("DOMContentLoaded"));
  await new Promise(r => setTimeout(r, 50));
  
  assert.ok(window.getComputedStyle(document.getElementById("upd-install-btn")).display !== "none");
  assert.strictEqual(window.getComputedStyle(document.getElementById("upd-progress-container")).display, "none");
  const p1 = polledCount;
  await new Promise(r => setTimeout(r, 1100));
  assert.strictEqual(polledCount, p1, "Polling should stop at staged phase");
  console.log("  OK");
  
  console.log("Test: admin.html safe redirect");
  dom = new JSDOM(`
    <html>
      <body>
        <form id="admin-unlock-form"><input id="admin-pwd" value="123"></form>
        <div id="admin-err"></div>
      </body>
    </html>
  `, { url: "http://localhost/admin?next=//evil.com/settings" });
  
  window = dom.window;
  document = window.document;
  window.api = async () => {};
  
  const adminHtml = fs.readFileSync(path.join(__dirname, '../../apps/dashboard/templates/admin.html'), 'utf8');
  const scriptContent = adminHtml.match(/<script>([\s\S]*?)<\/script>/)[1];
  
  let redirectUrl = "";
  window.__TEST_LOCATION_ASSIGN__ = (url) => { redirectUrl = url; };
  
  eval(scriptContent);
  const ev = new window.Event("submit");
  document.getElementById("admin-unlock-form").dispatchEvent(ev);
  
  await new Promise(r => setTimeout(r, 50));
  assert.strictEqual(redirectUrl, "/");
  console.log("  OK //evil.com/settings blocked");
  
  dom = new JSDOM(`
    <html>
      <body>
        <form id="admin-unlock-form"><input id="admin-pwd" value="123"></form>
        <div id="admin-err"></div>
      </body>
    </html>
  `, { url: "http://localhost/admin?next=/settings" });
  window = dom.window;
  document = window.document;
  window.api = async () => {};
  redirectUrl = "";
  window.__TEST_LOCATION_ASSIGN__ = (url) => { redirectUrl = url; };
  
  // Replace the {{ admin_next | default('') }} so it falls back to URL parameters.
  let testingScript = scriptContent.replace("{{ admin_next | default('') }}", "");
  eval(testingScript);
  document.getElementById("admin-unlock-form").dispatchEvent(new window.Event("submit"));
  await new Promise(r => setTimeout(r, 50));
  assert.strictEqual(redirectUrl, "/settings");
  console.log("  OK /settings allowed");
  
  dom = new JSDOM(`
    <html>
      <body>
        <form id="admin-unlock-form"><input id="admin-pwd" value="123"></form>
        <div id="admin-err"></div>
      </body>
    </html>
  `, { url: "http://localhost/admin?next=/settings/../../etc/passwd" });
  window = dom.window;
  document = window.document;
  window.api = async () => {};
  redirectUrl = "";
  window.__TEST_LOCATION_ASSIGN__ = (url) => { redirectUrl = url; };

  eval(testingScript);
  document.getElementById("admin-unlock-form").dispatchEvent(new window.Event("submit"));
  await new Promise(r => setTimeout(r, 50));
  assert.strictEqual(redirectUrl, "/");
  console.log("  OK path traversal blocked");

  console.log("All fix tests passed.");
}
runTests().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
