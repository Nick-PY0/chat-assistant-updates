// Test real dashboard chrome, rendered by Jinja, without credentials or APIs.
import { test } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { JSDOM } from "jsdom";

const dashboard = resolve(dirname(fileURLToPath(import.meta.url)), "../../apps/dashboard");
const rendered = execFileSync("python", ["-c", `
import json, sys
from jinja2 import Environment, FileSystemLoader, select_autoescape
env = Environment(loader=FileSystemLoader(sys.argv[1]), autoescape=select_autoescape())
print(env.get_template("base.html").render(
    csrf="fixture", app_version="fixture", active="status", home_url="/",
    state={"state": "SLEEPING", "muted": False}, quiet=False,
    ringing=None, broadcast_request=True))
`, resolve(dashboard, "templates")], { encoding: "utf8" });
const html = rendered.replace(/<script src="\/static\/([\w-]+\.js)[^"]*"><\/script>/g,
  (_, file) => `<script>${readFileSync(resolve(dashboard, "static", file), "utf8")}</script>`);

async function makePage(width = 390) {
  const dom = new JSDOM(html, {
    url: "https://navigation.fixture.test/",
    runScripts: "dangerously",
    pretendToBeVisual: true,
    beforeParse(window) {
      window.innerWidth = width;
      window.matchMedia = () => ({ get matches() { return window.innerWidth <= 880; } });
      window.fetch = async () => { throw new Error("Network disabled in navigation test"); };
      window.EventSource = class { close() {} };
    },
  });
  await new Promise((done) => dom.window.addEventListener("load", done));
  return dom;
}
function touch(window, target, type, x, y, count = 1) {
  const event = new window.Event(type, { bubbles: true, cancelable: true });
  const points = Array.from({ length: count }, (_, identifier) => ({
    identifier, clientX: x, clientY: y,
  }));
  Object.defineProperties(event, {
    touches: { value: type === "touchend" ? [] : points },
    changedTouches: { value: points },
  });
  target.dispatchEvent(event);
  assert.equal(event.defaultPrevented, false, `${type} must not cancel native scrolling`);
}
function swipe(window, target, from, to) {
  touch(window, target, "touchstart", ...from);
  touch(window, target, "touchmove", ...to);
  touch(window, target, "touchend", ...to);
}

test("menu opens with Dashboard first, closes explicitly, restores focus and scroll", async () => {
  const dom = await makePage();
  const { document } = dom.window;
  try {
    const toggle = document.getElementById("nav-toggle");
    const sidebar = document.getElementById("sidebar");
    const close = document.getElementById("nav-close");
    const main = document.querySelector("main");
    assert.equal(sidebar.inert, true);
    assert.match(sidebar.querySelector("nav a").textContent, /Dashboard/);
    toggle.focus();
    toggle.click();
    assert.equal(toggle.getAttribute("aria-expanded"), "true");
    assert.equal(document.activeElement, close);
    assert.equal(main.inert, true);
    sidebar.scrollTop = 900;
    close.click();
    assert.equal(main.inert, false);
    assert.equal(sidebar.inert, true);
    assert.equal(document.activeElement, toggle);
    toggle.click();
    assert.equal(sidebar.scrollTop, 0);
    document.getElementById("scrim").click();
    assert.equal(toggle.getAttribute("aria-expanded"), "false");
  } finally { dom.window.close(); }
});

test("horizontal edge swipe opens; closing swipe works; vertical and inner-page swipes stay native", async () => {
  const dom = await makePage();
  const w = dom.window, doc = w.document;
  try {
    const main = doc.querySelector("main"), sidebar = doc.getElementById("sidebar");
    const open = () => doc.body.classList.contains("nav-open");
    swipe(w, main, [150, 100], [250, 100]);
    assert.equal(open(), false, "inner-page gestures must not open the menu");
    swipe(w, main, [10, 100], [20, 280]);
    assert.equal(open(), false, "vertical edge scroll must not open the menu");
    swipe(w, main, [10, 100], [120, 105]);
    assert.equal(open(), true);
    swipe(w, sidebar, [200, 300], [190, 100]);
    assert.equal(open(), true, "drawer must stay open during vertical scroll");
    swipe(w, sidebar, [200, 100], [70, 105]);
    assert.equal(open(), false);
  } finally { w.close(); }
});

test("search fields and multitouch never trigger menu gestures", async () => {
  const dom = await makePage();
  const w = dom.window, doc = w.document;
  try {
    doc.getElementById("nav-toggle").click();
    swipe(w, doc.getElementById("nav-search-input"), [200, 100], [50, 100]);
    assert.equal(doc.body.classList.contains("nav-open"), true);
    const sidebar = doc.getElementById("sidebar");
    touch(w, sidebar, "touchstart", 200, 100, 2);
    touch(w, sidebar, "touchend", 50, 100, 2);
    assert.equal(doc.body.classList.contains("nav-open"), true);
  } finally { w.close(); }
});

test("Escape, page navigation, resize and Classic mode do not leave scrolling locked", async () => {
  const dom = await makePage();
  const w = dom.window, doc = w.document;
  try {
    const toggle = doc.getElementById("nav-toggle");
    const assertClosed = () => {
      assert.equal(doc.body.classList.contains("nav-open"), false);
      assert.equal(doc.querySelector("main").inert, false);
    };
    toggle.click();
    doc.dispatchEvent(new w.KeyboardEvent("keydown", { key: "Escape" }));
    assertClosed();
    toggle.click();
    const link = doc.querySelector("#sidebar nav a");
    link.addEventListener("click", (e) => e.preventDefault());
    link.click();
    assertClosed();
    toggle.click();
    w.__nexa_appearance.setMode("classic");
    doc.getElementById("nav-close").click();
    assertClosed();
    toggle.click();
    w.innerWidth = 1280;
    w.dispatchEvent(new w.Event("resize"));
    assertClosed();
    assert.equal(doc.getElementById("sidebar").inert, false);
    assert.equal(doc.getElementById("sidebar").hasAttribute("aria-hidden"), false);
  } finally { w.close(); }
});