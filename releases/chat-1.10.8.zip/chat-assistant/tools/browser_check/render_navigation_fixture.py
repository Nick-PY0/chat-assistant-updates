#!/usr/bin/env python3
"""Render disposable, offline navigation-drawer browser fixtures.

The fixtures deliberately execute the dashboard's real Jinja templates and
browser JavaScript, while replacing network/device boundaries with inert
browser-local shims.  They are simulated CSS regression fixtures, not a
physical Android or native-wrapper test.

Run from any directory with:

    python chat-assistant/tools/browser_check/render_navigation_fixture.py

The generated files are written to
``artifacts/mockup-sandbox/public/__mobile_check/`` by default.  Use
``?check`` for the in-document drawer assertions or ``?open`` for a clean
open-drawer screenshot.
"""

from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import re
import subprocess
import textwrap
from typing import Mapping

from jinja2 import Environment, FileSystemLoader, select_autoescape


ROOT = Path(__file__).resolve().parents[3]
DASHBOARD = ROOT / "chat-assistant" / "apps" / "dashboard"
TEMPLATES = DASHBOARD / "templates"
STATIC = DASHBOARD / "static"
DEFAULT_OUTPUT = ROOT / "artifacts" / "mockup-sandbox" / "public" / "__mobile_check"

CSS_FILES = ("style.css", "style-nexa.css")
LOGO_FILES = ("nexa-logo.webp", "nexa-mark-complete.webp")

STYLE_LINK_RE = re.compile(
    r'<link\s+rel="stylesheet"\s+href="/static/(style(?:-nexa)?\.css)(?:\?[^"]*)?"\s*/?>',
    re.IGNORECASE,
)
SCRIPT_SRC_RE = re.compile(
    r'<script\s+src="/static/(appearance\.js|app\.js)(?:\?[^"]*)?"></script>',
    re.IGNORECASE,
)


def git_head_file(relative_path: str) -> str:
    """Read a baseline source file from the repository's actual HEAD."""

    try:
        result = subprocess.run(
            ["git", "show", f"HEAD:{relative_path}"],
            cwd=ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise RuntimeError(
            f"Could not read baseline {relative_path} from git HEAD; "
            "run this generator from the repository checkout."
        ) from exc
    return result.stdout


def data_uri(path: Path) -> str:
    """Return a self-contained base64 data URI for a local logo asset."""

    suffix = path.suffix.lower()
    mime = {".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg"}[suffix]
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def zero_dynamic_viewport(css: str) -> str:
    """Model a WebView that accepts, but resolves, every 100dvh to zero."""

    return css.replace("100dvh", "0px")


def network_shim() -> str:
    """Return a pre-app script that keeps all fixture effects browser-local."""

    return textwrap.dedent(
        """\
        <script data-navigation-fixture="offline-shim">
        (() => {
          const disabled = () => Promise.reject(new Error(
            "Network disabled by the navigation fixture"
          ));
          window.__NAVIGATION_FIXTURE__ = true;
          window.fetch = disabled;

          // app.js still executes its live-event setup, but this constructor
          // cannot open a socket or deliver provider/device events.
          window.EventSource = class FixtureEventSource {
            constructor() { this.readyState = 2; }
            addEventListener() {}
            removeEventListener() {}
            close() {}
          };
          window.WebSocket = class FixtureWebSocket {
            constructor() { this.readyState = 3; }
            close() {}
            send() {}
          };

          // The status page only constructs this after a user click. Keep
          // that path harmless too, without changing the production source.
          class FixtureAudioContext {
            constructor() {
              this.currentTime = 0;
              this.destination = {};
            }
            resume() { return Promise.resolve(); }
            close() { return Promise.resolve(); }
            createBuffer() {
              return { duration: 0, getChannelData: () => new Float32Array(0) };
            }
            createBufferSource() {
              return {
                connect() {},
                start() {},
                stop() {},
                onended: null,
              };
            }
          }
          window.AudioContext = FixtureAudioContext;
          window.webkitAudioContext = FixtureAudioContext;
        })();
        </script>
        """
    )


def fixture_assertions() -> str:
    """Return document-level assertions used by the optional ``?check`` mode."""

    return textwrap.dedent(
        """\
        <script data-navigation-fixture="drawer-check">
        (() => {
          const check = {
            status: "idle",
            results: [],
            result: null,
            promise: null,
            run: null,
          };
          window.__drawerCheck = check;

          const waitForLayout = () => new Promise((resolve) => {
            const later = () => {
              if (typeof requestAnimationFrame === "function") {
                requestAnimationFrame(() => requestAnimationFrame(resolve));
              } else {
                setTimeout(resolve, 40);
              }
            };
            later();
          });

          function showResults(report) {
            let panel = document.getElementById("navigation-fixture-results");
            if (!panel) {
              panel = document.createElement("div");
              panel.id = "navigation-fixture-results";
              panel.setAttribute("role", "status");
              panel.setAttribute("aria-live", "polite");
              panel.style.cssText = [
                "position:fixed", "right:12px", "bottom:12px", "z-index:1000",
                "max-width:340px", "padding:9px 12px", "border-radius:9px",
                "font:12px/1.4 system-ui,sans-serif", "white-space:pre-wrap",
                "box-shadow:0 4px 18px rgba(0,0,0,.25)", "pointer-events:none",
              ].join(";");
              document.body.appendChild(panel);
            }
            panel.style.color = report.failed ? "#ffd9dd" : "#d8ffe9";
            panel.style.background = report.failed
              ? "rgba(130,24,39,.94)" : "rgba(11,91,59,.94)";
            const summary = `${report.passed}/${report.total} drawer checks passed`;
            const detail = report.results.map((item) =>
              `${item.ok ? "PASS" : "FAIL"} ${item.name}`
                + (item.detail ? ` — ${item.detail}` : "")
            ).join("\\n");
            panel.textContent = `${summary}\\n${detail}`;
          }

          function record(report, name, callback) {
            try {
              callback();
              report.passed += 1;
              report.results.push({ name, ok: true, detail: "" });
            } catch (error) {
              report.failed += 1;
              report.results.push({
                name,
                ok: false,
                detail: error && error.message ? error.message : String(error),
              });
            }
          }

          function requireThat(value, message) {
            if (!value) throw new Error(message);
          }

          function visible(element) {
            if (!element) return false;
            const style = getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.display !== "none"
              && style.visibility !== "hidden"
              && rect.width > 0
              && rect.height > 0;
          }

          function closeAfterCheck(toggle, close, sidebar) {
            if (document.body.classList.contains("nav-open")) {
              (close || toggle).click();
            }
            return waitForLayout().then(() => {
              const scrim = document.getElementById("scrim");
              const main = document.querySelector("main");
              const scrimHidden = scrim
                && getComputedStyle(scrim).display === "none";
              record(check._report, "closing removes scrim and inert state", () => {
                requireThat(
                  !document.body.classList.contains("nav-open"),
                  "body remains nav-open"
                );
                requireThat(scrimHidden, "scrim is still displayed");
                requireThat(main && main.inert === false, "main remains inert");
                requireThat(sidebar.inert === true, "closed drawer is not inert");
              });
            });
          }

          async function run() {
            check.status = "running";
            const report = {
              passed: 0,
              failed: 0,
              total: 0,
              results: [],
            };
            check._report = report;
            const toggle = document.getElementById("nav-toggle");
            const sidebar = document.getElementById("sidebar");
            const close = document.getElementById("nav-close");
            const main = document.querySelector("main");

            if (!toggle || !sidebar || !close || !main) {
              record(report, "dashboard drawer controls exist", () => {
                requireThat(false, "real dashboard drawer DOM is incomplete");
              });
              report.total = report.results.length;
              check.status = "failed";
              check.result = report;
              showResults(report);
              return report;
            }

            record(report, "drawer opens through #nav-toggle", () => {
              toggle.click();
              requireThat(
                document.body.classList.contains("nav-open"),
                "drawer did not open"
              );
              requireThat(
                toggle.getAttribute("aria-expanded") === "true",
                "toggle aria-expanded is not true"
              );
            });
            await waitForLayout();

            const drawerRect = sidebar.getBoundingClientRect();
            record(report, "drawer reaches the simulated viewport", () => {
              requireThat(Math.abs(drawerRect.top) <= 2,
                `top=${drawerRect.top}, expected 0`);
              requireThat(
                Math.abs(drawerRect.bottom - window.innerHeight) <= 3,
                `bottom=${drawerRect.bottom}, viewport=${window.innerHeight}`
              );
              requireThat(drawerRect.height > 300,
                `height=${drawerRect.height}, expected more than 300px`);
            });

            const dashboard = [...sidebar.querySelectorAll("nav a")]
              .find((link) => /Dashboard/.test(link.textContent || ""));
            record(report, "Dashboard is visible in the open drawer", () => {
              requireThat(dashboard, "Dashboard link is missing");
              requireThat(visible(dashboard), "Dashboard link has no visible box");
            });

            record(report, "drawer content is vertically scrollable", () => {
              requireThat(sidebar.scrollHeight > sidebar.clientHeight,
                `scrollHeight=${sidebar.scrollHeight}, clientHeight=${sidebar.clientHeight}`);
            });

            const lastAction = sidebar.querySelector(
              ".nav-bottom form button:last-child"
            );
            sidebar.scrollTop = sidebar.scrollHeight;
            await waitForLayout();
            record(report, "scrolling reaches the last drawer action", () => {
              requireThat(lastAction, "last drawer action is missing");
              const actionRect = lastAction.getBoundingClientRect();
              const currentDrawerRect = sidebar.getBoundingClientRect();
              requireThat(
                Math.abs(
                  sidebar.scrollTop
                  - (sidebar.scrollHeight - sidebar.clientHeight)
                ) <= 3,
                "drawer did not reach its scroll bottom"
              );
              requireThat(
                actionRect.bottom <= currentDrawerRect.bottom + 4
                && actionRect.top >= currentDrawerRect.top - 4,
                "last drawer action is outside the viewport"
              );
            });

            await closeAfterCheck(toggle, close, sidebar);
            report.total = report.results.length;
            check.status = report.failed ? "failed" : "passed";
            check.result = report;
            delete check._report;
            showResults(report);
            return report;
          }

          function schedule() {
            const params = new URLSearchParams(window.location.search);
            if (params.has("check")) {
              check.promise = check.run();
            } else if (params.has("open")) {
              const toggle = document.getElementById("nav-toggle");
              if (toggle) toggle.click();
            }
          }

          check.run = () => {
            if (!check.promise) {
              check.promise = run().catch((error) => {
                check.status = "failed";
                const report = {
                  passed: 0,
                  failed: 1,
                  total: 1,
                  results: [{
                    name: "drawer fixture execution",
                    ok: false,
                    detail: error && error.message ? error.message : String(error),
                  }],
                };
                check.result = report;
                showResults(report);
                return report;
              });
            }
            return check.promise;
          };

          if (document.readyState === "complete") {
            setTimeout(schedule, 0);
          } else {
            window.addEventListener("load", schedule, { once: true });
          }
        })();
        </script>
        """
    )


def inline_dashboard(
    rendered: str,
    css: Mapping[str, str],
    javascript: Mapping[str, str],
) -> str:
    """Inline dashboard styles/scripts/assets so the page has no dependencies."""

    def inline_style(match: re.Match[str]) -> str:
        filename = match.group(1)
        return f'<style data-dashboard-source="{filename}">\n{css[filename]}\n</style>'

    def inline_script(match: re.Match[str]) -> str:
        filename = match.group(1)
        prefix = network_shim() if filename == "appearance.js" else ""
        return f'{prefix}<script data-dashboard-source="{filename}">\n{javascript[filename]}\n</script>'

    rendered = STYLE_LINK_RE.sub(inline_style, rendered)
    rendered = SCRIPT_SRC_RE.sub(inline_script, rendered)
    for filename in LOGO_FILES:
        rendered = rendered.replace(
            f"/static/brand/{filename}",
            data_uri(STATIC / "brand" / filename),
        )
    return rendered


def render_status_page(css: Mapping[str, str]) -> str:
    """Render status.html/base.html with intentionally synthetic, safe data."""

    environment = Environment(
        loader=FileSystemLoader(TEMPLATES),
        autoescape=select_autoescape(),
    )
    rendered = environment.get_template("status.html").render(
        csrf="navigation-fixture-csrf",
        app_version="navigation-fixture",
        active="status",
        home_url="/",
        state={
            "state": "SLEEPING",
            "reason": "Synthetic fixture idle state",
            "muted": False,
        },
        quiet=False,
        ringing=None,
        broadcast_request=True,
        voice_ok=False,
        voice_reason="Disabled by the browser fixture",
        keychain_source="fixture-only",
        settings_json=json.dumps({"audio_output_route": "speaker"}),
    )
    javascript = {
        "appearance.js": (STATIC / "appearance.js").read_text(encoding="utf-8"),
        "app.js": (STATIC / "app.js").read_text(encoding="utf-8"),
    }
    page = inline_dashboard(rendered, css, javascript)
    return page.replace("</body>", fixture_assertions() + "\n</body>", 1)


def embedded_fixture() -> str:
    """Build a neutral 460px iframe shell around the zero-viewport fixture."""

    return textwrap.dedent(
        """\
        <!doctype html>
        <html lang="en">
        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Browser navigation fixture shell</title>
        <style>
          :root { color-scheme: light; font: 14px/1.45 system-ui, sans-serif; }
          body { margin: 0; color: #243247; background: #eef2f7; }
          header, footer { padding: 12px 16px; background: #dce4ee; }
          header { border-bottom: 1px solid #c8d3e0; }
          header strong { display: block; font-size: 14px; }
          header span, footer { color: #5b6b80; font-size: 12px; }
          main { padding: 12px; }
          iframe {
            display: block; width: 100%; height: 460px; box-sizing: border-box;
            border: 1px solid #bdc9d8; border-radius: 8px; background: #fff;
          }
          footer { border-top: 1px solid #c8d3e0; }
        </style>
        </head>
        <body>
        <header>
          <strong>Browser navigation fixture shell</strong>
          <span>Simulated 460px iframe viewport; this is not a native wrapper.</span>
        </header>
        <main>
          <iframe
            title="Simulated mobile browser viewport"
            src="fixed-zero.html"
            height="460"
          ></iframe>
        </main>
        <footer>Offline synthetic status data · no provider or device calls</footer>
        </body>
        </html>
        """
    )


def generate(output_dir: Path) -> tuple[Path, ...]:
    """Generate all four named fixtures and return their paths."""

    current_css = {
        filename: (STATIC / filename).read_text(encoding="utf-8")
        for filename in CSS_FILES
    }
    baseline_css = {
        filename: git_head_file(f"chat-assistant/apps/dashboard/static/{filename}")
        for filename in CSS_FILES
    }
    output_dir.mkdir(parents=True, exist_ok=True)

    fixed = render_status_page(current_css)
    fixed_zero = render_status_page(
        {filename: zero_dynamic_viewport(source) for filename, source in current_css.items()}
    )
    broken_zero = render_status_page(
        {
            filename: zero_dynamic_viewport(source)
            for filename, source in baseline_css.items()
        }
    )
    fixtures = {
        "fixed.html": fixed,
        "fixed-zero.html": fixed_zero,
        "broken-zero.html": broken_zero,
        "embedded.html": embedded_fixture(),
    }
    paths = []
    for filename, contents in fixtures.items():
        path = output_dir / filename
        path.write_text(contents, encoding="utf-8")
        paths.append(path)
    return tuple(paths)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT,
        help=f"fixture output directory (default: {DEFAULT_OUTPUT})",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_dir = args.output_dir
    if not output_dir.is_absolute():
        output_dir = (Path.cwd() / output_dir).resolve()
    try:
        paths = generate(output_dir)
    except (OSError, RuntimeError, KeyError, ValueError) as exc:
        raise SystemExit(f"navigation fixture generation failed: {exc}") from exc
    print("Generated offline browser navigation fixtures:")
    for path in paths:
        print(f"  {path}")
    print("Use ?check for assertions or ?open for an open-drawer screenshot.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())