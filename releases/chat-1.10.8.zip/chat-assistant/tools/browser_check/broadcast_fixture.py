"""Disposable desktop for the remote-dashboard browser test.

No real desktop data or password is read or modified. This fixture only connects
to this workspace's development Relay and disappears when the process stops.
Never run this against a published Relay.
"""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
import secrets
import signal
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from apps.dashboard.app import create_app
from chat_core.config.settings import Settings
from chat_core.runtime import Runtime
from chat_core.security.auth import SessionManager, hash_password

TEST_PASSWORD = "Broadcast-Test-Only-4927"


async def main() -> None:
    domain = os.environ.get("REPLIT_DEV_DOMAIN", "")
    if not domain.endswith(".replit.dev"):
        raise SystemExit("This fixture requires the workspace development domain.")
    done = asyncio.Event()
    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(signum, done.set)
    with tempfile.TemporaryDirectory(prefix="jarvis-broadcast-fixture-") as folder:
        settings = Settings(data_dir=folder)
        runtime = Runtime(settings)
        await runtime.start(voice=False, cloud=False, monitoring=False)
        try:
            await runtime.db.set_setting("admin_password_hash", hash_password(TEST_PASSWORD))
            settings.broadcast_enabled = True
            app = create_app(runtime)
            # Do not reuse the environment's session signer for a test desktop.
            app.state.sessions = SessionManager(secrets.token_hex(32), 3600)
            async with app.router.lifespan_context(app):
                for _ in range(100):
                    status = app.state.broadcast.status()
                    if status["state"] == "online":
                        print("DISPOSABLE BROADCAST READY", flush=True)
                        break
                    await asyncio.sleep(0.3)
                else:
                    print("DISPOSABLE BROADCAST NOT READY: " + status["state"], flush=True)
                    return
                try:
                    await asyncio.wait_for(done.wait(), timeout=900)
                except TimeoutError:
                    pass
        finally:
            await runtime.stop()
    print("DISPOSABLE BROADCAST STOPPED", flush=True)


if __name__ == "__main__":
    asyncio.run(main())