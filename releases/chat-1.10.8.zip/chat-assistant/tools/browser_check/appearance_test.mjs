// Cheap regression checks for the dashboard appearance contract.
//
// This intentionally executes the checked-in appearance.js (and, for the
// rendered settings fixture, app.js) in jsdom.  It does not start the
// dashboard, connect to a device, or exercise any of the network-backed
// surfaces.
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { JSDOM } from "jsdom";

const HERE = dirname(fileURLToPath(import.meta.url));
const DASHBOARD = resolve(HERE, "../../apps/dashboard");
const TEMPLATES = resolve(DASHBOARD, "templates");
const appearanceSource = readFileSync(
  resolve(DASHBOARD, "static/appearance.js"),
  "utf8",
);
const appSource = readFileSync(resolve(DASHBOARD, "static/app.js"), "utf8");

const failures = [];

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function check(name, fn) {
  try {
    await fn();
    console.log(`PASS ${name}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    failures.push(`${name}: ${message}`);
    console.log(`FAIL ${name}: ${message}`);
  }
}

function storage(initial = {}, blocked = false) {
  const values = new Map(Object.entries(initial));
  return {
    get length() {
      return values.size;
    },
    key(index) {
      return [...values.keys()][index] ?? null;
    },
    getItem(key) {
      if (blocked) throw new Error("storage blocked");
      return values.has(String(key)) ? values.get(String(key)) : null;
    },
    setItem(key, value) {
      if (blocked) throw new Error("storage blocked");
      values.set(String(key), String(value));
    },
    removeItem(key) {
      if (blocked) throw new Error("storage blocked");
      values.delete(String(key));
    },
    clear() {
      if (blocked) throw new Error("storage blocked");
      values.clear();
    },
    values,
  };
}

function pageWithAppearance() {
  return `<!doctype html>
    <html><head>
      <meta name="theme-color" content="#f2f4f8">
      <script>${appearanceSource}</script>
    </head><body>
      <nav class="nav"></nav>
      <form id="unsaved-form">
        <input id="unsaved-input" value="fixture initial value">
        <select id="unsaved-select"><option selected>Fixture option</option></select>
        <textarea id="unsaved-textarea">Fixture textarea value</textarea>
      </form>
      <button class="nexa-mode-btn" type="button">Nexa</button>
      <button class="classic-mode-btn" type="button">Classic</button>
    </body></html>`;
}

function inlineDashboardScripts(html) {
  return html
    .replace(
      /<script[^>]+src="\/static\/appearance\.js[^"]*"[^>]*><\/script>/g,
      `<script>${appearanceSource}</script>`,
    )
    .replace(
      /<script[^>]+src="\/static\/app\.js[^"]*"[^>]*><\/script>/g,
      `<script>${appSource}</script>`,
    );
}

function makeDom(html, {
  savedStorage = storage(),
  url = "https://appearance.fixture.test/",
  fetch = false,
} = {}) {
  const dom = new JSDOM(html, {
    url,
    runScripts: "dangerously",
    pretendToBeVisual: true,
    beforeParse(window) {
      Object.defineProperty(window, "localStorage", {
        configurable: true,
        value: savedStorage,
      });
      window.alert = () => {};
      window.confirm = () => false;
      window.open = () => null;
      // app.js only needs fetch when a page script explicitly asks for data.
      // Keep this fixture network-free; callers can opt out of the stub when
      // they only execute appearance.js.
      if (fetch) {
        window.fetch = () => Promise.reject(new Error("fixture has no network"));
      }
    },
  });
  return dom;
}

function flushDom() {
  return new Promise((resolvePromise) => setTimeout(resolvePromise, 0));
}

function modeClasses(window) {
  const root = window.document.documentElement;
  return {
    nexa: root.classList.contains("nexa-mode"),
    classic: root.classList.contains("classic-mode"),
    dark: root.classList.contains("dark"),
  };
}

function modeButton(window, mode) {
  const candidates = [...window.document.querySelectorAll(
    `.mode-${mode}, [data-appearance-mode="${mode}"], ` +
    `[data-mode="${mode}"], .${mode}-mode-btn, ` +
    `.appearance-btn, .nexa-mode-btn, .classic-mode-btn`,
  )];
  // The dashboard's visibility class describes the mode in which a control
  // is shown, while its onclick describes the mode it selects.
  return candidates.find((button) =>
    new RegExp(`setMode\\(['"]${mode}['"]\\)`).test(button.getAttribute("onclick") || ""),
  ) || candidates[0] || null;
}

function storageEvent(window, {
  key,
  oldValue = null,
  newValue = null,
  storageArea = null,
  url = "https://appearance.fixture.test/other-tab",
}) {
  // jsdom's StorageEvent constructor insists on a native Storage object, but
  // the fixture deliberately supplies a tiny controllable storage object.
  // Defining the event fields preserves the browser event contract without
  // weakening the blocked-storage test.
  const event = new window.Event("storage");
  Object.defineProperties(event, {
    key: { value: key },
    oldValue: { value: oldValue },
    newValue: { value: newValue },
    storageArea: { value: storageArea },
    url: { value: url },
  });
  return event;
}

function renderTemplate(name) {
  // Render through Jinja rather than maintaining a second HTML copy in this
  // test.  This uses only synthetic fixture values and never touches auth,
  // credentials, or an API server.
  const context = {
    request: { scope: {} },
    csrf: "FIXTURE_CSRF_NOT_A_SECRET",
    app_version: "0.0.0",
    active: "settings",
    home_url: "/",
    broadcast_request: false,
    quiet: false,
    ringing: null,
    state: { state: "ready", muted: false },
    settings_json: JSON.stringify({
      alarm_ring_seconds: 30,
      alarm_volume: 1,
      audio_output_route: "speaker",
      auto_update: false,
      dashboard_host: "127.0.0.1",
      dashboard_port: 8765,
      gemini_model: "FIXTURE_MODEL",
      gemini_voice: "FIXTURE_VOICE",
      inactivity_timeout_seconds: 60,
      interrupt_rms_threshold: 1000,
      location_lat: 0,
      location_lon: 0,
      location_name: "",
      low_power: false,
      mic_device: "",
      openai_live_model: "FIXTURE_OPENAI_MODEL",
      openai_voice: "alloy",
      pulse_audio_idle_interval: 30,
      pulse_credential_interval: 60,
      pulse_govee_interval: 60,
      pulse_internet_interval: 60,
      pulse_timer_interval: 60,
      pulse_tv_interval: 60,
      quiet_override_alarms: true,
      quota_reset_jitter_seconds: 0,
      quota_reset_timezone: "UTC",
      rate_limit_rotate_after_failures: 3,
      relay_chat_model: "",
      relay_command_model: "",
      relay_daily_request_cap: 0,
      relay_url: "",
      relay_voice: "alloy",
      retry_window_backoff_seconds: 60,
      rotation_enabled: true,
      speaker_device: "",
      system_prompt: "FIXTURE_SYSTEM_PROMPT",
      typed_chat_provider: "openai",
      unavailable_retry_seconds: 60,
      update_require_signature: true,
      update_url: "",
      voice_brain: "gemini",
      voice_enabled: false,
      vosk_model_path: "",
      wake_threshold: 0.5,
      wake_word_model: "hey_jarvis",
      weather_units: "fahrenheit",
    }),
  };
  const renderer = `
import json
import sys
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape

root = Path(sys.argv[1])
template_name = sys.argv[2]
context = json.loads(sys.stdin.read())
environment = Environment(
    loader=FileSystemLoader(str(root)),
    autoescape=select_autoescape(["html", "xml"]),
)
print(environment.get_template(template_name).render(**context))
`;
  const executable = process.env.PYTHON || "python3";
  return execFileSync(
    executable,
    ["-c", renderer, TEMPLATES, name],
    { input: JSON.stringify(context), encoding: "utf8" },
  );
}

const baseFixture = pageWithAppearance();

await check("Nexa is the default appearance", async () => {
  const dom = makeDom(baseFixture);
  try {
    const classes = modeClasses(dom.window);
    assert(dom.window.__nexa_appearance.mode() === "nexa", "mode did not default to nexa");
    assert(classes.nexa && !classes.classic, "default mode classes are not Nexa");
    assert(classes.dark, "Nexa default theme is not dark");
    assert(
      dom.window.document.querySelector('meta[name="theme-color"]').content === "#030712",
      "Nexa default theme color is wrong",
    );
  } finally {
    dom.window.close();
  }
});

await check("Classic restores chat-theme without overwriting it", async () => {
  const saved = storage({
    "nexa-appearance": "nexa",
    "chat-theme": "light",
    "nexa-theme": "dark",
  });
  const before = new Map(saved.values);
  const dom = makeDom(baseFixture, { savedStorage: saved });
  try {
    dom.window.__nexa_appearance.setMode("classic");
    const classes = modeClasses(dom.window);
    assert(classes.classic && !classes.nexa, "Classic mode was not applied");
    assert(!classes.dark, "Classic did not restore the saved light chat theme");
    assert(dom.window.__nexa_appearance.theme("classic") === "light", "chat-theme was not restored");
    assert(
      saved.values.get("chat-theme") === before.get("chat-theme"),
      "switching to Classic overwrote chat-theme",
    );
    assert(
      saved.values.get("nexa-theme") === before.get("nexa-theme"),
      "switching to Classic overwrote nexa-theme",
    );
  } finally {
    dom.window.close();
  }
});

await check("Nexa and Classic keep separate theme values", async () => {
  const saved = storage({ "chat-theme": "light", "nexa-theme": "dark" });
  const dom = makeDom(baseFixture, { savedStorage: saved });
  try {
    dom.window.__nexa_appearance.setTheme("light", "nexa");
    assert(saved.values.get("nexa-theme") === "light", "Nexa theme did not use nexa-theme");
    assert(saved.values.get("chat-theme") === "light", "Nexa changed chat-theme");
    dom.window.__nexa_appearance.setTheme("dark", "classic");
    assert(saved.values.get("chat-theme") === "dark", "Classic theme did not use chat-theme");
    assert(saved.values.get("nexa-theme") === "light", "Classic changed nexa-theme");
  } finally {
    dom.window.close();
  }
});

await check("appearance switches persist across reload and navigation", async () => {
  const saved = storage();
  const first = makeDom(baseFixture, { savedStorage: saved, url: "https://appearance.fixture.test/" });
  try {
    first.window.__nexa_appearance.setMode("classic");
    first.window.__nexa_appearance.setTheme("light", "classic");
  } finally {
    first.window.close();
  }

  const nextPage = makeDom(baseFixture, {
    savedStorage: saved,
    url: "https://appearance.fixture.test/settings",
  });
  try {
    assert(nextPage.window.__nexa_appearance.mode() === "classic", "mode did not survive navigation");
    assert(nextPage.window.__nexa_appearance.theme("classic") === "light", "theme did not survive navigation");
    assert(modeClasses(nextPage.window).classic, "reloaded page did not apply Classic");
  } finally {
    nextPage.window.close();
  }

  const reload = makeDom(baseFixture, {
    savedStorage: saved,
    url: "https://appearance.fixture.test/chat",
  });
  try {
    assert(reload.window.__nexa_appearance.mode() === "classic", "mode did not survive reload");
    assert(!modeClasses(reload.window).dark, "reloaded Classic page lost its light theme");
  } finally {
    reload.window.close();
  }
});

await check("blocked localStorage still permits a current-page switch", async () => {
  const dom = makeDom(baseFixture, { savedStorage: storage({}, true) });
  try {
    dom.window.__nexa_appearance.setMode("classic");
    const classes = modeClasses(dom.window);
    assert(classes.classic && !classes.nexa, "Classic switch failed with blocked localStorage");
    assert(dom.window.__nexa_appearance.mode() === "classic", "in-memory mode was not retained");
    dom.window.__nexa_appearance.setMode("nexa");
    assert(modeClasses(dom.window).nexa, "switching back to Nexa failed with blocked localStorage");
  } finally {
    dom.window.close();
  }
});

await check("cross-tab appearance storage events apply mode and theme", async () => {
  const saved = storage({ "nexa-appearance": "nexa", "nexa-theme": "dark" });
  const dom = makeDom(baseFixture, { savedStorage: saved });
  try {
    dom.window.dispatchEvent(storageEvent(dom.window, {
      key: "nexa-appearance",
      oldValue: "nexa",
      newValue: "classic",
      storageArea: saved,
      url: "https://appearance.fixture.test/other-tab",
    }));
    assert(modeClasses(dom.window).classic, "Classic storage event was ignored");
    dom.window.dispatchEvent(storageEvent(dom.window, {
      key: "chat-theme",
      oldValue: "light",
      newValue: "dark",
      storageArea: saved,
      url: "https://appearance.fixture.test/other-tab",
    }));
    assert(modeClasses(dom.window).dark, "theme storage event was ignored");
    dom.window.dispatchEvent(storageEvent(dom.window, {
      key: "nexa-appearance",
      oldValue: "classic",
      newValue: "nexa",
      storageArea: saved,
      url: "https://appearance.fixture.test/other-tab",
    }));
    assert(modeClasses(dom.window).nexa, "Nexa storage event was ignored");
  } finally {
    dom.window.close();
  }
});

await check("invalid stored appearance values normalize safely", async () => {
  const dom = makeDom(baseFixture, {
    savedStorage: storage({
      "nexa-appearance": "not-a-mode",
      "nexa-theme": "not-a-theme",
      "chat-theme": "also-not-a-theme",
    }),
  });
  try {
    assert(dom.window.__nexa_appearance.mode() === "nexa", "invalid mode was not normalized to Nexa");
    assert(dom.window.__nexa_appearance.theme("nexa") === "dark", "invalid Nexa theme was not normalized");
    assert(modeClasses(dom.window).nexa && modeClasses(dom.window).dark, "invalid values produced unsafe classes");
    dom.window.__nexa_appearance.setMode("classic");
    assert(dom.window.__nexa_appearance.theme("classic") === "light", "invalid Classic theme was not normalized");
    assert(!modeClasses(dom.window).dark, "invalid Classic theme produced a dark class");
    dom.window.__nexa_appearance.setMode("another-invalid-mode");
    assert(dom.window.__nexa_appearance.mode() === "nexa", "invalid setMode value was not normalized");
  } finally {
    dom.window.close();
  }
});

await check("appearance changes preserve unsaved form values", async () => {
  const dom = makeDom(baseFixture);
  try {
    const input = dom.window.document.getElementById("unsaved-input");
    const select = dom.window.document.getElementById("unsaved-select");
    const textarea = dom.window.document.getElementById("unsaved-textarea");
    input.value = "FIXTURE_UNSAVED_TEXT_VALUE";
    select.value = "Fixture option";
    textarea.value = "FIXTURE_UNSAVED_TEXTAREA_VALUE";

    dom.window.__nexa_appearance.setMode("classic");
    dom.window.__nexa_appearance.setTheme("dark", "classic");
    dom.window.dispatchEvent(storageEvent(dom.window, {
      key: "nexa-appearance",
      oldValue: "classic",
      newValue: "nexa",
      storageArea: dom.window.localStorage,
    }));

    assert(input.value === "FIXTURE_UNSAVED_TEXT_VALUE", "appearance replaced an unsaved input");
    assert(select.value === "Fixture option", "appearance dropped an unsaved select value");
    assert(textarea.value === "FIXTURE_UNSAVED_TEXTAREA_VALUE", "appearance dropped textarea content");
  } finally {
    dom.window.close();
  }
});

let renderedSettings;
let renderedAuth = {};
try {
  renderedSettings = renderTemplate("settings.html");
  renderedAuth.login = renderTemplate("login.html");
  renderedAuth.setup = renderTemplate("setup.html");
  renderedAuth.voice = renderTemplate("voice_controller.html");
  renderedAuth.mobile_setup = renderTemplate("mobile_setup.html");
} catch (error) {
  failures.push(`render Jinja fixtures: ${error.message}`);
  console.log(`FAIL render Jinja fixtures: ${error.message}`);
}

if (renderedSettings) {
  await check("rendered settings search clear restores all content", async () => {
    const dom = makeDom(inlineDashboardScripts(renderedSettings), {
      fetch: true,
      url: "https://appearance.fixture.test/settings",
    });
    try {
      await flushDom();
      const search = dom.window.document.getElementById("settings-search");
      const cards = [...dom.window.document.querySelectorAll("main .card, main details.card")];
      assert(search && cards.length > 3, "rendered settings fixture is missing search/cards");

      search.value = "voice brain";
      search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
      assert(
        cards.some((card) => card.style.display === "" && /voice brain/i.test(card.textContent)),
        "settings search did not retain a matching card",
      );
      assert(
        cards.some((card) => card.style.display === "none"),
        "settings search did not hide a non-matching card",
      );

      search.value = "";
      search.dispatchEvent(new dom.window.Event("input", { bubbles: true }));
      assert(
        cards.every((card) => card.style.display === ""),
        "clearing settings search did not restore all cards",
      );
    } finally {
      dom.window.close();
    }
  });

  await check("shared app.js remains before page inline scripts", async () => {
    const appearanceTag = renderedSettings.indexOf('src="/static/appearance.js');
    const appTag = renderedSettings.indexOf('src="/static/app.js');
    const firstInline = renderedSettings.indexOf("<script>");
    assert(appearanceTag !== -1, "rendered base omitted appearance.js");
    assert(appTag !== -1, "rendered base omitted app.js");
    assert(firstInline !== -1, "rendered settings has no page inline script to guard");
    assert(appearanceTag < appTag && appTag < firstInline, "shared scripts are not ordered before inline code");

    const dom = makeDom(inlineDashboardScripts(renderedSettings), {
      fetch: true,
      url: "https://appearance.fixture.test/settings",
    });
    try {
      assert(typeof dom.window.api === "function", "app.js helpers were not available in the rendered page");
    } finally {
      dom.window.close();
    }
  });

  await check("rendered base appearance controls switch modes", async () => {
    const renderedStorage = storage({ "chat-theme": "light", "nexa-theme": "dark" });
    const dom = makeDom(inlineDashboardScripts(renderedSettings), {
      savedStorage: renderedStorage,
      fetch: true,
      url: "https://appearance.fixture.test/settings",
    });
    try {
      await flushDom();
      const classic = modeButton(dom.window, "classic");
      const nexa = modeButton(dom.window, "nexa");
      assert(classic && nexa, "rendered base is missing appearance mode controls");
      classic.click();
      assert(modeClasses(dom.window).classic, "Classic control did not switch the rendered base");
      nexa.click();
      assert(modeClasses(dom.window).nexa, "Nexa control did not switch the rendered base");
      const themeButton = dom.window.document.getElementById("theme-btn");
      assert(themeButton, "rendered base is missing its theme control");
      const chatThemeBefore = renderedStorage.values.get("chat-theme");
      themeButton.click();
      assert(!modeClasses(dom.window).dark, "app.js theme control did not switch Nexa to light");
      assert(
        dom.window.localStorage.getItem("nexa-theme") === "light",
        "app.js theme control did not persist Nexa theme separately",
      );
      assert(
        dom.window.localStorage.getItem("chat-theme") === chatThemeBefore,
        "app.js theme control overwrote Classic theme",
      );
    } finally {
      dom.window.close();
    }
  });
}

for (const [name, html] of Object.entries(renderedAuth)) {
  const hasAppearance = /appearance\.js|nexa-floating-switcher|appearance-btn|data-appearance-mode|data-mode=/.test(html);
  await check(`${name} appearance chrome control works`, async () => {
    assert(hasAppearance, "template has no appearance script or control");
    assert(/\/static\/style-nexa\.css(?:\?|")/.test(html), "template omitted cache-busted style-nexa.css");
    assert(/\/static\/appearance\.js(?:\?|")/.test(html), "template omitted cache-busted appearance.js");
    if (name !== "voice") {
      assert(!/\/static\/app\.js(?:\?|")/.test(html), "logged-out template bootstrapped app.js");
    }
    const dom = makeDom(inlineDashboardScripts(html), {
      fetch: true,
      url: `https://appearance.fixture.test/${name}`,
    });
    try {
      await flushDom();
      const classic = modeButton(dom.window, "classic");
      assert(classic, "appearance-enabled template has no Classic control");
      const unsaved = dom.window.document.querySelector("input[type=password], input[type=text]");
      if (unsaved) unsaved.value = "FIXTURE_UNSAVED_AUTH_VALUE";
      const switcher = dom.window.document.querySelector(".nexa-floating-btn");
      switcher?.click();
      classic.click();
      assert(modeClasses(dom.window).classic, "auth/voice appearance control did not switch to Classic");
      if (unsaved) {
        assert(unsaved.value === "FIXTURE_UNSAVED_AUTH_VALUE", "appearance control replaced auth input");
      }
    } finally {
      dom.window.close();
    }
  });
}

if (failures.length) {
  console.log(`\nFAILURES (${failures.length}):`);
  for (const item of failures) console.log(`  - ${item}`);
  process.exitCode = 1;
} else {
  console.log("\nAppearance regression checks passed.");
}