@echo off
title Nexa
color 07
cd /d "%~dp0"
rem This marker makes the batch loop the sole restart owner.  A direct
rem run_chat.py invocation relaunches itself instead.
set "NEXA_LAUNCHER_BAT=1"

if exist .venv\Scripts\python.exe (
    set PY=.venv\Scripts\python.exe
) else (
    set PY=python
)

:run
%PY% run_chat.py %*
if "%errorlevel%"=="42" (
    echo Restarting Nexa...
    goto run
)
if errorlevel 1 (
    echo.
    if exist "%~dp0.update-rollback" (
        echo The staged update was rolled back. Starting the previous Nexa installation...
        del "%~dp0.update-rollback" >nul 2>&1
        goto run
    )
    echo Nexa exited with an error. See above.
    pause
)
