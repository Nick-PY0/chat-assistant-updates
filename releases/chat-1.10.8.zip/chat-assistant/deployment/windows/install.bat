@echo off
title Nexa - first-time install
cd /d "%~dp0..\.."

echo Creating a private Python environment (.venv)...
python -m venv .venv || goto :err

echo Installing the core packages (small download)...
.venv\Scripts\python.exe -m pip install --upgrade pip >nul
.venv\Scripts\python.exe -m pip install -r requirements.txt || goto :err

echo.
echo Core install done. Nexa can run now (dashboard, timers, key rotation).
echo.
choice /M "Also install the VOICE packages (microphone/wake word, bigger download)"
if errorlevel 2 goto :done
.venv\Scripts\python.exe -m pip install -r requirements-voice.txt || goto :err

echo Downloading the wake word model files (one-time, small)...
.venv\Scripts\python.exe -c "import openwakeword.utils as u; u.download_models()"
if errorlevel 1 echo That download did not finish -- Nexa will try again when it starts.

:done
echo.
echo All set. Start Nexa with run_chat.bat (in the chat-assistant folder).
pause
exit /b 0

:err
echo.
echo Install failed. Make sure Python 3.11+ is installed and on PATH:
echo   https://www.python.org/downloads/  (check "Add python.exe to PATH")
pause
exit /b 1
