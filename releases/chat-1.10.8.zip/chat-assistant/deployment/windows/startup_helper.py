"""Windows per-user Startup registry helper for Nexa.

Manages a per-user ``HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run``
entry that launches ``run_hidden.vbs`` so Nexa starts with Windows without
requiring administrator rights.

Usage (from the chat-assistant root)::

    python deployment/windows/startup_helper.py enable
    python deployment/windows/startup_helper.py disable
    python deployment/windows/startup_helper.py status

All three sub-commands exit 0 on success, 1 on failure, and print a
human-readable message. On non-Windows platforms every command prints a
clear error and exits 1.
"""

from __future__ import annotations

import sys
from pathlib import Path

_ENTRY_NAME = "ChatAssistant"
_ROOT = Path(__file__).resolve().parents[2]
_VBS = _ROOT / "deployment" / "windows" / "run_hidden.vbs"


def _require_windows() -> None:
    if sys.platform != "win32":
        print("ERROR: 'Start with Windows' is only supported on Windows.", file=sys.stderr)
        raise SystemExit(1)


def _run_value() -> str:
    """Absolute command string stored in the registry Run key."""
    vbs = _VBS.resolve()
    return f'wscript.exe "{vbs}"'


def enable() -> int:
    """Create/update the Startup registry entry. No admin required."""
    _require_windows()
    try:
        import winreg  # type: ignore[import]

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE,
        )
        with key:
            winreg.SetValueEx(key, _ENTRY_NAME, 0, winreg.REG_SZ, _run_value())
        print(f"Nexa will start with Windows (entry '{_ENTRY_NAME}' created).")
        return 0
    except OSError as exc:
        print(f"ERROR: could not write to the registry: {exc}", file=sys.stderr)
        return 1


def disable() -> int:
    """Remove the Startup registry entry if it exists."""
    _require_windows()
    try:
        import winreg  # type: ignore[import]

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_SET_VALUE,
        )
        with key:
            try:
                winreg.DeleteValue(key, _ENTRY_NAME)
            except FileNotFoundError:
                pass  # already absent — not an error
        print(f"Nexa will no longer start with Windows (entry '{_ENTRY_NAME}' removed).")
        return 0
    except OSError as exc:
        print(f"ERROR: could not modify the registry: {exc}", file=sys.stderr)
        return 1


def status() -> int:
    """Print whether the Startup entry exists and what command it holds."""
    _require_windows()
    try:
        import winreg  # type: ignore[import]

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_READ,
        )
        with key:
            try:
                value, _ = winreg.QueryValueEx(key, _ENTRY_NAME)
                print(f"enabled  command: {value}")
            except FileNotFoundError:
                print("disabled")
        return 0
    except OSError as exc:
        print(f"ERROR: could not read the registry: {exc}", file=sys.stderr)
        return 1


def _get_status() -> dict:
    """Return a dict suitable for JSON API responses (never raises)."""
    if sys.platform != "win32":
        return {"enabled": False, "supported": False, "error": "not Windows"}
    try:
        import winreg  # type: ignore[import]

        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0,
            winreg.KEY_READ,
        )
        with key:
            try:
                value, _ = winreg.QueryValueEx(key, _ENTRY_NAME)
                return {"enabled": True, "supported": True, "command": value}
            except FileNotFoundError:
                return {"enabled": False, "supported": True}
    except OSError as exc:
        return {"enabled": False, "supported": True, "error": str(exc)}


def main() -> int:
    import argparse

    p = argparse.ArgumentParser(
        prog="startup_helper",
        description="Manage Nexa's per-user Windows Startup entry.",
    )
    p.add_argument("action", choices=["enable", "disable", "status"])
    args = p.parse_args()
    return {"enable": enable, "disable": disable, "status": status}[args.action]()


if __name__ == "__main__":
    raise SystemExit(main())
