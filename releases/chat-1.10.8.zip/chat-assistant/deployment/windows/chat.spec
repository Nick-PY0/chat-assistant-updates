# PyInstaller spec for building Chat.exe (onedir).
# Build on Windows with:  deployment\windows\build_exe.bat
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH).resolve().parents[1]  # SPECPATH = deployment/windows

datas = [
    (str(ROOT / "apps" / "dashboard" / "templates"), "apps/dashboard/templates"),
    (str(ROOT / "apps" / "dashboard" / "static"), "apps/dashboard/static"),
    (
        str(ROOT / "apps" / "dashboard" / "broadcast_policy.json"),
        "apps/dashboard",
    ),
    (str(ROOT / "migrations"), "migrations"),
]
_assets = ROOT / "assets"
if _assets.exists():
    datas.append((str(_assets), "assets"))

hiddenimports = [
    "uvicorn.logging",
    "uvicorn.loops",
    "uvicorn.loops.asyncio",
    "uvicorn.protocols",
    "uvicorn.protocols.http",
    "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl",
    "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto",
    "uvicorn.protocols.websockets.websockets_impl",
    "uvicorn.lifespan",
    "uvicorn.lifespan.on",
    "websockets",
    "aiosqlite",
    "argon2",
]

# Optional voice stack: bundle model/data files only when installed.
for _pkg in ("openwakeword", "vosk", "sounddevice", "numpy"):
    try:
        datas += collect_data_files(_pkg)
        hiddenimports += collect_submodules(_pkg)
    except Exception:
        pass

a = Analysis(
    [str(ROOT / "run_chat.py")],
    pathex=[str(ROOT)],
    datas=datas,
    hiddenimports=hiddenimports,
    excludes=["tkinter", "matplotlib", "PIL", "pytest", "pip", "setuptools"],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Chat",
    console=True,  # Chat lives in a minimal console window on purpose
    disable_windowed_traceback=False,
)

coll = COLLECT(exe, a.binaries, a.datas, name="Chat")
