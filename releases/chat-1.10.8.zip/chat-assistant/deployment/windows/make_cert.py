"""Create HTTPS certificates for LAN dashboard access.

Run from the chat-assistant folder::

    python deployment/windows/make_cert.py

The script keeps a private local certificate-authority key in Nexa's data
folder, writes its public certificate to ``ca-cert.pem``, and signs a fresh
server certificate for localhost, this computer's names, and its current LAN
IPv4 addresses. Install only ``ca-cert.pem`` on devices that should trust the
dashboard. Never copy or install ``ca-key.pem``.
"""

from __future__ import annotations

import datetime
import ipaddress
import socket
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

from cryptography import x509  # noqa: E402
from cryptography.exceptions import InvalidSignature  # noqa: E402
from cryptography.hazmat.primitives import hashes, serialization  # noqa: E402
from cryptography.hazmat.primitives.asymmetric import padding, rsa  # noqa: E402
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID  # noqa: E402

from chat_core.config import load_settings  # noqa: E402


UTC = datetime.timezone.utc
_CA_VALID_DAYS = 3650
_LEAF_VALID_DAYS = 825
_CA_REUSE_MINIMUM = datetime.timedelta(days=30)


@dataclass(frozen=True)
class CertificatePaths:
    """Files created for the dashboard TLS listener."""

    certificate: Path
    private_key: Path
    ca_certificate: Path
    ca_private_key: Path


def _usable_ipv4(value: str) -> ipaddress.IPv4Address | None:
    try:
        address = ipaddress.ip_address(value.split("%", 1)[0])
    except ValueError:
        return None
    if not isinstance(address, ipaddress.IPv4Address):
        return None
    if address.is_unspecified or address.is_multicast:
        return None
    return address


def discover_local_ipv4_addresses() -> list[ipaddress.IPv4Address]:
    """Return loopback and LAN IPv4 addresses visible through local routes.

    Hostname lookup alone is unreliable on Windows: it can return loopback,
    a stale adapter, or nothing at all. In addition to all hostname results,
    UDP route probes ask the OS which local adapter it would use. UDP
    ``connect`` does not send application data, so this also works offline.
    """

    found: set[ipaddress.IPv4Address] = {ipaddress.IPv4Address("127.0.0.1")}
    hosts = {socket.gethostname(), socket.getfqdn()}
    for host in filter(None, hosts):
        try:
            _canonical, _aliases, values = socket.gethostbyname_ex(host)
        except OSError:
            values = []
        for value in values:
            address = _usable_ipv4(value)
            if address is not None:
                found.add(address)

        try:
            results = socket.getaddrinfo(host, None, socket.AF_INET, socket.SOCK_STREAM)
        except OSError:
            results = []
        for result in results:
            address = _usable_ipv4(result[4][0])
            if address is not None:
                found.add(address)

    # Documentation-only destinations are deliberately used for the first
    # probes. No packets are transmitted by a UDP connect, but the route
    # choice still reveals the primary local interface. Public destinations
    # cover networks whose routing table has no route for those ranges.
    for destination in ("192.0.2.1", "198.51.100.1", "8.8.8.8", "1.1.1.1"):
        route = None
        try:
            route = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            route.settimeout(0.2)
            route.connect((destination, 9))
            address = _usable_ipv4(route.getsockname()[0])
            if address is not None:
                found.add(address)
        except OSError:
            pass
        finally:
            if route is not None:
                route.close()

    return sorted(found, key=int)


def _dns_names(hostname: str | None = None) -> list[str]:
    current = (hostname or socket.gethostname()).strip().rstrip(".")
    candidates = ["localhost", current]
    try:
        fqdn = socket.getfqdn(current).strip().rstrip(".")
    except OSError:
        fqdn = ""
    if fqdn:
        candidates.append(fqdn)
    if current and not current.lower().endswith(".local"):
        candidates.append(f"{current}.local")

    names: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        if not candidate:
            continue
        try:
            ascii_name = candidate.encode("idna").decode("ascii")
        except UnicodeError:
            continue
        marker = ascii_name.casefold()
        if marker not in seen:
            names.append(ascii_name)
            seen.add(marker)
    return names


def _public_key_bytes(key: object) -> bytes:
    return key.public_bytes(  # type: ignore[union-attr]
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )


def _certificate_time(cert: x509.Certificate, attribute: str) -> datetime.datetime:
    modern = getattr(cert, f"{attribute}_utc", None)
    if modern is not None:
        return modern
    legacy = getattr(cert, attribute)
    return legacy.replace(tzinfo=UTC)


def _load_reusable_ca(
    cert_path: Path,
    key_path: Path,
    now: datetime.datetime,
) -> tuple[x509.Certificate, rsa.RSAPrivateKey] | None:
    if not cert_path.is_file() or not key_path.is_file():
        return None
    try:
        cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
        key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
        if not isinstance(key, rsa.RSAPrivateKey):
            return None
        if _public_key_bytes(cert.public_key()) != _public_key_bytes(key.public_key()):
            return None
        constraints = cert.extensions.get_extension_for_class(x509.BasicConstraints).value
        usage = cert.extensions.get_extension_for_class(x509.KeyUsage).value
        if not constraints.ca or not usage.key_cert_sign:
            return None
        if _certificate_time(cert, "not_valid_before") > now:
            return None
        if _certificate_time(cert, "not_valid_after") < now + _CA_REUSE_MINIMUM:
            return None
        cert.public_key().verify(
            cert.signature,
            cert.tbs_certificate_bytes,
            padding.PKCS1v15(),
            cert.signature_hash_algorithm,
        )
    except (InvalidSignature, OSError, ValueError, TypeError, x509.ExtensionNotFound):
        return None
    return cert, key


def _create_ca(now: datetime.datetime) -> tuple[x509.Certificate, rsa.RSAPrivateKey]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name(
        [x509.NameAttribute(NameOID.COMMON_NAME, "Chat Assistant Local CA")]
    )
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(days=1))
        .not_valid_after(now + datetime.timedelta(days=_CA_VALID_DAYS))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=False,
                content_commitment=False,
                key_encipherment=False,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=True,
                crl_sign=True,
                encipher_only=None,
                decipher_only=None,
            ),
            critical=True,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
            critical=False,
        )
        .sign(key, hashes.SHA256())
    )
    return cert, key


def _write_private_key(path: Path, key: rsa.RSAPrivateKey) -> None:
    """Write the key with restrictive permissions (owner-read-only on POSIX)."""
    pem = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    )
    path.write_bytes(pem)
    try:
        import stat

        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except (OSError, NotImplementedError):
        pass  # Windows: permissions handled at directory level


def create_certificates(
    data: Path,
    *,
    hostname: str | None = None,
    ip_addresses: Iterable[str | ipaddress.IPv4Address] | None = None,
    now: datetime.datetime | None = None,
) -> CertificatePaths:
    """Create (or refresh) the local CA and a signed server certificate.

    Parameters
    ----------
    data:
        Directory in which all four files are written.  Created if absent.
    hostname:
        Override the system hostname used for DNS SANs (useful in tests).
    ip_addresses:
        Override the list of LAN IPs added as IP SANs.  When *None* the
        live network interfaces are probed.
    now:
        Override "current time" (useful in tests; must be UTC-aware).
    """
    data.mkdir(parents=True, exist_ok=True)

    if now is None:
        current_time = datetime.datetime.now(UTC)
    elif now.tzinfo is None:
        current_time = now.replace(tzinfo=UTC)
    else:
        current_time = now.astimezone(UTC)

    paths = CertificatePaths(
        certificate=data / "cert.pem",
        private_key=data / "key.pem",
        ca_certificate=data / "ca-cert.pem",
        ca_private_key=data / "ca-key.pem",
    )
    reusable = _load_reusable_ca(paths.ca_certificate, paths.ca_private_key, current_time)
    if reusable is None:
        ca_cert, ca_key = _create_ca(current_time)
        paths.ca_certificate.write_bytes(ca_cert.public_bytes(serialization.Encoding.PEM))
        _write_private_key(paths.ca_private_key, ca_key)
    else:
        ca_cert, ca_key = reusable

    values = discover_local_ipv4_addresses() if ip_addresses is None else ip_addresses
    addresses: set[ipaddress.IPv4Address] = {ipaddress.IPv4Address("127.0.0.1")}
    for value in values:
        address = value if isinstance(value, ipaddress.IPv4Address) else _usable_ipv4(str(value))
        if address is not None:
            addresses.add(address)

    names = [x509.DNSName(name) for name in _dns_names(hostname)]
    names.extend(x509.IPAddress(address) for address in sorted(addresses, key=int))

    leaf_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    common_name = (hostname or socket.gethostname()).strip() or "localhost"
    leaf_cert = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, common_name)]))
        .issuer_name(ca_cert.subject)
        .public_key(leaf_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(current_time - datetime.timedelta(days=1))
        .not_valid_after(
            min(
                current_time + datetime.timedelta(days=_LEAF_VALID_DAYS),
                _certificate_time(ca_cert, "not_valid_after") - datetime.timedelta(days=1),
            )
        )
        .add_extension(x509.SubjectAlternativeName(names), critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                content_commitment=False,
                key_encipherment=True,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=None,
                decipher_only=None,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),
            critical=False,
        )
        .add_extension(
            x509.SubjectKeyIdentifier.from_public_key(leaf_key.public_key()),
            critical=False,
        )
        .add_extension(
            x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()),
            critical=False,
        )
        .sign(ca_key, hashes.SHA256())
    )

    # Uvicorn accepts a PEM chain. Supplying the public CA certificate after
    # the leaf gives clients the complete chain without exposing the CA key.
    paths.certificate.write_bytes(
        leaf_cert.public_bytes(serialization.Encoding.PEM)
        + ca_cert.public_bytes(serialization.Encoding.PEM)
    )
    _write_private_key(paths.private_key, leaf_key)
    return paths


def main() -> int:
    settings = load_settings()
    paths = create_certificates(settings.data_path)
    settings.ssl_certfile = str(paths.certificate)
    settings.ssl_keyfile = str(paths.private_key)
    settings.save()
    print(f"Server certificate written to {paths.certificate}")
    print(f"Server key written to         {paths.private_key}")
    print(f"CA certificate written to     {paths.ca_certificate}")
    print("Install ca-cert.pem (never ca-key.pem) on each phone/laptop, then restart Nexa.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
