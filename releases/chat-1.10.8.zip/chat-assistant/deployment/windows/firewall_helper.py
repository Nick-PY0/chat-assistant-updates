"""Windows Defender firewall helper for the Nexa dashboard.

Creates, reports, or removes a narrowly-scoped inbound TCP rule so that
phones on the same LAN can reach the dashboard without opening it to the
internet.

Rule scope (always):
  - Profile:    Private only
  - Protocol:   TCP
  - Direction:  Inbound
  - RemoteIP:   localsubnet (same subnet only, not the internet)
  - LocalPort:  current dashboard_port from settings
  - Name:       Chat Assistant Dashboard

Usage (run as Administrator)::

    python deployment/windows/firewall_helper.py allow
    python deployment/windows/firewall_helper.py status
    python deployment/windows/firewall_helper.py remove

This script NEVER:
  - Disables the firewall.
  - Uses Profile=Any or RemoteIP=Any.
  - Runs automatically at startup.
  - Touches any rule other than "Chat Assistant Dashboard".

On non-Windows platforms every command prints a clear error and exits 1.
This script must be invoked explicitly by the user; it is never called
automatically by run_chat.py or any other Chat module.
"""

from __future__ import annotations

import ipaddress
import subprocess
import sys
from pathlib import Path

RULE_NAME = "Chat Assistant Dashboard"
_CHAT_ROOT = Path(__file__).resolve().parents[2]
_RFC1918_NETWORKS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
)


def _require_windows() -> None:
    if sys.platform != "win32":
        print(
            "ERROR: Windows Defender firewall rules can only be managed on Windows.",
            file=sys.stderr,
        )
        raise SystemExit(1)


def _load_port() -> int:
    """Read dashboard_port from Chat settings without importing the full app."""
    sys.path.insert(0, str(_CHAT_ROOT))
    try:
        from chat_core.config import load_settings

        s = load_settings()
        if s.dashboard_host in ("127.0.0.1", "::1", "localhost"):
            print(
                "ERROR: dashboard_host is set to loopback (127.0.0.1). "
                "Phone access is currently disabled in settings. "
                "Enable it (Settings -> Dashboard access -> On) and restart "
                "Nexa before running this helper.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        return int(s.dashboard_port)
    except ImportError as exc:
        print(
            f"ERROR: could not load Nexa settings ({exc}). "
            "Run this script from the chat-assistant folder.",
            file=sys.stderr,
        )
        raise SystemExit(1)


def _netsh(*args: str) -> "subprocess.CompletedProcess[str]":
    """Run netsh with the given arguments and return the result."""
    cmd = ["netsh", "advfirewall", "firewall"] + list(args)
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=False,
    )


def _active_private_subnets() -> tuple[str, ...]:
    """Return validated RFC1918 CIDRs for active adapters with a gateway."""
    script = (
        "Get-NetIPConfiguration | "
        "Where-Object { $_.NetAdapter.Status -eq 'Up' -and "
        "$null -ne $_.IPv4DefaultGateway } | "
        "ForEach-Object { $_.IPv4Address | ForEach-Object { "
        "'{0}/{1}' -f $_.IPAddress, $_.PrefixLength } }"
    )
    try:
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                script,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return ()
    if result.returncode != 0:
        return ()

    safe: set[ipaddress.IPv4Network] = set()
    for raw in result.stdout.splitlines():
        candidate = raw.strip()
        if not candidate:
            continue
        try:
            interface = ipaddress.ip_interface(candidate)
        except ValueError:
            continue
        if not isinstance(interface, ipaddress.IPv4Interface):
            continue
        network = interface.network
        if any(network.subnet_of(private) for private in _RFC1918_NETWORKS):
            safe.add(network)
    return tuple(
        str(network)
        for network in sorted(
            safe,
            key=lambda item: (int(item.network_address), item.prefixlen),
        )
    )


def _add_rule(port: int, remote_ip: str) -> "subprocess.CompletedProcess[str]":
    return _netsh(
        "add",
        "rule",
        f"name={RULE_NAME}",
        "dir=in",
        "action=allow",
        "protocol=TCP",
        f"localport={port}",
        "profile=private",
        f"remoteip={remote_ip}",
        "enable=yes",
        f"description=Chat dashboard LAN access port {port}",
    )


def _delete_rule_confirmed() -> tuple[bool, "subprocess.CompletedProcess[str]"]:
    """Delete the named rule and require success or an explicit no-match reply."""
    result = _netsh("delete", "rule", f"name={RULE_NAME}")
    output = f"{result.stdout}\n{result.stderr}".lower()
    absent = "no rules match" in output or "no rule matches" in output
    return result.returncode == 0 or absent, result


def allow() -> int:
    """Create or replace the Nexa firewall rule (requires Administrator)."""
    _require_windows()
    port = _load_port()

    # Remove any existing rule with the same name first (idempotent).
    clean, cleanup = _delete_rule_confirmed()
    if not clean:
        print(
            "ERROR: Nexa could not remove the existing firewall rule before "
            "creating its replacement.\n"
            f"{cleanup.stdout.strip()}\n{cleanup.stderr.strip()}",
            file=sys.stderr,
        )
        return 1

    # Prefer Windows' own same-subnet keyword. Some builds list this keyword
    # in their help yet still reject it; those systems get a validated,
    # explicit RFC1918 CIDR list instead, never a broad "any" fallback.
    result = _add_rule(port, "localsubnet")

    if result.returncode == 0:
        print(
            f"Firewall rule created: TCP port {port}, Private profile,"
            f" RemoteIP=localsubnet. Phone must be on the same Wi-Fi network."
        )
        return 0

    # A failed add is not proof that Windows created nothing. Confirm cleanup
    # before discovery, retry, or returning a failure.
    clean, cleanup = _delete_rule_confirmed()
    if not clean:
        print(
            f"ERROR: netsh returned exit code {result.returncode}, and Nexa "
            "could not confirm cleanup of the failed firewall rule.\n"
            f"{cleanup.stdout.strip()}\n{cleanup.stderr.strip()}",
            file=sys.stderr,
        )
        return 1

    subnets = _active_private_subnets()
    if subnets:
        explicit_remote = ",".join(subnets)
        retry = _add_rule(port, explicit_remote)
        if retry.returncode == 0:
            print(
                f"Firewall rule created: TCP port {port}, Private profile, "
                f"RemoteIP={explicit_remote}. Windows rejected the LocalSubnet "
                "keyword, so Chat used the active private LAN subnet explicitly."
            )
            return 0
        clean, cleanup = _delete_rule_confirmed()
        if not clean:
            print(
                f"ERROR: netsh returned exit code {retry.returncode}, and Nexa "
                "could not confirm cleanup of the failed firewall rule.\n"
                f"{cleanup.stdout.strip()}\n{cleanup.stderr.strip()}",
                file=sys.stderr,
            )
            return 1
        result = retry

    print(
        f"ERROR: netsh returned exit code {result.returncode}.\n"
        f"{result.stdout.strip()}\n{result.stderr.strip()}",
        file=sys.stderr,
    )
    if not subnets:
        print(
            "Windows rejected the LocalSubnet keyword, and Nexa could not "
            "identify an active private IPv4 subnet for a safe retry.",
            file=sys.stderr,
        )
    print(
        "Make sure you are running as Administrator"
        " (right-click -> Run as administrator).",
        file=sys.stderr,
    )
    return 1


def status() -> int:
    """Print whether the Nexa firewall rule exists and what it contains."""
    _require_windows()
    result = _netsh(
        "show",
        "rule",
        f"name={RULE_NAME}",
    )
    output = result.stdout.strip()
    if "No rules match the specified criteria" in output or result.returncode != 0:
        print(f'Rule "{RULE_NAME}" does not exist.')
        return 0
    print(output)
    return 0


def remove() -> int:
    """Delete the Nexa firewall rule if it exists."""
    _require_windows()
    result = _netsh("delete", "rule", f"name={RULE_NAME}")
    if result.returncode == 0:
        print(f'Rule "{RULE_NAME}" removed.')
        return 0
    # netsh returns non-zero when no rule matched — treat as success
    if "No rules match" in result.stdout or "No rules match" in result.stderr:
        print(f'Rule "{RULE_NAME}" was not present.')
        return 0
    print(
        f"ERROR: netsh returned exit code {result.returncode}.\n"
        f"{result.stdout.strip()}\n{result.stderr.strip()}",
        file=sys.stderr,
    )
    return 1


def main() -> int:
    import argparse

    p = argparse.ArgumentParser(
        prog="firewall_helper",
        description=(
            "Manage the Nexa dashboard's Windows Defender firewall rule. "
            "Run as Administrator."
        ),
    )
    p.add_argument(
        "action",
        choices=["allow", "status", "remove"],
        help=(
            "allow: create/replace the inbound rule; "
            "status: show current rule; "
            "remove: delete the rule"
        ),
    )
    args = p.parse_args()
    return {"allow": allow, "status": status, "remove": remove}[args.action]()


if __name__ == "__main__":
    raise SystemExit(main())
