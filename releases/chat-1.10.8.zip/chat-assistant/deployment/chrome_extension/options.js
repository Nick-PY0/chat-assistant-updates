// options.js — pairing page logic.
//
// The pairing token is NEVER persisted — it is held only in memory in this
// page while the user types and is cleared from the DOM immediately after
// the background worker sends the hello frame. Only the bridge base URL is
// stored. The bridge secret is written by the background worker after the
// server issues it.

import {
  COMPANION_WS_PATH,
  STORAGE_KEYS,
  MSG,
  validateBridgeBase,
  validatePairingToken,
} from "./common.js";

const $ = (id) => document.getElementById(id);
const bridgeEl      = $("bridge");
const tokenEl       = $("token");
const showTokenEl   = $("showToken");
const msgEl         = $("msg");
const statusEl      = $("status");
const statusDetail  = $("statusDetail");

function setMsg(text, kind) {
  msgEl.textContent = text || "";
  msgEl.className   = "msg" + (kind ? " " + kind : "");
}

// A wss:// bridge address is the single most common pairing failure: Nexa can
// run the dashboard as HTTPS with its own local certificate, and a browser
// extension has no way to approve that certificate — the socket just fails.
// Nexa serves the companion bridge on a separate plain ws:// loopback port for
// exactly this reason, so point the user at it instead of leaving them with
// "unreachable".
function bridgeFailureHint(base) {
  if (String(base || "").toLowerCase().startsWith("wss://")) {
    return (
      " This address uses wss://. Chrome cannot accept Nexa's own local " +
      "certificate here, so use the plain ws:// bridge address shown in " +
      "Nexa Settings → YouTube companion extension."
    );
  }
  return " Check that Nexa is running on this computer and that the address " +
         "matches the one shown in Nexa Settings → YouTube companion extension.";
}

showTokenEl.addEventListener("change", () => {
  tokenEl.type = showTokenEl.checked ? "text" : "password";
});

function sendToBg(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(message, (resp) => {
        // Reading lastError inside the callback is required by Chrome. The old
        // code discarded it, which turned a useful service-worker error into
        // the unhelpful “unknown” shown on the options page.
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          resolve({
            ok: false,
            reason: "extension service worker error: " +
              (runtimeError.message || "no response"),
          });
          return;
        }
        resolve(resp || {
          ok: false,
          reason: "extension service worker returned no response",
        });
      });
    } catch (error) {
      resolve({
        ok: false,
        reason: "extension messaging error: " +
          (error && error.message ? error.message : String(error)),
      });
    }
  });
}

// The reachability check deliberately runs in this extension page rather than
// passing a four-second WebSocket probe through the service worker's one-shot
// runtime message channel. On some Chrome builds the worker can be suspended
// while that channel is waiting, producing "The message port closed before a
// response was received" even though the loopback bridge is available.
//
// This sends no token or secret. It is allowed only because the manifest grants
// this extension access to the two loopback hosts and validateBridgeBase() has
// already restricted the supplied address to one of them.
function probeBridgeFromOptions(base) {
  const wsUrl = (base + COMPANION_WS_PATH)
    .replace(/^http:/, "ws:")
    .replace(/^https:/, "wss:");
  return new Promise((resolve) => {
    let socket;
    let finished = false;
    const finish = (ok, reason) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      try { socket && socket.close(); } catch (_e) {}
      resolve({ ok, reason });
    };
    const timer = setTimeout(
      () => finish(false, "timed out waiting for the local bridge"),
      4000,
    );
    try {
      socket = new WebSocket(wsUrl);
    } catch (error) {
      finish(
        false,
        "browser could not open the local WebSocket: " +
          (error && error.message ? error.message : String(error)),
      );
      return;
    }
    // A completed WebSocket opening handshake proves the bridge is listening.
    // Closing immediately keeps this check tokenless and side-effect free.
    socket.addEventListener("open", () => finish(true, "reachable"));
    socket.addEventListener("error", () => finish(
      false,
      "browser could not reach the local WebSocket",
    ));
    socket.addEventListener("close", () => finish(
      false,
      "the local bridge closed the connection before it opened",
    ));
  });
}

async function loadBridgeBase() {
  const d = await chrome.storage.local.get([STORAGE_KEYS.bridgeBase]);
  if (d[STORAGE_KEYS.bridgeBase] && !bridgeEl.value) {
    bridgeEl.value = d[STORAGE_KEYS.bridgeBase];
  }
}

let statusRequestSequence = 0;

async function loadStatus() {
  const requestSequence = ++statusRequestSequence;
  const res = await sendToBg({ type: MSG.GET_STATUS });
  if (requestSequence !== statusRequestSequence) return;
  const s   = (res && res.status) || {};
  if (s.paired && s.connected) {
    statusEl.textContent = "Connected";
    statusEl.className   = "status good";
    statusDetail.textContent = s.detail ? "Bridge: " + s.detail : "Ready.";
  } else if (s.paired && !s.connected) {
    statusEl.textContent = "Paired · reconnecting";
    statusEl.className   = "status warn";
    statusDetail.textContent = s.detail || "Trying to reach the bridge…";
  } else {
    statusEl.textContent = "Not paired";
    statusEl.className   = "status";
    statusDetail.textContent = s.detail || "Enter the bridge URL and pairing token above.";
  }
}

$("test").addEventListener("click", async () => {
  setMsg("Testing connection…");
  let base;
  try { base = validateBridgeBase(bridgeEl.value); } catch (e) { return setMsg(e.message, "err"); }
  const res = await probeBridgeFromOptions(base);
  if (res && res.ok) setMsg("Bridge reachable at /ws/companion", "ok");
  else {
    setMsg(
      "Could not reach bridge: " + ((res && res.reason) || "unknown") +
      "." + bridgeFailureHint(base),
      "err",
    );
  }
});

$("pair").addEventListener("click", async () => {
  setMsg("");
  let base, token;
  try   { base  = validateBridgeBase(bridgeEl.value); }
  catch (e) { return setMsg(e.message, "err"); }
  try   { token = validatePairingToken(tokenEl.value); }
  catch (e) { return setMsg(e.message, "err"); }

  // Store the bridge base URL. The token is NEVER stored.
  await chrome.storage.local.set({ [STORAGE_KEYS.bridgeBase]: base });

  // Clear the token field immediately — it goes only to the background worker
  // in memory, never to storage.
  tokenEl.value         = "";
  showTokenEl.checked   = false;
  tokenEl.type          = "password";

  // Ask the background worker to open the socket and send hello(token).
  const res = await sendToBg({ type: MSG.PAIR, token, bridgeBase: base });
  if (res && res.ok) {
    setMsg("Pairing initiated. Status will update below when the bridge confirms.", "ok");
  } else {
    setMsg("Background worker did not accept the request: " + ((res && res.reason) || ""), "warn");
  }
  setTimeout(loadStatus, 800);
  setTimeout(loadStatus, 2500);
});

$("unpair").addEventListener("click", async () => {
  await sendToBg({ type: MSG.UNPAIR });
  bridgeEl.value = "";
  setMsg("Unpaired. Remember to revoke the token in the Nexa dashboard.", "ok");
  loadStatus();
});

loadBridgeBase();
loadStatus();
setInterval(loadStatus, 3000);
