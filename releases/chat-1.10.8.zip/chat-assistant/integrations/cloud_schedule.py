"""Purpose-scoped client for the authoritative Replit Jarvis schedule API."""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import re
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

import httpx


PURPOSE_MESSAGE = b"jarvis-scheduler:v1"


class CloudScheduleError(Exception):
    """A schedule service failure which is safe to show to the user."""

    def __init__(
        self, message: str, *, status: int = 503, code: str = "cloud_schedule_error"
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code


def schedule_origin(value: str) -> str:
    parsed = urlparse(str(value or "").strip())
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or parsed.path not in ("", "/")
    ):
        raise CloudScheduleError(
            "The Relay address must be an HTTPS origin without a path.",
            status=400,
        )
    return f"https://{parsed.netloc}"


class CloudScheduleClient:
    """Narrow HTTP client; it never receives or sends the dashboard password."""

    def __init__(
        self,
        relay_url: str,
        relay_secret: str,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout: float = 15.0,
    ) -> None:
        self.origin = schedule_origin(relay_url)
        self.base = self.origin + "/api/jarvis"
        self._token = hmac.new(
            relay_secret.encode(), PURPOSE_MESSAGE, hashlib.sha256
        ).hexdigest()
        self._transport = transport
        self._timeout = timeout

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        body: dict | None = None,
        idempotency_key: str | None = None,
        expected_version: int | None = None,
    ):
        headers = {"Authorization": f"Bearer {self._token}", "Accept": "application/json"}
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        if expected_version is not None:
            headers["If-Match-Version"] = str(expected_version)
        # A retry uses exactly the same idempotency key.  Never fall back to
        # SQLite after an uncertain cloud write.
        attempts = 2 if idempotency_key else 1
        for attempt in range(attempts):
            try:
                async with httpx.AsyncClient(
                    transport=self._transport,
                    timeout=self._timeout,
                    follow_redirects=False,
                ) as client:
                    response = await client.request(
                        method, self.base + path, params=params, json=body, headers=headers
                    )
                if 300 <= response.status_code < 400:
                    raise CloudScheduleError("The schedule service returned an unsafe redirect.")
                if response.status_code >= 400:
                    try:
                        detail = response.json()
                    except ValueError:
                        detail = {}
                    error_value = detail.get("error") if isinstance(detail, dict) else None
                    message = (
                        error_value.get("message")
                        if isinstance(error_value, dict)
                        else error_value
                    ) or (detail.get("message") if isinstance(detail, dict) else None)
                    code = (
                        error_value.get("code")
                        if isinstance(error_value, dict)
                        else detail.get("code") if isinstance(detail, dict) else None
                    )
                    raise CloudScheduleError(
                        str(message or f"Schedule service rejected the request ({response.status_code})."),
                        status=response.status_code,
                        code=str(code or (
                            "version_conflict"
                            if response.status_code == 409
                            else "cloud_schedule_rejected"
                        )),
                    )
                if response.status_code == 204:
                    return {"ok": True}
                try:
                    return response.json()
                except ValueError as exc:
                    raise CloudScheduleError("The schedule service returned invalid data.") from exc
            except CloudScheduleError:
                raise
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                if attempt + 1 < attempts:
                    await asyncio.sleep(0)
                    continue
                raise CloudScheduleError(
                    "The cloud schedule is unavailable. Nothing was saved locally.",
                    code="cloud_schedule_unavailable",
                ) from exc

    async def create_item(self, payload: dict, *, idempotency_key: str | None = None):
        key = idempotency_key or uuid.uuid4().hex
        body = dict(payload)
        # The API's idempotency table protects ordinary retries; the stable
        # caller UUID additionally makes a retry after a client restart safe.
        body.setdefault(
            "id", str(uuid.uuid5(uuid.NAMESPACE_URL, f"jarvis-scheduler:{key}"))
        )
        return await self._request(
            "POST", "/items", body=body, idempotency_key=key,
        )

    async def agenda(self, from_value: str, to_value: str):
        return await self._request("GET", "/agenda", params={"from": from_value, "to": to_value})

    async def current(self):
        result = await self._request("GET", "/agenda/current-next")
        return {"current": result.get("current")} if isinstance(result, dict) else result

    async def next(self):
        result = await self._request("GET", "/agenda/current-next")
        return {"next": result.get("next")} if isinstance(result, dict) else result

    async def search(self, query: str):
        return await self._request("GET", "/search", params={"q": query})

    async def school_day(self, date: str | None = None):
        return await self._request("GET", "/school/day", params={"date": date} if date else None)

    async def update_item(
        self, item_id: str, expected_version: int, changes: dict,
        *, idempotency_key: str | None = None,
    ):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", item_id):
            raise CloudScheduleError("Invalid schedule item ID.", status=400)
        return await self._request(
            "PATCH",
            f"/items/{item_id}",
            body={"expectedVersion": expected_version, "patch": changes},
            idempotency_key=idempotency_key or uuid.uuid4().hex,
            expected_version=expected_version,
        )

    async def cancel_item(
        self, item_id: str, expected_version: int, *, idempotency_key: str | None = None
    ):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", item_id):
            raise CloudScheduleError("Invalid schedule item ID.", status=400)
        return await self._request(
            "POST",
            f"/items/{item_id}/cancel",
            body={"expectedVersion": expected_version},
            idempotency_key=idempotency_key or uuid.uuid4().hex,
            expected_version=expected_version,
        )

    async def complete_item(
        self, item_id: str, expected_version: int, *, idempotency_key: str | None = None
    ):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", item_id):
            raise CloudScheduleError("Invalid schedule item ID.", status=400)
        return await self._request(
            "POST",
            f"/items/{item_id}/complete",
            body={"expectedVersion": expected_version},
            idempotency_key=idempotency_key or uuid.uuid4().hex,
            expected_version=expected_version,
        )

    async def ticket(self):
        return await self._request(
            "POST", "/tickets", body={}, idempotency_key=uuid.uuid4().hex
        )


class CloudScheduleService:
    """Loads Relay material from the encrypted CredentialStore only when used."""

    def __init__(self, settings, credentials, *, client_factory=CloudScheduleClient) -> None:
        self.settings = settings
        self.credentials = credentials
        self.client_factory = client_factory

    @property
    def enabled(self) -> bool:
        return bool(getattr(self.settings, "cloud_schedule_enabled", False))

    async def client(self) -> CloudScheduleClient:
        if not self.enabled:
            raise CloudScheduleError("Cloud scheduling is not enabled.")
        url = str(getattr(self.settings, "relay_url", "") or "").strip()
        if not url:
            raise CloudScheduleError("Configure the HTTPS Relay address first.")
        credentials = await self.credentials.list("relay") if self.credentials else []
        credential = next(
            (item for item in credentials if item.status not in {"disabled", "invalid"}), None
        )
        if credential is None:
            raise CloudScheduleError("Add an active Relay credential under Providers first.")
        secret = await self.credentials.get_secret(credential.id)
        return self.client_factory(url, secret)

    async def dispatch(self, name: str, args: dict):
        client = await self.client()
        if name in {"create_event", "create_reminder", "create_alarm"}:
            item_type = name.removeprefix("create_")
            title = " ".join(str(args.get("title") or args.get("message") or "").split())
            start = str(args.get("start") or args.get("start_at") or "").strip()
            timezone_name = str(args.get("timezone") or "").strip()
            if not title:
                raise CloudScheduleError("What should I call it?", status=400)
            if not start or not timezone_name:
                raise CloudScheduleError(
                    "Please give an unambiguous date, time, AM or PM, and timezone before I save it.",
                    status=400,
                )
            payload = {
                key: value for key, value in {
                    "type": item_type, "title": title, "startAt": start,
                    "endAt": args.get("end") or args.get("end_at"),
                    "timezone": timezone_name,
                    "recurrence": args.get("recurrence"),
                    "notifications": args.get("notifications") or [],
                    "priority": args.get("priority") or "normal",
                    "ringPolicy": (
                        args.get("ring_policy")
                        or ("alarm" if item_type == "alarm" else "default")
                    ),
                    "status": "active", "source": "voice",
                    "metadata": {},
                }.items() if value is not None
            }
            result = await client.create_item(
                payload, idempotency_key=str(args.get("idempotency_key") or "") or None
            )
            if isinstance(result, dict):
                result.setdefault("summary", f"Saved {title} to your cloud schedule.")
                result.setdefault("phone_acknowledged", False)
            return result
        if name == "list_schedule":
            from_value = str(args.get("from") or "").strip()
            to_value = str(args.get("to") or "").strip()
            if not from_value or not to_value:
                raise CloudScheduleError("Please specify the schedule date range.", status=400)
            return await client.agenda(from_value, to_value)
        if name == "get_current_item":
            return await client.current()
        if name == "get_next_item":
            return await client.next()
        if name == "search_schedule":
            query = " ".join(str(args.get("query") or "").split())
            if not query:
                raise CloudScheduleError("What should I search the schedule for?", status=400)
            return await client.search(query)
        if name == "get_school_day":
            return await client.school_day(str(args.get("date") or "").strip() or None)
        if name in {"update_item", "cancel_item", "complete_item"}:
            item_id = str(args.get("id") or "").strip()
            version = args.get("expectedVersion", args.get("expected_version"))
            if not item_id or isinstance(version, bool) or not isinstance(version, int):
                raise CloudScheduleError(
                    "First identify exactly one schedule item and provide its current ID and version.",
                    status=400,
                )
            if name == "cancel_item":
                return await client.cancel_item(
                    item_id, version,
                    idempotency_key=str(args.get("idempotency_key") or "") or None,
                )
            if name == "complete_item":
                return await client.complete_item(
                    item_id, version,
                    idempotency_key=str(args.get("idempotency_key") or "") or None,
                )
            changes = (
                dict(args.get("changes") or {})
                if name == "update_item" else {}
            )
            if not changes:
                raise CloudScheduleError("Say what should change.", status=400)
            return await client.update_item(
                item_id, version, changes,
                idempotency_key=str(args.get("idempotency_key") or "") or None,
            )
        raise CloudScheduleError("Unknown cloud schedule operation.", status=400)

    async def legacy_reminder(self, args: dict):
        at_local = str(args.get("at_local") or "").strip()
        timezone_name = str(args.get("timezone") or "").strip()
        if not at_local or not timezone_name:
            raise CloudScheduleError(
                "Cloud scheduling needs the full date, time, AM or PM, and timezone. Please clarify.",
                status=400,
            )
        name = "create_alarm" if str(args.get("kind") or "").lower() == "alarm" else "create_reminder"
        return await self.dispatch(name, {
            "title": args.get("message") or name.removeprefix("create_"),
            "start": at_local,
            "timezone": timezone_name,
        })

    async def legacy_list(self):
        now = datetime.now(timezone.utc)
        return await (await self.client()).agenda(
            now.isoformat(), (now + timedelta(days=365)).isoformat()
        )