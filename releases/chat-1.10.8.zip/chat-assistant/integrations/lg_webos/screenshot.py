"""Safe, transient retrieval of one LG webOS screen capture.

The TV returns an ``imageUri`` for ``ssap://tv/executeOneShot``. Treat that
URI as hostile even though it arrived over the paired control channel: only a
same-TV HTTP(S) URL on the webOS ports is fetched, redirects and environment
proxies are disabled, and the response must be a small JPEG.
"""

from __future__ import annotations

import asyncio
import ipaddress
from urllib.parse import urlsplit, urlunsplit

import httpx


MAX_SCREENSHOT_BYTES = 2_000_000
MAX_SCREENSHOT_PIXELS = 8_000_000
MAX_SCREENSHOT_EDGE = 4096
SCREENSHOT_TOTAL_TIMEOUT = 10.0
_ALLOWED_PORTS = {80, 443, 3000, 3001}
_START_OF_FRAME_MARKERS = frozenset({
    0xC0, 0xC1, 0xC2, 0xC3,
    0xC5, 0xC6, 0xC7,
    0xC9, 0xCA, 0xCB,
    0xCD, 0xCE, 0xCF,
})


class TVScreenshotError(Exception):
    """A screenshot failure whose message is safe to expose."""


def validate_tv_screenshot_url(value: str, expected_host: str) -> str:
    raw = str(value or "").strip()
    if not raw or len(raw) > 2048:
        raise TVScreenshotError("the TV did not provide a usable screen image")
    try:
        parsed = urlsplit(raw)
        port = parsed.port
    except ValueError:
        raise TVScreenshotError(
            "the TV provided an invalid screen image address"
        ) from None

    host = str(parsed.hostname or "").rstrip(".").casefold()
    expected = str(expected_host or "").strip().rstrip(".").casefold()
    if (
        parsed.scheme not in ("http", "https")
        or not host
        or host != expected
        or parsed.username is not None
        or parsed.password is not None
        or parsed.fragment
        or (port is not None and port not in _ALLOWED_PORTS)
        or not parsed.path.startswith("/")
    ):
        raise TVScreenshotError("the TV provided an unsafe screen image address")
    return raw


def _validated_peer_ip(expected_peer: str, expected_host: str) -> ipaddress._BaseAddress:
    try:
        peer = ipaddress.ip_address(str(expected_peer or "").split("%", 1)[0])
    except ValueError:
        raise TVScreenshotError(
            "the TV screen image could not be bound to the paired TV"
        ) from None
    if (
        peer.is_loopback
        or peer.is_multicast
        or peer.is_unspecified
        or peer.is_reserved
        or peer.is_global
    ):
        raise TVScreenshotError("the paired TV does not have a safe local address")
    try:
        configured_ip = ipaddress.ip_address(str(expected_host or "").strip())
    except ValueError:
        configured_ip = None
    if configured_ip is not None and configured_ip != peer:
        raise TVScreenshotError(
            "the TV screen image address did not match the paired TV"
        )
    return peer


def validate_jpeg_bytes(image: bytes) -> tuple[int, int]:
    """Validate a bounded JPEG container and return ``(width, height)``.

    This intentionally parses only the marker structure needed to establish
    that a complete, reasonably sized image reached a scan. The AI provider
    remains the decoder; malformed/polyglot prefixes are rejected locally.
    """
    if (
        not isinstance(image, bytes)
        or len(image) < 12
        or len(image) > MAX_SCREENSHOT_BYTES
        or not image.startswith(b"\xff\xd8")
        or not image.endswith(b"\xff\xd9")
    ):
        raise TVScreenshotError("the TV did not return a complete JPEG screen image")

    offset = 2
    width = height = 0
    saw_scan = False
    while offset < len(image) - 2:
        if image[offset] != 0xFF:
            raise TVScreenshotError("the TV returned a malformed JPEG screen image")
        while offset < len(image) and image[offset] == 0xFF:
            offset += 1
        if offset >= len(image):
            break
        marker = image[offset]
        offset += 1
        if marker == 0xD9:
            break
        if marker == 0xD8 or marker == 0x01 or 0xD0 <= marker <= 0xD7:
            continue
        if offset + 2 > len(image):
            raise TVScreenshotError("the TV returned a malformed JPEG screen image")
        segment_length = int.from_bytes(image[offset:offset + 2], "big")
        if segment_length < 2 or offset + segment_length > len(image):
            raise TVScreenshotError("the TV returned a malformed JPEG screen image")
        segment = image[offset + 2:offset + segment_length]
        if marker in _START_OF_FRAME_MARKERS:
            if len(segment) < 6:
                raise TVScreenshotError("the TV returned a malformed JPEG screen image")
            height = int.from_bytes(segment[1:3], "big")
            width = int.from_bytes(segment[3:5], "big")
        if marker == 0xDA:
            saw_scan = True
            break
        offset += segment_length

    if (
        not saw_scan
        or width <= 0
        or height <= 0
        or width > MAX_SCREENSHOT_EDGE
        or height > MAX_SCREENSHOT_EDGE
        or width * height > MAX_SCREENSHOT_PIXELS
    ):
        raise TVScreenshotError(
            "the TV returned an invalid or oversized JPEG screen image"
        )
    return width, height


async def fetch_tv_screenshot(
    url: str,
    expected_host: str,
    expected_peer: str,
    *,
    transport: httpx.AsyncBaseTransport | None = None,
) -> bytes:
    safe_url = validate_tv_screenshot_url(url, expected_host)
    parsed = urlsplit(safe_url)
    peer = _validated_peer_ip(expected_peer, expected_host)
    peer_host = f"[{peer.compressed}]" if peer.version == 6 else peer.compressed
    peer_netloc = (
        f"{peer_host}:{parsed.port}"
        if parsed.port is not None
        else peer_host
    )
    pinned_url = urlunsplit((
        parsed.scheme,
        peer_netloc,
        parsed.path,
        parsed.query,
        "",
    ))
    timeout = httpx.Timeout(5.0, connect=4.0)
    try:
        async with asyncio.timeout(SCREENSHOT_TOTAL_TIMEOUT):
            async with httpx.AsyncClient(
                verify=False,
                follow_redirects=False,
                trust_env=False,
                timeout=timeout,
                transport=transport,
            ) as client:
                async with client.stream(
                    "GET",
                    pinned_url,
                    headers={
                        "Accept": "image/jpeg",
                        "Host": parsed.netloc,
                    },
                ) as response:
                    if 300 <= response.status_code < 400:
                        raise TVScreenshotError(
                            "the TV redirected its screen image unexpectedly"
                        )
                    if response.status_code != 200:
                        raise TVScreenshotError(
                            "the TV screen image could not be downloaded"
                        )
                    length = response.headers.get("content-length")
                    if length:
                        try:
                            if int(length) > MAX_SCREENSHOT_BYTES:
                                raise TVScreenshotError(
                                    "the TV screen image was too large"
                                )
                        except ValueError:
                            raise TVScreenshotError(
                                "the TV returned an invalid screen image size"
                            ) from None
                    data = bytearray()
                    async for chunk in response.aiter_bytes():
                        data.extend(chunk)
                        if len(data) > MAX_SCREENSHOT_BYTES:
                            raise TVScreenshotError(
                                "the TV screen image was too large"
                            )
    except TVScreenshotError:
        raise
    except TimeoutError:
        raise TVScreenshotError("the TV screen image download timed out") from None
    except httpx.HTTPError:
        raise TVScreenshotError(
            "the TV screen image could not be downloaded"
        ) from None

    image = bytes(data)
    validate_jpeg_bytes(image)
    return image