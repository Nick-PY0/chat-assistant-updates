from __future__ import annotations

import copy
from types import SimpleNamespace

import pytest

from apps.tool_service.tv_screen_recognizer import (
    SCREEN_ACCOUNT_CHOOSER,
    SCREEN_OTHER,
    SCREEN_YOUTUBE_HOME,
    TVScreenRecognitionError,
    TVScreenRecognizer,
)


JPEG = (
    b"\xff\xd8"
    b"\xff\xe0\x00\x02"
    b"\xff\xc0\x00\x11\x08\x00\x01\x00\x01\x03"
    b"\x01\x11\x00\x02\x11\x00\x03\x11\x00"
    b"\xff\xda\x00\x0c\x03\x01\x00\x02\x11\x03\x11\x00\x3f\x00"
    b"\x00\xff\xd9"
)


def _response(label):
    return {
        "id": "resp_tv",
        "model": "gpt-5-mini",
        "status": "completed",
        "output": [{
            "type": "message",
            "content": [{
                "type": "output_text",
                "text": label,
                "annotations": [],
            }],
        }],
    }


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "label",
    (SCREEN_ACCOUNT_CHOOSER, SCREEN_YOUTUBE_HOME, SCREEN_OTHER),
)
async def test_recognizer_uses_encrypted_openai_credential_and_exact_labels(
    store, label
):
    credential = await store.add("openai", "secret-value", purpose="text")
    await store.set_status(credential.id, "active")
    seen = {}

    class Client:
        def __init__(self, secret):
            seen["secret"] = secret

        async def create(self, payload):
            seen["payload"] = copy.deepcopy(payload)
            return _response(label)

    recognizer = TVScreenRecognizer(
        SimpleNamespace(openai_text_model="gpt-5-mini"),
        store,
        client_factory=Client,
    )
    assert await recognizer.classify(JPEG) == label
    assert seen["secret"] == "secret-value"
    request = seen["payload"]
    assert request["model"] == "gpt-5-mini"
    assert request["max_output_tokens"] == 32
    image = request["input"][0]["content"][1]
    assert image["image_url"].startswith("data:image/jpeg;base64,")
    assert "secret-value" not in str(request)


@pytest.mark.asyncio
async def test_recognizer_rejects_bad_images_and_uncertain_or_raw_provider_errors(
):
    class Store:
        async def list(self, provider=None):
            return [SimpleNamespace(
                id="key-1",
                status="active",
                retry_after=None,
            )]

        async def get_secret(self, credential_id):
            return "provider-secret"

    class BadLabelClient:
        def __init__(self, _secret):
            pass

        async def create(self, _payload):
            return _response("The account chooser is visible")

    recognizer = TVScreenRecognizer(
        SimpleNamespace(openai_text_model="gpt-5-mini"),
        Store(),
        client_factory=BadLabelClient,
    )
    with pytest.raises(TVScreenRecognitionError, match="invalid"):
        await recognizer.classify(b"not-jpeg")
    with pytest.raises(TVScreenRecognitionError, match="uncertain"):
        await recognizer.classify(JPEG)

    class FailingClient:
        def __init__(self, _secret):
            pass

        async def create(self, _payload):
            raise RuntimeError("provider-secret and screen text")

    failing = TVScreenRecognizer(
        SimpleNamespace(openai_text_model="gpt-5-mini"),
        Store(),
        client_factory=FailingClient,
    )
    with pytest.raises(TVScreenRecognitionError) as caught:
        await failing.classify(JPEG)
    assert "provider-secret" not in str(caught.value)
    assert "screen text" not in str(caught.value)
    assert caught.value.__cause__ is None


@pytest.mark.asyncio
async def test_recognizer_fails_cleanly_without_an_openai_credential(monkeypatch):
    monkeypatch.delenv("AI_INTEGRATIONS_OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("AI_INTEGRATIONS_OPENAI_BASE_URL", raising=False)

    class EmptyStore:
        async def list(self, provider=None):
            return []

    recognizer = TVScreenRecognizer(
        SimpleNamespace(openai_text_model="gpt-5-mini"),
        EmptyStore(),
    )
    with pytest.raises(TVScreenRecognitionError, match="not configured"):
        await recognizer.classify(JPEG)