"""New dashboard endpoints: stop, memories, updates, restart, expanded settings."""

from __future__ import annotations

import asyncio
import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def login(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    token = client.cookies.get(COOKIE)
    return {"x-csrf": client.app.state.sessions.csrf_for(token)}


async def test_new_apis_require_auth(client):
    for path in ("/api/stop", "/api/update/check", "/api/update/install", "/api/restart", "/api/memories"):
        resp = await client.post(path, json={})
        assert resp.status_code == 401, path
    resp = await client.get("/memory")
    assert resp.status_code == 303  # page redirects to setup/login


async def test_stop_endpoint(client, rt):
    headers = await login(client)
    resp = await client.post("/api/stop", json={}, headers=headers)
    assert resp.status_code == 200
    assert resp.json()["ok"] is True


async def test_memories_crud(client):
    headers = await login(client)
    r = await client.post("/api/memories", json={"content": "the garage code is 4417"}, headers=headers)
    assert r.status_code == 200
    mem_id = r.json()["id"]

    listing = (await client.get("/api/memories")).json()
    assert len(listing["memories"]) == 1
    assert listing["memories"][0]["source"] == "dashboard"

    r2 = await client.post(f"/api/memories/{mem_id}/delete", json={}, headers=headers)
    assert r2.status_code == 200
    assert (await client.get("/api/memories")).json()["memories"] == []


async def test_memories_reject_empty(client):
    headers = await login(client)
    r = await client.post("/api/memories", json={"content": "  "}, headers=headers)
    assert r.status_code == 400


async def test_update_status_and_check_without_url(client, settings):
    # The default update link now points at the project's release page, so
    # "unconfigured" must be simulated by clearing it explicitly.
    settings.update_url = ""
    headers = await login(client)
    status = (await client.get("/api/update/status")).json()
    assert status["configured"] is False
    assert status["pending"] is None

    response = await client.post("/api/update/check", json={}, headers=headers)
    assert response.status_code == 202
    assert response.json()["operation"]["phase"] in ("checking", "failed")
    # Work is asynchronous: the operation's persisted status is authoritative.
    for _ in range(20):
        checked = (await client.get("/api/update/status")).json()
        if checked["operation"]["phase"] == "failed":
            break
        await asyncio.sleep(0.01)
    assert checked["error"] == "no update link configured"


async def test_update_install_queues_once_and_requires_csrf(client, rt, monkeypatch):
    headers = await login(client)
    assert (await client.post("/api/update/install", json={})).status_code == 403
    started = asyncio.Event()
    finish = asyncio.Event()
    installs = []

    async def worker(install):
        installs.append(install)
        started.set()
        await finish.wait()
        rt.updater._finish_operation("complete", message="Fixture update finished.")

    monkeypatch.setattr(rt.updater, "_operation_worker", worker)
    first = await client.post("/api/update/install", json={}, headers=headers)
    assert first.status_code == 202
    await asyncio.wait_for(started.wait(), 1)
    second = await client.post("/api/update/install", json={}, headers=headers)
    assert second.status_code == 202
    assert first.json()["operation"]["id"] == second.json()["operation"]["id"]
    assert installs == [True]
    assert first.json()["operation"]["automatic_restart"] is True
    finish.set()
    await rt.updater._operation_task


async def test_restart_endpoint_sets_exit_code(client, rt):
    headers = await login(client)
    resp = await client.post("/api/restart", json={}, headers=headers)
    assert resp.status_code == 200
    assert rt.restart_exit_code == 42


async def test_expanded_settings_roundtrip(client, rt):
    headers = await login(client)
    payload = {
        "audio_output_route": "phone",
        "update_url": "https://example.test/latest.json",
        "auto_update": False,
        "quota_reset_jitter_seconds": 60,
        "pulse_internet_interval": 45,
        "vosk_model_path": "C:\\models\\vosk",
    }
    r = await client.post("/api/settings", json=payload, headers=headers)
    assert r.status_code == 200
    assert rt.settings.audio_output_route == "phone"
    assert rt.settings.auto_update is False
    assert rt.settings.pulse_internet_interval == 45


async def test_settings_validation(client, rt):
    headers = await login(client)
    # unknown route falls back to speaker instead of breaking playback
    await client.post("/api/settings", json={"audio_output_route": "sideways"}, headers=headers)
    assert rt.settings.audio_output_route == "speaker"
    # a bad timezone is rejected outright
    r = await client.post("/api/settings", json={"quota_reset_timezone": "Mars/Olympus"}, headers=headers)
    assert r.status_code == 400
    assert rt.settings.quota_reset_timezone != "Mars/Olympus"  # never applied


async def test_rejected_save_changes_nothing(client, rt):
    """One invalid field must not let the valid fields in the same request
    leak into live settings (transactional validation)."""
    headers = await login(client)
    before_low_power = rt.settings.low_power
    r = await client.post(
        "/api/settings",
        json={"low_power": not before_low_power, "quota_reset_timezone": "Mars/Olympus"},
        headers=headers,
    )
    assert r.status_code == 400
    assert rt.settings.low_power == before_low_power

    r2 = await client.post("/api/settings", json={"pulse_internet_interval": 0}, headers=headers)
    assert r2.status_code == 400
    assert rt.settings.pulse_internet_interval != 0


async def test_settings_engine_keys_trigger_no_crash_without_gateway(client, rt):
    """Changing wake word with cloud disabled must not blow up (reload no-ops)."""
    headers = await login(client)
    r = await client.post("/api/settings", json={"wake_word_model": "alexa"}, headers=headers)
    assert r.status_code == 200
    assert r.json()["note"] == "voice settings applied live"
