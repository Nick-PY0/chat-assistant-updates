"""Focused regression coverage for remote owner-admin step-up."""

from __future__ import annotations

import time as wall_clock

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from apps.dashboard.broadcast import BroadcastPolicy
from apps.dashboard.remote_admin import (
    ADMIN_CAPABILITY_COOKIE,
    REMOTE_ADMIN_TTL_SECONDS,
    is_admin_api,
    is_admin_page,
)
from chat_core.runtime import Runtime
from chat_core.security.auth import hash_password


PASSWORD = "remote-owner-password"


@pytest.fixture
async def owner_context(settings, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    rt = Runtime(settings)
    await rt.start(voice=False, cloud=False, monitoring=False)
    app = create_app(rt)

    async def remote_app(scope, receive, send):
        if scope["type"] == "http":
            scope = dict(scope)
            scope["jarvis.broadcast"] = True
        await app(scope, receive, send)

    local_transport = httpx.ASGITransport(app=app)
    remote_transport = httpx.ASGITransport(app=remote_app)
    async with (
        httpx.AsyncClient(transport=local_transport, base_url="http://test") as local,
        httpx.AsyncClient(transport=remote_transport, base_url="https://jarvis.example") as remote,
    ):
        local.app = app
        remote.app = app
        setup = await local.post(
            "/setup", data={"password": PASSWORD, "confirm": PASSWORD}
        )
        assert setup.status_code == 303
        token = local.cookies.get(COOKIE)
        assert token
        remote.cookies.set(COOKIE, token)
        csrf = app.state.sessions.csrf_for(token)
        yield rt, app, local, remote, csrf
    await rt.stop()


async def unlock(remote, csrf: str, password: str = PASSWORD):
    return await remote.post(
        "/api/admin/unlock",
        json={"password": password},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )


async def test_remote_admin_requires_stepup_and_unlock_returns_safe_status(
    owner_context,
):
    _, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    remote.cookies.delete(COOKIE)
    logged_out = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert logged_out.status_code == 401
    remote.cookies.set(COOKIE, token)

    status = await remote.get("/api/admin/status")
    assert status.status_code == 200
    assert status.json() == {
        "remote": True,
        "unlocked": False,
        "expires_at": None,
        "ttl_seconds": 0,
    }

    page = await remote.get("/settings")
    assert page.status_code == 303
    assert page.headers["location"] == "/admin?next=/settings"
    encoded_page = await remote.get("/%73ettings")
    assert encoded_page.status_code == 303
    assert encoded_page.headers["location"] == "/admin?next=/settings"
    trailing_page = await remote.get("/settings/")
    assert trailing_page.status_code == 303
    assert trailing_page.headers["location"] == "/admin?next=/settings"
    github_page = await remote.get("/github")
    assert github_page.status_code == 303
    assert github_page.headers["location"] == "/admin?next=/github"

    denied = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert denied.status_code == 403
    assert denied.json() == {
        "error": "admin unlock required",
        "code": "admin_unlock_required",
    }
    github_denied = await remote.post(
        "/api/github/review",
        json={},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert github_denied.status_code == 403
    assert github_denied.json()["code"] == "admin_unlock_required"

    unlocked = await unlock(remote, csrf)
    assert unlocked.status_code == 200
    body = unlocked.json()
    assert body["remote"] is True
    assert body["unlocked"] is True
    assert body["ttl_seconds"] <= REMOTE_ADMIN_TTL_SECONDS
    assert body["expires_at"]
    assert "password" not in unlocked.text.lower()
    assert "capability" not in unlocked.text.lower()
    cookie = unlocked.headers["set-cookie"].lower()
    assert "chat_admin_capability=" in cookie
    assert "secure" in cookie and "httponly" in cookie
    assert "samesite=strict" in cookie

    assert (await remote.get("/settings")).status_code == 200
    assert (await remote.get("/github")).status_code == 200
    changed = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert changed.status_code == 200
    missing_csrf = await remote.post(
        "/api/settings",
        json={"audio_output_route": "speaker"},
        headers={"origin": "https://jarvis.example"},
    )
    assert missing_csrf.status_code == 403
    assert missing_csrf.json()["error"] == "bad csrf token"
    github_missing_csrf = await remote.post(
        "/api/github/review",
        json={},
        headers={"origin": "https://jarvis.example"},
    )
    assert github_missing_csrf.status_code == 403
    assert github_missing_csrf.json()["error"] == "bad csrf token"


async def test_wrong_password_rate_limit_and_csrf(owner_context):
    _, _, _, remote, csrf = owner_context
    wrong = await unlock(remote, csrf, "wrong-password")
    assert wrong.status_code == 403
    assert "wrong-password" not in wrong.text
    assert "admin_capability" not in wrong.text

    # The limiter is deliberately independent from the normal login limiter.
    for _ in range(4):
        assert (await unlock(remote, csrf, "wrong-password")).status_code == 403
    assert (await unlock(remote, csrf, "wrong-password")).status_code == 429

    no_csrf = await remote.post(
        "/api/admin/unlock",
        json={"password": PASSWORD},
        headers={"origin": "https://jarvis.example"},
    )
    assert no_csrf.status_code == 403
    assert no_csrf.json()["error"] == "bad csrf token"


async def test_lock_expiry_logout_and_password_change_revoke_access(owner_context, monkeypatch):
    _, app, local, remote, csrf = owner_context
    assert (await unlock(remote, csrf)).status_code == 200

    locked = await remote.post(
        "/api/admin/lock",
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert locked.status_code == 200
    assert locked.json()["unlocked"] is False
    assert "Max-Age=0" in locked.headers["set-cookie"]
    assert (await remote.get("/api/admin/status")).json()["unlocked"] is False

    assert (await unlock(remote, csrf)).status_code == 200
    future = wall_clock.time() + REMOTE_ADMIN_TTL_SECONDS + 2
    monkeypatch.setattr(dashboard_module.time, "time", lambda: future)
    expired = await remote.get("/api/admin/status")
    assert expired.status_code == 200
    assert expired.json()["unlocked"] is False
    assert (
        await remote.post(
            "/api/settings",
            json={"audio_output_route": "phone"},
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
    ).json()["code"] == "admin_unlock_required"
    monkeypatch.undo()

    assert (await unlock(remote, csrf)).status_code == 200
    logged_out = await local.post("/logout", data={"_csrf": csrf})
    assert logged_out.status_code == 303
    assert (await remote.get("/api/admin/status")).status_code == 401

    # A password generation change invalidates every ordinary session and its
    # bound capability, not only the browser that made the change.
    setup = await local.post(
        "/login", data={"password": PASSWORD}, headers={"origin": "http://test"}
    )
    assert setup.status_code == 303
    new_token = local.cookies.get(COOKIE)
    new_csrf = app.state.sessions.csrf_for(new_token)
    remote.cookies.set(COOKIE, new_token)
    assert (await unlock(remote, new_csrf)).status_code == 200
    changed = await remote.post(
        "/api/password",
        json={"current": PASSWORD, "new": "replacement-owner-password"},
        headers={"x-csrf": new_csrf, "origin": "https://jarvis.example"},
    )
    assert changed.status_code == 200
    assert (await remote.get("/api/admin/status")).status_code == 401


async def test_capability_is_bound_to_the_ordinary_session(owner_context):
    _, app, _, remote, csrf = owner_context
    assert (await unlock(remote, csrf)).status_code == 200
    cap = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
    token_b = app.state.sessions.issue()
    csrf_b = app.state.sessions.csrf_for(token_b)

    async def remote_b(scope, receive, send):
        scope = dict(scope)
        scope["jarvis.broadcast"] = True
        await app(scope, receive, send)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=remote_b),
        base_url="https://jarvis.example",
        cookies={COOKIE: token_b, ADMIN_CAPABILITY_COOKIE: cap},
    ) as other:
        assert (await other.get("/api/admin/status")).json()["unlocked"] is False
        denied = await other.post(
            "/api/settings",
            json={"audio_output_route": "phone"},
            headers={
                "x-csrf": csrf_b,
                "origin": "https://jarvis.example",
            },
        )
        assert denied.status_code == 403
        assert denied.json()["code"] == "admin_unlock_required"


def test_remote_admin_policy_covers_settings_ajax_and_exact_crud_paths():
    policy = BroadcastPolicy()
    for method, path in (
        ("GET", "/api/audio/devices"),
        ("GET", "/api/location/search"),
        ("GET", "/api/state"),
        ("GET", "/api/cloud-schedule/status"),
        ("POST", "/api/cloud-schedule"),
        ("POST", "/api/cloud-schedule/launch"),
        ("GET", "/api/companion/status"),
        ("POST", "/api/companion/pair"),
        ("POST", "/api/companion/rotate"),
        ("POST", "/api/companion/revoke"),
        ("GET", "/api/broadcast/status"),
        ("POST", "/api/broadcast"),
        ("POST", "/api/settings"),
        ("POST", "/api/password"),
        ("GET", "/api/startup/status"),
        ("POST", "/api/startup/enable"),
        ("POST", "/api/startup/disable"),
        ("GET", "/api/update/status"),
        ("POST", "/api/update/check"),
        ("POST", "/api/update/install"),
        ("POST", "/api/restart"),
        ("GET", "/api/providers/summary"),
        ("POST", "/api/credentials"),
        ("POST", "/api/credentials/c_123/action"),
        ("GET", "/api/spotify/status"),
        ("POST", "/api/spotify/oauth/start"),
        ("POST", "/api/spotify/disconnect"),
        ("GET", "/api/calendar/status"),
        ("POST", "/api/calendar/oauth/start"),
        ("POST", "/api/calendar/disconnect"),
        ("POST", "/api/calendar/sync"),
        ("POST", "/api/calendar/calendars"),
        ("PUT", "/api/experts"),
        ("PATCH", "/api/experts"),
        ("POST", "/api/github/review"),
        ("POST", "/api/github/publish"),
    ):
        assert policy.allows_http(method, path), (method, path)
    assert not policy.allows_http("PUT", "/api/settings/alias")
    assert not policy.allows_http("POST", "/api/github/review/alias")
    assert is_admin_page("/settings/")
    assert is_admin_page("/%73ettings")
    assert is_admin_api("POST", "/api/settings/")
    assert is_admin_api("POST", "/api/%73ettings")
    assert not is_admin_api("POST", "/api/settings/../state")
    assert not is_admin_api("GET", "/api/settings")