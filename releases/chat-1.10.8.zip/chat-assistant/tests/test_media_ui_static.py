"""Static contract checks for the page-scoped YouTube dashboard UI.

These tests enforce the no-CDN, no-remote-script policy:
  • The player MUST use a plain https://www.youtube.com/embed/<id> iframe.
  • No external script of any kind may be loaded (no iframe_api, no YT.Player,
    no document.createElement("script"), no remote src=).
  • All player control MUST go through the postMessage command protocol.
  • Blocked/unembeddable videos MUST offer an official watch-page fallback.
"""

import shutil
import subprocess

import pytest

from pathlib import Path


_INSTALLED_ROOT = Path(__file__).resolve().parents[1]
ROOT = (
    _INSTALLED_ROOT
    if (_INSTALLED_ROOT / "apps" / "dashboard").is_dir()
    else Path.home() / "Desktop" / "Key-Rotation-Manager" / "chat-assistant"
)


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# No external scripts, no CDN, no iframe_api
# ---------------------------------------------------------------------------

def test_no_external_script_is_ever_loaded():
    """The media player must NEVER load any remote script – not even lazily."""
    script = _read("apps/dashboard/static/media.js")
    base   = _read("apps/dashboard/templates/base.html")
    page   = _read("apps/dashboard/templates/media.html")

    # Forbidden: dynamic script injection
    assert 'createElement("script")' not in script, \
        "media.js must not inject a <script> element"
    assert "createElement('script')" not in script, \
        "media.js must not inject a <script> element"

    # Forbidden: the YouTube IFrame API URL in any file
    for name, content in [("media.js", script), ("base.html", base), ("media.html", page)]:
        assert "iframe_api" not in content, \
            f"{name} must not reference the YouTube iframe_api"
        assert "youtube.com/iframe_api" not in content, \
            f"{name} must not load the YouTube iframe_api"

    # Forbidden: YT.Player constructor (the iframe_api client)
    assert "YT.Player" not in script, \
        "media.js must not use the YT.Player constructor"
    assert "new YT." not in script, \
        "media.js must not instantiate any YT.* object"

    # Forbidden: any remote src= in the static files (only local /static/ allowed)
    import re
    remote_script_src = re.compile(r'<script[^>]+src=["\']https?://', re.IGNORECASE)
    assert not remote_script_src.search(base), \
        "base.html must not load remote <script> tags"
    assert not remote_script_src.search(page), \
        "media.html must not load remote <script> tags"


def test_player_uses_embed_iframe_postmessage_protocol():
    """The player must use a direct youtube.com/embed iframe + postMessage."""
    script = _read("apps/dashboard/static/media.js")

    # Must build an embed URL
    assert "youtube.com/embed/" in script, \
        "media.js must construct youtube.com/embed/<id> URLs"
    assert "enablejsapi" in script, \
        "embed URL must include enablejsapi parameter"

    # Must send commands via postMessage
    assert "postMessage" in script, \
        "media.js must use postMessage to control the player"
    assert "playVideo" in script,  "must send playVideo command"
    assert "pauseVideo" in script, "must send pauseVideo command"
    assert "stopVideo" in script,  "must send stopVideo command"
    assert "seekTo" in script,     "must send seekTo command"

    # Must listen for player events via window.message
    assert 'addEventListener("message"' in script or "addEventListener('message'" in script, \
        "media.js must listen for postMessage events from the player iframe"

    # Must check the event origin for safety
    assert "youtube.com" in script, \
        "media.js must verify the postMessage origin is youtube.com"


def test_blocked_unembeddable_videos_have_watch_page_fallback():
    """Error codes 101/150 (embedding disabled) must offer an open-on-YouTube link."""
    script = _read("apps/dashboard/static/media.js")

    # Unembeddable error codes must be handled
    assert "101" in script and "150" in script, \
        "media.js must handle unembeddable error codes 101 and 150"

    # Must offer the official watch URL as fallback
    assert "youtube.com/watch" in script, \
        "media.js must provide a youtube.com/watch fallback for blocked videos"

    # Fallback must be clearly presented
    assert "Open on YouTube" in script, \
        'media.js must show an "Open on YouTube" link for unembeddable videos'


def test_unembeddable_fallback_calls_narrow_host_open_endpoint():
    """101/150 and onAutoplayBlocked must automatically call the narrow,
    CSRF-protected host-open endpoint sending only client_id (no url/host/command)."""
    script = _read("apps/dashboard/static/media.js")
    assert "/api/media/host-open" in script, \
        "media.js must call the host-open fallback endpoint on 101/150"
    assert "renderHostBrowserFallback" in script
    # The fallback must send only the client_id, never a URL/host/command.
    assert 'api("/api/media/host-open", "POST", { client_id: clientId })' in script
    # onAutoplayBlocked must invoke the same fallback, not a tap-play overlay.
    assert "onAutoplayBlocked" in script
    assert "renderHostBrowserFallback" in script


def test_autoplay_blocked_does_not_show_tap_play_or_queued_copy():
    """onAutoplayBlocked must tear down the iframe and invoke the host-browser
    fallback — never show a 'tap to play' overlay or claim the video is queued."""
    script = _read("apps/dashboard/static/media.js")
    assert "teardownIframe()" in script
    assert "tapToPlay.hidden = true" in script
    assert "Tap the play button" not in script, \
        "onAutoplayBlocked must not show 'Tap the play button' copy"
    assert "tap once" not in script.lower(), \
        "onAutoplayBlocked must not instruct user to tap once"


def test_mobile_music_provider_and_search_type_are_persistent_choices():
    """Phones must use visible choice buttons instead of short-lived native
    select popups for Provider and Songs/Playlists/Everything."""
    page = _read("apps/dashboard/templates/media.html")
    script = _read("apps/dashboard/static/media.js")
    styles = _read("apps/dashboard/static/media.css")
    assert 'id="music-provider-choices"' in page
    assert 'id="music-search-kind-choices"' in page
    assert 'data-value="spotify"' in page
    assert 'data-value="playlist"' in page
    assert "bindPersistentChoices(musicProviderChoices, musicProvider)" in script
    assert "bindPersistentChoices(musicSearchKindChoices, musicSearchKind)" in script
    assert '.music-persistent-choices button[aria-pressed="true"]' in styles


def test_host_browser_mode_has_honest_copy():
    """The dashboard must honestly say playback is in the browser on this
    computer and must NOT claim it can control that separate tab."""
    script = _read("apps/dashboard/static/media.js")
    assert "Playing in browser on this computer" in script
    assert 'playback_mode === "host_browser"' in script
    # Honest note that YouTube's own controls live in the host tab.
    assert "YouTube's own controls" in script or "own controls in that tab" in script


def test_passive_claim_preserves_host_browser_mode():
    """When the server returns playback_mode=host_browser on a claim response,
    the dashboard must not build an iframe.  The initialize() and claimPlayer()
    paths must check playback_mode before calling ensureIframe."""
    script = _read("apps/dashboard/static/media.js")
    # claimPlayer must branch on host_browser to show honest message instead
    # of replaying the command (which would create an iframe).
    assert 'playback_mode === "host_browser"' in script
    # The initialize path must skip iframe creation when in host_browser mode.
    assert 'state.playback_mode !== "host_browser"' in script


def test_no_stale_report_overwrites_host_browser_on_client():
    """reportPlayerState must guard against sending stale embedded iframe state
    back to the server while in host_browser mode."""
    script = _read("apps/dashboard/static/media.js")
    assert 'playback_mode === "host_browser"' in script
    assert "return Promise.resolve()" in script  # early return in reportPlayerState


def test_media_page_nav_link_and_local_script():
    """The /media nav link must exist; its script must be page-local only."""
    base = _read("apps/dashboard/templates/base.html")
    page = _read("apps/dashboard/templates/media.html")

    assert 'href="/media"' in base, "base.html must contain a /media nav link"
    assert 'src="/static/media.js?' in page, \
        "media.html must load /static/media.js with a version query"
    assert "Tap to play" in page, \
        "media.html must contain the Tap-to-play autoplay-blocked overlay"


def test_media_ui_matches_authenticated_backend_and_events():
    script = _read("apps/dashboard/static/media.js")
    for endpoint in (
        "/api/media",
        "/api/media/claim",
        "/api/media/release",
        "/api/media/search",
        "/api/media/control",
        "/api/media/state",
    ):
        assert endpoint in script, f"media.js must call {endpoint}"
    assert 'detail.topic === "media_control"' in script
    assert 'detail.topic === "media_state"' in script
    assert "target_id !== clientId" in script
    assert "offset_seconds" in script


def test_media_ui_has_no_always_on_poll_or_sensitive_local_storage():
    script = _read("apps/dashboard/static/media.js")
    assert "setInterval" not in script, "use setTimeout chains, not setInterval"
    assert "localStorage"  not in script, "must not use localStorage"
    assert "api_key"        not in script.lower()
    assert "transcript"     not in script.lower()


def test_selected_player_renews_lease_within_thirty_seconds():
    script = _read("apps/dashboard/static/media.js")
    assert "updateLeaseRenewal"        in script
    assert "20000"                     in script
    assert "reportPlayerState(state.status)" in script


def test_remote_voice_bridge_sends_exact_media_state_shape():
    chat = _read("apps/dashboard/static/chat.js")
    assert 'new BroadcastChannel("chat-media-state-v1")' in chat
    assert 'JSON.stringify({ type: "media_state", playing: message.playing })' in chat


# ---------------------------------------------------------------------------
# iframe event identity: the message listener must bind events to the ACTIVE
# iframe (by its real id / source window), not a hardcoded "player" id.
# ---------------------------------------------------------------------------

def test_message_listener_binds_events_to_active_iframe_not_hardcoded_player():
    """Guards against the identity bug where the listener required id==='player'
    while the iframe id is 'youtube-iframe', causing every real event to be
    ignored. The listener must compare against the live iframe element."""
    script = _read("apps/dashboard/static/media.js")
    # Strict origin check stays.
    assert 'event.origin !== "https://www.youtube.com"' in script
    # The active iframe's own window must be the required source.
    assert "event.source !== iframeEl.contentWindow" in script
    # Events are matched against the live iframe's real id, not a constant.
    assert "String(msg.id) !== iframeEl.id" in script
    # The old buggy hardcoded comparison must be gone.
    assert 'msg.id !== "player"' not in script


# ---------------------------------------------------------------------------
# Blocker 3: Honest host-browser UI — controls disabled, stop labelled,
# Continuous indicator suppressed in host_browser mode.
# ---------------------------------------------------------------------------

def test_host_browser_controls_disabled_not_just_hidden():
    """In host_browser mode, play/pause, seek, previous, and next must be
    disabled (not merely visually hidden): the dashboard cannot control an
    external YouTube tab."""
    script = _read("apps/dashboard/static/media.js")
    # isHostBrowser flag is derived in updateControls.
    assert "isHostBrowser" in script, \
        "updateControls must define an isHostBrowser flag"
    # play/pause button must be disabled in host_browser mode.
    assert "isHostBrowser" in script
    # Seek buttons must be disabled.
    assert "isHostBrowser" in script
    # Verify the concrete disable expressions are present.
    assert "|| isHostBrowser" in script, \
        "controls must be disabled with '|| isHostBrowser' in updateControls"


def test_stop_button_labelled_honestly_in_host_browser():
    """The Stop button in host_browser mode must carry honest copy explaining
    it stops Chat tracking only and cannot close or pause the external tab."""
    script = _read("apps/dashboard/static/media.js")
    assert "Stop tracking" in script, \
        "stop button must be re-labelled 'Stop tracking' in host_browser mode"
    assert "Stops Chat tracking only" in script, \
        "stop button title must explain it does not close the YouTube tab"


def test_continuous_indicator_suppressed_in_host_browser():
    """The Continuous indicator must NOT be shown in host_browser mode because
    Chat cannot observe end events for an external tab."""
    script = _read("apps/dashboard/static/media.js")
    # The modeSuffix for continuous must be gated on !isHostBrowser.
    assert "!isHostBrowser" in script, \
        "Continuous indicator must be suppressed in host_browser mode (!isHostBrowser)"


def test_host_browser_stop_button_remains_available():
    """Stop must remain available (not disabled) in host_browser mode so the
    user can end Chat tracking of the external playback."""
    script = _read("apps/dashboard/static/media.js")
    # stopButton must not have isHostBrowser in its disable expression.
    # We verify this by checking stopButton.disabled does NOT include isHostBrowser.
    # Find the stopButton.disabled assignment line.
    import re
    # Extract the stopButton.disabled assignment
    match = re.search(r'stopButton\.disabled\s*=\s*([^;]+);', script)
    assert match is not None, "stopButton.disabled assignment must be present"
    expr = match.group(1)
    assert "isHostBrowser" not in expr, \
        f"stopButton.disabled must NOT include isHostBrowser, got: {expr}"


# ---------------------------------------------------------------------------
# Behavior test (jsdom): runs the REAL media.js and dispatches YouTube events.
# Skips cleanly when node or jsdom is unavailable in the environment.
# ---------------------------------------------------------------------------

def test_media_event_behavior_in_jsdom():
    """Execute media.js in jsdom and prove:
      • onError 101 and 150 from the active iframe remove the iframe and render
        exactly one validated https://www.youtube.com/watch?v=<id> link with
        target=_blank and rel="noopener noreferrer".
      • spoofed wrong-origin / wrong-id / wrong-source messages are ignored.
    """
    node = shutil.which("node")
    if node is None:
        pytest.skip("node is not available")
    harness = ROOT / "tools" / "browser_check" / "media_events.mjs"
    if not harness.is_file():
        pytest.skip("media_events.mjs harness not found")
    if not (ROOT / "tools" / "browser_check" / "node_modules" / "jsdom").is_dir():
        pytest.skip("jsdom is not installed in tools/browser_check")

    result = subprocess.run(
        [node, str(harness)],
        cwd=str(harness.parent),
        capture_output=True,
        text=True,
        timeout=120,
    )
    output = result.stdout + result.stderr
    assert result.returncode == 0, f"media event harness failed:\n{output}"
    assert "ALL MEDIA EVENT CHECKS PASSED" in output, output
