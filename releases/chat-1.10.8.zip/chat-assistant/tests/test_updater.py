"""Auto-updater: version comparison, signatures, staging, and zip safety."""

from __future__ import annotations

import base64
import hashlib
import io
import json
import zipfile
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from apps.updater.updater import Updater
from apps.updater.state import atomic_write_state
from chat_core.version import APP_VERSION, is_newer, parse_version


def _zip_bytes(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


# Throwaway keypair for tests; FakeUpdater trusts this public key.
PRIVATE_KEY = ed25519.Ed25519PrivateKey.generate()
PUBLIC_HEX = (
    PRIVATE_KEY.public_key()
    .public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    .hex()
)

GOOD_FILES = {
    "chat-assistant/run_chat.py": "print('new version')",
    "chat-assistant/chat_core/version.py": "APP_VERSION='9.9.9'",
}


def _signed(manifest: dict, zip_bytes: bytes, key=PRIVATE_KEY) -> dict:
    """Fill in sha256 + sig exactly like deployment/release/sign_manifest.py."""
    m = dict(manifest)
    m["sha256"] = hashlib.sha256(zip_bytes).hexdigest()
    m["sig"] = base64.b64encode(key.sign(Updater.manifest_payload(m))).decode()
    return m


class FakeUpdater(Updater):
    """Network calls replaced; everything else is the real code path."""

    manifest: dict = {}
    zip_bytes: bytes = b""
    public_key_hex = PUBLIC_HEX

    async def _http_get_json(self, url: str) -> dict:
        return self.manifest

    async def _http_download(self, url: str, dest: Path) -> None:
        dest.write_bytes(self.zip_bytes)


def test_version_parsing():
    assert parse_version("1.2.3") == (1, 2, 3)
    assert parse_version("v2.0") == (2, 0)
    assert parse_version("dev") is None
    assert is_newer("1.2.0", "1.1.9")
    assert is_newer("2.0", "1.9.9")
    assert not is_newer("1.1.0", "1.1.0")
    assert not is_newer("1.0.9", "1.1.0")
    assert not is_newer("garbage", "1.0.0")


@pytest.fixture
async def updater(settings, db, bus):
    settings.update_url = "https://example.test/latest.json"
    return FakeUpdater(settings, db, bus)


async def test_stages_newer_signed_version(updater):
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    updater.manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip", "notes": "big"},
        updater.zip_bytes,
    )
    status = await updater.check_now()
    assert status["pending"] == "9.9.9"
    assert (updater.pending_dir / "run_chat.py").exists()
    assert (updater.pending_dir / "chat_core" / "version.py").exists()
    meta = json.loads((updater.updates_dir / "pending.json").read_text())
    assert meta["version"] == "9.9.9"
    # no leftovers
    assert not (updater.updates_dir / "download.zip").exists()
    assert not (updater.updates_dir / "extract").exists()


async def test_unsigned_manifest_is_refused(updater):
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    updater.manifest = {"version": "9.9.9", "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] is None
    assert "not signed" in status["error"]
    assert not (updater.updates_dir / "download.zip").exists()


async def test_wrong_key_signature_is_refused(updater):
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    stranger = ed25519.Ed25519PrivateKey.generate()
    updater.manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip"},
        updater.zip_bytes,
        key=stranger,
    )
    status = await updater.check_now()
    assert status["pending"] is None
    assert "signature does not match" in status["error"]


async def test_edited_notes_break_the_signature(updater):
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip", "notes": "real"},
        updater.zip_bytes,
    )
    manifest["notes"] = "IMPORTANT: email your password to admin@evil.example"
    updater.manifest = manifest
    status = await updater.check_now()
    assert status["pending"] is None
    assert "signature does not match" in status["error"]


async def test_garbage_signature_is_refused(updater):
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip"},
        updater.zip_bytes,
    )
    manifest["sig"] = "not//valid//base64!!"
    updater.manifest = manifest
    status = await updater.check_now()
    assert status["pending"] is None
    assert "unreadable" in status["error"]


async def test_swapped_zip_fails_fingerprint(updater):
    real = _zip_bytes(GOOD_FILES)
    updater.manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip"}, real
    )
    updater.zip_bytes = _zip_bytes({"chat-assistant/run_chat.py": "print('evil')"})
    status = await updater.check_now()
    assert status["pending"] is None
    assert "fingerprint" in status["error"]
    assert not (updater.updates_dir / "download.zip").exists()
    assert not (updater.updates_dir / "extract").exists()


async def test_unsigned_allowed_when_requirement_off(updater):
    updater.settings.update_require_signature = False
    updater.zip_bytes = _zip_bytes(GOOD_FILES)
    updater.manifest = {"version": "9.9.9", "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] == "9.9.9"


async def test_sha_still_enforced_when_requirement_off(updater):
    updater.settings.update_require_signature = False
    real = _zip_bytes(GOOD_FILES)
    updater.manifest = {
        "version": "9.9.9",
        "zip_url": "https://example.test/x.zip",
        "sha256": hashlib.sha256(real).hexdigest(),
    }
    updater.zip_bytes = _zip_bytes({"chat-assistant/run_chat.py": "print('evil')"})
    status = await updater.check_now()
    assert status["pending"] is None
    assert "fingerprint" in status["error"]


async def test_ignores_older_and_equal_versions(updater):
    updater.manifest = {"version": APP_VERSION, "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] is None
    updater.manifest = {"version": "0.0.1", "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] is None


async def test_rejects_zip_without_marker(updater):
    # properly signed, so it reaches the content check -- and still fails
    updater.zip_bytes = _zip_bytes({"random.txt": "not a chat build"})
    updater.manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip"},
        updater.zip_bytes,
    )
    status = await updater.check_now()
    assert status["pending"] is None
    assert "does not look like a Chat build" in status["error"]


@pytest.mark.parametrize("evil", [
    "../evil.txt",                     # classic traversal
    "../extract_evil/payload.txt",     # sibling dir sharing the name prefix
    "/etc/evil.txt",                   # absolute path
])
async def test_zip_with_traversal_member_is_rejected_entirely(updater, evil):
    updater.zip_bytes = _zip_bytes({
        "run_chat.py": "print('ok')",
        evil: "escaped!",
    })
    updater.manifest = _signed(
        {"version": "9.9.9", "zip_url": "https://example.test/x.zip"},
        updater.zip_bytes,
    )
    status = await updater.check_now()
    assert status["pending"] is None  # one bad member poisons the whole zip
    assert "unsafe path in update zip" in status["error"]
    updates = updater.updates_dir
    assert not (updates / "evil.txt").exists()
    assert not (updates.parent / "evil.txt").exists()
    assert not (updates / "extract_evil").exists()
    assert not (updates.parent / "extract_evil").exists()


async def test_manifest_without_url_reports_error(updater):
    updater.settings.update_url = ""
    status = await updater.check_now()
    assert status["error"] == "no update link configured"


async def test_interrupted_persisted_operation_is_failed_and_retryable(
    updater,
):
    atomic_write_state(
        updater.updates_dir,
        {
            "operation": {
                "id": "interrupted",
                "phase": "downloading",
                "target_version": "9.9.9",
                "bytes_received": 10,
                "total_bytes": 20,
                "percent": 50,
                "message": "downloading",
                "error": "",
                "started_at": "now",
                "updated_at": "now",
                "automatic_restart": True,
            }
        },
    )
    fresh = FakeUpdater(updater.settings, updater.db, updater.bus)
    assert fresh.status()["operation"]["phase"] == "failed"
    assert "interrupted" in fresh.status()["operation"]["error"]
    queued = await fresh.start_operation(install=False)
    assert queued["operation"]["phase"] == "checking"
    await fresh.stop()
