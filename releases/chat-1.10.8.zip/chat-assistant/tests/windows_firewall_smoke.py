"""Real Windows smoke check for the dashboard firewall helper.

This script is intentionally separate from pytest: it creates temporary Windows
Defender Firewall rules and must run only on an elevated Windows CI runner.
Every rule name contains a UUID, and the final cleanup verifies that no matching
rule remains even when an assertion or netsh command fails.
"""

from __future__ import annotations

import ctypes
import importlib.util
import ipaddress
import json
import os
import subprocess
import sys
import traceback
import uuid
from pathlib import Path
from types import ModuleType
from typing import Any, Callable


APP_ROOT = Path(__file__).resolve().parents[1]
HELPER_PATH = APP_ROOT / "deployment" / "windows" / "firewall_helper.py"
SMOKE_PORT = int(os.environ.get("CHAT_FIREWALL_SMOKE_PORT", "48756"))
EXPLICIT_RFC1918 = (
    "10.123.0.0/16",
    "172.20.0.0/16",
    "192.168.250.0/24",
)
RFC1918_NETWORKS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
)


class SmokeFailure(RuntimeError):
    """Raised when the Windows firewall compatibility check fails."""


def _load_helper() -> ModuleType:
    spec = importlib.util.spec_from_file_location("firewall_helper_smoke", HELPER_PATH)
    if spec is None or spec.loader is None:
        raise SmokeFailure(f"could not import firewall helper from {HELPER_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _powershell_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _rule_snapshot(rule_name: str) -> dict[str, Any]:
    """Return stable, structured properties for one named firewall rule."""
    script = f"""
$ErrorActionPreference = 'Stop'
$rules = @(Get-NetFirewallRule -DisplayName {_powershell_literal(rule_name)} -ErrorAction SilentlyContinue)
if ($rules.Count -eq 0) {{
    [PSCustomObject]@{{ Count = 0 }} | ConvertTo-Json -Compress
    exit 0
}}
if ($rules.Count -ne 1) {{
    [PSCustomObject]@{{ Count = $rules.Count }} | ConvertTo-Json -Compress
    exit 0
}}
$rule = $rules[0]
$ports = @($rule | Get-NetFirewallPortFilter)
$addresses = @($rule | Get-NetFirewallAddressFilter)
[PSCustomObject]@{{
    Count = 1
    Direction = [string]$rule.Direction
    Action = [string]$rule.Action
    Enabled = [string]$rule.Enabled
    Profile = [string]$rule.Profile
    Protocol = (($ports | ForEach-Object {{ [string]$_.Protocol }}) -join ',')
    LocalPort = (($ports | ForEach-Object {{ [string]$_.LocalPort }}) -join ',')
    RemoteAddress = (($addresses | ForEach-Object {{ $_.RemoteAddress }}) -join ',')
}} | ConvertTo-Json -Compress
"""
    result = subprocess.run(
        [
            "powershell.exe",
            "-NoProfile",
            "-NonInteractive",
            "-Command",
            script,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise SmokeFailure(
            f"could not inspect firewall rule {rule_name!r}: "
            f"{result.stderr.strip() or result.stdout.strip()}"
        )
    try:
        return json.loads(result.stdout.strip())
    except (json.JSONDecodeError, TypeError) as exc:
        raise SmokeFailure(
            f"PowerShell returned an invalid rule snapshot for {rule_name!r}: "
            f"{result.stdout!r}"
        ) from exc


def _csv_values(value: Any) -> set[str]:
    return {
        item.strip()
        for item in str(value or "").split(",")
        if item.strip()
    }


def _validate_rfc1918(addresses: set[str]) -> None:
    if not addresses:
        raise SmokeFailure("explicit fallback rule has no remote addresses")
    for address in addresses:
        if address.casefold() == "any":
            raise SmokeFailure("explicit fallback widened to RemoteAddress=Any")
        try:
            network = ipaddress.ip_network(address, strict=True)
        except ValueError as exc:
            raise SmokeFailure(
                f"explicit fallback returned a non-CIDR remote address: {address!r}"
            ) from exc
        if not isinstance(network, ipaddress.IPv4Network) or not any(
            network.subnet_of(private) for private in RFC1918_NETWORKS
        ):
            raise SmokeFailure(
                f"explicit fallback escaped RFC1918 private space: {address!r}"
            )


def _validate_rule(
    rule_name: str,
    *,
    expected_port: int,
    expected_remote: set[str],
) -> None:
    snapshot = _rule_snapshot(rule_name)
    if snapshot.get("Count") != 1:
        raise SmokeFailure(
            f"expected exactly one firewall rule named {rule_name!r}, "
            f"found {snapshot.get('Count')!r}"
        )

    expected_properties = {
        "Direction": "inbound",
        "Action": "allow",
        "Enabled": "true",
        "Profile": "private",
    }
    for property_name, expected in expected_properties.items():
        actual = str(snapshot.get(property_name, "")).casefold()
        if actual != expected:
            raise SmokeFailure(
                f"{rule_name!r} has {property_name}={actual!r}, expected {expected!r}"
            )

    protocols = {value.casefold() for value in _csv_values(snapshot.get("Protocol"))}
    if protocols not in ({"tcp"}, {"6"}):
        raise SmokeFailure(
            f"{rule_name!r} has Protocol={snapshot.get('Protocol')!r}, expected TCP"
        )

    ports = _csv_values(snapshot.get("LocalPort"))
    if ports != {str(expected_port)}:
        raise SmokeFailure(
            f"{rule_name!r} has LocalPort={ports!r}, "
            f"expected only {expected_port}"
        )

    remotes = _csv_values(snapshot.get("RemoteAddress"))
    if {value.casefold() for value in remotes} != {
        value.casefold() for value in expected_remote
    }:
        raise SmokeFailure(
            f"{rule_name!r} has RemoteAddress={remotes!r}, "
            f"expected {expected_remote!r}"
        )
    if "any" in {value.casefold() for value in remotes}:
        raise SmokeFailure(f"{rule_name!r} widened to RemoteAddress=Any")


def _cleanup_rules(
    helper: ModuleType,
    rule_names: list[str],
    real_netsh: Callable[..., subprocess.CompletedProcess[str]],
) -> list[str]:
    """Delete every temporary rule and independently confirm its absence."""
    errors: list[str] = []
    for rule_name in reversed(rule_names):
        try:
            result = real_netsh("delete", "rule", f"name={rule_name}")
        except Exception as exc:  # pragma: no cover - exercised only on Windows CI
            errors.append(f"{rule_name!r}: cleanup command raised {exc!r}")
            continue

        try:
            remaining = _rule_snapshot(rule_name).get("Count")
        except Exception as exc:  # pragma: no cover - exercised only on Windows CI
            errors.append(f"{rule_name!r}: cleanup could not be confirmed: {exc}")
            continue

        if remaining != 0:
            errors.append(
                f"{rule_name!r}: cleanup left {remaining!r} matching rule(s); "
                f"netsh exit={result.returncode}, stdout={result.stdout!r}, "
                f"stderr={result.stderr!r}"
            )
    return errors


def _run_smoke(helper: ModuleType, rule_names: list[str]) -> None:
    if not 1 <= SMOKE_PORT <= 65535:
        raise SmokeFailure(f"invalid CHAT_FIREWALL_SMOKE_PORT: {SMOKE_PORT}")

    real_netsh = helper._netsh
    netsh_calls: list[tuple[str, ...]] = []

    def guarded_netsh(*args: str) -> subprocess.CompletedProcess[str]:
        normalized = {str(arg).strip().casefold() for arg in args}
        if "remoteip=any" in normalized or "profile=any" in normalized:
            raise SmokeFailure(f"unsafe netsh command refused: {args!r}")
        netsh_calls.append(tuple(args))
        return real_netsh(*args)

    helper._netsh = guarded_netsh
    helper._load_port = lambda: SMOKE_PORT

    local_name, fallback_name = rule_names

    # Exercise the exact LocalSubnet command on the Windows host.
    helper.RULE_NAME = local_name
    helper._active_private_subnets = lambda: ()
    if helper.allow() != 0:
        raise SmokeFailure(
            "the Windows host rejected the helper's LocalSubnet rule command"
        )
    _validate_rule(
        local_name,
        expected_port=SMOKE_PORT,
        expected_remote={"LocalSubnet"},
    )

    # Force only the first add to fail, then let the helper execute its real
    # netsh explicit-RFC1918 fallback on the Windows host.
    real_add_rule = helper._add_rule
    fallback_attempts: list[str] = []

    def reject_localsubnet_once(
        port: int, remote_ip: str
    ) -> subprocess.CompletedProcess[str]:
        fallback_attempts.append(remote_ip)
        if remote_ip.casefold() == "localsubnet":
            return subprocess.CompletedProcess(
                args=["netsh", "advfirewall", "firewall", "add", "rule"],
                returncode=87,
                stdout="",
                stderr="Simulated LocalSubnet compatibility failure.",
            )
        return real_add_rule(port, remote_ip)

    helper.RULE_NAME = fallback_name
    helper._active_private_subnets = lambda: EXPLICIT_RFC1918
    helper._add_rule = reject_localsubnet_once
    if helper.allow() != 0:
        raise SmokeFailure("the helper did not recover through its RFC1918 fallback")
    if fallback_attempts != ["localsubnet", ",".join(EXPLICIT_RFC1918)]:
        raise SmokeFailure(
            f"unexpected fallback attempts: {fallback_attempts!r}"
        )

    _validate_rule(
        fallback_name,
        expected_port=SMOKE_PORT,
        expected_remote=set(EXPLICIT_RFC1918),
    )
    _validate_rfc1918(_csv_values(_rule_snapshot(fallback_name)["RemoteAddress"]))

    add_calls = [call for call in netsh_calls if call[:2] == ("add", "rule")]
    if len(add_calls) != 2:
        raise SmokeFailure(f"expected two real netsh add calls, saw {add_calls!r}")
    for call in add_calls:
        normalized = {arg.casefold() for arg in call}
        if f"localport={SMOKE_PORT}" not in normalized:
            raise SmokeFailure(f"netsh add did not use the current port: {call!r}")
        if "profile=private" not in normalized:
            raise SmokeFailure(f"netsh add did not use the Private profile: {call!r}")
        if "dir=in" not in normalized or "protocol=tcp" not in normalized:
            raise SmokeFailure(f"netsh add was not inbound TCP: {call!r}")
        if "remoteip=any" in normalized:
            raise SmokeFailure(f"netsh add used forbidden RemoteIP=Any: {call!r}")


def main() -> int:
    if sys.platform != "win32":
        print("ERROR: this smoke check must run on Windows.", file=sys.stderr)
        return 1
    if not ctypes.windll.shell32.IsUserAnAdmin():
        print(
            "ERROR: this smoke check requires an elevated Windows runner.",
            file=sys.stderr,
        )
        return 1

    helper = _load_helper()
    unique = uuid.uuid4().hex
    rule_names = [
        f"Chat Assistant CI Firewall Smoke LocalSubnet {unique}",
        f"Chat Assistant CI Firewall Smoke RFC1918 {unique}",
    ]
    real_netsh = helper._netsh
    failure: BaseException | None = None

    try:
        _run_smoke(helper, rule_names)
    except BaseException as exc:
        failure = exc
        traceback.print_exception(exc, file=sys.stderr)
    finally:
        cleanup_errors = _cleanup_rules(helper, rule_names, real_netsh)

    if cleanup_errors:
        print("ERROR: firewall smoke cleanup could not be confirmed:", file=sys.stderr)
        for error in cleanup_errors:
            print(f"  - {error}", file=sys.stderr)
        return 1
    if failure is not None:
        return 1

    print(
        "Windows firewall smoke passed: LocalSubnet and RFC1918 fallback rules "
        f"were verified on TCP port {SMOKE_PORT} and cleanup was confirmed."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())