from __future__ import annotations

import asyncio
import socket
import sys
from pathlib import Path

import pytest

from run_chat import (
    _acquire_windows_mutex,
    _mark_updater_ready_when_serving,
    _print_dashboard_access,
    _restart_direct_after_rollback,
    dashboard_port_available,
)


def test_dashboard_port_available_detects_listener():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen()
        port = listener.getsockname()[1]
        assert dashboard_port_available("127.0.0.1", port) is False


def test_dashboard_port_available_accepts_free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reservation:
        reservation.bind(("127.0.0.1", 0))
        port = reservation.getsockname()[1]
    assert dashboard_port_available("127.0.0.1", port) is True


def test_startup_lan_output_has_exact_phone_url_and_diagnostics(capsys):
    _print_dashboard_access(
        "0.0.0.0",
        8765,
        "https",
        candidates=["192.168.1.23", "10.0.0.4"],
    )

    output = capsys.readouterr().out
    assert "PHONE ACCESS: ON" in output
    assert "PHONE URL:      https://192.168.1.23:8765" in output
    assert "Other adapter:  https://10.0.0.4:8765" in output
    assert "TIMES OUT" in output
    assert "same Wi-Fi" in output
    assert r"deployment\windows\allow_lan_access.bat" in output
    assert "CERTIFICATE/PRIVACY error" in output
    assert "reached Nexa" in output


def test_startup_loopback_output_says_phone_access_off(capsys):
    _print_dashboard_access("127.0.0.1", 8765, "http")

    output = capsys.readouterr().out
    assert "PHONE ACCESS: OFF" in output
    assert "Settings > Dashboard access > Phone access: On" in output
    assert "save, then restart Nexa" in output
    assert "allow_lan_access" not in output


def test_mutex_returns_true_on_non_windows(monkeypatch):
    """On non-Windows the mutex acquisition always succeeds (no-op)."""
    if sys.platform == "win32":
        # Skip this particular assertion on the real Windows path
        return
    import run_chat
    run_chat._WIN_MUTEX = None
    result = _acquire_windows_mutex()
    assert result is True


def test_verify_chat_on_port_returns_false_on_wrong_service(monkeypatch):
    """_verify_chat_on_port should return False when the response is not Chat."""
    import run_chat

    def fake_urlopen(url, timeout=None, context=None):
        import io
        import json

        class FakeResp:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def read(self):
                return json.dumps({"app": "not-chat"}).encode()

        return FakeResp()

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    assert run_chat._verify_chat_on_port("127.0.0.1", 9999) is False


def test_verify_chat_on_port_returns_true_for_chat(monkeypatch):
    """_verify_chat_on_port returns True when the response identifies as chat-assistant."""
    import run_chat
    import json

    def fake_urlopen(url, timeout=None, context=None):
        class FakeResp:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def read(self):
                return json.dumps({"app": "chat-assistant"}).encode()

        return FakeResp()

    import urllib.request
    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    assert run_chat._verify_chat_on_port("127.0.0.1", 9999) is True


@pytest.mark.asyncio
async def test_windows_disconnect_handler_ignores_only_expected_peer_reset(monkeypatch):
    import run_chat

    loop = asyncio.get_running_loop()
    old = loop.get_exception_handler()
    forwarded = []
    loop.set_exception_handler(lambda _loop, context: forwarded.append(context))
    monkeypatch.setattr(run_chat.sys, "platform", "win32")
    try:
        run_chat._install_windows_disconnect_handler()
        handler = loop.get_exception_handler()
        assert handler is not None

        expected = ConnectionResetError(10054, "remote host closed connection")
        expected.winerror = 10054
        handler(loop, {"exception": expected})
        assert forwarded == []

        handler(loop, {"exception": ValueError("keep reporting this")})
        assert len(forwarded) == 1
        assert isinstance(forwarded[0]["exception"], ValueError)
        assert str(forwarded[0]["exception"]) == "keep reporting this"
    finally:
        loop.set_exception_handler(old)


def _staged_source_update(tmp_path: Path, monkeypatch):
    import run_chat

    install = tmp_path / "install"
    install.mkdir()
    (install / "run_chat.py").write_text("old launcher")
    data = tmp_path / "data"
    pending = data / "updates" / "pending"
    pending.mkdir(parents=True)
    (pending / "run_chat.py").write_text("new launcher")
    (pending / "requirements.txt").write_text("tzlocal>=5.2,<6\n")
    (pending.parent / "pending.json").write_text('{"version":"1.9.24"}')
    monkeypatch.setattr(run_chat, "__file__", str(install / "run_chat.py"))
    monkeypatch.setenv("CHAT_DATA_DIR", str(data))
    return run_chat, install, pending


def test_source_update_syncs_dependencies_before_copy(monkeypatch, tmp_path):
    """The updated launcher must use its active environment before new imports."""
    import startup_dependencies

    run_chat, install, pending = _staged_source_update(tmp_path, monkeypatch)
    events = []

    def sync(requirements):
        events.append(("sync", Path(requirements)))
        assert (install / "run_chat.py").read_text() == "old launcher"

    monkeypatch.setattr(startup_dependencies, "sync_requirements", sync)
    run_chat.apply_pending_update()

    assert events == [("sync", pending / "requirements.txt")]
    assert (install / "run_chat.py").read_text() == "new launcher"
    assert not pending.exists()


def test_dependency_sync_uses_active_python_noninteractive_and_bounded(
    monkeypatch, tmp_path
):
    import subprocess
    import startup_dependencies

    requirements = tmp_path / "requirements.txt"
    requirements.write_text("tzlocal>=5.2,<6\n")
    seen = {}

    def run(command, **kwargs):
        seen["command"] = command
        seen.update(kwargs)
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(startup_dependencies.subprocess, "run", run)
    startup_dependencies.sync_requirements(requirements)

    assert seen["command"][:4] == [
        sys.executable,
        "-m",
        "pip",
        "install",
    ]
    assert "--no-input" in seen["command"]
    assert seen["command"][-1] == str(requirements.resolve())
    assert seen["stdin"] is subprocess.DEVNULL
    assert seen["env"]["PIP_NO_INPUT"] == "1"
    assert 0 < seen["timeout"] <= 300


def test_source_update_dependency_failure_preserves_staged_update(
    monkeypatch, tmp_path, capsys
):
    import run_chat
    import startup_dependencies

    run_chat, install, pending = _staged_source_update(tmp_path, monkeypatch)

    def fail(_requirements):
        raise startup_dependencies.DependencySyncError("pip exited with status 1")

    monkeypatch.setattr(startup_dependencies, "sync_requirements", fail)
    with pytest.raises(SystemExit) as stopped:
        run_chat.apply_pending_update()

    assert stopped.value.code == 1
    assert (install / "run_chat.py").read_text() == "old launcher"
    assert pending.is_dir()
    assert (pending.parent / "pending.json").exists()
    assert "update was kept safely" in capsys.readouterr().out.lower()


def test_source_update_copy_failure_does_not_half_start(monkeypatch, tmp_path):
    import run_chat
    import shutil
    import startup_dependencies

    run_chat, install, pending = _staged_source_update(tmp_path, monkeypatch)
    monkeypatch.setattr(startup_dependencies, "sync_requirements", lambda _path: None)

    def fail_copy(*_args, **_kwargs):
        raise PermissionError("locked")

    monkeypatch.setattr(shutil, "copytree", fail_copy)
    with pytest.raises(SystemExit) as stopped:
        run_chat.apply_pending_update()

    assert stopped.value.code == 1
    assert (install / "run_chat.py").read_text() == "old launcher"
    assert pending.is_dir()
    # The rollback is persisted, so the next launcher invocation boots the
    # previous installation instead of exiting with error 1 forever.
    run_chat.apply_pending_update()
    assert (install / "run_chat.py").read_text() == "old launcher"
    assert pending.is_dir()


def test_legacy_launcher_bridge_syncs_missing_new_requirement_before_startup(
    monkeypatch, tmp_path
):
    """A 1.9.23 in-memory launcher reaches this bridge after copying 1.9.24."""
    import startup_dependencies

    requirements = tmp_path / "requirements.txt"
    requirements.write_text("tzlocal>=5.2,<6\n")
    events = []

    def missing(name):
        events.append(("probe", name))
        raise ModuleNotFoundError(name)

    def sync(path):
        events.append(("sync", Path(path)))

    monkeypatch.setattr(startup_dependencies.importlib, "import_module", missing)
    monkeypatch.setattr(startup_dependencies, "sync_requirements", sync)
    startup_dependencies.ensure_legacy_update_dependencies(requirements)
    events.append(("runtime-import", None))

    assert events == [
        ("probe", "tzlocal"),
        ("sync", requirements),
        ("runtime-import", None),
    ]


@pytest.mark.asyncio
async def test_update_finalizes_only_after_server_reports_started():
    class FakeServer:
        started = False
        should_exit = False

    class FakeUpdater:
        def __init__(self):
            self.calls = 0

        def mark_serving_ready(self):
            self.calls += 1

    server = FakeServer()
    updater = FakeUpdater()

    async def start_later():
        await asyncio.sleep(0.02)
        server.started = True

    asyncio.create_task(start_later())
    assert await _mark_updater_ready_when_serving(server, updater, timeout=0.2)
    assert updater.calls == 1

    failed_server = FakeServer()
    failed_server.should_exit = True
    failed_updater = FakeUpdater()
    assert not await _mark_updater_ready_when_serving(
        failed_server, failed_updater, timeout=0.2
    )
    assert failed_updater.calls == 0


def test_direct_python_owns_one_rollback_relaunch_but_bat_does_not(
    monkeypatch, tmp_path
):
    import run_chat

    install = tmp_path / "install"
    install.mkdir()
    marker = install / ".update-rollback"
    marker.write_text("rolled back")
    monkeypatch.setattr(run_chat, "__file__", str(install / "run_chat.py"))
    monkeypatch.delenv("NEXA_LAUNCHER_BAT", raising=False)
    monkeypatch.delenv("NEXA_ROLLBACK_RECOVERY_USED", raising=False)
    seen = []
    monkeypatch.setattr(
        run_chat.os,
        "execv",
        lambda executable, argv: seen.append((executable, argv)),
    )

    assert _restart_direct_after_rollback() is True
    assert seen and seen[0][0] == sys.executable
    assert not marker.exists()

    marker.write_text("rolled back")
    monkeypatch.setenv("NEXA_LAUNCHER_BAT", "1")
    assert _restart_direct_after_rollback() is False
    assert len(seen) == 1
    assert marker.exists()


@pytest.mark.asyncio
async def test_direct_recovery_is_available_again_after_stable_boot(monkeypatch, tmp_path):
    import run_chat
    from types import SimpleNamespace

    marker = tmp_path / ".update-rollback"
    monkeypatch.setattr(run_chat, "__file__", str(tmp_path / "run_chat.py"))
    monkeypatch.delenv("NEXA_LAUNCHER_BAT", raising=False)
    monkeypatch.delenv("NEXA_ROLLBACK_RECOVERY_USED", raising=False)
    executions = []
    monkeypatch.setattr(run_chat.os, "execv", lambda *args: executions.append(args))
    updater = SimpleNamespace(mark_serving_ready=lambda: None)

    for attempt in range(2):
        marker.write_text("rolled back")
        assert _restart_direct_after_rollback()
        assert len(executions) == attempt + 1
        marker.write_text("same failed boot")
        assert not _restart_direct_after_rollback()
        failed_server = SimpleNamespace(started=False, should_exit=True)
        assert not await _mark_updater_ready_when_serving(failed_server, updater)
        assert not _restart_direct_after_rollback()
        marker.unlink()
        healthy_server = SimpleNamespace(started=True, should_exit=False)
        assert await _mark_updater_ready_when_serving(healthy_server, updater)
        assert "NEXA_ROLLBACK_RECOVERY_USED" not in run_chat.os.environ
