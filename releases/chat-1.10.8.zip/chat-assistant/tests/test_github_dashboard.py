from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def github_client(settings, monkeypatch):
    settings.relay_url = ""
    monkeypatch.delenv("CHAT_RELAY_SECRET", raising=False)
    monkeypatch.delenv("CHAT_RELAY_URL", raising=False)
    monkeypatch.delenv("REPLIT_DEV_DOMAIN", raising=False)

    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    app = create_app(runtime)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://test"
    ) as client:
        client.app = app
        yield client
    await runtime.stop()


async def setup(github_client) -> str:
    response = await github_client.post(
        "/setup",
        data={"password": "hunter2secure", "confirm": "hunter2secure"},
    )
    assert response.status_code == 303
    token = github_client.cookies.get(COOKIE)
    return github_client.app.state.sessions.csrf_for(token)


async def test_github_page_stays_behind_dashboard_auth(github_client):
    response = await github_client.get("/github")
    assert response.status_code == 303
    assert response.headers["location"] == "/setup"

    await setup(github_client)
    response = await github_client.get("/github")
    assert response.status_code == 200
    assert "GitHub Sync & Publish" in response.text
    assert "separate operator-only publishing credential" in response.text


async def test_github_status_never_exposes_credentials(github_client):
    await setup(github_client)
    response = await github_client.get("/api/github/status")
    assert response.status_code == 200
    body = response.json()
    assert body["available"] is False
    assert body["authenticated"] is False
    assert body["release_permissions"] == "separate"
    assert "secret" not in response.text.casefold()
    assert "token" not in response.text.casefold()


async def test_github_status_uses_hosted_replit_relay_environment(settings, monkeypatch):
    settings.relay_url = ""
    monkeypatch.setenv("CHAT_RELAY_SECRET", "managed-relay-test-secret")
    monkeypatch.delenv("CHAT_RELAY_URL", raising=False)
    monkeypatch.setenv("REPLIT_DEV_DOMAIN", "jarvis-relay.example.test")
    captured = {}

    class FakeBrokerClient:
        def __init__(self, base_url, secret):
            captured["base_url"] = base_url
            captured["secret"] = secret

        async def status(self):
            return {"login": "connected-user"}

    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "GitHubBrokerClient", FakeBrokerClient)
    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    app = create_app(runtime)
    transport = httpx.ASGITransport(app=app)
    try:
        async with httpx.AsyncClient(
            transport=transport, base_url="http://test"
        ) as client:
            client.app = app
            await setup(client)
            response = await client.get("/api/github/status")
    finally:
        await runtime.stop()

    assert response.status_code == 200
    assert response.json()["available"] is True
    assert response.json()["authenticated"] is True
    assert captured == {
        "base_url": "https://jarvis-relay.example.test",
        "secret": "managed-relay-test-secret",
    }
    assert "managed-relay-test-secret" not in response.text


async def test_managed_relay_secret_never_uses_custom_relay_url(settings, monkeypatch):
    settings.relay_url = "https://untrusted-relay.example"
    monkeypatch.setenv("CHAT_RELAY_SECRET", "managed-relay-test-secret")
    monkeypatch.delenv("REPLIT_DEV_DOMAIN", raising=False)

    class ForbiddenBrokerClient:
        def __init__(self, base_url, secret):
            raise AssertionError("managed secret must not be sent to a custom URL")

    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "GitHubBrokerClient", ForbiddenBrokerClient)
    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    app = create_app(runtime)
    transport = httpx.ASGITransport(app=app)
    try:
        async with httpx.AsyncClient(
            transport=transport, base_url="http://test"
        ) as client:
            client.app = app
            await setup(client)
            response = await client.get("/api/github/status")
    finally:
        await runtime.stop()

    body = response.json()
    assert response.status_code == 200
    assert body["available"] is False
    assert body["authenticated"] is False
    assert "hosted GitHub Relay is unavailable" in body["error"]
    assert "managed-relay-test-secret" not in response.text


def test_github_unavailable_message_surfaces_safe_server_reason():
    script = (dashboard_module.BASE_DIR / "static" / "github.js").read_text(
        encoding="utf-8"
    )
    assert '"GitHub unavailable: " + st.error' in script


async def test_github_writes_require_csrf(github_client):
    await setup(github_client)
    response = await github_client.post(
        "/api/github/config",
        json={"repository": "owner/fork", "branch": "main"},
        headers={"x-csrf": "forged"},
    )
    assert response.status_code == 403