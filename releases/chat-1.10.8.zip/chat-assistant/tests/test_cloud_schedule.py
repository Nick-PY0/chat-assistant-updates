from __future__ import annotations

import hashlib
import hmac
import json
import uuid

import httpx
import pytest

from apps.tool_service.schemas import online_tool_declarations
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from integrations.cloud_schedule import (
    CloudScheduleClient,
    CloudScheduleError,
    CloudScheduleService,
)


def names(settings) -> set[str]:
    return {item["name"] for item in online_tool_declarations(settings)}


def test_cloud_tools_are_advertised_only_after_explicit_opt_in(settings):
    assert "create_alarm" not in names(settings)
    settings.cloud_schedule_enabled = True
    assert {
        "create_event", "create_reminder", "create_alarm", "list_schedule",
        "get_current_item", "get_next_item", "update_item", "cancel_item",
        "complete_item", "search_schedule", "get_school_day",
    } <= names(settings)


@pytest.mark.asyncio
async def test_client_uses_purpose_token_and_contract_paths():
    seen = []

    def handler(request: httpx.Request):
        seen.append(request)
        return httpx.Response(200, json={"id": "item-1", "version": 1})

    client = CloudScheduleClient(
        "https://jarvis.example", "relay-secret",
        transport=httpx.MockTransport(handler),
    )
    await client.create_item({
        "type": "alarm", "title": "Wake up", "startAt": "2030-01-01T06:30:00Z",
        "endAt": None, "timezone": "UTC", "recurrence": None, "notifications": [],
        "priority": "normal", "ringPolicy": "alarm", "status": "active",
        "source": "voice", "metadata": {},
    }, idempotency_key="stable-create")
    await client.update_item("item-1", 1, {"status": "completed"}, idempotency_key="stable-update")

    expected = hmac.new(
        b"relay-secret", b"jarvis-scheduler:v1", hashlib.sha256
    ).hexdigest()
    assert [request.url.path for request in seen] == [
        "/api/jarvis/items", "/api/jarvis/items/item-1",
    ]
    assert all(request.headers["authorization"] == f"Bearer {expected}" for request in seen)
    assert seen[0].headers["idempotency-key"] == "stable-create"
    assert uuid.UUID(json.loads(seen[0].content)["id"]).version == 5
    assert json.loads(seen[1].content) == {
        "expectedVersion": 1, "patch": {"status": "completed"},
    }
    assert seen[1].headers["if-match-version"] == "1"


@pytest.mark.asyncio
async def test_cloud_failure_is_explicit_and_never_a_local_fallback(settings, store):
    settings.relay_url = "https://jarvis.example"
    settings.cloud_schedule_enabled = True
    await store.add("relay", "encrypted-relay-secret", purpose="chat")

    class FailedClient:
        def __init__(self, *_args, **_kwargs):
            pass

        async def create_item(self, *_args, **_kwargs):
            raise CloudScheduleError("cloud unavailable")

    service = CloudScheduleService(settings, store, client_factory=FailedClient)
    with pytest.raises(CloudScheduleError, match="cloud unavailable"):
        await service.dispatch("create_alarm", {
            "title": "Wake up", "start": "2030-01-01T06:30:00Z", "timezone": "UTC",
        })


@pytest.mark.asyncio
async def test_mutations_require_stable_id_and_expected_version(settings, store):
    settings.relay_url = "https://jarvis.example"
    settings.cloud_schedule_enabled = True
    await store.add("relay", "relay-secret", purpose="chat")
    service = CloudScheduleService(settings, store)
    with pytest.raises(CloudScheduleError, match="ID and version"):
        await service.dispatch("cancel_item", {"id": "one of several"})
    with pytest.raises(CloudScheduleError, match="date, time, AM or PM, and timezone"):
        await service.dispatch("create_reminder", {"title": "Study"})


@pytest.mark.asyncio
async def test_mutation_retry_reuses_idempotency_key():
    attempts = []

    def handler(request: httpx.Request):
        attempts.append(request.headers["idempotency-key"])
        if len(attempts) == 1:
            raise httpx.ConnectError("uncertain connection", request=request)
        return httpx.Response(200, json={"id": "item-1", "version": 1})

    client = CloudScheduleClient(
        "https://jarvis.example", "relay-secret",
        transport=httpx.MockTransport(handler),
    )
    await client.create_item({"title": "Study"}, idempotency_key="one-stable-key")
    assert attempts == ["one-stable-key", "one-stable-key"]


@pytest.mark.asyncio
async def test_remote_conflict_and_network_failure_are_structured():
    conflict_client = CloudScheduleClient(
        "https://jarvis.example", "relay-secret",
        transport=httpx.MockTransport(
            lambda _request: httpx.Response(
                409, json={"error": "Refresh first.", "code": "version_conflict"}
            )
        ),
    )
    with pytest.raises(CloudScheduleError) as conflict:
        await conflict_client.complete_item("item-1", 2, idempotency_key="conflict")
    assert (conflict.value.status, conflict.value.code) == (409, "version_conflict")

    def unavailable(request: httpx.Request):
        raise httpx.ConnectError("offline", request=request)

    network_client = CloudScheduleClient(
        "https://jarvis.example", "relay-secret",
        transport=httpx.MockTransport(unavailable),
    )
    with pytest.raises(CloudScheduleError) as network:
        await network_client.create_item({"title": "Study"}, idempotency_key="network")
    assert network.value.code == "cloud_schedule_unavailable"
    assert "Nothing was saved locally" in str(network.value)


@pytest.mark.asyncio
async def test_voice_cloud_failure_is_structured_without_legacy_write(db, bus, store):
    class Cloud:
        enabled = True

        async def legacy_reminder(self, _args):
            raise CloudScheduleError(
                "Cloud unavailable. Nothing was saved locally.",
                code="cloud_schedule_unavailable",
            )

    class LegacyReminders:
        called = False

        async def set_reminder(self, **_kwargs):
            self.called = True
            return {"saved": "locally"}

    legacy = LegacyReminders()
    tools = ToolService(
        db, bus, TimerManager(db, bus), store,
        reminders=legacy, cloud_schedule=Cloud(),
    )
    result = await tools.dispatch("call-1", "set_reminder", {
        "message": "Study", "at_local": "2030-01-01T19:00:00Z", "timezone": "UTC",
    })
    assert result == {
        "error": "Cloud unavailable. Nothing was saved locally.",
        "code": "cloud_schedule_unavailable",
        "status": 503,
    }
    assert legacy.called is False