"""The first concurrent requests after a restart share one revocation owner."""
import asyncio

import httpx

from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime
from chat_core.security.auth import SessionManager, hash_password


async def test_cold_start_concurrent_logouts_cannot_lose_revocations(settings, monkeypatch):
    monkeypatch.delenv("SESSION_SECRET", raising=False)
    rt = Runtime(settings)
    await rt.start(voice=False, cloud=False, monitoring=False)
    try:
        await rt.db.set_setting("admin_password_hash", hash_password("test-password-only"))
        await rt.db.set_setting("session_secret", "cold-start-test-only")
        issuer = SessionManager("cold-start-test-only", 3600)
        tokens = [issuer.issue(), issuer.issue()]
        original_get = rt.db.get_setting
        loads = 0

        async def delayed_get(key):
            nonlocal loads
            value = await original_get(key)
            if key == "session_security_state":
                loads += 1
                await asyncio.sleep(0.02)
            return value

        monkeypatch.setattr(rt.db, "get_setting", delayed_get)
        app = create_app(rt)
        assert not hasattr(app.state, "sessions")

        async def logout(token):
            async with httpx.AsyncClient(
                transport=httpx.ASGITransport(app=app),
                base_url="http://test",
            ) as client:
                return await client.post(
                    "/logout",
                    headers={"cookie": f"{COOKIE}={token}"},
                    data={"_csrf": issuer.csrf_for(token)},
                )

        results = await asyncio.gather(*(logout(token) for token in tokens))
        assert [result.status_code for result in results] == [303, 303]
        assert loads == 1
        reloaded = create_app(rt)
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=reloaded), base_url="http://test"
        ) as client:
            for token in tokens:
                response = await client.get(
                    "/api/state", headers={"cookie": f"{COOKIE}={token}"}
                )
                assert response.status_code == 401
    finally:
        await rt.stop()