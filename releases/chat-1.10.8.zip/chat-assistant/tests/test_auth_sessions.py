"""Focused signed session lifetime and compatibility tests."""

from __future__ import annotations

import time

from itsdangerous import TimestampSigner

import chat_core.security.auth as auth_module
from chat_core.security.auth import SessionManager


def test_session_ttl_is_signed_and_server_bounded():
    sessions = SessionManager("ttl-test-secret", 86400)
    token = sessions.issue(sessions.remembered_max_age)
    assert sessions.validate(token) is not None

    payload, timestamp = sessions._serializer.loads(token, return_timestamp=True)
    payload["ttl"] = sessions.remembered_max_age + 1
    overlong = sessions._serializer.dumps(payload)
    assert sessions.validate(overlong) is None

    pieces = token.split(".")
    pieces[0] = ("A" if pieces[0][0] != "A" else "B") + pieces[0][1:]
    assert sessions.validate(".".join(pieces)) is None


def test_per_session_ttl_expires_and_legacy_cookie_keeps_normal_ttl(monkeypatch):
    sessions = SessionManager("expiry-test-secret", 60)
    now = int(time.time())
    monkeypatch.setattr(TimestampSigner, "get_timestamp", lambda self: now - 61)
    expired = sessions.issue(60)
    legacy = sessions._serializer.dumps({"sid": "legacy", "generation": 0})
    monkeypatch.undo()

    assert sessions.validate(expired) is None
    assert sessions.validate(legacy) is None

    current_legacy = sessions._serializer.dumps({
        "sid": "current-legacy",
        "generation": 0,
    })
    assert sessions.validate(current_legacy) is not None


async def test_long_session_revocation_uses_its_signed_expiry():
    persisted = []

    async def persist(state):
        persisted.append(state)

    sessions = SessionManager(
        "revocation-horizon-test-secret",
        86400,
        persist_security_state=persist,
    )
    token = sessions.issue(sessions.remembered_max_age)
    assert await sessions.revoke(token)
    expiry = next(iter(persisted[-1]["revoked"].values()))
    assert expiry > int(time.time()) + 29 * 86400


def test_admin_capability_is_session_bound_and_exposes_only_timing():
    sessions = SessionManager("admin-capability-test-secret", 86400)
    session = sessions.issue()
    other_session = sessions.issue()
    capability = sessions.issue_capability(session, "remote-admin", 900)

    info = sessions.capability_info(session, capability, "remote-admin", 900)
    assert info is not None
    assert set(info) == {"issued_at", "expires_at", "ttl_seconds"}
    assert 0 < info["ttl_seconds"] <= 900
    assert sessions.capability_info(
        other_session, capability, "remote-admin", 900
    ) is None
    assert sessions.capability_info(
        session, capability, "different-scope", 900
    ) is None
    payload, signature = capability.rsplit(".", 1)
    bad_signature = ("A" if signature[0] != "A" else "B") + signature[1:]
    assert sessions.capability_info(
        session, payload + "." + bad_signature, "remote-admin", 900
    ) is None


def test_admin_capability_expiry_is_enforced_without_returning_token_material(
    monkeypatch,
):
    sessions = SessionManager("admin-capability-expiry-secret", 86400)
    session = sessions.issue()
    capability = sessions.issue_capability(session, "remote-admin", 1)
    now = int(time.time())
    monkeypatch.setattr(auth_module.time, "time", lambda: now + 2)
    assert sessions.capability_info(
        session, capability, "remote-admin", 900
    ) is None