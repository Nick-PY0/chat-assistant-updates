from __future__ import annotations

import httpx
import pytest

from integrations.lg_webos.screenshot import (
    MAX_SCREENSHOT_BYTES,
    TVScreenshotError,
    fetch_tv_screenshot,
    validate_jpeg_bytes,
    validate_tv_screenshot_url,
)

JPEG = (
    b"\xff\xd8"
    b"\xff\xe0\x00\x02"
    b"\xff\xc0\x00\x11\x08\x00\x01\x00\x01\x03"
    b"\x01\x11\x00\x02\x11\x00\x03\x11\x00"
    b"\xff\xda\x00\x0c\x03\x01\x00\x02\x11\x03\x11\x00\x3f\x00"
    b"\x00\xff\xd9"
)


def test_screenshot_url_must_stay_on_exact_tv_host_and_safe_ports():
    safe = "https://192.168.1.50:3001/resources/screen.jpg?token=local"
    assert validate_tv_screenshot_url(safe, "192.168.1.50") == safe

    unsafe = (
        "https://evil.example:3001/screen.jpg",
        "https://user@192.168.1.50:3001/screen.jpg",
        "https://192.168.1.50:9999/screen.jpg",
        "file:///tmp/screen.jpg",
        "https://192.168.1.50:3001/screen.jpg#fragment",
    )
    for value in unsafe:
        with pytest.raises(TVScreenshotError, match="unsafe"):
            validate_tv_screenshot_url(value, "192.168.1.50")


@pytest.mark.asyncio
async def test_screenshot_fetch_is_bounded_no_redirect_and_requires_jpeg():
    async def handler(request):
        assert request.url.host == "192.168.1.50"
        assert request.headers["host"] == "tv.local:3001"
        if request.url.path == "/ok.jpg":
            return httpx.Response(200, content=JPEG)
        if request.url.path == "/redirect.jpg":
            return httpx.Response(302, headers={"location": "https://evil.example/x"})
        if request.url.path == "/large.jpg":
            return httpx.Response(
                200,
                headers={"content-length": str(MAX_SCREENSHOT_BYTES + 1)},
                content=b"",
            )
        return httpx.Response(200, content=b"not-an-image")

    transport = httpx.MockTransport(handler)
    assert await fetch_tv_screenshot(
        "https://tv.local:3001/ok.jpg",
        "tv.local",
        "192.168.1.50",
        transport=transport,
    ) == JPEG
    with pytest.raises(TVScreenshotError, match="redirected"):
        await fetch_tv_screenshot(
            "https://tv.local:3001/redirect.jpg",
            "tv.local",
            "192.168.1.50",
            transport=transport,
        )
    with pytest.raises(TVScreenshotError, match="too large"):
        await fetch_tv_screenshot(
            "https://tv.local:3001/large.jpg",
            "tv.local",
            "192.168.1.50",
            transport=transport,
        )
    with pytest.raises(TVScreenshotError, match="JPEG"):
        await fetch_tv_screenshot(
            "https://tv.local:3001/text.jpg",
            "tv.local",
            "192.168.1.50",
            transport=transport,
        )


@pytest.mark.asyncio
async def test_screenshot_fetch_rejects_unpaired_or_public_peer_addresses():
    transport = httpx.MockTransport(lambda request: httpx.Response(200, content=JPEG))
    with pytest.raises(TVScreenshotError, match="match the paired TV"):
        await fetch_tv_screenshot(
            "https://192.168.1.50:3001/screen.jpg",
            "192.168.1.50",
            "192.168.1.51",
            transport=transport,
        )
    with pytest.raises(TVScreenshotError, match="safe local"):
        await fetch_tv_screenshot(
            "https://tv.example:3001/screen.jpg",
            "tv.example",
            "8.8.8.8",
            transport=transport,
        )


def test_jpeg_validation_rejects_truncation_and_excessive_dimensions():
    assert validate_jpeg_bytes(JPEG) == (1, 1)
    with pytest.raises(TVScreenshotError, match="complete"):
        validate_jpeg_bytes(JPEG[:-2])
    oversized = JPEG.replace(
        b"\x08\x00\x01\x00\x01",
        b"\x08\x13\x88\x13\x88",
        1,
    )
    with pytest.raises(TVScreenshotError, match="oversized"):
        validate_jpeg_bytes(oversized)