"""Regression tests for the targeted changes:

  - tzdata requirement entries are present in both requirement files
  - quota_reset_timezone is trimmed of whitespace before ZoneInfo validation
  - gemini_model default is no longer the retired gemini-2.0-flash-live-001
  - relay_chat_model and relay_command_model defaults are gpt-4o-mini
  - Windows asyncio policy call is removed from run_chat.py
  - duplicate-instance preflight returns 0 when port is already in use
  - openwakeword TFLite-import warning is suppressed (not arbitrary warnings)
"""

from __future__ import annotations

import asyncio
import logging
import socket
import threading
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest

# ---------------------------------------------------------------------------
# Requirement file checks
# ---------------------------------------------------------------------------

_REPO_ROOT = Path(__file__).resolve().parents[1]


def _req_lines(filename: str) -> list[str]:
    return (
        (_REPO_ROOT / filename).read_text().splitlines()
    )


def test_tzdata_in_core_requirements():
    lines = _req_lines("requirements.txt")
    assert any("tzdata" in l for l in lines), (
        "tzdata should appear in requirements.txt for Windows timezone support"
    )


def test_tzdata_in_voice_requirements():
    lines = _req_lines("requirements-voice.txt")
    assert any("tzdata" in l for l in lines), (
        "tzdata should appear in requirements-voice.txt for standalone installs"
    )


# ---------------------------------------------------------------------------
# Settings defaults
# ---------------------------------------------------------------------------

from chat_core.config.settings import Settings


def test_gemini_model_default_is_not_retired():
    s = Settings()
    assert s.gemini_model != "models/gemini-2.0-flash-live-001", (
        "default gemini_model must not be the retired gemini-2.0-flash-live-001"
    )
    assert "live" in s.gemini_model.lower(), (
        "default gemini_model should still reference a Live model"
    )


def test_relay_defaults_are_gpt4o_mini():
    s = Settings()
    assert s.relay_chat_model == "gpt-4o-mini", (
        "relay_chat_model default should be gpt-4o-mini"
    )
    assert s.relay_command_model == "gpt-4o-mini", (
        "relay_command_model default should be gpt-4o-mini"
    )


def test_relay_defaults_can_be_overridden(tmp_path):
    import json
    cfg = tmp_path / "config.json"
    cfg.write_text(json.dumps({
        "relay_chat_model": "custom-model-x",
        "relay_command_model": "custom-model-y",
    }))
    from chat_core.config.settings import load_settings
    import os
    os.environ["CHAT_DATA_DIR"] = str(tmp_path)
    try:
        s = load_settings()
        assert s.relay_chat_model == "custom-model-x"
        assert s.relay_command_model == "custom-model-y"
    finally:
        del os.environ["CHAT_DATA_DIR"]


def test_default_assistant_prompt_uses_nexa_identity():
    prompt = Settings().system_prompt
    assert prompt.startswith("You are Nexa,")
    assert "You are Chat" not in prompt


# ---------------------------------------------------------------------------
# Timezone trimming in the settings API
# ---------------------------------------------------------------------------

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def authed_client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        # set up password and session
        await c.post(
            "/setup",
            data={"password": "testpass123", "confirm": "testpass123"},
        )
        yield c


async def _csrf(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def test_timezone_with_leading_trailing_whitespace_accepted(authed_client):
    """A timezone string with surrounding spaces should be trimmed and accepted."""
    csrf = await _csrf(authed_client)
    resp = await authed_client.post(
        "/api/settings",
        json={"quota_reset_timezone": "  America/New_York  "},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data.get("ok") is True


async def test_timezone_invalid_still_rejected(authed_client):
    """An invalid timezone (even after trimming) must still be rejected."""
    csrf = await _csrf(authed_client)
    resp = await authed_client.post(
        "/api/settings",
        json={"quota_reset_timezone": "  Not/A/Real/Zone  "},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 400
    assert "timezone" in resp.json().get("error", "").lower()


async def test_timezone_saved_trimmed(authed_client, rt):
    """The saved value should have no surrounding whitespace."""
    csrf = await _csrf(authed_client)
    await authed_client.post(
        "/api/settings",
        json={"quota_reset_timezone": "  Europe/London  "},
        headers={"x-csrf": csrf},
    )
    assert rt.settings.quota_reset_timezone == "Europe/London"


# ---------------------------------------------------------------------------
# Windows asyncio policy call removed from run_chat.py
# ---------------------------------------------------------------------------

def test_windows_proactor_policy_not_called_in_run_chat():
    src = (_REPO_ROOT / "run_chat.py").read_text()
    assert "WindowsProactorEventLoopPolicy" not in src, (
        "WindowsProactorEventLoopPolicy should have been removed from run_chat.py"
    )


# ---------------------------------------------------------------------------
# Duplicate-instance preflight
# ---------------------------------------------------------------------------

from run_chat import _port_already_answering, dashboard_port_available


def test_port_not_in_use_returns_false(unused_tcp_port):
    # _port_already_answering returns True when something IS listening
    assert _port_already_answering("127.0.0.1", unused_tcp_port) is False


@pytest.fixture
def unused_tcp_port():
    """Find a free port, return it (not bound)."""
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture
def listening_port():
    """Bind a TCP server socket on a free port, yield the port, then close."""
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    port = server.getsockname()[1]
    yield port
    server.close()


def test_port_in_use_returns_true(listening_port):
    assert _port_already_answering("127.0.0.1", listening_port) is True


async def test_main_exits_0_when_port_already_in_use(listening_port, monkeypatch, tmp_path):
    """main() should return 0 (friendly exit) when Chat is already on the port."""
    import sys
    import os

    # Point data dir at tmp_path so load_settings does not touch the real dir
    os.environ["CHAT_DATA_DIR"] = str(tmp_path)
    try:
        import run_chat
        # dashboard_port_available returns False = port is NOT free (already in use)
        monkeypatch.setattr(
            run_chat, "dashboard_port_available",
            lambda host, port: False,
        )
        # _verify_chat_on_port: claim it IS Chat to get the friendly message
        monkeypatch.setattr(
            run_chat, "_verify_chat_on_port",
            lambda host, port: True,
        )
        # Mutex always succeeds on Linux; on Windows also let it through
        monkeypatch.setattr(run_chat, "_acquire_windows_mutex", lambda: True)
        # parse_args needs to not conflict with pytest's argv
        monkeypatch.setattr(sys, "argv", ["run_chat.py"])
        result = await run_chat.main()
        assert result == 0
    finally:
        del os.environ["CHAT_DATA_DIR"]


# ---------------------------------------------------------------------------
# openwakeword TFLite warning suppression
# ---------------------------------------------------------------------------

from apps.audio import engine as audio_engine


def test_oww_tflite_warning_is_suppressed(monkeypatch):
    """The known tflite-import warning from openwakeword must be filtered out."""
    received: list[logging.LogRecord] = []

    class CapturingHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            received.append(record)

    handler = CapturingHandler(level=logging.WARNING)
    root = logging.getLogger()
    root.addHandler(handler)

    class FakeWakeModel:
        def __init__(self, wakeword_models=None):
            # Emit exactly the warning openwakeword emits when tflite is absent
            logging.warning(
                "Tried to import the tflite runtime, but it was not found. "
                "Trying to switching to onnxruntime instead, if appropriate "
                "models are available."
            )

    monkeypatch.setattr(audio_engine, "WakeModel", FakeWakeModel, raising=False)
    try:
        model, reason = audio_engine._load_wake_model_blocking("hey_jarvis")
    finally:
        root.removeHandler(handler)

    _tflite_prefix = "Tried to import the tflite runtime"
    tflite_records = [
        r for r in received
        if _tflite_prefix in r.getMessage()
    ]
    assert tflite_records == [], (
        "The openwakeword TFLite-import warning should be suppressed"
    )


def test_other_warnings_are_not_suppressed(monkeypatch):
    """A different warning from the wake model must still pass through."""
    received: list[logging.LogRecord] = []

    class CapturingHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            received.append(record)

    handler = CapturingHandler(level=logging.WARNING)
    root = logging.getLogger()
    root.addHandler(handler)

    other_msg = "some other completely different warning"

    class FakeWakeModel:
        def __init__(self, wakeword_models=None):
            logging.warning(other_msg)

    monkeypatch.setattr(audio_engine, "WakeModel", FakeWakeModel, raising=False)
    try:
        audio_engine._load_wake_model_blocking("hey_jarvis")
    finally:
        root.removeHandler(handler)

    other_records = [r for r in received if other_msg in r.getMessage()]
    assert other_records, "Non-tflite warnings must not be suppressed"
