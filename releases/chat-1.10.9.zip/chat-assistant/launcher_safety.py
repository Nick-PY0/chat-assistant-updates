"""Small, dependency-free safety primitives used before Nexa imports itself.

This module intentionally has no imports from ``chat_core`` or ``apps``.  The
launcher uses it while a staged update may replace those packages.
"""

from __future__ import annotations

import errno
import contextlib
import os
import socket
from dataclasses import dataclass
from pathlib import Path


DEFAULT_PORT_ATTEMPTS = 16


class LockAcquireError(RuntimeError):
    """The lock could not be created or managed safely."""


class DashboardBindError(RuntimeError):
    """The requested dashboard address cannot be bound."""


class PortInUseError(DashboardBindError):
    """Every permitted candidate dashboard port is already in use."""


@dataclass
class FileLock:
    """An advisory OS lock whose lifetime is the lifetime of this object."""

    path: Path
    _fd: int
    _released: bool = False

    def release(self) -> None:
        """Release only this process's lock; the marker file is left in place.

        A marker's timestamp says nothing about whether an owner is still
        alive, so it is deliberately never used for stale-lock deletion.
        """
        if self._released:
            return
        try:
            if os.name == "nt":
                import msvcrt

                os.lseek(self._fd, 0, os.SEEK_SET)
                with contextlib.suppress(OSError):
                    msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                with contextlib.suppress(OSError):
                    fcntl.flock(self._fd, fcntl.LOCK_UN)
        finally:
            os.close(self._fd)
            self._released = True

    def __enter__(self) -> FileLock:
        return self

    def __exit__(self, *_exc) -> None:
        self.release()


def data_dir_lock_path(data_dir: str | Path) -> Path:
    return Path(data_dir).expanduser().resolve() / ".nexa-instance.lock"


def installation_lock_path(installation_root: str | Path) -> Path:
    return Path(installation_root).expanduser().resolve() / ".nexa-update.lock"


def _is_lock_busy(exc: OSError) -> bool:
    return exc.errno in {errno.EACCES, errno.EAGAIN, errno.EWOULDBLOCK} or getattr(
        exc, "winerror", None
    ) in {32, 33}


def try_acquire_file_lock(path: str | Path) -> FileLock | None:
    """Atomically acquire an OS lock, returning ``None`` only if it is held.

    Unlike a create/delete sentinel, this remains correct after a crash: the
    operating system releases the lock with the owning process.  The lock file
    itself may remain and is harmless.
    """
    lock_path = Path(path)
    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o600)
    except OSError as exc:
        raise LockAcquireError(f"cannot open lock {lock_path}: {exc}") from exc

    try:
        if os.name == "nt":
            import msvcrt

            # msvcrt locks a byte range, and a new file has no byte to lock.
            if os.fstat(fd).st_size == 0:
                os.write(fd, b"\0")
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        os.close(fd)
        if _is_lock_busy(exc):
            return None
        raise LockAcquireError(f"cannot lock {lock_path}: {exc}") from exc
    return FileLock(lock_path, fd)


def is_address_in_use(exc: OSError) -> bool:
    """Return true only for an address-in-use bind failure."""
    return exc.errno == errno.EADDRINUSE or getattr(exc, "winerror", None) == 10048


def _addresses(host: str, port: int) -> list[tuple[int, int, int, tuple]]:
    try:
        values = socket.getaddrinfo(host, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise DashboardBindError(f"invalid dashboard address {host!r}: {exc}") from exc
    return [
        (family, socktype, protocol, sockaddr)
        for family, socktype, protocol, _canonname, sockaddr in values
        if family in (socket.AF_INET, socket.AF_INET6)
    ]


def reserve_dashboard_socket(
    host: str,
    port: int,
    *,
    strict: bool = False,
    attempts: int = DEFAULT_PORT_ATTEMPTS,
) -> tuple[socket.socket, int]:
    """Bind and retain a dashboard socket, with a bounded EADDRINUSE fallback.

    The returned socket must be passed to Uvicorn's ``serve(sockets=...)``.
    This removes the check-then-bind race.  Only address-in-use errors advance
    to another port; malformed addresses, permissions, and other bind failures
    are reported rather than being misrepresented as a busy port.
    """
    try:
        requested = int(port)
    except (TypeError, ValueError) as exc:
        raise DashboardBindError(f"invalid dashboard port {port!r}") from exc
    if not 0 <= requested <= 65535:
        raise DashboardBindError(f"invalid dashboard port {requested}; expected 0-65535")
    if not isinstance(host, str) or not host.strip():
        raise DashboardBindError("invalid dashboard address: it must not be empty")
    if requested == 0:
        candidates = [0]
    else:
        count = 1 if strict else max(1, int(attempts))
        candidates = list(range(requested, min(65536, requested + count)))
        # A high configured port still gets a bounded fallback rather than a
        # surprising failure solely because there is no higher numbered port.
        if len(candidates) < count:
            candidates.extend(
                range(requested - 1, max(-1, requested - (count - len(candidates)) - 1), -1)
            )

    last_busy: OSError | None = None
    for candidate in candidates:
        addresses = _addresses(host, candidate)
        if not addresses:
            raise DashboardBindError(f"invalid dashboard address {host!r}")
        candidate_busy = False
        for family, socktype, protocol, sockaddr in addresses:
            sock = socket.socket(family, socktype, protocol)
            try:
                # Windows otherwise permits surprising same-address sharing.
                if os.name == "nt" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
                sock.bind(sockaddr)
                sock.listen(128)
                sock.set_inheritable(False)
                return sock, int(sock.getsockname()[1])
            except OSError as exc:
                sock.close()
                if is_address_in_use(exc):
                    candidate_busy = True
                    last_busy = exc
                    continue
                raise DashboardBindError(
                    f"cannot bind dashboard to {host}:{candidate}: {exc}"
                ) from exc
        if not candidate_busy:
            break
    suffix = " (strict port selection)" if strict else ""
    raise PortInUseError(
        f"dashboard port {requested} is already in use; no free fallback was found{suffix}"
    ) from last_busy