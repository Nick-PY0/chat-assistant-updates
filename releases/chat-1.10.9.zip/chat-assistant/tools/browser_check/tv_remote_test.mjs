// TV remote browser-level test: loads the real /devices page in jsdom with
// scripts enabled, intercepts only the /api/tv endpoints, and drives the
// remote through offline → connected → typing → mute flows. Guards:
//   * remote visible while paired-but-offline (power key can wake the TV)
//   * one state-aware power key (wake vs power off) + best-effort labelling
//   * non-power controls disabled while offline
//   * polling must NOT clobber the text composer's value or focus
//   * Type / Type + Enter post the bounded type_text command and clear only
//     on success
import assert from "node:assert/strict";
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = process.env.CHAT_BROWSER_CHECK_BASE || "http://127.0.0.1:8756";
let cookie = "";

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}
async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// ---- session: harness.mjs already ran /setup with this password ----
{
  const form = new URLSearchParams();
  form.set("password", "Testpass123");
  const r = await req("/login", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", origin: BASE, referer: BASE + "/login" },
    body: form.toString(),
  });
  if (![200, 302, 303].includes(r.status)) { console.log("FATAL: login failed:", r.status); process.exit(2); }
}

const resp = await req("/devices");
if (resp.status !== 200) { console.log("FATAL: /devices HTTP", resp.status); process.exit(2); }
const html = await resp.text();

// ---- fake TV state, mutated per scenario ----
let tv = {
  enabled: true, configured: true, host: "192.168.1.50", name: "Living room TV",
  paired: true, connected: false, pairing: { status: "paired", error: "" },
  power: "off", volume: 20, muted: false, app: "", model: "LG C3",
  app_count: 0, apps_stale: false, inputs: [], wol_ready: true,
  last_error: "the TV did not answer", last_seen_at: null,
  lifecycle: "offline", seq: 1, can_command: false, busy: null,
  power_confirmed: false, fresh_seconds: null, transition_remaining: null,
  recovery: { attempt: 2, retry_in: 1.5 },
};
const commands = [];
const refreshCalls = [];
let tvFetchDelay = 0; // next GET /api/tv answers after this many ms

const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(html, {
  url: BASE + "/devices",
  runScripts: "dangerously",
  resources: "usable",
  pretendToBeVisual: true,
  virtualConsole: vc,
  beforeParse(window) {
    window.alert = () => {};
    window.confirm = () => true;
    window.fetch = (p, o = {}) => {
      const path = new URL(p, BASE + "/devices").pathname;
      // Node's global Response (jsdom has none); the page's api() helper
      // already consumes node-fetch responses via the passthrough below.
      if (path === "/api/tv" && (!o.method || o.method === "GET")) {
        const body = JSON.stringify(tv);   // state as of the request, like a real server
        const wait = tvFetchDelay; tvFetchDelay = 0;
        return new Promise((res) => setTimeout(() => res(new Response(body, {
          status: 200, headers: { "content-type": "application/json" },
        })), wait));
      }
      if (path === "/api/tv/refresh") {
        refreshCalls.push(JSON.parse(o.body || "{}"));
        return Promise.resolve(new Response(JSON.stringify(tv), {
          status: 200, headers: { "content-type": "application/json" },
        }));
      }
      if (path === "/api/tv/command") {
        const body = JSON.parse(o.body || "{}");
        commands.push(body);
        return Promise.resolve(new Response(
          JSON.stringify({ ok: true, message: "done" }),
          { status: 200, headers: { "content-type": "application/json" } },
        ));
      }
      const { signal, ...rest } = o;
      rest.headers = { ...(rest.headers || {}), cookie };
      return fetch(new URL(p, BASE + "/devices").href, rest);
    };
  },
});

await new Promise((res) => {
  let done = false;
  const finish = () => { if (!done) { done = true; setTimeout(res, 900); } };
  dom.window.addEventListener("load", finish);
  setTimeout(finish, 3000);
});

const doc = dom.window.document;
const el = (id) => doc.getElementById(id);
const poll = async () => { await dom.window.loadTv(); await new Promise((r) => setTimeout(r, 50)); };

let failures = 0;
const check = (name, fn) => {
  try { fn(); console.log("  ok  " + name); }
  catch (e) { console.log("FAIL  " + name + ": " + e.message); failures++; }
};

// ---- 1. paired but OFFLINE: remote shows, only power usable ----
check("offline: remote body is visible so the TV can be woken", () => {
  assert.notEqual(el("tv-remote").style.display, "none");
  assert.ok(el("tv-remote").classList.contains("tvr-offline"));
});
check("offline: Wake-on-LAN note is shown and labelled best effort", () => {
  assert.notEqual(el("tv-offline-note").style.display, "none");
  assert.match(el("tv-offline-note").textContent, /best\s*effort/i);
  assert.match(el("tv-power-note").textContent, /best effort/i);
});
check("offline: power key enabled (wake), other keys disabled", () => {
  assert.equal(el("tv-power").disabled, false);
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, true);
  assert.equal(el("tv-type-text").disabled, true);
  assert.equal(el("tv-vol-set").disabled, true);
});
check("offline: power click sends power_on (wake attempt)", () => {
  el("tv-power").click();
  assert.equal(commands.at(-1).action, "power_on");
});

// ---- 2. no MAC saved: power key disabled with guidance ----
tv = { ...tv, wol_ready: false, seq: 2 };
await poll();
check("offline without MAC: power key disabled with hint", () => {
  assert.equal(el("tv-power").disabled, true);
  assert.match(el("tv-power-note").textContent, /MAC address/i);
});

// ---- 3. CONNECTED: keys enable, power becomes power-off ----
tv = {
  ...tv, connected: true, power: "on", wol_ready: true, app: "Netflix",
  inputs: [{ label: "HDMI 1" }, { label: "HDMI 2" }], last_error: "",
  lifecycle: "ready", can_command: true, seq: 3, power_confirmed: true,
  fresh_seconds: 0.3, recovery: null, keyboard: { focused: false },
};
await poll();
check("connected: controls enabled, offline chrome gone", () => {
  assert.ok(!el("tv-remote").classList.contains("tvr-offline"));
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.equal(el("tv-offline-note").style.display, "none");
});
check("connected: power key is ON-state and sends power_off", () => {
  assert.ok(el("tv-power").classList.contains("on"));
  assert.match(el("tv-power-label").textContent, /^On/);
  el("tv-power").click();
  assert.equal(commands.at(-1).action, "power_off");
});
check("connected: D-pad OK sends button ok", () => {
  doc.querySelector(".tvr-ok").click();
  assert.deepEqual(commands.at(-1), { action: "button", value: "ok" });
});
check("connected: input selector populated", () => {
  assert.equal(el("tv-input").options.length, 2);
  assert.notEqual(el("tv-input-row").style.display, "none");
});
check("connected without TV focus explains how to enable typing", () => {
  assert.match(el("tv-keyboard-note").textContent, /open search/i);
  assert.match(el("tv-type-text").placeholder, /focus search/i);
});

tv = { ...tv, app: "YouTube", keyboard: { focused: false }, seq: 4 };
await poll();
check("YouTube custom keyboard explains the A-grid fallback", () => {
  assert.match(el("tv-keyboard-note").textContent, /highlight A/i);
  assert.match(el("tv-type-text").placeholder, /highlight A/i);
  assert.notEqual(el("tv-youtube-grid-confirm").style.display, "none");
});

tv = { ...tv, app: "YouTube", keyboard: { focused: true }, seq: 5 };
await poll();
check("focused TV text field is shown as ready", () => {
  assert.match(el("tv-keyboard-note").textContent, /text box ready/i);
  assert.match(el("tv-type-text").placeholder, /ready/i);
  assert.equal(el("tv-youtube-grid-confirm").style.display, "none");
});

// ---- 4. polling must not clobber the composer ----
const composer = el("tv-type-text");
composer.value = "stranger things";
composer.focus();
await poll();
await poll();
check("polling preserves composer text and focus", () => {
  assert.equal(composer.value, "stranger things");
  assert.equal(doc.activeElement, composer);
});

// ---- 5. typing commands ----
el("tv-type-send").click();
await new Promise((r) => setTimeout(r, 50));
check("Type sends type_text without submit and clears on success", () => {
  const cmd = commands.at(-1);
  assert.equal(cmd.action, "type_text");
  assert.equal(cmd.text, "stranger things");
  assert.equal(cmd.submit, false);
  assert.equal(cmd.youtube_grid_ready, false);
  assert.equal(composer.value, "");
  assert.equal(doc.activeElement, composer);
});
composer.value = "dark";
el("tv-type-go").click();
await new Promise((r) => setTimeout(r, 50));
check("Type + Enter sends submit=true", () => {
  const cmd = commands.at(-1);
  assert.equal(cmd.action, "type_text");
  assert.equal(cmd.text, "dark");
  assert.equal(cmd.submit, true);
  assert.equal(cmd.youtube_grid_ready, false);
});

tv = { ...tv, app: "YouTube", keyboard: { focused: false }, seq: 6 };
await poll();
el("tv-youtube-grid-ready").checked = true;
composer.value = "mrbeast";
el("tv-type-go").click();
await new Promise((r) => setTimeout(r, 50));
check("YouTube grid typing sends one-shot A-highlight confirmation", () => {
  const cmd = commands.at(-1);
  assert.equal(cmd.action, "type_text");
  assert.equal(cmd.text, "mrbeast");
  assert.equal(cmd.submit, true);
  assert.equal(cmd.youtube_grid_ready, true);
  assert.equal(el("tv-youtube-grid-ready").checked, false);
});
check("empty composer is rejected locally without an API call", () => {
  const before = commands.length;
  el("tv-type-send").click();
  assert.equal(commands.length, before);
  assert.match(el("tv-error").textContent, /text first/i);
});

// ---- 6. mute is state-aware ----
tv = { ...tv, muted: true, seq: 6 };
await poll();
check("muted snapshot flips the key to Unmute and sends unmute", () => {
  assert.equal(el("tv-mute").textContent, "Unmute");
  el("tv-mute").click();
  assert.equal(commands.at(-1).action, "unmute");
});

// ---- 7. Refresh button performs a real server-side health check ----
tv = { ...tv, seq: 7 };
const reloadLabel = el("tv-reload").textContent;
el("tv-reload").click();
await new Promise((r) => setTimeout(r, 80));
check("Refresh button POSTs /api/tv/refresh and re-enables itself", () => {
  assert.equal(refreshCalls.length, 1);
  assert.equal(el("tv-reload").disabled, false);
  assert.equal(el("tv-reload").textContent, reloadLabel);
});

// ---- 8. DEGRADED: truthful state, visible reason, controls paused ----
tv = {
  ...tv, seq: 8, connected: false, lifecycle: "degraded", can_command: false,
  last_error: "the TV stopped answering; reconnecting",
  recovery: { attempt: 1, retry_in: 0 },
};
await poll();
check("degraded: controls disabled with a visible recovery reason", () => {
  assert.ok(el("tv-remote").classList.contains("tvr-offline"));
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, true);
  assert.notEqual(el("tv-ctl-note").style.display, "none");
  assert.match(el("tv-ctl-note").textContent, /reconnecting/i);
  assert.match(el("tv-state").textContent, /connection trouble/i);
});

// ---- 9. POWERING ON: live progress, power key disabled ----
tv = {
  ...tv, seq: 9, lifecycle: "powering_on", can_command: false,
  recovery: null, transition_remaining: 12.5, last_error: "",
};
await poll();
check("powering_on: waking label, disabled power key, no stale off-note", () => {
  assert.equal(el("tv-power").disabled, true);
  assert.match(el("tv-power-label").textContent, /waking/i);
  assert.match(el("tv-state").textContent, /powering on/i);
  assert.equal(el("tv-offline-note").style.display, "none");
});

// ---- 10. back to READY without any page reload ----
tv = {
  ...tv, seq: 10, connected: true, lifecycle: "ready", can_command: true,
  power: "on", power_confirmed: true, transition_remaining: null, fresh_seconds: 0.2,
};
await poll();
check("recovered: controls re-enable without a page reload", () => {
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.equal(el("tv-ctl-note").style.display, "none");
  assert.ok(!el("tv-remote").classList.contains("tvr-offline"));
});

// ---- Roku ECP is intentionally narrower than LG webOS -----------------
tv = {
  ...tv, platform: "roku", seq: 13, name: "Den Roku", model: "TCL Roku TV",
  power: null, muted: null, volume: null, wol_ready: false, inputs: [],
  pairing: { status: "linked", error: "" },
  capabilities: {
    power: false, volume_set: false, volume_delta: true, mute: false,
    media: true, buttons: true, apps: true, input: false, text: false, pairing: false,
  },
  media_actions: ["play", "rewind", "fast_forward"],
  button_actions: ["up", "down", "left", "right", "ok", "back", "home", "menu"],
};
await poll();
check("Roku: shows link terminology and hides unsupported LG-only actions", () => {
  assert.match(el("tv-title").textContent, /Roku/i);
  assert.equal(el("tv-power-row").style.display, "none");
  assert.equal(el("tv-vol-set-row").style.display, "none");
  assert.equal(el("tv-mute").style.display, "none");
  assert.equal(el("tv-text-row").style.display, "none");
  assert.equal(doc.querySelector("[data-tvmedia='pause']").style.display, "none");
  assert.equal(doc.querySelector("[data-tvmedia='stop']").style.display, "none");
  assert.equal(doc.querySelector("[data-tvbtn='exit']").style.display, "none");
  assert.match(el("tv-pair-status").textContent, /linked/i);
});
check("Roku: remaining remote controls stay usable", () => {
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.equal(doc.querySelector("[data-tvdelta='5']").disabled, false);
});

// ---- 11. a STALE (older-seq) response must never repaint newer state ----
tv = { ...tv, seq: 4, connected: false, lifecycle: "offline", can_command: false, power: "off" };
await poll();
check("older seq response is dropped (no gray-out from a stale poll)", () => {
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.match(el("tv-state").textContent, /connected/i);
  assert.ok(!el("tv-remote").classList.contains("tvr-offline"));
});

// ---- 12. newest-request-wins: a slow older response loses ----
tv = {
  ...tv, seq: 14, connected: false, lifecycle: "offline", can_command: false,
  power: "off", last_error: "connection lost",
};
tvFetchDelay = 150;                 // request A: slow, snapshots the offline state
const pA = dom.window.loadTv();
tv = {
  ...tv, seq: 15, connected: true, lifecycle: "ready", can_command: true, power: "on",
};
const pB = dom.window.loadTv();     // request B: fast, ready
await pB; await pA;
await new Promise((r) => setTimeout(r, 30));
check("delayed older response cannot repaint the newer state", () => {
  assert.equal(doc.querySelector("[data-tvbtn='up']").disabled, false);
  assert.match(el("tv-state").textContent, /connected/i);
});

// ---- 13. unreachable-but-maybe-on is labelled honestly ----
tv = {
  // Reset Roku-only fields: this is an LG fixture and its power capability
  // must not inherit the preceding Roku snapshot.
  ...tv, platform: "lg_webos", capabilities: undefined, media_actions: undefined,
  button_actions: undefined, wol_ready: true, seq: 16, connected: false, lifecycle: "offline", can_command: false,
  power: "on", power_confirmed: false, last_error: "connection lost (TV off or unreachable)",
  recovery: { attempt: 2, retry_in: 3.0 },
};
await poll();
check("offline with unconfirmed power: honest label + wake key + retry progress", () => {
  assert.match(el("tv-state").textContent, /may still be on/i);
  assert.equal(el("tv-power").disabled, false);
  assert.match(el("tv-power-label").textContent, /unreachable/i);
  assert.match(el("tv-ctl-note").textContent, /retrying/i);
});

// ---- page JS errors collected along the way ----
check("no page JavaScript errors", () => {
  assert.deepEqual(errors, []);
});

dom.window.close();
console.log(failures === 0 ? "TV REMOTE CHECKS PASSED" : `${failures} TV REMOTE FAILURES`);
process.exit(failures === 0 ? 0 : 1);
