const { JSDOM, VirtualConsole } = require("jsdom");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

const code = fs.readFileSync(
  path.join(__dirname, "../../apps/dashboard/static/admin.js"), "utf8",
);
const settle = () => new Promise(resolve => setImmediate(resolve));

async function fixture(api) {
  const errors = [];
  const console = new VirtualConsole();
  console.on("jsdomError", error => {
    if (!error.message.includes("navigation")) errors.push(error);
  });
  const dom = new JSDOM(`
    <div id="admin-status-bar" style="display:none">
      <span id="admin-timer"></span>
      <button id="admin-lock-btn">Lock</button>
    </div>
    <div id="admin-status-error" role="alert"></div>
  `, { runScripts: "outside-only", virtualConsole: console });
  await new Promise(resolve => {
    dom.window.document.addEventListener("DOMContentLoaded", resolve, { once: true });
  });
  dom.window.api = api;
  dom.window.eval(code);
  dom.window.document.dispatchEvent(new dom.window.Event("DOMContentLoaded"));
  await settle();
  return { dom, window: dom.window, document: dom.window.document, errors };
}

async function run() {
  let status = { remote: true, unlocked: true, session_bound: true, ttl_seconds: 899 };
  let lockCalls = 0;
  const first = await fixture(async (url, method) => {
    if (url === "/api/admin/lock") {
      assert.equal(method, "POST");
      lockCalls++;
      status = { remote: true, unlocked: false, session_bound: true };
      return status;
    }
    assert.equal(url, "/api/admin/status");
    return status;
  });
  try {
    const bar = first.document.getElementById("admin-status-bar");
    const label = first.document.getElementById("admin-timer");
    assert.equal(bar.style.display, "flex");
    assert.equal(label.textContent, "Unlocked for this sign-in");
    assert.doesNotMatch(bar.textContent, /expires|remaining|\d+m/i);
    status.ttl_seconds = 1;
    await first.window.checkAdminStatus();
    assert.equal(label.textContent, "Unlocked for this sign-in", "No countdown near login expiry");
    status = { remote: true, unlocked: false, session_bound: true };
    await first.window.checkAdminStatus();
    assert.equal(bar.style.display, "none", "Server revocation hides unlocked state");
    status = { remote: true, unlocked: true, session_bound: true };
    await first.window.checkAdminStatus();
    first.document.getElementById("admin-lock-btn").click();
    await settle();
    assert.equal(lockCalls, 1);
    assert.equal(bar.style.display, "none");
    assert.equal(first.errors.length, 0);
  } finally {
    first.window.close();
  }

  let failLock = false;
  let failStatus = false;
  const second = await fixture(async url => {
    if (url === "/api/admin/lock" && failLock) throw new Error("offline");
    if (failStatus) throw new Error("offline");
    return { remote: true, unlocked: true, session_bound: true };
  });
  try {
    failStatus = true;
    await second.window.checkAdminStatus();
    assert.equal(second.document.getElementById("admin-timer").textContent, "Status unavailable");
    assert.match(second.document.getElementById("admin-status-error").textContent, /verify/i);
    failStatus = false;
    await second.window.checkAdminStatus();
    failLock = true;
    second.document.getElementById("admin-lock-btn").click();
    await settle();
    assert.equal(second.document.getElementById("admin-timer").textContent, "Lock not confirmed");
    assert.match(second.document.getElementById("admin-status-error").textContent, /try again/i);
    assert.equal(second.document.getElementById("admin-lock-btn").disabled, false);
    assert.equal(second.errors.length, 0);
  } finally {
    second.window.close();
  }

  let pending;
  let calls = 0;
  const third = await fixture(async url => {
    if (url === "/api/admin/lock") return { unlocked: false };
    if (++calls === 1) return { remote: true, unlocked: true, session_bound: true };
    return new Promise(resolve => { pending = resolve; });
  });
  try {
    const stale = third.window.checkAdminStatus();
    third.document.getElementById("admin-lock-btn").click();
    await settle();
    pending({ remote: true, unlocked: true, session_bound: true });
    await stale;
    assert.equal(third.document.getElementById("admin-status-bar").style.display, "none",
      "A pre-lock status response cannot restore the unlocked banner");
    assert.equal(third.errors.length, 0);
  } finally {
    third.window.close();
  }
  console.log("Admin session UI tests passed: no countdown, revocation, lock, failures, stale responses.");
}

run().catch(error => {
  console.error(error);
  process.exitCode = 1;
});