#!/bin/bash
# Boots Chat on a throwaway data dir and runs harness.mjs (jsdom) against it:
# every dashboard page's JavaScript executes in browser-like document order,
# so script-ordering bugs ("api is not defined") are caught here -- pytest and
# curl execute zero JS and cannot see them.
#
# One-time setup in this directory:  npm init -y && npm i jsdom
#
HERE="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$(cd "$HERE/../.." && pwd)"
rm -rf /tmp/uitest_data
cd "$APP_DIR" || exit 3
TEST_PORT="$(python - <<'PY'
import socket
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    print(sock.getsockname()[1])
PY
)"
CHAT_DATA_DIR=/tmp/uitest_data timeout 130 python run_chat.py \
  --port "$TEST_PORT" > /tmp/uitest_server.log 2>&1 &
SERVER_PID=$!
sleep 5
cd "$HERE" || exit 3
export CHAT_BROWSER_CHECK_BASE="http://127.0.0.1:$TEST_PORT"
node harness.mjs
EC=$?
if [ "$EC" -eq 0 ]; then
  node tv_remote_test.mjs
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node voice_controller_test.mjs
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node providers_experts_test.mjs
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node navigation_test.mjs
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node test_admin_updates.js
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node test_admin_fixes.js
  EC=$?
fi
if [ "$EC" -eq 0 ]; then
  node test_admin_session.js
  EC=$?
fi
kill "$SERVER_PID" 2>/dev/null
for _ in $(seq 1 50); do
  kill -0 "$SERVER_PID" 2>/dev/null || break
  sleep 0.1
done
kill -9 "$SERVER_PID" 2>/dev/null
wait "$SERVER_PID" 2>/dev/null
exit "$EC"
