window.promptAdminUnlock = function() {
  return new Promise((resolve) => {
    const modal = document.getElementById("admin-reauth-modal");
    if (!modal) return resolve(false);
    modal.style.display = "flex";
    const pwd = document.getElementById("admin-reauth-pwd");
    const err = document.getElementById("admin-reauth-err");
    pwd.value = "";
    err.textContent = "";
    pwd.focus();
    
    const cleanup = () => {
      document.getElementById("admin-reauth-submit").onclick = null;
      document.getElementById("admin-reauth-cancel").onclick = null;
    };
    
    document.getElementById("admin-reauth-submit").onclick = async () => {
      err.textContent = "";
      try {
        const csrf = document.querySelector('meta[name="csrf"]')?.content || "";
        const resp = await fetch("/api/admin/unlock", {
          method: "POST",
          headers: {"Content-Type": "application/json", "x-csrf": csrf},
          body: JSON.stringify({password: pwd.value})
        });
        const data = await resp.json();
        if (!resp.ok) {
          throw new Error(data.error || "Unlock failed");
        }
        modal.style.display = "none";
        cleanup();
        
        if (window.checkAdminStatus) window.checkAdminStatus();
        
        resolve(true);
      } catch (e) {
        err.textContent = e.message;
      }
    };
    document.getElementById("admin-reauth-cancel").onclick = () => {
      modal.style.display = "none";
      cleanup();
      resolve(false);
    };
  });
};

document.addEventListener("DOMContentLoaded", () => {
  const statusBar = document.getElementById("admin-status-bar");
  const timer = document.getElementById("admin-timer");
  const lockBtn = document.getElementById("admin-lock-btn");
  const statusError = document.getElementById("admin-status-error");
  let statusVersion = 0;
  let locking = false;
  
  window.checkAdminStatus = async function() {
    if (!statusBar || locking) return;
    const version = ++statusVersion;
    try {
      const st = await api("/api/admin/status");
      if (version !== statusVersion || locking) return;
      statusBar.style.display = st.remote && st.unlocked ? "flex" : "none";
      timer.textContent = st.session_bound
        ? "Unlocked for this sign-in"
        : "Unlocked";
      if (statusError) statusError.textContent = "";
    } catch (e) {
      if (version !== statusVersion || locking) return;
      statusBar.style.display = "flex";
      timer.textContent = "Status unavailable";
      if (statusError) statusError.textContent = "Could not verify admin access. Check your connection.";
    }
  };
  
  if (lockBtn) {
    lockBtn.addEventListener("click", async () => {
      if (locking) return;
      locking = true;
      statusVersion++;
      lockBtn.disabled = true;
      if (statusError) statusError.textContent = "";
      try {
        await api("/api/admin/lock", "POST", {});
        if (statusBar) statusBar.style.display = "none";
        location.reload();
      } catch(e) {
        if (timer) timer.textContent = "Lock not confirmed";
        if (statusError) statusError.textContent = "Could not confirm the lock. Check your connection and try again.";
      } finally {
        locking = false;
        lockBtn.disabled = false;
      }
    });
  }
  
  if (statusBar) {
    window.checkAdminStatus();
    setInterval(window.checkAdminStatus, 30000);
  }
});