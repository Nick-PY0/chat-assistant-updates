"""Outbound dashboard broadcast connector.

The connector is deliberately a small, hostile-input ASGI server: the public
gateway is only a transport and every request is validated again here.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import unquote, urlparse

from websockets.asyncio.client import connect
from websockets.exceptions import SecurityError

PROTOCOL_MESSAGE = b"jarvis-dashboard-tunnel:v1"
MAX_FRAME = 16 * 1024 * 1024
MAX_BODY = 10 * 1024 * 1024
MAX_WS_MESSAGE = 128 * 1024
MAX_ACTIVE = 32
MAX_QUERY = 8 * 1024
MAX_HEADERS = 16 * 1024
MAX_CHUNK = 64 * 1024
_ID_RE = re.compile(r"^[A-Za-z0-9._~-]{1,64}$")
_BAD_PERCENT = re.compile(r"%(?![0-9A-Fa-f]{2})")
_ALLOWED_HEADERS = frozenset({
    "accept", "content-type", "cookie", "x-csrf", "origin", "range",
    "if-range", "if-none-match", "last-event-id", "sec-fetch-site",
})
_DESKTOP_COOKIE_NAMES = frozenset({
    "chat_session", "chat_admin_capability", "chat_google_oauth", "chat_spotify_oauth",
})
_SINGLE_HEADERS = frozenset({"cookie", "origin", "x-csrf", "content-type"})
_ATTESTATION_KEYS = frozenset({
    "verified_owner", "subject", "login_sid", "expires_at",
})
_UNSAFE = frozenset({"POST", "PUT", "PATCH", "DELETE"})
_NEVER_REMOTE = (
    "/setup", "/mobile-setup", "/ca-cert", "/ca-cert.pem",
    "/ws/companion",
)
_CLOUD_NAVIGATION_PATHS = frozenset({"/sign-in", "/account", "/account/access"})
_INTERNAL_ATTESTATION_HEADERS = frozenset({
    "owner-attestation",
    "owner_attestation",
    "x-owner-attestation",
    "x-jarvis-owner-attestation",
    "x-clerk-session-id",
    "x-clerk-subject",
})
_INTERNAL_ATTESTATION_COOKIES = frozenset({
    "owner_attestation",
    "jarvis_owner_attestation",
    "clerk_session_id",
    "clerk_subject",
    "__session",
    "__client",
    "__client_uat",
})


class _PinnedConnect(connect):
    """websockets asyncio connector that never follows HTTP redirects.

    The library's default redirect handling can move Authorization to another
    URL (and follows same-origin redirects with it).  Broadcast pins the exact
    endpoint, so every redirect is an authentication failure instead.
    """

    def process_redirect(self, exc: Exception) -> Exception | str:
        result = super().process_redirect(exc)
        if isinstance(result, str):
            return SecurityError("dashboard Relay redirects are disabled")
        return result


class BroadcastRejected(ValueError):
    """A generic protocol rejection safe to send to the gateway."""


class BroadcastPolicy:
    def __init__(self, path: Path | None = None) -> None:
        source = path or Path(__file__).with_name("broadcast_policy.json")
        data = json.loads(source.read_text(encoding="utf-8"))
        if data.get("version") != 1:
            raise RuntimeError("unsupported broadcast policy")
        self.pages = frozenset(data["pages"])
        self.methods = {
            "GET": frozenset(data.get("get", ())),
            "POST": frozenset(data.get("post", ())),
            "PUT": frozenset(data.get("put", ())),
            "DELETE": frozenset(data.get("delete", ())),
            "PATCH": frozenset(data.get("patch", ())),
        }
        self.patterns = {
            method: tuple(re.compile(pattern) for pattern in patterns)
            for method, patterns in data.get("patterns", {}).items()
        }
        self.websockets = frozenset(data["websockets"])

    @staticmethod
    def canonical_path(path: object) -> str:
        if not isinstance(path, str) or not path.startswith("/") or len(path) > 2048:
            raise BroadcastRejected()
        if any(ord(char) < 32 or ord(char) == 127 for char in path):
            raise BroadcastRejected()
        if "\\" in path or "//" in path or _BAD_PERCENT.search(path):
            raise BroadcastRejected()
        decoded = unquote(path)
        # The wire contract says paths are already decoded.  Refusing encoded
        # aliases prevents a gateway/desktop routing disagreement.
        if decoded != path or any(part in {".", ".."} for part in path.split("/")):
            raise BroadcastRejected()
        return path

    def allows_http(self, method: str, path: str) -> bool:
        if any(path == prefix or path.startswith(prefix + "/") for prefix in _NEVER_REMOTE):
            return False
        if method == "GET" and path in self.pages:
            return True
        if path in self.methods.get(method, ()):
            return True
        return any(pattern.fullmatch(path) for pattern in self.patterns.get(method, ()))

    def allows_ws(self, path: str) -> bool:
        if any(path == prefix or path.startswith(prefix + "/") for prefix in _NEVER_REMOTE):
            return False
        return path in self.websockets


def relay_endpoint(configured_url: str) -> tuple[str, str]:
    parsed = urlparse(str(configured_url or "").strip())
    if (
        parsed.scheme != "https" or not parsed.hostname or parsed.username
        or parsed.password or parsed.query or parsed.fragment
        or parsed.path not in ("", "/")
    ):
        raise BroadcastRejected()
    origin = f"https://{parsed.netloc}"
    return origin, f"wss://{parsed.netloc}/remote-link/connect"


def _headers(value: object, origin: str, *, require_origin: bool) -> list[tuple[bytes, bytes]]:
    if not isinstance(value, list):
        raise BroadcastRejected()
    total = 0
    seen: set[str] = set()
    output: list[tuple[bytes, bytes]] = []
    browser_origin = ""
    for pair in value:
        if not isinstance(pair, list) or len(pair) != 2:
            raise BroadcastRejected()
        name, item = pair
        if not isinstance(name, str) or not isinstance(item, str):
            raise BroadcastRejected()
        if name != name.lower() or not re.fullmatch(r"[a-z0-9-]+", name):
            raise BroadcastRejected()
        if any(ord(char) < 32 and char != "\t" for char in item) or "\x7f" in item:
            raise BroadcastRejected()
        total += len(name.encode()) + len(item.encode())
        if total > MAX_HEADERS:
            raise BroadcastRejected()
        if name in _SINGLE_HEADERS and name in seen:
            raise BroadcastRejected()
        seen.add(name)
        if name == "origin":
            browser_origin = item
        if name in _ALLOWED_HEADERS:
            if name == "cookie":
                item = "; ".join(
                    part.strip()
                    for part in item.split(";")
                    if "=" in part
                    and part.split("=", 1)[0].strip().lower() in _DESKTOP_COOKIE_NAMES
                )
                if not item:
                    continue
            try:
                output.append((name.encode("ascii"), item.encode("latin-1")))
            except UnicodeEncodeError:
                raise BroadcastRejected() from None
    if require_origin and browser_origin != origin:
        raise BroadcastRejected()
    # Host and transport headers from the gateway are never trusted.
    output.append((b"host", urlparse(origin).netloc.encode("ascii")))
    return output


def _owner_attestation(value: object) -> dict | None:
    """Validate the gateway-owned SSO fact carried out-of-band.

    This is deliberately not accepted from browser headers/cookies or echoed
    by the desktop. The Node gateway derives it after Clerk + DB checks and
    places it on the internal request frame; the ASGI scope keeps it separate
    from attacker-controlled HTTP headers.
    """
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != _ATTESTATION_KEYS:
        raise BroadcastRejected()
    if value.get("verified_owner") is not True:
        raise BroadcastRejected()
    subject = value.get("subject")
    login_sid = value.get("login_sid")
    expires_at = value.get("expires_at")
    now = int(time.time())
    if (
        not isinstance(subject, str)
        or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", subject)
        or not isinstance(login_sid, str)
        or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", login_sid)
        or isinstance(expires_at, bool)
        or not isinstance(expires_at, int)
        or expires_at <= now
        or expires_at > now + 300
    ):
        raise BroadcastRejected()
    return {
        "verified_owner": True,
        "subject": subject,
        "login_sid": login_sid,
        "expires_at": expires_at,
    }


def _request(frame: object, policy: BroadcastPolicy, origin: str, *, websocket: bool = False):
    if not isinstance(frame, dict):
        raise BroadcastRejected()
    request_id = frame.get("id")
    if not isinstance(request_id, str) or not _ID_RE.fullmatch(request_id):
        raise BroadcastRejected()
    path = policy.canonical_path(frame.get("path"))
    query = frame.get("query", "")
    if (
        not isinstance(query, str) or len(query.encode()) > MAX_QUERY
        or query.startswith("?") or any(ord(char) < 32 for char in query)
    ):
        raise BroadcastRejected()
    if websocket:
        if not policy.allows_ws(path):
            raise BroadcastRejected()
        headers = _headers(frame.get("headers"), origin, require_origin=True)
        return request_id, path, query, headers, _owner_attestation(
            frame.get("owner_attestation")
        )
    method = frame.get("method")
    policy_path = "/" if path == "/dashboard" else path
    if (
        not isinstance(method, str) or method != method.upper()
        or not policy.allows_http(method, policy_path)
    ):
        raise BroadcastRejected()
    headers = _headers(frame.get("headers"), origin, require_origin=method in _UNSAFE)
    body64 = frame.get("body", "")
    if not isinstance(body64, str) or len(body64) > ((MAX_BODY + 2) // 3) * 4:
        raise BroadcastRejected()
    try:
        body = base64.b64decode(body64, validate=True)
    except (ValueError, TypeError):
        raise BroadcastRejected() from None
    if len(body) > MAX_BODY:
        raise BroadcastRejected()
    return request_id, method, path, query, headers, body, _owner_attestation(
        frame.get("owner_attestation")
    )


def _secure_cookie(value: str) -> str:
    parts = [part.strip() for part in value.split(";") if part.strip()]
    names = {part.split("=", 1)[0].lower() for part in parts[1:]}
    if "secure" not in names:
        parts.append("Secure")
    if "httponly" not in names:
        parts.append("HttpOnly")
    parts = [part for part in parts if not part.lower().startswith("samesite=")]
    parts.append("SameSite=Strict")
    return "; ".join(parts)


class BroadcastConnector:
    def __init__(self, app, runtime) -> None:
        self.app = app
        self.runtime = runtime
        self.policy = BroadcastPolicy()
        self.state = "disabled"
        self.reason = ""
        self.public_url: str | None = None
        self._epoch = 0
        self._runner: asyncio.Task | None = None
        self._socket = None
        self._active: dict[str, asyncio.Task] = {}
        self._ws_inboxes: dict[str, asyncio.Queue] = {}
        self._outgoing: asyncio.Queue | None = None

    def status(self) -> dict:
        return {
            "enabled": bool(self.runtime.settings.broadcast_enabled),
            "state": self.state,
            "reason": self.reason,
            "url": self.public_url,
        }

    async def start(self) -> None:
        if self.runtime.settings.broadcast_enabled and self._runner is None:
            self._epoch += 1
            self.state = "connecting"
            self.reason = ""
            self._runner = asyncio.create_task(self._run(self._epoch))

    async def set_enabled(self, enabled: bool) -> None:
        self.runtime.settings.broadcast_enabled = enabled
        self.runtime.settings.save()
        if enabled:
            await self.start()
        else:
            await self.stop()

    async def stop(self) -> None:
        self._epoch += 1
        runner, self._runner = self._runner, None
        socket, self._socket = self._socket, None
        tasks, self._active = list(self._active.values()), {}
        self._ws_inboxes.clear()
        for task in tasks:
            task.cancel()
        if socket is not None:
            try:
                await asyncio.wait_for(socket.close(), 5)
            except (TimeoutError, OSError):
                pass
        if runner is not None and runner is not asyncio.current_task():
            runner.cancel()
            await asyncio.gather(runner, return_exceptions=True)
        await asyncio.gather(*tasks, return_exceptions=True)
        self.state = "disabled" if not self.runtime.settings.broadcast_enabled else "connecting"
        self.reason = ""
        if not self.runtime.settings.broadcast_enabled:
            self.public_url = None

    async def _configuration(self) -> tuple[str, str, str]:
        if await self.runtime.db.get_setting("admin_password_hash") is None:
            raise RuntimeError("Set the Jarvis dashboard password before enabling broadcast.")
        configured = str(self.runtime.settings.relay_url or "").strip()
        secret = ""
        if configured:
            origin, endpoint = relay_endpoint(configured)
            credentials = await self.runtime.store.list("relay") if self.runtime.store else []
            credential = next((c for c in credentials if c.status not in {"disabled", "invalid"}), None)
            if credential is None:
                raise RuntimeError("Add an active Relay credential under Providers.")
            secret = await self.runtime.store.get_secret(credential.id)
        else:
            domain = os.environ.get("REPLIT_DEV_DOMAIN", "").strip()
            secret = os.environ.get("CHAT_RELAY_SECRET", "").strip()
            if not domain or not secret or "/" in domain or urlparse(f"https://{domain}").hostname != domain.split(":")[0]:
                raise RuntimeError("Configure an HTTPS Relay URL and credential under Providers.")
            origin, endpoint = relay_endpoint(f"https://{domain}")
        token = hmac.new(secret.encode(), PROTOCOL_MESSAGE, hashlib.sha256).hexdigest()
        return origin, endpoint, token

    async def _run(self, epoch: int) -> None:
        delay = 1.0
        try:
            while self.runtime.settings.broadcast_enabled and epoch == self._epoch:
                self.state = "connecting"
                self.reason = ""
                try:
                    origin, endpoint, token = await self._configuration()
                    self.public_url = origin + "/dashboard"
                    async with _PinnedConnect(
                        endpoint,
                        additional_headers={"Authorization": f"Bearer {token}"},
                        max_size=MAX_FRAME,
                        max_queue=16,
                        ping_interval=20,
                        ping_timeout=20,
                        open_timeout=15,
                    ) as socket:
                        if epoch != self._epoch:
                            return
                        self._socket = socket
                        self._outgoing = asyncio.Queue(maxsize=128)
                        sender = asyncio.create_task(self._sender(socket, epoch))
                        try:
                            ready = json.loads(await asyncio.wait_for(socket.recv(), 15))
                            if ready != {"type": "ready", "version": 1}:
                                raise RuntimeError("Relay protocol version mismatch.")
                            self.state = "online"
                            self.reason = ""
                            delay = 1.0
                            async for raw in socket:
                                if epoch != self._epoch:
                                    break
                                await self._frame(raw, origin, epoch)
                        finally:
                            sender.cancel()
                            await asyncio.gather(sender, return_exceptions=True)
                            await self._revoke_epoch()
                except asyncio.CancelledError:
                    raise
                except RuntimeError as exc:
                    if epoch != self._epoch:
                        return
                    self.state = "error"
                    self.reason = str(exc)
                except Exception:
                    if epoch != self._epoch:
                        return
                    self.state = "error"
                    self.reason = "Could not establish the secure Relay connection."
                if self.runtime.settings.broadcast_enabled and epoch == self._epoch:
                    await asyncio.sleep(delay)
                    delay = min(delay * 2, 30.0)
        finally:
            if epoch == self._epoch:
                self._runner = None
                self._socket = None
                if self.runtime.settings.broadcast_enabled and self.state == "online":
                    self.state = "connecting"

    async def _revoke_epoch(self) -> None:
        self._socket = None
        tasks, self._active = list(self._active.values()), {}
        self._ws_inboxes.clear()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if self.runtime.settings.broadcast_enabled:
            self.state = "connecting"

    async def _sender(self, socket, epoch: int) -> None:
        while epoch == self._epoch:
            frame = await self._outgoing.get()
            await socket.send(json.dumps(frame, separators=(",", ":")))

    async def _send(self, frame: dict, epoch: int) -> None:
        if epoch != self._epoch or self._outgoing is None:
            return
        await self._outgoing.put(frame)

    async def _frame(self, raw: object, origin: str, epoch: int) -> None:
        if not isinstance(raw, str) or len(raw.encode()) > MAX_FRAME:
            raise BroadcastRejected()
        try:
            frame = json.loads(raw)
        except json.JSONDecodeError:
            raise BroadcastRejected() from None
        if not isinstance(frame, dict):
            raise BroadcastRejected()
        kind, request_id = frame.get("type"), frame.get("id")
        if kind == "cancel":
            if isinstance(request_id, str):
                task = self._active.pop(request_id, None)
                if task:
                    task.cancel()
            return
        if kind == "ws.disconnect":
            inbox = self._ws_inboxes.get(request_id)
            if inbox is not None:
                try:
                    inbox.put_nowait({
                        "type": "websocket.disconnect",
                        "code": int(frame.get("code", 1000)),
                    })
                except (ValueError, TypeError, asyncio.QueueFull):
                    task = self._active.get(request_id)
                    if task:
                        task.cancel()
            return
        if kind == "ws.receive":
            try:
                inbox = self._ws_inboxes.get(request_id)
                if inbox is None:
                    raise BroadcastRejected()
                inbox.put_nowait(self._ws_message(frame))
            except (BroadcastRejected, asyncio.QueueFull):
                if isinstance(request_id, str) and _ID_RE.fullmatch(request_id):
                    await self._send({"type": "error", "id": request_id}, epoch)
            return
        if len(self._active) >= MAX_ACTIVE or request_id in self._active:
            if isinstance(request_id, str) and _ID_RE.fullmatch(request_id):
                await self._send({"type": "error", "id": request_id}, epoch)
            return
        try:
            if kind == "http":
                parsed = _request(frame, self.policy, origin)
                task = asyncio.create_task(self._http(parsed, origin, epoch))
            elif kind == "ws.open":
                parsed = _request(frame, self.policy, origin, websocket=True)
                inbox: asyncio.Queue = asyncio.Queue(maxsize=32)
                self._ws_inboxes[request_id] = inbox
                task = asyncio.create_task(self._websocket(parsed, origin, epoch, inbox))
            else:
                raise BroadcastRejected()
        except (BroadcastRejected, asyncio.QueueFull):
            if isinstance(request_id, str) and _ID_RE.fullmatch(request_id):
                await self._send({"type": "error", "id": request_id}, epoch)
            return
        self._active[request_id] = task
        def completed(done, rid=request_id):
            self._active.pop(rid, None)
            self._ws_inboxes.pop(rid, None)
        task.add_done_callback(completed)

    @staticmethod
    def _ws_message(frame: dict) -> dict:
        if ("text" in frame) == ("bytes" in frame):
            raise BroadcastRejected()
        if "text" in frame:
            value = frame["text"]
            if not isinstance(value, str) or len(value.encode()) > MAX_WS_MESSAGE:
                raise BroadcastRejected()
            return {"type": "websocket.receive", "text": value}
        try:
            value = base64.b64decode(frame["bytes"], validate=True)
        except (TypeError, ValueError):
            raise BroadcastRejected() from None
        if len(value) > MAX_WS_MESSAGE:
            raise BroadcastRejected()
        return {"type": "websocket.receive", "bytes": value}

    async def _http(self, parsed, origin: str, epoch: int) -> None:
        request_id, method, wire_path, query, headers, body, attestation = parsed
        path = "/" if wire_path == "/dashboard" else wire_path
        received = False
        started = asyncio.Event()

        async def receive():
            nonlocal received
            if not received:
                received = True
                return {"type": "http.request", "body": body, "more_body": False}
            await asyncio.Future()

        async def send(message):
            kind = message.get("type")
            if kind == "http.response.start":
                response_headers = self._response_headers(message.get("headers", []))
                await self._send({
                    "type": "http.start", "id": request_id,
                    "status": int(message.get("status", 500)),
                    "headers": response_headers,
                }, epoch)
                started.set()
            elif kind == "http.response.body":
                data = message.get("body", b"")
                if not isinstance(data, bytes):
                    raise RuntimeError()
                more = bool(message.get("more_body"))
                for offset in range(0, max(1, len(data)), MAX_CHUNK):
                    chunk = data[offset:offset + MAX_CHUNK]
                    chunk_more = more or offset + MAX_CHUNK < len(data)
                    await self._send({
                        "type": "http.body", "id": request_id,
                        "body": base64.b64encode(chunk).decode(), "more": chunk_more,
                    }, epoch)

        scope = {
            "type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1",
            "method": method, "scheme": "https", "path": path,
            "raw_path": path.encode(), "query_string": query.encode(),
            "root_path": "", "headers": headers,
            "server": (urlparse(origin).hostname, urlparse(origin).port or 443),
            "client": ("remote-browser", 0), "extensions": {},
            "jarvis.broadcast": True,
            "jarvis.owner_attestation": attestation,
        }
        app_task = asyncio.create_task(self.app(scope, receive, send))
        try:
            await asyncio.wait_for(started.wait(), 30)
            timeout = 600 if wire_path == "/events" else 120
            await asyncio.wait_for(app_task, timeout)
        except asyncio.CancelledError:
            app_task.cancel()
            raise
        except Exception:
            app_task.cancel()
            await self._send({"type": "error", "id": request_id}, epoch)
        finally:
            await asyncio.gather(app_task, return_exceptions=True)

    def _response_headers(self, headers: object) -> list[list[str]]:
        output: list[list[str]] = [["cache-control", "no-store"]]
        if not isinstance(headers, list):
            return output
        for name_b, value_b in headers:
            try:
                name = name_b.decode("latin-1").lower()
                value = value_b.decode("latin-1")
            except Exception:
                continue
            if name in _INTERNAL_ATTESTATION_HEADERS:
                # The owner proof is an internal gateway-to-desktop fact. A
                # connector response must never reflect it into the browser.
                continue
            if name in {"connection", "transfer-encoding", "content-length", "cache-control"}:
                continue
            if name == "set-cookie":
                cookie_name = value.split("=", 1)[0].strip().lower()
                if (
                    cookie_name in _INTERNAL_ATTESTATION_COOKIES
                    or cookie_name.startswith("__clerk")
                ):
                    continue
                value = _secure_cookie(value)
            if name == "location":
                parsed = urlparse(value)
                if parsed.scheme or parsed.netloc:
                    continue
                target = parsed.path or "/"
                try:
                    target = self.policy.canonical_path(target)
                except BroadcastRejected:
                    continue
                if not (
                    self.policy.allows_http("GET", target)
                    or target in {"/login", "/dashboard"}
                    or target in _CLOUD_NAVIGATION_PATHS
                ):
                    continue
                if target == "/":
                    target = "/dashboard"
                value = target + (("?" + parsed.query) if parsed.query else "")
            output.append([name, value])
        return output

    async def _websocket(
        self, parsed, origin: str, epoch: int, inbox: asyncio.Queue
    ) -> None:
        request_id, path, query, headers, attestation = parsed
        accepted = asyncio.Event()

        async def receive():
            return await inbox.get()

        async def send(message):
            kind = message.get("type")
            if kind == "websocket.accept":
                accepted.set()
                await self._send({"type": "ws.accept", "id": request_id}, epoch)
            elif kind == "websocket.send":
                frame = {"type": "ws.send", "id": request_id}
                if message.get("text") is not None:
                    if (
                        not isinstance(message["text"], str)
                        or len(message["text"].encode()) > MAX_WS_MESSAGE
                    ):
                        raise RuntimeError()
                    frame["text"] = message["text"]
                else:
                    data = message.get("bytes", b"")
                    if not isinstance(data, bytes) or len(data) > MAX_WS_MESSAGE:
                        raise RuntimeError()
                    frame["bytes"] = base64.b64encode(data).decode()
                await self._send(frame, epoch)
            elif kind == "websocket.close":
                await self._send({
                    "type": "ws.close", "id": request_id,
                    "code": int(message.get("code", 1000)),
                }, epoch)

        scope = {
            "type": "websocket", "asgi": {"version": "3.0"}, "scheme": "wss",
            "path": path, "raw_path": path.encode(), "query_string": query.encode(),
            "root_path": "", "headers": headers,
            "server": (urlparse(origin).hostname, urlparse(origin).port or 443),
            "client": ("remote-browser", 0), "subprotocols": [], "extensions": {},
            "jarvis.broadcast": True,
            "jarvis.owner_attestation": attestation,
        }
        await inbox.put({"type": "websocket.connect"})
        app_task = asyncio.create_task(self.app(scope, receive, send))
        accept_task = asyncio.create_task(accepted.wait())
        try:
            done, _ = await asyncio.wait(
                {accept_task, app_task},
                timeout=10,
                return_when=asyncio.FIRST_COMPLETED,
            )
            if app_task in done:
                await app_task
                return
            if accept_task not in done:
                raise TimeoutError()
            await app_task
        except asyncio.CancelledError:
            try:
                inbox.put_nowait({"type": "websocket.disconnect", "code": 1001})
            except asyncio.QueueFull:
                pass
            app_task.cancel()
            raise
        except Exception:
            app_task.cancel()
            await self._send({"type": "error", "id": request_id}, epoch)
        finally:
            accept_task.cancel()
            await asyncio.gather(app_task, return_exceptions=True)
            await asyncio.gather(accept_task, return_exceptions=True)