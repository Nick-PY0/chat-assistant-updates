# Jarvis dashboard broadcast protocol

Single-owner outbound WSS gateway. Disabled by default. The desktop remains the
authority for password authentication, sessions, CSRF, voice capabilities and
all controls. No public signup; no network proxy to arbitrary host/port.

## Address and authentication

Desktop connects to `wss://<configured Relay origin>/remote-link/connect`.
Both sides pin the HTTPS origin. Node uses `JARVIS_PUBLIC_ORIGIN` in production,
or the workspace development origin in development. No redirects.
Authorization header: `Bearer <hex HMAC-SHA256>`, key = Relay credential
retrieved from encrypted desktop storage, message = UTF-8
`jarvis-dashboard-tunnel:v1`.
The server derives the expected scoped credential from `CHAT_RELAY_SECRET`.
Do not expose the credential to browsers or logs.
Only one connector is accepted at a time; a second is rejected, not a takeover.
On connection server sends `{"type":"ready","version":1}`.

## Frames (JSON; version 1)

All request IDs are random opaque strings, at most 64 characters.
Header lists are arrays of `[lowercaseName, value]`; bodies are base64.

Gateway -> desktop:

- `{type:"http", id, method, path, query, headers, body}`.
  Path is decoded/canonical and independently allowlisted by both sides.
  `/dashboard` maps to `/`; all other browser paths retain their root paths.
  Query has no leading `?`. Body is complete, at most 10 MiB decoded.
- `{type:"cancel", id}` cancels an HTTP/WS stream; it must not be replayed.
- `{type:"ws.open", id, path, query, headers}`; do NOT upgrade browser until accepted.
- `{type:"ws.receive", id, text}` or `{type:"ws.receive", id, bytes}` (base64).
- `{type:"ws.disconnect", id, code}`.

Desktop -> gateway:

- `{type:"http.start", id, status, headers}`
- `{type:"http.body", id, body, more}` (chunks at most 64 KiB decoded).
- `{type:"ws.accept", id}` after the existing app authorizes the upgrade.
- `{type:"ws.send", id, text}` or `{type:"ws.send", id, bytes}` (base64).
- `{type:"ws.close", id, code}`.
- `{type:"error", id}` produces a generic upstream-unavailable error, never exception text.

## Limits and trust

Use broadcast_policy.json as the shared method/path allowlist. Reject
backslashes, malformed percent encoding, dot segments, double slashes, control
characters, queries exceeding 8 KiB and headers exceeding 16 KiB. Never allow
setup, certificates, companion pairing/socket, settings/password/credential/
provider changes, GitHub publishing or broadcast settings via the tunnel.

In-process ASGI dispatch: scheme `https` / `wss`, configured origin Host,
client `("remote-browser", 0)` (NEVER loopback), extension
`scope["jarvis.broadcast"] = True`. Strip forwarded/host/connection headers,
allow only accept, content-type, cookie, x-csrf, origin, range,
if-range, if-none-match, last-event-id and sec-fetch-site.
Only desktop `chat_*` cookies are relayed; hosted Clerk cookies/JWTs are
consumed by the gateway and never forwarded to the connector.
Require same-origin for unsafe HTTP methods and every WS. Desktop preserves
the browser Origin and verifies it independently against the pinned origin.

For browser requests that passed the API server's verified Clerk/platform-owner
authorization, including a fresh positive Clerk Backend API session lookup
whose status is exactly `active` and whose resource ID and user ID exactly
match the verified JWT subject/session ID, the gateway adds the server-only ASGI extension
`scope["jarvis.owner_attestation"]` with exactly:

```json
{
  "verified_owner": true,
  "login_sid": "stable verified Clerk session id",
  "subject": "stable verified Clerk user id",
  "expires_at": 1730000000
}
```

`expires_at` is a Unix timestamp in seconds from the verified Clerk session,
not a browser value. The gateway must never copy this object from an HTTP
header, cookie, query, or Relay credential, and must omit it for non-owner
requests. The desktop accepts the attestation only from this ASGI scope and
requires the exact four-field shape. A matching attestation may materialize
one purpose-bound owner SSO session and remote-admin capability for that
verified Clerk login; account switching, expiry, logout, password change, and
manual admin lock revoke those grants. The remote-admin capability is never
restored merely because a later request carries an attestation.

## Pre-bootstrap password availability

While the freshly-read singleton `platform_state.owner_user_id` is `NULL`,
the API gateway may return `prebootstrap_password_gate` only for a signed-in
Clerk browser whose primary email is provider-verified. This state is an
availability bridge, not a role or owner claim: it carries no SSO attestation,
and the desktop still requires the existing `chat_session` created by the
ordinary desktop password login before serving dashboard pages or APIs. A
missing, failed, or stale state read fails closed; once `owner_user_id` is
set, non-owners receive `403` and no legacy fallback. HTTP requests and active
browser WebSockets recheck this decision, so a state transition closes a
pre-bootstrap socket.

Ownership is completed separately through the trusted hosted bootstrap UI:
an operator creates a one-use, expiring grant at
`/api/platform/operator/bootstrap-grants`, and the signed-in browser redeems
it at `/api/platform/bootstrap`. The grant is the only operation that binds
the Clerk user as owner; the pre-bootstrap password gate never changes Clerk
roles and cannot redeem ownership by itself.

Desktop password must already exist before connecting. Every response is
no-store; remote cookies are Secure, HttpOnly and SameSite=Strict. Redirects
may only target local allowlisted paths; `/` becomes `/dashboard`.
Template home links use `/dashboard` for remote requests, `/` locally.
Public gateway status (`GET /api/dashboard-status`) exposes only configured,
online and loginRequired booleans. Offline requests fail visibly with 503.

Maximum 32 active streams per connection, 16 MiB JSON frames, 10 MiB request
bodies; 128 KiB browser WS messages. Bounded queues/backpressure. HTTP first
response deadline 30s, regular responses 120s, SSE 10min (EventSource reconnects);
WS auth deadline 10s. Heartbeat / reconnect with capped backoff. Drops/disable
cancel every stream and fence old connection callbacks. Never retry a command.
Global login limit and total request/WS attempt limit, before large body reads.
No request body/frame/cookie logging. No permissive CORS on gateway routes.

## Autoscale routing

The desktop still speaks the same WSS v1 protocol. Browser and desktop
connections need not reach the same cloud instance: the gateways exchange
short-lived envelopes through shared PostgreSQL. The desktop remains the
authority for sessions, passwords, settings, and all device state.

A live connector has one shared lease with a random generation and an instance
owner. Claiming is atomic; a second connector cannot displace a live owner.
Each browser request belongs to its gateway instance and has a renewable lease.
Session and request leases fence every enqueue, delivery, reply, and cleanup.
All instances enforce one shared active-request quota and attempt limits.

Frames are encrypted with AES-256-GCM before database insertion. The encryption
key is purpose-separated from tunnel authentication and derived from the Relay
secret. Envelope routing metadata is authenticated along with its ciphertext.
Passwords, cookies, commands, response bodies, and audio are never stored as
plaintext transport payloads or written to logs. The gateway can decrypt these
buffers; this is not end-to-end encryption against the Relay operator.

Delivery claims/removes envelopes atomically before writing to a socket.
Ordering comes from the committed shared queue, not timing or notifications.
Claimed commands are never requeued: if an instance dies after claiming one,
the outcome may be unknown and the client must not automatically retry it.
Changing generation drops old work. Expired browser-request leases arrange
desktop cancellation, including when a browser gateway disappears abruptly.
SSE and browser WebSockets reconnect normally after an instance restart.

Queue size, frame size, active requests, and lifetimes are bounded. Expired
envelopes are ineligible for delivery and are cleaned up during service
activity; the mailbox is not an archive or permanent file store. Database
backup retention is separate from transport expiry.

Missing or unavailable shared storage fails broadcasting closed; it must never
silently fall back to instance-local routing. Existing independent Relay APIs
do not depend on the presence of a live desktop connection.

Use the shared development schema through the normal database tooling; the
Replit Publish flow applies its production schema. Never add startup-time or
deployment-build DDL. Autoscale is supported without sticky sessions or an
instance-count restriction. A live WSS connection may keep compute active:
Autoscale compatibility is not a promise of zero usage while broadcasting.
Publishing and enabling on the user's desktop remain separate, explicit steps.