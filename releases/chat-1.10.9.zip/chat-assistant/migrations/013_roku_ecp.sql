CREATE TABLE IF NOT EXISTS roku_ecp_devices (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT 'Roku TV',
    host TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 0,
    linked INTEGER NOT NULL DEFAULT 0,
    last_seen_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);