"""Nexa — single-process launcher.

Runs every service (audio, Gemini gateway, tools, pulse, dashboard) as
asyncio tasks in ONE quiet process. Designed to sit in a minimal console
window and use as close to zero resources as possible while idle.

Usage:
  python run_chat.py                  # everything (voice auto-disables if
                                      # audio packages/hardware are missing)
  python run_chat.py --dashboard-only # no voice, no cloud, no pulse
  python run_chat.py --no-voice       # cloud + dashboard, no microphone
  python run_chat.py --verbose        # more console output
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import logging
import os
import re
import socket
import sys

from launcher_safety import (
    DashboardBindError,
    LockAcquireError,
    PortInUseError,
    data_dir_lock_path,
    installation_lock_path,
    reserve_dashboard_socket,
    try_acquire_file_lock,
)

RESTART_CODE = 42  # run_chat.bat relaunches when Chat exits with this code

# Windows named-mutex handle held for the lifetime of this process as a
# data-directory-scoped fast path.  The cross-platform file lock is primary.
_WIN_MUTEX = None


def _install_windows_disconnect_handler() -> None:
    """Keep normal browser/socket disconnects out of the Windows console.

    The Proactor loop can report a peer's ordinary TCP reset a second time
    from its internal ``connection_lost`` callback, after the WebSocket
    coroutine has already caught the disconnect.  It is not an app crash and
    only obscures useful diagnostics such as audio-device failures.
    """
    if sys.platform != "win32":
        return
    loop = asyncio.get_running_loop()
    previous = loop.get_exception_handler()

    def handle(loop: asyncio.AbstractEventLoop, context: dict) -> None:
        exc = context.get("exception")
        if isinstance(exc, ConnectionResetError) and getattr(exc, "winerror", None) == 10054:
            logging.getLogger("asyncio").debug("peer closed a browser/network connection")
            return
        if previous is not None:
            previous(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(handle)


def _acquire_windows_mutex() -> bool:
    """On Windows, create a named mutex that is held until the process exits.

    Returns True if the mutex was newly acquired (no other instance running),
    False if the mutex already existed (another instance is running).
    On non-Windows platforms always returns True (no-op).
    """
    global _WIN_MUTEX
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        import ctypes.wintypes

        # Different data directories are deliberately independent instances.
        # The OS file lock below is authoritative on every platform; this
        # Windows fast path mirrors that scope rather than globally blocking a
        # separate portable copy.
        import hashlib

        identity = str(_peek_data_dir().resolve()).encode("utf-8", "surrogatepass")
        _MUTEX_NAME = "Local\\NexaDataDir-" + hashlib.sha256(identity).hexdigest()
        handle = ctypes.windll.kernel32.CreateMutexW(None, True, _MUTEX_NAME)
        last_err = ctypes.windll.kernel32.GetLastError()
        _ERROR_ALREADY_EXISTS = 183
        if handle and last_err == _ERROR_ALREADY_EXISTS:
            ctypes.windll.kernel32.CloseHandle(handle)
            return False
        if handle:
            _WIN_MUTEX = handle  # keep alive for process lifetime
        return True
    except Exception:
        # If the mutex API fails for any reason, the cross-platform data-dir
        # lock remains the authoritative guard.
        return True


def _release_windows_mutex() -> None:
    """Release the optional Windows fast-path when this launcher exits."""
    global _WIN_MUTEX
    if _WIN_MUTEX is None or sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.kernel32.ReleaseMutex(_WIN_MUTEX)
        ctypes.windll.kernel32.CloseHandle(_WIN_MUTEX)
    except Exception:
        pass
    finally:
        _WIN_MUTEX = None


def _port_already_answering(host: str, port: int) -> bool:
    """Backward-compatible alias for dashboard_port_available.

    Returns True when something is already listening (port is NOT available),
    mirroring the old semantics used by existing tests.
    """
    return not dashboard_port_available(host, port)


def dashboard_port_available(host: str, port: int) -> bool:
    """Check the dashboard bind before starting audio/cloud services.

    A second run used to initialize the whole voice stack, print that Chat
    was running, and only then fail inside uvicorn with WinError 10048.
    On non-Windows (and as a secondary check on Windows when the mutex passed)
    this confirms whether the port is free.
    """
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    try:
        with socket.socket(family, socket.SOCK_STREAM) as probe:
            if sys.platform == "win32" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            probe.bind((host, port))
    except OSError:
        return False
    return True


def _print_dashboard_access(
    host: str,
    port: int,
    scheme: str,
    *,
    candidates: list[str] | None = None,
) -> None:
    """Print actionable dashboard URLs without changing network exposure."""
    if host not in ("0.0.0.0", "::"):
        print(f"  Control panel: {scheme}://{host}:{port}")
        print("  PHONE ACCESS: OFF — this computer only.")
        print(
            "  To enable it: Settings > Dashboard access > Phone access: On; "
            "save, then restart Nexa."
        )
        return

    if candidates is None:
        from chat_core.net import lan_ips

        candidates = lan_ips()

    print("  PHONE ACCESS: ON — phones must be on the same normal Wi-Fi.")
    print(f"  This computer: {scheme}://127.0.0.1:{port}")
    if candidates:
        print(f"  PHONE URL:      {scheme}://{candidates[0]}:{port}")
        for ip in candidates[1:]:
            print(f"  Other adapter:  {scheme}://{ip}:{port}")
        if len(candidates) > 1:
            print("  Use the address for the same Wi-Fi network as the phone.")
    else:
        print(
            "  PHONE URL: unavailable — no private LAN address found. "
            "Connect this computer to Wi-Fi or Ethernet, then restart Nexa."
        )

    print(
        "  If the phone TIMES OUT: confirm same Wi-Fi (not guest/VPN/mobile data), "
        r"then run deployment\windows\allow_lan_access.bat manually."
    )
    print(
        "  A CERTIFICATE/PRIVACY error (HTTPS only) means the phone reached Nexa; "
        "follow /mobile-setup instead of changing the firewall."
    )


def _verify_chat_on_port(host: str, port: int) -> bool:
    """Return True when the process already on *port* identifies as Chat.

    Tries a lightweight HTTP probe to /api/healthz. Any failure (connection
    refused, timeout, wrong response) returns False; callers must not assume
    the service is Chat without this confirmation.
    """
    probe_host = "127.0.0.1"
    if host not in ("", "0.0.0.0", "::"):
        probe_host = host
    # Use http; the probe should succeed regardless of TLS config
    import urllib.request
    import urllib.error

    for scheme in ("http", "https"):
        try:
            import ssl
            ctx = ssl.create_default_context() if scheme == "https" else None
            if ctx:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            url = f"{scheme}://{probe_host}:{port}/api/healthz"
            with urllib.request.urlopen(url, timeout=1.5, context=ctx) as resp:
                import json
                data = json.loads(resp.read())
                return data.get("app") == "chat-assistant"
        except Exception:
            pass
    return False


def _peek_data_dir():
    """Resolve the data dir WITHOUT importing chat_core — the update swap
    below must happen before any app module is loaded."""
    from pathlib import Path

    for i, arg in enumerate(sys.argv):
        if arg == "--data-dir" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1]).expanduser()
        if arg.startswith("--data-dir="):
            return Path(arg.split("=", 1)[1]).expanduser()
    override = os.environ.get("CHAT_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "ChatAssistant"
    return Path.home() / ".chat-assistant"


def _update_state(data_dir, *, phase=None, target_version=None, error=None):
    """Update launcher-visible updater state without importing Chat modules."""
    try:
        from pathlib import Path
        from apps.updater.state import atomic_write_state, load_state

        updates = Path(data_dir) / "updates"
        state = load_state(updates)
        operation = state.get("operation")
        if not isinstance(operation, dict):
            from apps.updater.state import now_iso
            import uuid

            now = now_iso()
            operation = {
                "id": uuid.uuid4().hex,
                "phase": phase or "applying",
                "target_version": target_version,
                "bytes_received": 0,
                "total_bytes": None,
                "percent": None,
                "message": "",
                "error": "",
                "started_at": now,
                "updated_at": now,
                "automatic_restart": True,
            }
        if phase:
            operation["phase"] = phase
        if target_version is not None:
            operation["target_version"] = str(target_version)[:256]
        if error is not None:
            operation["error"] = str(error)[:4096]
        from apps.updater.state import now_iso

        operation["updated_at"] = now_iso()
        state["operation"] = operation
        if error is not None:
            state["error"] = str(error)[:4096]
        atomic_write_state(updates, state)
    except Exception:
        # Applying an update must still be attempted when a read-only state
        # file prevents progress reporting.  The staged tree is the recovery
        # source in that case.
        logging.getLogger("launcher").debug("could not persist update state", exc_info=True)


def _pending_version(pending_json):
    import json

    try:
        value = json.loads(pending_json.read_text(encoding="utf-8"))
        version = str(value.get("version", "")).strip()
        return version or None
    except (OSError, ValueError, TypeError):
        return None


def _source_version(version_file):
    """Read APP_VERSION as data, never importing code from an update tree."""
    import re

    try:
        text = version_file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    match = re.search(r"\bAPP_VERSION\s*=\s*['\"]([^'\"]+)['\"]", text)
    return match.group(1).strip() if match else None


def _same_version(left, right):
    import re

    def parts(value):
        match = re.fullmatch(r"v?(\d+(?:\.\d+)*)", str(value or "").strip(), re.I)
        return tuple(int(piece) for piece in match.group(1).split(".")) if match else None

    a, b = parts(left), parts(right)
    if a is None or b is None:
        return False
    length = max(len(a), len(b))
    return a + (0,) * (length - len(a)) == b + (0,) * (length - len(b))


def _restore_source_backup(target, backup, touched):
    import shutil

    for relative in touched:
        destination = target / relative
        saved = backup / relative
        try:
            if saved.is_file():
                destination.unlink(missing_ok=True)
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(saved, destination)
            else:
                # This path was absent before the transaction.
                if destination.is_file() or destination.is_symlink():
                    destination.unlink(missing_ok=True)
                elif destination.is_dir():
                    shutil.rmtree(destination, ignore_errors=True)
        except OSError:
            logging.getLogger("launcher").exception(
                "could not restore update path %s", relative
            )


def _apply_source_update(pending, target, data_dir, version):
    """Apply source files as a bounded transaction, returning on success."""
    import shutil
    import uuid
    from pathlib import Path

    updates = Path(data_dir) / "updates"
    backup = updates / f".apply-backup-{uuid.uuid4().hex}"
    touched = [path.relative_to(pending) for path in pending.rglob("*") if path.is_file()]
    backup.mkdir(parents=True, exist_ok=False)
    try:
        # Backup every destination path before the first replacement.  Missing
        # paths are represented by their absence and removed during rollback.
        for relative in touched:
            destination = target / relative
            if destination.is_file():
                saved = backup / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destination, saved)

        shutil.copytree(pending, target, dirs_exist_ok=True)

        # Validate the installation after copying.  An update without a
        # version.py is an old/exe-style package; its signed pending version
        # remains the authoritative version in that format.
        if not (target / "run_chat.py").exists() and not (target / "Chat.exe").exists():
            raise RuntimeError("applied update is missing its launcher marker")
        pending_version_file = pending / "chat_core" / "version.py"
        if pending_version_file.exists():
            target_version = _source_version(target / "chat_core" / "version.py")
            if not target_version or not _same_version(target_version, version):
                raise RuntimeError(
                    f"applied update version mismatch (expected {version}, "
                    f"found {target_version or 'unknown'})"
                )
        # Metadata removal is part of the transaction.  If it cannot be
        # committed, the caller's exception path restores the old files and
        # leaves the stage available.
        (pending.parent / "pending.json").unlink(missing_ok=True)
        shutil.rmtree(pending, ignore_errors=False)
        shutil.rmtree(backup, ignore_errors=True)
    except Exception:
        _restore_source_backup(target, backup, touched)
        # Keep the backup when rollback itself needs diagnosis.  It is outside
        # the application tree and can be removed by a later successful apply.
        raise


def _update_installation_root():
    """Return the tree an updater transaction is allowed to mutate."""
    from pathlib import Path

    # A frozen __file__ can point into a PyInstaller extraction directory;
    # Chat.exe's parent is the actual shared installation tree.
    return (
        Path(sys.executable).resolve().parent
        if getattr(sys, "frozen", False)
        else Path(__file__).resolve().parent
    )


_FROZEN_TRANSACTION_RE = re.compile(r"^\.frozen-apply-([0-9a-f]{32})\.marker$")


def _frozen_transaction_markers(data_dir):
    """Return valid frozen-apply markers without trusting marker contents."""
    from pathlib import Path

    updates = Path(data_dir) / "updates"
    try:
        return [
            marker
            for marker in updates.glob(".frozen-apply-*.marker")
            if _FROZEN_TRANSACTION_RE.fullmatch(marker.name)
        ]
    except OSError:
        return []


def _signal_frozen_update_ready(data_dir) -> None:
    """Signal the frozen helper only after the new server is truly ready."""
    from pathlib import Path
    import uuid

    for marker in _frozen_transaction_markers(data_dir):
        match = _FROZEN_TRANSACTION_RE.fullmatch(marker.name)
        if match is None:
            continue
        ready = marker.parent / f".frozen-ready-{match.group(1)}.marker"
        temporary = ready.with_name(f"{ready.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text("serving\n", encoding="ascii")
            os.replace(temporary, ready)
        except OSError:
            with contextlib.suppress(OSError):
                temporary.unlink()


def apply_pending_update() -> None:
    """Apply a staged update while owning both its data and install locks.

    This bridge runs before any application imports, so it must remain
    dependency-free apart from the existing updater state bridge.  A retained
    lock marker is never interpreted as stale: only the operating system's
    live lock decides ownership.
    """
    from pathlib import Path

    data_dir = _peek_data_dir()
    if not (Path(data_dir) / "updates" / "pending").is_dir():
        return
    try:
        data_lock = try_acquire_file_lock(data_dir_lock_path(data_dir))
    except LockAcquireError as exc:
        print(f"Update was not applied safely: {exc}")
        return
    if data_lock is None:
        print("Nexa is already applying or running this data directory; update was not applied.")
        return
    try:
        try:
            install_lock = try_acquire_file_lock(
                installation_lock_path(_update_installation_root())
            )
        except LockAcquireError as exc:
            print(f"Update was not applied safely: {exc}")
            return
        if install_lock is None:
            print("Another Nexa copy is updating this installation; update was not applied.")
            return
        try:
            _apply_pending_update_owned(data_dir)
        finally:
            install_lock.release()
    finally:
        data_lock.release()


def _apply_pending_update_owned(data_dir) -> None:
    """If the in-app updater staged a new version (data/updates/pending),
    swap it in now. Source installs copy the files over this folder and boot
    straight into the new code; exe installs hand off to a tiny helper
    script (files are locked while the exe runs) and exit."""
    import shutil
    from pathlib import Path

    pending = Path(data_dir) / "updates" / "pending"
    if not pending.is_dir():
        return
    if not ((pending / "run_chat.py").exists() or (pending / "Chat.exe").exists()):
        return  # not a Chat build; ignore
    meta_path = pending.parent / "pending.json"
    target_version = _pending_version(meta_path)
    helper_failure = pending.parent / "apply-failed.marker"
    if helper_failure.exists():
        _update_state(
            _peek_data_dir(),
            phase="rolled_back",
            target_version=target_version,
            error="frozen update helper rolled back to the previous installation",
        )
        print(
            "A frozen update could not be applied; the previous installation "
            "was restored and will continue running."
        )
        return
    # A failed transaction is intentionally not retried every time the user
    # launches Chat.  The pending tree remains available for a deliberate
    # manual recovery or for a later staged version.
    try:
        from apps.updater.state import load_state

        previous = load_state(pending.parent).get("operation") or {}
        if (
            previous.get("phase") in {"failed", "rolled_back"}
            and (
                not target_version
                or str(previous.get("target_version") or "") == target_version
            )
        ):
            print(
                "A staged update was not applied because its previous attempt "
                "failed; the current installation was kept."
            )
            return
    except Exception:
        pass
    _update_state(
        _peek_data_dir(),
        phase="applying",
        target_version=target_version,
    )
    if getattr(sys, "frozen", False):
        _apply_update_frozen(pending)
        return
    target = Path(__file__).resolve().parent
    # Synchronize before replacing any source files.  This uses the exact
    # interpreter that launched Chat (including .venv on Windows), and leaves
    # the authenticated staged update intact if pip cannot complete.
    from startup_dependencies import DependencySyncError, sync_requirements

    try:
        sync_requirements(pending / "requirements.txt")
    except DependencySyncError as exc:
        _update_state(
            _peek_data_dir(),
            phase="failed",
            target_version=target_version,
            error=f"dependency installation failed: {exc}",
        )
        try:
            (Path(__file__).resolve().parent / ".update-rollback").write_text(
                "dependency installation failed\n", encoding="utf-8"
            )
        except OSError:
            pass
        print(
            "Update is ready, but its Python dependencies could not be installed "
            f"({exc}).\n"
            "The update was kept safely. Check your internet connection and "
            "restart Nexa to try again."
        )
        raise SystemExit(1) from exc
    try:
        _apply_source_update(pending, target, _peek_data_dir(), target_version)
        print("Update applied.")
    except Exception as exc:
        # A copy failure can leave a mixture of old and new source files.  Do
        # not import either set in this process; retain the staged source so a
        # clean restart can safely retry it.
        _update_state(
            _peek_data_dir(),
            phase="rolled_back",
            target_version=target_version,
            error=f"update rollback: {type(exc).__name__}: {exc}",
        )
        try:
            (Path(__file__).resolve().parent / ".update-rollback").write_text(
                "source update rolled back\n", encoding="utf-8"
            )
        except OSError:
            pass
        print(
            f"Update could not be applied ({type(exc).__name__}). "
            "The staged update was kept and the previous installation restored."
        )
        raise SystemExit(1) from exc


def _ps_literal(value) -> str:
    """Quote a value as a PowerShell single-quoted literal."""
    return "'" + str(value).replace("'", "''") + "'"


def _frozen_update_helper_scripts(
    *,
    exe,
    pending,
    data_lock,
    install_lock,
    backup,
    failed_marker,
    result_marker,
    transaction_marker,
    ready_marker,
    applied_stage,
    launcher_pid: int,
) -> tuple[str, str]:
    """Return the isolated batch transaction and its lock-owning PS wrapper.

    A batch file cannot keep an OS file lock open.  The PowerShell parent does:
    it waits for this old executable to exit, acquires the exact data/install
    lock paths used by the Python launcher, and waits for the batch child to
    finish copying and rolling back before releasing either lock.
    """
    from pathlib import Path

    try:
        Path(backup).resolve().relative_to(Path(exe).resolve().parent)
    except ValueError:
        pass
    else:
        raise ValueError("frozen update backup must be outside the installation tree")
    batch = (
        "@echo off\r\n"
        "setlocal\r\n"
        f'set "BACKUP={backup}"\r\n'
        f'set "RESULT={result_marker}"\r\n'
        f'set "TRANSACTION={transaction_marker}"\r\n'
        f'set "READY={ready_marker}"\r\n'
        f'set "STAGE={pending}"\r\n'
        f'set "APPLIED={applied_stage}"\r\n'
        'if /I "%~1"=="restore" goto restore\r\n'
        'if exist "%BACKUP%" goto failed\r\n'
        'if exist "%TRANSACTION%" goto failed\r\n'
        'if exist "%APPLIED%" goto failed\r\n'
        'mkdir "%BACKUP%" >nul 2>&1\r\n'
        'if errorlevel 1 goto failed\r\n'
        f'xcopy /e /i /h /y /q "{exe.parent}\\*" "%BACKUP%\\" >nul\r\n'
        'if errorlevel 1 goto failed\r\n'
        f'xcopy /e /i /h /y /q "%STAGE%\\*" "{exe.parent}\\" >nul\r\n'
        'if errorlevel 1 goto restore\r\n'
        f'if not exist "{exe.parent}\\Chat.exe" if not exist "{exe.parent}\\run_chat.py" goto restore\r\n'
        'move "%STAGE%" "%APPLIED%" >nul\r\n'
        'if errorlevel 1 goto restore\r\n'
        f'del "{failed_marker}" >nul 2>&1\r\n'
        f'if exist "{failed_marker}" goto restore\r\n'
        '> "%TRANSACTION%" echo applying\r\n'
        'if not exist "%TRANSACTION%" goto restore\r\n'
        '> "%RESULT%" echo copied\r\n'
        'if not exist "%RESULT%" goto restore\r\n'
        'exit /b 0\r\n'
        ':restore\r\n'
        f'xcopy /e /i /h /y /q "%BACKUP%\\*" "{exe.parent}\\" >nul\r\n'
        'if errorlevel 1 goto failed\r\n'
        'if exist "%APPLIED%" move "%APPLIED%" "%STAGE%" >nul\r\n'
        'if errorlevel 1 goto failed\r\n'
        'del "%TRANSACTION%" >nul 2>&1\r\n'
        'if exist "%TRANSACTION%" goto failed\r\n'
        'del "%READY%" >nul 2>&1\r\n'
        'if exist "%READY%" goto failed\r\n'
        f'> "{failed_marker}" echo update helper rollback\r\n'
        f'if not exist "{failed_marker}" goto failed\r\n'
        '> "%RESULT%" echo rolled_back\r\n'
        'exit /b 2\r\n'
        ':failed\r\n'
        f'> "{failed_marker}" echo update helper failed\r\n'
        '> "%RESULT%" echo rolled_back\r\n'
        'rem Keep the staged update and unique backup for diagnosis/retry.\r\n'
        'exit /b 1\r\n'
    )
    # FileStream.Lock is a Windows byte-range lock, interoperable with the
    # msvcrt byte-range lock in launcher_safety.py.  FileShare.ReadWrite lets
    # independent contenders open the marker and have Lock decide ownership.
    ps = f"""$ErrorActionPreference = 'Stop'
$launcherPid = {int(launcher_pid)}
$dataLockPath = {_ps_literal(data_lock)}
$installLockPath = {_ps_literal(install_lock)}
$batchPath = {_ps_literal(result_marker.parent / (result_marker.stem + '.bat'))}
$resultPath = {_ps_literal(result_marker)}
$failedMarker = {_ps_literal(failed_marker)}
$transactionMarker = {_ps_literal(transaction_marker)}
$readyMarker = {_ps_literal(ready_marker)}
$backupPath = {_ps_literal(backup)}
$appliedStage = {_ps_literal(applied_stage)}
$statePath = {_ps_literal(pending.parent / 'state.json')}
$exePath = {_ps_literal(exe)}

function Acquire-NexaLock([string] $path, [int] $attempts = 120) {{
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $path) | Out-Null
    for ($attempt = 0; $attempt -lt $attempts; $attempt++) {{
        $stream = [System.IO.File]::Open(
            $path,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::ReadWrite
        )
        try {{
            $stream.Lock(0, 1)
            return $stream
        }} catch {{
            $stream.Dispose()
            Start-Sleep -Milliseconds 250
        }}
    }}
    return $null
}}

function Test-NexaServingReady {{
    if (Test-Path -LiteralPath $readyMarker) {{ return $true }}
    try {{
        $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json
        return $null -ne $state.operation -and $state.operation.phase -eq 'complete'
    }} catch {{
        return $false
    }}
}}

# Do not race the old frozen executable's still-live Python locks.
try {{ Wait-Process -Id $launcherPid -ErrorAction Stop }} catch {{ }}
$dataLock = $null
$installLock = $null
$copyExit = 99
$lockFailure = $false
try {{
    $dataLock = Acquire-NexaLock $dataLockPath
    if ($null -eq $dataLock) {{
        $lockFailure = $true
    }} else {{
        $installLock = Acquire-NexaLock $installLockPath
        if ($null -eq $installLock) {{
            $lockFailure = $true
        }} else {{
            & cmd.exe /d /c $batchPath
            $copyExit = $LASTEXITCODE
            if ($copyExit -ne 0 -and -not (Test-Path -LiteralPath $failedMarker)) {{
                Set-Content -LiteralPath $failedMarker -Value 'update helper failed' -NoNewline
            }}
        }}
    }}
}} finally {{
    if ($null -ne $installLock) {{ try {{ $installLock.Unlock(0, 1) }} finally {{ $installLock.Dispose() }} }}
    if ($null -ne $dataLock) {{ try {{ $dataLock.Unlock(0, 1) }} finally {{ $dataLock.Dispose() }} }}
}}

# Never start a second copy when locking failed.  A verified immediate
# rollback starts the old executable; a completed copy starts the target only
# after both locks were released.
if (-not $lockFailure -and $copyExit -eq 2) {{
    Start-Process -FilePath $exePath
}} elseif (-not $lockFailure -and $copyExit -eq 0) {{
    Start-Process -FilePath $exePath
    $ready = $false
    for ($attempt = 0; $attempt -lt 180; $attempt++) {{
        if (Test-NexaServingReady) {{ $ready = $true; break }}
        Start-Sleep -Milliseconds 250
    }}
    if ($ready) {{
        # The serving process owns the data lock.  Cleanup only needs the
        # shared installation lock and never removes the backup on an error.
        $cleanupLock = Acquire-NexaLock $installLockPath
        if ($null -ne $cleanupLock) {{
            try {{
                Remove-Item -LiteralPath $appliedStage -Recurse -Force -ErrorAction Stop
                Remove-Item -LiteralPath {_ps_literal(pending.parent / 'pending.json')} -Force -ErrorAction Stop
                Remove-Item -LiteralPath $backupPath -Recurse -Force -ErrorAction Stop
                Remove-Item -LiteralPath $readyMarker -Force -ErrorAction Stop
                # Keep this marker until every other cleanup completed.  A
                # retained marker is safer than accidentally reapplying the
                # same pending tree after a partial cleanup.
                Remove-Item -LiteralPath $transactionMarker -Force -ErrorAction Stop
                Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
            }} catch {{
                Set-Content -LiteralPath $failedMarker -Value 'frozen update cleanup failed; backup retained' -NoNewline
            }} finally {{
                $cleanupLock.Unlock(0, 1); $cleanupLock.Dispose()
            }}
        }} else {{
            Set-Content -LiteralPath $failedMarker -Value 'frozen update cleanup lock timed out; backup retained' -NoNewline
        }}
    }} else {{
        # The target never reached Uvicorn's serving-ready bridge.  Only
        # restore after both live locks become available; otherwise leave all
        # recovery files intact rather than overwriting a live process.
        $rollbackDataLock = Acquire-NexaLock $dataLockPath
        $rollbackInstallLock = $null
        if ($null -ne $rollbackDataLock) {{
            $rollbackInstallLock = Acquire-NexaLock $installLockPath
        }}
        if ($null -ne $rollbackDataLock -and $null -ne $rollbackInstallLock) {{
            try {{
                & cmd.exe /d /c $batchPath restore
                if ($LASTEXITCODE -eq 2) {{
                    Start-Process -FilePath $exePath
                }} else {{
                    Set-Content -LiteralPath $failedMarker -Value 'frozen update rollback failed; backup retained' -NoNewline
                }}
            }} finally {{
                $rollbackInstallLock.Unlock(0, 1); $rollbackInstallLock.Dispose()
                $rollbackDataLock.Unlock(0, 1); $rollbackDataLock.Dispose()
            }}
        }} else {{
            if ($null -ne $rollbackInstallLock) {{ $rollbackInstallLock.Unlock(0, 1); $rollbackInstallLock.Dispose() }}
            if ($null -ne $rollbackDataLock) {{ $rollbackDataLock.Unlock(0, 1); $rollbackDataLock.Dispose() }}
        }}
    }}
}}
Remove-Item -LiteralPath $batchPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $resultPath -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
"""
    return batch, ps


def _apply_update_frozen(pending) -> None:
    """Hand frozen replacement to a helper that owns locks through copying.

    The helper is unique per transaction.  In particular, it does not use the
    historic shared ``chat_apply_update.bat`` or ``.update-backup`` names,
    which let separate --data-dir copies overwrite each other's recovery data.
    """
    import subprocess
    import tempfile
    import uuid
    from pathlib import Path

    exe = Path(sys.executable).resolve()
    token = uuid.uuid4().hex
    helper_dir = Path(tempfile.gettempdir()) / "nexa-update-helpers"
    ps1 = helper_dir / f"apply-{token}.ps1"
    # The batch path is encoded in the result marker's stem by the wrapper.
    # Keep it beside pending (which is already data-dir scoped) and unique.
    result_marker = pending.parent / f".apply-result-{token}.marker"
    bat = result_marker.parent / f"{result_marker.stem}.bat"
    # A backup inside its copied source would recursively copy itself.  Prefer
    # a sibling on the same volume; an installation located directly at a
    # volume root falls back to the per-transaction temp directory instead.
    backup_parent = exe.parent.parent
    if backup_parent == exe.parent:
        backup_parent = helper_dir
    backup = backup_parent / f".{exe.parent.name}.update-backup-{token}"
    failed_marker = pending.parent / "apply-failed.marker"
    transaction_marker = pending.parent / f".frozen-apply-{token}.marker"
    ready_marker = pending.parent / f".frozen-ready-{token}.marker"
    applied_stage = pending.parent / f".frozen-applied-{token}"
    data_lock = data_dir_lock_path(pending.parent.parent)
    install_lock = installation_lock_path(exe.parent)
    batch_text, ps_text = _frozen_update_helper_scripts(
        exe=exe,
        pending=pending,
        data_lock=data_lock,
        install_lock=install_lock,
        backup=backup,
        failed_marker=failed_marker,
        result_marker=result_marker,
        transaction_marker=transaction_marker,
        ready_marker=ready_marker,
        applied_stage=applied_stage,
        launcher_pid=os.getpid(),
    )
    # Only unique paths are touched before the helper owns locks.  It creates
    # the backup and mutates the installation only under its lock-owning
    # PowerShell parent.
    try:
        helper_dir.mkdir(parents=True, exist_ok=True)
        bat.write_text(batch_text, encoding="utf-8", newline="")
        # Windows PowerShell 5.1 reliably recognizes UTF-8 only with a BOM.
        ps1.write_text(ps_text, encoding="utf-8-sig", newline="")
    except OSError as exc:
        with contextlib.suppress(OSError):
            bat.unlink()
        with contextlib.suppress(OSError):
            ps1.unlink()
        print(f"Frozen update could not safely prepare its helper ({exc}).")
        raise SystemExit(1) from exc
    try:
        subprocess.Popen(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(ps1),
            ],
            creationflags=0x00000008 | 0x00000200,  # DETACHED | NEW_PROCESS_GROUP
            close_fds=True,
        )
    except OSError as exc:
        # No unlocked fallback batch is ever launched.  The authenticated
        # pending tree remains for a later safe retry.
        with contextlib.suppress(OSError):
            bat.unlink()
        with contextlib.suppress(OSError):
            ps1.unlink()
        print(f"Frozen update could not safely start its helper ({exc}).")
        raise SystemExit(1) from exc
    print("Applying the downloaded update... Nexa restarts itself in a few seconds.")
    raise SystemExit(0)


def _restart_direct_after_rollback() -> bool:
    """Relaunch a direct Python invocation once after source rollback.

    ``run_chat.bat`` owns recovery when it launched us (and must receive the
    original error code so its bounded rollback branch can loop once).  A
    direct ``python run_chat.py`` process has no parent supervisor, so consume
    the source rollback marker and replace this process exactly once.  The
    inherited guard prevents a corrupt/read-only installation from creating a
    restart storm.
    """
    from pathlib import Path

    if os.environ.get("NEXA_LAUNCHER_BAT") == "1":
        return False
    marker = Path(__file__).resolve().parent / ".update-rollback"
    if not marker.exists():
        return False
    if os.environ.get("NEXA_ROLLBACK_RECOVERY_USED") == "1":
        return False
    os.environ["NEXA_ROLLBACK_RECOVERY_USED"] = "1"
    try:
        marker.unlink(missing_ok=True)
    except OSError:
        # The persisted rollback state still prevents the next process from
        # applying this stage.  Keep the marker for diagnostics, but do not
        # let cleanup failure turn into a restart loop.
        pass
    os.execv(sys.executable, [sys.executable, *sys.argv])
    return True


async def _mark_updater_ready_when_serving(server, updater, timeout: float = 30.0) -> bool:
    """Finalize an update only after Uvicorn completed its bind/startup.

    ``Runtime.start`` initializes application objects, but it does not prove
    that the configured dashboard port/TLS socket actually bound.  Watching
    Uvicorn's own ``started`` flag avoids marking a failed restart complete.
    The bounded timeout also prevents a malformed server implementation from
    leaving a task alive forever.
    """
    loop = asyncio.get_running_loop()
    deadline = loop.time() + max(0.1, float(timeout))
    while loop.time() < deadline:
        if bool(getattr(server, "started", False)):
            status = updater.mark_serving_ready()
            # Frozen helpers retain the backup and signed stage until this
            # exact post-bind point.  Older/current updater implementations
            # need no new API: their existing completion status is enough.
            operation = status.get("operation") if isinstance(status, dict) else None
            if not isinstance(operation, dict) or operation.get("phase") == "complete":
                updater_settings = getattr(updater, "settings", None)
                data_dir = getattr(updater_settings, "data_dir", "")
                if data_dir:
                    _signal_frozen_update_ready(data_dir)
            # A recovered installation is healthy now. Future, independent
            # updates get their own bounded recovery attempt.
            os.environ.pop("NEXA_ROLLBACK_RECOVERY_USED", None)
            return True
        if bool(getattr(server, "should_exit", False)):
            return False
        await asyncio.sleep(0.05)
    return False


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Nexa voice assistant")
    p.add_argument("--dashboard-only", action="store_true", help="dashboard + timers only")
    p.add_argument("--no-voice", action="store_true", help="disable microphone/wake word")
    p.add_argument("--verbose", action="store_true", help="chatty console logging")
    p.add_argument("--host", default=None, help="dashboard bind address")
    p.add_argument("--port", type=int, default=None, help="dashboard port")
    p.add_argument(
        "--strict-port",
        action="store_true",
        help="fail instead of choosing a nearby free port",
    )
    p.add_argument("--data-dir", default=None, help="data directory override")
    return p.parse_args()


async def main() -> int:
    args = parse_args()
    if args.data_dir:
        os.environ["CHAT_DATA_DIR"] = args.data_dir

    from chat_core.config import load_settings

    settings = load_settings()
    if args.host:
        settings.dashboard_host = args.host
    if args.port is not None:
        settings.dashboard_port = args.port
    if args.verbose:
        settings.log_level = "INFO"
        settings.low_power = False

    # This is the cross-platform, per-data-directory instance owner.  It is
    # deliberately acquired before audio/cloud startup and retained until all
    # shutdown has completed.  A second normal launch exits rather than
    # creating a second microphone owner, while portable --data-dir copies
    # remain independent.
    try:
        instance_lock = try_acquire_file_lock(data_dir_lock_path(settings.data_dir))
    except LockAcquireError as exc:
        print(f"Nexa could not safely lock its data folder: {exc}")
        return 1
    if instance_lock is None:
        print("Nexa is already running. Only one instance at a time is supported.")
        return 0
    try:
        return await _main_with_data_lock(args, settings)
    finally:
        instance_lock.release()
        _release_windows_mutex()


async def _main_with_data_lock(args: argparse.Namespace, settings) -> int:
    # Primary check: atomic named mutex (Windows only). If this process gets
    # the mutex, it can proceed. A second launch will fail here immediately,
    # before any audio or cloud services start.
    if not _acquire_windows_mutex():
        print(
            "Nexa is already running. Only one instance at a time is supported."
        )
        return 0

    requested_port = settings.dashboard_port
    try:
        # Keep the bound socket all the way into Uvicorn.  A free-port probe
        # followed by Uvicorn's later bind leaves a race that is especially
        # visible when two desktop copies launch together.
        dashboard_socket, selected_port = reserve_dashboard_socket(
            settings.dashboard_host,
            requested_port,
            strict=bool(args.strict_port),
        )
    except PortInUseError as exc:
        print(
            f"Port {requested_port} is already in use and Nexa could not select "
            f"a safe local fallback. {exc}"
        )
        return 0
    except DashboardBindError as exc:
        print(f"Nexa could not start the dashboard: {exc}")
        return 1

    # Every consumer below (Runtime, companion selection, Uvicorn and the
    # printed URL) reads the selected port rather than the stale preference.
    settings.dashboard_port = selected_port
    if selected_port != requested_port:
        print(
            f"Dashboard port {requested_port} is in use; "
            f"using local port {selected_port} instead."
        )

    try:
        from chat_core.runtime import Runtime
        from apps.dashboard.app import create_app
        import uvicorn

        rt = Runtime(settings)
        await rt.start(
            voice=not (args.no_voice or args.dashboard_only),
            cloud=not args.dashboard_only,
            monitoring=not args.dashboard_only,
        )
        _install_windows_disconnect_handler()

        app = create_app(rt)
    except BaseException:
        # Uvicorn never received ownership when an earlier startup operation
        # fails, so close the reservation ourselves.
        with contextlib.suppress(OSError):
            dashboard_socket.close()
        with contextlib.suppress(Exception):
            if "rt" in locals():
                await rt.stop()
        raise

    try:
        config = uvicorn.Config(
            app,
            host=settings.dashboard_host,
            port=settings.dashboard_port,
            log_level="warning" if settings.low_power else "info",
            access_log=not settings.low_power,
            **(
                {
                    "ssl_certfile": settings.ssl_certfile,
                    "ssl_keyfile": settings.ssl_keyfile,
                }
                if settings.ssl_certfile and settings.ssl_keyfile
                else {}
            ),
        )
        server = uvicorn.Server(config)
        # lets the dashboard's Restart button stop the server loop cleanly
        rt.on_uvicorn_exit = lambda: setattr(server, "should_exit", True)

        # Dedicated loopback-only, always-plain-HTTP bridge for the YouTube
        # companion extension.  A browser extension cannot approve a self-signed
        # certificate, so it must never be asked to speak TLS to the dashboard.
        # Failure here is non-fatal: everything except the companion still works.
        from apps.dashboard.companion_server import CompanionBridgeServer

        companion_server = CompanionBridgeServer(rt)
        await companion_server.start()

        from chat_core.version import APP_VERSION

        scheme = "https" if settings.ssl_certfile else "http"
        print(f"Nexa {APP_VERSION} is running.")
        _print_dashboard_access(
            settings.dashboard_host,
            settings.dashboard_port,
            scheme,
        )
        print(f"  Data folder:   {settings.data_dir}")
        if companion_server.running:
            print(f"  YouTube companion bridge: ws://127.0.0.1:{companion_server.port}")
        elif companion_server.error:
            print(f"  YouTube companion bridge: not running — {companion_server.error}")
        print("  Press Ctrl+C to stop.")

        ready_task = (
            asyncio.create_task(
                _mark_updater_ready_when_serving(server, rt.updater),
                name="updater-serving-ready",
            )
            if rt.updater is not None
            else None
        )
        try:
            await server.serve(sockets=[dashboard_socket])
        finally:
            if ready_task is not None and not ready_task.done():
                # If startup succeeded in the same loop turn that serve() ended,
                # let the observer consume the started flag before cancelling it.
                if bool(getattr(server, "started", False)):
                    with contextlib.suppress(Exception):
                        await ready_task
                else:
                    ready_task.cancel()
                    await asyncio.gather(ready_task, return_exceptions=True)
            with contextlib.suppress(Exception):
                await companion_server.stop()
            with contextlib.suppress(Exception):
                await rt.stop()
            with contextlib.suppress(OSError):
                dashboard_socket.close()

        code = rt.restart_exit_code or 0
        if code == RESTART_CODE and getattr(sys, "frozen", False):
            # exe has no .bat loop around it: relaunch ourselves after a beat
            import subprocess

            subprocess.Popen(
                ["cmd", "/c", f'timeout /t 2 /nobreak >nul & start "" "{sys.executable}"'],
                creationflags=0x00000008,
                close_fds=True,
            )
            return 0
        if code == RESTART_CODE:
            # A direct ``python run_chat.py`` invocation has no batch-file parent
            # to perform the restart.  The Windows launcher sets this marker so
            # the batch loop remains the sole owner there (avoiding two children).
            if sys.platform != "win32" or os.environ.get("NEXA_LAUNCHER_BAT") != "1":
                os.execv(sys.executable, [sys.executable, *sys.argv])
                return 0
        return code
    except BaseException:
        # Covers failures after Runtime.start but before server.serve enters its
        # own shutdown path.
        with contextlib.suppress(OSError):
            dashboard_socket.close()
        with contextlib.suppress(Exception):
            await rt.stop()
        raise

if __name__ == "__main__":
    try:
        apply_pending_update()  # must run before chat_core/apps are imported
    except SystemExit as exc:
        # The batch launcher deliberately owns its own one-shot rollback
        # branch.  Direct Python has no supervisor, so replace this process
        # with the previous boot exactly once instead of requiring a user to
        # rerun it manually.
        if exc.code == 1 and _restart_direct_after_rollback():
            raise SystemExit(0)
        raise
    if sys.platform == "win32":
        # ProactorEventLoop is the default on Python 3.8+; no explicit policy
        # call is needed and the deprecated setter was removed from 3.12+.
        # Only set the process priority to below-normal.
        try:
            import ctypes

            ctypes.windll.kernel32.SetPriorityClass(
                ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000  # BELOW_NORMAL
            )
        except Exception:
            pass
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        print("\nNexa stopped.")
