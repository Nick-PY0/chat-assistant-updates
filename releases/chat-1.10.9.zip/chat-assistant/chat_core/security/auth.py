"""Dashboard authentication: Argon2id password, signed cookies, CSRF,
and login rate limiting."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import time
import asyncio
from collections.abc import Awaitable, Callable
from typing import Mapping

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

_hasher = PasswordHasher()  # argon2id by default

# This is deliberately a server-injected ASGI scope value, not an HTTP
# header/cookie.  The broadcast gateway writes it only after Clerk has
# verified the browser session and the platform-owner role.  Keep the shape
# small and exact so the desktop never starts accepting a browser-supplied
# identity by accident. The wire names deliberately describe a verified owner,
# stable login session, and trusted expiry; no rotating JWT timestamp travels
# through the desktop.
OWNER_ATTESTATION_SCOPE = "jarvis.owner_attestation"
OWNER_ATTESTATION_KEYS = frozenset(
    {"verified_owner", "subject", "login_sid", "expires_at"}
)


def normalize_owner_attestation(
    value: object, *, now: int | None = None
) -> dict[str, str | int] | None:
    """Validate the gateway's trusted owner attestation.

    The caller must obtain *value* from the ASGI scope populated by the
    verified broadcast gateway.  This helper only validates the wire shape and
    deadline; it intentionally has no browser/header fallback.
    """
    if not isinstance(value, Mapping):
        return None
    if set(value) != OWNER_ATTESTATION_KEYS:
        return None
    verified_owner = value.get("verified_owner")
    session_id = value.get("login_sid")
    subject = value.get("subject")
    expires_at = value.get("expires_at")
    if (
        verified_owner is not True
        or not isinstance(session_id, str)
        or not isinstance(subject, str)
        or not session_id
        or not subject
        or len(session_id) > 256
        or len(subject) > 256
        or any(ord(char) < 33 or ord(char) > 126 for char in session_id)
        or any(ord(char) < 33 or ord(char) > 126 for char in subject)
        or isinstance(expires_at, bool)
        or not isinstance(expires_at, int)
    ):
        return None
    current = int(time.time()) if now is None else int(now)
    if expires_at <= current:
        return None
    return {
        "verified_owner": True,
        "login_sid": session_id,
        "subject": subject,
        "expires_at": expires_at,
    }


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


class SessionManager:
    _MAX_REVOCATIONS = 2048
    _MAX_ADMIN_GENERATIONS = 2048
    REMEMBERED_MAX_AGE = 30 * 86400

    def __init__(
        self,
        secret: str,
        max_age_seconds: int,
        security_state: dict | None = None,
        persist_security_state: Callable[[dict], Awaitable[None]] | None = None,
        mutate_security_state: (
            Callable[[dict, dict], Awaitable[dict | None]] | None
        ) = None,
    ) -> None:
        self._serializer = URLSafeTimedSerializer(secret, salt="chat-session")
        self._cap_serializer = URLSafeTimedSerializer(secret, salt="chat-capability")
        self._csrf_key = hashlib.sha256(("csrf:" + secret).encode()).digest()
        self.max_age = max_age_seconds
        # The ordinary session lifetime remains configurable. Remembered
        # sessions have a fixed, server-owned upper bound; a value carried in
        # the signed token can select a shorter lifetime but never extend it.
        self.remembered_max_age = self.REMEMBERED_MAX_AGE
        self._max_token_age = max(self.max_age, self.remembered_max_age)
        self._generation = 0
        self._revoked: dict[str, int] = {}
        # Remote-admin grants have their own revocation epoch.  Locking an
        # admin grant must not revoke the ordinary login session, while a
        # persisted epoch prevents a captured capability from being replayed
        # after a process restart.
        self._admin_generation = 0
        self._admin_generations: dict[str, dict[str, int]] = {}
        # Clerk session IDs explicitly logged out or replaced by an account
        # switch cannot silently mint a fresh desktop session while the same
        # browser attestation remains live.
        self._owner_sso_revoked: dict[str, int] = {}
        # Manual Lock is also keyed by the verified Clerk login, not only the
        # replaceable desktop session cookie. This prevents a fresh tab or a
        # short-lived attestation refresh from silently restoring admin access.
        # Owner-wide SSO lock tombstones are keyed by verified Clerk subject,
        # not rotating login_sid values. Revisions are allocated atomically by
        # the durable mutation callback.
        self._owner_sso_revision = 0
        self._owner_sso_subject_locks: dict[str, dict[str, int | bool]] = {}
        self._owner_sso_revocation_tombstones: dict[
            str, dict[str, int | bool | str]
        ] = {}
        self._failed_owner_sso_subject_floors: dict[
            str, tuple[int, bool]
        ] = {}
        self._failed_owner_sso_revocation_floors: dict[
            str, tuple[int, str]
        ] = {}
        # A failed durable write must not make this manager less restrictive
        # when a later successful mutation adopts the committed state.
        self._failed_generation_floor = 0
        self._failed_admin_generation_floor = 0
        self._failed_revocations: dict[str, int] = {}
        self._failed_admin_generations: dict[str, dict[str, int]] = {}
        self._apply_security_state(security_state)
        self._persist_security_state = persist_security_state
        self._mutate_security_state = mutate_security_state
        self._security_lock = asyncio.Lock()

    def _apply_security_state(self, state: dict | None) -> None:
        """Load persisted revocations and admin epochs.

        This deliberately treats malformed or oversized state as a
        fail-closed condition.  In particular, silently dropping a live
        revocation would turn a restart into an authentication bypass.
        """
        state = state if isinstance(state, dict) else {}
        try:
            generation = max(0, int(state.get("generation", 0)))
        except (TypeError, ValueError):
            generation = 0
        try:
            admin_generation = max(0, int(state.get("admin_generation", 0)))
        except (TypeError, ValueError):
            admin_generation = 0
        now = int(time.time())
        revoked = state.get("revoked", {})
        parsed_revoked = {
            str(sid): int(expiry)
            for sid, expiry in (
                revoked.items() if isinstance(revoked, dict) else ()
            )
            if isinstance(sid, str)
            and isinstance(expiry, (int, float))
            and int(expiry) > now
        }
        # An oversized persisted value must fail closed rather than restoring
        # old sessions by dropping live revocations.
        if len(parsed_revoked) > self._MAX_REVOCATIONS:
            generation += 1
            parsed_revoked.clear()

        raw_admin = state.get("admin_generations", {})
        parsed_admin: dict[str, dict[str, int]] = {}
        if isinstance(raw_admin, dict):
            for sid, value in raw_admin.items():
                if not isinstance(sid, str) or not isinstance(value, dict):
                    continue
                try:
                    epoch = int(value.get("generation", 0))
                    expiry = int(value.get("expires_at", 0))
                except (TypeError, ValueError):
                    continue
                if epoch >= 0 and expiry > now:
                    parsed_admin[sid] = {
                        "generation": epoch,
                        "expires_at": expiry,
                    }
        # If an attacker or a damaged database supplies an oversized map,
        # advance the global admin epoch and discard it.  Existing signed
        # capabilities carry the previous epoch and therefore fail closed.
        if len(parsed_admin) > self._MAX_ADMIN_GENERATIONS:
            admin_generation += 1
            parsed_admin.clear()

        self._generation = generation
        self._revoked = parsed_revoked
        self._admin_generation = admin_generation
        self._admin_generations = parsed_admin
        raw_sso_revoked = state.get("owner_sso_revoked", {})
        self._owner_sso_revoked = {
            str(session_id): int(expiry)
            for session_id, expiry in (
                raw_sso_revoked.items()
                if isinstance(raw_sso_revoked, dict)
                else ()
            )
            if (
                isinstance(session_id, str)
                and isinstance(expiry, (int, float))
                and int(expiry) > now
            )
        }
        if len(self._owner_sso_revoked) > self._MAX_REVOCATIONS:
            # Preserve fail-closed behavior for a damaged/hostile oversized
            # state rather than silently restoring every owner SSO login.
            self._owner_sso_revoked = {"*": now + self.max_age}
        try:
            self._owner_sso_revision = max(
                0, int(state.get("owner_sso_revision", 0))
            )
        except (TypeError, ValueError):
            self._owner_sso_revision = 0
        self._owner_sso_subject_locks = {}
        raw_subject_locks = state.get("owner_sso_subject_locks", {})
        if isinstance(raw_subject_locks, dict):
            for subject, value in raw_subject_locks.items():
                if (
                    not isinstance(subject, str)
                    or not subject
                    or not isinstance(value, dict)
                ):
                    continue
                try:
                    revision = int(value.get("revision", 0))
                except (TypeError, ValueError):
                    continue
                if revision < 0 or not isinstance(value.get("locked"), bool):
                    continue
                self._owner_sso_subject_locks[subject] = {
                    "revision": revision,
                    "locked": value["locked"],
                }
        if len(self._owner_sso_subject_locks) > self._MAX_REVOCATIONS:
            self._owner_sso_subject_locks = {
                "*": {
                    "revision": self._owner_sso_revision,
                    "locked": True,
                }
            }
        self._owner_sso_revocation_tombstones = {}
        raw_revocation_tombstones = state.get("owner_sso_revocations", {})
        if isinstance(raw_revocation_tombstones, dict):
            for login_sid, value in raw_revocation_tombstones.items():
                if (
                    not isinstance(login_sid, str)
                    or not login_sid
                    or not isinstance(value, dict)
                ):
                    continue
                try:
                    revision = int(value.get("revision", 0))
                except (TypeError, ValueError):
                    continue
                subject = value.get("subject")
                if (
                    revision < 0
                    or value.get("revoked") is not True
                    or not isinstance(subject, str)
                    or not subject
                ):
                    continue
                self._owner_sso_revocation_tombstones[login_sid] = {
                    "revision": revision,
                    "revoked": True,
                    "subject": subject,
                }
        if len(self._owner_sso_revocation_tombstones) > self._MAX_REVOCATIONS:
            self._owner_sso_revocation_tombstones = {
                "*": {
                    "revision": self._owner_sso_revision,
                    "revoked": True,
                    "subject": "*",
                }
            }

    def _merge_owner_sso_state(
        self,
        previous_revision: int,
        previous_subject_locks: dict[str, dict],
        previous_revocations: dict[str, dict],
    ) -> None:
        """Keep newer local owner-SSO records across a stale DB refresh."""
        self._owner_sso_revision = max(
            self._owner_sso_revision, previous_revision
        )
        for subject, previous in previous_subject_locks.items():
            current = self._owner_sso_subject_locks.get(subject)
            if current is None or int(previous.get("revision", 0)) > int(
                current.get("revision", 0)
            ):
                self._owner_sso_subject_locks[subject] = dict(previous)
        for login_sid, previous in previous_revocations.items():
            current = self._owner_sso_revocation_tombstones.get(login_sid)
            if current is None or int(previous.get("revision", 0)) > int(
                current.get("revision", 0)
            ):
                self._owner_sso_revocation_tombstones[login_sid] = dict(
                    previous
                )

    def _reapply_failed_owner_sso_floors(self) -> None:
        """Reassert unresolved failed owner-SSO intents after any adoption."""
        for subject, (floor, wanted_locked) in list(
            self._failed_owner_sso_subject_floors.items()
        ):
            current = self._owner_sso_subject_locks.get(subject)
            current_revision = (
                int(current.get("revision", 0)) if current is not None else -1
            )
            if (
                current is None
                or current_revision < floor
                or (
                    current_revision == floor
                    and wanted_locked
                    and current.get("locked") is not wanted_locked
                )
            ):
                self._owner_sso_subject_locks[subject] = {
                    "revision": floor,
                    "locked": True,
                }
            elif current_revision == floor and current.get(
                "locked"
            ) is wanted_locked:
                self._failed_owner_sso_subject_floors.pop(subject, None)
        for login_sid, (floor, subject) in list(
            self._failed_owner_sso_revocation_floors.items()
        ):
            current = self._owner_sso_revocation_tombstones.get(login_sid)
            if current is None or int(current.get("revision", 0)) < floor:
                self._owner_sso_revocation_tombstones[login_sid] = {
                    "revision": floor,
                    "revoked": True,
                    "subject": subject,
                }
            elif int(current.get("revision", 0)) >= floor:
                self._failed_owner_sso_revocation_floors.pop(login_sid, None)

    def apply_security_state(self, state: dict | None) -> None:
        """Refresh persisted state before a security-sensitive admin check."""
        previous_generation = self._generation
        previous_revoked = dict(self._revoked)
        previous_owner_sso_revoked = dict(self._owner_sso_revoked)
        previous_owner_sso_revision = self._owner_sso_revision
        previous_owner_sso_subject_locks = {
            subject: dict(value)
            for subject, value in self._owner_sso_subject_locks.items()
        }
        previous_owner_sso_revocations = {
            login_sid: dict(value)
            for login_sid, value
            in self._owner_sso_revocation_tombstones.items()
        }
        previous_admin_generation = self._admin_generation
        previous_admin_generations = {
            sid: dict(value)
            for sid, value in self._admin_generations.items()
        }
        self._apply_security_state(state)
        # A refresh can race a mutation in another app instance.  Never let a
        # stale database read weaken this manager before the writer commits.
        self._generation = max(self._generation, previous_generation)
        self._admin_generation = max(
            self._admin_generation, previous_admin_generation
        )
        for sid, value in previous_revoked.items():
            self._revoked[sid] = max(self._revoked.get(sid, 0), value)
        for sid, value in previous_admin_generations.items():
            current = self._admin_generations.get(sid)
            if current is None or value["generation"] > current["generation"]:
                self._admin_generations[sid] = value
            elif value["expires_at"] > current["expires_at"]:
                current["expires_at"] = value["expires_at"]
        for session_id, expiry in previous_owner_sso_revoked.items():
            self._owner_sso_revoked[session_id] = max(
                self._owner_sso_revoked.get(session_id, 0), expiry
            )
        self._merge_owner_sso_state(
            previous_owner_sso_revision,
            previous_owner_sso_subject_locks,
            previous_owner_sso_revocations,
        )
        self._reapply_failed_owner_sso_floors()
        now = int(time.time())
        self._revoked = {
            sid: expiry
            for sid, expiry in self._revoked.items()
            if expiry > now
        }
        self._admin_generations = {
            sid: value
            for sid, value in self._admin_generations.items()
            if value.get("expires_at", 0) > now
        }
        self._owner_sso_revoked = {
            session_id: expiry
            for session_id, expiry in self._owner_sso_revoked.items()
            if expiry > now
        }

    def replace_security_state(self, state: dict | None) -> None:
        """Adopt an atomically committed state without stale-state merging."""
        previous_owner_sso_revision = self._owner_sso_revision
        previous_owner_sso_subject_locks = {
            subject: dict(value)
            for subject, value in self._owner_sso_subject_locks.items()
        }
        previous_owner_sso_revocations = {
            login_sid: dict(value)
            for login_sid, value
            in self._owner_sso_revocation_tombstones.items()
        }
        committed_generation = 0
        committed_admin_generation = 0
        committed_revoked: dict[str, int] = {}
        committed_admin: dict[str, dict[str, int]] = {}
        if isinstance(state, dict):
            try:
                committed_generation = int(state.get("generation", 0))
            except (TypeError, ValueError):
                committed_generation = 0
            try:
                committed_admin_generation = int(
                    state.get("admin_generation", 0)
                )
            except (TypeError, ValueError):
                committed_admin_generation = 0
            raw_revoked = state.get("revoked")
            if isinstance(raw_revoked, dict):
                committed_revoked = {
                    sid: int(expiry)
                    for sid, expiry in raw_revoked.items()
                    if isinstance(sid, str)
                    and isinstance(expiry, (int, float))
                }
            raw_admin = state.get("admin_generations")
            if isinstance(raw_admin, dict):
                for sid, value in raw_admin.items():
                    if not isinstance(sid, str) or not isinstance(value, dict):
                        continue
                    try:
                        committed_admin[sid] = {
                            "generation": int(value.get("generation", 0)),
                            "expires_at": int(value.get("expires_at", 0)),
                        }
                    except (TypeError, ValueError):
                        continue
        self._apply_security_state(state)
        self._merge_owner_sso_state(
            previous_owner_sso_revision,
            previous_owner_sso_subject_locks,
            previous_owner_sso_revocations,
        )
        self._reapply_failed_owner_sso_floors()
        failed_generation_floor = self._failed_generation_floor
        failed_admin_generation_floor = self._failed_admin_generation_floor
        if committed_generation >= failed_generation_floor:
            self._failed_generation_floor = 0
        else:
            self._generation = max(self._generation, self._failed_generation_floor)
        if committed_admin_generation >= failed_admin_generation_floor:
            self._failed_admin_generation_floor = 0
        else:
            self._admin_generation = max(
                self._admin_generation, self._failed_admin_generation_floor
            )
        now = int(time.time())
        for sid, expiry in list(self._failed_revocations.items()):
            if expiry <= now:
                self._failed_revocations.pop(sid, None)
            elif committed_revoked.get(sid, 0) >= expiry:
                self._failed_revocations.pop(sid, None)
            else:
                self._revoked[sid] = expiry
        for sid, value in list(self._failed_admin_generations.items()):
            if value.get("expires_at", 0) <= now:
                self._failed_admin_generations.pop(sid, None)
                continue
            committed_value = committed_admin.get(sid, {})
            if (
                committed_admin_generation >= failed_admin_generation_floor > 0
                or committed_value.get("generation", 0)
                >= value["generation"]
            ):
                self._failed_admin_generations.pop(sid, None)
                continue
            current = self._admin_generations.get(sid)
            if current is None or value["generation"] > current["generation"]:
                self._admin_generations[sid] = dict(value)
            elif value["expires_at"] > current["expires_at"]:
                current["expires_at"] = value["expires_at"]

    def issue(self, max_age_seconds: int | None = None) -> str:
        ttl = self.max_age if max_age_seconds is None else max_age_seconds
        if (
            isinstance(ttl, bool)
            or not isinstance(ttl, int)
            or ttl <= 0
            or ttl > self._max_token_age
        ):
            raise ValueError("session lifetime is outside the server limit")
        return self._serializer.dumps({
            "sid": secrets.token_hex(16),
            "generation": self._generation,
            "ttl": ttl,
        })

    @staticmethod
    def is_owner_sso(data: object) -> bool:
        """Return whether a decoded session is an attested owner session."""
        return isinstance(data, dict) and data.get("auth") == "owner_sso"

    def issue_owner_sso(self, attestation: Mapping[str, object]) -> str | None:
        """Issue a session requiring the same live owner attestation."""
        verified = normalize_owner_attestation(attestation)
        if verified is None:
            return None
        now = int(time.time())
        deadline = int(verified["expires_at"])
        # The gateway attestation is a per-request freshness proof, not the
        # lifetime of the local desktop session. Binding the signed cookie to
        # its first 45-second deadline would rematerialize a new admin grant
        # every time that freshness window elapsed.
        ttl = self.max_age
        subject = str(verified["subject"])
        login_sid = str(verified["login_sid"])
        tombstone = self._owner_sso_revocation_tombstones.get(
            login_sid,
            self._owner_sso_revocation_tombstones.get("*"),
        )
        if (
            ttl <= 0
            or (
                tombstone is not None
                and tombstone.get("revoked") is True
            )
            or max(
                self._owner_sso_revoked.get(login_sid, 0),
                self._owner_sso_revoked.get("*", 0),
            ) > now
        ):
            return None
        return self._serializer.dumps({
            "sid": secrets.token_hex(16),
            "generation": self._generation,
            "ttl": ttl,
            "auth": "owner_sso",
            "clerk_session_id": login_sid,
            "clerk_subject": subject,
            "attestation_expires_at": deadline,
        })

    @staticmethod
    def owner_sso_matches(
        data: object, attestation: Mapping[str, object] | None
    ) -> bool:
        """Check identity binding; signature/deadline checks are separate."""
        verified = normalize_owner_attestation(attestation)
        return bool(
            SessionManager.is_owner_sso(data)
            and verified is not None
            and hmac.compare_digest(
                str(data.get("clerk_session_id", "")),
                str(verified["login_sid"]),
            )
            and hmac.compare_digest(
                str(data.get("clerk_subject", "")),
                str(verified["subject"]),
            )
        )

    async def revoke_owner_sso(
        self,
        token: str | None,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> bool:
        """Permanently stop this Clerk login from silently re-materializing."""
        loaded = self._load(token)
        if loaded is None or not self.is_owner_sso(loaded[0]):
            return False
        data, ttl, issued_at = loaded
        session_id = data.get("clerk_session_id")
        subject = data.get("clerk_subject")
        if (
            not isinstance(session_id, str)
            or not session_id
            or not isinstance(subject, str)
            or not subject
        ):
            return False
        expiry = max(
            int(data.get("attestation_expires_at", 0)),
            issued_at + ttl + 1,
        )
        async with self._security_lock:
            self._owner_sso_revoked[session_id] = max(
                expiry, self._owner_sso_revoked.get(session_id, 0)
            )
            revision = self._owner_sso_revision + 1
            self._owner_sso_revocation_tombstones[session_id] = {
                "revision": revision,
                "revoked": True,
                "subject": subject,
            }
            await self._persist({
                "kind": "owner_sso_revoke",
                "login_sid": session_id,
                "subject": subject,
                "expires_at": expiry,
                "revision": revision,
            })
        return True

    @staticmethod
    def owner_sso_login_id(
        attestation: Mapping[str, object] | None,
    ) -> str | None:
        verified = normalize_owner_attestation(attestation)
        if verified is None:
            return None
        return str(verified["login_sid"])

    def owner_sso_admin_locked(
        self, attestation: Mapping[str, object] | None
    ) -> bool:
        verified = normalize_owner_attestation(attestation)
        subject = str(verified["subject"]) if verified is not None else None
        state = (
            self._owner_sso_subject_locks.get(subject)
            if subject is not None
            else None
        )
        return bool(
            subject
            and (
                state is not None and state.get("locked") is True
                or self._owner_sso_subject_locks.get("*", {}).get("locked")
                is True
            )
        )

    async def lock_owner_sso_admin(
        self, attestation: Mapping[str, object] | None
    ) -> bool:
        verified = normalize_owner_attestation(attestation)
        if verified is None:
            return False
        subject = str(verified["subject"])
        # Lock the verified subject until an explicit unlock, not only for
        # this request's short attestation freshness window. Otherwise a later
        # login_sid could auto-grant admin again after Manual Lock.
        async with self._security_lock:
            revision = self._owner_sso_revision + 1
            self._owner_sso_subject_locks[subject] = {
                "revision": revision,
                "locked": True,
            }
            await self._persist({
                "kind": "owner_sso_subject_lock",
                "subject": subject,
                "locked": True,
                "revision": revision,
            })
        return True

    async def unlock_owner_sso_admin(
        self, attestation: Mapping[str, object] | None
    ) -> bool:
        verified = normalize_owner_attestation(attestation)
        if verified is None:
            return False
        subject = str(verified["subject"])
        async with self._security_lock:
            revision = self._owner_sso_revision + 1
            await self._persist({
                "kind": "owner_sso_subject_lock",
                "subject": subject,
                "locked": False,
                "revision": revision,
            })
            self._owner_sso_subject_locks[subject] = {
                "revision": max(revision, self._owner_sso_revision),
                "locked": False,
            }
        return True

    def _load(self, token: str | None) -> tuple[dict, int, int] | None:
        if not token:
            return None
        try:
            data, timestamp = self._serializer.loads(
                token, max_age=self._max_token_age, return_timestamp=True
            )
        except (BadSignature, SignatureExpired):
            return None
        if not isinstance(data, dict) or not isinstance(data.get("sid"), str):
            return None
        # Cookies issued before per-session lifetimes were introduced did not
        # contain ttl. Keep them valid for the ordinary configured lifetime.
        ttl = data.get("ttl", self.max_age)
        if (
            isinstance(ttl, bool)
            or not isinstance(ttl, int)
            or ttl <= 0
            or ttl > self._max_token_age
        ):
            return None
        try:
            # Re-run the timed verification with the signed per-session bound.
            self._serializer.loads(token, max_age=ttl)
        except (BadSignature, SignatureExpired):
            return None
        try:
            generation = int(data.get("generation", 0))
        except (TypeError, ValueError):
            return None
        if generation != self._generation:
            return None
        issued_at = int(timestamp.timestamp())
        return data, ttl, issued_at

    def validate(
        self,
        token: str | None,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> dict | None:
        loaded = self._load(token)
        if loaded is None:
            return None
        data, ttl, issued_at = loaded
        if self.is_owner_sso(data):
            verified = normalize_owner_attestation(owner_attestation)
            if not self.owner_sso_matches(data, owner_attestation):
                return None
            sso_revoked_until = self._owner_sso_revoked.get(
                str(data.get("clerk_session_id", "")), 0
            )
            tombstone = self._owner_sso_revocation_tombstones.get(
                str(data.get("clerk_session_id", "")),
                self._owner_sso_revocation_tombstones.get("*"),
            )
            if (
                sso_revoked_until > int(time.time())
                or (
                    tombstone is not None
                    and tombstone.get("revoked") is True
                )
            ):
                return None
            try:
                attestation_deadline = int(data["attestation_expires_at"])
            except (KeyError, TypeError, ValueError):
                return None
            # The first attestation only bootstraps the signed session. Every
            # later request still supplies and validates a fresh gateway
            # attestation above, so this stored deadline must merely be a
            # valid signed timestamp at issuance.
            if attestation_deadline < issued_at:
                return None
            if min(issued_at + ttl, int(verified["expires_at"])) <= int(time.time()):
                return None
        expiry = self._revoked.get(data["sid"])
        if expiry is not None:
            if expiry > int(time.time()):
                return None
            self._revoked.pop(data["sid"], None)
        return data

    def remaining_session_lifetime(self, token: str | None) -> int | None:
        """Return the validated ordinary session's remaining lifetime.

        The value is derived from the signed session timestamp and its signed
        per-session TTL, never from a caller-provided duration.  Returning
        ``None`` for an invalid or expired token makes it safe for callers to
        use this as the upper bound for a secondary capability.
        """
        loaded = self._load(token)
        if loaded is None:
            return None
        data, ttl, issued_at = loaded
        expiry = issued_at + ttl
        remaining = expiry - int(time.time())
        if remaining <= 0:
            return None
        revoked = self._revoked.get(data["sid"])
        if revoked is not None:
            if revoked > int(time.time()):
                return None
            self._revoked.pop(data["sid"], None)
        return remaining

    def _state(self) -> dict:
        now = int(time.time())
        self._revoked = {
            sid: expiry for sid, expiry in self._revoked.items()
            if expiry > now
        }
        self._admin_generations = {
            sid: value
            for sid, value in self._admin_generations.items()
            if value.get("expires_at", 0) > now
        }
        self._owner_sso_revoked = {
            session_id: expiry
            for session_id, expiry in self._owner_sso_revoked.items()
            if expiry > now
        }
        return {
            "generation": self._generation,
            "revoked": dict(self._revoked),
            "admin_generation": self._admin_generation,
            "admin_generations": {
                sid: dict(value)
                for sid, value in self._admin_generations.items()
            },
            "owner_sso_revoked": dict(self._owner_sso_revoked),
            "owner_sso_revision": self._owner_sso_revision,
            "owner_sso_subject_locks": {
                subject: dict(value)
                for subject, value in self._owner_sso_subject_locks.items()
            },
            "owner_sso_revocations": {
                login_sid: dict(value)
                for login_sid, value
                in self._owner_sso_revocation_tombstones.items()
            },
        }

    def _fail_closed_after_persist_failure(self, mutation: dict | None) -> None:
        """Keep this manager stricter when durable auth state cannot commit."""
        kind = mutation.get("kind") if isinstance(mutation, dict) else None
        if kind == "invalidate_all":
            # A different manager may have committed the same generation while
            # this write failed.  Do not accept tokens issued at that epoch.
            self._generation += 1
            self._failed_generation_floor = max(
                self._failed_generation_floor, self._generation
            )
        elif kind == "revoke_admin_grant":
            sid = mutation.get("sid")
            if isinstance(sid, str):
                current = self._admin_generations.get(sid, {}).get(
                    "generation", 0
                )
                self._admin_generations[sid] = {
                    "generation": current + 1,
                    "expires_at": max(
                        int(mutation.get("expires_at", 0)),
                        int(time.time()) + 1,
                    ),
                }
                self._failed_admin_generations[sid] = dict(
                    self._admin_generations[sid]
                )
                try:
                    candidate_global = int(
                        mutation.get("candidate_admin_generation", 0)
                    )
                except (TypeError, ValueError):
                    candidate_global = 0
                self._failed_admin_generation_floor = max(
                    self._failed_admin_generation_floor, candidate_global
                )
        elif kind == "revoke_session":
            sid = mutation.get("sid")
            expiry = mutation.get("expires_at")
            if isinstance(sid, str) and isinstance(expiry, (int, float)):
                self._failed_revocations[sid] = max(
                    int(expiry), self._failed_revocations.get(sid, 0)
                )
        elif kind == "owner_sso_subject_lock":
            subject = mutation.get("subject")
            revision = mutation.get("revision")
            if isinstance(subject, str) and isinstance(revision, (int, float)):
                candidate = (int(revision), mutation.get("locked") is True)
                current_floor = self._failed_owner_sso_subject_floors.get(
                    subject, (0, False)
                )
                if candidate[0] >= current_floor[0]:
                    self._failed_owner_sso_subject_floors[subject] = candidate
                if mutation.get("locked") is False:
                    self._owner_sso_subject_locks[subject] = {
                        "revision": int(revision),
                        "locked": True,
                    }
        elif kind == "owner_sso_revoke":
            login_sid = mutation.get("login_sid")
            subject = mutation.get("subject")
            revision = mutation.get("revision")
            if (
                isinstance(login_sid, str)
                and isinstance(subject, str)
                and isinstance(revision, (int, float))
            ):
                current = self._failed_owner_sso_revocation_floors.get(
                    login_sid, (0, subject)
                )
                if int(revision) >= current[0]:
                    self._failed_owner_sso_revocation_floors[login_sid] = (
                        int(revision),
                        subject,
                    )

    def mark_invalidation_failed(self) -> None:
        """Fail closed when a compound password mutation cannot commit."""
        self._generation += 1
        self._failed_generation_floor = max(
            self._failed_generation_floor, self._generation
        )

    async def _persist(self, mutation: dict | None = None) -> None:
        state = self._state()
        try:
            if self._mutate_security_state is not None:
                committed = await self._mutate_security_state(
                    state, mutation or {}
                )
                if isinstance(committed, dict):
                    # The callback allocates generations from the committed
                    # database value.  Apply it before reporting success.
                    self.replace_security_state(committed)
            elif self._persist_security_state is not None:
                await self._persist_security_state(state)
        except BaseException:
            self._fail_closed_after_persist_failure(mutation)
            raise

    async def revoke(
        self,
        token: str | None,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> bool:
        """Revoke one valid session and persist the revocation before return."""
        loaded = self._load(token)
        if loaded is None:
            return False
        if (
            not self.is_owner_sso(loaded[0])
            and self.validate(token, owner_attestation) is None
        ):
            return False
        async with self._security_lock:
            # Re-check after acquiring the lock so concurrent logout/password
            # mutations can't overwrite or revive one another.
            loaded = self._load(token)
            if loaded is None:
                return False
            if (
                not self.is_owner_sso(loaded[0])
                and self.validate(token, owner_attestation) is None
            ):
                return False
            data, ttl, issued_at = loaded
            # Retain the revocation through this token's own signed expiry.
            # In particular, a 30-day token must not revive when the old
            # ordinary-session prune horizon passes.
            self._revoked[data["sid"]] = issued_at + ttl + 1
            candidate_generation = None
            if len(self._revoked) > self._MAX_REVOCATIONS:
                self._generation += 1
                self._revoked.clear()
                candidate_generation = self._generation
            mutation = {
                "kind": "revoke_session",
                "sid": data["sid"],
                "expires_at": issued_at + ttl + 1,
            }
            if candidate_generation is not None:
                mutation["candidate_generation"] = candidate_generation
            await self._persist(mutation)
        return True

    async def invalidate_all(self) -> None:
        """Invalidate every issued session, used after a password change."""
        async with self._security_lock:
            self._generation += 1
            self._revoked.clear()
            await self._persist({
                "kind": "invalidate_all",
                "candidate_generation": self._generation,
            })

    async def revoke_admin_grant(
        self,
        cookie_token: str | None,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> bool:
        """Revoke all remote-admin grants for one authenticated session.

        The ordinary session remains valid.  A monotonically increasing
        per-session epoch is persisted before this returns, so bearer
        capabilities captured before Manual Lock fail even after recreation
        of the dashboard process.
        """
        loaded = self._load(cookie_token)
        if loaded is None or self.validate(cookie_token, owner_attestation) is None:
            return False
        data, ttl, issued_at = loaded
        sid = data["sid"]
        expiry = issued_at + ttl + 1
        async with self._security_lock:
            loaded = self._load(cookie_token)
            if loaded is None or self.validate(cookie_token, owner_attestation) is None:
                return False
            data, ttl, issued_at = loaded
            sid = data["sid"]
            expiry = issued_at + ttl + 1
            current = self._admin_generations.get(sid, {}).get(
                "generation", 0
            )
            self._admin_generations[sid] = {
                "generation": current + 1,
                "expires_at": expiry,
            }
            candidate_admin_generation = None
            if len(self._admin_generations) > self._MAX_ADMIN_GENERATIONS:
                self._admin_generation += 1
                self._admin_generations.clear()
                candidate_admin_generation = self._admin_generation
            mutation = {
                "kind": "revoke_admin_grant",
                "sid": sid,
                "expires_at": expiry,
                "candidate_generation": current + 1,
            }
            if candidate_admin_generation is not None:
                mutation["candidate_admin_generation"] = (
                    candidate_admin_generation
                )
            await self._persist(mutation)
        return True

    def csrf_for(self, token: str) -> str:
        return hmac.new(self._csrf_key, token.encode(), hashlib.sha256).hexdigest()

    def csrf_ok(self, token: str | None, csrf: str | None) -> bool:
        if not token or not csrf:
            return False
        return hmac.compare_digest(self.csrf_for(token), csrf)

    # -- scoped capabilities ------------------------------------------------
    # WebSocket handshakes cannot carry custom headers, and putting the
    # session cookie value in JavaScript-visible messages would widen its
    # exposure. Instead the page fetches a short-lived capability over an
    # authenticated (cookie + CSRF) endpoint and presents it in the socket
    # hello. A capability is bound to the session id AND an explicit scope,
    # so it cannot be replayed for a different purpose or another session.

    def capability_for(
        self,
        cookie_token: str | None,
        scope: str,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> str | None:
        """Issue a signed, scoped capability for the authenticated session."""
        data = self.validate(cookie_token, owner_attestation)
        if not isinstance(data, dict) or not data.get("sid"):
            return None
        if (
            scope == "remote-admin"
            and self.is_owner_sso(data)
            and self.owner_sso_admin_locked(owner_attestation)
        ):
            return None
        return self._cap_serializer.dumps({"sid": data["sid"], "scope": scope})

    def issue_capability(
        self,
        cookie_token: str | None,
        scope: str,
        ttl_seconds: int,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> str | None:
        """Issue a signed, session-bound capability with an explicit lifetime.

        The lifetime is part of the signed payload as well as being enforced
        when the token is read.  Callers should still validate the ordinary
        session on every request; a capability never extends that session.
        """
        if (
            isinstance(ttl_seconds, bool)
            or not isinstance(ttl_seconds, int)
            or ttl_seconds <= 0
        ):
            raise ValueError("capability lifetime must be a positive integer")
        data = self.validate(cookie_token, owner_attestation)
        if not isinstance(data, dict) or not data.get("sid"):
            return None
        return self._cap_serializer.dumps({
            "sid": data["sid"],
            "scope": scope,
            "ttl": ttl_seconds,
        })

    def issue_session_capability(
        self,
        cookie_token: str | None,
        scope: str,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> str | None:
        """Issue a capability that cannot outlive its ordinary session.

        This is intentionally separate from :meth:`issue_capability`: the
        latter keeps its generic short-lived behavior for existing callers,
        while this mode carries the verified session expiry and admin epoch.
        """
        loaded = self._load(cookie_token)
        if loaded is None or self.validate(cookie_token, owner_attestation) is None:
            return None
        data, ttl, issued_at = loaded
        if (
            scope == "remote-admin"
            and self.is_owner_sso(data)
            and self.owner_sso_admin_locked(owner_attestation)
        ):
            return None
        now = int(time.time())
        session_expires_at = issued_at + ttl
        if session_expires_at <= now:
            return None
        admin_epoch = self._admin_generations.get(data["sid"], {}).get(
            "generation", 0
        )
        return self._cap_serializer.dumps({
            "sid": data["sid"],
            "scope": scope,
            "mode": "session",
            "session_expires_at": session_expires_at,
            "admin_generation": self._admin_generation,
            "admin_session_generation": admin_epoch,
            "jti": secrets.token_hex(16),
        })

    def session_capability_info(
        self,
        cookie_token: str | None,
        capability: str | None,
        scope: str,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> dict | None:
        """Validate a session-scoped capability and return safe timing data."""
        loaded = self._load(cookie_token)
        if (
            loaded is None
            or self.validate(cookie_token, owner_attestation) is None
            or not capability
        ):
            return None
        session_data, session_ttl, session_issued_at = loaded
        if (
            scope == "remote-admin"
            and self.is_owner_sso(session_data)
            and self.owner_sso_admin_locked(owner_attestation)
        ):
            return None
        try:
            cap, timestamp = self._cap_serializer.loads(
                capability,
                max_age=self._max_token_age,
                return_timestamp=True,
            )
        except (BadSignature, SignatureExpired):
            return None
        if not isinstance(cap, dict):
            return None
        if (
            cap.get("mode") != "session"
            or not isinstance(cap.get("jti"), str)
            or not cap.get("jti")
            or not hmac.compare_digest(str(cap.get("scope", "")), scope)
            or not hmac.compare_digest(
                str(cap.get("sid", "")), str(session_data["sid"])
            )
        ):
            return None
        try:
            session_expires_at = int(cap["session_expires_at"])
            cap_admin_generation = int(cap["admin_generation"])
            cap_session_generation = int(cap["admin_session_generation"])
        except (KeyError, TypeError, ValueError):
            return None
        # The signed capability must describe exactly the session that
        # accompanies it.  This rejects capabilities minted for a shorter or
        # different session even when the bearer presents another valid cookie.
        if session_expires_at != session_issued_at + session_ttl:
            return None
        current_session_generation = self._admin_generations.get(
            session_data["sid"], {}
        ).get("generation", 0)
        if (
            cap_admin_generation != self._admin_generation
            or cap_session_generation != current_session_generation
        ):
            return None
        now = int(time.time())
        if session_expires_at <= now:
            return None
        # A capability may not be accepted past either its own signed age or
        # the ordinary session deadline.  There is no independent 15-minute
        # admin lifetime in this mode.
        issued_at = int(timestamp.timestamp())
        expires_at = min(session_expires_at, issued_at + self._max_token_age)
        if expires_at <= now:
            return None
        return {
            "issued_at": issued_at,
            "expires_at": expires_at,
            "ttl_seconds": max(0, expires_at - now),
        }

    def capability_info(
        self,
        cookie_token: str | None,
        capability: str | None,
        scope: str,
        max_age: int,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> dict | None:
        """Return safe timing metadata for a fresh scoped capability.

        The returned mapping intentionally contains no token material.  It is
        useful for status endpoints that need to report expiry without
        accidentally echoing a bearer capability.
        """
        data = self.validate(cookie_token, owner_attestation)
        if not isinstance(data, dict) or not data.get("sid") or not capability:
            return None
        if (
            isinstance(max_age, bool)
            or not isinstance(max_age, int)
            or max_age <= 0
        ):
            return None
        try:
            cap, timestamp = self._cap_serializer.loads(
                capability, max_age=max_age, return_timestamp=True
            )
        except (BadSignature, SignatureExpired):
            return None
        if not isinstance(cap, dict):
            return None
        ttl = cap.get("ttl", max_age)
        if (
            isinstance(ttl, bool)
            or not isinstance(ttl, int)
            or ttl <= 0
            or ttl > max_age
        ):
            return None
        issued_at = int(timestamp.timestamp())
        expires_at = issued_at + ttl
        now = int(time.time())
        if expires_at <= now:
            return None
        if not (
            hmac.compare_digest(str(cap.get("sid", "")), str(data["sid"]))
            and hmac.compare_digest(str(cap.get("scope", "")), scope)
        ):
            return None
        return {
            "issued_at": issued_at,
            "expires_at": expires_at,
            "ttl_seconds": max(0, expires_at - now),
        }

    def capability_ok(
        self,
        cookie_token: str | None,
        capability: str | None,
        scope: str,
        max_age: int = 120,
        owner_attestation: Mapping[str, object] | None = None,
    ) -> bool:
        """True when *capability* is fresh, matches *scope*, and belongs to
        the same session that presents it."""
        data = self.validate(cookie_token, owner_attestation)
        if not isinstance(data, dict) or not data.get("sid") or not capability:
            return False
        try:
            cap = self._cap_serializer.loads(capability, max_age=max_age)
        except (BadSignature, SignatureExpired):
            return False
        if not isinstance(cap, dict):
            return False
        return hmac.compare_digest(
            str(cap.get("sid", "")), str(data["sid"])
        ) and hmac.compare_digest(str(cap.get("scope", "")), scope)


class LoginRateLimiter:
    def __init__(self, max_attempts: int, window_seconds: int) -> None:
        self.max_attempts = max_attempts
        self.window = window_seconds
        self._attempts: dict[str, list[float]] = {}

    def check(self, ip: str) -> bool:
        """True if this IP may attempt a login."""
        now = time.monotonic()
        attempts = [t for t in self._attempts.get(ip, []) if now - t < self.window]
        self._attempts[ip] = attempts
        return len(attempts) < self.max_attempts

    def record_failure(self, ip: str) -> None:
        self._attempts.setdefault(ip, []).append(time.monotonic())

    def reset(self, ip: str) -> None:
        self._attempts.pop(ip, None)

    def retry_in(self, ip: str) -> int:
        attempts = self._attempts.get(ip, [])
        if not attempts:
            return 0
        return max(0, int(self.window - (time.monotonic() - min(attempts))))
