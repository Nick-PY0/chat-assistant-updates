"""Focused pre-runtime safety tests for the desktop launcher."""

from __future__ import annotations

import socket
import subprocess
import sys
from pathlib import Path

import pytest

from launcher_safety import (
    DashboardBindError,
    PortInUseError,
    data_dir_lock_path,
    installation_lock_path,
    reserve_dashboard_socket,
    try_acquire_file_lock,
)


def _child_can_acquire(path: Path) -> bool:
    source_root = Path(__file__).resolve().parents[1]
    code = (
        "from launcher_safety import try_acquire_file_lock; "
        f"lock = try_acquire_file_lock({str(path)!r}); "
        "print('yes' if lock is not None else 'no'); "
        "lock and lock.release()"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=source_root,
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip() == "yes"


def test_busy_preferred_port_selects_and_holds_bounded_fallback():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as occupied:
        occupied.bind(("127.0.0.1", 0))
        occupied.listen()
        preferred = occupied.getsockname()[1]
        reserved, selected = reserve_dashboard_socket(
            "127.0.0.1", preferred, attempts=8
        )
        try:
            assert preferred < selected <= preferred + 7
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as challenger:
                with pytest.raises(OSError):
                    challenger.bind(("127.0.0.1", selected))
        finally:
            reserved.close()


def test_strict_port_never_moves_a_busy_explicit_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as occupied:
        occupied.bind(("127.0.0.1", 0))
        occupied.listen()
        with pytest.raises(PortInUseError):
            reserve_dashboard_socket(
                "127.0.0.1", occupied.getsockname()[1], strict=True
            )


@pytest.mark.parametrize("host", ["", "not a valid host name !!!"])
def test_invalid_dashboard_address_is_not_misreported_as_busy(host):
    with pytest.raises(DashboardBindError) as raised:
        reserve_dashboard_socket(host, 8756)
    assert not isinstance(raised.value, PortInUseError)


def test_data_lock_blocks_a_simultaneous_process_and_releases(tmp_path):
    lock_path = data_dir_lock_path(tmp_path / "nexa-data")
    owner = try_acquire_file_lock(lock_path)
    assert owner is not None
    try:
        assert _child_can_acquire(lock_path) is False
    finally:
        owner.release()
    assert _child_can_acquire(lock_path) is True
    # Retained marker files are not treated as live locks.
    assert lock_path.exists()


def test_independent_data_dirs_do_not_conflict_but_shared_install_does(tmp_path):
    first_data = try_acquire_file_lock(data_dir_lock_path(tmp_path / "one"))
    second_data = try_acquire_file_lock(data_dir_lock_path(tmp_path / "two"))
    install_path = installation_lock_path(tmp_path / "shared-install")
    install_owner = try_acquire_file_lock(install_path)
    assert first_data is not None
    assert second_data is not None
    assert install_owner is not None
    try:
        # Separate portable data directories can run independently.
        assert _child_can_acquire(data_dir_lock_path(tmp_path / "three")) is True
        # But two updater transactions cannot mutate the same install tree.
        assert _child_can_acquire(install_path) is False
    finally:
        install_owner.release()
        second_data.release()
        first_data.release()


def test_staged_update_does_not_mutate_an_install_locked_by_another_copy(
    monkeypatch, tmp_path
):
    """The pre-runtime bridge must respect another data dir's install owner."""
    import run_chat

    install = tmp_path / "shared-install"
    install.mkdir()
    launcher = install / "run_chat.py"
    launcher.write_text("old launcher", encoding="utf-8")
    pending = tmp_path / "other-data" / "updates" / "pending"
    pending.mkdir(parents=True)
    (pending / "run_chat.py").write_text("new launcher", encoding="utf-8")
    (pending / "requirements.txt").write_text("", encoding="utf-8")

    lock_path = installation_lock_path(install)
    source_root = Path(__file__).resolve().parents[1]
    holder_code = (
        "from launcher_safety import try_acquire_file_lock; "
        "import sys, time; "
        f"lock = try_acquire_file_lock({str(lock_path)!r}); "
        "assert lock is not None; print('ready', flush=True); time.sleep(20)"
    )
    holder = subprocess.Popen(
        [sys.executable, "-c", holder_code],
        cwd=source_root,
        stdout=subprocess.PIPE,
        text=True,
    )
    try:
        assert holder.stdout is not None
        assert holder.stdout.readline().strip() == "ready"
        monkeypatch.setattr(run_chat, "__file__", str(launcher))
        monkeypatch.setenv("CHAT_DATA_DIR", str(tmp_path / "other-data"))
        run_chat.apply_pending_update()
        assert launcher.read_text(encoding="utf-8") == "old launcher"
        assert pending.is_dir()
    finally:
        holder.terminate()
        holder.wait(timeout=5)


def test_frozen_helper_holds_shared_locks_until_copy_then_relaunches(tmp_path):
    """The delayed frozen copy is owned by the helper, not its exiting parent."""
    import run_chat

    install = tmp_path / "install"
    install.mkdir()
    exe = install / "Chat.exe"
    pending = tmp_path / "data-a" / "updates" / "pending"
    pending.mkdir(parents=True)
    result = pending.parent / ".apply-result-alpha.marker"
    transaction = pending.parent / ".frozen-apply-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.marker"
    ready = pending.parent / ".frozen-ready-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.marker"
    batch, powershell = run_chat._frozen_update_helper_scripts(
        exe=exe,
        pending=pending,
        data_lock=data_dir_lock_path(pending.parent.parent),
        install_lock=installation_lock_path(install),
        backup=tmp_path / ".install.update-backup-alpha",
        failed_marker=pending.parent / "apply-failed.marker",
        result_marker=result,
        transaction_marker=transaction,
        ready_marker=ready,
        applied_stage=pending.parent / ".frozen-applied-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        launcher_pid=12345,
    )

    assert "timeout /t" not in batch
    assert "start " not in batch.lower()
    assert ".install.update-backup-alpha" in batch
    assert 'if exist "%BACKUP%" goto failed' in batch
    assert 'if /I "%~1"=="restore" goto restore' in batch
    assert 'exit /b 2' in batch
    assert 'move "%STAGE%" "%APPLIED%"' in batch
    assert batch.index('move "%STAGE%" "%APPLIED%"') < batch.index('> "%TRANSACTION%"')
    assert f'rmdir /s /q "{pending}"' not in batch
    assert "Wait-Process -Id $launcherPid" in powershell
    assert str(data_dir_lock_path(pending.parent.parent)) in powershell
    assert str(installation_lock_path(install)) in powershell
    assert "Acquire-NexaLock $dataLockPath" in powershell
    assert "Acquire-NexaLock $installLockPath" in powershell
    assert "for ($attempt = 0; $attempt -lt $attempts; $attempt++)" in powershell
    assert "Test-Path -LiteralPath $readyMarker" in powershell
    assert "state.operation.phase -eq 'complete'" in powershell
    assert "Remove-Item -LiteralPath $backupPath" in powershell
    assert "Unlock(0, 1)" in powershell
    # Relaunch happens only after the finally block disposes both locks.
    assert powershell.index("finally") < powershell.index("Start-Process -FilePath $exePath")
    assert powershell.index("Remove-Item -LiteralPath $appliedStage") > powershell.index(
        "if ($ready)"
    )
    assert "if ($LASTEXITCODE -eq 2)" in powershell


def test_frozen_helpers_for_independent_data_dirs_share_only_install_lock(tmp_path):
    """Concurrent portable copies get unique transactions, never a shared bat."""
    import run_chat

    install = tmp_path / "install"
    install.mkdir()
    exe = install / "Chat.exe"

    generated = []
    for token in ("first", "second"):
        pending = tmp_path / token / "updates" / "pending"
        pending.mkdir(parents=True)
        result = pending.parent / f".apply-result-{token}.marker"
        transaction = pending.parent / f".frozen-apply-{'a' * 32}.marker"
        ready = pending.parent / f".frozen-ready-{'a' * 32}.marker"
        generated.append(
            run_chat._frozen_update_helper_scripts(
                exe=exe,
                pending=pending,
                data_lock=data_dir_lock_path(pending.parent.parent),
                install_lock=installation_lock_path(install),
                backup=tmp_path / f".install.update-backup-{token}",
                failed_marker=pending.parent / "apply-failed.marker",
                result_marker=result,
                transaction_marker=transaction,
                ready_marker=ready,
                applied_stage=pending.parent / f".frozen-applied-{token}",
                launcher_pid=1,
            )
        )

    (first_batch, first_ps), (second_batch, second_ps) = generated
    assert first_batch != second_batch
    assert ".update-backup-first" in first_batch
    assert ".update-backup-second" in second_batch
    assert str(installation_lock_path(install)) in first_ps
    assert str(installation_lock_path(install)) in second_ps
    assert str(data_dir_lock_path(tmp_path / "first")) in first_ps
    assert str(data_dir_lock_path(tmp_path / "second")) in second_ps


def test_frozen_handoffs_from_two_data_dirs_are_unique_and_share_root_lock(
    monkeypatch, tmp_path
):
    """Preparing simultaneous frozen updates never touches shared helper state."""
    import tempfile
    import uuid
    import subprocess
    from types import SimpleNamespace

    import run_chat

    install = tmp_path / "install"
    install.mkdir()
    exe = install / "Chat.exe"
    helper_temp = tmp_path / "helper-temp"
    pending_dirs = []
    for name in ("one", "two"):
        pending = tmp_path / name / "updates" / "pending"
        pending.mkdir(parents=True)
        pending_dirs.append(pending)

    tokens = iter(("a" * 32, "b" * 32))
    launched = []
    monkeypatch.setattr(run_chat.sys, "executable", str(exe))
    monkeypatch.setattr(tempfile, "gettempdir", lambda: str(helper_temp))
    monkeypatch.setattr(
        uuid, "uuid4", lambda: SimpleNamespace(hex=next(tokens))
    )
    monkeypatch.setattr(
        subprocess, "Popen", lambda command, **kwargs: launched.append((command, kwargs))
    )

    for pending in pending_dirs:
        with pytest.raises(SystemExit) as handoff:
            run_chat._apply_update_frozen(pending)
        assert handoff.value.code == 0

    assert len(launched) == 2
    ps_paths = [Path(command[-1]) for command, _kwargs in launched]
    assert ps_paths[0] != ps_paths[1]
    scripts = [path.read_text(encoding="utf-8") for path in ps_paths]
    shared_lock = str(installation_lock_path(install))
    assert all(shared_lock in script for script in scripts)
    assert str(data_dir_lock_path(tmp_path / "one")) in scripts[0]
    assert str(data_dir_lock_path(tmp_path / "two")) in scripts[1]
    first_batch = pending_dirs[0].parent / f".apply-result-{'a' * 32}.bat"
    second_batch = pending_dirs[1].parent / f".apply-result-{'b' * 32}.bat"
    assert first_batch.exists() and second_batch.exists()
    assert first_batch.read_text(encoding="utf-8") != second_batch.read_text(encoding="utf-8")
    first_text = first_batch.read_text(encoding="utf-8")
    # The backup is a sibling of the install, never a recursive child copied
    # by xcopy's source wildcard.
    assert str(install / f".install.update-backup-{'a' * 32}") not in first_text
    assert str(tmp_path / f".install.update-backup-{'a' * 32}") in first_text


def test_frozen_parent_and_helper_use_the_executable_install_root(monkeypatch, tmp_path):
    """A PyInstaller extraction __file__ must not split the install lock."""
    import run_chat

    install = tmp_path / "actual-install"
    install.mkdir()
    monkeypatch.setattr(run_chat.sys, "frozen", True, raising=False)
    monkeypatch.setattr(run_chat.sys, "executable", str(install / "Chat.exe"))
    monkeypatch.setattr(run_chat, "__file__", str(tmp_path / "pyi-temp" / "run_chat.py"))
    assert run_chat._update_installation_root() == install


def test_serving_ready_signals_only_valid_frozen_transaction(tmp_path):
    """The retained backup is released only after the normal ready bridge."""
    import run_chat

    updates = tmp_path / "data" / "updates"
    updates.mkdir(parents=True)
    token = "c" * 32
    transaction = updates / f".frozen-apply-{token}.marker"
    transaction.write_text("applying\n", encoding="ascii")
    (updates / ".frozen-apply-not-a-token.marker").write_text("ignored", encoding="ascii")

    run_chat._signal_frozen_update_ready(tmp_path / "data")

    assert (updates / f".frozen-ready-{token}.marker").read_text(encoding="ascii") == "serving\n"
    assert not (updates / ".frozen-ready-not-a-token.marker").exists()