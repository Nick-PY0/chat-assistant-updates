"""Focused signed session lifetime and compatibility tests."""

from __future__ import annotations

import time
from copy import deepcopy

from itsdangerous import TimestampSigner
import pytest

import chat_core.security.auth as auth_module
from chat_core.security.auth import SessionManager


class _AtomicOwnerSecurityStore:
    """Small committed-state oracle for interleaved manager tests."""

    def __init__(self):
        self.state = {
            "generation": 0,
            "revoked": {},
            "admin_generation": 0,
            "admin_generations": {},
            "owner_sso_revoked": {},
            "owner_sso_revision": 0,
            "owner_sso_subject_locks": {},
            "owner_sso_revocations": {},
        }
        self.fail = False

    async def mutate(self, _snapshot, mutation):
        if self.fail:
            raise OSError("deliberate durable write failure")
        committed = deepcopy(self.state)
        kind = mutation.get("kind")
        if kind == "invalidate_all":
            committed["generation"] += 1
        elif kind == "owner_sso_subject_lock":
            revision = committed["owner_sso_revision"] + 1
            committed["owner_sso_revision"] = revision
            committed["owner_sso_subject_locks"][mutation["subject"]] = {
                "revision": revision,
                "locked": mutation["locked"],
            }
        elif kind == "owner_sso_revoke":
            revision = committed["owner_sso_revision"] + 1
            committed["owner_sso_revision"] = revision
            committed["owner_sso_revocations"][mutation["login_sid"]] = {
                "revision": revision,
                "revoked": True,
                "subject": mutation["subject"],
            }
        else:
            raise AssertionError(f"unexpected mutation: {kind}")
        self.state = committed
        return deepcopy(committed)


def _owner_attestation(session_id="sid-1", subject="owner-1"):
    return {
        "verified_owner": True,
        "login_sid": session_id,
        "subject": subject,
        "expires_at": int(time.time()) + 3600,
    }


def _owner_manager(store):
    return SessionManager(
        "interleaved-owner-state-secret",
        86400,
        security_state=deepcopy(store.state),
        mutate_security_state=store.mutate,
    )


def test_session_ttl_is_signed_and_server_bounded():
    sessions = SessionManager("ttl-test-secret", 86400)
    token = sessions.issue(sessions.remembered_max_age)
    assert sessions.validate(token) is not None

    payload, timestamp = sessions._serializer.loads(token, return_timestamp=True)
    payload["ttl"] = sessions.remembered_max_age + 1
    overlong = sessions._serializer.dumps(payload)
    assert sessions.validate(overlong) is None

    pieces = token.split(".")
    pieces[0] = ("A" if pieces[0][0] != "A" else "B") + pieces[0][1:]
    assert sessions.validate(".".join(pieces)) is None


def test_per_session_ttl_expires_and_legacy_cookie_keeps_normal_ttl(monkeypatch):
    sessions = SessionManager("expiry-test-secret", 60)
    now = int(time.time())
    monkeypatch.setattr(TimestampSigner, "get_timestamp", lambda self: now - 61)
    expired = sessions.issue(60)
    legacy = sessions._serializer.dumps({"sid": "legacy", "generation": 0})
    monkeypatch.undo()

    assert sessions.validate(expired) is None
    assert sessions.validate(legacy) is None

    current_legacy = sessions._serializer.dumps({
        "sid": "current-legacy",
        "generation": 0,
    })
    assert sessions.validate(current_legacy) is not None


async def test_long_session_revocation_uses_its_signed_expiry():
    persisted = []

    async def persist(state):
        persisted.append(state)

    sessions = SessionManager(
        "revocation-horizon-test-secret",
        86400,
        persist_security_state=persist,
    )
    token = sessions.issue(sessions.remembered_max_age)
    assert await sessions.revoke(token)
    expiry = next(iter(persisted[-1]["revoked"].values()))
    assert expiry > int(time.time()) + 29 * 86400


def test_admin_capability_is_session_bound_and_exposes_only_timing():
    sessions = SessionManager("admin-capability-test-secret", 86400)
    session = sessions.issue()
    other_session = sessions.issue()
    capability = sessions.issue_capability(session, "remote-admin", 900)

    info = sessions.capability_info(session, capability, "remote-admin", 900)
    assert info is not None
    assert set(info) == {"issued_at", "expires_at", "ttl_seconds"}
    assert 0 < info["ttl_seconds"] <= 900
    assert sessions.capability_info(
        other_session, capability, "remote-admin", 900
    ) is None
    assert sessions.capability_info(
        session, capability, "different-scope", 900
    ) is None
    payload, signature = capability.rsplit(".", 1)
    bad_signature = ("A" if signature[0] != "A" else "B") + signature[1:]
    assert sessions.capability_info(
        session, payload + "." + bad_signature, "remote-admin", 900
    ) is None


def test_admin_capability_expiry_is_enforced_without_returning_token_material(
    monkeypatch,
):
    sessions = SessionManager("admin-capability-expiry-secret", 86400)
    session = sessions.issue()
    capability = sessions.issue_capability(session, "remote-admin", 1)
    now = int(time.time())
    monkeypatch.setattr(auth_module.time, "time", lambda: now + 2)
    assert sessions.capability_info(
        session, capability, "remote-admin", 900
    ) is None


async def test_owner_sso_requires_current_attestation_and_logout_blocks_reminting():
    sessions = SessionManager("owner-sso-test-secret", 86400)
    attestation = {
        "verified_owner": True,
        "login_sid": "sess_owner_1",
        "subject": "user_owner_1",
        "expires_at": int(time.time()) + 3600,
    }
    token = sessions.issue_owner_sso(attestation)
    assert token
    assert sessions.validate(token, attestation) is not None
    assert sessions.validate(token) is None
    assert sessions.validate(
        token,
        {**attestation, "subject": "user_other"},
    ) is None

    capability = sessions.issue_session_capability(
        token, "remote-admin", attestation
    )
    assert capability
    assert sessions.session_capability_info(
        token, capability, "remote-admin", owner_attestation=attestation
    ) is not None
    assert sessions.session_capability_info(
        token, capability, "remote-admin"
    ) is None

    assert await sessions.lock_owner_sso_admin(attestation)
    assert sessions.owner_sso_admin_locked(attestation)
    locked_token = sessions.issue_owner_sso(attestation)
    assert locked_token
    locked_state = sessions._state()
    restarted_locked = SessionManager(
        "owner-sso-test-secret", 86400, security_state=locked_state
    )
    assert restarted_locked.owner_sso_admin_locked(attestation)
    assert await restarted_locked.unlock_owner_sso_admin(attestation)
    assert not restarted_locked.owner_sso_admin_locked(attestation)

    assert await sessions.revoke_owner_sso(token, attestation)
    assert sessions.validate(token, attestation) is None
    assert sessions.issue_owner_sso(attestation) is None
    restarted = SessionManager(
        "owner-sso-test-secret", 86400, security_state=sessions._state()
    )
    assert restarted.issue_owner_sso(attestation) is None


async def test_interleaved_owner_managers_logout_tombstone_blocks_stale_remint():
    store = _AtomicOwnerSecurityStore()
    first = _owner_manager(store)
    stale = _owner_manager(store)
    attestation = _owner_attestation()
    token = first.issue_owner_sso(attestation)
    assert token

    assert await stale.revoke_owner_sso(token, attestation)
    first.apply_security_state(deepcopy(store.state))
    assert first.issue_owner_sso(attestation) is None


async def test_interleaved_owner_lock_is_subject_bound_across_login_sid_rotation():
    store = _AtomicOwnerSecurityStore()
    first = _owner_manager(store)
    stale = _owner_manager(store)
    first_attestation = _owner_attestation("sid-1", "owner-1")
    second_attestation = _owner_attestation("sid-2", "owner-1")

    assert await first.lock_owner_sso_admin(first_attestation)
    stale.apply_security_state(deepcopy(store.state))
    rotated = stale.issue_owner_sso(second_attestation)
    assert rotated
    assert stale.owner_sso_admin_locked(second_attestation)
    assert stale.issue_session_capability(
        rotated, "remote-admin", second_attestation
    ) is None

    assert await stale.unlock_owner_sso_admin(second_attestation)
    first.apply_security_state(deepcopy(store.state))
    assert not first.owner_sso_admin_locked(first_attestation)


async def test_interleaved_failed_owner_intents_fail_closed_until_committed_retry():
    store = _AtomicOwnerSecurityStore()
    failing = _owner_manager(store)
    other = _owner_manager(store)
    attestation = _owner_attestation()
    token = failing.issue_owner_sso(attestation)
    assert token

    store.fail = True
    with pytest.raises(OSError):
        await failing.revoke_owner_sso(token, attestation)
    failing.apply_security_state(deepcopy(store.state))
    assert failing.validate(token, attestation) is None

    store.fail = False
    assert await other.revoke_owner_sso(token, attestation)
    failing.apply_security_state(deepcopy(store.state))
    assert failing.validate(token, attestation) is None

    # An unlock write failure must not delete a locally effective lock. A
    # later committed unlock with a higher revision is allowed to clear it.
    lock_store = _AtomicOwnerSecurityStore()
    locker = _owner_manager(lock_store)
    unlocker = _owner_manager(lock_store)
    assert await locker.lock_owner_sso_admin(attestation)
    lock_store.fail = True
    with pytest.raises(OSError):
        await unlocker.unlock_owner_sso_admin(attestation)
    unlocker.apply_security_state(deepcopy(lock_store.state))
    assert unlocker.owner_sso_admin_locked(attestation)
    lock_store.fail = False
    assert await locker.unlock_owner_sso_admin(attestation)
    unlocker.apply_security_state(deepcopy(lock_store.state))
    assert not unlocker.owner_sso_admin_locked(attestation)


async def test_interleaved_password_change_generation_denies_stale_owner_sso():
    store = _AtomicOwnerSecurityStore()
    first = _owner_manager(store)
    stale = _owner_manager(store)
    attestation = _owner_attestation()
    token = first.issue_owner_sso(attestation)
    assert token

    assert await stale.invalidate_all() is None
    first.apply_security_state(deepcopy(store.state))
    assert first.validate(token, attestation) is None


async def test_owner_sso_adoption_keeps_newer_lock_unlock_and_revoke_records():
    store = _AtomicOwnerSecurityStore()
    manager = _owner_manager(store)
    first = _owner_attestation("sid-1", "owner-1")
    second = _owner_attestation("sid-2", "owner-1")

    stale_before_lock = deepcopy(store.state)
    assert await manager.lock_owner_sso_admin(first)
    manager.apply_security_state(stale_before_lock)
    assert manager.owner_sso_admin_locked(first)

    stale_before_unlock = deepcopy(store.state)
    assert await manager.unlock_owner_sso_admin(first)
    manager.apply_security_state(stale_before_unlock)
    assert not manager.owner_sso_admin_locked(first)

    token = manager.issue_owner_sso(second)
    assert token
    stale_before_revoke = deepcopy(store.state)
    assert await manager.revoke_owner_sso(token, second)
    manager.apply_security_state(stale_before_revoke)
    assert manager.validate(token, second) is None
    assert manager.issue_owner_sso(second) is None


async def test_failed_owner_sso_floor_survives_unrelated_replace_adoption():
    store = _AtomicOwnerSecurityStore()
    failing = _owner_manager(store)
    other = _owner_manager(store)
    failed_subject = _owner_attestation("sid-1", "owner-1")
    other_subject = _owner_attestation("sid-2", "owner-2")

    store.fail = True
    with pytest.raises(OSError):
        await failing.lock_owner_sso_admin(failed_subject)

    store.fail = False
    assert await other.lock_owner_sso_admin(other_subject)
    failing.replace_security_state(deepcopy(store.state))
    assert failing.owner_sso_admin_locked(failed_subject)