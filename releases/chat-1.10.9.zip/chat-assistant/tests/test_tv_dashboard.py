"""LG TV dashboard endpoints: auth, CSRF, secret hygiene, pairing flow."""

from __future__ import annotations

import asyncio

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime

from test_lg_webos import FakeTV, FakeWoLSender

MAC_RAW = "aa:bb:cc:dd:ee:ff"


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


@pytest.fixture
async def tv_fake(rt):
    """Swap the runtime's TV manager onto in-memory fakes."""
    fake = FakeTV()
    wol = FakeWoLSender()
    rt.tv._connect_factory = fake.connect
    rt.tv._wol_sender = wol
    rt.tv._reconnect_delays = (0.05, 0.05)
    rt.tv._refresh_wait = 0.4  # keep POST /api/tv/refresh snappy under httpx timeouts

    async def _discover():
        return [{"host": "192.168.1.50", "name": "LG UA8000"}]

    rt.tv._discover_fn = _discover
    return fake, wol


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def do_setup(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303


async def _wait_tv(client, predicate, timeout=5.0):
    snap = {}
    for _ in range(int(timeout / 0.02)):
        snap = (await client.get("/api/tv")).json()
        if predicate(snap):
            return snap
        await asyncio.sleep(0.02)
    return snap


async def test_tv_endpoints_require_auth(client):
    await do_setup(client)
    client.cookies.delete(COOKIE)
    assert (await client.get("/api/tv")).status_code == 401
    assert (await client.get("/api/tv/apps?query=x")).status_code == 401
    assert (await client.post("/api/tv/pair", json={})).status_code == 401
    assert (await client.post("/api/tv/command", json={"action": "power_off"})).status_code == 401
    assert (await client.post("/api/tv/refresh", json={})).status_code == 401


async def test_tv_posts_require_csrf(client):
    await do_setup(client)
    resp = await client.post("/api/tv/config", json={"host": "192.168.1.50"})
    assert resp.status_code == 403
    assert (await client.post("/api/tv/refresh", json={})).status_code == 403
    resp = await client.post(
        "/api/tv/config", json={"host": "192.168.1.50"}, headers={"x-csrf": "forged"}
    )
    assert resp.status_code == 403


async def test_tv_api_never_reveals_mac_or_key(client, tv_fake):
    fake, _ = tv_fake
    await do_setup(client)
    csrf = await csrf_of(client)
    h = {"x-csrf": csrf}

    resp = await client.post(
        "/api/tv/config",
        json={"host": "192.168.1.50", "name": "Bedroom TV", "mac": MAC_RAW, "enabled": True},
        headers=h,
    )
    assert resp.status_code == 200
    snap = resp.json()
    assert snap["wol_ready"] is True
    assert "mac" not in snap and "mac_address" not in snap
    assert MAC_RAW not in resp.text.lower()
    assert "aabbccddeeff" not in resp.text.lower().replace(":", "").replace("-", "")

    assert (await client.post("/api/tv/pair", json={}, headers=h)).status_code == 200
    snap = await _wait_tv(client, lambda s: s["connected"])
    assert snap["connected"] is True

    text = (await client.get("/api/tv")).text.lower()
    assert MAC_RAW not in text
    assert fake.client_key.lower() not in text


async def test_tv_pairing_and_control_flow(client, tv_fake):
    fake, _ = tv_fake
    await do_setup(client)
    csrf = await csrf_of(client)
    h = {"x-csrf": csrf}

    r = await client.post("/api/tv/config", json={"host": "10.0.0.9", "enabled": True}, headers=h)
    assert r.status_code == 200

    r = await client.post("/api/tv/pair", json={}, headers=h)
    assert r.status_code == 200
    assert r.json() == {"status": "connecting"}

    snap = await _wait_tv(client, lambda s: s["pairing"]["status"] == "paired" and s["connected"])
    assert snap["connected"] is True
    assert snap["app_count"] == 3
    assert snap["model"] == "UA8000"

    apps = (await client.get("/api/tv/apps", params={"query": "netflix"})).json()
    assert [a["title"] for a in apps["apps"]] == ["Netflix"]
    assert apps["stale"] is False

    r = await client.post(
        "/api/tv/command", json={"action": "volume_set", "percentage": 33}, headers=h
    )
    assert r.status_code == 200 and r.json() == {"volume": 33}
    assert fake.volume == 33

    r = await client.post("/api/tv/command", json={"action": "button", "value": "home"}, headers=h)
    assert r.status_code == 200 and r.json() == {"pressed": "home"}

    r = await client.post("/api/tv/command", json={"action": "launch", "value": "netflix"}, headers=h)
    assert r.status_code == 200
    assert fake.launched == ["netflix"]

    r = await client.post("/api/tv/command", json={"action": "launch", "value": "hulu"}, headers=h)
    assert r.status_code == 400 and "isn't installed" in r.json()["error"]

    # exact payload the Devices-page composer sends: {action, text, submit}
    r = await client.post(
        "/api/tv/command",
        json={"action": "type_text", "text": "stranger things", "submit": True},
        headers=h,
    )
    assert r.status_code == 200
    # the response reports only a character count -- never the text itself
    assert r.json() == {"typed": 15, "submitted": True}
    assert fake.typed == [("stranger things", 0)]
    assert fake.enter_presses == 1

    r = await client.post(
        "/api/tv/command", json={"action": "type_text", "text": "x" * 500}, headers=h
    )
    assert r.status_code == 400 and "120 characters" in r.json()["error"]

    r = await client.post(
        "/api/tv/command", json={"action": "type_text", "text": "a\nb"}, headers=h
    )
    assert r.status_code == 400 and "control characters" in r.json()["error"]

    # the legacy "value" field must NOT silently work for text entry -- the
    # contract is "text"; a value-only payload is an empty-text error
    r = await client.post(
        "/api/tv/command", json={"action": "type_text", "value": "oops"}, headers=h
    )
    assert r.status_code == 400 and "no text" in r.json()["error"]
    assert ("oops", 0) not in fake.typed

    r = await client.post("/api/tv/command", json={"action": "reboot"}, headers=h)
    assert r.status_code == 400 and r.json()["error"] == "unknown TV action"

    r = await client.post("/api/tv/unpair", json={}, headers=h)
    assert r.status_code == 200 and r.json()["paired"] is False


async def test_tv_command_failures_return_400_not_500(client, tv_fake):
    """TV-side/transport failures surface as clean 400 errors with a safe
    message -- never an unhandled 500."""
    fake, _ = tv_fake
    await do_setup(client)
    csrf = await csrf_of(client)
    h = {"x-csrf": csrf}

    r = await client.post("/api/tv/config", json={"host": "10.0.0.9", "enabled": True}, headers=h)
    assert r.status_code == 200
    assert (await client.post("/api/tv/pair", json={}, headers=h)).status_code == 200
    snap = await _wait_tv(client, lambda s: s["pairing"]["status"] == "paired" and s["connected"])
    assert snap["connected"] is True

    # a nonnumeric volume is rejected as a safe user error
    r = await client.post(
        "/api/tv/command", json={"action": "volume_set", "percentage": "loud"}, headers=h
    )
    assert r.status_code == 400
    assert "between 0 and 100" in r.json()["error"]

    # the TV starts failing every request: still clean 400s, never a 500
    fake.error_requests = True
    for body in (
        {"action": "power_off"},
        {"action": "volume_set", "percentage": 30},
        {"action": "mute"},
        {"action": "media", "value": "pause"},
        {"action": "input", "value": "hdmi 1"},
        {"action": "launch", "value": "netflix"},
        {"action": "refresh_apps"},
    ):
        r = await client.post("/api/tv/command", json=body, headers=h)
        assert r.status_code == 400, body
        assert r.json()["error"], body


async def test_tv_discover_endpoint(client, tv_fake):
    await do_setup(client)
    csrf = await csrf_of(client)
    r = await client.post("/api/tv/discover", json={}, headers={"x-csrf": csrf})
    assert r.status_code == 200
    assert r.json() == {"tvs": [{"host": "192.168.1.50", "name": "LG UA8000"}]}


async def test_tv_config_validation_via_api(client, tv_fake):
    await do_setup(client)
    csrf = await csrf_of(client)
    h = {"x-csrf": csrf}
    for payload in ({"mac": "nope"}, {"host": "192.168.1.5:3000"}, {"enabled": True}):
        r = await client.post("/api/tv/config", json=payload, headers=h)
        assert r.status_code == 400, payload
        assert r.json()["error"]


async def test_tv_disabled_commands_rejected(client, tv_fake):
    await do_setup(client)
    csrf = await csrf_of(client)
    r = await client.post(
        "/api/tv/command",
        json={"action": "volume_set", "percentage": 10},
        headers={"x-csrf": csrf},
    )
    assert r.status_code == 400
    assert "turned off" in r.json()["error"]
    assert (await client.get("/api/tv/apps?query=x")).status_code == 400


async def test_tv_unavailable_gives_503(client, rt, monkeypatch):
    await do_setup(client)
    monkeypatch.setattr(rt, "tv", None)
    assert (await client.get("/api/tv")).status_code == 503
    csrf = await csrf_of(client)
    r = await client.post("/api/tv/pair", json={}, headers={"x-csrf": csrf})
    assert r.status_code == 503


async def test_tv_pulse_interval_setting_roundtrip(client, rt):
    await do_setup(client)
    csrf = await csrf_of(client)
    r = await client.post(
        "/api/settings", json={"pulse_tv_interval": 120}, headers={"x-csrf": csrf}
    )
    assert r.status_code == 200
    assert rt.settings.pulse_tv_interval == 120
    # too-small values are rejected, keeping the previous value
    r = await client.post(
        "/api/settings", json={"pulse_tv_interval": 1}, headers={"x-csrf": csrf}
    )
    assert r.status_code == 400
    assert rt.settings.pulse_tv_interval == 120
    # the settings page ships the value to the form
    page = await client.get("/settings")
    assert "pulse_tv_interval" in page.text


async def test_tv_power_on_network_failure_is_400(client, tv_fake):
    """A dead local network during Wake-on-LAN is an ordinary failure: the
    dashboard answers 400 with a safe message, never a 500."""
    fake, wol = tv_fake
    await do_setup(client)
    csrf = await csrf_of(client)
    h = {"x-csrf": csrf}
    r = await client.post(
        "/api/tv/config",
        json={"host": "192.168.1.50", "mac": MAC_RAW, "enabled": True},
        headers=h,
    )
    assert r.status_code == 200
    wol.oserror = True
    r = await client.post("/api/tv/command", json={"action": "power_on"}, headers=h)
    assert r.status_code == 400
    assert "wake signal" in r.json()["error"]


async def test_roku_routes_link_without_an_lg_pairing_prompt(client, rt):
    """Router integration: Roku link is an ECP probe, not LG key pairing."""
    class FakeECP:
        async def request(self, method, path):
            if path == "/query/device-info":
                return 200, b"<device-info><model-name>TCL Roku TV</model-name><is-tv>true</is-tv></device-info>"
            if path == "/query/apps":
                return 200, b'<apps><app id="12">Netflix</app></apps>'
            if path == "/query/active-app":
                return 200, b"<active-app><app>Netflix</app></active-app>"
            if path == "/launch/12":
                return 200, b""
            return 404, b""

    rt.tv.roku._request_fn = FakeECP().request
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        await do_setup(c)
        csrf = await csrf_of(c)
        headers = {"x-csrf": csrf}
        configured = await c.post(
            "/api/tv/config",
            json={"platform": "roku", "host": "192.168.1.55", "enabled": True},
            headers=headers,
        )
        assert configured.status_code == 200
        assert configured.json()["platform"] == "roku"
        linked = await c.post("/api/tv/pair", json={}, headers=headers)
        assert linked.json() == {"status": "linked"}
        snap = (await c.get("/api/tv")).json()
        assert snap["paired"] and snap["capabilities"]["text"] is False
        assert "mac" not in snap
        assert (await c.post(
            "/api/tv/command", json={"action": "launch", "value": "12"}, headers=headers
        )).status_code == 200
        unsupported = await c.post(
            "/api/tv/command", json={"action": "power_on"}, headers=headers
        )
        assert unsupported.status_code == 400
        assert "does not support" in unsupported.json()["error"]
