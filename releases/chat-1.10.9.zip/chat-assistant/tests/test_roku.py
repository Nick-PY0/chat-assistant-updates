"""Roku ECP protocol, manager, and active-TV facade regression coverage."""

from __future__ import annotations

import asyncio

import pytest

from integrations.roku.discovery import parse_ssdp_response
from integrations.roku.manager import RokuManager, RokuTVError
from integrations.roku.protocol import valid_host
from integrations.tv import TVManager
from test_lg_webos import FakeTV


class FakeECP:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []
        self.online = True

    async def request(self, method: str, path: str) -> tuple[int, bytes]:
        self.calls.append((method, path))
        if not self.online:
            raise OSError("offline")
        if path == "/query/device-info":
            return 200, b"<device-info><model-name>TCL Roku TV</model-name><is-tv>true</is-tv></device-info>"
        if path == "/query/active-app":
            return 200, b"<active-app><app>Netflix</app></active-app>"
        if path == "/query/apps":
            return 200, b'<apps><app id="12" type="appl">Netflix</app><app id="837" type="appl">YouTube</app></apps>'
        return (200, b"") if path.startswith(("/keypress/", "/launch/")) else (404, b"")


@pytest.fixture
async def roku(db, bus):
    fake = FakeECP()
    manager = RokuManager(db, bus, request_fn=fake.request, poll_seconds=3600)
    await manager.start()
    yield manager, fake
    await manager.stop()


def test_roku_only_accepts_private_literal_hosts():
    assert valid_host("192.168.1.55")
    assert valid_host("10.0.0.2")
    for value in ("roku.local", "192.168.1.55:8060", "127.0.0.1", "169.254.1.1", "8.8.8.8"):
        assert not valid_host(value)


def test_roku_discovery_pins_location_to_the_ssdp_sender():
    good = (
        b"HTTP/1.1 200 OK\r\nST: roku:ecp\r\n"
        b"LOCATION: http://192.168.1.55:8060/\r\n\r\n"
    )
    assert parse_ssdp_response(good, "192.168.1.55") == {
        "host": "192.168.1.55", "name": "Roku TV"
    }
    hostile = good.replace(b"192.168.1.55", b"127.0.0.1")
    assert parse_ssdp_response(hostile, "192.168.1.55") is None


async def test_roku_link_persists_without_pairing_key_and_exposes_closed_controls(roku, db):
    manager, fake = roku
    snap = await manager.configure(host="192.168.1.55", enabled=True, name="Den TV")
    assert snap["paired"] is False
    assert await manager.start_pairing() == {"status": "linked"}
    snap = manager.snapshot()
    assert snap["paired"] and snap["connected"]
    assert snap["model"] == "TCL Roku TV"
    assert snap["capabilities"]["text"] is False
    assert snap["capabilities"]["power"] is False
    assert snap["capabilities"]["volume_set"] is False
    assert snap["media_actions"] == ["fast_forward", "play", "rewind"]
    row = await db.fetchone("SELECT host, linked FROM roku_ecp_devices WHERE id='default'")
    assert dict(row) == {"host": "192.168.1.55", "linked": 1}
    assert "client_key" not in snap
    await manager.button("home")
    await manager.media("play")
    assert await manager.set_volume(delta=2) == {"volume_changed": 2}
    assert ("POST", "/keypress/Home") in fake.calls
    assert ("POST", "/keypress/Play") in fake.calls
    assert fake.calls.count(("POST", "/keypress/VolumeUp")) == 2
    with pytest.raises(RokuTVError, match="exact volume"):
        await manager.set_volume(percentage=20)
    with pytest.raises(RokuTVError, match="does not support typing"):
        await manager.type_text("secret")
    with pytest.raises(RokuTVError, match="does not support turning"):
        await manager.power_on()


async def test_roku_launch_is_limited_to_discovered_installed_apps(roku):
    manager, fake = roku
    await manager.configure(host="192.168.1.55", enabled=True)
    await manager.start_pairing()
    assert await manager.launch_app("Netflix") == {"launched": "Netflix"}
    assert fake.calls[-1] == ("POST", "/launch/12")
    with pytest.raises(RokuTVError, match="isn't installed"):
        await manager.launch_app("https://example.invalid/launch")


async def test_active_tv_facade_switch_keeps_existing_lg_configuration(db, bus, vault):
    fake = FakeECP()
    tv = TVManager(db, bus, vault)
    await tv.start()
    await tv.configure(name="Existing LG", host="192.168.1.20", enabled=False)
    await tv.configure(platform="roku", name="Roku", host="192.168.1.55", enabled=False)
    assert tv.snapshot()["platform"] == "roku"
    await tv.configure(platform="lg_webos")
    assert tv.snapshot()["platform"] == "lg_webos"
    assert tv.snapshot()["name"] == "Existing LG"
    await tv.stop()


async def test_active_tv_facade_restarts_enabled_adapters_after_round_trip(db, bus, vault):
    """Switching platforms must not leave either manager permanently stopped."""
    ecp = FakeECP()
    lg = FakeTV()
    tv = TVManager(db, bus, vault)
    tv.lg._connect_factory = lg.connect
    tv.lg._reconnect_delays = (0.01,)
    tv.roku._request_fn = ecp.request
    tv.roku._poll_seconds = 3600
    await tv.start()

    await tv.configure(name="LG", host="192.168.1.20", enabled=True)
    await tv.start_pairing()
    for _ in range(100):
        if tv.snapshot()["connected"]:
            break
        await asyncio.sleep(0.01)
    assert tv.snapshot()["platform"] == "lg_webos"
    assert tv.snapshot()["connected"] is True

    await tv.configure(platform="roku", name="Roku", host="192.168.1.55", enabled=True)
    assert tv.platform == "roku"
    assert tv.roku._stopping is False
    assert await tv.start_pairing() == {"status": "linked"}
    assert tv.snapshot()["connected"] is True

    await tv.configure(platform="lg_webos")
    for _ in range(100):
        if tv.snapshot()["connected"]:
            break
        await asyncio.sleep(0.01)
    assert tv.platform == "lg_webos"
    assert tv.lg._stopping is False
    assert tv.snapshot()["connected"] is True

    await tv.configure(platform="roku")
    for _ in range(100):
        if tv.snapshot()["connected"]:
            break
        await asyncio.sleep(0.01)
    assert tv.platform == "roku"
    assert tv.roku._stopping is False
    assert tv.snapshot()["connected"] is True
    await tv.stop()