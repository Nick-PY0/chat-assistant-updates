from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

import deployment.release.publish_release as release_publisher_module
from deployment.release.publish_release import (
    ArchiveExistsError,
    ReleaseError,
    RepositorySnapshot,
    build_release_archive,
    publish_release,
    verify_manifest,
)


class MemoryRepository:
    def __init__(self, latest: dict | None = None) -> None:
        self.objects: dict[str, RepositorySnapshot] = {}
        self.calls: list[tuple] = []
        self.alter_archive = False
        self.fail_archive = False
        self.current_head = "root-head"
        if latest is not None:
            self.objects["latest.json"] = RepositorySnapshot(
                json.dumps(latest).encode(), "old-head"
            )
            self.current_head = "old-head"

    async def read(self, path: str):
        self.calls.append(("read", path))
        snapshot = self.objects.get(path)
        if snapshot is None:
            return None
        return RepositorySnapshot(snapshot.data, self.current_head)

    async def head(self):
        self.calls.append(("head",))
        return self.current_head

    async def write(self, path, data, expected_head, create_only):
        self.calls.append(("write", path, expected_head, create_only))
        if path.startswith("releases/") and self.fail_archive:
            raise RuntimeError("upload failed")
        if expected_head != self.current_head:
            raise RuntimeError("conflict")
        if create_only and path in self.objects:
            raise RuntimeError("already exists")
        stored = data
        if path.startswith("releases/") and self.alter_archive:
            stored += b"altered"
        head = f"head-{len(self.calls)}"
        self.current_head = head
        self.objects[path] = RepositorySnapshot(stored, head)
        return head


@pytest.fixture
def app(tmp_path: Path) -> Path:
    root = tmp_path / "chat-assistant"
    root.mkdir()
    (root / "run_chat.py").write_text("print('chat')\n")
    (root / "chat_core").mkdir()
    (root / "chat_core" / "feature.py").write_text("enabled = True\n")
    return root


@pytest.fixture
def signing(tmp_path: Path):
    private = ed25519.Ed25519PrivateKey.generate()
    path = tmp_path / "publisher.pem"
    path.write_bytes(
        private.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
    )
    public_hex = private.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    ).hex()
    return path, public_hex


def allow_fixture(app: Path, relative: str, reason: str = "Intentional test fixture"):
    fixture = app / relative
    manifest = app / "deployment/release/sensitive_fixture_allowlist.json"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(
        json.dumps(
            {
                "version": 1,
                "fixtures": [
                    {
                        "path": relative,
                        "sha256": hashlib.sha256(fixture.read_bytes()).hexdigest(),
                        "reason": reason,
                    }
                ],
            }
        )
    )


def test_existing_local_archive_is_never_replaced(app: Path):
    archive = app / "releases" / "chat-2.0.0.zip"
    archive.parent.mkdir()
    archive.write_bytes(b"keep")
    with pytest.raises(ArchiveExistsError):
        build_release_archive(app_root=app, version="2.0.0")
    assert archive.read_bytes() == b"keep"


def test_archive_excludes_keys_secrets_and_build_artifacts(app: Path):
    excluded = [
        "master.key",
        "state.db",
        "state.db-wal",
        "deployment/release/signing_key.pem",
        "assets/announcements/message.wav",
        "node_modules/package/file.js",
        ".expo/README.md",
        ".expo-shared/state.json",
        "__pycache__/thing.pyc",
        "old-release.zip",
    ]
    for relative in excluded:
        path = app / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("secret")
    archive = build_release_archive(app_root=app, version="2.0.0")
    with zipfile.ZipFile(archive) as zipped:
        names = set(zipped.namelist())
    assert "chat-assistant/" in names
    assert "chat-assistant/run_chat.py" in names
    assert "chat-assistant/chat_core/feature.py" in names
    assert not names.intersection(
        {f"chat-assistant/{relative}" for relative in excluded}
    )


def test_owner_archive_separates_customer_surface_and_preserves_owner_files(app: Path):
    (app / "run_customer.py").write_text("print('customer marker')\n")
    (app / "customer-installation.json").write_text(
        '{"edition":"customer","entrypoint":"run_customer.py","protocolVersion":2}\n'
    )
    (app / "customer" / "runtime.py").parent.mkdir(parents=True)
    (app / "customer" / "runtime.py").write_text("customer_only = True\n")
    customer_test = app / "tests" / "test_customer_runtime.py"
    customer_test.parent.mkdir(parents=True)
    customer_test.write_text(
        'SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n'
    )
    allowlist = app / "deployment" / "release" / "sensitive_fixture_allowlist.json"
    allowlist.parent.mkdir(parents=True)
    allowlist.write_text(
        json.dumps(
            {
                "version": 1,
                "fixtures": [
                    {
                        "path": "tests/test_customer_runtime.py",
                        "sha256": hashlib.sha256(customer_test.read_bytes()).hexdigest(),
                        "reason": "Customer-only fixture reviewed by the customer release worker.",
                    }
                ],
            }
        )
    )
    customer_test.write_text(
        'SAMPLE = "sk-zyxwvutsrqponmlkjihgfedcba654321"\n'
    )
    (app / "tests" / "fixtures" / "customer_release.json").parent.mkdir(
        parents=True
    )
    (app / "tests" / "fixtures" / "customer_release.json").write_text("{}\n")
    credentials = app / "chat_core" / "models" / "credentials.py"
    credentials.parent.mkdir(parents=True)
    credentials.write_text("OWNER_CREDENTIAL_MODEL = True\n")
    settings = app / "chat_core" / "config" / "settings.py"
    settings.parent.mkdir(parents=True)
    settings.write_text("OWNER_SETTINGS = True\n")

    archive = build_release_archive(app_root=app, version="2.0.0")
    with zipfile.ZipFile(archive) as zipped:
        names = set(zipped.namelist())
        archived_credentials = zipped.read(
            "chat-assistant/chat_core/models/credentials.py"
        )
        archived_settings = zipped.read("chat-assistant/chat_core/config/settings.py")

    assert "chat-assistant/run_customer.py" not in names
    assert "chat-assistant/customer-installation.json" not in names
    assert not any(name.startswith("chat-assistant/customer/") for name in names)
    assert "chat-assistant/tests/test_customer_runtime.py" not in names
    assert "chat-assistant/tests/fixtures/customer_release.json" not in names
    assert archived_credentials == credentials.read_bytes()
    assert archived_settings == settings.read_bytes()


def test_archive_preserves_established_root_tests_and_tools_layout(app: Path):
    retained = (
        "tests/test_feature.py",
        "tools/check_feature.py",
        "tools/check_feature_test.mjs",
        "deployment/chrome_extension/harness/contract_test.mjs",
        "deployment/release/sign_manifest.py",
    )
    for relative in retained:
        path = app / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("checked = True\n")
    operator_tool = app / "deployment/release/publish_release.py"
    operator_tool.write_text("operator_only = True\n")

    archive = build_release_archive(app_root=app, version="2.0.0")
    with zipfile.ZipFile(archive) as zipped:
        names = set(zipped.namelist())

    assert "chat-assistant/" in names
    assert "chat-assistant/tests/" in names
    assert "chat-assistant/tests/test_feature.py" in names
    assert "chat-assistant/tools/" in names
    assert "chat-assistant/tools/check_feature.py" in names
    for relative in retained:
        assert f"chat-assistant/{relative}" in names
    assert "chat-assistant/deployment/release/" in names
    assert "chat-assistant/deployment/release/publish_release.py" not in names
    assert all(name.startswith("chat-assistant/") for name in names)


def test_exact_byte_allowlisted_sensitive_fixture_is_archived(app: Path):
    fixture = app / "tests/test_secret_filter.py"
    fixture.parent.mkdir()
    fixture.write_text('SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n')
    allow_fixture(app, "tests/test_secret_filter.py")

    archive = build_release_archive(app_root=app, version="2.0.0")
    with zipfile.ZipFile(archive) as zipped:
        assert (
            zipped.read("chat-assistant/tests/test_secret_filter.py")
            == fixture.read_bytes()
        )


def test_any_allowlisted_fixture_change_fails_closed(app: Path):
    fixture = app / "tests/test_secret_filter.py"
    fixture.parent.mkdir()
    fixture.write_text('SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n')
    allow_fixture(app, "tests/test_secret_filter.py")
    fixture.write_text(
        'SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n'
        'OTHER = "sk-zyxwvutsrqponmlkjihgfedcba654321"\n'
    )

    with pytest.raises(ReleaseError, match="credential material"):
        build_release_archive(app_root=app, version="2.0.0")


def test_archive_writes_audited_snapshot_if_allowlisted_fixture_changes_later(
    app: Path, monkeypatch
):
    fixture = app / "tests/test_secret_filter.py"
    fixture.parent.mkdir()
    approved = b'SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n'
    fixture.write_bytes(approved)
    allow_fixture(app, "tests/test_secret_filter.py")
    collect = release_publisher_module._archive_entries

    def collect_then_mutate(root: Path):
        entries = collect(root)
        fixture.write_text('SAMPLE = "sk-zyxwvutsrqponmlkjihgfedcba654321"\n')
        return entries

    monkeypatch.setattr(
        release_publisher_module,
        "_archive_entries",
        collect_then_mutate,
    )
    archive = build_release_archive(app_root=app, version="2.0.0")
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.read("chat-assistant/tests/test_secret_filter.py") == approved


def test_allowlisted_fixture_content_at_another_path_is_refused(app: Path):
    fixture = app / "tests/test_secret_filter.py"
    copied = app / "tests/test_copied_filter.py"
    fixture.parent.mkdir()
    content = 'SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n'
    fixture.write_text(content)
    copied.write_text(content)
    allow_fixture(app, "tests/test_secret_filter.py")

    with pytest.raises(ReleaseError, match="credential material"):
        build_release_archive(app_root=app, version="2.0.0")


@pytest.mark.parametrize(
    "content",
    [
        'SAMPLE = "sk-abcdefghijklmnopqrstuvwxyz123456"\n',
        'SAMPLE = "eyJabcdefgh.eyJijklmnop.abcdefghijk"\n',
        'SAMPLE = "https://user:password@example.test/database"\n',
        'SAMPLE = "-----BEGIN PRIVATE KEY-----\\nnot-a-real-key"\n',
    ],
)
def test_non_allowlisted_test_fixtures_remain_blocked(app: Path, content: str):
    fixture = app / "tests/test_unreviewed_fixture.py"
    fixture.parent.mkdir()
    fixture.write_text(content)
    with pytest.raises(ReleaseError, match="credential material"):
        build_release_archive(app_root=app, version="2.0.0")


@pytest.mark.parametrize(
    "fixtures",
    [
        [{"path": "../outside.py", "sha256": "0" * 64, "reason": "bad path"}],
        [{"path": "chat_core/runtime.py", "sha256": "0" * 64, "reason": "runtime"}],
        [{"path": "tests/test_x.py", "sha256": "invalid", "reason": "bad hash"}],
        [
            {"path": "tests/test_x.py", "sha256": "0" * 64, "reason": "first"},
            {"path": "tests/test_x.py", "sha256": "0" * 64, "reason": "duplicate"},
        ],
    ],
)
def test_malformed_fixture_allowlist_fails_closed(app: Path, fixtures: list[dict]):
    fixture = app / "tests/test_x.py"
    fixture.parent.mkdir()
    fixture.write_text("checked = True\n")
    manifest = app / "deployment/release/sensitive_fixture_allowlist.json"
    manifest.parent.mkdir(parents=True)
    manifest.write_text(json.dumps({"version": 1, "fixtures": fixtures}))

    with pytest.raises(ReleaseError, match="allowlist"):
        build_release_archive(app_root=app, version="2.0.0")


def test_sensitive_filename_is_blocked_even_if_allowlisted(app: Path):
    fixture = app / "tests/private_key.pem"
    fixture.parent.mkdir()
    fixture.write_text("not a key")
    allow_fixture(app, "tests/private_key.pem")

    with pytest.raises(ReleaseError, match="private-key path"):
        build_release_archive(app_root=app, version="2.0.0")


@pytest.mark.parametrize(
    ("relative", "content"),
    [
        (".env", "OPENAI_API_KEY=arbitrary-local-value"),
        ("config/private-copy.pem", "-----BEGIN PRIVATE KEY-----\nnot-a-real-key"),
        (
            "chat_core/local_config.py",
            'OPENAI_API_KEY = "arbitrary-value-that-is-not-provider-shaped"\n',
        ),
    ],
)
def test_archive_refuses_unrecognized_secret_material(
    app: Path, relative: str, content: str
):
    path = app / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    with pytest.raises(ReleaseError, match="credential|private-key"):
        build_release_archive(app_root=app, version="2.0.0")
    assert not (app / "releases" / "chat-2.0.0.zip").exists()


async def test_custom_signing_key_inside_source_is_refused(app: Path, signing):
    key = app / "private-release-key.pem"
    key.write_bytes(signing[0].read_bytes())
    repo = MemoryRepository()
    with pytest.raises(ReleaseError, match="inside the release source"):
        await publish_release(
            repo,
            app_root=app,
            version="2.0.0",
            signing_key_path=key,
            public_key_hex=signing[1],
        )
    assert not (app / "releases").exists()


@pytest.mark.parametrize("published", ["2.0.0", "2.1.0"])
async def test_same_or_older_version_refused_before_upload(
    app: Path, signing, published: str
):
    repo = MemoryRepository({"version": published})
    with pytest.raises(ReleaseError, match="not newer"):
        await publish_release(
            repo,
            app_root=app,
            version="2.0.0",
            signing_key_path=signing[0],
            public_key_hex=signing[1],
        )
    assert [call for call in repo.calls if call[0] == "write"] == []


@pytest.mark.parametrize("mode", ["failed", "altered"])
async def test_archive_failure_never_promotes_manifest(app: Path, signing, mode: str):
    repo = MemoryRepository({"version": "1.0.0"})
    repo.fail_archive = mode == "failed"
    repo.alter_archive = mode == "altered"
    with pytest.raises((ReleaseError, RuntimeError)):
        await publish_release(
            repo,
            app_root=app,
            version="2.0.0",
            signing_key_path=signing[0],
            public_key_hex=signing[1],
        )
    assert not any(
        call[0] == "write" and call[1] == "latest.json" for call in repo.calls
    )
    assert json.loads(repo.objects["latest.json"].data)["version"] == "1.0.0"


async def test_success_orders_archive_before_manifest_and_round_trips(app: Path, signing):
    repo = MemoryRepository({"version": "1.9.0"})
    manifest = await publish_release(
        repo,
        app_root=app,
        version="2.0.0",
        notes="Safe release",
        signing_key_path=signing[0],
        public_key_hex=signing[1],
    )
    writes = [call for call in repo.calls if call[0] == "write"]
    assert writes == [
        ("write", "releases/chat-2.0.0.zip", "old-head", True),
        ("write", "latest.json", "head-2", False),
    ]
    archive = repo.objects["releases/chat-2.0.0.zip"].data
    assert manifest["sha256"] == hashlib.sha256(archive).hexdigest()
    assert json.loads(repo.objects["latest.json"].data) == manifest
    verify_manifest(manifest, public_key_hex=signing[1])


async def test_public_key_mismatch_refused_before_upload(app: Path, signing):
    wrong = ed25519.Ed25519PrivateKey.generate().public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw
    ).hex()
    repo = MemoryRepository()
    with pytest.raises(ReleaseError, match="signature"):
        await publish_release(
            repo,
            app_root=app,
            version="2.0.0",
            signing_key_path=signing[0],
            public_key_hex=wrong,
        )
    assert not any(call[0] == "write" for call in repo.calls)