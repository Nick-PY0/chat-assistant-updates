"""Focused regression coverage for remote owner-admin step-up."""

from __future__ import annotations

import asyncio
import threading
import time as wall_clock

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from apps.dashboard.broadcast import BroadcastPolicy
from apps.dashboard.remote_admin import (
    ADMIN_CAPABILITY_COOKIE,
    REMOTE_ADMIN_SCOPE,
    REMOTE_ADMIN_TTL_SECONDS,
    is_admin_api,
    is_admin_page,
)
from chat_core.runtime import Runtime
from chat_core.security.auth import hash_password


PASSWORD = "remote-owner-password"


@pytest.fixture
async def owner_context(settings, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    rt = Runtime(settings)
    await rt.start(voice=False, cloud=False, monitoring=False)
    app = create_app(rt)

    async def remote_app(scope, receive, send):
        if scope["type"] == "http":
            scope = dict(scope)
            scope["jarvis.broadcast"] = True
        await app(scope, receive, send)

    local_transport = httpx.ASGITransport(app=app)
    remote_transport = httpx.ASGITransport(app=remote_app)
    async with (
        httpx.AsyncClient(transport=local_transport, base_url="http://test") as local,
        httpx.AsyncClient(transport=remote_transport, base_url="https://jarvis.example") as remote,
    ):
        local.app = app
        remote.app = app
        setup = await local.post(
            "/setup", data={"password": PASSWORD, "confirm": PASSWORD}
        )
        assert setup.status_code == 303
        token = local.cookies.get(COOKIE)
        assert token
        remote.cookies.set(COOKIE, token)
        csrf = app.state.sessions.csrf_for(token)
        yield rt, app, local, remote, csrf
    await rt.stop()


async def unlock(remote, csrf: str, password: str = PASSWORD):
    return await remote.post(
        "/api/admin/unlock",
        json={"password": password},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )


def remote_wrapper(app):
    async def remote_app(scope, receive, send):
        scope = dict(scope)
        scope["jarvis.broadcast"] = True
        await app(scope, receive, send)

    return remote_app


def prebootstrap_remote_wrapper(app):
    async def remote_app(scope, receive, send):
        scope = dict(scope)
        scope["jarvis.broadcast"] = True
        # Deliberately no owner attestation: this path preserves only the
        # ordinary desktop-password/chat_session boundary.
        await app(scope, receive, send)

    return remote_app


def attested_remote_wrapper(app, *, session_id="sess_owner_1", subject="user_owner_1"):
    async def remote_app(scope, receive, send):
        scope = dict(scope)
        scope["jarvis.broadcast"] = True
        scope["jarvis.owner_attestation"] = {
            "verified_owner": True,
            "login_sid": session_id,
            "subject": subject,
            "expires_at": int(wall_clock.time()) + 3600,
        }
        await app(scope, receive, send)

    return remote_app


async def test_remote_admin_requires_stepup_and_unlock_returns_safe_status(
    owner_context,
):
    _, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    remote.cookies.delete(COOKIE)
    logged_out = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert logged_out.status_code == 401
    remote.cookies.set(COOKIE, token)

    status = await remote.get("/api/admin/status")
    assert status.status_code == 200
    assert status.json() == {
        "remote": True,
        "unlocked": False,
        "expires_at": None,
        "ttl_seconds": 0,
        "session_bound": False,
    }

    page = await remote.get("/settings")
    assert page.status_code == 303
    assert page.headers["location"] == "/admin?next=/settings"
    encoded_page = await remote.get("/%73ettings")
    assert encoded_page.status_code == 303
    assert encoded_page.headers["location"] == "/admin?next=/settings"
    trailing_page = await remote.get("/settings/")
    assert trailing_page.status_code == 303
    assert trailing_page.headers["location"] == "/admin?next=/settings"
    github_page = await remote.get("/github")
    assert github_page.status_code == 303
    assert github_page.headers["location"] == "/admin?next=/github"

    denied = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert denied.status_code == 403
    assert denied.json() == {
        "error": "admin unlock required",
        "code": "admin_unlock_required",
    }
    github_denied = await remote.post(
        "/api/github/review",
        json={},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert github_denied.status_code == 403
    assert github_denied.json()["code"] == "admin_unlock_required"

    unlocked = await unlock(remote, csrf)
    assert unlocked.status_code == 200
    body = unlocked.json()
    assert body["remote"] is True
    assert body["unlocked"] is True
    assert body["session_bound"] is True
    # The step-up grant is bounded by the ordinary login, not the historical
    # 15-minute capability lifetime.
    assert body["ttl_seconds"] > REMOTE_ADMIN_TTL_SECONDS
    assert body["expires_at"]
    assert "password" not in unlocked.text.lower()
    assert "capability" not in unlocked.text.lower()
    cookie = unlocked.headers["set-cookie"].lower()
    assert "chat_admin_capability=" in cookie
    assert "secure" in cookie and "httponly" in cookie
    assert "samesite=strict" in cookie

    assert (await remote.get("/settings")).status_code == 200
    assert (await remote.get("/github")).status_code == 200
    changed = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert changed.status_code == 200
    missing_csrf = await remote.post(
        "/api/settings",
        json={"audio_output_route": "speaker"},
        headers={"origin": "https://jarvis.example"},
    )
    assert missing_csrf.status_code == 403
    assert missing_csrf.json()["error"] == "bad csrf token"
    github_missing_csrf = await remote.post(
        "/api/github/review",
        json={},
        headers={"origin": "https://jarvis.example"},
    )
    assert github_missing_csrf.status_code == 403
    assert github_missing_csrf.json()["error"] == "bad csrf token"


async def test_local_admin_capability_cookie_can_persist_over_http(owner_context):
    """Cookie transport must not make local development look one-shot."""
    _, _, local, _, csrf = owner_context
    unlocked = await local.post(
        "/api/admin/unlock",
        json={"password": PASSWORD},
        headers={"x-csrf": csrf, "origin": "http://test"},
    )
    assert unlocked.status_code == 200
    set_cookie = unlocked.headers["set-cookie"].lower()
    assert "chat_admin_capability=" in set_cookie
    assert "secure" not in {
        part.strip().split("=", 1)[0]
        for part in set_cookie.split(";")
        if part.strip()
    }
    capability = local.cookies.get(ADMIN_CAPABILITY_COOKIE)
    assert capability
    assert (await local.get("/api/admin/status")).status_code == 200


async def test_prebootstrap_known_password_preserves_session_without_clerk_role(
    owner_context,
):
    _, app, local, _, _ = owner_context
    token = local.cookies.get(COOKIE)
    assert token
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=prebootstrap_remote_wrapper(app)),
        base_url="https://jarvis.example",
        cookies={COOKIE: token},
    ) as remote:
        state = await remote.get("/api/state")
        assert state.status_code == 200
        status = await remote.get("/api/admin/status")
        assert status.json()["unlocked"] is False
        assert remote.cookies.get(ADMIN_CAPABILITY_COOKIE) is None
        # The known desktop password created this ordinary chat_session, but
        # pre-bootstrap never creates an owner SSO/admin capability.
        assert (await remote.get("/settings")).status_code == 303


async def test_attested_owner_gets_sso_without_password_and_lock_needs_explicit_reunlock(
    owner_context,
):
    _, app, local, _, _ = owner_context
    attested = attested_remote_wrapper(app)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=attested),
        base_url="https://jarvis.example",
    ) as remote:
        dashboard = await remote.get("/")
        assert dashboard.status_code == 200
        sso_token = remote.cookies.get(COOKIE)
        capability = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
        assert sso_token and capability
        assert (await remote.get("/settings")).status_code == 200
        assert (await remote.get("/api/admin/status")).json()["unlocked"] is True

        # The attested SSO cookie is not a local/LAN password session.
        local.cookies.set(COOKIE, sso_token)
        assert (await local.get("/")).status_code == 303
        local.cookies.delete(COOKIE)

        csrf = app.state.sessions.csrf_for(sso_token)
        locked = await remote.post(
            "/api/admin/lock",
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
        assert locked.status_code == 200
        assert (await remote.get("/api/admin/status")).json()["unlocked"] is False
        remote.cookies.set(ADMIN_CAPABILITY_COOKIE, capability)
        replay = await remote.post(
            "/api/settings",
            json={"audio_output_route": "phone"},
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
        assert replay.status_code == 403
        remote.cookies.delete(ADMIN_CAPABILITY_COOKIE)
        assert (await remote.get("/settings")).headers["location"] == (
            "/admin?next=/settings"
        )

        # A fresh browser tab may have no desktop cookie at all. The owner
        # attestation can rematerialize viewing SSO, but not admin access.
        remote.cookies.delete(COOKIE)
        remote.cookies.delete(ADMIN_CAPABILITY_COOKIE)
        assert (await remote.get("/")).status_code == 200
        assert (await remote.get("/api/admin/status")).json()["unlocked"] is False
        sso_token = remote.cookies.get(COOKIE)
        assert sso_token
        csrf = app.state.sessions.csrf_for(sso_token)

        # Lock is not undone by a later attested request. Explicit unlock is
        # passwordless only because this request carries the verified SSO.
        still_locked = await remote.get("/")
        assert still_locked.status_code == 200
        relocked = await remote.get("/api/admin/status")
        assert relocked.json()["unlocked"] is False
        unlocked = await remote.post(
            "/api/admin/unlock",
            json={},
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
        assert unlocked.status_code == 200
        assert unlocked.json()["unlocked"] is True

        # Logout fences the Clerk login itself; a subsequent request with the
        # same attestation cannot silently mint a replacement SSO cookie.
        logged_out = await remote.post(
            "/logout",
            data={"_csrf": csrf},
            headers={"origin": "https://jarvis.example"},
        )
        assert logged_out.status_code == 303
        assert (await remote.get("/")).status_code == 401


async def test_attested_owner_account_switch_fences_old_sso_identity(owner_context):
    _, app, _, _, _ = owner_context
    first = attested_remote_wrapper(app, session_id="sess_owner_1", subject="user_1")
    second = attested_remote_wrapper(app, session_id="sess_owner_2", subject="user_2")
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=first),
        base_url="https://jarvis.example",
    ) as owner_one, httpx.AsyncClient(
        transport=httpx.ASGITransport(app=second),
        base_url="https://jarvis.example",
    ) as owner_two:
        assert (await owner_one.get("/")).status_code == 200
        old_token = owner_one.cookies.get(COOKIE)
        old_capability = owner_one.cookies.get(ADMIN_CAPABILITY_COOKIE)
        assert old_token and old_capability
        owner_two.cookies.set(COOKIE, old_token)
        owner_two.cookies.set(ADMIN_CAPABILITY_COOKIE, old_capability)
        switched = await owner_two.get("/api/admin/status")
        assert switched.status_code == 200
        assert switched.json()["unlocked"] is True
        new_token = next(
            cookie.value
            for cookie in owner_two.cookies.jar
            if cookie.name == COOKIE and cookie.value != old_token
        )
        assert new_token and new_token != old_token

        # The old Clerk identity cannot replay its desktop SSO session after
        # the browser switched accounts.
        owner_one.cookies.set(COOKIE, old_token)
        assert (await owner_one.get("/")).status_code == 401


@pytest.mark.parametrize("remember", ("false", "true"))
async def test_remote_admin_follows_actual_login_deadline_after_late_unlock(
    owner_context, monkeypatch, remember
):
    """The grant follows both ordinary and Remember-me login deadlines."""
    _, app, local, remote, old_csrf = owner_context
    old_token = local.cookies.get(COOKIE)
    assert old_token
    logged_out = await local.post("/logout", data={"_csrf": old_csrf})
    assert logged_out.status_code == 303
    remote.cookies.delete(COOKIE)

    login = await local.post(
        "/login",
        data={"password": PASSWORD, "remember": remember},
    )
    assert login.status_code == 303
    token = local.cookies.get(COOKIE)
    assert token
    remote.cookies.set(COOKIE, token)
    csrf = app.state.sessions.csrf_for(token)

    _, issued_at = app.state.sessions._serializer.loads(
        token, return_timestamp=True
    )
    session_ttl = (
        app.state.sessions.remembered_max_age
        if remember == "true"
        else app.state.sessions.max_age
    )
    session_expiry = int(issued_at.timestamp()) + session_ttl

    # Unlock after the removed 15-minute admin lifetime has elapsed.
    late_now = int(issued_at.timestamp()) + REMOTE_ADMIN_TTL_SECONDS + 5
    monkeypatch.setattr(dashboard_module.time, "time", lambda: late_now)
    unlocked = await unlock(remote, csrf)
    assert unlocked.status_code == 200
    body = unlocked.json()
    assert body["session_bound"] is True
    assert body["expires_at"]
    assert body["ttl_seconds"] == session_expiry - late_now

    # The ordinary login boundary, rather than the unlock time, is decisive.
    monkeypatch.setattr(
        dashboard_module.time, "time", lambda: session_expiry + 1
    )
    expired = await remote.get("/api/admin/status")
    assert expired.status_code == 401


async def test_wrong_password_rate_limit_and_csrf(owner_context):
    _, _, _, remote, csrf = owner_context
    wrong = await unlock(remote, csrf, "wrong-password")
    assert wrong.status_code == 403
    assert "wrong-password" not in wrong.text
    assert "admin_capability" not in wrong.text

    # The limiter is deliberately independent from the normal login limiter.
    for _ in range(4):
        assert (await unlock(remote, csrf, "wrong-password")).status_code == 403
    assert (await unlock(remote, csrf, "wrong-password")).status_code == 429

    no_csrf = await remote.post(
        "/api/admin/unlock",
        json={"password": PASSWORD},
        headers={"origin": "https://jarvis.example"},
    )
    assert no_csrf.status_code == 403
    assert no_csrf.json()["error"] == "bad csrf token"


async def test_lock_expiry_logout_and_password_change_revoke_access(owner_context, monkeypatch):
    _, app, local, remote, csrf = owner_context
    assert (await unlock(remote, csrf)).status_code == 200
    captured_capability = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
    assert captured_capability

    locked = await remote.post(
        "/api/admin/lock",
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert locked.status_code == 200
    assert locked.json()["unlocked"] is False
    assert locked.json()["session_bound"] is False
    assert "Max-Age=0" in locked.headers["set-cookie"]
    assert (await remote.get("/api/admin/status")).json()["unlocked"] is False

    # Manual Lock revokes the grant on the server.  Replaying the captured
    # bearer after the browser cookie was deleted must still be denied.
    remote.cookies.set(ADMIN_CAPABILITY_COOKIE, captured_capability)
    replay = await remote.post(
        "/api/settings",
        json={"audio_output_route": "phone"},
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert replay.status_code == 403

    remote.cookies.delete(ADMIN_CAPABILITY_COOKIE)
    assert (await unlock(remote, csrf)).status_code == 200
    future = wall_clock.time() + REMOTE_ADMIN_TTL_SECONDS + 2
    monkeypatch.setattr(dashboard_module.time, "time", lambda: future)
    # A grant remains usable after the removed 15-minute deadline while the
    # ordinary login itself is still alive.
    still_unlocked = await remote.get("/api/admin/status")
    assert still_unlocked.status_code == 200
    assert still_unlocked.json()["unlocked"] is True
    monkeypatch.undo()

    assert (await unlock(remote, csrf)).status_code == 200
    logged_out = await local.post("/logout", data={"_csrf": csrf})
    assert logged_out.status_code == 303
    assert (await remote.get("/api/admin/status")).status_code == 401

    # A password generation change invalidates every ordinary session and its
    # bound capability, not only the browser that made the change.
    setup = await local.post(
        "/login", data={"password": PASSWORD}, headers={"origin": "http://test"}
    )
    assert setup.status_code == 303
    new_token = local.cookies.get(COOKIE)
    new_csrf = app.state.sessions.csrf_for(new_token)
    remote.cookies.set(COOKIE, new_token)
    assert (await unlock(remote, new_csrf)).status_code == 200
    changed = await remote.post(
        "/api/password",
        json={"current": PASSWORD, "new": "replacement-owner-password"},
        headers={"x-csrf": new_csrf, "origin": "https://jarvis.example"},
    )
    assert changed.status_code == 200
    assert (await remote.get("/api/admin/status")).status_code == 401


async def test_lock_replay_is_denied_after_dashboard_recreation(owner_context):
    rt, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    assert (await unlock(remote, csrf)).status_code == 200
    captured = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
    assert captured

    locked = await remote.post(
        "/api/admin/lock",
        headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
    )
    assert locked.status_code == 200

    restarted = create_app(rt)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=remote_wrapper(restarted)),
        base_url="https://jarvis.example",
        cookies={
            COOKIE: token,
            ADMIN_CAPABILITY_COOKIE: captured,
        },
    ) as after_restart:
        status = await after_restart.get("/api/admin/status")
        assert status.status_code == 200
        assert status.json()["unlocked"] is False
        assert status.json()["session_bound"] is False
        replay = await after_restart.post(
            "/api/settings",
            json={"audio_output_route": "phone"},
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
        assert replay.status_code == 403
        # Lock did not revoke ordinary viewing access.
        assert (await after_restart.get("/api/state")).status_code == 200


async def test_cross_instance_second_lock_revokes_between_lock_grant(
    owner_context,
):
    """A stale manager must not merge away a later per-session lock epoch."""
    rt, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    app_a = create_app(rt)
    app_b = create_app(rt)
    async with (
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_a)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_a,
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_b)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_b,
    ):
        # Cold-start both managers before either one mutates the persisted
        # admin epoch.
        assert (await client_a.get("/api/admin/status")).status_code == 200
        assert (await client_b.get("/api/admin/status")).status_code == 200

        first_unlock = await unlock(client_a, csrf)
        assert first_unlock.status_code == 200
        assert (
            await client_a.post(
                "/api/admin/lock",
                headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
            )
        ).status_code == 200

        # This grant is issued between the two locks by the other cold-start
        # manager.  A stale epoch merge must not make it survive lock #2.
        second_unlock = await unlock(client_b, csrf)
        assert second_unlock.status_code == 200
        between_locks = client_b.cookies.get(ADMIN_CAPABILITY_COOKIE)
        assert between_locks
        assert (
            await client_b.get("/api/admin/status")
        ).json()["session_bound"] is True

        assert (
            await client_a.post(
                "/api/admin/lock",
                headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
            )
        ).status_code == 200
        client_b.cookies.set(ADMIN_CAPABILITY_COOKIE, between_locks)
        final_status = await client_b.get("/api/admin/status")
        assert final_status.status_code == 200
        assert final_status.json()["unlocked"] is False
        assert final_status.json()["session_bound"] is False


async def test_interleaved_lock_persistence_allocates_a_fresh_epoch(
    owner_context,
):
    """A paused stale lock cannot preserve an intervening capability."""
    rt, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    app_a = create_app(rt)
    app_b = create_app(rt)
    async with (
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_a)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_a,
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_b)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_b,
    ):
        assert (await client_a.get("/api/admin/status")).status_code == 200
        assert (await client_b.get("/api/admin/status")).status_code == 200
        manager_b = app_b.state.sessions
        paused = asyncio.Event()
        resume = asyncio.Event()
        original_mutation = getattr(manager_b, "_mutate_security_state", None)
        if original_mutation is not None:
            async def delayed_mutation(snapshot, mutation):
                if mutation.get("kind") == "revoke_admin_grant":
                    sid = mutation["sid"]
                    # This is the stale local N+1 computed before B's durable
                    # transaction.  Keep B paused while A commits N+1.
                    assert snapshot["admin_generations"][sid]["generation"] == 1
                    paused.set()
                    await resume.wait()
                return await original_mutation(snapshot, mutation)

            manager_b._mutate_security_state = delayed_mutation
        else:
            # Compatibility branch used to prove this regression against the
            # pre-atomic implementation: its max(snapshot) callback loses the
            # second increment after the pause.
            original_persist = manager_b._persist_security_state

            async def delayed_persist(snapshot):
                loaded = manager_b._load(token)
                assert loaded
                sid = loaded[0]["sid"]
                assert snapshot["admin_generations"][sid]["generation"] == 1
                paused.set()
                await resume.wait()
                await original_persist(snapshot)

            manager_b._persist_security_state = delayed_persist
        pending_lock = asyncio.create_task(
            client_b.post(
                "/api/admin/lock",
                headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
            )
        )
        await asyncio.wait_for(paused.wait(), timeout=2)

        # A commits epoch N+1 while B is holding the stale N+1 snapshot.
        first_lock = await client_a.post(
            "/api/admin/lock",
            headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
        )
        assert first_lock.status_code == 200
        between_locks = await unlock(client_a, csrf)
        assert between_locks.status_code == 200
        assert between_locks.json()["session_bound"] is True

        resume.set()
        second_lock = await asyncio.wait_for(pending_lock, timeout=2)
        assert second_lock.status_code == 200
        denied = await client_a.get("/api/admin/status")
        assert denied.status_code == 200
        assert denied.json()["unlocked"] is False


async def test_interleaved_invalidation_rejects_login_between_generations(
    owner_context,
):
    """A login issued between overlapping invalidations is not resurrected."""
    rt, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    app_a = create_app(rt)
    app_b = create_app(rt)
    async with (
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_a)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_a,
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_b)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as client_b,
    ):
        assert (await client_a.get("/api/admin/status")).status_code == 200
        assert (await client_b.get("/api/admin/status")).status_code == 200
        manager_b = app_b.state.sessions
        paused = asyncio.Event()
        resume = asyncio.Event()
        original_mutation = getattr(manager_b, "_mutate_security_state", None)
        if original_mutation is not None:
            async def delayed_mutation(snapshot, mutation):
                if mutation.get("kind") == "invalidate_all":
                    assert snapshot["generation"] == 1
                    paused.set()
                    await resume.wait()
                return await original_mutation(snapshot, mutation)

            manager_b._mutate_security_state = delayed_mutation
        else:
            original_persist = manager_b._persist_security_state

            async def delayed_persist(snapshot):
                assert snapshot["generation"] == 1
                paused.set()
                await resume.wait()
                await original_persist(snapshot)

            manager_b._persist_security_state = delayed_persist
        pending_invalidation = asyncio.create_task(
            manager_b.invalidate_all()
        )
        await asyncio.wait_for(paused.wait(), timeout=2)

        # A commits generation N+1, then a login legitimately issued before
        # B resumes receives generation N+1.
        await app_a.state.sessions.invalidate_all()
        client_a.cookies.delete(COOKIE)
        login = await client_a.post(
            "/login",
            data={"password": PASSWORD, "remember": "false"},
        )
        assert login.status_code == 303
        between_generations = client_a.cookies.get(COOKIE)
        assert between_generations

        resume.set()
        await asyncio.wait_for(pending_invalidation, timeout=2)
        client_b.cookies.set(COOKIE, between_generations)
        assert (await client_b.get("/api/state")).status_code == 401


async def test_failed_admin_persist_floor_is_honored_by_retry(owner_context):
    rt, app, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    manager = app.state.sessions
    assert (await unlock(remote, csrf)).status_code == 200
    original_mutation = manager._mutate_security_state
    assert original_mutation is not None

    async def fail_once(snapshot, mutation):
        raise RuntimeError("injected auth persistence failure")

    manager._mutate_security_state = fail_once
    with pytest.raises(RuntimeError, match="injected"):
        await manager.revoke_admin_grant(token)

    # The local fail-closed floor permits a fresh unlock, but that grant must
    # not become durable at a lower epoch when the lock is retried.
    unlocked_during_failure = await unlock(remote, csrf)
    assert unlocked_during_failure.status_code == 200
    failed_capability = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
    assert failed_capability

    manager._mutate_security_state = original_mutation
    assert await manager.revoke_admin_grant(token)
    assert manager.session_capability_info(
        token, failed_capability, REMOTE_ADMIN_SCOPE
    ) is None

    restarted = create_app(rt)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=remote_wrapper(restarted)),
        base_url="https://jarvis.example",
        cookies={
            COOKIE: token,
            ADMIN_CAPABILITY_COOKIE: failed_capability,
        },
    ) as after_restart:
        assert (await after_restart.get("/api/admin/status")).json()[
            "unlocked"
        ] is False


async def test_failed_invalidation_floor_rejects_login_after_retry(owner_context):
    rt, app, local, _, _ = owner_context
    manager = app.state.sessions
    original_mutation = manager._mutate_security_state
    assert original_mutation is not None

    async def fail_once(snapshot, mutation):
        raise RuntimeError("injected auth persistence failure")

    manager._mutate_security_state = fail_once
    with pytest.raises(RuntimeError, match="injected"):
        await manager.invalidate_all()

    local.cookies.delete(COOKIE)
    login = await local.post(
        "/login",
        data={"password": PASSWORD, "remember": "false"},
    )
    assert login.status_code == 303
    between = local.cookies.get(COOKIE)
    assert between

    manager._mutate_security_state = original_mutation
    await manager.invalidate_all()

    restarted = create_app(rt)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=restarted),
        base_url="http://test",
        cookies={COOKIE: between},
    ) as after_retry:
        assert (await after_retry.get("/api/state")).status_code == 401


async def test_password_change_transaction_blocks_paused_old_password_login(
    owner_context, monkeypatch
):
    """The verifier and password-generation transition share one DB lock."""
    rt, _, _, remote, csrf = owner_context
    token = remote.cookies.get(COOKIE)
    app_a = create_app(rt)
    app_b = create_app(rt)
    async with (
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_a)),
            base_url="https://jarvis.example",
            cookies={COOKIE: token},
        ) as changer,
        httpx.AsyncClient(
            transport=httpx.ASGITransport(app=remote_wrapper(app_b)),
            base_url="https://jarvis.example",
        ) as login_client,
    ):
        assert (await changer.get("/api/admin/status")).status_code == 200
        assert (await login_client.get("/api/admin/status")).status_code == 401
        assert (await unlock(changer, csrf)).status_code == 200

        verified = threading.Event()
        release = threading.Event()
        original_verify = dashboard_module.verify_password

        def paused_verify(stored_hash, password):
            if password == PASSWORD and not verified.is_set():
                verified.set()
                assert release.wait(timeout=5)
            return original_verify(stored_hash, password)

        monkeypatch.setattr(dashboard_module, "verify_password", paused_verify)
        login_task = asyncio.create_task(
            login_client.post(
                "/login",
                data={"password": PASSWORD, "remember": "false"},
            )
        )
        assert await asyncio.to_thread(verified.wait, 2)
        change_task = asyncio.create_task(
            changer.post(
                "/api/password",
                json={
                    "current": PASSWORD,
                    "new": "replacement-owner-password",
                },
                headers={"x-csrf": csrf, "origin": "https://jarvis.example"},
            )
        )
        await asyncio.sleep(0.05)
        assert not change_task.done()
        release.set()
        login_response, change_response = await asyncio.gather(
            login_task, change_task
        )
        assert login_response.status_code == 303
        assert change_response.status_code == 200
        between_change = login_client.cookies.get(COOKIE)
        assert between_change

    restarted = create_app(rt)
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=restarted),
        base_url="http://test",
        cookies={COOKIE: between_change},
    ) as after_change:
        assert (await after_change.get("/api/state")).status_code == 401
        old_login = await after_change.post(
            "/login",
            data={"password": PASSWORD, "remember": "false"},
        )
        assert old_login.status_code == 401


async def test_capability_is_bound_to_the_ordinary_session(owner_context):
    _, app, _, remote, csrf = owner_context
    assert (await unlock(remote, csrf)).status_code == 200
    cap = remote.cookies.get(ADMIN_CAPABILITY_COOKIE)
    token_b = app.state.sessions.issue()
    csrf_b = app.state.sessions.csrf_for(token_b)

    async def remote_b(scope, receive, send):
        scope = dict(scope)
        scope["jarvis.broadcast"] = True
        await app(scope, receive, send)

    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=remote_b),
        base_url="https://jarvis.example",
        cookies={COOKIE: token_b, ADMIN_CAPABILITY_COOKIE: cap},
    ) as other:
        other_status = await other.get("/api/admin/status")
        assert other_status.json()["unlocked"] is False
        assert other_status.json()["session_bound"] is False
        denied = await other.post(
            "/api/settings",
            json={"audio_output_route": "phone"},
            headers={
                "x-csrf": csrf_b,
                "origin": "https://jarvis.example",
            },
        )
        assert denied.status_code == 403
        assert denied.json()["code"] == "admin_unlock_required"


def test_remote_admin_policy_covers_settings_ajax_and_exact_crud_paths():
    policy = BroadcastPolicy()
    for method, path in (
        ("GET", "/api/audio/devices"),
        ("GET", "/api/location/search"),
        ("GET", "/api/state"),
        ("GET", "/api/cloud-schedule/status"),
        ("POST", "/api/cloud-schedule"),
        ("POST", "/api/cloud-schedule/launch"),
        ("GET", "/api/companion/status"),
        ("POST", "/api/companion/pair"),
        ("POST", "/api/companion/rotate"),
        ("POST", "/api/companion/revoke"),
        ("GET", "/api/broadcast/status"),
        ("POST", "/api/broadcast"),
        ("POST", "/api/settings"),
        ("POST", "/api/password"),
        ("GET", "/api/startup/status"),
        ("POST", "/api/startup/enable"),
        ("POST", "/api/startup/disable"),
        ("GET", "/api/update/status"),
        ("POST", "/api/update/check"),
        ("POST", "/api/update/install"),
        ("POST", "/api/restart"),
        ("GET", "/api/providers/summary"),
        ("POST", "/api/credentials"),
        ("POST", "/api/credentials/c_123/action"),
        ("GET", "/api/spotify/status"),
        ("POST", "/api/spotify/oauth/start"),
        ("POST", "/api/spotify/disconnect"),
        ("GET", "/api/calendar/status"),
        ("POST", "/api/calendar/oauth/start"),
        ("POST", "/api/calendar/disconnect"),
        ("POST", "/api/calendar/sync"),
        ("POST", "/api/calendar/calendars"),
        ("PUT", "/api/experts"),
        ("PATCH", "/api/experts"),
        ("POST", "/api/github/review"),
        ("POST", "/api/github/publish"),
    ):
        assert policy.allows_http(method, path), (method, path)
    assert not policy.allows_http("PUT", "/api/settings/alias")
    assert not policy.allows_http("POST", "/api/github/review/alias")
    assert is_admin_page("/settings/")
    assert is_admin_page("/%73ettings")
    assert is_admin_api("POST", "/api/settings/")
    assert is_admin_api("POST", "/api/%73ettings")
    assert not is_admin_api("POST", "/api/settings/../state")
    assert not is_admin_api("GET", "/api/settings")