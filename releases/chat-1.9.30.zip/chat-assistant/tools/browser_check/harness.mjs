// Real-execution check of the Chat dashboard: loads every page in jsdom with
// scripts ENABLED (same ordering rules as a browser), lets the page's own
// fetches run against the live server, then inspects the rendered DOM for
// failures like "api is not defined".
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = process.env.CHAT_BROWSER_CHECK_BASE || "http://127.0.0.1:8756";
let cookie = "";
const maliciousLog = {
  ts: '<img src=x onerror="window.__logXss = true">',
  level: '<svg onload="window.__logXss = true">',
  component: '<script>window.__logXss = true</script>',
  message: '<a href="javascript:window.__logXss = true">unsafe-looking log message</a>',
};

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}

async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// ---- wait for server ----
let up = false;
for (let i = 0; i < 30; i++) {
  try { await fetch(BASE + "/setup"); up = true; break; } catch { await new Promise((r) => setTimeout(r, 500)); }
}
if (!up) { console.log("FATAL: server not reachable"); process.exit(2); }

// ---- first-run setup ----
const form = new URLSearchParams();
form.set("password", "Testpass123");
form.set("confirm", "Testpass123");
let r = await req("/setup", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: form.toString() });
console.log("setup POST:", r.status, "(303 = ok)");

// ---- per-page browser-like test ----
const pages = ["/", "/credentials", "/usage", "/logs", "/timers", "/reminders", "/routines", "/calendar", "/memory", "/devices", "/providers", "/settings", "/voice-controller"];
const mustContain = {
  "/credentials": "No Gemini keys yet",
  "/usage": "Nothing yet",
};
let failures = 0;

for (const path of pages) {
  const resp = await req(path);
  if (resp.status !== 200) { console.log(`FAIL ${path}: HTTP ${resp.status}`); failures++; continue; }
  const html = await resp.text();

  // static ordering guarantees, independent of jsdom behavior
  const headScript = html.indexOf('src="/static/app.js');
  const firstInline = html.indexOf("<script>");
  if (headScript === -1) { console.log(`FAIL ${path}: app.js tag missing`); failures++; continue; }
  if (firstInline !== -1 && headScript > firstInline) { console.log(`FAIL ${path}: app.js loads AFTER inline scripts`); failures++; continue; }
  if (!/app\.js\?v=\d+\.\d+\.\d+/.test(html)) { console.log(`WARN ${path}: cache-buster version missing on app.js tag`); }

  const errors = [];
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
  vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

  const dom = new JSDOM(html, {
    url: BASE + path,
    runScripts: "dangerously",
    resources: "usable",
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      window.alert = () => {};
      window.fetch = (p, o = {}) => {
        const url = new URL(p, BASE + path);
        if (path === "/logs" && url.pathname === "/api/logs") {
          return Promise.resolve(new Response(JSON.stringify({
            logs: [
              maliciousLog,
              { ts: "now", level: "ERROR", component: "harness", message: "visual class check" },
            ],
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/calendar" && url.pathname === "/api/calendar/events") {
          return Promise.resolve(new Response(JSON.stringify({
            events: [{
              id: "harness-event",
              calendar_id: "primary",
              calendar_name: "Main",
              title: '<img src=x onerror="window.__calendarXss=true"> Harness planning',
              start_at: "2030-01-07T09:00:00+00:00",
              end_at: "2030-01-07T10:00:00+00:00",
              all_day: false,
              timezone: "UTC",
              location: "<script>unsafe-looking room</script>",
              html_link: "https://calendar.google.com/calendar/event?eid=harness",
              recurring_event_id: null,
              status: "confirmed",
            }],
            timezone: "UTC",
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/calendar" && url.pathname === "/api/calendar/status") {
          return Promise.resolve(new Response(JSON.stringify({
            account: { configured: true, connected: true, needs_reauthorization: false },
            calendars: [],
            preferences: {
              timezone: "America/Los_Angeles",
              meeting_alert_enabled: true,
              meeting_lead_minutes: 15,
              briefing_enabled: true,
              briefing_time: "08:30",
              weekdays: [0, 1, 2, 3, 4],
              sections: ["calendar", "weather"],
            },
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/providers" && url.pathname === "/api/calendar/status") {
          return Promise.resolve(new Response(JSON.stringify({
            account: {
              configured: true,
              connected: true,
              needs_reauthorization: false,
              status: "connected",
              email: "calendar@example.test",
              last_sync_at: "2030-01-07T09:00:00+00:00",
            },
            calendars: [{
              id: "primary",
              name: "Harness Primary Calendar",
              selected: true,
              primary: true,
              write_allowed: true,
              default_write: true,
            }],
            preferences: {},
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/routines" && url.pathname === "/api/routines/catalog") {
          return Promise.resolve(new Response(JSON.stringify({
            actions: [{
              type: "wait", label: "Wait", description: "Wait briefly",
              fields: [{ name: "seconds", label: "Seconds", type: "number", required: true, min: 0, max: 300 }],
            }],
            default_timezone: "America/Los_Angeles",
            weekdays: [{ value: 0, label: "Mon" }, { value: 1, label: "Tue" }],
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/routines" && url.pathname === "/api/routines/templates") {
          return Promise.resolve(new Response(JSON.stringify({
            templates: [{
              id: "good_morning", name: "Good morning",
              description: "A safe starter",
              setup: ["Choose calendars on the Calendar page."],
            }],
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/routines" && url.pathname === "/api/routines") {
          return Promise.resolve(new Response(JSON.stringify({
            routines: [{
              id: "rt-harness",
              name: '<img src=x onerror="window.__routineXss=true"> Harness Scene',
              description: '<script>window.__routineXss=true</script> Safe-looking details',
              aliases: [],
              enabled: true,
              template_draft: false,
              trigger: null,
              steps: [{ type: "wait", args: { seconds: 1 }, timeout_seconds: 30, continue_on_error: false }],
            }],
            recent_runs: [{
              id: "rr-harness", routine_id: "rt-harness", source: "manual",
              status: "completed", duration_ms: 12, started_at: "2030-01-07T09:00:00+00:00",
              steps: [{ step_index: 0, action_type: "wait", status: "success", duration_ms: 12, summary: "completed" }],
            }],
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        if (path === "/routines" && url.pathname === "/api/routines/rt-harness/run") {
          return Promise.resolve(new Response(JSON.stringify({
            run: {
              id: "rr-card", routine_id: "rt-harness", source: "dashboard",
              status: "partial", summary: "Routine completed with some failures.",
              duration_ms: 15, started_at: "2030-01-07T09:00:00+00:00",
              steps: [{ step_index: 0, action_type: "wait", status: "failure", duration_ms: 15, summary: "action failed" }],
            },
          }), { status: 200, headers: { "content-type": "application/json" } }));
        }
        const { signal, ...rest } = o; // node fetch rejects jsdom's AbortSignal
        rest.headers = { ...(rest.headers || {}), cookie };
        return fetch(url.href, rest);
      };
      // no EventSource stub on purpose: app.js must survive its absence
    },
  });

  await new Promise((res) => {
    let done = false;
    const finish = () => { if (!done) { done = true; setTimeout(res, 900); } }; // settle fetches after load
    dom.window.addEventListener("load", finish);
    setTimeout(finish, 3000); // in case load never fires
  });

  const text = dom.serialize();
  const bad = [];
  if (/is not defined/i.test(text)) bad.push('page shows "... is not defined"');
  if (/Could not reach Chat/i.test(text)) bad.push("page shows could-not-reach error");
  if (mustContain[path] && !text.includes(mustContain[path])) bad.push(`missing expected content: "${mustContain[path]}"`);
  if (path === "/logs") {
    const box = dom.window.document.getElementById("log-box");
    const expectedText = Object.values(maliciousLog);
    if (!expectedText.every((value) => box.textContent.includes(value))) {
      bad.push("HTML-like log fields were not rendered as text");
    }
    if (box.querySelector("img, svg, script, a") || dom.window.__logXss) {
      bad.push("HTML-like log content created active DOM");
    }
    if (!box.querySelector(".log-line > span.ERROR")) {
      bad.push("ERROR log visual class was not preserved");
    }
  }
  if (path === "/calendar") {
    const eventList = dom.window.document.getElementById("cal-events-list");
    if (!eventList.textContent.includes("Harness planning")) {
      bad.push("calendar event data did not render");
    }
    if (eventList.querySelector("img, script") || dom.window.__calendarXss) {
      bad.push("HTML-like calendar content created active DOM");
    }
    if (dom.window.document.getElementById("pref-timezone").value !== "America/Los_Angeles") {
      bad.push("calendar preferences did not render");
    }
    if (!dom.window.document.querySelector('#pref-weekdays input[value="0"]').checked) {
      bad.push("Python-style Monday weekday value did not render as checked");
    }
  }
  if (path === "/providers") {
    const checkbox = dom.window.document.querySelector(".calendar-option .cal-read-cb");
    const calendarName = dom.window.document.querySelector(".calendar-option-name");
    const saveButton = dom.window.document.getElementById("cal-save-cals");
    if (!checkbox || checkbox.style.width !== "" || dom.window.getComputedStyle(checkbox).width !== "16px") {
      bad.push("calendar checkbox was not constrained to 16px");
    }
    if (!calendarName || !calendarName.textContent.includes("Harness Primary Calendar")) {
      bad.push("calendar name did not render beside its checkbox");
    }
    if (!saveButton || !saveButton.classList.contains("calendar-save")
        || saveButton.parentElement?.classList.contains("row")) {
      bad.push("calendar save button still uses the collapsing generic row layout");
    }
  }
  if (path === "/routines") {
    const grid = dom.window.document.getElementById("rt-grid");
    if (!grid.textContent.includes("Harness Scene")) {
      bad.push("routine data did not render");
    }
    if (grid.querySelector("img, script") || dom.window.__routineXss) {
      bad.push("HTML-like routine content created active DOM");
    }
    if (!dom.window.document.getElementById("rt-tpl-grid").textContent.includes("Choose calendars")) {
      bad.push("routine template guidance did not render");
    }
    grid.querySelector(".btn-run")?.click();
    await new Promise((resolve) => setTimeout(resolve, 50));
    const runStatus = dom.window.document.getElementById("rt-list-status");
    if (!runStatus.textContent.includes("completed with some failures")) {
      bad.push("routine card run outcome was not shown immediately");
    }
  }
  // The theme toggle shows its visible label through CSS content, which screen
  // readers cannot rely on -- so the button must carry a real name in the DOM.
  const themeBtn = dom.window.document.getElementById("theme-btn");
  if (themeBtn && !(themeBtn.getAttribute("aria-label") || "").trim() && !themeBtn.textContent.trim()) {
    bad.push("theme toggle has no accessible name (needs aria-label or text)");
  }
  for (const e of errors) bad.push(e);

  if (bad.length) { console.log(`FAIL ${path}:\n   - ` + bad.join("\n   - ")); failures++; }
  else console.log(`PASS ${path}`);
  dom.window.close();
}

// ---- end-to-end: add a Gemini key exactly like the page's Add button ----
r = await req("/credentials");
const meta = (await r.text()).match(/name="csrf" content="([^"]+)"/);
const csrf = meta ? meta[1] : "";
r = await req("/api/credentials", {
  method: "POST",
  headers: { "content-type": "application/json", "x-csrf": csrf },
  body: JSON.stringify({ provider: "gemini", secret: "AIzaSyFakeKeyForHarness0000000000000000", project_label: "harness" }),
});
const bodyText = await r.text();
console.log("add-key POST:", r.status, bodyText.slice(0, 140));
if (r.status === 200) {
  const list = await (await req("/api/credentials")).json();
  console.log("keys now stored:", list.projects.length);
} else if (r.status === 400 && bodyText.includes("rejected")) {
  console.log("(Google reachable from sandbox and rejected the fake key -- endpoint + csrf flow work)");
} else {
  console.log("UNEXPECTED add-key result"); failures++;
}

console.log(failures === 0 ? "ALL PAGE CHECKS PASSED" : `${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
