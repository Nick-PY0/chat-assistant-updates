"""Dependency synchronization used while bootstrapping source updates.

This module intentionally imports only the standard library.  In particular,
it must remain importable before any of Chat's third-party dependencies are
available.
"""

from __future__ import annotations

import importlib
import os
import subprocess
import sys
from pathlib import Path


DEPENDENCY_SYNC_TIMEOUT_SECONDS = 300


class DependencySyncError(RuntimeError):
    """The active Python environment could not be synchronized."""


def sync_requirements(requirements: Path) -> None:
    """Install *requirements* into the environment running this launcher."""
    requirements = Path(requirements).resolve()
    if not requirements.is_file():
        raise DependencySyncError("the update has no requirements.txt")

    env = os.environ.copy()
    env["PIP_NO_INPUT"] = "1"
    command = [
        sys.executable,
        "-m",
        "pip",
        "install",
        "--disable-pip-version-check",
        "--no-input",
        "--requirement",
        str(requirements),
    ]
    try:
        completed = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            timeout=DEPENDENCY_SYNC_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise DependencySyncError("dependency installation timed out") from exc
    except OSError as exc:
        raise DependencySyncError("could not start pip with the active Python") from exc
    if completed.returncode:
        # Do not include pip output here: requirement URLs and configured index
        # URLs can contain credentials.  The remediation below is sufficient.
        raise DependencySyncError(f"pip exited with status {completed.returncode}")


def ensure_legacy_update_dependencies(requirements: Path) -> None:
    """Bridge updates applied by the pre-1.9.24 launcher.

    That launcher copies the new source and then imports ``chat_core`` in the
    same process, without reloading its own updated launcher code.  tzlocal is
    the first dependency newly required by 1.9.24, so its absence identifies
    precisely the old environment that needs the one-time full requirements
    synchronization.
    """
    if getattr(sys, "frozen", False):
        return
    try:
        importlib.import_module("tzlocal")
    except ModuleNotFoundError:
        sync_requirements(requirements)