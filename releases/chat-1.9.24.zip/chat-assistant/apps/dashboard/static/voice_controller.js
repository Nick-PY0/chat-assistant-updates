"use strict";
// voice_controller.js — remote-native voice endpoint for /voice-controller.
//
// This page IS a voice device: it owns a dedicated cloud conversation on the
// server (its own provider session, transcripts, tools) and never touches the
// host machine's microphone, speakers, or host conversation.
//
// Pipeline (capture):
//   getUserMedia (AEC/NS/AGC requested) → AudioWorklet capture processor
//   (real-time thread, zero-copy blocks) → deterministic linear resampler to
//   16 kHz PCM16 → exact 1280-sample frames → 8-byte "JV" header with a
//   sequence number → WebSocket, with a bounded ring of pending frames when
//   the socket back-pressures (oldest dropped first, counted).
//   ScriptProcessor remains only as a fallback for browsers without worklets.
//
// Pipeline (playback):
//   Binary "JA" frames (24 kHz PCM16, turn-stamped) → shared AudioContext
//   (same context as capture so browser AEC can subtract playback) → two
//   schedule chains: conversation audio (turn-fenced: frames from an
//   interrupted answer are dropped client-side too) and host announcements.
//
// Session flow:
//   fetch short-lived capability token → WS hello {token, device, resume?} →
//   ready {epoch, resume secret} (stored in sessionStorage for reconnects) →
//   wake-listening ("Hey Jarvis", server-side model) or manual start /
//   push-to-talk when the wake model is unavailable → conversation → goodbye
//   returns to wake listening. Unexpected drops auto-reconnect with backoff
//   and resume the same lease within the server's grace window.

(() => {
  // ---- constants -----------------------------------------------------------
  const IN_RATE = 16000;          // server contract: 16 kHz PCM16 mono
  const CHUNK = 1280;             // 80 ms frames — must match the server
  const OUT_RATE = 24000;         // provider replies at 24 kHz
  const UP_MAGIC0 = 0x4a, UP_MAGIC1 = 0x56;   // "JV"
  const DOWN_HEADER_BYTES = 12;               // "JA" v1
  const KIND_VOICE = 0, KIND_ANNOUNCE = 1;
  const WS_HIGH_WATER = 262144;   // bytes buffered before frames go to the ring
  const RING_CAP = 25;            // ~2 s of pending audio at 80 ms/frame
  const PING_EVERY_MS = 20000;
  const DIAG_EVERY_MS = 10000;
  const RECONNECT_BASE_MS = 1000;
  const RECONNECT_MAX_MS = 10000;

  // ---- small pure helpers (exposed for the jsdom harness/tests) ------------
  class Resampler {
    // Deterministic stateful linear resampler: any source rate → 16 kHz,
    // framed into exact CHUNK-sample PCM16 blocks; partial frames carry over.
    constructor(srcRate, dstRate, chunkSamples) {
      this.srcRate = srcRate;
      this.dstRate = dstRate;
      this.chunkSamples = chunkSamples;
      this._srcPos = 0.0;
      this._prevSample = 0;
      this._outBuf = new Int16Array(chunkSamples);
      this._outFill = 0;
      this._ready = [];
    }
    push(f32) {
      const step = this.srcRate / this.dstRate;
      const n = f32.length;
      while (true) {
        const srcIdx = this._srcPos;
        if (srcIdx >= n) {
          this._srcPos = srcIdx - n;
          if (n > 0) this._prevSample = this._toInt16(f32[n - 1]);
          break;
        }
        const j = Math.floor(srcIdx);
        const frac = srcIdx - j;
        const a = j < 0 ? this._prevSample : this._toInt16(f32[j]);
        const b = j + 1 < n ? this._toInt16(f32[j + 1]) : a;
        this._outBuf[this._outFill++] = Math.round(a + (b - a) * frac);
        if (this._outFill === this.chunkSamples) {
          this._ready.push(this._outBuf.buffer.slice(0));
          this._outBuf = new Int16Array(this.chunkSamples);
          this._outFill = 0;
        }
        this._srcPos = srcIdx + step;
      }
      const out = this._ready;
      this._ready = [];
      return out;
    }
    _toInt16(f) {
      const s = Math.max(-1, Math.min(1, f));
      return s < 0 ? (s * 0x8000) | 0 : (s * 0x7fff) | 0;
    }
  }

  function packFrame(pcmBuf, seq) {
    // 8-byte header: "JV", version 1, flags 0, u32 LE sequence.
    const out = new Uint8Array(8 + pcmBuf.byteLength);
    const dv = new DataView(out.buffer);
    dv.setUint8(0, UP_MAGIC0);
    dv.setUint8(1, UP_MAGIC1);
    dv.setUint8(2, 1);
    dv.setUint8(3, 0);
    dv.setUint32(4, seq >>> 0, true);
    out.set(new Uint8Array(pcmBuf), 8);
    return out.buffer;
  }

  function parseDownHeader(buf) {
    if (buf.byteLength < DOWN_HEADER_BYTES) return null;
    const dv = new DataView(buf);
    if (dv.getUint8(0) !== 0x4a || dv.getUint8(1) !== 0x41) return null; // "JA"
    if (dv.getUint8(2) !== 1) return null;
    return {
      kind: dv.getUint8(3),
      turn: dv.getUint16(4, true),
      seq: dv.getUint32(8, true),
      pcm: buf.slice(DOWN_HEADER_BYTES),
    };
  }

  class RingQueue {
    // Bounded FIFO of pending upstream frames; oldest dropped when full.
    constructor(cap) { this.cap = cap; this.items = []; this.dropped = 0; }
    push(item) {
      if (this.items.length >= this.cap) { this.items.shift(); this.dropped++; }
      this.items.push(item);
    }
    drain(fn) {
      while (this.items.length) fn(this.items.shift());
    }
    get length() { return this.items.length; }
  }

  function reconnectDelay(attempt) {
    const ms = RECONNECT_BASE_MS * Math.pow(2, Math.max(0, attempt - 1));
    return Math.min(RECONNECT_MAX_MS, ms) + Math.floor(Math.random() * 250);
  }

  function rmsOfPcm(buf) {
    const pcm = new Int16Array(buf);
    if (!pcm.length) return 0;
    let acc = 0;
    for (let i = 0; i < pcm.length; i += 4) acc += pcm[i] * pcm[i]; // stride 4: cheap
    return Math.sqrt(acc / Math.ceil(pcm.length / 4));
  }

  function deviceLabel() {
    const ua = navigator.userAgent || "";
    let os = "Device";
    if (/Android/i.test(ua)) os = "Android";
    else if (/iPhone|iPad|iPod/i.test(ua)) os = "iPhone/iPad";
    else if (/Windows/i.test(ua)) os = "Windows PC";
    else if (/Mac OS/i.test(ua)) os = "Mac";
    else if (/Linux/i.test(ua)) os = "Linux PC";
    let browser = "browser";
    if (/Edg\//.test(ua)) browser = "Edge";
    else if (/Chrome\//.test(ua)) browser = "Chrome";
    else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) browser = "Safari";
    else if (/Firefox\//.test(ua)) browser = "Firefox";
    return os + " · " + browser;
  }

  // ---- DOM ------------------------------------------------------------------
  const $ = (id) => document.getElementById(id);
  const els = {
    status: $("vc-status"),          // hidden text mirror (tests/title)
    conn: $("vc-conn"),
    state: $("vc-state"),
    hint: $("vc-hint"),
    main: $("vc-main"),
    mainLabel: $("vc-main-label"),
    meter: $("vc-meter"),
    stop: $("vc-stop"),
    goodbye: $("vc-goodbye"),
    mute: $("vc-mute"),
    ptt: $("vc-ptt"),
    manual: $("vc-manual"),
    takeover: $("vc-takeover"),
    banner: $("vc-banner"),
    error: $("vc-error"),
    transcript: $("vc-transcript"),
    latency: $("vc-latency"),
    diag: $("vc-diag"),
  };
  const csrf = (document.querySelector('meta[name="csrf"]') || {}).content || "";

  // ---- state ----------------------------------------------------------------
  let ws = null;
  let wsGeneration = 0;          // guards stale socket callbacks
  let audioCtx = null;
  let micStream = null;
  let mediaSource = null;
  let workletNode = null;
  let scriptNode = null;         // fallback path only
  let zeroGain = null;
  let resampler = null;
  let captureWatchdogTimer = null;

  let started = false;           // user pressed the main button at least once
  let setupGeneration = 0;       // fences async mic/token/socket setup retries
  let closingDeliberately = false;
  let reconnectAttempt = 0;
  let reconnectTimer = null;

  let phase = "idle";            // idle|connecting|wake|starting|listening|speaking|local_only|busy|revoked|error
  let wakeAvailable = false;
  let conversation = false;
  let muted = false;
  let ptt = false;
  let pttHeld = false;
  let serverMuted = false;

  let seq = 0;
  let currentTurn = 0;
  const ring = new RingQueue(RING_CAP);

  // playback scheduling: separate chains for conversation + announcements
  let voiceCursor = 0, announceCursor = 0;
  let voiceSources = [], announceSources = [];
  let playbackReportTimer = null, playbackReported = false;
  let workingTimer = null, workingNodes = [];

  // stats for the diag channel + panel
  const stats = {
    frames_sent: 0,
    frames_ring_dropped: 0,
    frames_gated: 0,
    capture_blocks: 0,
    capture_stalls: 0,
    stale_voice_frames: 0,
    playback_frames: 0,
    reconnects: 0,
    engine: "none",              // worklet | scriptprocessor
    src_rate: 0,
    latency_ms: -1,
    server_frames_in: 0,
    server_frames_forwarded: 0,
    wake_predictions: 0,
    wake_last_score: 0,
    wake_peak_score: 0,
    wake_threshold: 0,
    wake_errors: 0,
    wake_error: "",
  };

  let pingTimer = null, diagTimer = null;

  // ---- UI helpers -------------------------------------------------------------
  const PHASE_LABEL = {
    idle: "Ready",
    connecting: "Connecting…",
    wake: "Say “Hey Jarvis”",
    starting: "Starting…",
    listening: "Listening",
    speaking: "Speaking",
    local_only: "Local-only mode",
    busy: "In use elsewhere",
    revoked: "Taken over",
    error: "Error",
  };
  const PHASE_CLASS = {
    wake: "vc-wake", starting: "vc-connecting", listening: "vc-listening",
    speaking: "vc-speaking", local_only: "vc-warn", busy: "vc-warn",
    revoked: "vc-warn", error: "vc-error", connecting: "vc-connecting",
    idle: "",
  };

  function setPhase(next, hint) {
    if (next === "wake" || next === "local_only" || next === "revoked"
        || next === "error" || next === "idle") stopWorkingLoop();
    phase = next;
    const label = PHASE_LABEL[next] || next;
    if (els.state) {
      els.state.textContent = label;
      els.state.className = "vc-state-label " + (PHASE_CLASS[next] || "");
    }
    if (els.status) els.status.textContent = label;
    document.title = "Voice — " + label;
    if (els.hint && hint !== undefined) els.hint.textContent = hint || "";
    if (els.main) {
      els.main.className = "vc-big " + (PHASE_CLASS[next] || "");
      els.main.classList.toggle("vc-live", next === "listening" || next === "speaking");
      els.main.classList.toggle("vc-idlebtn", next === "idle" || next === "error");
    }
    if (els.mainLabel) {
      if (next === "idle") els.mainLabel.textContent = "Enable microphone";
      else if (next === "error") els.mainLabel.textContent = "Try again";
      else if (next === "connecting") els.mainLabel.textContent = "Connecting…";
      else if (ptt && !conversation) els.mainLabel.textContent = "Hold to talk";
      else if (next === "wake") els.mainLabel.textContent = wakeAvailable ? "Listening for “Hey Jarvis”" : "Tap to start";
      else if (ptt) els.mainLabel.textContent = pttHeld ? "Talking…" : "Hold to talk";
      else if (next === "speaking") els.mainLabel.textContent = "Tap to interrupt";
      else els.mainLabel.textContent = "Conversation active";
    }
    const inSession = conversation && (next === "starting" || next === "listening" || next === "speaking");
    if (els.stop) els.stop.disabled = !(next === "speaking" || inSession);
    if (els.goodbye) els.goodbye.disabled = !inSession;
    if (els.manual) {
      els.manual.hidden = !(next === "wake" && !ptt);
      els.manual.textContent = wakeAvailable ? "Start without wake word" : "Start conversation";
    }
  }

  function setError(msg) { if (els.error) els.error.textContent = msg || ""; }

  function setBanner(msg, cls) {
    if (!els.banner) return;
    els.banner.textContent = msg || "";
    els.banner.className = "vc-banner " + (cls || "");
    els.banner.hidden = !msg;
  }

  function setConn(label, cls) {
    if (!els.conn) return;
    els.conn.textContent = label;
    els.conn.className = "vc-conn " + (cls || "");
  }

  function addTranscript(role, text) {
    if (!els.transcript) return;
    const row = document.createElement("div");
    row.className = "vc-line " + (role === "user" ? "vc-line-user" : "vc-line-assistant");
    const who = document.createElement("span");
    who.className = "vc-who";
    who.textContent = role === "user" ? "You" : "Jarvis";
    const body = document.createElement("span");
    body.textContent = text;
    row.appendChild(who);
    row.appendChild(body);
    els.transcript.appendChild(row);
    while (els.transcript.children.length > 8) els.transcript.removeChild(els.transcript.firstChild);
    els.transcript.scrollTop = els.transcript.scrollHeight;
    els.transcript.hidden = false;
  }

  let meterRaf = 0;
  function setMeter(level01) {
    if (!els.meter || meterRaf) return;
    meterRaf = requestAnimationFrame(() => {
      meterRaf = 0;
      els.meter.style.width = Math.round(Math.min(1, level01) * 100) + "%";
      els.meter.classList.toggle("vc-meter-gated", muted || (ptt && !pttHeld));
    });
  }

  function renderDiag() {
    if (!els.diag) return;
    els.diag.textContent = JSON.stringify({
      engine: stats.engine,
      source_rate: stats.src_rate,
      capture_blocks: stats.capture_blocks,
      capture_stalls: stats.capture_stalls,
      frames_sent: stats.frames_sent,
      server_frames_in: stats.server_frames_in,
      server_frames_forwarded: stats.server_frames_forwarded,
      wake_predictions: stats.wake_predictions,
      wake_last_score: stats.wake_last_score,
      wake_peak_score: stats.wake_peak_score,
      wake_threshold: stats.wake_threshold,
      wake_errors: stats.wake_errors,
      wake_error: stats.wake_error,
      ring_dropped: stats.frames_ring_dropped,
      gated: stats.frames_gated,
      stale_playback_dropped: stats.stale_voice_frames,
      playback_frames: stats.playback_frames,
      reconnects: stats.reconnects,
      latency_ms: stats.latency_ms,
      timing_trace: stats.timing_trace || [],
      ws_buffered: ws && ws.readyState === WebSocket.OPEN ? ws.bufferedAmount : 0,
    }, null, 1);
  }

  // ---- playback ---------------------------------------------------------------
  function playWakeAck(ctx = audioCtx) {
    // Local-only confirmation: this runs only after the server reports that
    // OpenWakeWord detected "Hey Jarvis". It never enters provider/downstream
    // audio. The server briefly gates mic frames to keep speaker echo out.
    if (!ctx || typeof ctx.createOscillator !== "function"
        || typeof ctx.createGain !== "function") return false;
    try {
      if (ctx.state === "suspended" && typeof ctx.resume === "function") {
        ctx.resume().catch(() => {});
      }
      const at = ctx.currentTime + 0.015;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(587.33, at);
      osc.frequency.exponentialRampToValueAtTime(880.0, at + 0.11);
      gain.gain.setValueAtTime(0.0001, at);
      gain.gain.exponentialRampToValueAtTime(0.10, at + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.onended = () => {
        try { osc.disconnect(); } catch (_) {}
        try { gain.disconnect(); } catch (_) {}
      };
      osc.start(at);
      osc.stop(at + 0.19);
      return true;
    } catch (_) {
      return false;
    }
  }

  function playHeardCue(ctx = audioCtx) {
    if (!ctx || typeof ctx.createOscillator !== "function"
        || typeof ctx.createGain !== "function") return false;
    try {
      const at = ctx.currentTime + 0.01;
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(740, at);
      gain.gain.setValueAtTime(0.0001, at);
      gain.gain.exponentialRampToValueAtTime(0.055, at + 0.018);
      gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.105);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(at); osc.stop(at + 0.11);
      return true;
    } catch (_) { return false; }
  }

  function stopWorkingLoop() {
    if (workingTimer) { clearTimeout(workingTimer); workingTimer = null; }
    for (const node of workingNodes) { try { node.stop(); } catch (_) {} }
    workingNodes = [];
  }

  function startWorkingLoop(ctx = audioCtx) {
    stopWorkingLoop();
    if (!ctx || typeof ctx.createOscillator !== "function") return;
    const pulse = () => {
      if (!conversation || !ws || ws.readyState !== WebSocket.OPEN) {
        stopWorkingLoop(); return;
      }
      try {
        const at = ctx.currentTime + 0.01;
        const osc = ctx.createOscillator(), gain = ctx.createGain();
        osc.frequency.setValueAtTime(392, at);
        gain.gain.setValueAtTime(0.0001, at);
        gain.gain.exponentialRampToValueAtTime(0.012, at + 0.025);
        gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
        osc.connect(gain); gain.connect(ctx.destination);
        workingNodes.push(osc);
        osc.onended = () => { workingNodes = workingNodes.filter((x) => x !== osc); };
        osc.start(at); osc.stop(at + 0.13);
      } catch (_) {}
      workingTimer = setTimeout(pulse, 900);
    };
    workingTimer = setTimeout(pulse, 320);
  }

  function flushVoicePlayback() {
    stopWorkingLoop();
    for (const s of voiceSources) { try { s.stop(); } catch (_) {} }
    voiceSources = [];
    voiceCursor = 0;
    maybeReportPlayback();
  }

  function flushAnnouncePlayback() {
    for (const s of announceSources) { try { s.stop(); } catch (_) {} }
    announceSources = [];
    announceCursor = 0;
    maybeReportPlayback();
  }

  function sendJson(obj) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try { ws.send(JSON.stringify(obj)); } catch (_) {}
    }
  }

  function maybeReportPlayback() {
    if (playbackReportTimer) { clearTimeout(playbackReportTimer); playbackReportTimer = null; }
    const playing = voiceSources.length > 0 || announceSources.length > 0;
    if (playing && !playbackReported) {
      playbackReported = true;
      sendJson({ type: "playback", playing: true });
    } else if (!playing && playbackReported) {
      playbackReportTimer = setTimeout(() => {
        playbackReportTimer = null;
        if (voiceSources.length === 0 && announceSources.length === 0 && playbackReported) {
          playbackReported = false;
          sendJson({ type: "playback", playing: false });
        }
      }, 40);
    }
  }

  function scheduleAudio(pcmBuf, kindVoice) {
    if (!audioCtx) return;
    const pcm = new Int16Array(pcmBuf);
    if (!pcm.length) return;
    const abuf = audioCtx.createBuffer(1, pcm.length, OUT_RATE);
    const ch = abuf.getChannelData(0);
    for (let i = 0; i < pcm.length; i++) ch[i] = pcm[i] / 32768;
    const src = audioCtx.createBufferSource();
    src.buffer = abuf;
    src.connect(audioCtx.destination);
    const lead = audioCtx.currentTime + 0.06;
    if (kindVoice) {
      const at = Math.max(voiceCursor, lead);
      src.start(at);
      voiceCursor = at + abuf.duration;
      voiceSources.push(src);
      src.onended = () => {
        voiceSources = voiceSources.filter((x) => x !== src);
        maybeReportPlayback();
      };
    } else {
      const at = Math.max(announceCursor, lead);
      src.start(at);
      announceCursor = at + abuf.duration;
      announceSources.push(src);
      src.onended = () => {
        announceSources = announceSources.filter((x) => x !== src);
        maybeReportPlayback();
      };
    }
    stats.playback_frames++;
    maybeReportPlayback();
  }

  function handleBinary(buf) {
    const frame = parseDownHeader(buf);
    if (!frame) return;
    if (frame.kind === KIND_VOICE) {
      if (currentTurn && frame.turn !== currentTurn) {
        stats.stale_voice_frames++;   // late audio from an interrupted answer
        return;
      }
      stopWorkingLoop();
      scheduleAudio(frame.pcm, true);
    } else if (frame.kind === KIND_ANNOUNCE) {
      scheduleAudio(frame.pcm, false);
    }
  }

  // ---- capture -----------------------------------------------------------------
  function onCaptureBlock(f32) {
    if (!f32 || typeof f32.length !== "number") return;
    stats.capture_blocks++;
    if (!resampler) return;
    const frames = resampler.push(f32);
    for (const pcmBuf of frames) {
      setMeter(rmsOfPcm(pcmBuf) / 8000);
      if (muted || (ptt && !pttHeld)) { stats.frames_gated++; continue; }
      if (!ws || ws.readyState !== WebSocket.OPEN) continue;
      const framed = packFrame(pcmBuf, seq++);
      if (ws.bufferedAmount > WS_HIGH_WATER) {
        ring.push(framed);
        stats.frames_ring_dropped = ring.dropped;
        continue;
      }
      ring.drain((old) => { try { ws.send(old); } catch (_) {} });
      try { ws.send(framed); stats.frames_sent++; } catch (_) {}
    }
  }

  function clearCaptureWatchdog() {
    if (captureWatchdogTimer) {
      clearTimeout(captureWatchdogTimer);
      captureWatchdogTimer = null;
    }
  }

  function installScriptCapture(recovered) {
    if (!audioCtx || !mediaSource || !zeroGain) return false;
    clearCaptureWatchdog();
    try {
      if (workletNode) {
        workletNode.port.onmessage = null;
        workletNode.disconnect();
      }
      mediaSource.disconnect();
      workletNode = null;
      scriptNode = audioCtx.createScriptProcessor(4096, 1, 1);
      scriptNode.onaudioprocess = (e) => {
        onCaptureBlock(e.inputBuffer.getChannelData(0).slice(0));
      };
      mediaSource.connect(scriptNode);
      scriptNode.connect(zeroGain);
      stats.engine = "scriptprocessor";
      if (recovered) {
        stats.capture_stalls++;
        setBanner("Microphone capture recovered in compatibility mode.", "vc-banner-good");
      }
      const baseline = stats.capture_blocks;
      captureWatchdogTimer = setTimeout(() => {
        captureWatchdogTimer = null;
        if (micStream && stats.capture_blocks === baseline) {
          stats.capture_stalls++;
          setError("The browser opened the microphone but no audio is arriving. Close other apps using the mic, then tap Try again.");
          setPhase("error", "");
        }
      }, 3000);
      return true;
    } catch (_) {
      return false;
    }
  }

  function armWorkletWatchdog() {
    clearCaptureWatchdog();
    const baseline = stats.capture_blocks;
    captureWatchdogTimer = setTimeout(() => {
      captureWatchdogTimer = null;
      if (!micStream || stats.capture_blocks !== baseline) return;
      if (audioCtx && audioCtx.state === "suspended") {
        audioCtx.resume().catch(() => {});
      }
      installScriptCapture(true);
    }, 2500);
  }

  function disposeCaptureParts(stream, source, worklet, script, gain) {
    try { worklet && (worklet.port.onmessage = null); } catch (_) {}
    try { source && source.disconnect(); } catch (_) {}
    try { worklet && worklet.disconnect(); } catch (_) {}
    try { script && script.disconnect(); } catch (_) {}
    try { gain && gain.disconnect(); } catch (_) {}
    if (stream && stream.getTracks) {
      stream.getTracks().forEach((t) => { try { t.stop(); } catch (_) {} });
    }
  }

  async function startCapture(generation = setupGeneration) {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: { ideal: true },
          noiseSuppression: { ideal: true },
          autoGainControl: { ideal: true },
        },
        video: false,
      });
    } catch (e) {
      if (generation !== setupGeneration) return false;
      const name = (e && e.name) || "";
      if (name === "NotAllowedError" || name === "SecurityError") {
        setError("Microphone permission was denied. Allow microphone access for this site in your browser settings, then try again.");
      } else if (name === "NotFoundError") {
        setError("No microphone was found on this device.");
      } else if (name === "NotReadableError") {
        setError("The microphone is in use by another app.");
      } else {
        setError("Microphone error: " + ((e && e.message) || e));
      }
      return false;
    }

    if (generation !== setupGeneration) {
      disposeCaptureParts(stream, null, null, null, null);
      return false;
    }

    const ctx = audioCtx;
    let source = null, gain = null, worklet = null, script = null;
    try {
      source = ctx.createMediaStreamSource(stream);
      gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(ctx.destination);
    } catch (e) {
      disposeCaptureParts(stream, source, worklet, script, gain);
      if (generation === setupGeneration) {
        setError("Could not connect the microphone to browser audio.");
      }
      return false;
    }

    if (ctx.audioWorklet && typeof ctx.audioWorklet.addModule === "function") {
      try {
        const ver = (document.querySelector('script[src*="voice_controller.js"]') || {}).src || "";
        const v = (ver.split("?v=")[1] || "dev");
        await ctx.audioWorklet.addModule("/static/voice_worklet.js?v=" + encodeURIComponent(v));
        if (generation !== setupGeneration) {
          disposeCaptureParts(stream, source, null, null, gain);
          return false;
        }
        worklet = new AudioWorkletNode(ctx, "jarvis-capture", {
          numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1],
        });
        worklet.port.onmessage = (e) => {
          if (e.data && e.data.stats) return;
          onCaptureBlock(e.data);
        };
        if (generation !== setupGeneration) {
          disposeCaptureParts(stream, source, worklet, null, gain);
          return false;
        }
        micStream = stream;
        mediaSource = source;
        workletNode = worklet;
        scriptNode = null;
        zeroGain = gain;
        resampler = new Resampler(ctx.sampleRate, IN_RATE, CHUNK);
        inspectAEC(stream);
        stats.src_rate = ctx.sampleRate;
        source.connect(worklet);
        worklet.connect(gain);
        stats.engine = "worklet";
        armWorkletWatchdog();
        return true;
      } catch (_) {
        try { worklet && (worklet.port.onmessage = null); } catch (_) {}
        try { worklet && worklet.disconnect(); } catch (_) {}
        worklet = null;
        if (generation !== setupGeneration) {
          disposeCaptureParts(stream, source, null, null, gain);
          return false;
        }
      }
    }

    try {
      script = ctx.createScriptProcessor(4096, 1, 1);
      script.onaudioprocess = (e) => {
        onCaptureBlock(e.inputBuffer.getChannelData(0).slice(0));
      };
      if (generation !== setupGeneration) {
        disposeCaptureParts(stream, source, null, script, gain);
        return false;
      }
      micStream = stream;
      mediaSource = source;
      workletNode = null;
      scriptNode = script;
      zeroGain = gain;
      resampler = new Resampler(ctx.sampleRate, IN_RATE, CHUNK);
      inspectAEC(stream);
      stats.src_rate = ctx.sampleRate;
      source.connect(script);
      script.connect(gain);
      stats.engine = "scriptprocessor";
      return true;
    } catch (_) {
      disposeCaptureParts(stream, source, null, script, gain);
      if (generation === setupGeneration) {
        setError("Could not start microphone capture in this browser.");
      }
      return false;
    }
  }

  function stopCapture() {
    clearCaptureWatchdog();
    try { mediaSource && mediaSource.disconnect(); } catch (_) {}
    try { workletNode && workletNode.disconnect(); } catch (_) {}
    try { scriptNode && scriptNode.disconnect(); } catch (_) {}
    try { zeroGain && zeroGain.disconnect(); } catch (_) {}
    mediaSource = workletNode = scriptNode = zeroGain = null;
    if (micStream) {
      micStream.getTracks().forEach((t) => t.stop());
      micStream = null;
    }
    resampler = null;
  }

  function inspectAEC(stream) {
    const track = stream && stream.getAudioTracks && stream.getAudioTracks()[0];
    if (!track) return;
    let enabled = true, unavailable = false;
    if (track.getSettings) {
      const s = track.getSettings();
      if (typeof s.echoCancellation === "boolean") enabled = s.echoCancellation;
    }
    if (track.getCapabilities) {
      try {
        const caps = track.getCapabilities();
        if (caps.echoCancellation && Array.isArray(caps.echoCancellation)
            && caps.echoCancellation.length === 1 && caps.echoCancellation[0] === false) {
          unavailable = true; enabled = false;
        }
      } catch (_) {}
    }
    if (unavailable) {
      setBanner("Echo cancellation is not available on this microphone — use headphones or push-to-talk to avoid feedback.", "vc-banner-warn");
    } else if (!enabled) {
      setBanner("Echo cancellation appears to be off — if Jarvis hears itself, use headphones or push-to-talk.", "vc-banner-warn");
    }
  }

  // ---- session / socket ----------------------------------------------------------
  function loadResume() {
    try {
      const raw = sessionStorage.getItem("vc-resume");
      if (!raw) return null;
      const data = JSON.parse(raw);
      if (data && typeof data.epoch === "number" && typeof data.secret === "string") return data;
    } catch (_) {}
    return null;
  }
  function storeResume(resume) {
    try { sessionStorage.setItem("vc-resume", JSON.stringify(resume)); } catch (_) {}
  }
  function clearResume() {
    try { sessionStorage.removeItem("vc-resume"); } catch (_) {}
  }

  function buildHello(token, takeover = false) {
    const hello = {
      type: "hello",
      protocol: 1,
      token,
      device: deviceLabel(),
    };
    if (takeover) {
      // An explicit Talk click is authoritative even when this tab still has
      // an old resume token from a session that another device took over.
      hello.takeover = true;
    } else {
      const resume = loadResume();
      if (resume) hello.resume = resume;
    }
    return hello;
  }

  async function fetchToken() {
    const r = await fetch("/api/remote-voice/token", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf": csrf },
      body: "{}",
    });
    if (r.status === 401) throw new Error("auth");
    if (r.status === 503) throw new Error("disabled");
    if (!r.ok) throw new Error("token http " + r.status);
    const data = await r.json();
    if (!data || !data.token) throw new Error("token missing");
    return data.token;
  }

  async function connect(opts, generation = setupGeneration) {
    if (generation !== setupGeneration) return;
    const takeover = !!(opts && opts.takeover);
    closingDeliberately = false;
    const prior = ws;
    ws = null;
    const gen = ++wsGeneration;
    if (prior) { try { prior.close(1000); } catch (_) {} }
    stopTimers();
    setConn("Connecting…", "vc-conn-warn");
    setPhase("connecting");
    setError("");

    let token;
    try {
      token = await fetchToken();
    } catch (e) {
      if (generation !== setupGeneration || gen !== wsGeneration) return;
      if (e && e.message === "auth") {
        setPhase("error", "");
        setError("Session expired — sign in again, then reopen this window.");
        setConn("Signed out", "vc-conn-bad");
      } else if (e && e.message === "disabled") {
        setPhase("error", "");
        setError("Cloud voice is disabled — enable the gateway in Settings.");
        setConn("Unavailable", "vc-conn-bad");
      } else {
        scheduleReconnect("Could not reach the server.");
      }
      return;
    }
    if (generation !== setupGeneration || gen !== wsGeneration) return;

    const proto = location.protocol === "https:" ? "wss://" : "ws://";
    let sock;
    try {
      sock = new WebSocket(proto + location.host + "/ws/remote-voice");
    } catch (e) {
      scheduleReconnect("Could not open the connection.");
      return;
    }
    if (generation !== setupGeneration || gen !== wsGeneration) {
      try { sock.close(1000); } catch (_) {}
      return;
    }
    ws = sock;
    sock.binaryType = "arraybuffer";

    sock.onopen = () => {
      if (gen !== wsGeneration) return;
      sock.send(JSON.stringify(buildHello(token, takeover)));
    };

    sock.onmessage = (e) => {
      if (gen !== wsGeneration) return;
      if (typeof e.data === "string") {
        let msg;
        try { msg = JSON.parse(e.data); } catch (_) { return; }
        handleControl(msg);
      } else {
        handleBinary(e.data);
      }
    };

    sock.onclose = (e) => {
      if (gen !== wsGeneration) return;
      ws = null;
      stopTimers();
      flushVoicePlayback();
      flushAnnouncePlayback();
      playbackReported = false;
      if (closingDeliberately) return;
      if (e.code === 4401) {
        setPhase("error", "");
        setError("Session expired — sign in again, then reopen this window.");
        setConn("Signed out", "vc-conn-bad");
        clearResume();
      } else if (e.code === 4403) {
        setPhase("error", "");
        setError("Cloud voice is unavailable (disabled or blocked). Check Settings.");
        setConn("Unavailable", "vc-conn-bad");
      } else if (e.code === 4409) {
        // busy — message already shown via {"type":"busy"}
        setConn("Busy", "vc-conn-warn");
      } else if (e.code === 4412) {
        // revoked — message already shown via {"type":"revoked"}
        setConn("Taken over", "vc-conn-warn");
      } else {
        setConn("Reconnecting…", "vc-conn-warn");
        scheduleReconnect("Connection lost.");
      }
    };

    sock.onerror = () => { /* onclose carries the outcome */ };
  }

  function scheduleReconnect(msg) {
    if (!started || closingDeliberately) return;
    reconnectAttempt++;
    stats.reconnects = reconnectAttempt;
    const delay = reconnectDelay(reconnectAttempt);
    setPhase("connecting", "");
    setError((msg || "Connection lost.") + " Reconnecting in " + Math.round(delay / 1000) + "s…");
    if (reconnectTimer) clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connect({});
    }, delay);
  }

  function stopTimers() {
    if (pingTimer) { clearInterval(pingTimer); pingTimer = null; }
    if (diagTimer) { clearInterval(diagTimer); diagTimer = null; }
  }

  function startTimers() {
    stopTimers();
    pingTimer = setInterval(() => {
      sendJson({ type: "ping", t: Date.now() });
    }, PING_EVERY_MS);
    diagTimer = setInterval(() => {
      sendJson({ type: "diag", stats: {
        engine: stats.engine,
        src_rate: stats.src_rate,
        capture_blocks: stats.capture_blocks,
        capture_stalls: stats.capture_stalls,
        frames_sent: stats.frames_sent,
        ring_dropped: stats.frames_ring_dropped,
        gated: stats.frames_gated,
        stale_playback: stats.stale_voice_frames,
        latency_ms: stats.latency_ms,
      }});
      renderDiag();
    }, DIAG_EVERY_MS);
  }

  // ---- control messages ------------------------------------------------------------
  function applyServerState(state) {
    if (state === "wake") {
      conversation = false;
      flushVoicePlayback();
      setPhase("wake", wakeAvailable
        ? "Say “Hey Jarvis” or tap the button to start manually."
        : "The wake model is unavailable on the server — use the button or push-to-talk.");
    } else if (state === "starting") {
      conversation = true;
      setPhase("starting", "");
    } else if (state === "listening") {
      conversation = true;
      setPhase("listening", "Goodbye ends the conversation; Stop only silences the reply.");
    } else if (state === "speaking") {
      conversation = true;
      setPhase("speaking", "Speak to interrupt, or tap Stop.");
    } else if (state === "local_only") {
      conversation = false;
      setPhase("local_only", "Cloud is unreachable — voice commands are paused here until it recovers.");
    }
  }

  function handleControl(msg) {
    switch (msg.type) {
      case "ready": {
        reconnectAttempt = 0;
        setConn("Connected", "vc-conn-good");
        setError("");
        wakeAvailable = !!(msg.wake && msg.wake.available);
        currentTurn = msg.turn || 0;
        serverMuted = !!msg.muted;
        if (msg.resume) storeResume(msg.resume);
        conversation = !!msg.conversation_active;
        setBanner(serverMuted ? "The assistant is muted (from the dashboard) — unmute to talk." : "", "vc-banner-warn");
        applyServerState(msg.state || "wake");
        if (msg.mode === "resumed") setBanner("Reconnected — the conversation continued.", "vc-banner-good");
        startTimers();
        break;
      }
      case "busy": {
        const holder = msg.holder || {};
        setPhase("busy", "");
        setError("");
        setBanner(
          "Another device (" + (holder.device || "unknown") + ") is using voice right now" +
          (holder.in_conversation ? " — mid-conversation." : "."),
          "vc-banner-warn"
        );
        if (els.takeover) {
          els.takeover.hidden = false;
          els.takeover.textContent = "Take over on this device";
          els.takeover.onclick = () => {
            els.takeover.hidden = true;
            connect({ takeover: true });
          };
        }
        break;
      }
      case "revoked": {
        stopWorkingLoop();
        started = false;   // do not auto-reconnect into a takeover war
        setupGeneration++;
        clearResume();
        conversation = false;
        setPhase("revoked", "");
        setBanner("Another device took over the voice endpoint.", "vc-banner-warn");
        if (els.takeover) {
          els.takeover.hidden = false;
          els.takeover.textContent = "Take it back";
          els.takeover.onclick = () => {
            els.takeover.hidden = true;
            started = true;
            connect({ takeover: true });
          };
        }
        stopCapture();
        break;
      }
      case "state":
        if (typeof msg.turn === "number" && msg.turn) currentTurn = msg.turn;
        applyServerState(msg.state);
        break;
      case "wake":
        playWakeAck();
        setBanner("Heard you — starting…", "vc-banner-good");
        setTimeout(() => { if (phase === "starting" || phase === "listening") setBanner(""); }, 1500);
        break;
      case "mic_status":
        if (msg.status === "streaming") {
          setBanner("Microphone audio is reaching Jarvis. Say “Hey Jarvis”.", "vc-banner-good");
        }
        break;
      case "clear":
        stopWorkingLoop();
        if (msg.scope === "announce") {
          flushAnnouncePlayback();
        } else {
          if (typeof msg.turn === "number" && msg.turn) currentTurn = msg.turn;
          flushVoicePlayback();
        }
        break;
      case "utterance_accepted":
        playHeardCue();
        startWorkingLoop();
        setBanner("Heard you — working…", "vc-banner-good");
        break;
      case "working":
        if (!msg.active) stopWorkingLoop();
        break;
      case "timing_trace":
        if (Array.isArray(msg.trace)) {
          stats.timing_trace = msg.trace.slice(-64);
          renderDiag();
        }
        break;
      case "transcript":
        addTranscript(msg.role === "user" ? "user" : "assistant", msg.text || "");
        break;
      case "local_only":
        applyServerState("local_only");
        if (msg.quota) setBanner("Provider quota exhausted — Jarvis will retry automatically.", "vc-banner-warn");
        break;
      case "muted":
        serverMuted = !!msg.muted;
        setBanner(serverMuted ? "The assistant is muted (from the dashboard) — unmute to talk." : "", "vc-banner-warn");
        break;
      case "wake_status":
        wakeAvailable = !!msg.available;
        if (phase === "wake") applyServerState("wake");
        break;
      case "wake_diagnostics":
        stats.wake_predictions = Number(msg.predictions) || 0;
        stats.wake_last_score = Number(msg.last_score) || 0;
        stats.wake_peak_score = Number(msg.peak_score) || 0;
        stats.wake_threshold = Number(msg.threshold) || 0;
        stats.wake_errors = Number(msg.consecutive_errors) || 0;
        stats.wake_error = String(msg.error || "");
        if (phase === "wake" && stats.wake_error) {
          setBanner(
            "The wake detector failed: " + stats.wake_error +
            ". Tap the large button to start manually.",
            "vc-banner-warn"
          );
        } else if (phase === "wake" && stats.wake_predictions >= 25) {
          const peak = Math.round(stats.wake_peak_score * 100);
          const needed = Math.round(stats.wake_threshold * 100);
          setBanner(
            "The microphone is streaming, but the wake phrase has not matched " +
            "(best " + peak + "%, needs " + needed +
            "%). Tap the large button to start manually.",
            "vc-banner-warn"
          );
        }
        renderDiag();
        break;
      case "start_result":
        if (msg.status === "started" || msg.status === "already") {
          conversation = true;
          setPhase("starting", "");
          setBanner("");
        } else if (msg.status === "busy_host") {
          setBanner("The host microphone is mid-conversation.", "vc-banner-warn");
          if (els.takeover) {
            els.takeover.hidden = false;
            els.takeover.textContent = "Take over from the host";
            els.takeover.onclick = () => {
              els.takeover.hidden = true;
              sendJson({ type: "start", takeover_host: true });
            };
          }
        } else if (msg.status === "muted") {
          setBanner("The assistant is muted (from the dashboard) — unmute to talk.", "vc-banner-warn");
        }
        break;
      case "pong":
        if (typeof msg.t === "number") stats.latency_ms = Date.now() - msg.t;
        if (typeof msg.frames_in === "number") stats.server_frames_in = msg.frames_in;
        if (typeof msg.frames_forwarded === "number") {
          stats.server_frames_forwarded = msg.frames_forwarded;
        }
        if (typeof msg.turn === "number" && msg.turn) currentTurn = msg.turn;
        if (typeof msg.wake_available === "boolean"
            && msg.wake_available !== wakeAvailable) {
          wakeAvailable = msg.wake_available;
          if (phase === "wake") applyServerState("wake");
        }
        if (typeof msg.conversation_active === "boolean" && !msg.conversation_active && conversation) {
          conversation = false;
          applyServerState("wake");
        }
        if (typeof msg.muted === "boolean" && msg.muted !== serverMuted) {
          serverMuted = msg.muted;
          setBanner(serverMuted ? "The assistant is muted (from the dashboard) — unmute to talk." : "", "vc-banner-warn");
        }
        renderDiag();
        break;
    }
  }

  // ---- user actions ------------------------------------------------------------------
  async function enable() {
    const generation = ++setupGeneration;
    setError("");
    deliberateClose(false);
    if (micStream) stopCapture();
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setPhase("error", "");
      setError(location.protocol === "http:" && location.hostname !== "localhost"
        ? "This page is served over plain HTTP, so the browser blocks microphone access. Enable HTTPS in Settings → Security, or open it on the host as localhost."
        : "This browser does not support microphone capture.");
      return;
    }
    setPhase("connecting");
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    try { await audioCtx.resume(); } catch (_) {}
    const ok = await startCapture(generation);
    if (generation !== setupGeneration) return;
    if (!ok) {
      setPhase("error", "");
      return;
    }
    started = true;
    reconnectAttempt = 0;
    // Pressing Talk is always an explicit authority transfer. Automatic socket
    // recovery uses resume; a user gesture must atomically revoke older owners
    // even if this tab still holds a stale resume token.
    await connect({ takeover: true }, generation);
  }

  function deliberateClose(invalidateSetup = true) {
    if (invalidateSetup) setupGeneration++;
    closingDeliberately = true;
    wsGeneration++;  // fence late callbacks from the socket being replaced
    if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
    const closing = ws;
    ws = null;
    if (closing) { try { closing.close(1000); } catch (_) {} }
    stopTimers();
  }

  if (els.main) {
    els.main.addEventListener("pointerdown", () => {
      if (ptt && started && phase !== "idle" && phase !== "error") {
        pttHeld = true;
        if (!conversation) sendJson({ type: "start", takeover_host: true });
        setPhase(phase); // refresh label
      }
    });
    const pttUp = () => {
      if (ptt && pttHeld) { pttHeld = false; setPhase(phase); }
    };
    els.main.addEventListener("pointerup", pttUp);
    els.main.addEventListener("pointercancel", pttUp);
    els.main.addEventListener("pointerleave", pttUp);
    els.main.addEventListener("click", () => {
      if (phase === "idle" || phase === "error") { enable(); return; }
      if (ptt) return; // press-and-hold handles it
      if (phase === "speaking") { sendJson({ type: "stop" }); flushVoicePlayback(); return; }
      if (phase === "wake") {
        setBanner("Starting a conversation…", "vc-banner-good");
        sendJson({ type: "start", takeover_host: true });
      }
    });
  }

  if (els.manual) {
    els.manual.addEventListener("click", () => {
      sendJson({ type: "start", takeover_host: true });
    });
  }

  if (els.stop) {
    els.stop.addEventListener("click", () => {
      sendJson({ type: "stop" });
      flushVoicePlayback();
      flushAnnouncePlayback();
    });
  }

  if (els.goodbye) {
    els.goodbye.addEventListener("click", () => {
      sendJson({ type: "end" });
      flushVoicePlayback();
      conversation = false;
      applyServerState("wake");
    });
  }

  if (els.mute) {
    els.mute.addEventListener("click", () => {
      muted = !muted;
      els.mute.textContent = muted ? "Unmute mic" : "Mute mic";
      els.mute.classList.toggle("muted", muted);
      sendJson({ type: "mute", muted });
      setMeter(0);
    });
  }

  if (els.ptt) {
    els.ptt.addEventListener("change", () => {
      ptt = !!els.ptt.checked;
      pttHeld = false;
      setPhase(phase);
    });
  }

  // Space bar as push-to-talk while enabled
  window.addEventListener("keydown", (e) => {
    if (!ptt || e.repeat || e.code !== "Space" || phase === "idle") return;
    if (/^(input|textarea|select)$/i.test((e.target && e.target.tagName) || "")) return;
    e.preventDefault();
    if (!pttHeld) {
      pttHeld = true;
      if (!conversation) sendJson({ type: "start", takeover_host: true });
      setPhase(phase);
    }
  });
  window.addEventListener("keyup", (e) => {
    if (e.code === "Space" && pttHeld) { pttHeld = false; setPhase(phase); }
  });

  window.addEventListener("pagehide", () => { deliberateClose(); stopCapture(); });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && audioCtx && audioCtx.state === "suspended") {
      audioCtx.resume().catch(() => {});
    }
  });

  // ---- initial state --------------------------------------------------------------
  setPhase("idle", "One click grants microphone permission; after that this window can sit in the background.");
  setConn("Not connected", "");
  if (els.takeover) els.takeover.hidden = true;
  if (els.transcript) els.transcript.hidden = true;
  if (els.banner) els.banner.hidden = true;

  // Expose pure helpers for the jsdom harness + unit tests.
  window.__vc = {
    Resampler, packFrame, parseDownHeader, RingQueue, reconnectDelay,
    rmsOfPcm, deviceLabel, buildHello,
    _internals: {
      setPhase, handleControl, applyServerState, onCaptureBlock,
      playWakeAck, playHeardCue, startWorkingLoop, stopWorkingLoop,
      installScriptCapture, enable, stopCapture, deliberateClose,
    },
    get state() {
      return { phase, conversation, wakeAvailable, muted, ptt, currentTurn, stats };
    },
  };
})();
