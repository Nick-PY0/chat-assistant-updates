"use strict";
/* voice_worklet.js — AudioWorklet capture processor for /voice-controller.
 *
 * Runs on the real-time audio thread. It only copies mic samples into a
 * fixed-size block and transfers the block to the main thread (zero-copy);
 * resampling, framing, and WebSocket work all happen off this thread.
 *
 * Block size: 2048 samples (~43 ms at 48 kHz) — small enough for snappy
 * barge-in, large enough to keep the message rate low (~23/s).
 */

class JarvisCaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this._block = new Float32Array(2048);
    this._fill = 0;
    this._posted = 0;
    this._silentTicks = 0;
    this.port.onmessage = (e) => {
      if (e.data === "stats") {
        this.port.postMessage({ stats: { posted: this._posted } });
      }
    };
  }

  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch || ch.length === 0) {
      // Keep the node alive; some devices deliver empty blocks briefly.
      this._silentTicks++;
      return true;
    }
    let off = 0;
    while (off < ch.length) {
      const n = Math.min(ch.length - off, this._block.length - this._fill);
      this._block.set(ch.subarray(off, off + n), this._fill);
      this._fill += n;
      off += n;
      if (this._fill === this._block.length) {
        const out = this._block;
        this._block = new Float32Array(2048);
        this._fill = 0;
        this._posted++;
        this.port.postMessage(out, [out.buffer]);
      }
    }
    return true;
  }
}

registerProcessor("jarvis-capture", JarvisCaptureProcessor);
