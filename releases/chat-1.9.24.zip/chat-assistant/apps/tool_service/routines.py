"""Strict, durable user routines and their wall-clock scheduler."""

from __future__ import annotations

import asyncio
import inspect
import json
import re
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from chat_core.models.credentials import iso


class RoutineError(ValueError):
    """A safe, user-presentable routine error."""


class _StepResultError(Exception):
    pass


PLACEHOLDER_PREFIX = "__REQUIRED_"
MAX_ACTIONS = 30

# Each entry is (ToolService name, allowed argument specification).  A
# specification value is: type, (type,min,max), or a finite set of strings.
# None denotes an action implemented here rather than dispatched to a provider.
ACTION_CATALOG: dict[str, tuple[str | None, dict[str, Any]]] = {
    "calendar_read": ("list_calendar_events", {"days": (int, 1, 31), "limit": (int, 1, 50)}),
    "calendar_next_meeting": ("get_next_meeting", {}),
    "briefing": ("get_briefing", {}),
    "music_play": ("play_music", {"query": (str, 1, 120), "room": (str, 1, 60)}),
    "music_control": ("control_music", {"action": {"play", "pause", "stop", "next", "previous", "mute", "unmute"}, "room": (str, 1, 60)}),
    "music_volume": ("set_music_volume", {"percentage": (int, 0, 100), "room": (str, 1, 60)}),
    "govee_power": ("set_govee_power", {"device": (str, 1, 60), "state": {"on", "off"}}),
    "govee_brightness": ("set_govee_brightness", {"device": (str, 1, 60), "percentage": (int, 0, 100)}),
    "govee_color": ("set_govee_color", {"device": (str, 1, 60), "color": (str, 1, 30)}),
    "govee_scene": ("activate_govee_scene", {"device": (str, 1, 60), "scene": (str, 1, 60)}),
    "tv_power": ("tv_power", {"state": {"on", "off"}}),
    "tv_volume": ("tv_set_volume", {"percentage": (int, 0, 100)}),
    "tv_mute": ("tv_mute", {"muted": bool}),
    "tv_media": ("tv_media", {"action": {"play", "pause", "stop", "rewind", "fast_forward"}}),
    "tv_button": ("tv_button", {"button": {"up", "down", "left", "right", "enter", "back", "home", "menu", "info", "exit", "channel_up", "channel_down", "red", "green", "yellow", "blue"}}),
    "tv_input": ("tv_set_input", {"input": (str, 1, 60)}),
    "tv_app": ("tv_launch_app", {"app": (str, 1, 60)}),
    "quiet_mode": ("set_quiet_mode", {"enabled": bool}),
    "reminder": ("set_reminder", {"time": (str, 5, 5), "message": (str, 1, 200), "day": (str, 1, 20)}),
    "alarm": ("set_reminder", {"time": (str, 5, 5), "message": (str, 1, 200), "day": (str, 1, 20)}),
    "wait": (None, {"seconds": (int, 0, 300)}),
    "announcement": (None, {"text": (str, 1, 200)}),
}
ACTION_TO_TOOL = {name: spec[0] for name, spec in ACTION_CATALOG.items()}

_ACTION_TEXT = {
    "calendar_read": ("Calendar", "Read upcoming calendar events"),
    "calendar_next_meeting": ("Next meeting", "Read the next meeting"),
    "briefing": ("Briefing", "Prepare the configured briefing"),
    "music_play": ("Play music", "Play a music search in an optional room"),
    "music_control": ("Music control", "Control current music playback"),
    "music_volume": ("Music volume", "Set music volume"),
    "govee_power": ("Light power", "Turn a configured light on or off"),
    "govee_brightness": ("Light brightness", "Set light brightness"),
    "govee_color": ("Light color", "Set a light color"),
    "govee_scene": ("Light scene", "Activate a light scene"),
    "tv_power": ("TV power", "Turn the TV on or off"),
    "tv_volume": ("TV volume", "Set TV volume"),
    "tv_mute": ("TV mute", "Mute or unmute the TV"),
    "tv_media": ("TV media", "Control TV playback"),
    "tv_button": ("TV button", "Press an allowlisted remote button"),
    "tv_input": ("TV input", "Select a configured TV input"),
    "tv_app": ("TV app", "Launch an installed TV app"),
    "quiet_mode": ("Quiet mode", "Enable or disable quiet mode"),
    "reminder": ("Reminder", "Set a reminder at a wall-clock time"),
    "alarm": ("Alarm", "Set an alarm at a wall-clock time"),
    "wait": ("Wait", "Wait for a bounded number of seconds"),
    "announcement": ("Announcement", "Speak a short announcement"),
}


def catalog_public() -> list[dict]:
    """Return dashboard metadata without exposing implementation tool names."""
    optional = {
        "calendar_read": {"days", "limit"}, "music_control": {"room"},
        "music_volume": {"room"}, "reminder": {"message", "day"},
        "alarm": {"message", "day"},
    }
    labels = {
        "days": "Days", "limit": "Limit", "query": "Music", "room": "Room",
        "action": "Action", "percentage": "Percentage", "device": "Device",
        "state": "State", "color": "Color", "scene": "Scene", "muted": "Muted",
        "button": "Button", "input": "Input", "app": "Installed app",
        "enabled": "Enabled", "time": "Time", "message": "Message",
        "day": "Day", "seconds": "Seconds", "text": "Text",
    }
    output = []
    for action, (_, spec) in ACTION_CATALOG.items():
        fields = []
        for name, rule in spec.items():
            field = {"name": name, "label": labels.get(name, name.replace("_", " ").title()),
                     "required": name not in optional.get(action, set())}
            if isinstance(rule, set):
                field.update(type="select", options=sorted(rule))
            elif rule is bool:
                field["type"] = "boolean"
            else:
                kind, low, high = rule
                field["type"] = "number" if kind is int else ("time" if name == "time" else "text")
                field.update(min=low, max=high)
                if kind is str:
                    field["placeholder"] = labels.get(name, "")
            fields.append(field)
        label, description = _ACTION_TEXT[action]
        output.append({"type": action, "label": label, "description": description,
                       "fields": fields})
    return output

_RESERVED = {
    "stop", "mute", "unmute", "quiet", "timer", "timers", "reminder",
    "reminders", "alarm", "alarms", "tv", "television", "light", "lights",
    "media", "music", "play", "pause", "next", "previous", "volume", "power",
    "turn on", "turn off", "goodbye", "cancel", "resume",
}
_DANGEROUS_PHRASE = re.compile(
    r"^(?:stop(?:\s|$)|mute(?:\s|$)|unmute(?:\s|$)|goodbye$|"
    r"quiet(?:\s+mode)?(?:\s|$)|remind(?:\s+me)?(?:\s|$)|wake\s+me(?:\s|$)|"
    r"(?:timer|reminder|alarm)s?(?:\s|$)|"
    r"turn\s+(?:on|off)(?:\s|$)|(?:set|start|cancel|pause|resume|list)\s+"
    r"(?:a\s+|the\s+)?(?:timer|reminder|alarm)s?(?:\s|$)|"
    r"(?:play|pause|next|previous)(?:\s|$)|"
    r"music\s+(?:play|pause|stop|next|previous|mute|unmute|volume)(?:\s|$)|"
    r"lights?\s+(?:on|off|up|down)(?:\s|$)|"
    r"(?:tv|television|media)\s+(?:play|pause|stop|next|previous|mute|"
    r"unmute|volume|power)(?:\s|$))"
)
_TOP_KEYS = {"name", "description", "aliases", "steps", "enabled", "trigger",
             "announce_summary"}
_STEP_KEYS = {"type", "args", "timeout_seconds", "continue_on_error"}


def _norm(value: str) -> str:
    return " ".join(value.casefold().split())


def _now(clock) -> datetime:
    value = clock()
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


class RoutineManager:
    def __init__(
        self, db, bus, executor: Callable[[str, dict], Awaitable[dict]],
        announce: Callable[[str], Awaitable[Any]] | None = None,
        default_timezone: str = "UTC", clock=lambda: datetime.now(timezone.utc),
        poll_seconds: float = 15, staleness_seconds: int = 120,
    ) -> None:
        try:
            ZoneInfo(default_timezone)
        except ZoneInfoNotFoundError as exc:
            raise RoutineError("invalid default timezone") from exc
        self.db, self.bus, self.executor, self.announce = db, bus, executor, announce
        self.default_timezone, self.clock = default_timezone, clock
        self.poll_seconds = max(.05, float(poll_seconds))
        self.staleness_seconds = max(1, min(int(staleness_seconds), 300))
        self._active: dict[str, asyncio.Task] = {}
        self._scheduled_tasks: set[asyncio.Task] = set()
        self._active_lock = asyncio.Lock()
        self._stop = asyncio.Event()
        self._task: asyncio.Task | None = None
        self._started_at = _now(clock)

    @staticmethod
    def catalog_public() -> list[dict]:
        return catalog_public()

    def validate(self, payload: dict, allow_template_placeholders: bool = False) -> dict:
        if not isinstance(payload, dict):
            raise RoutineError("routine must be an object")
        unknown = set(payload) - _TOP_KEYS
        if unknown:
            raise RoutineError(f"unknown routine field: {sorted(unknown)[0]}")
        name = payload.get("name")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 60:
            raise RoutineError("name must be 1 to 60 characters")
        name = " ".join(name.split())
        normalized_name = _norm(name)
        if normalized_name.startswith(("run ", "start ")):
            raise RoutineError("run/start prefixes are not stored names")
        self._safe_phrase(normalized_name, "name")
        description = payload.get("description", "")
        if not isinstance(description, str) or len(description) > 300:
            raise RoutineError("description must be at most 300 characters")
        aliases = payload.get("aliases", [])
        if not isinstance(aliases, list) or len(aliases) > 10:
            raise RoutineError("aliases must be a list of at most 10")
        clean_aliases: list[str] = []
        seen = {normalized_name}
        for alias in aliases:
            if not isinstance(alias, str) or not 1 <= len(alias.strip()) <= 60:
                raise RoutineError("each alias must be 1 to 60 characters")
            clean = _norm(alias)
            if clean.startswith(("run ", "start ")):
                raise RoutineError("run/start prefixes are not stored aliases")
            self._safe_phrase(clean, "alias")
            if clean not in seen:
                clean_aliases.append(clean)
                seen.add(clean)
        steps = payload.get("steps")
        if not isinstance(steps, list) or not 1 <= len(steps) <= MAX_ACTIONS:
            raise RoutineError("steps must contain 1 to 30 actions")
        clean_steps = [self._validate_step(step, allow_template_placeholders) for step in steps]
        enabled = payload.get("enabled", False)
        if not isinstance(enabled, bool):
            raise RoutineError("enabled must be true or false")
        trigger = self._validate_trigger(payload.get("trigger"))
        announce_summary = payload.get("announce_summary", False)
        if type(announce_summary) is not bool:
            raise RoutineError("announce_summary must be true or false")
        definition = {
            "name": name, "description": description.strip(), "aliases": clean_aliases,
            "steps": clean_steps, "enabled": enabled, "trigger": trigger,
            "announce_summary": announce_summary,
        }
        if self._has_placeholders(definition) and (enabled or not allow_template_placeholders):
            raise RoutineError("replace all required template fields first")
        return definition

    def _safe_phrase(self, phrase: str, label: str) -> None:
        if phrase in _RESERVED or _DANGEROUS_PHRASE.match(phrase):
            raise RoutineError(f"{label} shadows a built-in command")

    def _validate_step(self, step: Any, placeholders: bool) -> dict:
        if not isinstance(step, dict):
            raise RoutineError("each step must be an object")
        extra = set(step) - _STEP_KEYS
        if extra:
            raise RoutineError(f"unknown step field: {sorted(extra)[0]}")
        action = step.get("type")
        if action not in ACTION_CATALOG:
            raise RoutineError("unknown action type")
        args = step.get("args", {})
        if not isinstance(args, dict):
            raise RoutineError("step args must be an object")
        spec = ACTION_CATALOG[action][1]
        extra = set(args) - set(spec)
        if extra:
            raise RoutineError(f"unknown argument for {action}: {sorted(extra)[0]}")
        clean: dict[str, Any] = {}
        for key, value in args.items():
            rule = spec[key]
            if isinstance(value, str) and value.startswith(PLACEHOLDER_PREFIX):
                if not placeholders:
                    raise RoutineError("template placeholder is not allowed")
                clean[key] = value
                continue
            if isinstance(rule, set):
                if not isinstance(value, str) or value not in rule:
                    raise RoutineError(f"invalid {key} for {action}")
            elif rule is bool:
                if type(value) is not bool:
                    raise RoutineError(f"{key} must be boolean")
            else:
                kind, low, high = rule
                if kind is int:
                    if type(value) is not int or not low <= value <= high:
                        raise RoutineError(f"{key} is out of range")
                elif key == "time":
                    if not isinstance(value, str) or not re.fullmatch(
                            r"(?:[01]\d|2[0-3]):[0-5]\d", value.strip()):
                        raise RoutineError("time must be HH:MM")
                elif not isinstance(value, str) or not low <= len(value.strip()) <= high:
                    raise RoutineError(f"{key} has invalid length")
                if kind is str:
                    value = value.strip()
                    if ("://" in value.casefold() or
                            value.casefold().startswith(("javascript:", "data:")) or
                            any(char in value for char in ("\x00", "\r", "\n"))):
                        raise RoutineError(f"{key} contains unsafe content")
            clean[key] = value
        # Require all catalog fields except intentionally optional room/query.
        optional_by_action = {
            "calendar_read": {"days", "limit"},
            "music_control": {"room"},
            "music_volume": {"room"},
            "reminder": {"message", "day"},
            "alarm": {"message", "day"},
        }
        optional = optional_by_action.get(action, set())
        missing = set(spec) - set(clean) - optional
        if missing:
            raise RoutineError(f"missing argument for {action}: {sorted(missing)[0]}")
        timeout = step.get("timeout_seconds", 30)
        if type(timeout) is not int or not 1 <= timeout <= 60:
            raise RoutineError("timeout_seconds must be 1 to 60")
        cont = step.get("continue_on_error", False)
        if type(cont) is not bool:
            raise RoutineError("continue_on_error must be boolean")
        return {"type": action, "args": clean, "timeout_seconds": timeout,
                "continue_on_error": cont}

    def _validate_trigger(self, trigger: Any) -> dict | None:
        if trigger is None:
            return None
        if not isinstance(trigger, dict) or set(trigger) - {"enabled", "time", "weekdays", "timezone"}:
            raise RoutineError("invalid trigger fields")
        if type(trigger.get("enabled", False)) is not bool:
            raise RoutineError("trigger enabled must be boolean")
        value = trigger.get("time")
        if not isinstance(value, str) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", value):
            raise RoutineError("trigger time must be HH:MM")
        days = trigger.get("weekdays")
        if not isinstance(days, list) or not days or any(type(x) is not int or not 0 <= x <= 6 for x in days):
            raise RoutineError("weekdays must contain 0 through 6")
        zone = trigger.get("timezone", self.default_timezone)
        try:
            ZoneInfo(zone)
        except (TypeError, ZoneInfoNotFoundError) as exc:
            raise RoutineError("invalid trigger timezone") from exc
        return {"enabled": trigger.get("enabled", False), "time": value,
                "weekdays": sorted(set(days)), "timezone": zone}

    @staticmethod
    def _has_placeholders(value: Any) -> bool:
        if isinstance(value, str):
            return value.startswith(PLACEHOLDER_PREFIX)
        if isinstance(value, dict):
            return any(RoutineManager._has_placeholders(v) for v in value.values())
        if isinstance(value, list):
            return any(RoutineManager._has_placeholders(v) for v in value)
        return False

    @staticmethod
    async def _collision_conn(conn, definition: dict, exclude: str | None = None) -> None:
        values = [_norm(definition["name"]), *definition["aliases"]]
        marks = ",".join("?" for _ in values)
        cursor = await conn.execute(
            f"SELECT normalized_alias FROM routine_aliases WHERE normalized_alias IN ({marks})"
            + (" AND routine_id<>?" if exclude else ""),
            tuple(values) + ((exclude,) if exclude else ()),
        )
        row = await cursor.fetchone()
        if row:
            raise RoutineError(f"name or alias already used: {row['normalized_alias']}")

    async def create_routine(self, payload: dict, *, _template: bool = False) -> dict:
        definition = self.validate(payload, allow_template_placeholders=_template)
        rid, now = "rt_" + secrets.token_hex(8), iso(_now(self.clock))
        try:
            async with self.db.transaction() as conn:
                await self._collision_conn(conn, definition)
                await conn.execute(
                    """INSERT INTO routines(id,name,normalized_name,description,enabled,current_version,
                       fence,template_draft,trigger_json,created_at,updated_at)
                       VALUES(?,?,?,?,?,1,1,?,?,?,?)""",
                    (rid, definition["name"], _norm(definition["name"]),
                     definition["description"], int(definition["enabled"]),
                     int(_template and self._has_placeholders(definition)),
                     json.dumps(definition["trigger"]) if definition["trigger"] else None,
                     now, now))
                await conn.execute(
                    """INSERT INTO routine_versions
                       (routine_id,version,definition_json,created_at) VALUES(?,1,?,?)""",
                    (rid, json.dumps(definition, separators=(",", ":")), now))
                await self._replace_aliases_conn(conn, rid, definition)
        except sqlite3.IntegrityError as exc:
            raise RoutineError("name or alias already exists") from exc
        self._publish("created", rid)
        return await self.get_routine(rid)

    @staticmethod
    async def _replace_aliases_conn(conn, rid: str, definition: dict) -> None:
        await conn.execute("DELETE FROM routine_aliases WHERE routine_id=?", (rid,))
        await conn.execute("INSERT INTO routine_aliases VALUES(?,?,1)",
                           (_norm(definition["name"]), rid))
        for alias in definition["aliases"]:
            await conn.execute("INSERT INTO routine_aliases VALUES(?,?,0)", (alias, rid))

    async def update_routine(self, routine_id: str, payload: dict,
                             expected_version: int | None = None) -> dict:
        try:
            async with self.db.transaction() as conn:
                cursor = await conn.execute(
                    """SELECT r.*,v.definition_json FROM routines r
                       JOIN routine_versions v ON v.routine_id=r.id
                       AND v.version=r.current_version
                       WHERE r.id=? AND r.deleted_at IS NULL""",
                    (routine_id,),
                )
                old = await cursor.fetchone()
                if not old:
                    raise RoutineError("routine not found")
                merged = dict(json.loads(old["definition_json"]))
                merged.update(payload)
                draft = bool(old["template_draft"])
                definition = self.validate(merged, allow_template_placeholders=draft)
                await self._collision_conn(conn, definition, routine_id)
                if (expected_version is not None and
                        expected_version != old["current_version"]):
                    raise RoutineError("routine version conflict")
                version, now = old["current_version"] + 1, iso(_now(self.clock))
                changed = await conn.execute(
                    """UPDATE routines SET name=?,normalized_name=?,description=?,enabled=?,
                       current_version=?,fence=fence+1,template_draft=?,trigger_json=?,updated_at=?
                       WHERE id=? AND current_version=? AND deleted_at IS NULL""",
                    (definition["name"], _norm(definition["name"]),
                     definition["description"], int(definition["enabled"]), version,
                     int(self._has_placeholders(definition)),
                     json.dumps(definition["trigger"]) if definition["trigger"] else None,
                     now, routine_id, old["current_version"]))
                if changed.rowcount != 1:
                    raise RoutineError("routine version conflict")
                await conn.execute(
                    "INSERT INTO routine_versions VALUES(?,?,?,?)",
                    (routine_id, version,
                     json.dumps(definition, separators=(",", ":")), now))
                await self._replace_aliases_conn(conn, routine_id, definition)
        except sqlite3.IntegrityError as exc:
            raise RoutineError("name or alias already exists") from exc
        self._publish("updated", routine_id)
        return await self.get_routine(routine_id)

    async def duplicate_routine(self, routine_id: str, name: str | None = None) -> dict:
        item = await self.get_routine(routine_id)
        definition = dict(item["definition"])
        definition["name"] = name or f"{definition['name']} copy"
        definition["aliases"], definition["enabled"] = [], False
        definition["trigger"] = None
        return await self.create_routine(definition, _template=item["template_draft"])

    async def delete_routine(self, routine_id: str) -> dict:
        now = iso(_now(self.clock))
        count = await self.db.execute(
            "UPDATE routines SET deleted_at=?,enabled=0,fence=fence+1,updated_at=? WHERE id=? AND deleted_at IS NULL",
            (now, now, routine_id))
        if not count:
            raise RoutineError("routine not found")
        await self.db.execute("DELETE FROM routine_aliases WHERE routine_id=?", (routine_id,))
        self._publish("deleted", routine_id)
        return {"id": routine_id, "deleted": True}

    async def set_enabled(self, routine_id: str, enabled: bool) -> dict:
        if type(enabled) is not bool:
            raise RoutineError("enabled must be boolean")
        row = await self._row(routine_id)
        if not row:
            raise RoutineError("routine not found")
        definition = json.loads(row["definition_json"])
        if enabled and self._has_placeholders(definition):
            raise RoutineError("replace all required template fields first")
        definition["enabled"] = enabled
        return await self.update_routine(routine_id, definition, row["current_version"])

    async def _row(self, ref: str):
        return await self.db.fetchone(
            """SELECT r.*,v.definition_json FROM routines r JOIN routine_versions v
               ON v.routine_id=r.id AND v.version=r.current_version
               WHERE r.id=? AND r.deleted_at IS NULL""", (ref,))

    async def get_routine(self, routine_id: str) -> dict:
        row = await self._row(routine_id)
        if not row:
            raise RoutineError("routine not found")
        active = await self.db.fetchone(
            "SELECT id,status,started_at,source FROM routine_runs WHERE routine_id=? AND status='running' ORDER BY started_at DESC LIMIT 1",
            (routine_id,))
        return self._public(row, active)

    async def list_routines(self) -> list[dict]:
        rows = await self.db.fetchall(
            """SELECT r.*,v.definition_json,
               ar.id AS active_id,ar.status AS active_status,
               ar.started_at AS active_started_at,ar.source AS active_source
               FROM routines r JOIN routine_versions v
               ON v.routine_id=r.id AND v.version=r.current_version
               LEFT JOIN routine_runs ar ON ar.id=(
                 SELECT id FROM routine_runs WHERE routine_id=r.id AND status='running'
                 ORDER BY started_at DESC LIMIT 1)
               WHERE r.deleted_at IS NULL ORDER BY r.normalized_name""")
        return [self._public(row, {
            "id": row["active_id"], "status": row["active_status"],
            "started_at": row["active_started_at"], "source": row["active_source"],
        } if row["active_id"] else None) for row in rows]

    @staticmethod
    def _public(row, active=None) -> dict:
        definition = json.loads(row["definition_json"])
        draft = bool(row["template_draft"])
        return {"id": row["id"], "version": row["current_version"],
                "enabled": bool(row["enabled"]), "draft": draft,
                "template_draft": draft, "updated_at": row["updated_at"],
                "validation": {"valid": not draft, "errors":
                    ([] if not draft else ["replace all required template fields"])},
                "active_run": dict(active) if active else None,
                "definition": definition, **definition}

    async def list_runs(self, routine_id: str | None = None, limit: int = 50) -> list[dict]:
        if type(limit) is not int or not 1 <= limit <= 200:
            raise RoutineError("limit must be 1 to 200")
        if routine_id is not None and not await self._row(routine_id):
            raise RoutineError("routine not found")
        rows = await self.db.fetchall(
            "SELECT * FROM routine_runs" + (" WHERE routine_id=?" if routine_id else "") +
            " ORDER BY started_at DESC LIMIT ?",
            ((routine_id, limit) if routine_id else (limit,)))
        return [await self._run_public(row, include_steps=True) for row in rows]

    async def get_run(self, run_id: str) -> dict:
        row = await self.db.fetchone("SELECT * FROM routine_runs WHERE id=?", (run_id,))
        if not row:
            raise RoutineError("run not found")
        return await self._run_public(row, include_steps=True)

    async def _run_public(self, row, include_steps: bool) -> dict:
        started = datetime.fromisoformat(row["started_at"])
        finished = datetime.fromisoformat(row["finished_at"]) if row["finished_at"] else None
        value = {
            "id": row["id"], "run_id": row["id"], "routine_id": row["routine_id"],
            "version": row["version"], "source": row["source"], "status": row["status"],
            "summary": row["summary"], "started_at": row["started_at"],
            "finished_at": row["finished_at"],
            "duration_ms": (max(0, int((finished - started).total_seconds() * 1000))
                            if finished else None),
        }
        if include_steps:
            steps = await self.db.fetchall(
                """SELECT step_index,action_type,status,duration_ms,summary
                   FROM routine_run_steps WHERE run_id=? ORDER BY step_index""",
                (row["id"],))
            value["steps"] = [dict(step) for step in steps]
        return value

    async def validate_routine(self, routine_id: str) -> dict:
        try:
            row = await self._row(routine_id)
            if not row:
                raise RoutineError("routine not found")
            self.validate(json.loads(row["definition_json"]),
                          allow_template_placeholders=bool(row["template_draft"]))
            errors = ["replace all required template fields"] if row["template_draft"] else []
            return {"valid": not errors, "errors": errors}
        except RoutineError as exc:
            return {"valid": False, "errors": [str(exc)]}

    def templates(self) -> list[dict]:
        p = lambda field: f"{PLACEHOLDER_PREFIX}{field}__"
        return [
            {"id": "good_morning", "name": "Good morning", "description": "A safe morning starter",
             "setup": [
                 "Choose the calendars to read on the Calendar page.",
                 "Choose the music and room below.",
             ],
             "aliases": [], "enabled": False, "trigger": None, "announce_summary": False, "steps": [
                 {"type": "calendar_read", "args": {"days": 1, "limit": 10}},
                 {"type": "music_play", "args": {"query": p("MUSIC"), "room": p("ROOM")}},
                 {"type": "announcement", "args": {"text": "Good morning."}}]},
            {"id": "movie_time", "name": "Movie time", "description": "Prepare a room for a movie",
             "setup": [
                 "Choose the room light below.",
                 "Choose an app already installed on your TV.",
             ],
             "aliases": [], "enabled": False, "trigger": None, "announce_summary": False, "steps": [
                 {"type": "govee_brightness", "args": {"device": p("LIGHT"), "percentage": 20}},
                 {"type": "tv_power", "args": {"state": "on"}},
                 {"type": "tv_app", "args": {"app": p("INSTALLED_TV_APP")}}]},
            {"id": "good_night", "name": "Good night", "description": "A safe bedtime starter",
             "setup": [
                 "Choose the room light below.",
                 "Choose the next wake-up time below.",
             ],
             "aliases": [], "enabled": False, "trigger": None, "announce_summary": False, "steps": [
                 {"type": "govee_power", "args": {"device": p("LIGHT"), "state": "off"}},
                 {"type": "tv_power", "args": {"state": "off"}},
                 {"type": "alarm", "args": {"time": p("WAKE_TIME"),
                                            "message": "Wake up"}}]},
        ]

    async def create_from_template(self, template_id: str) -> dict:
        template = next((x for x in self.templates() if x["id"] == template_id), None)
        if not template:
            raise RoutineError("template not found")
        payload = {k: v for k, v in template.items() if k not in {"id", "setup"}}
        return await self.create_routine(payload, _template=True)

    async def resolve_command(self, text: str) -> dict | None:
        phrase = _norm(text)
        explicit = phrase.startswith("run ") or phrase.startswith("start ")
        if explicit:
            phrase = phrase.split(" ", 1)[1].strip()
        row = await self.db.fetchone(
            """SELECT r.id FROM routine_aliases a JOIN routines r ON r.id=a.routine_id
               WHERE a.normalized_alias=? AND r.enabled=1 AND r.template_draft=0
               AND r.deleted_at IS NULL""", (phrase,))
        if not row:
            return None
        # Exact aliases are accepted; explicit prefixes add no stored alias.
        return {"routine_id": row["id"], "explicit": explicit}

    async def _resolve(self, ref: str):
        row = await self._row(ref)
        if row:
            return row
        alias = await self.db.fetchone(
            "SELECT routine_id FROM routine_aliases WHERE normalized_alias=?", (_norm(ref),))
        return await self._row(alias["routine_id"]) if alias else None

    async def run(self, routine_ref: str, source: str = "manual",
                  occurrence_key: str | None = None, dry_run: bool = False) -> dict:
        row = await self._resolve(routine_ref)
        if not row:
            raise RoutineError("routine not found")
        if dry_run:
            check = await self.validate_routine(row["id"])
            return {"dry_run": True, **check}
        if not row["enabled"] or row["template_draft"]:
            raise RoutineError("routine is disabled or incomplete")
        rid = row["id"]
        async with self._active_lock:
            if rid in self._active:
                raise RoutineError("routine is already running")
            current = asyncio.current_task()
            assert current
            self._active[rid] = current
        try:
            return await self._execute(row, source, occurrence_key)
        finally:
            async with self._active_lock:
                self._active.pop(rid, None)

    async def _execute(self, row, source: str, occurrence_key: str | None) -> dict:
        rid, run_id = row["id"], "rr_" + secrets.token_hex(10)
        started = _now(self.clock)
        if occurrence_key:
            try:
                await self.db.execute(
                    "INSERT INTO routine_trigger_claims VALUES(?,?,?,?,NULL,?)",
                    (occurrence_key, rid, iso(started), "claimed", iso(started)))
            except sqlite3.IntegrityError:
                raise RoutineError("scheduled occurrence already claimed")
        await self.db.execute(
            """INSERT INTO routine_runs(id,routine_id,version,source,occurrence_key,status,
               summary,started_at) VALUES(?,?,?,?,?,'running','',?)""",
            (run_id, rid, row["current_version"], source[:20], occurrence_key, iso(started)))
        if self.bus:
            self.bus.publish("routine_run_started", run_id=run_id, routine_id=rid,
                             status="running")
        if occurrence_key:
            await self.db.execute(
                "UPDATE routine_trigger_claims SET run_id=?,status='running' WHERE occurrence_key=?",
                (run_id, occurrence_key))
        definition = json.loads(row["definition_json"])
        failures, succeeded, terminal = 0, 0, None
        for index, step in enumerate(definition["steps"]):
            fresh = await self.db.fetchone(
                "SELECT fence,enabled,deleted_at FROM routines WHERE id=?", (rid,))
            if not fresh or fresh["fence"] != row["fence"] or not fresh["enabled"] or fresh["deleted_at"]:
                terminal = "superseded"
                await self._record_remaining(run_id, definition["steps"], index, "cancelled")
                break
            before = _now(self.clock)
            try:
                result = await asyncio.wait_for(self._invoke(step), step["timeout_seconds"])
                fresh = await self.db.fetchone("SELECT fence,enabled FROM routines WHERE id=?", (rid,))
                if not fresh or fresh["fence"] != row["fence"] or not fresh["enabled"]:
                    terminal = "superseded"
                    await self._record_step(run_id, index, step["type"], "cancelled", before, "definition changed")
                    await self._record_remaining(run_id, definition["steps"], index + 1, "cancelled")
                    break
                succeeded += 1
                await self._record_step(run_id, index, step["type"], "success", before,
                                        self._summary(result))
            except asyncio.CancelledError:
                terminal = "cancelled"
                await self._record_step(run_id, index, step["type"], "cancelled", before, "cancelled")
                await self._record_remaining(run_id, definition["steps"], index + 1, "cancelled")
                break
            except Exception as exc:
                failures += 1
                message = "timed out" if isinstance(exc, TimeoutError) else self._error(exc)
                await self._record_step(run_id, index, step["type"], "failure", before, message)
                if not step["continue_on_error"]:
                    await self._record_remaining(run_id, definition["steps"], index + 1, "skipped")
                    terminal = "failed"
                    break
        # A failure that explicitly allowed execution to continue is partial
        # even if every attempted step failed. "Failed" is reserved for a run
        # that actually stopped at a failure.
        status = terminal or ("partial" if failures else "completed")
        summary = {
            "completed": "Routine completed.", "partial": "Routine completed with some failures.",
            "failed": "Routine stopped after a failure.", "cancelled": "Routine was cancelled.",
            "superseded": "Routine stopped because it was changed or disabled.",
        }[status]
        finished = iso(_now(self.clock))
        await self.db.execute("UPDATE routine_runs SET status=?,summary=?,finished_at=? WHERE id=?",
                              (status, summary, finished, run_id))
        if occurrence_key:
            await self.db.execute("UPDATE routine_trigger_claims SET status=? WHERE occurrence_key=?",
                                  (status, occurrence_key))
        await self._trim(rid)
        if self.bus:
            self.bus.publish("routine_run_finished", run_id=run_id, routine_id=rid,
                             status=status,
                             duration_ms=max(0, int((_now(self.clock) - started).total_seconds() * 1000)))
        if definition.get("announce_summary") and status in {"completed", "partial", "failed"}:
            if self.announce:
                try:
                    value = self.announce(summary)
                    if inspect.isawaitable(value):
                        await value
                except Exception:
                    pass
        return {"run_id": run_id, "routine_id": rid, "version": row["current_version"],
                "status": status, "summary": summary}

    async def _invoke(self, step: dict) -> dict:
        action, args = step["type"], dict(step["args"])
        if action == "wait":
            await asyncio.sleep(args["seconds"])
            return {"waited": args["seconds"]}
        if action == "announcement":
            if not self.announce:
                raise RoutineError("announcements are not available")
            value = self.announce(args["text"])
            if inspect.isawaitable(value):
                await value
            return {"announced": True}
        tool = ACTION_TO_TOOL[action]
        assert tool
        if action in {"reminder", "alarm"}:
            hour, minute = map(int, args.pop("time").split(":"))
            args["hour"], args["minute"] = hour, minute
            args["kind"] = action
            args["day"] = args.get("day", "")
        result = await self.executor(tool, args)
        if isinstance(result, dict) and result.get("needs_confirmation"):
            raise _StepResultError("confirmation required")
        if isinstance(result, dict) and result.get("error"):
            raise _StepResultError("tool reported an error")
        return result if isinstance(result, dict) else {"ok": True}

    async def _record_step(self, run_id, index, action, status, before, summary) -> None:
        duration = max(0, int((_now(self.clock) - before).total_seconds() * 1000))
        await self.db.execute("INSERT INTO routine_run_steps VALUES(?,?,?,?,?,?)",
                              (run_id, index, action, status, duration, str(summary)[:200]))
        if self.bus:
            routine = await self.db.fetchone(
                "SELECT routine_id FROM routine_runs WHERE id=?", (run_id,))
            self.bus.publish("routine_run_progress", run_id=run_id,
                             routine_id=routine["routine_id"] if routine else "",
                             step_index=index, status=status, duration_ms=duration)

    async def _record_remaining(self, run_id, steps, start, status) -> None:
        for index in range(start, len(steps)):
            await self._record_step(run_id, index, steps[index]["type"], status,
                                    _now(self.clock), status)

    @staticmethod
    def _summary(result: dict) -> str:
        # Tool results can contain provider and configuration data even in a
        # friendly-looking summary field. Never persist any of it.
        return "completed"

    @staticmethod
    def _error(exc: Exception) -> str:
        # Provider exceptions can contain request bodies, device identifiers,
        # URLs, or credentials. Persist only the exception category.
        if isinstance(exc, _StepResultError):
            return str(exc)
        return "action failed"

    async def _trim(self, rid: str) -> None:
        await self.db.execute(
            """DELETE FROM routine_runs WHERE routine_id=? AND id NOT IN
               (SELECT id FROM routine_runs WHERE routine_id=? ORDER BY started_at DESC LIMIT 200)""",
            (rid, rid))

    def _publish(self, change: str, rid: str) -> None:
        if self.bus:
            self.bus.publish("routines_changed", change=change[:20], routine_id=rid[:40])

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._started_at = _now(self.clock)
        finished = iso(self._started_at)
        await self.db.execute(
            """UPDATE routine_runs SET status='interrupted',
               summary='Routine was interrupted by a restart.',finished_at=?
               WHERE status='running'""", (finished,))
        await self.db.execute(
            """UPDATE routine_trigger_claims SET status='interrupted'
               WHERE status IN ('claimed','running')""")
        await self.db.execute(
            "DELETE FROM routine_trigger_claims WHERE created_at<?",
            (iso(self._started_at - timedelta(days=400)),),
        )
        self._stop.clear()
        self._task = asyncio.create_task(self._scheduler(), name="routine-scheduler")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None
        tasks = list(set(self._active.values()) | self._scheduled_tasks)
        for task in tasks:
            if task is not asyncio.current_task():
                task.cancel()
        if tasks:
            await asyncio.gather(*(t for t in tasks if t is not asyncio.current_task()),
                                 return_exceptions=True)
        self._scheduled_tasks.clear()

    async def _scheduler(self) -> None:
        while not self._stop.is_set():
            try:
                await self.tick()
            except Exception:
                await self.db.log("WARNING", "routines", "routine scheduler tick failed")
            await asyncio.sleep(self.poll_seconds)

    def _scheduled_done(self, task: asyncio.Task) -> None:
        self._scheduled_tasks.discard(task)
        if not task.cancelled():
            try:
                task.exception()
            except Exception:
                pass

    async def _run_scheduled(self, routine_id: str, key: str) -> None:
        try:
            await self.run(routine_id, source="schedule", occurrence_key=key)
        except RoutineError as exc:
            if "already claimed" not in str(exc) and "already running" not in str(exc):
                raise

    async def tick(self) -> None:
        now = _now(self.clock)
        for item in await self.list_routines():
            trigger = item["trigger"]
            if not item["enabled"] or item["draft"] or not trigger or not trigger["enabled"]:
                continue
            zone = ZoneInfo(trigger["timezone"])
            local = now.astimezone(zone)
            if local.weekday() not in trigger["weekdays"]:
                continue
            hour, minute = map(int, trigger["time"].split(":"))
            wall = datetime(local.year, local.month, local.day, hour, minute)
            # For a DST fold choose the first occurrence deterministically. A
            # nonexistent wall time (spring-forward gap) is skipped, never
            # shifted into a surprising household action.
            due_local = wall.replace(tzinfo=zone, fold=0)
            if due_local.astimezone(timezone.utc).astimezone(zone).replace(
                    tzinfo=None) != wall:
                continue
            due = due_local.astimezone(timezone.utc)
            age = (now - due).total_seconds()
            if due < self._started_at or age < 0:
                continue
            key = f"{item['id']}:{due_local.date()}:{trigger['time']}:{trigger['timezone']}"
            if age > self.staleness_seconds:
                await self._claim_stale(item["id"], key, due)
                continue
            try:
                task = asyncio.create_task(
                    self._run_scheduled(item["id"], key),
                    name=f"routine-schedule-{item['id']}")
                self._scheduled_tasks.add(task)
                task.add_done_callback(self._scheduled_done)
            except RoutineError:
                # Resolution errors are isolated to this configured routine.
                continue

    async def _claim_stale(self, rid: str, key: str, due: datetime) -> None:
        try:
            await self.db.execute(
                "INSERT INTO routine_trigger_claims VALUES(?,?,?,'skipped_stale',NULL,?)",
                (key, rid, iso(due), iso(_now(self.clock))))
        except sqlite3.IntegrityError:
            pass