"""Durable meeting-alert and morning-briefing scheduler."""

from __future__ import annotations

import asyncio
import inspect
import json
import sqlite3
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from chat_core.events import EventBus
from chat_core.models.credentials import iso, parse_iso
from chat_core.models.db import Database


class SchedulerError(ValueError):
    pass


def _time(value: str) -> time:
    try:
        return time.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise SchedulerError("briefing time must be HH:MM") from exc


class CalendarScheduler:
    def __init__(self, db: Database, calendar, announce, bus: EventBus | None = None,
                 weather=None, news=None, is_busy=lambda: False, is_quiet=lambda: False,
                  clock=lambda: datetime.now(timezone.utc), staleness_seconds: int = 120,
                  poll_seconds: float = 15, default_timezone: str = "UTC",
                  on_timezone_change=None) -> None:
        self.db, self.calendar, self.announce, self.bus = db, calendar, announce, bus
        self.weather, self.news = weather, news
        self.is_busy, self.is_quiet, self.clock = is_busy, is_quiet, clock
        self.default_timezone = default_timezone
        self.on_timezone_change = on_timezone_change
        self.grace, self.poll_seconds = max(30, min(staleness_seconds, 300)), poll_seconds
        self._stop, self._task = asyncio.Event(), None
        self._started_at = self.clock().astimezone(timezone.utc)

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._started_at = self.clock().astimezone(timezone.utc)
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="calendar-scheduler")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None

    async def _run(self) -> None:
        while not self._stop.is_set():
            try:
                await self.tick()
            except Exception:
                await self.db.log("WARNING", "calendar_scheduler", "scheduler tick failed")
            await asyncio.sleep(self.poll_seconds)

    async def get_preferences(self) -> dict:
        row = await self.db.fetchone("SELECT * FROM briefing_preferences WHERE id=1")
        if not row:
            return {"timezone": self.default_timezone, "meeting_alert_enabled": False,
                    "meeting_lead_minutes": 10, "briefing_enabled": False,
                    "briefing_time": "08:00", "weekdays": [0, 1, 2, 3, 4],
                    "sections": ["calendar", "weather", "news"]}
        return {"timezone": row["timezone"],
                "meeting_alert_enabled": bool(row["meeting_alert_enabled"]),
                "meeting_lead_minutes": row["meeting_lead_minutes"],
                "briefing_enabled": bool(row["briefing_enabled"]),
                "briefing_time": row["briefing_time"],
                "weekdays": json.loads(row["weekdays"]),
                "sections": json.loads(row["sections"])}

    async def set_combined_preferences(
        self, *, timezone_name: str, meeting_alert_enabled: bool,
        meeting_lead_minutes: int, briefing_enabled: bool, briefing_time: str,
        weekdays: list[int], sections: list[str]
    ) -> dict:
        try:
            ZoneInfo(timezone_name)
        except ZoneInfoNotFoundError as exc:
            raise SchedulerError("invalid timezone") from exc
        _time(briefing_time)
        lead = int(meeting_lead_minutes)
        if not 1 <= lead <= 120:
            raise SchedulerError("meeting lead must be 1 to 120 minutes")
        days = sorted(set(weekdays))
        if any(not isinstance(day, int) or not 0 <= day <= 6 for day in days):
            raise SchedulerError("weekdays must contain 0 through 6")
        clean = list(dict.fromkeys(x for x in sections
                                   if x in ("calendar", "weather", "news")))
        await self.db.execute(
            """INSERT INTO briefing_preferences
               (id,timezone,meeting_alert_enabled,meeting_lead_minutes,briefing_enabled,
                briefing_time,weekdays,sections,updated_at) VALUES(1,?,?,?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET timezone=excluded.timezone,
               meeting_alert_enabled=excluded.meeting_alert_enabled,
               meeting_lead_minutes=excluded.meeting_lead_minutes,
               briefing_enabled=excluded.briefing_enabled,
               briefing_time=excluded.briefing_time,weekdays=excluded.weekdays,
               sections=excluded.sections,updated_at=excluded.updated_at""",
            (timezone_name, int(meeting_alert_enabled), lead, int(briefing_enabled),
             briefing_time, json.dumps(days), json.dumps(clean), iso(self.clock())))
        if self.on_timezone_change:
            changed = self.on_timezone_change(timezone_name)
            if inspect.isawaitable(changed):
                await changed
        return await self.get_preferences()

    async def _bool(self, callback) -> bool:
        value = callback()
        return bool(await value) if inspect.isawaitable(value) else bool(value)

    async def _claim(self, key: str, kind: str, scheduled: datetime, status: str) -> bool:
        try:
            await self.db.execute(
                "INSERT INTO briefing_runs(dedup_key,kind,scheduled_for,status,created_at) VALUES(?,?,?,?,?)",
                (key, kind, iso(scheduled), status, iso(self.clock())))
            await self.db.execute(
                """DELETE FROM briefing_runs WHERE created_at<?
                   AND dedup_key NOT IN (
                     SELECT dedup_key FROM briefing_runs ORDER BY created_at DESC LIMIT 2000
                   )""",
                (iso(self.clock() - timedelta(days=90)),),
            )
            return True
        except sqlite3.IntegrityError:
            return False

    async def _finish(self, key: str, status: str) -> None:
        await self.db.execute(
            "UPDATE briefing_runs SET status=?,finished_at=? WHERE dedup_key=?",
            (status, iso(self.clock()), key))

    async def _due(self, key: str, kind: str, scheduled: datetime, text_factory) -> None:
        # Quiet runs are claimed permanently. Busy runs remain unclaimed only
        # while tick's short staleness window permits a retry.
        if await self._bool(self.is_quiet):
            if await self._claim(key, kind, scheduled, "suppressed_quiet"):
                await self._finish(key, "suppressed_quiet")
            return
        if await self._bool(self.is_busy):
            return
        if not await self._claim(key, kind, scheduled, "running"):
            return
        try:
            text = text_factory()
            if inspect.isawaitable(text):
                text = await text
            await self.announce(str(text)[:2000])
            await self._finish(key, "announced")
            if self.bus:
                self.bus.publish("calendar_schedule_run", kind=kind, status="announced")
            await self.db.log("INFO", "calendar_scheduler", f"{kind} announced")
        except Exception:
            await self._finish(key, "failed")
            raise

    async def tick(self) -> None:
        pref = await self.get_preferences()
        now = self.clock().astimezone(timezone.utc)
        local = now.astimezone(ZoneInfo(pref["timezone"]))
        if pref["briefing_enabled"] and local.weekday() in pref["weekdays"]:
            local_due = datetime.combine(local.date(), _time(pref["briefing_time"]),
                                         ZoneInfo(pref["timezone"]))
            due = local_due.astimezone(timezone.utc)
            if self._started_at <= due <= now <= due + timedelta(seconds=self.grace):
                key = f"briefing:{local_due.date()}:{pref['timezone']}:{pref['briefing_time']}"
                await self._due(key, "morning_briefing", due,
                                lambda: self._briefing(pref, now))
        if pref["meeting_alert_enabled"]:
            lead = int(pref["meeting_lead_minutes"])
            events = await self.calendar.list_events(
                now, now + timedelta(minutes=lead, seconds=self.grace))
            for event in events:
                if event.all_day or event.status == "cancelled":
                    continue
                starts = parse_iso(event.start_at)
                if not starts:
                    continue
                due = starts.astimezone(timezone.utc) - timedelta(minutes=lead)
                if self._started_at <= due <= now <= due + timedelta(seconds=self.grace):
                    key = f"meeting:{event.calendar_id}:{event.id}:{event.start_at}:{lead}"
                    await self._due(key, "meeting_alert", due,
                        lambda event=event: f"Your meeting {event.title} starts in {lead} minutes.")

    async def run_briefing(self, sections: list[str] | None = None) -> dict:
        """Build one on-demand briefing without scheduling or announcing it.

        Routines use this shared boundary so they get the same bounded
        calendar/weather/news behavior as the scheduled morning briefing.
        Speaking remains a separate, explicitly configured routine action.
        """
        pref = await self.get_preferences()
        if sections is not None:
            if not isinstance(sections, list):
                raise SchedulerError("briefing sections must be a list")
            clean = list(dict.fromkeys(
                section for section in sections
                if section in ("calendar", "weather", "news")
            ))
            if len(clean) != len(sections):
                raise SchedulerError("unsupported briefing section")
            pref = dict(pref)
            pref["sections"] = clean
        summary = await self._briefing(pref, self.clock().astimezone(timezone.utc))
        return {"summary": summary, "sections": list(pref["sections"])}

    async def _briefing(self, pref: dict, now: datetime) -> str:
        parts = ["Good morning."]
        if "calendar" in pref["sections"]:
            events = await self.calendar.list_events(now, now + timedelta(days=1))
            parts.append(f"You have {len(events)} calendar event"
                         f"{'s' if len(events) != 1 else ''} today.")
            if events:
                parts.append(f"First is {events[0].title}.")
        if "weather" in pref["sections"] and self.weather:
            try:
                value = await self.weather()
                parts.append(str(value.get("summary") if isinstance(value, dict) else value)[:500])
            except Exception:
                parts.append("Weather is unavailable right now.")
        if "news" in pref["sections"] and self.news:
            try:
                value = await self.news()
                if isinstance(value, dict):
                    items = value.get("results") or value.get("items") or []
                    titles = [str(item.get("title")) for item in items[:3]
                              if isinstance(item, dict) and item.get("title")]
                    if titles:
                        parts.append("Headlines: " + "; ".join(titles) + ".")
                elif value:
                    parts.append(str(value)[:500])
            except Exception:
                parts.append("News is unavailable right now.")
        return " ".join(part for part in parts if part)