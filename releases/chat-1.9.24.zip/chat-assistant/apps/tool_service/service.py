"""Local tool service: validates and executes allowlisted tool calls from
Gemini, the local grammar, or the dashboard command box. Records sanitized
outcomes only -- never spoken content."""

from __future__ import annotations

import logging
import uuid
from typing import Callable

from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore, iso, utcnow
from chat_core.models.db import Database
from apps.tool_service.media_tool import MediaError, media_control
from apps.tool_service.reminders import ReminderError, ReminderManager
from apps.tool_service.timers import TimerError, TimerManager
from integrations.govee.client import (
    GoveeClient,
    GoveeError,
    canonical_color,
    validate_percentage,
)
from integrations.lg_webos import WebOSTVError
from integrations.weather import WeatherError
from integrations.web_search import WebSearchError
from integrations.youtube import YouTubeAPIError
from apps.tool_service.youtube_tool import YouTubeError
from apps.tool_service.music_tool import MusicError
from chat_core.music import LocalMusicLibraryError
from integrations.spotify import SpotifyError
from integrations.google_calendar import GoogleCalendarError
from apps.tool_service.calendar_tool import CalendarToolError
from apps.tool_service.routines import RoutineError

log = logging.getLogger("tools")

CONFIRM_TIMER_SECONDS = 4 * 3600
MAX_MEMORIES = 500
MAX_MEMORY_CHARS = 500


class ToolError(Exception):
    """Invalid arguments for a local tool (safe to show the user)."""


class ToolService:
    def __init__(
        self,
        db: Database,
        bus: EventBus,
        timers: TimerManager,
        credentials: CredentialStore,
        on_stop: Callable[[], None] | None = None,
        reminders: ReminderManager | None = None,
        weather=None,      # object with async get(day) -> dict
        web=None,          # read-only current-time, search, and news tools
        youtube=None,      # official YouTube search + dashboard player controller
        music=None,        # room-aware Spotify/YouTube/local coordinator
        tv=None,           # optional LG webOS TV manager (allowlisted commands only)
        calendar=None,     # Google Calendar manager (cache reads + reviewed writes)
        briefing=None,     # shared calendar/weather/news briefing builder
        routines=None,     # bounded versioned routine manager
        on_quiet=None,     # async callable(enabled: bool)
        on_end_session: Callable[[], None] | None = None,
    ) -> None:
        self.db = db
        self.bus = bus
        self.timers = timers
        self.credentials = credentials
        self.on_stop = on_stop
        self.reminders = reminders
        self.weather = weather
        self.web = web
        self.youtube = youtube
        self.music = music
        self.tv = tv
        self.calendar = calendar
        self.briefing = briefing
        self.routines = routines
        self.on_quiet = on_quiet
        self.on_end_session = on_end_session
        self._devices_cache: list[dict] = []

    # ------------------------------------------------------------------
    async def _govee(self) -> GoveeClient | None:
        for cred in await self.credentials.list(provider="govee"):
            if cred.status in ("active", "standby"):
                try:
                    key = await self.credentials.get_secret(cred.id)
                except KeyError:
                    continue
                return GoveeClient(key)
        return None

    async def devices(self, refresh: bool = False) -> list[dict]:
        if self._devices_cache and not refresh:
            return self._devices_cache
        client = await self._govee()
        if client is None:
            return []
        self._devices_cache = await client.list_devices()
        return self._devices_cache

    async def _resolve_device(self, name: str) -> dict:
        name = str(name or "").strip().lower()
        if not name:
            raise GoveeError("device name required")
        devices = await self.devices()
        if not devices:
            raise GoveeError("no Govee devices available (is a Govee API key saved?)")
        for d in devices:
            if str(d["name"]).lower() == name or str(d["device"]).lower() == name:
                return d
        # fuzzy: substring match, e.g. "desk" -> "Desk Light"
        matches = [d for d in devices if name in str(d["name"]).lower()]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise GoveeError(f"'{name}' matches multiple devices; be more specific")
        raise GoveeError(f"no device named '{name}'")

    # ------------------------------------------------------------------
    async def dispatch(self, call_id: str, name: str, args: dict) -> dict:
        """Single entry point for every tool call. Validates against the
        allowlist and returns a JSON-safe result dict."""
        try:
            result = await self._dispatch_inner(name, args or {})
            await self.db.usage(None, f"tool:{name}", "ok")
            return result
        except (
            TimerError, GoveeError, ToolError, ReminderError, WeatherError, WebSearchError,
            MediaError, YouTubeError, YouTubeAPIError, WebOSTVError,
            GoogleCalendarError, CalendarToolError, MusicError, SpotifyError,
            LocalMusicLibraryError, RoutineError, ValueError, LookupError,
        ) as exc:
            await self.db.usage(None, f"tool:{name}", f"rejected: {exc}")
            return {"error": str(exc)}
        except Exception as exc:  # sanitized failure
            log.warning("tool %s failed: %s", name, type(exc).__name__)
            await self.db.usage(None, f"tool:{name}", f"failed: {type(exc).__name__}")
            return {"error": "tool execution failed"}

    async def _dispatch_inner(self, name: str, args: dict) -> dict:
        if name == "start_timer":
            seconds = args.get("duration_seconds")
            confirmed = bool(args.get("confirmed"))
            try:
                seconds_int = int(seconds)
            except (TypeError, ValueError) as exc:
                raise TimerError("duration must be a number of seconds") from exc
            if seconds_int > CONFIRM_TIMER_SECONDS and not confirmed:
                return {
                    "needs_confirmation": True,
                    "message": f"That's over {CONFIRM_TIMER_SECONDS // 3600} hours. Ask the user to confirm, then retry with confirmed=true.",
                }
            return await self.timers.start_timer(seconds_int, args.get("label", ""))

        if name == "list_timers":
            return {"timers": await self.timers.list_timers()}

        if name == "cancel_timer":
            return await self.timers.cancel_timer(args.get("timer_id", ""))

        if name == "pause_timer":
            return await self.timers.pause_timer(args.get("timer_id", ""))

        if name == "resume_timer":
            return await self.timers.resume_timer(args.get("timer_id", ""))

        if name == "set_govee_power":
            state = str(args.get("state", "")).strip().lower()
            if state not in ("on", "off"):
                raise GoveeError("state must be 'on' or 'off'")
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_power(device["sku"], device["device"], state == "on")
            return {"device": device["name"], "power": state}

        if name == "set_govee_brightness":
            pct = validate_percentage(args.get("percentage"))
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_brightness(device["sku"], device["device"], pct)
            return {"device": device["name"], "brightness": pct}

        if name == "set_govee_color":
            color = canonical_color(args.get("color"))
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_color(device["sku"], device["device"], color)
            return {"device": device["name"], "color": color}

        if name == "activate_govee_scene":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            scene = str(args.get("scene", "")).strip()
            if not scene or len(scene) > 60:
                raise GoveeError("invalid scene name")
            await client.activate_scene(device["sku"], device["device"], scene)
            return {"device": device["name"], "scene": scene}

        if name == "get_govee_status":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            state = await client.get_state(device["sku"], device["device"])
            return {"device": device["name"], "state": state.get("payload", state)}

        if name in ("stop_speaking", "stop_output"):
            if self.on_stop:
                self.on_stop()
            return {"stopped": True}

        if name == "end_voice_session":
            if self.on_stop:
                self.on_stop()
            if self.on_end_session:
                self.on_end_session()
            return {"stopped": True, "session_ended": True}

        if name == "set_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return await self.reminders.set_reminder(
                message=str(args.get("message", "")),
                hour=args.get("hour"),
                minute=args.get("minute", 0),
                ampm=str(args.get("ampm", "")),
                day=str(args.get("day", "")),
                kind=str(args.get("kind", "reminder")),
                at_local=str(args.get("at_local", "")),
            )

        if name == "list_reminders":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return {"reminders": await self.reminders.list_reminders()}

        if name == "cancel_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            ref = str(args.get("ref", "") or args.get("reminder_id", ""))
            return await self.reminders.cancel_reminder(ref)

        if name == "get_weather":
            if self.weather is None:
                raise ToolError("weather is not available")
            return await self.weather.get(str(args.get("day", "today")))

        if name == "get_current_time":
            if self.web is None:
                raise ToolError("current time is not available")
            return self.web.current_time()

        if name == "search_web":
            if self.web is None:
                raise ToolError("web search is not available")
            return await self.web.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "get_latest_news":
            if self.web is None:
                raise ToolError("news search is not available")
            return await self.web.news(
                args.get("query", ""), args.get("max_results", 6)
            )

        if name == "set_quiet_mode":
            if self.on_quiet is None:
                raise ToolError("quiet mode is not available")
            enabled = bool(args.get("enabled"))
            await self.on_quiet(enabled)
            return {"quiet": enabled}

        if name == "get_briefing":
            if self.briefing is None:
                raise ToolError("briefings are not available")
            sections = args.get("sections")
            return await self.briefing.run_briefing(sections)

        if name == "list_routines":
            if self.routines is None:
                raise ToolError("routines are not available")
            routines = await self.routines.list_routines()
            public = [
                {
                    "id": item["id"],
                    "name": item["name"],
                    "aliases": item["aliases"],
                    "enabled": item["enabled"],
                    "complete": not item["template_draft"],
                }
                for item in routines
            ]
            names = [item["name"] for item in public if item["enabled"] and item["complete"]]
            return {
                "routines": public,
                "summary": (
                    "Available routines: " + ", ".join(names)
                    if names else "There are no enabled, complete routines."
                ),
            }

        if name == "run_routine":
            if self.routines is None:
                raise ToolError("routines are not available")
            ref = str(args.get("routine", "")).strip()
            if not ref:
                raise RoutineError("routine name is required")
            result = await self.routines.run(ref, source=str(args.get("source", "assistant")))
            return {**result, "summary": result["summary"]}

        if name == "list_calendar_events":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            return await self.calendar.upcoming(
                days=args.get("days", 14), limit=args.get("limit", 20)
            )

        if name == "get_next_meeting":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            return await self.calendar.next_meeting()

        if name == "create_calendar_event":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            draft_id = str(args.get("draft_id", "")).strip()
            if draft_id:
                result = await self.calendar.confirm_appointment(
                    draft_id, bool(args.get("confirmed"))
                )
                event = result.get("event") or {}
                result["summary"] = (
                    f"Created {event.get('title', 'the appointment')} "
                    f"for {event.get('start_at', 'the confirmed time')}."
                )
                return result
            if bool(args.get("confirmed")):
                raise CalendarToolError("review the appointment before confirming it")
            result = await self.calendar.review_appointment(
                title=str(args.get("title", "")),
                start_local=str(args.get("start_local", "")),
                duration_minutes=args.get("duration_minutes"),
                calendar_id=str(args.get("calendar_id", "")).strip() or None,
                timezone_name=str(args.get("timezone", "")).strip() or None,
            )
            draft = result["draft"]
            result.update({
                "needs_confirmation": True,
                "summary": (
                    f"Please confirm: {draft['title']} on {draft['when']} "
                    f"in {draft['calendar_name']}."
                ),
            })
            return result

        if name == "confirm_calendar_event":
            if self.calendar is None:
                raise ToolError("Google Calendar is not available")
            draft_id = str(args.get("draft_id", "")).strip()
            if not draft_id:
                raise CalendarToolError("there is no reviewed appointment to confirm")
            result = await self.calendar.confirm_appointment(draft_id, True)
            event = result.get("event") or {}
            result["summary"] = (
                f"Created {event.get('title', 'the appointment')} "
                f"for {event.get('start_at', 'the confirmed time')}."
            )
            return result

        if name == "search_music":
            if self.music is None:
                raise ToolError("music is not available")
            return {
                "results": await self.music.search(
                    args.get("query", ""),
                    provider=args.get("provider", "auto"),
                    kind=args.get("kind", "any"),
                    max_results=args.get("max_results", 10),
                )
            }

        if name == "play_music":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.play(
                item_id=str(args.get("item_id", "")).strip() or None,
                query=str(args.get("query", "")).strip() or None,
                provider=str(args.get("provider", "")).strip() or None,
                room=str(args.get("room", "")).strip() or None,
                favorites=bool(args.get("favorites")),
                playlist_name=str(args.get("playlist_name", "")).strip() or None,
                provider_playlist_id=(
                    str(args.get("provider_playlist_id", "")).strip() or None
                ),
            )

        if name == "control_music":
            if self.music is None:
                raise ToolError("music is not available")
            action = str(args.get("action", "")).strip().lower()
            if action == "mute":
                return await self.music.mute(
                    True, room=str(args.get("room", "")).strip() or None
                )
            if action == "unmute":
                return await self.music.mute(
                    False, room=str(args.get("room", "")).strip() or None
                )
            return await self.music.control(
                action, room=str(args.get("room", "")).strip() or None
            )

        if name == "seek_music":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.seek(
                args.get("offset_seconds"),
                room=str(args.get("room", "")).strip() or None,
            )

        if name == "set_music_volume":
            if self.music is None:
                raise ToolError("music is not available")
            return await self.music.set_volume(
                percentage=args.get("percentage"),
                delta=args.get("delta"),
                room=str(args.get("room", "")).strip() or None,
            )

        if name == "manage_music_queue":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_queue(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            return {"queue": result} if isinstance(result, list) else result

        if name == "manage_music_favorites":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_favorites(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"favorites": result} if action in {"list", "get"} else result

        if name == "manage_music_playlist":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.manage_playlist(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"playlists": result} if action in {"list", "all"} else result

        if name == "configure_music_room":
            if self.music is None:
                raise ToolError("music is not available")
            result = await self.music.configure_room(
                str(args.get("action", "")), **{
                    key: value for key, value in args.items() if key != "action"
                }
            )
            action = str(args.get("action", "")).lower()
            return {"rooms": result} if action in {"list", "rooms"} else result

        if name == "search_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "play_youtube":
            # All production play_youtube requests route through YouTubeTool.
            # If a Media page owns the lease, the official embedded player runs
            # the video.  If no embedded owner is available, YouTubeTool opens
            # the selected canonical https watch URL in the host computer's
            # default browser (webbrowser.open_new_tab) — never a shell command,
            # never an arbitrary URL.  The 101/150 embed-error fallback is a
            # separate authenticated CSRF-protected endpoint on the Media page.
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            video = str(args.get("video", "") or args.get("video_id", "")).strip()
            query = str(args.get("query", "")).strip()
            url = str(args.get("url", "")).strip()
            title = str(args.get("title", "")).strip()
            playlist_url = str(args.get("playlist_url", "")).strip()
            playlist_id = str(args.get("playlist_id", "")).strip()
            playlist_query = str(args.get("playlist_query", "")).strip()
            # Playlist request takes precedence over ordinary video args.
            if playlist_url or playlist_id or playlist_query:
                return await self.youtube.play_playlist(
                    playlist_id=playlist_id,
                    playlist_url=playlist_url,
                    query=playlist_query,
                    title=title,
                )
            if url:
                return await self.youtube.play_url(url, title)
            if query:
                return await self.youtube.play_query(query, title)
            # Direct video_id / resume
            return await self.youtube.play(video, title)

        if name == "play_playlist":
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            return await self.youtube.play_playlist(
                playlist_id=str(args.get("playlist_id", "")).strip(),
                playlist_url=str(args.get("playlist_url", "")).strip(),
                query=str(args.get("playlist_query", "") or args.get("query", "")).strip(),
                title=str(args.get("title", "")).strip(),
            )

        if name == "pause_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.pause_media()

        if name == "stop_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.stop_media()

        if name == "seek_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.seek_media(args.get("offset_seconds"))

        if name == "restart_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.restart_media()

        if name == "set_youtube_volume":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            if "delta" in args and args.get("percentage") is None:
                return await self.youtube.adjust_volume(args.get("delta"))
            if args.get("percentage") is not None:
                return await self.youtube.set_volume(args.get("percentage"))
            if args.get("delta") is not None:
                return await self.youtube.adjust_volume(args.get("delta"))
            raise ToolError("provide a volume percentage or a relative change")

        if name == "mute_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.set_muted(True)

        if name == "unmute_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.set_muted(False)

        if name == "next_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.next()

        if name == "previous_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.previous()

        if name == "media_control":
            action = str(args.get("action", "")).strip()
            if not action:
                raise MediaError("action is required (play, pause, stop, next, previous)")
            return media_control(action)

        if name == "remember_fact":
            return await self.remember(str(args.get("content", "")), source=str(args.get("source", "voice")))

        if name == "recall_memories":
            return await self.recall(str(args.get("query", "")))

        if name == "forget_memory":
            return await self.forget(str(args.get("query", "")))

        if name.startswith("tv_"):
            return await self._dispatch_tv(name, args)

        raise GoveeError(f"unknown tool: {name}")  # not on the allowlist

    async def _dispatch_tv(self, name: str, args: dict) -> dict:
        """LG TV tools.  Every action is a narrow allowlisted method on the
        manager -- raw webOS URIs or payloads are impossible from here."""
        tv = self.tv
        if tv is None:
            raise ToolError("TV control is not available")

        if name == "tv_power":
            state = str(args.get("state", "")).strip().lower()
            if state == "on":
                return await tv.power_on()
            if state == "off":
                return await tv.power_off()
            raise WebOSTVError("state must be 'on' or 'off'")

        if name == "tv_set_volume":
            percentage = args.get("percentage")
            delta = args.get("delta")
            return await tv.set_volume(percentage=percentage, delta=delta)

        if name == "tv_mute":
            muted = args.get("muted")
            if not isinstance(muted, bool):
                raise WebOSTVError("muted must be true or false")
            return await tv.set_mute(muted)

        if name == "tv_media":
            return await tv.media(str(args.get("action", "")))

        if name == "tv_button":
            return await tv.button(str(args.get("button", "")))

        if name == "tv_type_text":
            text = args.get("text")
            if not isinstance(text, str) or not text.strip():
                raise WebOSTVError("text is required")
            return await tv.type_text(text, submit=bool(args.get("submit")))

        if name == "tv_set_input":
            return await tv.set_input(str(args.get("input", "")))

        if name == "tv_launch_app":
            return await tv.launch_app(str(args.get("app", "")))

        if name == "tv_search_apps":
            return tv.search_apps(str(args.get("query", "")))

        if name == "tv_status":
            return tv.status()

        raise GoveeError(f"unknown tool: {name}")  # not on the allowlist

    # -- persistent memory -------------------------------------------------
    async def remember(self, content: str, source: str = "voice") -> dict:
        content = " ".join(content.split()).strip()
        if not content:
            raise ToolError("nothing to remember")
        if len(content) > MAX_MEMORY_CHARS:
            content = content[:MAX_MEMORY_CHARS]
        mem_id = uuid.uuid4().hex[:12]
        await self.db.execute(
            "INSERT INTO memories (id, content, source, created_at) VALUES (?, ?, ?, ?)",
            (mem_id, content, source[:20], iso(utcnow())),
        )
        # cap total memories: oldest fall off
        await self.db.execute(
            "DELETE FROM memories WHERE id NOT IN "
            "(SELECT id FROM memories ORDER BY created_at DESC, id DESC LIMIT ?)",
            (MAX_MEMORIES,),
        )
        self.bus.publish("memories_changed", action="added")
        return {"remembered": content, "id": mem_id}

    async def recall(self, query: str = "", limit: int = 20) -> dict:
        query = " ".join(query.split()).strip()
        if query:
            words = [w for w in query.lower().split() if len(w) > 1][:8]
            if words:
                clause = " OR ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content, created_at FROM memories WHERE {clause} "
                    "ORDER BY created_at DESC, id DESC LIMIT ?",
                    tuple(f"%{w}%" for w in words) + (limit,),
                )
            else:
                rows = []
        else:
            rows = await self.db.fetchall(
                "SELECT id, content, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT ?",
                (limit,),
            )
        memories = [dict(r) for r in rows]
        return {"memories": memories, "count": len(memories)}

    async def forget(self, query: str) -> dict:
        query = " ".join(query.split()).strip()
        if not query:
            raise ToolError("say what to forget")
        rows = await self.db.fetchall(
            "SELECT id, content FROM memories WHERE LOWER(content) LIKE ?",
            (f"%{query.lower()}%",),
        )
        if not rows:
            # fall back to all-words match so "forget the parking spot" works
            words = [w for w in query.lower().split() if len(w) > 2][:8]
            if words:
                clause = " AND ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content FROM memories WHERE {clause}",
                    tuple(f"%{w}%" for w in words),
                )
        if not rows:
            return {"forgotten": 0, "items": []}
        ids = [r["id"] for r in rows]
        marks = ",".join("?" for _ in ids)
        await self.db.execute(f"DELETE FROM memories WHERE id IN ({marks})", tuple(ids))
        self.bus.publish("memories_changed", action="forgot")
        return {"forgotten": len(ids), "items": [r["content"] for r in rows]}
