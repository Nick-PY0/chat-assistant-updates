"""Dashboard/tool calendar contract with durable review-before-write."""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from chat_core.events import EventBus
from chat_core.models.credentials import iso, parse_iso
from chat_core.models.db import Database


class CalendarToolError(ValueError):
    pass


class CalendarManager:
    def __init__(self, db: Database, provider, bus: EventBus | None = None,
                 clock=lambda: datetime.now(timezone.utc), draft_ttl_seconds: int = 600,
                 default_timezone: str = "UTC") -> None:
        self.db, self.provider, self.bus, self.clock = db, provider, bus, clock
        self.draft_ttl = max(60, min(draft_ttl_seconds, 1800))
        self.default_timezone = default_timezone

    async def upcoming(self, days: int = 14, limit: int = 100) -> dict:
        days, limit = max(1, min(int(days), 366)), max(1, min(int(limit), 500))
        now = self.clock()
        events = await self.provider.list_events(now, now + timedelta(days=days))
        public = [event.public() for event in events[:limit]]
        if not public:
            summary = "You have no upcoming calendar events."
        else:
            first = public[0]
            summary = (
                f"You have {len(public)} upcoming calendar event"
                f"{'s' if len(public) != 1 else ''}. "
                f"First is {first['title']} {self._spoken_when(first)}."
            )
        return {"events": public, "timezone": self.default_timezone, "summary": summary}

    async def next_meeting(self) -> dict:
        result = await self.upcoming(days=14, limit=100)
        event = next((item for item in result["events"] if not item["all_day"]), None)
        summary = "No upcoming meetings." if not event else (
            f"Your next meeting is {event['title']} {self._spoken_when(event)}.")
        return {"event": event, "summary": summary}

    def _spoken_when(self, event: dict) -> str:
        if event.get("all_day"):
            try:
                day = datetime.fromisoformat(event["start_at"]).date()
                return f"all day on {day.strftime('%A, %B %d').replace(' 0', ' ')}"
            except (TypeError, ValueError):
                return "as an all-day event"
        try:
            zone = ZoneInfo(event.get("timezone") or self.default_timezone)
            begins = datetime.fromisoformat(event["start_at"]).astimezone(zone)
            label = begins.strftime("%A, %B %d at %I:%M %p").replace(" 0", " ")
            return f"on {label} {zone.key}"
        except (TypeError, ValueError, ZoneInfoNotFoundError):
            return f"at {event.get('start_at', '')}"

    @staticmethod
    def _resolve_local(value: str, zone: ZoneInfo) -> datetime:
        try:
            parsed = datetime.fromisoformat(str(value))
        except (TypeError, ValueError) as exc:
            raise CalendarToolError("start time must be a complete ISO local date-time") from exc
        if parsed.tzinfo is not None:
            return parsed.astimezone(zone)
        # A differing fold offset means the wall time occurs twice.
        first, second = parsed.replace(tzinfo=zone, fold=0), parsed.replace(tzinfo=zone, fold=1)
        if first.utcoffset() != second.utcoffset():
            raise CalendarToolError("start time is ambiguous in that timezone")
        # UTC round-trip detects DST gaps (nonexistent local wall times).
        if first.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None) != parsed:
            raise CalendarToolError("start time does not exist in that timezone")
        return first

    async def review_appointment(self, title: str, start_local: str,
                                 duration_minutes: int, calendar_id: str | None = None,
                                 timezone_name: str | None = None) -> dict:
        title = " ".join(str(title or "").split())
        if not title or not start_local:
            raise CalendarToolError("title and start time are required")
        try:
            duration = int(duration_minutes)
        except (TypeError, ValueError) as exc:
            raise CalendarToolError("duration must be 5 to 1440 minutes") from exc
        if not 5 <= duration <= 1440:
            raise CalendarToolError("duration must be 5 to 1440 minutes")
        zone_name = timezone_name or self.default_timezone
        try:
            zone = ZoneInfo(zone_name)
        except ZoneInfoNotFoundError as exc:
            raise CalendarToolError("invalid timezone") from exc
        starts = self._resolve_local(start_local, zone)
        if starts.astimezone(timezone.utc) <= self.clock().astimezone(timezone.utc):
            raise CalendarToolError("appointment must be in the future")
        selected, writable = await self.provider.account.selection()
        destination = calendar_id or writable
        if not destination or destination not in selected or destination != writable:
            raise CalendarToolError("destination calendar is not selected and writable")
        discovered = {item["id"]: item for item in await self.provider.calendars()}
        if destination not in discovered or not discovered[destination]["write_allowed"]:
            raise CalendarToolError("destination calendar is not writable")
        finishes = starts + timedelta(minutes=duration)
        draft_id, expires = "cald_" + secrets.token_hex(8), self.clock() + timedelta(
            seconds=self.draft_ttl)
        await self.db.execute(
            """INSERT INTO calendar_drafts
               (id,provider,calendar_id,calendar_name,title,start_at,end_at,timezone,
                status,expires_at,created_at) VALUES(?,'google',?,?,?,?,?,?,'pending',?,?)""",
            (draft_id, destination, discovered[destination]["name"], title[:500],
             starts.isoformat(), finishes.isoformat(), zone_name, iso(expires), iso(self.clock())))
        return {"draft": {"id": draft_id, "title": title[:500],
            "start_at": starts.isoformat(), "end_at": finishes.isoformat(),
            "when": starts.strftime("%A, %B %d at %I:%M %p").replace(" 0", " "),
            "calendar_id": destination, "calendar_name": discovered[destination]["name"],
            "timezone": zone_name, "expires_at": iso(expires)}}

    async def confirm_appointment(self, draft_id: str, confirmed: bool) -> dict:
        if confirmed is not True:
            raise CalendarToolError("appointment creation requires explicit confirmation")
        now = self.clock()
        # Expiry and one-use transition are one atomic claim.
        claimed = await self.db.execute(
            """UPDATE calendar_drafts SET status='claimed',finished_at=? WHERE id=?
               AND status='pending' AND expires_at>?""", (iso(now), draft_id, iso(now)))
        if claimed != 1:
            row = await self.db.fetchone("SELECT expires_at FROM calendar_drafts WHERE id=?",
                                         (draft_id,))
            if row and (parse_iso(row["expires_at"]) or now) <= now:
                await self.db.execute(
                    "UPDATE calendar_drafts SET status='expired' WHERE id=? AND status='pending'",
                    (draft_id,))
            raise CalendarToolError("appointment draft is expired, unavailable, or already used")
        row = await self.db.fetchone("SELECT * FROM calendar_drafts WHERE id=?", (draft_id,))
        selected, writable = await self.provider.account.selection()
        if row["calendar_id"] not in selected or row["calendar_id"] != writable:
            await self.db.execute(
                "UPDATE calendar_drafts SET status='failed',finished_at=? WHERE id=?",
                (iso(self.clock()), draft_id),
            )
            raise CalendarToolError(
                "the reviewed destination calendar is no longer selected and writable"
            )
        payload = {"summary": row["title"],
                   "start": {"dateTime": row["start_at"], "timeZone": row["timezone"]},
                   "end": {"dateTime": row["end_at"], "timeZone": row["timezone"]}}
        try:
            created = await self.provider.create_event(row["calendar_id"], payload)
            verified = await self.provider.get_event(row["calendar_id"], created.id)
            await self.provider.cache_event(verified)
        except Exception:
            await self.db.execute(
                "UPDATE calendar_drafts SET status='failed',finished_at=? WHERE id=?",
                (iso(self.clock()), draft_id))
            raise
        await self.db.execute(
            "UPDATE calendar_drafts SET status='created',finished_at=? WHERE id=?",
            (iso(self.clock()), draft_id))
        if self.bus:
            self.bus.publish("calendar_changed", action="created")
        return {"event": verified.public()}