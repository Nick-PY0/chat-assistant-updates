"""Room-aware, provider-neutral music coordination.

Provider adapters remain authoritative: in particular this class never
duplicates YouTube's player state machine and never treats a Spotify request as
successful before the Web API call returns.
"""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import secrets
from typing import Any, Callable

from chat_core.models.music import MusicStore, StaleMusicSessionError
from integrations.spotify.client import SpotifyClient


class MusicError(RuntimeError):
    """A validation or routing error safe to show to an application user."""


def _clean(value: object, limit: int = 250) -> str:
    return " ".join(str(value or "").split())[:limit]


async def _await(value: Any) -> Any:
    return await value if inspect.isawaitable(value) else value


class MusicTool:
    """Coordinate exactly one fenced music destination across named rooms."""

    PROVIDERS = ("spotify", "youtube", "local")
    PREFERENCE_KEY = "music.provider_preference"

    def __init__(
        self,
        db: Any,
        bus: Any,
        store: MusicStore,
        youtube: Any,
        spotify: SpotifyClient | None = None,
        local: Any | None = None,
        on_playing: Callable[[bool], None] | None = None,
    ) -> None:
        self.db = db
        self.bus = bus
        self.store = store
        self.youtube = youtube
        self.spotify = spotify
        self.local = local
        self.on_playing = on_playing
        self._started = False
        self._generation = 0
        self._voice_generation: int | None = None
        self._voice_state: dict[str, Any] | None = None
        self._last_player_owner = ""
        self._tasks: set[asyncio.Task] = set()
        # Provider and browser side effects are globally serialized. The
        # product promises transfer (one destination), not synchronized
        # multi-room playback, so a second operation must not overtake the
        # first between retirement, session reservation, provider I/O, and
        # final fenced publication.
        self._operation_lock = asyncio.Lock()

    async def start(self) -> dict:
        room = await self.store.ensure_default_room()
        async with self._operation_lock:
            await self._reconcile_after_restart()
        self._started = True
        self._track_task(self._owner_watchdog(), "music-owner-watchdog")
        if self.local is not None:
            try:
                roots = await self.local.list_roots()
            except Exception:
                roots = []
            for root in roots:
                root_id = str(root.get("id") or "")
                if root_id:
                    self._track_task(
                        self._startup_scan(root_id),
                        f"music-startup-scan-{root_id[:16]}",
                    )
        return room

    async def _reconcile_after_restart(self) -> None:
        """Retire or truthfully fence durable sessions after process restart."""
        rows = await self.db.fetchall(
            "SELECT room_id FROM music_sessions WHERE active=1"
        )
        audible_unverified = False
        for row in rows:
            session = await self.store.get_active_session(row["room_id"])
            if not session:
                continue
            state = dict(session.get("state") or {})
            provider = str(state.get("provider") or "")
            keep_active = False
            if provider == "spotify":
                if self.spotify is None:
                    keep_active = True
                else:
                    try:
                        await self.spotify.stop(str(state.get("target_ref") or ""))
                    except Exception:
                        keep_active = True
            elif provider == "youtube":
                actual = self.youtube.snapshot()
                actual_status = str(actual.get("status") or "stopped")
                if actual_status in {"playing", "buffering"}:
                    state.update(
                        status=actual_status,
                        audible=actual_status == "playing",
                        pending_action="",
                    )
                    keep_active = True

            if keep_active:
                if provider == "spotify":
                    state.update(
                        status="restart_unverified",
                        audible=True,
                        pending_action="",
                        error_message=(
                            "Spotify playback could not be verified after restart; "
                            "use Stop to reconcile it."
                        ),
                    )
                try:
                    await self.store.update_session(
                        row["room_id"],
                        session["session_id"],
                        session["operation_id"],
                        state=state,
                    )
                except StaleMusicSessionError:
                    continue
                audible_unverified = audible_unverified or bool(state.get("audible"))
                continue

            try:
                await self.store.update_session(
                    row["room_id"],
                    session["session_id"],
                    session["operation_id"],
                    state={
                        **state,
                        "status": "retired_after_restart",
                        "audible": False,
                        "pending_action": "",
                    },
                    active=False,
                )
            except StaleMusicSessionError:
                continue
        if self.on_playing is not None:
            self.on_playing(audible_unverified)

    def _track_task(self, coroutine: Any, name: str) -> None:
        task = asyncio.create_task(coroutine, name=name)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _startup_scan(self, root_id: str) -> None:
        try:
            await self.local.scan(root_id)
        except (asyncio.CancelledError, Exception):
            # A missing/unmounted folder remains visible for explicit repair;
            # startup must not fail because one optional library is offline.
            return

    async def _owner_watchdog(self) -> None:
        while True:
            await asyncio.sleep(5)
            current = str(getattr(self.youtube, "owner_id", "") or "")
            if self._last_player_owner and current != self._last_player_owner:
                await self.player_released(self._last_player_owner)

    async def close(self) -> None:
        tasks = list(self._tasks)
        self._tasks.clear()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        if self.spotify is not None:
            closer = getattr(self.spotify, "close", None)
            if closer is not None:
                await _await(closer())
        self._started = False

    async def stop(self) -> None:
        """Stop coordinator background services and owned provider clients."""
        await self.close()

    def _explicit(self) -> int:
        self._generation += 1
        self._voice_generation = None
        self._voice_state = None
        return self._generation

    @staticmethod
    def _id(prefix: str = "") -> str:
        return prefix + secrets.token_urlsafe(18)

    @staticmethod
    def _stable_item_id(provider: str, provider_id: object) -> str:
        digest = hashlib.sha256(
            f"{provider}\0{str(provider_id)}".encode("utf-8")
        ).hexdigest()
        return f"music-{digest}"

    @staticmethod
    def _target_ref(provider: str, target_id: str) -> str:
        if provider == "spotify":
            # Spotify already exposes an opaque, one-way device reference.
            return target_id
        return hashlib.sha256(
            f"{provider}\0{target_id}".encode("utf-8")
        ).hexdigest()[:24]

    async def get_provider_preference(self) -> str:
        value = _clean(await self.db.get_setting(self.PREFERENCE_KEY, "youtube"), 20).lower()
        return value if value in self.PROVIDERS else "youtube"

    async def set_provider_preference(self, provider: str) -> str:
        clean = _clean(provider, 20).lower()
        if clean not in self.PROVIDERS:
            raise MusicError("unknown music provider")
        if clean == "spotify" and self.spotify is None:
            raise MusicError("Spotify is not configured")
        if clean == "local" and self.local is None:
            raise MusicError("local music is not configured")
        await self.db.set_setting(self.PREFERENCE_KEY, clean)
        return clean

    async def _discover(self) -> tuple[dict[str, list[dict]], dict[str, dict]]:
        targets: dict[str, list[dict]] = {name: [] for name in self.PROVIDERS}
        health: dict[str, dict] = {}

        ys = self.youtube.snapshot()
        owner = str(getattr(self.youtube, "owner_id", "") or "")
        if owner and bool(ys.get("player_connected")):
            for provider in ("youtube", "local"):
                targets[provider].append(
                    {
                        "target_ref": self._target_ref(provider, owner),
                        "label": _clean(ys.get("target_label") or "Media page", 200),
                    }
                )
        health["youtube"] = {
            "available": True,
            "connected": bool(ys.get("player_connected") or ys.get("companion_connected")),
        }

        if self.spotify is None:
            health["spotify"] = {"available": False, "connected": False}
        else:
            try:
                devices = await self.spotify.discover_devices()
                targets["spotify"] = [
                    {"target_ref": str(x["ref"]), "label": _clean(x.get("name"), 200)}
                    for x in devices
                    if isinstance(x, dict) and x.get("ref")
                ]
                health["spotify"] = {"available": True, "connected": True}
            except Exception:
                # Snapshot is deliberately safe and non-throwing. Provider
                # commands themselves preserve SpotifyError unchanged.
                health["spotify"] = {"available": True, "connected": False}

        if self.local is None:
            health["local"] = {"available": False, "connected": False}
        else:
            health["local"] = {
                "available": True,
                "connected": bool(owner and ys.get("player_connected")),
            }
        return targets, health

    @staticmethod
    def _public_item(item: dict) -> dict:
        result = {key: value for key, value in item.items() if key != "metadata"}
        metadata = dict(item.get("metadata") or {})
        # Provider IDs and URIs are server-side routing material. Public
        # snapshots need only identify the provider.
        result["metadata"] = {
            key: value for key, value in metadata.items()
            if key not in {"provider_id", "uri"}
        }
        result["provider"] = str(metadata.get("provider") or "")
        return result

    async def safe_snapshot(self, room: str | None = None) -> dict:
        resolved = await self.store.resolve_room(room)
        targets, health = await self._discover()
        session = await self.store.get_active_session(resolved["id"])
        mappings = await self.store.list_target_mappings(resolved["id"])
        queue = [self._public_item(x) for x in await self.store.list_queue(resolved["id"])]
        favorites = [
            self._public_item(x) for x in await self.store.list_favorites(resolved["id"])
        ]
        playlists = await self.store.list_playlists(resolved["id"])
        roots = await self.store.list_local_roots()
        if self.local is not None:
            try:
                library = await self.local.list(limit=500)
            except Exception:
                library = []
                health["local"]["connected"] = False
        else:
            library = []
        public_session = None
        if session:
            state = dict(session.get("state") or {})
            state.pop("provider_id", None)
            state.pop("uri", None)
            public_session = {**session, "state": state}
        return {
            "room": resolved,
            "room_id": resolved["id"],
            "rooms": await self.store.list_rooms(),
            "default_room_id": next(
                (x["id"] for x in await self.store.list_rooms() if x["is_default"]),
                resolved["id"],
            ),
            "provider_preference": await self.get_provider_preference(),
            "provider_health": health,
            "targets": targets,
            "target_mappings": mappings,
            "session": public_session,
            "session_id": public_session["session_id"] if public_session else "",
            "operation_id": public_session["operation_id"] if public_session else "",
            "status": (
                str(public_session["state"].get("status") or "ready")
                if public_session else "ready"
            ),
            "now_playing": (
                {
                    **public_session["state"],
                    "room_id": resolved["id"],
                }
                if public_session else {}
            ),
            "queue": queue,
            "favorites": favorites,
            "playlists": playlists,
            "local_roots": roots,
            "local_library": library,
            "library_roots": roots,
            "library": {"roots": roots, "items": library},
        }

    async def snapshot(self, room: str | None = None) -> dict:
        return await self.safe_snapshot(room)

    async def player_claimed(self, claim_result: dict) -> dict:
        async with self._operation_lock:
            return await self._player_claimed_locked(claim_result)

    async def _player_claimed_locked(self, claim_result: dict) -> dict:
        """Observe YouTubeTool's already-authorized lease result."""
        if isinstance(claim_result, dict) and claim_result.get("owner"):
            incoming = str(claim_result.get("target_id") or "")
            if (
                self._last_player_owner
                and incoming
                and incoming != self._last_player_owner
            ):
                previous = self._last_player_owner
                rows = await self.db.fetchall(
                    "SELECT room_id FROM music_sessions WHERE active=1"
                )
                for row in rows:
                    session = await self.store.get_active_session(row["room_id"])
                    if not session or session["state"].get("provider") != "local":
                        continue
                    self.bus.publish(
                        "music_control",
                        room_id=row["room_id"],
                        session_id=session["session_id"],
                        operation_id=session["operation_id"],
                        target_id=previous,
                        action="stop",
                        item_id=session["state"].get("item_id", ""),
                    )
                    try:
                        await self.store.update_session(
                            row["room_id"],
                            session["session_id"],
                            session["operation_id"],
                            state={
                                **session["state"],
                                "status": "retired",
                                "audible": False,
                            },
                            active=False,
                        )
                    except StaleMusicSessionError:
                        pass
                if self.on_playing is not None:
                    self.on_playing(False)
            self._last_player_owner = incoming
        return await self.safe_snapshot()

    async def player_released(self, client_id: str) -> None:
        async with self._operation_lock:
            await self._player_released_locked(client_id)

    async def _player_released_locked(self, client_id: str) -> None:
        """Retire local state when its authenticated browser lease disappears."""
        if self._last_player_owner and str(client_id) != self._last_player_owner:
            return
        self._last_player_owner = ""
        rows = await self.db.fetchall(
            "SELECT room_id FROM music_sessions WHERE active=1"
        )
        for row in rows:
            session = await self.store.get_active_session(row["room_id"])
            if not session or session["state"].get("provider") != "local":
                continue
            try:
                await self.store.update_session(
                    row["room_id"], session["session_id"], session["operation_id"],
                    state={**session["state"], "status": "stopped", "audible": False},
                    active=False,
                )
            except StaleMusicSessionError:
                pass
        if self.on_playing is not None:
            self.on_playing(False)

    async def map_room_target(
        self, room: str | None, provider: str, target_ref: str
    ) -> dict:
        async with self._operation_lock:
            return await self._map_room_target_locked(room, provider, target_ref)

    async def _map_room_target_locked(
        self, room: str | None, provider: str, target_ref: str
    ) -> dict:
        clean_provider = _clean(provider, 20).lower()
        targets, _ = await self._discover()
        match = next(
            (x for x in targets.get(clean_provider, []) if x["target_ref"] == target_ref),
            None,
        )
        if match is None:
            raise MusicError("music target is not currently available")
        return await self.store.set_target_mapping(
            room, clean_provider, target_ref, match["label"]
        )

    set_room_target = map_room_target

    async def _target(self, room_id: str, provider: str) -> str:
        try:
            target_ref = await self.store.decrypt_target_id(room_id, provider)
        except LookupError as exc:
            raise MusicError(f"no {provider} target is mapped to this room") from exc
        if provider in {"youtube", "local"}:
            owner = str(getattr(self.youtube, "owner_id", "") or "")
            if not owner or target_ref != self._target_ref(provider, owner):
                label = "YouTube target" if provider == "youtube" else "local player"
                raise MusicError(f"the room's {label} is not connected")
            return owner
        return target_ref

    async def _persist(
        self, provider: str, raw: dict, *, kind: str = "track"
    ) -> dict:
        provider_id = (
            raw.get("id") or raw.get("video_id") or raw.get("playlist_id")
            or raw.get("item_id")
        )
        if not provider_id:
            raise MusicError("music provider returned an invalid item")
        iid = (
            str(provider_id)
            if provider == "local"
            else self._stable_item_id(provider, provider_id)
        )
        artists = raw.get("artists")
        artist = ", ".join(str(x) for x in artists) if isinstance(artists, list) else (
            raw.get("artist") or raw.get("channel") or ""
        )
        metadata = {
            "provider": provider,
            "provider_id": str(provider_id),
            "uri": raw.get("uri") or "",
            "external_url": raw.get("external_url") or raw.get("url") or "",
        }
        return await self.store.upsert_item(
            iid,
            kind=kind,
            title=raw.get("name") or raw.get("title") or "Unknown title",
            artist=artist,
            album=raw.get("album") or "",
            duration_ms=raw.get("duration_ms"),
            artwork_url=raw.get("image_url") or raw.get("artwork_url"),
            metadata=metadata,
        )

    async def search(
        self,
        query: str,
        provider: str = "auto",
        kind: str = "any",
        max_results: int = 10,
    ) -> list[dict]:
        clean_query = _clean(query)
        if not clean_query:
            raise MusicError("a music search query is required")
        clean_provider = _clean(provider, 20).lower()
        providers = (
            list(self.PROVIDERS)
            if clean_provider in {"", "auto", "all"}
            else [clean_provider]
        )
        clean_kind = _clean(kind, 20).lower()
        if clean_kind not in {"any", "track", "playlist"}:
            raise MusicError("search kind must be any, track, or playlist")
        limit = max(1, min(int(max_results), 50))
        results: list[dict] = []
        for name in providers:
            if name == "spotify":
                if self.spotify is None:
                    continue
                account = await self.spotify.account.public_metadata()
                if not account.get("connected"):
                    if clean_provider == "spotify":
                        # Preserve the provider's safe setup error contract.
                        await self.spotify.search(clean_query, ("track",), 1)
                    continue
                types = (
                    ("track", "playlist") if clean_kind == "any" else (clean_kind,)
                )
                data = await self.spotify.search(clean_query, types, limit)
                if clean_kind in {"any", "track"}:
                    results.extend(
                        [await self._persist(name, x) for x in data.get("tracks", [])]
                    )
                if clean_kind in {"any", "playlist"}:
                    results.extend(
                        [await self._persist(name, x, kind="playlist")
                         for x in data.get("playlists", [])]
                    )
            elif name == "youtube":
                if clean_kind in {"any", "track"}:
                    data = await self.youtube.search(clean_query, limit)
                    results.extend(
                        [await self._persist(name, x) for x in data.get("results", [])]
                    )
                if clean_kind in {"any", "playlist"}:
                    search_playlists = getattr(self.youtube, "search_playlists", None)
                    if search_playlists is not None:
                        data = await _await(search_playlists(clean_query, limit))
                        results.extend(
                            [await self._persist(name, x, kind="playlist")
                             for x in data.get("results", [])]
                        )
            elif (
                name == "local"
                and self.local is not None
                and clean_kind in {"any", "track"}
            ):
                rows = await self.local.search(clean_query, limit=limit)
                results.extend([await self._persist(name, x) for x in rows])
            elif name not in self.PROVIDERS:
                raise MusicError("unknown music provider")
        return [self._public_item(item) for item in results[:limit]]

    async def _retire_other_sessions(self, room_id: str) -> None:
        rows = await self.db.fetchall(
            "SELECT room_id FROM music_sessions WHERE active=1",
        )
        retired = False
        for row in rows:
            session = await self.store.get_active_session(row["room_id"])
            if not session:
                continue
            state = dict(session.get("state") or {})
            provider = state.get("provider")
            if provider == "spotify" and self.spotify is not None:
                await self.spotify.stop(state.get("target_ref", ""))
            elif provider == "youtube":
                youtube_state = self.youtube.snapshot()
                if (
                    youtube_state.get("playback_mode") == "host_browser"
                    and youtube_state.get("status") in {"playing", "buffering"}
                ):
                    raise MusicError(
                        "YouTube is playing in a separate browser tab. Stop it in "
                        "that tab before transferring music to another room."
                    )
                await self.youtube.stop_media()
            elif provider == "local":
                owner = str(getattr(self.youtube, "owner_id", "") or "")
                if owner:
                    self.bus.publish(
                        "music_control",
                        room_id=row["room_id"],
                        session_id=session["session_id"],
                        operation_id=session["operation_id"],
                        target_id=owner,
                        action="stop",
                        item_id=state.get("item_id", ""),
                    )
            try:
                await self.store.update_session(
                    row["room_id"], session["session_id"], session["operation_id"],
                    state={**state, "status": "retired"}, active=False,
                )
            except StaleMusicSessionError:
                pass
            retired = True
        if retired and self.on_playing is not None:
            self.on_playing(False)

    async def _begin(self, room_id: str, provider: str, item: dict | None) -> dict:
        await self._retire_other_sessions(room_id)
        target = await self._target(room_id, provider)
        session_id, operation_id = self._id("ms-"), self._id("op-")
        state = {
            "provider": provider,
            "target_ref": (
                self._target_ref(provider, target) if provider in {"youtube", "local"}
                else target
            ),
            "item_id": item["id"] if item else "",
            "title": item["title"] if item else "",
            "status": "awaiting_provider",
            "audible": False,
        }
        return await self.store.begin_session(room_id, session_id, operation_id, state)

    async def _finish(
        self, room_id: str, session: dict, state: dict
    ) -> dict:
        try:
            updated = await self.store.update_session(
                room_id, session["session_id"], session["operation_id"], state=state
            )
        except StaleMusicSessionError:
            return {"stale": True, "session_id": session["session_id"]}
        if "audible" in state and self.on_playing is not None:
            self.on_playing(bool(state["audible"]))
        return updated or {"stale": True}

    async def play(
        self,
        item_id: str | None = None,
        *,
        room: str | None = None,
        query: str | None = None,
        provider: str | None = None,
        favorites: bool = False,
        playlist_id: str | None = None,
        spotify_playlist_id: str | None = None,
        **kwargs: Any,
    ) -> dict:
        async with self._operation_lock:
            return await self._play_locked(
                item_id,
                room=room,
                query=query,
                provider=provider,
                favorites=favorites,
                playlist_id=playlist_id,
                spotify_playlist_id=spotify_playlist_id,
                **kwargs,
            )

    async def _play_locked(
        self,
        item_id: str | None = None,
        *,
        room: str | None = None,
        query: str | None = None,
        provider: str | None = None,
        favorites: bool = False,
        playlist_id: str | None = None,
        spotify_playlist_id: str | None = None,
        **kwargs: Any,
    ) -> dict:
        self._explicit()
        room = room or kwargs.get("room_id")
        item_id = item_id or kwargs.get("id") or kwargs.get("music_item_id")
        query = query or kwargs.get("search")
        provider = provider or kwargs.get("source")
        favorites = bool(favorites or kwargs.get("favorite"))
        playlist_id = playlist_id or kwargs.get("assistant_playlist_id")
        spotify_playlist_id = (
            spotify_playlist_id or kwargs.get("native_playlist_id")
            or kwargs.get("native_spotify_playlist_id")
            or (
                kwargs.get("provider_playlist_id")
                if _clean(provider, 20).lower() == "spotify" else None
            )
        )
        resolved = await self.store.resolve_room(room)
        item: dict | None = None
        playlist_name = _clean(kwargs.get("playlist_name"), 200)
        if playlist_name and not playlist_id:
            playlists = await self.store.list_playlists(resolved["id"])
            match = next(
                (
                    row for row in playlists
                    if str(row.get("name", "")).casefold() == playlist_name.casefold()
                ),
                None,
            )
            if match is None:
                raise MusicError(f"assistant playlist '{playlist_name}' was not found")
            playlist_id = str(match["id"])
        if favorites:
            values = await self.store.list_favorites(resolved["id"])
            if not values:
                raise MusicError("this room has no favorite music")
            item = values[0]
        elif playlist_id:
            values = await self.store.list_playlist_items(playlist_id)
            if not values:
                raise MusicError("the playlist is empty")
            item = values[0]
        elif item_id:
            item = await self.store.get_item(item_id)
        elif spotify_playlist_id:
            provider = "spotify"
            item = await self._persist(
                "spotify",
                {
                    "id": spotify_playlist_id,
                    "name": "Spotify playlist",
                    "uri": f"spotify:playlist:{spotify_playlist_id}",
                },
                kind="playlist",
            )
        elif query:
            chosen = provider or await self.get_provider_preference()
            if str(chosen).lower() == "auto":
                chosen = await self.get_provider_preference()
            found = await self.search(query, provider=chosen, max_results=10)
            if not found:
                raise MusicError("no matching music was found")
            item = found[0]
        else:
            raise MusicError("choose music to play")
        metadata = dict(item.get("metadata") or {})
        chosen = _clean(provider or metadata.get("provider"), 20).lower()
        if chosen == "auto":
            chosen = _clean(metadata.get("provider"), 20).lower()
        if chosen not in self.PROVIDERS:
            raise MusicError("music item has no playable provider")
        session = await self._begin(resolved["id"], chosen, item)
        target = await self._target(resolved["id"], chosen)
        state = dict(session["state"])

        if chosen == "spotify":
            if self.spotify is None:
                raise MusicError("Spotify is not configured")
            if item.get("kind") == "playlist":
                await self.spotify.start(target, context_uri=metadata.get("uri"))
            else:
                await self.spotify.start(target, uri=metadata.get("uri"))
            return await self._finish(
                resolved["id"], session, {**state, "status": "playing", "audible": True}
            )
        if chosen == "youtube":
            if item.get("kind") == "playlist":
                result = await self.youtube.play_playlist(
                    playlist_id=metadata.get("provider_id"), title=item["title"]
                )
            else:
                result = await self.youtube.play(
                    metadata.get("provider_id") or metadata.get("external_url"),
                    item["title"],
                )
            status = self.youtube.snapshot().get("status", "buffering")
            await self._finish(
                resolved["id"], session,
                {**state, "status": status, "audible": status == "playing"},
            )
            return result

        # Local playback is acknowledged only by the authenticated Media-page
        # lease owner. No filesystem path crosses this boundary.
        self.bus.publish(
            "music_control",
            room_id=resolved["id"],
            session_id=session["session_id"],
            operation_id=session["operation_id"],
            target_id=target,
            action="play_local",
            item_id=item["id"],
            title=item["title"],
            position_seconds=0,
        )
        return {
            "awaiting_confirmation": True,
            "message": "Awaiting browser confirmation.",
            "session_id": session["session_id"],
            "operation_id": session["operation_id"],
        }

    async def play_query(self, query: str, room: str | None = None,
                         provider: str | None = None) -> dict:
        return await self.play(room=room, query=query, provider=provider)

    async def play_favorites(self, room: str | None = None) -> dict:
        return await self.play(room=room, favorites=True)

    async def play_playlist(self, playlist_id: str, room: str | None = None) -> dict:
        return await self.play(room=room, playlist_id=playlist_id)

    async def play_spotify_playlist(
        self, playlist_id: str, room: str | None = None
    ) -> dict:
        return await self.play(room=room, spotify_playlist_id=playlist_id)

    async def _new_operation(self, room: str | None, action: str) -> tuple[dict, dict, str]:
        resolved = await self.store.resolve_room(room)
        session = await self.store.get_active_session(resolved["id"])
        if not session:
            raise MusicError("there is no active music session in this room")
        operation = self._id("op-")
        state = {**session["state"], "pending_action": action}
        updated = await self.store.update_session(
            resolved["id"], session["session_id"], session["operation_id"],
            operation_id=operation, state=state,
        )
        assert updated is not None
        return resolved, updated, operation

    async def control(self, action: str, room: str | None = None,
                      value: Any = None) -> dict:
        async with self._operation_lock:
            return await self._control_locked(action, room=room, value=value)

    async def _control_locked(self, action: str, room: str | None = None,
                              value: Any = None) -> dict:
        self._explicit()
        action = _clean(action, 20).lower()
        aliases = {"play": "resume", "unmute": "mute"}
        action = aliases.get(action, action)
        if action not in {
            "pause", "resume", "stop", "next", "previous", "restart",
            "seek", "volume", "mute",
        }:
            raise MusicError("unknown music control")
        resolved, session, _operation = await self._new_operation(room, action)
        state = dict(session["state"])
        provider = state.get("provider")
        if provider == "local" and action in {"next", "previous"}:
            queue = await self.store.list_queue(resolved["id"])
            current = next(
                (
                    index for index, item in enumerate(queue)
                    if item["id"] == state.get("item_id")
                ),
                -1,
            )
            wanted = current + (1 if action == "next" else -1)
            if current < 0 or wanted < 0 or wanted >= len(queue):
                raise MusicError(f"there is no {action} item in the music queue")
            return await self._play_locked(
                item_id=queue[wanted]["id"], room=resolved["id"]
            )
        target = (
            str(state.get("target_ref") or "")
            if provider == "spotify"
            else await self._target(resolved["id"], provider)
        )
        result: Any
        if provider == "spotify":
            if self.spotify is None:
                raise MusicError("Spotify is not configured")
            method = {
                "pause": self.spotify.pause, "resume": self.spotify.resume,
                "stop": self.spotify.stop, "next": self.spotify.next,
                "previous": self.spotify.previous,
                "restart": lambda ref: self.spotify.seek(ref, 0),
                "seek": lambda ref: self.spotify.seek(ref, int(value)),
                "volume": lambda ref: self.spotify.volume(ref, int(value)),
                "mute": lambda ref: self.spotify.mute(ref, bool(value)),
            }[action]
            result = await method(target)
        elif provider == "youtube":
            methods = {
                "pause": self.youtube.pause_media, "resume": self.youtube.play,
                "stop": self.youtube.stop_media, "next": self.youtube.next,
                "previous": self.youtube.previous,
                "restart": self.youtube.restart_media,
                "seek": lambda: self.youtube.seek_media(float(value)),
                "volume": lambda: self.youtube.set_volume(value),
                "mute": lambda: self.youtube.set_muted(bool(value)),
            }
            result = await _await(methods[action]())
        elif provider == "local":
            fields: dict[str, Any] = {}
            if action == "seek":
                fields["position_seconds"] = max(
                    0.0, float(state.get("position_seconds") or 0) + float(value or 0)
                )
            elif action == "volume":
                if isinstance(value, dict):
                    current = float(state.get("volume", 1.0))
                    fields["volume"] = max(
                        0.0, min(1.0, current + int(value.get("delta", 0)) / 100)
                    )
                else:
                    fields["volume"] = max(0.0, min(1.0, float(value or 0) / 100))
            elif action == "mute":
                fields["muted"] = bool(value)
            self.bus.publish(
                "music_control",
                room_id=resolved["id"],
                session_id=session["session_id"],
                operation_id=session["operation_id"],
                target_id=target,
                action=action,
                item_id=state.get("item_id", ""),
                **fields,
            )
            return {
                "awaiting_confirmation": True,
                "message": "Awaiting browser confirmation.",
                "session_id": session["session_id"],
                "operation_id": session["operation_id"],
            }
        else:
            raise MusicError("active music provider is unavailable")
        next_status = {
            "pause": "paused", "resume": "playing", "stop": "stopped"
        }.get(action, state.get("status", "playing"))
        finished = await self._finish(
            resolved["id"], session,
            {**state, "status": next_status, "audible": next_status == "playing",
             "pending_action": ""},
        )
        return {**(result if isinstance(result, dict) else {}), "session": finished}

    async def pause(self, room: str | None = None) -> dict:
        return await self.control("pause", room=room)

    async def resume(self, room: str | None = None) -> dict:
        return await self.control("resume", room=room)

    async def stop_playback(self, room: str | None = None) -> dict:
        return await self.control("stop", room=room)

    async def next(self, room: str | None = None) -> dict:
        return await self.control("next", room=room)

    async def previous(self, room: str | None = None) -> dict:
        return await self.control("previous", room=room)

    async def restart(self, room: str | None = None) -> dict:
        return await self.control("restart", room=room)

    async def seek(self, offset_seconds: float, room: str | None = None) -> dict:
        """Seek using the integration's public seconds-based unit."""
        resolved = await self.store.resolve_room(room)
        session = await self.store.get_active_session(resolved["id"])
        if not session:
            raise MusicError("there is no active music session in this room")
        value: float | int = float(offset_seconds)
        if session["state"].get("provider") == "spotify":
            value = int(value * 1000)
        return await self.control("seek", room=resolved["id"], value=value)

    async def volume(self, percent: int, room: str | None = None) -> dict:
        return await self.control("volume", room=room, value=percent)

    async def set_volume(
        self,
        percentage: int | None = None,
        delta: int | None = None,
        room: str | None = None,
    ) -> dict:
        async with self._operation_lock:
            return await self._set_volume_locked(percentage, delta, room)

    async def _set_volume_locked(
        self,
        percentage: int | None,
        delta: int | None,
        room: str | None,
    ) -> dict:
        if (percentage is None) == (delta is None):
            raise MusicError("provide either a volume percentage or a volume change")
        if percentage is not None:
            return await self._control_locked(
                "volume", room=room, value=percentage
            )
        resolved = await self.store.resolve_room(room)
        session = await self.store.get_active_session(resolved["id"])
        if not session:
            raise MusicError("there is no active music session in this room")
        provider = session["state"].get("provider")
        if provider == "youtube":
            self._explicit()
            return await self.youtube.adjust_volume(int(delta or 0))
        if provider == "spotify" and self.spotify is not None:
            target = str(session["state"].get("target_ref") or "")
            devices = await self.spotify.discover_devices()
            device = next((x for x in devices if x.get("ref") == target), None)
            current = device.get("volume_percent") if device else None
            if current is None:
                raise MusicError("the current Spotify volume is unavailable")
            return await self._control_locked(
                "volume", room=resolved["id"],
                value=max(0, min(100, int(current) + int(delta or 0))),
            )
        # The browser computes relative local volume from authoritative state.
        return await self._control_locked(
            "volume", room=resolved["id"], value={"delta": int(delta or 0)}
        )

    async def mute(self, muted: bool = True, room: str | None = None) -> dict:
        return await self.control("mute", room=room, value=muted)

    async def report_local(self, client_id: str, payload: dict) -> dict:
        async with self._operation_lock:
            return await self._report_local_locked(client_id, payload)

    async def _report_local_locked(self, client_id: str, payload: dict) -> dict:
        owner = str(getattr(self.youtube, "owner_id", "") or "")
        if not owner or str(client_id) != owner:
            raise MusicError("local playback report is not from the current Media page")
        try:
            room = await self.store.resolve_room(payload.get("room_id"))
            session = await self.store.get_active_session(room["id"])
        except (LookupError, TypeError) as exc:
            raise MusicError("stale local playback report rejected") from exc
        if (
            not session
            or session["state"].get("provider") != "local"
            or payload.get("session_id") != session["session_id"]
            or payload.get("operation_id") != session["operation_id"]
        ):
            raise MusicError("stale local playback report rejected")
        status = _clean(payload.get("status"), 20).lower()
        if status not in {"playing", "buffering", "paused", "stopped", "ended", "error"}:
            raise MusicError("invalid local playback status")
        item_id = session["state"].get("item_id")
        if payload.get("item_id") not in (None, item_id):
            raise MusicError("stale local playback report rejected")
        volume = max(0.0, min(1.0, float(payload.get("volume", 1.0))))
        muted = bool(payload.get("muted"))
        audible = (
            bool(payload.get("audible", status in {"playing", "buffering"}))
            and status in {"playing", "buffering"}
            and not muted
            and volume > 0
        )
        state = {
            **session["state"], "status": status, "audible": audible,
            "pending_action": "",
            "position_seconds": max(0.0, float(payload.get("position_seconds", 0))),
            "duration_seconds": max(0.0, float(payload.get("duration_seconds", 0))),
            "volume": volume,
            "muted": muted,
            "error_code": _clean(payload.get("error_code"), 80),
            "error_message": _clean(payload.get("error_message"), 500),
        }
        updated = await self._finish(room["id"], session, state)
        if updated.get("stale"):
            raise MusicError("stale local playback report rejected")
        if status == "ended":
            queue = await self.store.list_queue(room["id"])
            current = next(
                (
                    index for index, item in enumerate(queue)
                    if item["id"] == item_id
                ),
                -1,
            )
            if 0 <= current < len(queue) - 1:
                # The ended report is authoritative and fully fenced. Advance
                # now so the next command receives a fresh session+operation;
                # the browser will ignore the old report response once that
                # command becomes active.
                return await self._play_locked(
                    item_id=queue[current + 1]["id"], room=room["id"]
                )
        return updated

    # Durable collection delegation keeps all limits and validation in MusicStore.
    async def queue(self, room: str | None = None) -> list[dict]:
        return await self.store.list_queue(room)

    async def queue_add(self, item_ids: list[str], room: str | None = None) -> list[dict]:
        return await self.store.append_queue(room, item_ids)

    async def queue_replace(self, item_ids: list[str], room: str | None = None) -> list[dict]:
        return await self.store.replace_queue(room, item_ids)

    async def queue_remove(self, position: int, room: str | None = None) -> list[dict]:
        return await self.store.remove_queue(room, position)

    async def queue_clear(self, room: str | None = None) -> None:
        await self.store.clear_queue(room)

    async def manage_queue(self, action: str, **kwargs: Any) -> Any:
        action = _clean(action, 20).lower()
        room = kwargs.get("room")
        items = kwargs.get("item_ids", kwargs.get("items", []))
        if kwargs.get("item_id") is not None:
            items = [kwargs["item_id"]] if kwargs["item_id"] else []
        if (
            action in {"add", "append", "replace", "set"}
            and not items
            and _clean(kwargs.get("query"))
        ):
            found = await self.search(
                _clean(kwargs.get("query")),
                provider=_clean(kwargs.get("provider"), 20) or "auto",
                kind="track",
                max_results=1,
            )
            if not found:
                raise MusicError("no matching music was found")
            items = [found[0]["id"]]
        if action in {"list", "get"}:
            return await self.queue(room)
        if action in {"add", "append"}:
            return await self.queue_add(list(items), room)
        if action in {"replace", "set"}:
            return await self.queue_replace(list(items), room)
        if action == "remove":
            return await self.queue_remove(int(kwargs["position"]), room)
        if action == "clear":
            await self.queue_clear(room)
            return []
        if action == "play":
            queue = await self.queue(room)
            if not queue:
                raise MusicError("the music queue is empty")
            position = int(kwargs.get("position", 0))
            if position < 0 or position >= len(queue):
                raise MusicError("queue position not found")
            return await self.play(item_id=queue[position]["id"], room=room)
        raise MusicError("unknown queue action")

    async def favorite(self, item_id: str, room: str | None = None) -> dict:
        return await self.store.favorite(room, item_id)

    async def unfavorite(self, item_id: str, room: str | None = None) -> None:
        await self.store.unfavorite(room, item_id)

    async def favorites(self, room: str | None = None) -> list[dict]:
        return await self.store.list_favorites(room)

    async def manage_favorites(self, action: str, **kwargs: Any) -> Any:
        action = _clean(action, 20).lower()
        room, item_id = kwargs.get("room"), kwargs.get("item_id")
        if not item_id and action not in {"list", "get", "play"}:
            resolved = await self.store.resolve_room(room)
            active = await self.store.get_active_session(resolved["id"])
            item_id = active["state"].get("item_id") if active else None
        if action in {"list", "get"}:
            return await self.favorites(room)
        if action in {"add", "favorite"}:
            if not item_id:
                raise MusicError("a music item is required")
            return await self.favorite(str(item_id), room)
        if action in {"remove", "unfavorite"}:
            if not item_id:
                raise MusicError("a music item is required")
            await self.unfavorite(str(item_id), room)
            return {"removed": True}
        if action == "play":
            return await self.play_favorites(room)
        raise MusicError("unknown favorites action")

    async def create_playlist(self, name: str, room: str | None = None,
                              description: str = "") -> dict:
        return await self.store.create_playlist(room, name, description)

    async def playlists(self, room: str | None = None) -> list[dict]:
        return await self.store.list_playlists(room)

    async def update_playlist(self, playlist_id: str, **changes: Any) -> dict:
        return await self.store.update_playlist(playlist_id, **changes)

    async def delete_playlist(self, playlist_id: str) -> None:
        await self.store.delete_playlist(playlist_id)

    async def playlist_add(self, playlist_id: str, item_ids: list[str]) -> list[dict]:
        return await self.store.append_playlist_items(playlist_id, item_ids)

    async def playlist_replace(self, playlist_id: str, item_ids: list[str]) -> list[dict]:
        return await self.store.replace_playlist_items(playlist_id, item_ids)

    async def playlist_remove(self, playlist_id: str, position: int) -> list[dict]:
        return await self.store.remove_playlist_item(playlist_id, position)

    async def manage_playlist(self, action: str, **kwargs: Any) -> Any:
        action = _clean(action, 20).lower()
        room, playlist_id = kwargs.get("room"), kwargs.get("playlist_id")
        name = _clean(kwargs.get("name"), 200)
        if not playlist_id and name and action != "create":
            playlists = await self.store.list_playlists(room)
            match = next(
                (
                    row for row in playlists
                    if str(row.get("name", "")).casefold() == name.casefold()
                ),
                None,
            )
            playlist_id = match["id"] if match else None
        if action in {"list", "all"}:
            return await self.playlists(room)
        if action == "get":
            if not playlist_id:
                raise MusicError("a playlist is required")
            return await self.store.get_playlist(str(playlist_id))
        if action == "create":
            return await self.create_playlist(
                str(kwargs.get("name") or ""), room, str(kwargs.get("description") or "")
            )
        if action == "update":
            if not playlist_id:
                raise MusicError("a playlist is required")
            changes = {
                key: kwargs[key] for key in ("name", "description") if key in kwargs
            }
            return await self.update_playlist(str(playlist_id), **changes)
        if action == "delete":
            if not playlist_id:
                raise MusicError("a playlist is required")
            await self.delete_playlist(str(playlist_id))
            return {"deleted": True}
        if action in {"add", "append", "replace"}:
            if not playlist_id:
                raise MusicError("a playlist is required")
            items = kwargs.get("item_ids", kwargs.get("items", []))
            if kwargs.get("item_id") is not None:
                items = [kwargs["item_id"]]
            if action == "replace":
                return await self.playlist_replace(str(playlist_id), list(items))
            return await self.playlist_add(str(playlist_id), list(items))
        if action == "remove":
            if not playlist_id:
                raise MusicError("a playlist is required")
            return await self.playlist_remove(
                str(playlist_id), int(kwargs["position"])
            )
        if action == "play":
            if not playlist_id:
                raise MusicError("a playlist is required")
            return await self.play_playlist(str(playlist_id), room)
        raise MusicError("unknown playlist action")

    async def create_room(self, name: str, *, make_default: bool = False) -> dict:
        return await self.store.create_room(name, make_default=make_default)

    async def rooms(self) -> list[dict]:
        return await self.store.list_rooms()

    async def delete_room(self, room: str) -> None:
        async with self._operation_lock:
            resolved = await self.store.resolve_room(room)
            if await self.store.get_active_session(resolved["id"]):
                await self._retire_other_sessions(resolved["id"])
            await self.store.delete_room(resolved["id"])

    async def set_default_room(self, room: str) -> dict:
        return await self.store.set_default_room(room)

    async def configure_room(self, action: str, **kwargs: Any) -> Any:
        action = _clean(action, 20).lower()
        room = kwargs.get("room", kwargs.get("room_id"))
        if action in {"list", "rooms"}:
            return await self.rooms()
        if action == "create":
            return await self.create_room(
                str(kwargs.get("name") or ""),
                make_default=bool(kwargs.get("make_default", False)),
            )
        if action in {"upsert", "save"}:
            name = _clean(kwargs.get("name"), 100)
            if not name:
                raise MusicError("a room name is required")
            rooms = await self.store.list_rooms()
            match = next(
                (x for x in rooms if str(x["name"]).casefold() == name.casefold()),
                None,
            )
            configured = match or await self.create_room(name)
            provider = _clean(kwargs.get("provider"), 20).lower()
            target_ref = _clean(kwargs.get("target_ref"), 500)
            if provider and target_ref:
                await self.map_room_target(configured["id"], provider, target_ref)
            return await self.safe_snapshot(configured["id"])
        if action in {"delete", "remove"}:
            if not room:
                raise MusicError("a room is required")
            await self.delete_room(str(room))
            return {"deleted": True}
        if action in {"default", "set_default"}:
            if not room:
                raise MusicError("a room is required")
            return await self.set_default_room(str(room))
        if action in {"map", "target"}:
            return await self.map_room_target(
                room, str(kwargs.get("provider") or ""),
                str(kwargs.get("target_ref") or ""),
            )
        if action in {"targets", "discover"}:
            targets, health = await self._discover()
            return {"targets": targets, "provider_health": health}
        if action == "unmap":
            if not room or not kwargs.get("provider"):
                raise MusicError("a room and provider are required")
            async with self._operation_lock:
                resolved = await self.store.resolve_room(str(room))
                active = await self.store.get_active_session(resolved["id"])
                if (
                    active
                    and active["state"].get("provider")
                    == str(kwargs.get("provider")).lower()
                ):
                    await self._retire_other_sessions(resolved["id"])
                await self.store.delete_target_mapping(
                    resolved["id"], str(kwargs.get("provider"))
                )
            return {"unmapped": True}
        if action in {"preference", "set_provider"}:
            return {
                "provider_preference": await self.set_provider_preference(
                    str(kwargs.get("provider") or "")
                )
            }
        if action in {"get", "snapshot"}:
            return await self.safe_snapshot(room)
        raise MusicError("unknown room action")

    async def voice_focus_duck(self) -> bool:
        async with self._operation_lock:
            return await self._voice_focus_duck_locked()

    async def _voice_focus_duck_locked(self) -> bool:
        generation = self._generation
        session = await self._active_any()
        if generation != self._generation:
            return False
        if not session or session["state"].get("status") not in {"playing", "buffering"}:
            return False
        provider = session["state"].get("provider")
        if provider == "youtube":
            return bool(await self.youtube.voice_focus_duck())
        self._voice_generation = generation
        self._voice_state = {**session, "_voice_action": "duck"}
        if provider == "spotify" and self.spotify is not None:
            try:
                devices = await self.spotify.discover_devices()
                target = session["state"].get("target_ref")
                device = next((x for x in devices if x.get("ref") == target), None)
                if device is not None and device.get("volume_percent") is not None:
                    self._voice_state["_restore_volume"] = int(
                        device["volume_percent"]
                    )
            except Exception:
                pass
        if generation != self._generation:
            return False
        return await self._voice_apply(session, "duck", generation)

    async def voice_focus_pause(self) -> bool:
        async with self._operation_lock:
            return await self._voice_focus_pause_locked()

    async def _voice_focus_pause_locked(self) -> bool:
        generation = self._generation
        session = await self._active_any()
        if generation != self._generation or not session:
            return False
        if session["state"].get("provider") == "youtube":
            return bool(await self.youtube.voice_focus_pause())
        self._voice_generation = generation
        self._voice_state = {**session, "_voice_action": "pause"}
        return await self._voice_apply(session, "pause", generation)

    async def voice_focus_restore(self) -> bool:
        async with self._operation_lock:
            return await self._voice_focus_restore_locked()

    async def _voice_focus_restore_locked(self) -> bool:
        generation, session = self._voice_generation, self._voice_state
        if generation is None or generation != self._generation or not session:
            # Preserve YouTube's own independently fenced restore behavior.
            return bool(await self.youtube.voice_focus_restore())
        result = await self._voice_apply(session, "restore", generation)
        if generation == self._generation:
            self._voice_generation = None
            self._voice_state = None
        return result

    async def _active_any(self) -> dict | None:
        row = await self.db.fetchone(
            "SELECT room_id FROM music_sessions WHERE active=1 ORDER BY updated_at DESC LIMIT 1"
        )
        return await self.store.get_active_session(row["room_id"]) if row else None

    async def _voice_apply(self, session: dict, action: str, generation: int) -> bool:
        if generation != self._generation:
            return False
        state = session["state"]
        provider = state.get("provider")
        try:
            if provider == "spotify" and self.spotify is not None:
                target = state.get("target_ref", "")
                if action == "duck":
                    await self.spotify.volume(target, 20)
                elif action == "pause":
                    await self.spotify.pause(target)
                else:
                    if (
                        session.get("_voice_action") == "duck"
                        and session.get("_restore_volume") is not None
                    ):
                        await self.spotify.volume(
                            target, int(session["_restore_volume"])
                        )
                    else:
                        await self.spotify.resume(target)
            elif provider == "local":
                owner = str(getattr(self.youtube, "owner_id", "") or "")
                if not owner:
                    return False
                self.bus.publish(
                    "music_control",
                    room_id=session["room_id"],
                    session_id=session["session_id"],
                    operation_id=session["operation_id"],
                    target_id=owner,
                    action=action,
                    item_id=state.get("item_id", ""),
                )
            else:
                return False
        except Exception:
            return False
        return generation == self._generation


RoomMusicCoordinator = MusicTool