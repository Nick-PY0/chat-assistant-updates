"""Local music library support."""

from .local_library import LocalMusicLibrary, LocalMusicLibraryError

__all__ = ["LocalMusicLibrary", "LocalMusicLibraryError"]