"""Secure indexing and resolution of music stored on the local filesystem.

Filesystem paths are deliberately kept out of this module's public values.  A
root path is encrypted before it is handed to the persistence layer; tracks
store only a root-relative path.
"""

from __future__ import annotations

import asyncio
import io
import hashlib
import inspect
import mimetypes
import os
import re
import stat
import unicodedata
from pathlib import Path, PurePosixPath
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from chat_core.models.db import Database
from chat_core.security.vault import Vault

SUPPORTED_EXTENSIONS = frozenset({"mp3", "m4a", "aac", "ogg", "flac", "wav"})
MAX_FILE_SIZE = 1024 * 1024 * 1024  # conservative upper bound: 1 GiB
_MIME_TYPES = {
    "mp3": "audio/mpeg",
    "m4a": "audio/mp4",
    "aac": "audio/aac",
    "ogg": "audio/ogg",
    "flac": "audio/flac",
    "wav": "audio/wav",
}
_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_WINDOWS = os.name == "nt"


class LocalMusicLibraryError(ValueError):
    """A root or track failed a local-library security check."""


def _value(row: Any, key: str, default: Any = None) -> Any:
    if row is None:
        return default
    if isinstance(row, Mapping):
        return row.get(key, default)
    try:
        return row[key]
    except (KeyError, TypeError, IndexError):
        return getattr(row, key, default)


async def _maybe_await(value: Any) -> Any:
    return await value if inspect.isawaitable(value) else value


class _MusicStoreAdapter:
    """The only coupling to MusicStore.

    The preferred method names are ``add_local_root``, ``get_local_root``,
    ``list_local_roots``, ``begin_local_root_scan``,
    ``set_local_root_status``, ``replace_local_tracks``,
    ``list_local_tracks``, ``search_local_tracks`` and ``get_local_track``.
    A few straightforward aliases are accepted to ease integration while the
    model and this engine are developed independently.
    """

    _ALIASES = {
        "add_local_root": ("create_local_root", "upsert_local_root"),
        "get_local_root": ("local_root",),
        "list_local_roots": ("get_local_roots",),
        "delete_local_root": ("remove_local_root",),
        "begin_local_root_scan": ("begin_local_scan",),
        "set_local_root_status": ("update_local_root_status",),
        "replace_local_tracks": ("replace_tracks_for_root",),
        "list_local_tracks": ("get_local_tracks",),
        "search_local_tracks": ("search_tracks",),
        "get_local_track": ("local_track",),
    }

    def __init__(self, store: Any) -> None:
        self.store = store

    def _method(self, name: str) -> Any:
        for candidate in (name, *self._ALIASES.get(name, ())):
            method = getattr(self.store, candidate, None)
            if method is not None:
                return method
        raise RuntimeError(f"MusicStore is missing {name}()")

    async def call(self, name: str, *args: Any, **kwargs: Any) -> Any:
        # Compatibility with the initial MusicStore API, which deliberately
        # owns its encryption and stores track details as encrypted metadata.
        # This branch can be removed once that store adopts the preferred
        # generation-aware methods documented above.
        if name == "add_local_root" and not hasattr(self.store, name):
            root_id = str(kwargs["id"])
            vault = getattr(self.store, "vault")
            path = vault.decrypt(
                kwargs["encrypted_path"], f"music:local-root:path:{root_id}"
            )
            method = self._method(name)
            parameters = inspect.signature(method).parameters
            identity = (
                {
                    "root_device": kwargs.get("root_device"),
                    "root_inode": kwargs.get("root_inode"),
                }
                if "root_device" in parameters else {}
            )
            return await _maybe_await(
                method(path, kwargs["label"], root_id=root_id, **identity)
            )
        if name == "begin_local_root_scan" and not any(
            hasattr(self.store, candidate)
            for candidate in (name, *self._ALIASES.get(name, ()))
        ):
            return None
        if name == "set_local_root_status" and not any(
            hasattr(self.store, candidate)
            for candidate in (name, *self._ALIASES.get(name, ()))
        ):
            return None
        if name == "replace_local_tracks":
            method = self._method(name)
            parameters = inspect.signature(method).parameters
            if "generation" not in parameters and len(args) == 3:
                root_id, _generation, tracks = args
                prepared = []
                for track in tracks:
                    await _maybe_await(
                        self.store.upsert_item(
                            track["id"],
                            kind="local",
                            title=track["title"],
                            artist=track["artist"],
                            album=track["album"],
                            metadata={"mime": track["mime"]},
                        )
                    )
                    prepared.append(
                        {
                            "item_id": track["id"],
                            "path": track["relative_path"],
                            "metadata": {
                                "title": track["title"],
                                "artist": track["artist"],
                                "album": track["album"],
                                "mime": track["mime"],
                                "size": track["size"],
                                "mtime_ns": track["mtime_ns"],
                            },
                        }
                    )
                await _maybe_await(method(root_id, prepared))
                return True
        if name == "list_local_tracks":
            method = self._method(name)
            root_id, offset, limit = args
            if root_id is not None:
                rows = await _maybe_await(
                    method(root_id, offset=offset, limit=limit)
                )
            else:
                roots = await _maybe_await(self._method("list_local_roots")())
                rows = []
                for root in roots:
                    rows.extend(
                        await _maybe_await(
                            method(_value(root, "id"), offset=0, limit=1000)
                        )
                    )
                rows = rows[offset : offset + limit]
            if rows and "title" not in rows[0]:
                rows = [await self._hydrate_track(row) for row in rows]
            return rows
        if name == "search_local_tracks" and not hasattr(self.store, name):
            query, root_id, limit = args
            rows = await self.call("list_local_tracks", root_id, 0, 1000)
            folded = query.casefold()
            return [
                row
                for row in rows
                if folded
                in " ".join(
                    (row.get("title", ""), row.get("artist", ""), row.get("album", ""))
                ).casefold()
            ][:limit]
        if name == "get_local_track":
            method = self._method(name)
            if len(inspect.signature(method).parameters) > 1 and len(args) == 1:
                item_id = args[0]
                roots = await _maybe_await(self._method("list_local_roots")())
                for root in roots:
                    root_id = str(_value(root, "id"))
                    rows = await _maybe_await(
                        self._method("list_local_tracks")(root_id, limit=1000, offset=0)
                    )
                    for row in rows:
                        if _value(row, "item_id") == item_id:
                            return await self._hydrate_track(row)
                return None
        method = self._method(name)
        try:
            return await _maybe_await(method(*args, **kwargs))
        except TypeError:
            # Stores commonly expose positional-only methods.  Keep this
            # compatibility shim here rather than leaking DB details upward.
            if kwargs and not args:
                return await _maybe_await(method(*kwargs.values()))
            raise

    async def _hydrate_track(self, row: Any) -> dict[str, Any]:
        root_id = str(_value(row, "root_id"))
        track_ref = str(_value(row, "track_ref"))
        metadata = await _maybe_await(
            self.store.decrypt_local_track_metadata(root_id, track_ref)
        )
        item = await _maybe_await(self.store.get_item(_value(row, "item_id")))
        return {
            "id": item["id"],
            "item_id": item["id"],
            "root_id": root_id,
            "relative_path": metadata["path"],
            "title": item["title"],
            "artist": item["artist"],
            "album": item["album"],
            "mime": metadata.get("mime", item.get("metadata", {}).get("mime", "")),
            "size": metadata.get("size", 0),
            "mtime_ns": metadata.get("mtime_ns", 0),
        }

    async def count_local_tracks(self, root_id: str) -> int:
        """Count through the store API without exposing or decrypting paths."""
        method = self._method("list_local_tracks")
        offset = 0
        while True:
            try:
                batch = await _maybe_await(method(root_id, offset=offset, limit=1000))
            except TypeError:
                batch = await _maybe_await(method(root_id, offset, 1000))
            offset += len(batch)
            if len(batch) < 1000:
                return offset


class LocalMusicLibrary:
    """Index local audio without exposing or trusting persisted paths."""

    def __init__(
        self,
        db: Database,
        vault: Vault,
        store: Any,
        *,
        max_file_size: int = MAX_FILE_SIZE,
    ) -> None:
        self.db = db
        self.vault = vault
        self._store = _MusicStoreAdapter(store)
        self.max_file_size = max_file_size
        self._generation: dict[str, int] = {}
        self._generation_lock = asyncio.Lock()

    @staticmethod
    def _root_context(root_id: str) -> str:
        return f"music:local-root:path:{root_id}"

    @staticmethod
    def _public_root(row: Any) -> dict[str, Any]:
        return {
            "id": str(_value(row, "id", "")),
            "label": str(_value(row, "label", "")),
            "count": int(_value(row, "count", _value(row, "track_count", 0)) or 0),
            "status": str(_value(row, "status", "ready")),
        }

    @staticmethod
    def _public_track(row: Any) -> dict[str, Any]:
        return {
            "id": str(_value(row, "id", _value(row, "item_id", ""))),
            "root_id": str(_value(row, "root_id", "")),
            "title": _safe_text(_value(row, "title", ""), "Unknown title"),
            "artist": _safe_text(_value(row, "artist", ""), ""),
            "album": _safe_text(_value(row, "album", ""), ""),
            "mime": _safe_text(
                _value(row, "mime", _value(row, "mime_type", "")), ""
            ),
            "size": int(_value(row, "size", 0) or 0),
            "mtime_ns": int(_value(row, "mtime_ns", 0) or 0),
        }

    async def setup_root(self, directory: str | os.PathLike[str], label: str | None = None) -> dict[str, Any]:
        raw = Path(directory)
        if not raw.is_absolute():
            raise LocalMusicLibraryError("music root must be an absolute path")
        if _WINDOWS:
            canonical = Path(os.path.abspath(os.path.normpath(str(raw))))
            root_device, root_inode = _windows_root_identity(canonical)
        else:
            try:
                before = raw.lstat()
                if stat.S_ISLNK(before.st_mode):
                    raise LocalMusicLibraryError("music root cannot be a symlink")
                canonical = raw.resolve(strict=True)
            except (FileNotFoundError, OSError) as exc:
                raise LocalMusicLibraryError("music root does not exist") from exc
            if not stat.S_ISDIR(before.st_mode) or not canonical.is_dir():
                raise LocalMusicLibraryError("music root must be a directory")
            root_fd = _open_absolute_directory(canonical)
            try:
                root_stat = os.fstat(root_fd)
                root_device, root_inode = int(root_stat.st_dev), int(root_stat.st_ino)
            finally:
                os.close(root_fd)

        fingerprint = self.vault.fingerprint(str(canonical))
        root_id = "local-" + fingerprint
        safe_label = _safe_text(label or canonical.name or "Music", "Music")
        encrypted_path = self.vault.encrypt(str(canonical), self._root_context(root_id))
        row = await self._store.call(
            "add_local_root",
            id=root_id,
            label=safe_label,
            encrypted_path=encrypted_path,
            fingerprint=fingerprint,
            root_device=root_device,
            root_inode=root_inode,
            status="ready",
        )
        if row is None:
            row = await self._store.call("get_local_root", root_id)
        return self._public_root(row)

    add_root = setup_root

    async def list_roots(self) -> list[dict[str, Any]]:
        rows = await self._store.call("list_local_roots")
        result = []
        for row in rows:
            public = self._public_root(row)
            if _value(row, "count", _value(row, "track_count")) is None:
                public["count"] = await self._store.count_local_tracks(public["id"])
            result.append(public)
        return result

    async def delete_root(self, root_id: str) -> None:
        """Delete a configured root and fence any scan still in flight."""
        clean = str(root_id or "").strip()
        if not clean:
            raise LocalMusicLibraryError("music root is required")
        async with self._generation_lock:
            self._generation[clean] = self._generation.get(clean, 0) + 1
            try:
                await self._store.call("delete_local_root", clean)
            except LookupError as exc:
                raise LocalMusicLibraryError("unknown music root") from exc

    async def _root(self, root_id: str) -> tuple[Any, Path, str]:
        try:
            row = await self._store.call("get_local_root", root_id)
        except LookupError as exc:
            raise LocalMusicLibraryError("unknown music root") from exc
        if row is None:
            raise LocalMusicLibraryError("unknown music root")
        encrypted = _value(row, "encrypted_path", _value(row, "path_encrypted"))
        try:
            if encrypted is None and hasattr(
                self._store.store, "decrypt_local_root_path"
            ):
                path = Path(
                    await _maybe_await(
                        self._store.store.decrypt_local_root_path(root_id)
                    )
                )
            else:
                if encrypted is None:
                    raise LocalMusicLibraryError("music root has no encrypted path")
                if isinstance(encrypted, memoryview):
                    encrypted = encrypted.tobytes()
                path = Path(
                    self.vault.decrypt(encrypted, self._root_context(root_id))
                )
        except LocalMusicLibraryError:
            raise
        except Exception as exc:
            raise LocalMusicLibraryError("music root path cannot be decrypted") from exc
        fingerprint = str(_value(row, "fingerprint", self.vault.fingerprint(str(path))))
        root_device = _value(row, "root_device")
        root_inode = _value(row, "root_inode")
        if root_device is None or root_inode is None:
            raise LocalMusicLibraryError(
                "music root must be removed and added again to establish its identity"
            )
        return row, path, fingerprint

    async def scan(self, root_id: str) -> dict[str, Any]:
        """Scan one root; cancellation or a newer scan can never publish it."""
        _row, root, fingerprint = await self._root(root_id)
        async with self._generation_lock:
            local_generation = self._generation.get(root_id, 0) + 1
            self._generation[root_id] = local_generation
        persisted_generation = await self._store.call("begin_local_root_scan", root_id)
        generation = (
            int(persisted_generation)
            if persisted_generation is not None
            else local_generation
        )
        try:
            tracks = await asyncio.to_thread(
                _scan_root,
                root,
                root_id,
                fingerprint,
                self.max_file_size,
                int(_value(_row, "root_device")),
                int(_value(_row, "root_inode")),
            )
        except asyncio.CancelledError:
            raise
        except Exception:
            await self._set_status(root_id, generation, "error", 0)
            raise

        # Keep the local fence locked through publication.  This makes stores
        # without their own atomic generation predicate safe as well.
        async with self._generation_lock:
            if self._generation.get(root_id) != local_generation:
                return {"id": root_id, "status": "stale", "count": 0}
            replaced = await self._store.call(
                "replace_local_tracks", root_id, generation, tracks
            )
        if replaced is False:
            return {"id": root_id, "status": "stale", "count": 0}
        await self._set_status(root_id, generation, "ready", len(tracks))
        return {"id": root_id, "status": "ready", "count": len(tracks)}

    scan_root = scan

    async def _set_status(self, root_id: str, generation: int, status: str, count: int) -> None:
        await self._store.call(
            "set_local_root_status", root_id, generation, status, count
        )

    async def list(
        self, root_id: str | None = None, *, offset: int = 0, limit: int = 100
    ) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 500))
        offset = max(0, int(offset))
        rows = await self._store.call("list_local_tracks", root_id, offset, limit)
        return [self._public_track(row) for row in rows]

    list_tracks = list

    async def search(
        self, query: str, *, root_id: str | None = None, limit: int = 50
    ) -> list[dict[str, Any]]:
        query = _safe_text(query, "")
        if not query:
            return []
        rows = await self._store.call(
            "search_local_tracks", query, root_id, max(1, min(int(limit), 100))
        )
        return [self._public_track(row) for row in rows]

    async def resolve_for_stream(self, item_id: str) -> tuple[Path, dict[str, Any]]:
        track = await self._store.call("get_local_track", item_id)
        if track is None:
            raise LocalMusicLibraryError("unknown local track")
        root_id = str(_value(track, "root_id", ""))
        _row, root, _fingerprint = await self._root(root_id)
        relative = str(_value(track, "relative_path", _value(track, "rel_path", "")))
        expected_size = int(_value(track, "size", -1))
        expected_mtime = int(_value(track, "mtime_ns", -1))
        source = await asyncio.to_thread(
            _open_track_descriptor,
            root,
            relative,
            self.max_file_size,
            expected_size,
            expected_mtime,
            int(_value(_row, "root_device")),
            int(_value(_row, "root_inode")),
        )
        source.close()
        return root.joinpath(*PurePosixPath(relative).parts), self._public_track(track)

    async def open_for_stream(self, item_id: str) -> tuple[Any, dict[str, Any]]:
        """Return an already-validated descriptor; callers must close it."""
        track = await self._store.call("get_local_track", item_id)
        if track is None:
            raise LocalMusicLibraryError("unknown local track")
        root_id = str(_value(track, "root_id", ""))
        _row, root, _fingerprint = await self._root(root_id)
        relative = str(_value(track, "relative_path", _value(track, "rel_path", "")))
        source = await asyncio.to_thread(
            _open_track_descriptor,
            root,
            relative,
            self.max_file_size,
            int(_value(track, "size", -1)),
            int(_value(track, "mtime_ns", -1)),
            int(_value(_row, "root_device")),
            int(_value(_row, "root_inode")),
        )
        public = self._public_track(track)
        public["size"] = _stream_size(source)
        return source, public


def _safe_text(value: Any, default: str) -> str:
    text = unicodedata.normalize("NFC", str(value or ""))
    text = _CONTROL_CHARS.sub("", text).strip()
    text = re.sub(r"\s+", " ", text)
    return text[:240] or default


def _normal_relative(path: Path) -> str:
    return unicodedata.normalize("NFC", path.as_posix())


def _track_metadata(relative: Path) -> tuple[str, str, str]:
    stem = _safe_text(relative.stem.replace("_", " "), "Unknown title")
    artist = ""
    title = stem
    if " - " in stem:
        left, right = stem.split(" - ", 1)
        artist, title = _safe_text(left, ""), _safe_text(right, "Unknown title")
    parts = relative.parts[:-1]
    album = _safe_text(parts[-1], "") if parts else ""
    if not artist and len(parts) >= 2:
        artist = _safe_text(parts[-2], "")
    return title, artist, album


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _validate_root(root: Path) -> Path:
    try:
        root_lstat = root.lstat()
        if stat.S_ISLNK(root_lstat.st_mode) or not stat.S_ISDIR(root_lstat.st_mode):
            raise LocalMusicLibraryError("music root is no longer a safe directory")
        canonical = root.resolve(strict=True)
    except OSError as exc:
        raise LocalMusicLibraryError("music root is unavailable") from exc
    if canonical != root:
        raise LocalMusicLibraryError("music root changed since configuration")
    return canonical


def _validate_track_path(
    root: Path, relative_text: str, max_file_size: int
) -> tuple[Path, os.stat_result]:
    canonical_root = _validate_root(root)
    pure = PurePosixPath(unicodedata.normalize("NFC", relative_text))
    if not relative_text or pure.is_absolute() or ".." in pure.parts:
        raise LocalMusicLibraryError("invalid local track path")
    if pure.suffix.lower().lstrip(".") not in SUPPORTED_EXTENSIONS:
        raise LocalMusicLibraryError("unsupported local track format")
    candidate = canonical_root.joinpath(*pure.parts)
    current = canonical_root
    try:
        for part in pure.parts:
            current = current / part
            entry_stat = current.lstat()
            if stat.S_ISLNK(entry_stat.st_mode):
                raise LocalMusicLibraryError("symlinks are not allowed in music roots")
        resolved = candidate.resolve(strict=True)
    except OSError as exc:
        raise LocalMusicLibraryError("local track is unavailable") from exc
    if not _is_within(resolved, canonical_root):
        raise LocalMusicLibraryError("local track escapes its root")
    if not stat.S_ISREG(entry_stat.st_mode):
        raise LocalMusicLibraryError("local track is not a regular file")
    if entry_stat.st_size < 0 or entry_stat.st_size > max_file_size:
        raise LocalMusicLibraryError("local track is too large")
    return resolved, entry_stat


def _open_track_descriptor(
    root: Path,
    relative_text: str,
    max_file_size: int,
    expected_size: int,
    expected_mtime: int,
    expected_root_device: int,
    expected_root_inode: int,
) -> Any:
    """Open every path component with no-follow semantics and verify the fd."""
    if _WINDOWS:
        return _windows_open_track(
            root,
            relative_text,
            max_file_size,
            expected_size,
            expected_mtime,
            expected_root_device,
            expected_root_inode,
        )
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
        raise LocalMusicLibraryError(
            "secure local music streaming is unavailable on this system"
        )
    pure = PurePosixPath(unicodedata.normalize("NFC", relative_text))
    if (
        not relative_text
        or pure.is_absolute()
        or not pure.parts
        or any(part in {"", ".", ".."} for part in pure.parts)
    ):
        raise LocalMusicLibraryError("invalid local track path")
    if pure.suffix.lower().lstrip(".") not in SUPPORTED_EXTENSIONS:
        raise LocalMusicLibraryError("unsupported local track format")

    directory_flags = (
        os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY | os.O_NOFOLLOW
    )
    file_flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW
    parent_fd = _open_verified_root(
        root, expected_root_device, expected_root_inode
    )
    file_fd = -1
    try:
        for part in pure.parts[:-1]:
            next_fd = os.open(part, directory_flags, dir_fd=parent_fd)
            os.close(parent_fd)
            parent_fd = next_fd
        file_fd = os.open(pure.parts[-1], file_flags, dir_fd=parent_fd)
        file_stat = os.fstat(file_fd)
        if not stat.S_ISREG(file_stat.st_mode):
            raise LocalMusicLibraryError("local track is not a regular file")
        if file_stat.st_size < 0 or file_stat.st_size > max_file_size:
            raise LocalMusicLibraryError("local track is too large")
        if (
            file_stat.st_size != expected_size
            or file_stat.st_mtime_ns != expected_mtime
        ):
            raise LocalMusicLibraryError("local track changed since it was indexed")
        source = os.fdopen(file_fd, "rb", closefd=True)
        file_fd = -1
        return source
    except OSError as exc:
        raise LocalMusicLibraryError("local track is unavailable") from exc
    finally:
        if file_fd >= 0:
            os.close(file_fd)
        if parent_fd >= 0:
            os.close(parent_fd)


def _open_absolute_directory(path: Path) -> int:
    """Walk an absolute path from '/' without following any component."""
    if not path.is_absolute():
        raise LocalMusicLibraryError("music root must be an absolute path")
    if not hasattr(os, "O_NOFOLLOW") or not hasattr(os, "O_DIRECTORY"):
        raise LocalMusicLibraryError(
            "secure local music access is unavailable on this system"
        )
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY | os.O_NOFOLLOW
    current_fd = os.open("/", flags)
    try:
        for part in path.parts[1:]:
            next_fd = os.open(part, flags, dir_fd=current_fd)
            os.close(current_fd)
            current_fd = next_fd
        result = current_fd
        current_fd = -1
        return result
    except OSError as exc:
        raise LocalMusicLibraryError("music root is unavailable") from exc
    finally:
        if current_fd >= 0:
            os.close(current_fd)


def _open_verified_root(root: Path, expected_device: int, expected_inode: int) -> int:
    root_fd = _open_absolute_directory(root)
    root_stat = os.fstat(root_fd)
    if (
        root_stat.st_dev != int(expected_device)
        or root_stat.st_ino != int(expected_inode)
    ):
        os.close(root_fd)
        raise LocalMusicLibraryError(
            "music root changed since it was configured; remove and add it again"
        )
    return root_fd


def _scan_root(
    root: Path,
    root_id: str,
    fingerprint: str,
    max_file_size: int,
    expected_root_device: int,
    expected_root_inode: int,
) -> list[dict[str, Any]]:
    if _WINDOWS:
        return _windows_scan_root(
            root,
            root_id,
            fingerprint,
            max_file_size,
            expected_root_device,
            expected_root_inode,
        )
    root_fd = _open_verified_root(
        root, expected_root_device, expected_root_inode
    )
    tracks: list[dict[str, Any]] = []
    try:
        for directory, dirnames, filenames, directory_fd in os.fwalk(
            ".", topdown=True, follow_symlinks=False, dir_fd=root_fd
        ):
            safe_dirs: list[str] = []
            for name in dirnames:
                try:
                    entry = os.stat(
                        name, dir_fd=directory_fd, follow_symlinks=False
                    )
                    if stat.S_ISDIR(entry.st_mode) and not stat.S_ISLNK(entry.st_mode):
                        safe_dirs.append(name)
                except OSError:
                    continue
            dirnames[:] = safe_dirs

            relative_directory = (
                PurePosixPath()
                if directory == "."
                else PurePosixPath(directory)
            )
            for filename in filenames:
                try:
                    file_stat = os.stat(
                        filename, dir_fd=directory_fd, follow_symlinks=False
                    )
                except OSError:
                    continue
                if (
                    not stat.S_ISREG(file_stat.st_mode)
                    or stat.S_ISLNK(file_stat.st_mode)
                    or file_stat.st_size < 0
                    or file_stat.st_size > max_file_size
                ):
                    continue
                relative = relative_directory / filename
                relative_text = _normal_relative(Path(*relative.parts))
                extension = relative.suffix.lower().lstrip(".")
                if extension not in SUPPORTED_EXTENSIONS:
                    continue
                title, artist, album = _track_metadata(Path(*relative.parts))
                item_id = hashlib.sha256(
                    (fingerprint + "\0" + relative_text).encode("utf-8")
                ).hexdigest()
                tracks.append(
                    {
                        "id": item_id,
                        "item_id": item_id,
                        "root_id": root_id,
                        "relative_path": relative_text,
                        "title": title,
                        "artist": artist,
                        "album": album,
                        "mime": _MIME_TYPES.get(
                            extension,
                            mimetypes.guess_type(filename)[0]
                            or "application/octet-stream",
                        ),
                        "size": file_stat.st_size,
                        "mtime_ns": file_stat.st_mtime_ns,
                    }
                )
    finally:
        os.close(root_fd)
    tracks.sort(key=lambda item: (item["relative_path"].casefold(), item["relative_path"]))
    return tracks


@dataclass(frozen=True)
class _WindowsFileInfo:
    volume: int
    index: int
    attributes: int
    size: int
    mtime_ns: int

    @property
    def identity(self) -> tuple[int, int]:
        return self.volume, self.index

    @property
    def is_directory(self) -> bool:
        return bool(self.attributes & 0x10)

    @property
    def is_reparse(self) -> bool:
        return bool(self.attributes & 0x400)


@dataclass
class _WindowsHandle:
    raw: int
    path: Path
    info: _WindowsFileInfo


class _WindowsFileSystem:
    """Small, mockable wrapper around no-follow Windows file handles."""

    def __init__(self) -> None:
        if os.name != "nt":
            raise LocalMusicLibraryError(
                "secure Windows local music access is unavailable on this system"
            )
        import ctypes
        from ctypes import wintypes

        self._ctypes = ctypes
        self._wintypes = wintypes
        self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

        class BY_HANDLE_FILE_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("dwFileAttributes", wintypes.DWORD),
                ("ftCreationTime", wintypes.FILETIME),
                ("ftLastAccessTime", wintypes.FILETIME),
                ("ftLastWriteTime", wintypes.FILETIME),
                ("dwVolumeSerialNumber", wintypes.DWORD),
                ("nFileSizeHigh", wintypes.DWORD),
                ("nFileSizeLow", wintypes.DWORD),
                ("nNumberOfLinks", wintypes.DWORD),
                ("nFileIndexHigh", wintypes.DWORD),
                ("nFileIndexLow", wintypes.DWORD),
            ]

        self._info_type = BY_HANDLE_FILE_INFORMATION
        self._kernel32.CreateFileW.argtypes = [
            wintypes.LPCWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.HANDLE,
        ]
        self._kernel32.CreateFileW.restype = wintypes.HANDLE
        self._kernel32.GetFileInformationByHandle.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(BY_HANDLE_FILE_INFORMATION),
        ]
        self._kernel32.GetFileInformationByHandle.restype = wintypes.BOOL
        self._kernel32.GetFinalPathNameByHandleW.argtypes = [
            wintypes.HANDLE,
            wintypes.LPWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
        ]
        self._kernel32.GetFinalPathNameByHandleW.restype = wintypes.DWORD
        self._kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self._kernel32.CloseHandle.restype = wintypes.BOOL

    @staticmethod
    def _comparable(path: str | os.PathLike[str]) -> str:
        text = str(path)
        if text.startswith("\\\\?\\UNC\\"):
            text = "\\\\" + text[8:]
        elif text.startswith("\\\\?\\"):
            text = text[4:]
        return os.path.normcase(os.path.normpath(os.path.abspath(text)))

    def _open_native(self, path: Path) -> _WindowsHandle:
        ctypes, wintypes = self._ctypes, self._wintypes
        raw = self._kernel32.CreateFileW(
            str(path),
            0x80000000,  # GENERIC_READ
            0x1 | 0x2 | 0x4,  # share read, write and delete
            None,
            3,  # OPEN_EXISTING
            0x02000000 | 0x00200000,  # BACKUP_SEMANTICS | OPEN_REPARSE_POINT
            None,
        )
        invalid = ctypes.c_void_p(-1).value
        if raw == invalid:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            native = int(raw)
            details = self._info_type()
            if not self._kernel32.GetFileInformationByHandle(
                wintypes.HANDLE(native), ctypes.byref(details)
            ):
                raise ctypes.WinError(ctypes.get_last_error())
            length = self._kernel32.GetFinalPathNameByHandleW(
                wintypes.HANDLE(native), None, 0, 0
            )
            if not length:
                raise ctypes.WinError(ctypes.get_last_error())
            buffer = ctypes.create_unicode_buffer(length + 1)
            if not self._kernel32.GetFinalPathNameByHandleW(
                wintypes.HANDLE(native), buffer, len(buffer), 0
            ):
                raise ctypes.WinError(ctypes.get_last_error())
            if self._comparable(buffer.value) != self._comparable(path):
                raise LocalMusicLibraryError("local music path changed while opening")
            ticks = (details.ftLastWriteTime.dwHighDateTime << 32) | (
                details.ftLastWriteTime.dwLowDateTime
            )
            info = _WindowsFileInfo(
                int(details.dwVolumeSerialNumber),
                int((details.nFileIndexHigh << 32) | details.nFileIndexLow),
                int(details.dwFileAttributes),
                int((details.nFileSizeHigh << 32) | details.nFileSizeLow),
                int((ticks - 116444736000000000) * 100),
            )
            return _WindowsHandle(native, path, info)
        except Exception:
            self._kernel32.CloseHandle(wintypes.HANDLE(raw))
            raise

    def open_root(self, path: Path) -> _WindowsHandle:
        if not path.is_absolute():
            raise LocalMusicLibraryError("music root must be an absolute path")
        # Opening each prefix with OPEN_REPARSE_POINT makes junctions, mount
        # points and symbolic links visible rather than traversing them.
        anchor = Path(path.anchor)
        parts = path.parts[1:]
        current = anchor
        last: _WindowsHandle | None = None
        try:
            for part in (None, *parts):
                if part is not None:
                    current = current / part
                candidate = self._open_native(current)
                if candidate.info.is_reparse or not candidate.info.is_directory:
                    self.close(candidate)
                    raise LocalMusicLibraryError(
                        "music root contains a reparse point or non-directory"
                    )
                if last is not None:
                    self.close(last)
                last = candidate
            if last is None:  # pragma: no cover - absolute paths always have an anchor
                raise LocalMusicLibraryError("music root has no absolute anchor")
            return last
        except Exception:
            if last is not None:
                self.close(last)
            raise

    def assert_current(self, handle: _WindowsHandle) -> None:
        current = self.open_root(handle.path)
        try:
            if current.info.identity != handle.info.identity:
                raise LocalMusicLibraryError("local music directory changed while open")
        finally:
            self.close(current)

    def open_child(self, parent: _WindowsHandle, name: str) -> _WindowsHandle:
        if not name or name in {".", ".."} or "\\" in name or "/" in name:
            raise LocalMusicLibraryError("invalid local music entry")
        self.assert_current(parent)
        child = self._open_native(parent.path / name)
        try:
            self.assert_current(parent)
            if child.info.is_reparse:
                raise LocalMusicLibraryError("reparse points are not allowed in music roots")
            return child
        except Exception:
            self.close(child)
            raise

    def names(self, directory: _WindowsHandle) -> Iterable[str]:
        self.assert_current(directory)
        try:
            names = [entry.name for entry in os.scandir(directory.path)]
        except OSError as exc:
            raise LocalMusicLibraryError("local music directory is unavailable") from exc
        self.assert_current(directory)
        return names

    def stream(self, handle: _WindowsHandle) -> Any:
        import msvcrt

        fd = msvcrt.open_osfhandle(handle.raw, os.O_RDONLY | getattr(os, "O_BINARY", 0))
        handle.raw = -1
        return os.fdopen(fd, "rb", closefd=True)

    def close(self, handle: _WindowsHandle) -> None:
        if handle.raw != -1:
            self._kernel32.CloseHandle(self._wintypes.HANDLE(handle.raw))
            handle.raw = -1


_WINDOWS_FILESYSTEM_FACTORY = _WindowsFileSystem


def _windows_filesystem() -> _WindowsFileSystem:
    return _WINDOWS_FILESYSTEM_FACTORY()


def _windows_root_identity(root: Path) -> tuple[int, int]:
    fs = _windows_filesystem()
    handle = None
    try:
        handle = fs.open_root(root)
        return handle.info.identity
    except LocalMusicLibraryError:
        raise
    except OSError as exc:
        raise LocalMusicLibraryError("music root does not exist") from exc
    finally:
        if handle is not None:
            fs.close(handle)


def _windows_verified_root(
    fs: _WindowsFileSystem, root: Path, expected_device: int, expected_inode: int
) -> _WindowsHandle:
    try:
        handle = fs.open_root(root)
    except LocalMusicLibraryError:
        raise
    except OSError as exc:
        raise LocalMusicLibraryError("music root is unavailable") from exc
    if handle.info.identity != (int(expected_device), int(expected_inode)):
        fs.close(handle)
        raise LocalMusicLibraryError(
            "music root changed since it was configured; remove and add it again"
        )
    return handle


def _windows_open_track(
    root: Path,
    relative_text: str,
    max_file_size: int,
    expected_size: int,
    expected_mtime: int,
    expected_root_device: int,
    expected_root_inode: int,
) -> Any:
    pure = _secure_relative(relative_text)
    fs = _windows_filesystem()
    root_handle = _windows_verified_root(
        fs, root, expected_root_device, expected_root_inode
    )
    parent = root_handle
    opened: list[_WindowsHandle] = [root_handle]
    file_handle = None
    try:
        for part in pure.parts[:-1]:
            child = fs.open_child(parent, part)
            opened.append(child)
            if not child.info.is_directory:
                raise LocalMusicLibraryError("local track ancestor is not a directory")
            parent = child
        file_handle = fs.open_child(parent, pure.parts[-1])
        if file_handle.info.is_directory:
            raise LocalMusicLibraryError("local track is not a regular file")
        if file_handle.info.size < 0 or file_handle.info.size > max_file_size:
            raise LocalMusicLibraryError("local track is too large")
        if (
            file_handle.info.size != expected_size
            or file_handle.info.mtime_ns != expected_mtime
        ):
            raise LocalMusicLibraryError("local track changed since it was indexed")
        fs.assert_current(root_handle)
        source = fs.stream(file_handle)
        file_handle = None
        return source
    except OSError as exc:
        raise LocalMusicLibraryError("local track is unavailable") from exc
    finally:
        if file_handle is not None:
            fs.close(file_handle)
        for handle in reversed(opened):
            fs.close(handle)


def _windows_scan_root(
    root: Path,
    root_id: str,
    fingerprint: str,
    max_file_size: int,
    expected_root_device: int,
    expected_root_inode: int,
) -> list[dict[str, Any]]:
    fs = _windows_filesystem()
    root_handle = _windows_verified_root(
        fs, root, expected_root_device, expected_root_inode
    )
    tracks: list[dict[str, Any]] = []
    stack: list[tuple[_WindowsHandle, PurePosixPath]] = [
        (root_handle, PurePosixPath())
    ]
    try:
        while stack:
            directory, relative_directory = stack.pop()
            try:
                for name in fs.names(directory):
                    child = None
                    try:
                        child = fs.open_child(directory, name)
                        relative = relative_directory / name
                        if child.info.is_directory:
                            stack.append((child, relative))
                            child = None
                            continue
                        extension = relative.suffix.lower().lstrip(".")
                        if (
                            extension not in SUPPORTED_EXTENSIONS
                            or child.info.size < 0
                            or child.info.size > max_file_size
                        ):
                            continue
                        relative_path = Path(*relative.parts)
                        relative_text = _normal_relative(relative_path)
                        title, artist, album = _track_metadata(relative_path)
                        item_id = hashlib.sha256(
                            (fingerprint + "\0" + relative_text).encode("utf-8")
                        ).hexdigest()
                        tracks.append(
                            {
                                "id": item_id,
                                "item_id": item_id,
                                "root_id": root_id,
                                "relative_path": relative_text,
                                "title": title,
                                "artist": artist,
                                "album": album,
                                "mime": _MIME_TYPES[extension],
                                "size": child.info.size,
                                "mtime_ns": child.info.mtime_ns,
                            }
                        )
                    except (OSError, LocalMusicLibraryError):
                        continue
                    finally:
                        if child is not None:
                            fs.close(child)
            finally:
                if directory is not root_handle:
                    fs.close(directory)
        fs.assert_current(root_handle)
    finally:
        fs.close(root_handle)
        for directory, _relative in stack:
            fs.close(directory)
    tracks.sort(key=lambda item: (item["relative_path"].casefold(), item["relative_path"]))
    return tracks


def _secure_relative(relative_text: str) -> PurePosixPath:
    pure = PurePosixPath(unicodedata.normalize("NFC", relative_text))
    if (
        not relative_text
        or pure.is_absolute()
        or not pure.parts
        or any(part in {"", ".", ".."} for part in pure.parts)
        or "\\" in relative_text
    ):
        raise LocalMusicLibraryError("invalid local track path")
    if pure.suffix.lower().lstrip(".") not in SUPPORTED_EXTENSIONS:
        raise LocalMusicLibraryError("unsupported local track format")
    return pure


def _stream_size(source: Any) -> int:
    try:
        return int(os.fstat(source.fileno()).st_size)
    except (AttributeError, io.UnsupportedOperation):
        position = source.tell()
        source.seek(0, os.SEEK_END)
        size = source.tell()
        source.seek(position)
        return int(size)