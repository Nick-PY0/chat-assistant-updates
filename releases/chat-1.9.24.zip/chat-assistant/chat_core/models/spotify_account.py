"""Encrypted persistence for the single configured Spotify account."""

from __future__ import annotations

from chat_core.models.google_account import ConnectedAccountStore, OAuthStateError, _utcnow
from chat_core.models.db import Database
from chat_core.security.vault import Vault


class SpotifyAccountStore(ConnectedAccountStore):
    """Connected-account storage isolated in the ``spotify`` vault context."""

    def __init__(self, db: Database, vault: Vault, clock=_utcnow) -> None:
        super().__init__(db, vault, "spotify", clock)


__all__ = ["SpotifyAccountStore", "OAuthStateError"]