"""Provider-generic encrypted connected-account persistence."""

from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from chat_core.models.credentials import iso, parse_iso
from chat_core.models.db import Database
from chat_core.security.vault import Vault


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class OAuthStateError(ValueError):
    pass


@dataclass(frozen=True)
class AccountSecrets:
    client_id: str
    client_secret: str
    access_token: str | None
    refresh_token: str | None
    expires_at: datetime | None
    scopes: tuple[str, ...]


class ConnectedAccountStore:
    def __init__(self, db: Database, vault: Vault, provider: str,
                 clock=_utcnow) -> None:
        if not provider or not provider.replace("_", "").replace("-", "").isalnum():
            raise ValueError("invalid provider")
        self.db, self.vault, self.provider, self.clock = db, vault, provider, clock

    def _context(self, field: str) -> str:
        return f"connected-account:{self.provider}:{field}"

    def _enc(self, value: str, field: str) -> bytes:
        return self.vault.encrypt(value, self._context(field))

    def _dec(self, blob: bytes | None, field: str) -> str | None:
        return self.vault.decrypt(blob, self._context(field)) if blob else None

    async def configure(self, client_id: str, client_secret: str) -> dict:
        if not str(client_id).strip() or not str(client_secret).strip():
            raise ValueError("OAuth client ID and secret are required")
        await self.db.execute(
            """INSERT INTO connected_accounts
               (provider,encrypted_client_id,encrypted_client_secret,status,updated_at)
               VALUES(?,?,?,'configured',?) ON CONFLICT(provider) DO UPDATE SET
               encrypted_client_id=excluded.encrypted_client_id,
               encrypted_client_secret=excluded.encrypted_client_secret,
               encrypted_access_token=NULL,encrypted_refresh_token=NULL,scopes='[]',
               expires_at=NULL,email=NULL,display_name=NULL,status='configured',
               failure_code=NULL,needs_reauthorization=0,selected_calendar_ids='[]',
               writable_calendar_id=NULL,last_sync_at=NULL,updated_at=excluded.updated_at""",
            (self.provider, self._enc(client_id.strip(), "client_id"),
             self._enc(client_secret.strip(), "client_secret"), iso(self.clock())))
        await self.db.execute("DELETE FROM oauth_pending WHERE provider=?", (self.provider,))
        await self._clear_calendar_data()
        return await self.public_metadata()

    async def reset_configuration(self) -> None:
        await self._clear_calendar_data()
        await self.db.execute("DELETE FROM oauth_pending WHERE provider=?", (self.provider,))
        await self.db.execute("DELETE FROM connected_accounts WHERE provider=?", (self.provider,))

    async def disconnect(self, retain_client_config: bool = True) -> dict:
        await self._clear_calendar_data()
        await self.db.execute("DELETE FROM oauth_pending WHERE provider=?", (self.provider,))
        if retain_client_config:
            await self.db.execute(
                """UPDATE connected_accounts SET encrypted_access_token=NULL,
                   encrypted_refresh_token=NULL,scopes='[]',expires_at=NULL,email=NULL,
                   display_name=NULL,status='configured',failure_code=NULL,
                   needs_reauthorization=0,selected_calendar_ids='[]',
                   writable_calendar_id=NULL,last_sync_at=NULL,updated_at=? WHERE provider=?""",
                (iso(self.clock()), self.provider))
        else:
            await self.db.execute("DELETE FROM connected_accounts WHERE provider=?", (self.provider,))
        return await self.public_metadata()

    async def _clear_calendar_data(self) -> None:
        await self.db.execute("DELETE FROM calendar_sync_state WHERE provider=?", (self.provider,))
        await self.db.execute("DELETE FROM calendar_event_cache WHERE provider=?", (self.provider,))
        await self.db.execute(
            """UPDATE calendar_drafts SET status='expired',finished_at=?
               WHERE provider=? AND status='pending'""",
            (iso(self.clock()), self.provider),
        )

    async def secrets(self) -> AccountSecrets:
        row = await self.db.fetchone("SELECT * FROM connected_accounts WHERE provider=?",
                                     (self.provider,))
        if not row:
            raise LookupError(f"{self.provider} is not configured")
        return AccountSecrets(
            self._dec(row["encrypted_client_id"], "client_id") or "",
            self._dec(row["encrypted_client_secret"], "client_secret") or "",
            self._dec(row["encrypted_access_token"], "access_token"),
            self._dec(row["encrypted_refresh_token"], "refresh_token"),
            parse_iso(row["expires_at"]), tuple(json.loads(row["scopes"])))

    async def save_tokens(self, access_token: str, refresh_token: str | None,
                          expires_at: datetime | None, scopes: list[str] | tuple[str, ...]) -> None:
        old = await self.secrets()
        refresh = refresh_token or old.refresh_token
        await self.db.execute(
            """UPDATE connected_accounts SET encrypted_access_token=?,
               encrypted_refresh_token=?,expires_at=?,scopes=?,status='connected',
               failure_code=NULL,needs_reauthorization=0,updated_at=? WHERE provider=?""",
            (self._enc(access_token, "access_token"),
             self._enc(refresh, "refresh_token") if refresh else None, iso(expires_at),
             json.dumps(sorted(set(scopes))), iso(self.clock()), self.provider))

    async def save_identity(self, email: str, display_name: str = "") -> None:
        await self.db.execute(
            "UPDATE connected_accounts SET email=?,display_name=?,updated_at=? WHERE provider=?",
            (str(email)[:320], str(display_name)[:255], iso(self.clock()), self.provider))

    async def mark_failure(self, code: str, reauthorization: bool = False) -> None:
        await self.db.execute(
            """UPDATE connected_accounts SET status=?,failure_code=?,
               needs_reauthorization=?,updated_at=? WHERE provider=?""",
            ("reauthorization_required" if reauthorization else "error",
             code[:80], int(reauthorization), iso(self.clock()), self.provider))

    async def mark_synced(self) -> None:
        await self.db.execute(
            "UPDATE connected_accounts SET last_sync_at=?,status='connected',failure_code=NULL WHERE provider=?",
            (iso(self.clock()), self.provider))

    async def public_metadata(self) -> dict:
        row = await self.db.fetchone(
            """SELECT encrypted_client_id IS NOT NULL AS configured,
               encrypted_access_token IS NOT NULL AS connected,status,email,display_name,
               scopes,expires_at,last_sync_at,failure_code,needs_reauthorization
               FROM connected_accounts WHERE provider=?""", (self.provider,))
        if not row:
            return {"configured": False, "connected": False, "status": "not_configured",
                    "email": None, "display_name": None, "scopes": [], "expires_at": None,
                    "last_sync_at": None, "failure_code": None,
                    "needs_reauthorization": False}
        return {"configured": bool(row["configured"]), "connected": bool(row["connected"]),
                "status": row["status"], "email": row["email"],
                "display_name": row["display_name"], "scopes": json.loads(row["scopes"]),
                "expires_at": row["expires_at"], "last_sync_at": row["last_sync_at"],
                "failure_code": row["failure_code"],
                "needs_reauthorization": bool(row["needs_reauthorization"])}

    async def save_calendar_selection(self, readable: list[str], writable: str | None) -> None:
        clean = list(dict.fromkeys(str(x) for x in readable if x))[:100]
        if writable and writable not in clean:
            raise ValueError("writable calendar must be selected")
        old, _ = await self.selection()
        removed = set(old) - set(clean)
        for cid in removed:
            await self.db.execute(
                "DELETE FROM calendar_sync_state WHERE provider=? AND calendar_id=?",
                (self.provider, cid))
            await self.db.execute(
                "DELETE FROM calendar_event_cache WHERE provider=? AND calendar_id=?",
                (self.provider, cid))
        await self.db.execute(
            "UPDATE connected_accounts SET selected_calendar_ids=?,writable_calendar_id=?,updated_at=? WHERE provider=?",
            (json.dumps(clean), writable, iso(self.clock()), self.provider))

    async def selection(self) -> tuple[list[str], str | None]:
        row = await self.db.fetchone(
            "SELECT selected_calendar_ids,writable_calendar_id FROM connected_accounts WHERE provider=?",
            (self.provider,))
        return (json.loads(row["selected_calendar_ids"]), row["writable_calendar_id"]) if row else ([], None)

    async def create_pending(self, binding: str, ttl_seconds: int = 600) -> tuple[str, str]:
        if not binding:
            raise OAuthStateError("browser binding is required")
        await self.db.execute(
            """DELETE FROM oauth_pending WHERE provider=?
               AND (consumed_at IS NOT NULL OR expires_at<=?)""",
            (self.provider, iso(self.clock())),
        )
        state, verifier = secrets.token_urlsafe(32), secrets.token_urlsafe(64)
        await self.db.execute(
            """INSERT INTO oauth_pending(provider,state_hash,binding_hash,encrypted_verifier,expires_at)
               VALUES(?,?,?,?,?)""",
            (self.provider, _digest(state), _digest(binding), self._enc(verifier, "pkce_verifier"),
             iso(self.clock() + timedelta(seconds=max(60, min(ttl_seconds, 900))))))
        return state, verifier

    async def consume_pending(self, state: str, binding: str) -> str:
        now, state_hash = self.clock(), _digest(state)
        # Binding and expiry are part of the conditional claim, making use atomic.
        changed = await self.db.execute(
            """UPDATE oauth_pending SET consumed_at=? WHERE provider=? AND state_hash=?
               AND binding_hash=? AND consumed_at IS NULL AND expires_at>?""",
            (iso(now), self.provider, state_hash, _digest(binding), iso(now)))
        if changed != 1:
            raise OAuthStateError("OAuth request is invalid, expired, or already used")
        row = await self.db.fetchone(
            "SELECT encrypted_verifier FROM oauth_pending WHERE provider=? AND state_hash=?",
            (self.provider, state_hash))
        return self._dec(row["encrypted_verifier"], "pkce_verifier") if row else ""


class GoogleAccountStore(ConnectedAccountStore):
    def __init__(self, db: Database, vault: Vault, clock=_utcnow) -> None:
        super().__init__(db, vault, "google", clock)