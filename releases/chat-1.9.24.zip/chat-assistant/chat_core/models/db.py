"""SQLite access layer (aiosqlite) + migrations runner."""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

import aiosqlite

from chat_core.paths import resource_root

MIGRATIONS_DIR = resource_root() / "migrations"


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._conn: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        # NORMAL under WAL: integrity is preserved on any crash, but an OS
        # crash / power cut may lose the last moment of commits. Accepted
        # tradeoff: FULL fsyncs every commit, and on Windows (antivirus
        # scanning the db) that stalled writes -- and every dashboard read
        # queues behind writes on this single serialized connection.
        await self._conn.execute("PRAGMA synchronous=NORMAL")
        await self._conn.execute("PRAGMA foreign_keys=ON")
        await self._migrate()

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database not opened")
        return self._conn

    async def _migrate(self) -> None:
        await self.conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT)"
        )
        await self.conn.commit()
        cur = await self.conn.execute("SELECT name FROM schema_migrations")
        applied = {row["name"] for row in await cur.fetchall()}
        for sql_file in sorted(MIGRATIONS_DIR.glob("*.sql")):
            if sql_file.name in applied:
                continue
            script = sql_file.read_text()
            await self.conn.executescript(script)
            await self.conn.execute(
                "INSERT INTO schema_migrations (name, applied_at) VALUES (?, datetime('now'))",
                (sql_file.name,),
            )
            await self.conn.commit()

    # ------------------------------------------------------------------
    async def execute(self, sql: str, params: tuple = ()) -> int:
        """Run a write statement. Returns the affected row count so callers
        can use conditional UPDATEs as atomic state-transition claims."""
        async with self._lock:
            cur = await self.conn.execute(sql, params)
            await self.conn.commit()
            return cur.rowcount

    @asynccontextmanager
    async def transaction(self):
        """Yield the connection inside one serialized immediate transaction.

        Callers must use the yielded connection directly; calling Database
        write helpers from inside this context would try to acquire the same
        lock again.
        """
        async with self._lock:
            await self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
            except BaseException:
                await self.conn.rollback()
                raise
            else:
                await self.conn.commit()

    async def fetchall(self, sql: str, params: tuple = ()) -> list[aiosqlite.Row]:
        async with self._lock:
            cur = await self.conn.execute(sql, params)
            return list(await cur.fetchall())

    async def fetchone(self, sql: str, params: tuple = ()) -> aiosqlite.Row | None:
        async with self._lock:
            cur = await self.conn.execute(sql, params)
            return await cur.fetchone()

    # -- settings kv ----------------------------------------------------
    async def get_setting(self, key: str, default: str | None = None) -> str | None:
        row = await self.fetchone("SELECT value FROM app_settings WHERE key=?", (key,))
        return row["value"] if row else default

    async def set_setting(self, key: str, value: str) -> None:
        await self.execute(
            "INSERT INTO app_settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )

    async def delete_setting(self, key: str) -> None:
        await self.execute("DELETE FROM app_settings WHERE key=?", (key,))

    # -- log ------------------------------------------------------------
    async def log(self, level: str, component: str, message: str) -> None:
        await self.execute(
            "INSERT INTO events_log (ts, level, component, message) VALUES (datetime('now'), ?, ?, ?)",
            (level, component, message[:1000]),
        )
        # keep the log bounded so the DB never grows unbounded on a small machine
        await self.execute(
            "DELETE FROM events_log WHERE id NOT IN (SELECT id FROM events_log ORDER BY id DESC LIMIT 5000)"
        )

    async def usage(self, credential_id: str | None, event: str, detail: str = "") -> None:
        await self.execute(
            "INSERT INTO usage_log (ts, credential_id, event, detail) VALUES (datetime('now'), ?, ?, ?)",
            (credential_id, event, detail[:500]),
        )

    # -- voice sessions & transcripts -----------------------------------
    async def open_voice_session(
        self, session_id: str, provider: str, credential_id: str | None
    ) -> None:
        await self.execute(
            "INSERT INTO voice_sessions (id, provider, credential_id, started_at) "
            "VALUES (?, ?, ?, datetime('now'))",
            (session_id, provider, credential_id),
        )

    async def close_voice_session(self, session_id: str, reason: str) -> None:
        await self.execute(
            "UPDATE voice_sessions SET ended_at = datetime('now'), close_reason = ? "
            "WHERE id = ? AND ended_at IS NULL",
            (reason[:200], session_id),
        )

    async def add_transcript(self, session_id: str, role: str, text: str) -> None:
        """Append one transcript line. Silently ignored if session_id is unknown
        (e.g. if the voice_sessions row was never opened due to a race)."""
        try:
            await self.execute(
                "INSERT INTO transcripts (session_id, ts, role, text) "
                "VALUES (?, datetime('now'), ?, ?)",
                (session_id, role, text[:8000]),
            )
        except Exception:
            pass
