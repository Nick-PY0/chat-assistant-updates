"""Durable provider-neutral music, room, queue, and local-library state."""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import secrets
from datetime import datetime, timezone
from typing import Any, Iterable

from chat_core.models.credentials import iso
from chat_core.models.db import Database
from chat_core.security.vault import Vault

MAX_QUEUE_ITEMS = 500
MAX_FAVORITES_PER_ROOM = 2000
MAX_PLAYLISTS_PER_ROOM = 200
MAX_PLAYLIST_ITEMS = 1000
MAX_LOCAL_TRACKS_PER_ROOT = 20_000
MAX_METADATA_BYTES = 32_000


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _id() -> str:
    return secrets.token_urlsafe(18)


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _text(value: Any, limit: int, field: str, required: bool = False) -> str:
    result = str(value or "").strip()
    if required and not result:
        raise ValueError(f"{field} is required")
    return result[:limit]


def _json_dump(value: Any, *, require_object: bool = False) -> str:
    if value is None:
        value = {}
    if require_object and not isinstance(value, dict):
        raise ValueError("metadata/state must be an object")
    try:
        encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"),
                             sort_keys=True, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("value is not safe JSON") from exc
    if len(encoded.encode("utf-8")) > MAX_METADATA_BYTES:
        raise ValueError("JSON value is too large")
    return encoded


def _json_load(value: str) -> Any:
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return {}


class StaleMusicSessionError(RuntimeError):
    """Raised when a session update loses its session/operation fence."""


class MusicStore:
    def __init__(self, db: Database, vault: Vault, clock=_now) -> None:
        self.db, self.vault, self.clock = db, vault, clock
        self._queue_lock = asyncio.Lock()

    def _time(self) -> str:
        return iso(self.clock()) or ""

    @staticmethod
    def _room(row: Any) -> dict:
        return {"id": row["id"], "name": row["name"],
                "is_default": bool(row["is_default"]),
                "created_at": row["created_at"], "updated_at": row["updated_at"]}

    async def ensure_default_room(self, name: str = "Default") -> dict:
        row = await self.db.fetchone(
            "SELECT * FROM music_rooms WHERE is_default=1 LIMIT 1")
        if row:
            return self._room(row)
        existing = await self.db.fetchone(
            "SELECT * FROM music_rooms ORDER BY created_at,id LIMIT 1")
        if existing:
            await self.set_default_room(existing["id"])
            return (await self.resolve_room(existing["id"]))
        return await self.create_room(name, make_default=True)

    async def list_rooms(self) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM music_rooms ORDER BY is_default DESC,name COLLATE NOCASE,id")
        return [self._room(row) for row in rows]

    async def create_room(self, name: str, *, room_id: str | None = None,
                          make_default: bool = False) -> dict:
        clean = _text(name, 100, "room name", True)
        rid, now = room_id or _id(), self._time()
        count = await self.db.fetchone("SELECT COUNT(*) AS n FROM music_rooms")
        default = bool(make_default or not count or count["n"] == 0)
        await self.db.execute(
            """INSERT INTO music_rooms(id,name,is_default,created_at,updated_at)
               VALUES(?,?,0,?,?)""", (rid, clean, now, now))
        if default:
            await self.set_default_room(rid)
        return await self.resolve_room(rid)

    async def delete_room(self, room: str) -> None:
        resolved = await self.resolve_room(room)
        if resolved["is_default"]:
            raise ValueError("the default room cannot be deleted")
        await self.db.execute("DELETE FROM music_rooms WHERE id=?", (resolved["id"],))

    async def set_default_room(self, room: str) -> dict:
        resolved = await self.resolve_room(room)
        now = self._time()
        await self.db.execute("UPDATE music_rooms SET is_default=0 WHERE is_default=1")
        await self.db.execute(
            "UPDATE music_rooms SET is_default=1,updated_at=? WHERE id=?",
            (now, resolved["id"]))
        return await self.resolve_room(resolved["id"])

    async def resolve_room(self, room: str | None = None) -> dict:
        if room is None or not str(room).strip():
            row = await self.db.fetchone(
                "SELECT * FROM music_rooms WHERE is_default=1 LIMIT 1")
            if not row:
                return await self.ensure_default_room()
        else:
            value = str(room).strip()
            row = await self.db.fetchone(
                "SELECT * FROM music_rooms WHERE id=? OR name=? COLLATE NOCASE LIMIT 1",
                (value, value))
        if not row:
            raise LookupError("music room not found")
        return self._room(row)

    @staticmethod
    def _item(row: Any) -> dict:
        return {
            "id": row["id"], "kind": row["kind"], "title": row["title"],
            "artist": row["artist"], "album": row["album"],
            "duration_ms": row["duration_ms"], "artwork_url": row["artwork_url"],
            "metadata": _json_load(row["metadata_json"]),
            "created_at": row["created_at"], "updated_at": row["updated_at"],
        }

    async def upsert_item(self, item_id: str | None = None, *, kind: str = "track",
                          title: str, artist: str = "", album: str = "",
                          duration_ms: int | None = None,
                          artwork_url: str | None = None,
                          metadata: dict | None = None) -> dict:
        iid, now = item_id or _id(), self._time()
        duration = None if duration_ms is None else max(0, int(duration_ms))
        await self.db.execute(
            """INSERT INTO music_items
               (id,kind,title,artist,album,duration_ms,artwork_url,metadata_json,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,title=excluded.title,
               artist=excluded.artist,album=excluded.album,duration_ms=excluded.duration_ms,
               artwork_url=excluded.artwork_url,metadata_json=excluded.metadata_json,
               updated_at=excluded.updated_at""",
            (iid, _text(kind, 30, "kind", True), _text(title, 500, "title", True),
             _text(artist, 300, "artist"), _text(album, 300, "album"), duration,
             _text(artwork_url, 2000, "artwork URL") or None,
             _json_dump(metadata, require_object=True), now, now))
        return await self.get_item(iid)

    async def get_item(self, item_id: str) -> dict:
        row = await self.db.fetchone("SELECT * FROM music_items WHERE id=?", (item_id,))
        if not row:
            raise LookupError("music item not found")
        return self._item(row)

    async def list_items(self, *, limit: int = 100, offset: int = 0) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM music_items ORDER BY updated_at DESC,id LIMIT ? OFFSET ?",
            (max(1, min(int(limit), 500)), max(0, int(offset))))
        return [self._item(row) for row in rows]

    async def search_items(self, query: str, *, limit: int = 50) -> list[dict]:
        term = str(query).replace("!", "!!").replace("%", "!%").replace("_", "!_")
        rows = await self.db.fetchall(
            """SELECT * FROM music_items
               WHERE title LIKE ? ESCAPE '!' OR artist LIKE ? ESCAPE '!'
                  OR album LIKE ? ESCAPE '!'
               ORDER BY title COLLATE NOCASE,id LIMIT ?""",
            (f"%{term}%", f"%{term}%", f"%{term}%",
             max(1, min(int(limit), 200))))
        return [self._item(row) for row in rows]

    async def _item_ids(self, items: Iterable[str | dict]) -> list[str]:
        ids = [str(x["id"] if isinstance(x, dict) else x) for x in items]
        if ids:
            marks = ",".join("?" for _ in ids)
            rows = await self.db.fetchall(
                f"SELECT id FROM music_items WHERE id IN ({marks})", tuple(ids))
            if len({row["id"] for row in rows}) != len(set(ids)):
                raise LookupError("music item not found")
        return ids

    async def list_queue(self, room: str | None = None) -> list[dict]:
        rid = (await self.resolve_room(room))["id"]
        rows = await self.db.fetchall(
            """SELECT i.*,q.position,q.added_at AS queue_added_at FROM music_queue q
               JOIN music_items i ON i.id=q.item_id WHERE q.room_id=?
               ORDER BY q.position""", (rid,))
        return [dict(self._item(row), position=row["position"],
                     added_at=row["queue_added_at"]) for row in rows]

    async def replace_queue(self, room: str | None, items: Iterable[str | dict]) -> list[dict]:
        async with self._queue_lock:
            return await self._replace_queue_locked(room, items)

    async def _replace_queue_locked(
        self, room: str | None, items: Iterable[str | dict]
    ) -> list[dict]:
        rid, ids = (await self.resolve_room(room))["id"], await self._item_ids(items)
        if len(ids) > MAX_QUEUE_ITEMS:
            raise ValueError("queue is too large")
        await self.db.execute("DELETE FROM music_queue WHERE room_id=?", (rid,))
        now = self._time()
        for position, iid in enumerate(ids):
            await self.db.execute(
                "INSERT INTO music_queue(room_id,position,item_id,added_at) VALUES(?,?,?,?)",
                (rid, position, iid, now))
        return await self.list_queue(rid)

    async def append_queue(self, room: str | None, items: Iterable[str | dict]) -> list[dict]:
        async with self._queue_lock:
            return await self._append_queue_locked(room, items)

    async def _append_queue_locked(
        self, room: str | None, items: Iterable[str | dict]
    ) -> list[dict]:
        rid, ids = (await self.resolve_room(room))["id"], await self._item_ids(items)
        row = await self.db.fetchone(
            "SELECT COUNT(*) AS n,COALESCE(MAX(position),-1) AS p FROM music_queue WHERE room_id=?",
            (rid,))
        if row["n"] + len(ids) > MAX_QUEUE_ITEMS:
            raise ValueError("queue is too large")
        now = self._time()
        for index, iid in enumerate(ids, row["p"] + 1):
            await self.db.execute(
                "INSERT INTO music_queue(room_id,position,item_id,added_at) VALUES(?,?,?,?)",
                (rid, index, iid, now))
        return await self.list_queue(rid)

    async def remove_queue(self, room: str | None, position: int) -> list[dict]:
        async with self._queue_lock:
            rid = (await self.resolve_room(room))["id"]
            changed = await self.db.execute(
                "DELETE FROM music_queue WHERE room_id=? AND position=?",
                (rid, int(position)))
            if not changed:
                raise LookupError("queue position not found")
            rows = await self.db.fetchall(
                "SELECT item_id FROM music_queue WHERE room_id=? ORDER BY position",
                (rid,),
            )
            return await self._replace_queue_locked(
                rid, [row["item_id"] for row in rows]
            )

    async def clear_queue(self, room: str | None = None) -> None:
        async with self._queue_lock:
            rid = (await self.resolve_room(room))["id"]
            await self.db.execute("DELETE FROM music_queue WHERE room_id=?", (rid,))

    async def favorite(self, room: str | None, item_id: str) -> dict:
        rid = (await self.resolve_room(room))["id"]
        await self.get_item(item_id)
        existing = await self.db.fetchone(
            "SELECT 1 FROM music_favorites WHERE room_id=? AND item_id=?",
            (rid, item_id))
        count = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM music_favorites WHERE room_id=?", (rid,))
        if not existing and count["n"] >= MAX_FAVORITES_PER_ROOM:
            raise ValueError("favorites collection is full")
        await self.db.execute(
            "INSERT OR IGNORE INTO music_favorites(room_id,item_id,created_at) VALUES(?,?,?)",
            (rid, item_id, self._time()))
        return await self.get_item(item_id)

    async def unfavorite(self, room: str | None, item_id: str) -> None:
        rid = (await self.resolve_room(room))["id"]
        await self.db.execute(
            "DELETE FROM music_favorites WHERE room_id=? AND item_id=?", (rid, item_id))

    async def list_favorites(self, room: str | None = None) -> list[dict]:
        rid = (await self.resolve_room(room))["id"]
        rows = await self.db.fetchall(
            """SELECT i.*,f.created_at AS favorite_at FROM music_favorites f
               JOIN music_items i ON i.id=f.item_id WHERE f.room_id=?
               ORDER BY f.created_at DESC,i.id""", (rid,))
        return [dict(self._item(row), favorited_at=row["favorite_at"]) for row in rows]

    @staticmethod
    def _playlist(row: Any) -> dict:
        return {"id": row["id"], "room_id": row["room_id"], "name": row["name"],
                "description": row["description"], "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                **({"item_count": row["item_count"]} if "item_count" in row.keys() else {})}

    async def create_playlist(self, room: str | None, name: str, description: str = "",
                              *, playlist_id: str | None = None) -> dict:
        rid = (await self.resolve_room(room))["id"]
        count = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM music_playlists WHERE room_id=?", (rid,))
        if count["n"] >= MAX_PLAYLISTS_PER_ROOM:
            raise ValueError("playlist collection is full")
        pid, now = playlist_id or _id(), self._time()
        await self.db.execute(
            """INSERT INTO music_playlists(id,room_id,name,description,created_at,updated_at)
               VALUES(?,?,?,?,?,?)""",
            (pid, rid, _text(name, 200, "playlist name", True),
             _text(description, 2000, "description"), now, now))
        return await self.get_playlist(pid)

    async def get_playlist(self, playlist_id: str) -> dict:
        row = await self.db.fetchone(
            """SELECT p.*,COUNT(pi.item_id) AS item_count FROM music_playlists p
               LEFT JOIN music_playlist_items pi ON pi.playlist_id=p.id
               WHERE p.id=? GROUP BY p.id""", (playlist_id,))
        if not row:
            raise LookupError("playlist not found")
        result = self._playlist(row)
        result["items"] = await self.list_playlist_items(playlist_id)
        return result

    async def list_playlists(self, room: str | None = None) -> list[dict]:
        rid = (await self.resolve_room(room))["id"]
        rows = await self.db.fetchall(
            """SELECT p.*,COUNT(pi.item_id) AS item_count FROM music_playlists p
               LEFT JOIN music_playlist_items pi ON pi.playlist_id=p.id
               WHERE p.room_id=? GROUP BY p.id ORDER BY p.name COLLATE NOCASE,p.id""", (rid,))
        return [self._playlist(row) for row in rows]

    async def update_playlist(self, playlist_id: str, *, name: str | None = None,
                              description: str | None = None) -> dict:
        old = await self.get_playlist(playlist_id)
        await self.db.execute(
            "UPDATE music_playlists SET name=?,description=?,updated_at=? WHERE id=?",
            (_text(name if name is not None else old["name"], 200, "playlist name", True),
             _text(description if description is not None else old["description"],
                   2000, "description"), self._time(), playlist_id))
        return await self.get_playlist(playlist_id)

    async def delete_playlist(self, playlist_id: str) -> None:
        changed = await self.db.execute("DELETE FROM music_playlists WHERE id=?",
                                        (playlist_id,))
        if not changed:
            raise LookupError("playlist not found")

    async def list_playlist_items(self, playlist_id: str) -> list[dict]:
        rows = await self.db.fetchall(
            """SELECT i.*,pi.position,pi.added_at AS playlist_added_at
               FROM music_playlist_items pi JOIN music_items i ON i.id=pi.item_id
               WHERE pi.playlist_id=? ORDER BY pi.position""", (playlist_id,))
        return [dict(self._item(row), position=row["position"],
                     added_at=row["playlist_added_at"]) for row in rows]

    async def replace_playlist_items(self, playlist_id: str,
                                     items: Iterable[str | dict]) -> list[dict]:
        await self.get_playlist(playlist_id)
        ids = await self._item_ids(items)
        if len(ids) > MAX_PLAYLIST_ITEMS:
            raise ValueError("playlist is too large")
        await self.db.execute(
            "DELETE FROM music_playlist_items WHERE playlist_id=?", (playlist_id,))
        now = self._time()
        for position, iid in enumerate(ids):
            await self.db.execute(
                """INSERT INTO music_playlist_items(playlist_id,position,item_id,added_at)
                   VALUES(?,?,?,?)""", (playlist_id, position, iid, now))
        await self.db.execute("UPDATE music_playlists SET updated_at=? WHERE id=?",
                              (now, playlist_id))
        return await self.list_playlist_items(playlist_id)

    async def append_playlist_items(self, playlist_id: str,
                                    items: Iterable[str | dict]) -> list[dict]:
        current = await self.list_playlist_items(playlist_id)
        return await self.replace_playlist_items(
            playlist_id, [x["id"] for x in current] + await self._item_ids(items))

    async def remove_playlist_item(self, playlist_id: str, position: int) -> list[dict]:
        current = await self.list_playlist_items(playlist_id)
        if position < 0 or position >= len(current):
            raise LookupError("playlist position not found")
        del current[position]
        return await self.replace_playlist_items(playlist_id, [x["id"] for x in current])

    def _target_context(self, room_id: str, provider: str) -> str:
        return f"music-target:{room_id}:{provider}"

    async def set_target_mapping(self, room: str | None, provider: str,
                                 target_id: str, label: str = "") -> dict:
        rid = (await self.resolve_room(room))["id"]
        clean_provider = _text(provider, 50, "provider", True).lower()
        target = _text(target_id, 2000, "target ID", True)
        await self.db.execute(
            """INSERT INTO music_room_targets
               (room_id,provider,encrypted_target_id,target_ref,label,updated_at)
               VALUES(?,?,?,?,?,?) ON CONFLICT(room_id,provider) DO UPDATE SET
               encrypted_target_id=excluded.encrypted_target_id,
               target_ref=excluded.target_ref,label=excluded.label,updated_at=excluded.updated_at""",
            (rid, clean_provider,
             self.vault.encrypt(target, self._target_context(rid, clean_provider)),
             _hash(f"{clean_provider}\0{target}")[:24],
             _text(label, 200, "label"), self._time()))
        return await self.get_target_mapping(rid, clean_provider)

    @staticmethod
    def _target(row: Any) -> dict:
        return {"room_id": row["room_id"], "provider": row["provider"],
                "target_ref": row["target_ref"], "label": row["label"],
                "updated_at": row["updated_at"]}

    async def list_target_mappings(self, room: str | None = None) -> list[dict]:
        rid = (await self.resolve_room(room))["id"]
        rows = await self.db.fetchall(
            "SELECT * FROM music_room_targets WHERE room_id=? ORDER BY provider", (rid,))
        return [self._target(row) for row in rows]

    async def get_target_mapping(self, room: str | None, provider: str) -> dict:
        rid = (await self.resolve_room(room))["id"]
        row = await self.db.fetchone(
            "SELECT * FROM music_room_targets WHERE room_id=? AND provider=?",
            (rid, str(provider).strip().lower()))
        if not row:
            raise LookupError("music target mapping not found")
        return self._target(row)

    async def delete_target_mapping(self, room: str | None, provider: str) -> None:
        rid = (await self.resolve_room(room))["id"]
        clean_provider = _text(provider, 50, "provider", True).lower()
        changed = await self.db.execute(
            "DELETE FROM music_room_targets WHERE room_id=? AND provider=?",
            (rid, clean_provider),
        )
        if not changed:
            raise LookupError("music target mapping not found")

    async def decrypt_target_id(self, room: str | None, provider: str) -> str:
        rid = (await self.resolve_room(room))["id"]
        clean_provider = str(provider).strip().lower()
        row = await self.db.fetchone(
            "SELECT encrypted_target_id FROM music_room_targets WHERE room_id=? AND provider=?",
            (rid, clean_provider))
        if not row:
            raise LookupError("music target mapping not found")
        return self.vault.decrypt(
            row["encrypted_target_id"], self._target_context(rid, clean_provider))

    @staticmethod
    def _session(row: Any) -> dict:
        return {"room_id": row["room_id"], "session_id": row["session_id"],
                "operation_id": row["operation_id"], "state": _json_load(row["state_json"]),
                "active": bool(row["active"]), "started_at": row["started_at"],
                "updated_at": row["updated_at"]}

    async def begin_session(self, room: str | None, session_id: str,
                            operation_id: str, state: dict | None = None) -> dict:
        rid, now = (await self.resolve_room(room))["id"], self._time()
        await self.db.execute(
            """INSERT INTO music_sessions
               (room_id,session_id,operation_id,state_json,active,started_at,updated_at)
               VALUES(?,?,?,?,1,?,?) ON CONFLICT(room_id) DO UPDATE SET
               session_id=excluded.session_id,operation_id=excluded.operation_id,
               state_json=excluded.state_json,active=1,started_at=excluded.started_at,
               updated_at=excluded.updated_at""",
            (rid, _text(session_id, 200, "session ID", True),
             _text(operation_id, 200, "operation ID", True),
             _json_dump(state, require_object=True), now, now))
        result = await self.get_active_session(rid)
        assert result is not None
        return result

    async def update_session(self, room: str | None, session_id: str,
                             expected_operation_id: str, *,
                             operation_id: str | None = None,
                             state: dict | None = None,
                             active: bool = True) -> dict | None:
        rid, now = (await self.resolve_room(room))["id"], self._time()
        current = await self.db.fetchone(
            """SELECT state_json,operation_id FROM music_sessions
               WHERE room_id=? AND session_id=? AND operation_id=? AND active=1""",
            (rid, session_id, expected_operation_id))
        if not current:
            raise StaleMusicSessionError("stale music session update rejected")
        next_operation = _text(operation_id or current["operation_id"], 200,
                               "operation ID", True)
        changed = await self.db.execute(
            """UPDATE music_sessions SET operation_id=?,state_json=?,active=?,updated_at=?
               WHERE room_id=? AND session_id=? AND operation_id=? AND active=1""",
            (next_operation,
             _json_dump(state if state is not None else _json_load(current["state_json"]),
                        require_object=True),
             int(active), now, rid, session_id, expected_operation_id))
        if changed != 1:
            raise StaleMusicSessionError("stale music session update rejected")
        return await self.get_active_session(rid)

    async def get_active_session(self, room: str | None = None) -> dict | None:
        rid = (await self.resolve_room(room))["id"]
        row = await self.db.fetchone(
            "SELECT * FROM music_sessions WHERE room_id=? AND active=1", (rid,))
        return self._session(row) if row else None

    def _root_context(self, root_id: str) -> str:
        return f"music-local-root:{root_id}"

    def _track_context(self, root_id: str, track_ref: str) -> str:
        return f"music-local-track:{root_id}:{track_ref}"

    @staticmethod
    def _root(row: Any) -> dict:
        return {"id": row["id"], "root_ref": row["path_ref"], "label": row["label"],
                "root_device": row["root_device"], "root_inode": row["root_inode"],
                "created_at": row["created_at"], "updated_at": row["updated_at"]}

    async def create_local_root(self, path: str, label: str = "",
                                *, root_id: str | None = None,
                                root_device: int | None = None,
                                root_inode: int | None = None) -> dict:
        absolute = os.path.abspath(os.path.expanduser(_text(path, 4096, "path", True)))
        rid, now = root_id or _id(), self._time()
        await self.db.execute(
            """INSERT INTO music_local_roots
               (id,encrypted_path,path_ref,label,root_device,root_inode,created_at,updated_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (rid, self.vault.encrypt(absolute, self._root_context(rid)),
              _hash(absolute)[:24], _text(label, 200, "label"),
              root_device, root_inode, now, now))
        return await self.get_local_root(rid)

    async def list_local_roots(self) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT * FROM music_local_roots ORDER BY label COLLATE NOCASE,id")
        return [self._root(row) for row in rows]

    async def get_local_root(self, root_id: str) -> dict:
        row = await self.db.fetchone("SELECT * FROM music_local_roots WHERE id=?",
                                     (root_id,))
        if not row:
            raise LookupError("local music root not found")
        return self._root(row)

    async def decrypt_local_root_path(self, root_id: str) -> str:
        row = await self.db.fetchone(
            "SELECT encrypted_path FROM music_local_roots WHERE id=?", (root_id,))
        if not row:
            raise LookupError("local music root not found")
        return self.vault.decrypt(row["encrypted_path"], self._root_context(root_id))

    async def update_local_root(self, root_id: str, *, path: str | None = None,
                                label: str | None = None,
                                root_device: int | None = None,
                                root_inode: int | None = None) -> dict:
        old = await self.db.fetchone("SELECT * FROM music_local_roots WHERE id=?",
                                     (root_id,))
        if not old:
            raise LookupError("local music root not found")
        absolute = (os.path.abspath(os.path.expanduser(_text(path, 4096, "path", True)))
                    if path is not None else
                    self.vault.decrypt(old["encrypted_path"], self._root_context(root_id)))
        await self.db.execute(
            """UPDATE music_local_roots SET encrypted_path=?,path_ref=?,label=?,
               root_device=?,root_inode=?,updated_at=?
               WHERE id=?""",
            (self.vault.encrypt(absolute, self._root_context(root_id)),
             _hash(absolute)[:24],
             _text(label if label is not None else old["label"], 200, "label"),
              root_device if root_device is not None else old["root_device"],
              root_inode if root_inode is not None else old["root_inode"],
              self._time(), root_id))
        return await self.get_local_root(root_id)

    async def set_local_root_identity(
        self, root_id: str, root_device: int, root_inode: int
    ) -> dict:
        changed = await self.db.execute(
            """UPDATE music_local_roots SET root_device=?,root_inode=?,updated_at=?
               WHERE id=?""",
            (int(root_device), int(root_inode), self._time(), root_id),
        )
        if not changed:
            raise LookupError("local music root not found")
        return await self.get_local_root(root_id)

    async def delete_local_root(self, root_id: str) -> None:
        changed = await self.db.execute("DELETE FROM music_local_roots WHERE id=?",
                                        (root_id,))
        if not changed:
            raise LookupError("local music root not found")

    @staticmethod
    def _track_public(row: Any) -> dict:
        return {"root_id": row["root_id"], "track_ref": row["track_ref"],
                "item_id": row["item_id"], "updated_at": row["updated_at"]}

    async def replace_local_tracks(self, root_id: str, tracks: Iterable[dict]) -> list[dict]:
        await self.get_local_root(root_id)
        values = list(tracks)
        if len(values) > MAX_LOCAL_TRACKS_PER_ROOT:
            raise ValueError("local track collection is too large")
        prepared: list[tuple[str, str, str]] = []
        for track in values:
            if not isinstance(track, dict):
                raise ValueError("local track must be an object")
            iid = _text(track.get("item_id"), 200, "item ID", True)
            await self.get_item(iid)
            path = _text(track.get("path"), 4096, "track path", True)
            metadata = dict(track.get("metadata") or {})
            metadata["path"] = path
            encoded = _json_dump(metadata, require_object=True)
            prepared.append((_hash(path)[:24], iid, encoded))
        if len({x[0] for x in prepared}) != len(prepared):
            raise ValueError("duplicate local track path")
        await self.db.execute("DELETE FROM music_local_tracks WHERE root_id=?", (root_id,))
        now = self._time()
        for track_ref, iid, encoded in prepared:
            await self.db.execute(
                """INSERT INTO music_local_tracks
                   (root_id,track_ref,item_id,encrypted_metadata,updated_at)
                   VALUES(?,?,?,?,?)""",
                (root_id, track_ref, iid,
                 self.vault.encrypt(encoded, self._track_context(root_id, track_ref)), now))
        return await self.list_local_tracks(root_id)

    async def list_local_tracks(self, root_id: str, *, limit: int = 500,
                                offset: int = 0) -> list[dict]:
        await self.get_local_root(root_id)
        rows = await self.db.fetchall(
            """SELECT root_id,track_ref,item_id,updated_at FROM music_local_tracks
               WHERE root_id=? ORDER BY track_ref LIMIT ? OFFSET ?""",
            (root_id, max(1, min(int(limit), 1000)), max(0, int(offset))))
        return [self._track_public(row) for row in rows]

    async def get_local_track(self, root_id: str, track_ref: str) -> dict:
        row = await self.db.fetchone(
            """SELECT root_id,track_ref,item_id,updated_at FROM music_local_tracks
               WHERE root_id=? AND track_ref=?""", (root_id, track_ref))
        if not row:
            raise LookupError("local music track not found")
        return self._track_public(row)

    async def decrypt_local_track_metadata(self, root_id: str,
                                           track_ref: str) -> dict:
        row = await self.db.fetchone(
            """SELECT encrypted_metadata FROM music_local_tracks
               WHERE root_id=? AND track_ref=?""", (root_id, track_ref))
        if not row:
            raise LookupError("local music track not found")
        value = self.vault.decrypt(
            row["encrypted_metadata"], self._track_context(root_id, track_ref))
        result = _json_load(value)
        if not isinstance(result, dict):
            raise ValueError("invalid local track metadata")
        return result