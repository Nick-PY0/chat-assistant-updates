# Chat YouTube Companion (Chrome / Edge extension)

An **opt-in** companion extension that lets your local Chat (Jarvis) assistant
control **regular YouTube playback** in your own browser through an authenticated
loopback WebSocket connection to the Chat backend's `/ws/companion` endpoint.

The extension implements the **client side** of the Chat CompanionBridge v1
protocol (`apps/tool_service/companion_bridge.py`). Full protocol details are in
[`PROTOCOL.md`](./PROTOCOL.md).

It is intentionally narrow:

* **YouTube only.** Runs exclusively on `https://www.youtube.com/*`.
* **No broad permissions.** Declared permissions: `storage`, `tabs`, `alarms`.
  Host permissions: `https://www.youtube.com/*` only.
* **Loopback only.** The WebSocket connection goes only to `127.0.0.1` /
  `localhost`. A LAN device can reach the Chat dashboard, but never the companion socket.
* **Authenticated.** A one-time pairing token from the Chat dashboard yields a
  persistent bridge secret. The token is never stored — it is cleared from
  memory the moment the server returns the secret.
* **Ad passivity.** While YouTube is showing an ad, ALL commands (including
  navigation, play, pause, seek, volume) are rejected. The assistant waits.
* **Canonical navigation only.** `navigate_video` and `navigate_playlist`
  commands navigate to
  `https://www.youtube.com/watch?v=<id>` or `playlist?list=<id>` — URLs
  constructed from server-validated ids only, never from a raw URL.
* **Standard HTML5 controls only.** Pause, stop, seek, volume, and mute use
  the standard `<video>` element API only.

## Protocol summary

See [`PROTOCOL.md`](./PROTOCOL.md) for the full specification. In brief:

| Direction | Frame | Meaning |
|-----------|-------|---------|
| Server → ext | `welcome` | Socket accepted, protocol version |
| Server → ext | `paired` + `auth_ok` | First pairing succeeded, secret issued |
| Server → ext | `auth_ok` | Reconnect authenticated |
| Server → ext | `auth_error` | Authentication rejected (socket closed) |
| Server → ext | `revoked` | Owner revoked/rotated — forget secret |
| Server → ext | `command` | Media command with `id`, `session`, `target`, `action`, args |
| Server → ext | `ping` | Liveness probe |
| Ext → server | `hello` | `token` (first pair) or `secret` (reconnect) |
| Ext → server | `ack` | Command result: `{id, ok, error?}` |
| Ext → server | `state` | Playback state with `session` + `target` fencing |
| Ext → server | `pong` | Reply to ping |

Supported actions: `navigate_video`, `navigate_playlist`, `play`, `pause`,
`stop`, `next`, `previous`, `seek`, `restart`, `set_volume`,
`adjust_volume`, `mute`, `unmute`, `duck`, and `restore`.

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | MV3, YouTube-only scope, minimal permissions |
| `background.js` | Service worker: bridge WebSocket client, auth, command routing, canonical navigation, ad gate |
| `content.js` | YouTube observer: HTML5 video state, ad detection, command execution |
| `common.js` | Shared constants + validators (loopback URL, ids, tokens, actions) |
| `options.html/js` | Pairing & settings page |
| `popup.html/js` | Toolbar status popup |
| `ui.css` | Styling |
| `icons/` | Extension icons |
| `PROTOCOL.md` | Full wire protocol specification |
| `harness/bridge_harness.js` | Node test bridge (server side, NOT shipped) |
| `harness/contract_tests.js` | Protocol contract fixture tests (NOT shipped) |
| `harness/static_check.js` | Source invariant validator (NOT shipped) |
| `package.sh` | Builds the distributable zip (excludes harness + credentials) |

## Install (developer/unpacked)

1. Open `chrome://extensions` (Chrome) or `edge://extensions` (Edge).
2. Enable **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select this `deployment/chrome_extension` folder.

## Pair with Chat

1. Start Chat. Open the Chat dashboard → **Settings → YouTube Companion** →
   **Generate pairing token**. Note the displayed bridge address and token.
2. Click the extension toolbar icon → **Pairing & settings**.
3. Enter the exact **bridge address** shown by Chat Settings, without the
   final `/ws/companion` path (for example `ws://127.0.0.1:8757`). The
   extension appends `/ws/companion` automatically.

   Chat runs the companion bridge on its own loopback port, always plain
   `ws://`, even when the dashboard itself is HTTPS. This is deliberate: a
   browser extension has no way to approve Chat's self-signed local
   certificate, so a `wss://` address fails with an unexplained connection
   error and pairing can never complete. The plain-`ws://` bridge is bound
   strictly to `127.0.0.1`, authenticates every frame, and carries only media
   commands, so nothing leaves the computer and no credential is exposed.
   Version 1.0.2 also explicitly requests access to only `127.0.0.1` and
   `localhost`, which Chrome requires for a service worker to reach Chat's
   local bridge; it still cannot reach any other local or network address.
   Version 1.0.3 runs the tokenless **Test connection** check directly in this
   extension page. That avoids a Chrome service-worker message-port timeout
   which could report an unavailable bridge even when Chat was listening.
   Version 1.0.4 acknowledges **Pair now** synchronously before the WebSocket
   handshake, avoiding the same message-port race during pairing.
   Version 1.0.6 routes the extension's private UI message types directly,
   instead of relying on Chrome's optional sender metadata. That makes pairing
   work whether the options page is opened in a tab, popup, or extension page.
   Set `companion_bridge_port` in settings to pin a specific port.
4. Paste the **one-time pairing token** (shown once in the dashboard).
5. Click **Pair now**.

The extension sends a `hello` frame with the token over the loopback WebSocket.
The server responds with `paired` (bridge secret) + `auth_ok`. The extension
stores only the secret — the token is discarded immediately after the server
issues the secret.

After pairing, the popup shows **Connected**. Open a YouTube tab. Chat can now
control playback via the bridge.

## Test with the local harness (no Chat required)

```bash
cd deployment/chrome_extension
node harness/bridge_harness.js
# Prints ws://127.0.0.1:8757 and a pairing token.
# Enter these in the pairing page, then type commands at the harness prompt.
```

Run protocol contract tests:

```bash
node harness/contract_tests.js
```

Run static source checks:

```bash
node harness/static_check.js
```

## Package for distribution

```bash
./package.sh
# Produces chat-youtube-companion-<version>.zip
# Excludes harness/, package.sh, README.md, and all credential-like files.
```

## Uninstall / revoke

1. **Unpair** in the options page — clears the bridge secret from this browser.
2. In the Chat dashboard, **Revoke** (or **Rotate**) the companion token so the
   old secret is invalidated server-side.
3. To remove the extension: `chrome://extensions` → Chat YouTube Companion →
   **Remove**.

## Security

* Loopback-only. The Chat server enforces this server-side too before upgrading.
* One-time token → persistent bridge secret. Token is never persisted.
* Secret held in `chrome.storage.local`, only in the background worker. Never logged, never sent to the content script.
* On `auth_error` (bad secret): secret is cleared, extension reports "unpaired".
* On `revoked`: secret is cleared, reconnect is suppressed until re-pairing.
* Navigation uses only server-validated video/playlist ids → canonical YouTube URLs.
* Ad passivity: ALL actions blocked during ad detection.
* State frames fenced by `session` + `target: "browser_companion"`.
