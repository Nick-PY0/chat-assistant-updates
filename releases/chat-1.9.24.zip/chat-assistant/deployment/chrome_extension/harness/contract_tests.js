#!/usr/bin/env node
/*
 * contract_tests.js — dependency-free protocol contract fixture tests.
 *
 * Authority: apps/tool_service/COMPANION_PROTOCOL.md
 *
 * Tests the extension's protocol logic (pure functions) against the exact
 * CompanionBridge v1 contract. No npm packages. No browser.
 *
 * Run:  node harness/contract_tests.js
 * Exit: 0 = all passed, non-zero = failures.
 */
"use strict";

const crypto = require("crypto");
const assert = require("assert/strict");

let passed = 0, failed = 0;
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

async function runAll() {
  for (const t of tests) {
    try {
      await t.fn();
      console.log("  ok  " + t.name);
      passed++;
    } catch (e) {
      console.log("FAIL  " + t.name);
      console.log("      " + (e.message || String(e)));
      failed++;
    }
  }
}

// ---------------------------------------------------------------------------
// Pure protocol logic (mirrors background.js and content.js)
// ---------------------------------------------------------------------------
const TARGET_ID       = "browser_companion";
const PROTOCOL_VERSION = 1;

// Exact action allowlist from COMPANION_PROTOCOL.md §command table.
const COMPANION_ACTIONS = [
  "navigate_video", "navigate_playlist",
  "play", "pause", "stop",
  "next", "previous",
  "seek", "restart",
  "set_volume", "adjust_volume",
  "mute", "unmute",
  "duck", "restore",
];

// FULL AD PASSIVITY: ad-blocked set is EXACTLY the full action set — no
// exceptions (incl. next/previous, duck/restore).
const AD_BLOCKED_ACTIONS = new Set(COMPANION_ACTIONS);

// Voice-focus lifecycle actions (mirrors content.js).
const VOICE_FOCUS_ACTIONS = new Set(["duck", "restore"]);

// Valid wire statuses for state frames.
const VALID_WIRE_STATUSES = new Set([
  "playing", "paused", "ended", "buffering", "stopped", "error",
]);

// Strict ID validators (mirrors common.js).
const VIDEO_ID_RE    = /^[A-Za-z0-9_-]{11}$/;
const PLAYLIST_ID_RE = /^(?:PL|UU|FL|OL|RD|UL|LP)[A-Za-z0-9_-]{10,42}$/;
const PRIVATE_PL     = ["LL", "WL", "HL"];

function validateVideoId(raw) {
  const t = String(raw || "").trim();
  if (!VIDEO_ID_RE.test(t)) throw new Error("Invalid video id: " + t);
  return t;
}
function validatePlaylistId(raw) {
  const t = String(raw || "").trim();
  if (!PLAYLIST_ID_RE.test(t)) throw new Error("Invalid playlist id: " + t);
  if (PRIVATE_PL.includes(t.slice(0, 2))) throw new Error("Private playlist");
  return t;
}
function canonicalWatchUrl(vid) {
  return "https://www.youtube.com/watch?v=" + validateVideoId(vid);
}
function canonicalPlaylistUrl(pid) {
  return "https://www.youtube.com/playlist?list=" + validatePlaylistId(pid);
}

// Bridge base URL validator (mirrors common.js).
const LOOPBACK = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);
function validateBridgeBase(raw) {
  const text = String(raw || "").trim();
  if (!text) throw new Error("empty");
  let u;
  try { u = new URL(text); } catch (_e) { throw new Error("not a URL"); }
  if (!["ws:", "wss:", "http:", "https:"].includes(u.protocol)) throw new Error("bad protocol");
  if (!LOOPBACK.has(u.hostname.toLowerCase())) throw new Error("not loopback");
  return u.origin;
}

// UI routing mirrors background.js. MessageSender metadata varies between an
// extension popup, options page, and options tab, so the private message type
// is the stable boundary. External pages use onMessageExternal, which is not
// registered by this extension.
const UI_MESSAGE_TYPES = new Set(["get_status", "pair", "unpair", "test_bridge"]);
function isUiRequest(message) {
  return !!message && UI_MESSAGE_TYPES.has(message.type);
}

// Param extractor (mirrors background.js extractParams).
function extractParams(action, frame) {
  const nc = (v, lo, hi) => { const n = Number(v); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : undefined; };
  switch (action) {
    case "seek":         return { offset_seconds: nc(frame.offset_seconds, -86400, 86400), target_seconds: nc(frame.target_seconds, 0, 86400) };
    case "set_volume":   return { volume: nc(frame.volume, 0, 100) };
    case "adjust_volume":return { delta:  nc(frame.delta, -100, 100) };
    // duck: payload field is "volume" per COMPANION_PROTOCOL.md §duck
    case "duck":         return { volume: nc(frame.volume, 0, 100) !== undefined ? nc(frame.volume, 0, 100) : 20 };
    default:             return {};
  }
}

// Command router — a faithful browser-level simulation of background.js.
//
// opts:
//   adPlaying        {bool}  the flag maintained from the last content state.
//   existingTab      {bool}  whether a YouTube target tab already exists.
//   freshAdCheck     {"ad"|"no_ad"|"unreachable"}
//                            what the SYNCHRONOUS pre-navigation ad probe returns
//                            for an existing tab. Defaults to "no_ad".
function makeRouter(opts = {}) {
  const adPlaying    = !!opts.adPlaying;
  const existingTab  = opts.existingTab !== false; // default: a tab exists
  const freshAdCheck = opts.freshAdCheck || "no_ad";

  const acks        = [];
  const navsUpdate  = []; // tabs.update on an existing tab
  const navsCreate  = []; // tabs.create (new tab)
  const contentCmds = [];
  const adChecks    = []; // record of synchronous ad-check probes performed

  function ackOk(id)       { acks.push({ id, ok: true }); }
  function ackErr(id, err) { acks.push({ id, ok: false, error: err }); }

  // Simulate the synchronous fresh ad check against a content script.
  //   returns { ok:true, adPlaying:bool } | { ok:false }  (cannot confirm)
  function doFreshAdCheck() {
    adChecks.push(true);
    if (freshAdCheck === "ad")          return { ok: true, adPlaying: true };
    if (freshAdCheck === "no_ad")       return { ok: true, adPlaying: false };
    return { ok: false }; // "unreachable" / malformed → cannot confirm
  }

  function navigateGuarded(id, url, isVideo, start) {
    let dest = url;
    if (isVideo && start > 0) dest += "&t=" + Math.round(start);
    if (existingTab) {
      const check = doFreshAdCheck();
      if (!check.ok)       { ackErr(id, "busy_ad_unconfirmed"); return; }
      if (check.adPlaying) { ackErr(id, "busy_ad"); return; }
      navsUpdate.push({ url: dest });
      ackOk(id);
      return;
    }
    // No existing tab → safe to open a new one (no ad context can exist).
    navsCreate.push({ url: dest });
    ackOk(id);
  }

  async function routeCommand(frame) {
    const id     = frame.id;
    const action = String(frame.action || "");

    if (String(frame.target || "") !== TARGET_ID) { ackErr(id, "wrong_target"); return; }
    if (!COMPANION_ACTIONS.includes(action))       { ackErr(id, "action_not_allowed"); return; }
    // Full ad passivity: every action blocked while an ad is playing.
    if (adPlaying && AD_BLOCKED_ACTIONS.has(action)) { ackErr(id, "busy_ad"); return; }

    if (action === "navigate_video") {
      let vid;
      try   { vid = validateVideoId(frame.video_id); }
      catch (_e) { ackErr(id, "invalid_video_id"); return; }
      navigateGuarded(id, canonicalWatchUrl(vid), true, frame.start_seconds || 0);
      return;
    }
    if (action === "navigate_playlist") {
      let pid;
      try   { pid = validatePlaylistId(frame.playlist_id); }
      catch (_e) { ackErr(id, "invalid_playlist_id"); return; }
      navigateGuarded(id, canonicalPlaylistUrl(pid), false, 0);
      return;
    }
    // All others → content script.
    contentCmds.push({ action, params: extractParams(action, frame) });
    ackOk(id);
  }

  // Back-compat accessor: total navigations (update + create).
  const navs = { get length() { return navsUpdate.length + navsCreate.length; } };

  return { routeCommand, acks, navs, navsUpdate, navsCreate, contentCmds, adChecks };
}

// Browser-level content simulation of applyCommand() — models the HTML5 player,
// the ad gate, preDuck lifecycle, and DOM-click actions (next/previous).
function makeContentPlayer(init = {}) {
  const player = {
    volume: init.volume != null ? init.volume : 0.85, // 0..1
    muted:  !!init.muted,
    currentTime: init.currentTime != null ? init.currentTime : 30,
    duration: 212,
    paused: init.paused != null ? init.paused : false,
    ended: false,
    clicks: [],          // recorded DOM clicks (next/previous)
    playCalls: 0,
    pauseCalls: 0,
  };
  let preDuck  = null;
  let ad       = !!init.adPlaying;
  const AD_BLOCKED_LOCAL = new Set(COMPANION_ACTIONS); // full passivity

  function snapshot() {
    return { volume: player.volume, muted: player.muted, currentTime: player.currentTime,
             paused: player.paused, clicks: player.clicks.slice(),
             playCalls: player.playCalls, pauseCalls: player.pauseCalls,
             preDuckPending: preDuck !== null };
  }
  function setAd(v) { ad = !!v; }
  function clamp01(n) { return Math.max(0, Math.min(1, Number(n) || 0)); }

  function applyCommand(action, params = {}) {
    if (!COMPANION_ACTIONS.includes(action)) return { accepted: false, error: "action_not_allowed" };

    // Full ad passivity — mutate NOTHING (incl. preDuck) during an ad.
    if (ad && AD_BLOCKED_LOCAL.has(action)) return { accepted: false, error: "busy_ad" };

    // Explicit non-voice command drops pending duck WITHOUT restoring.
    if (!VOICE_FOCUS_ACTIONS.has(action)) preDuck = null;

    switch (action) {
      case "navigate_video":
      case "navigate_playlist":
        return { accepted: false, error: "navigation_only" };
      case "play":     player.paused = false; player.playCalls++; return { accepted: true };
      case "pause":    player.paused = true;  player.pauseCalls++; return { accepted: true };
      case "stop":     player.paused = true;  player.currentTime = 0; return { accepted: true };
      case "next":     player.clicks.push("next");     return { accepted: true };
      case "previous": player.clicks.push("previous"); return { accepted: true };
      case "restart":  player.currentTime = 0; player.paused = false; return { accepted: true };
      case "seek": {
        let target = null;
        if (typeof params.target_seconds === "number" && params.target_seconds >= 0) target = params.target_seconds;
        else if (typeof params.offset_seconds === "number") target = player.currentTime + params.offset_seconds;
        if (target === null) return { accepted: false, error: "no_seek_target" };
        player.currentTime = Math.max(0, Math.min(player.duration, target));
        return { accepted: true };
      }
      case "set_volume":
        if (typeof params.volume !== "number") return { accepted: false, error: "no_volume" };
        player.volume = clamp01(params.volume / 100);
        if (player.volume > 0) player.muted = false;
        return { accepted: true };
      case "adjust_volume":
        if (typeof params.delta !== "number") return { accepted: false, error: "no_delta" };
        player.volume = clamp01(player.volume + params.delta / 100);
        if (player.volume > 0) player.muted = false;
        return { accepted: true };
      case "mute":   player.muted = true;  return { accepted: true };
      case "unmute": player.muted = false; return { accepted: true };
      case "duck": {
        if (preDuck === null) preDuck = { volume: player.volume, muted: player.muted };
        const level = typeof params.volume === "number" ? params.volume : 20;
        player.volume = clamp01(level / 100);
        return { accepted: true };
      }
      case "restore": {
        if (preDuck !== null) {
          player.volume = clamp01(preDuck.volume);
          player.muted  = preDuck.muted;
          preDuck = null;
        }
        return { accepted: true };
      }
      default: return { accepted: false, error: "action_not_allowed" };
    }
  }

  return { applyCommand, snapshot, setAd };
}

// State frame builder (mirrors content.js buildState).
function buildContentState({ adPlaying = false, videoId = "", playlistId = "", hasVideo = true, status = "playing", volume = 85, muted = false }) {
  const wireStatus = VALID_WIRE_STATUSES.has(status) ? status : "stopped";
  const state = {
    status:      wireStatus,  // always a valid wire status
    ad_playing:  adPlaying,   // always present
    video_id:    videoId,
    playlist_id: playlistId,  // always present (empty string when not in a playlist)
  };
  if (hasVideo) {
    state.position_seconds = 42.0;
    state.duration_seconds = 212.0;
    state.volume = volume;
    state.muted  = muted;
  }
  return state;
}

// State frame validator (mirrors server-side fencing in companion_bridge.py).
function wouldServerAccept(frame, currentSession) {
  if (String(frame.target || "") !== TARGET_ID) return false;
  let s;
  try { s = parseInt(frame.session, 10); } catch (_e) { return false; }
  if (isNaN(s) || s !== currentSession) return false;
  if (!VALID_WIRE_STATUSES.has(String(frame.status || ""))) return false;
  return true;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

test("pair request is UI-routed without MessageSender metadata", () => {
  assert.equal(isUiRequest({ type: "pair" }), true);
});

test("content state is not UI-routed", () => {
  assert.equal(isUiRequest({ type: "content_state" }), false);
});

// ── Handshake ────────────────────────────────────────────────────────────────
test("welcome frame has protocol=1", () => {
  const f = { type: "welcome", protocol: PROTOCOL_VERSION };
  assert.equal(f.protocol, 1);
});

test("hello(token) path: paired frame carries secret, auth_ok follows", () => {
  const secret = crypto.randomBytes(24).toString("base64url");
  const sent   = [{ type: "paired", secret }, { type: "auth_ok", target: TARGET_ID, session: 0 }];
  const paired = sent.find(f => f.type === "paired");
  assert.ok(paired && paired.secret && paired.secret.length >= 8);
  const authOk = sent.find(f => f.type === "auth_ok");
  assert.ok(authOk);
  assert.equal(authOk.target, TARGET_ID);
  assert.equal(typeof authOk.session, "number");
});

test("hello(secret) path: only auth_ok, no paired frame", () => {
  const sent = [{ type: "auth_ok", target: TARGET_ID, session: 5 }];
  assert.equal(sent.filter(f => f.type === "paired").length, 0);
  assert.equal(sent.find(f => f.type === "auth_ok").session, 5);
});

test("auth_error on secret rejection should trigger clear-secret", () => {
  const frame = { type: "auth_error", reason: "invalid credentials" };
  // Not containing 'token' or 'pairing' → it's a secret rejection.
  const isSecretReject = !frame.reason.includes("token") && !frame.reason.includes("pairing");
  assert.ok(isSecretReject, "should detect as secret rejection");
});

test("revoked frame should clear secret and suppress reconnect", () => {
  const frame = { type: "revoked", reason: "rotated" };
  assert.equal(frame.type, "revoked");
  // reconnectAttempt is set to 999 in background.js.
});

// ── Command routing: navigate_video ──────────────────────────────────────────
test("navigate_video with valid 11-char id → canonical watch URL (existing tab, no ad)", async () => {
  const r = makeRouter(); // existing tab, fresh ad-check says no_ad
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ", start_seconds: 0 });
  assert.ok(r.acks[0].ok);
  assert.equal(r.adChecks.length, 1, "must perform a synchronous fresh ad check before navigating an existing tab");
  assert.equal(r.navsUpdate[0].url, "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  assert.equal(r.navsCreate.length, 0);
});

test("navigate_video respects start_seconds via ?t=", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ", start_seconds: 42 });
  assert.ok(r.navsUpdate[0].url.endsWith("&t=42"));
});

test("navigate_video with invalid id → ack error", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "not-an-id" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "invalid_video_id");
  assert.equal(r.navs.length, 0);
});

test("navigate_video missing video_id → ack error", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "invalid_video_id");
});

// ── Command routing: navigate_playlist ───────────────────────────────────────
test("navigate_playlist with valid id → canonical playlist URL", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_playlist", playlist_id: "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l" });
  assert.ok(r.acks[0].ok);
  assert.equal(r.adChecks.length, 1, "playlist navigation also runs a fresh ad check on an existing tab");
  assert.ok(r.navsUpdate[0].url.startsWith("https://www.youtube.com/playlist?list="));
  assert.ok(r.navsUpdate[0].url.includes("PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l"));
});

test("navigate_playlist with invalid id → ack error", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_playlist", playlist_id: "bad" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "invalid_playlist_id");
  assert.equal(r.navs.length, 0);
});

test("navigate_playlist with LL/WL/HL (private) → ack error", async () => {
  for (const prefix of ["LL", "WL", "HL"]) {
    const r = makeRouter();
    await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_playlist",
      playlist_id: prefix + "xxxxxxxxxxxxxxxxxxxx" }); // won't match regex (LL not in prefix set)
    assert.ok(!r.acks[0].ok);
    assert.equal(r.acks[0].error, "invalid_playlist_id");
  }
});

// ── play (resume), next, previous, restart ───────────────────────────────────
test("play (resume) routes to content with no params", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "play" });
  assert.ok(r.acks[0].ok);
  assert.deepEqual(r.contentCmds[0], { action: "play", params: {} });
});

test("next and previous route to content with no params", async () => {
  for (const action of ["next", "previous"]) {
    const r = makeRouter();
    await r.routeCommand({ id: 1, target: TARGET_ID, action });
    assert.ok(r.acks[0].ok);
    assert.deepEqual(r.contentCmds[0], { action, params: {} });
  }
});

test("restart routes to content with no params", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "restart" });
  assert.ok(r.acks[0].ok);
  assert.deepEqual(r.contentCmds[0], { action: "restart", params: {} });
});

// ── seek / volumes ────────────────────────────────────────────────────────────
test("seek passes offset_seconds + target_seconds", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "seek", offset_seconds: -30, target_seconds: 90.5 });
  const p = r.contentCmds[0].params;
  assert.equal(p.offset_seconds, -30);
  assert.equal(p.target_seconds, 90.5);
});

test("set_volume clamps to 0..100", async () => {
  for (const [raw, expected] of [[150, 100], [-5, 0], [75, 75]]) {
    const r = makeRouter();
    await r.routeCommand({ id: 1, target: TARGET_ID, action: "set_volume", volume: raw });
    assert.equal(r.contentCmds[0].params.volume, expected);
  }
});

test("adjust_volume passes delta clamped to -100..100", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "adjust_volume", delta: -200 });
  assert.equal(r.contentCmds[0].params.delta, -100);
  const r2 = makeRouter();
  await r2.routeCommand({ id: 1, target: TARGET_ID, action: "adjust_volume", delta: 10 });
  assert.equal(r2.contentCmds[0].params.delta, 10);
});

// ── duck / restore ────────────────────────────────────────────────────────────
test("duck passes volume field (not level) with default 20", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "duck" });
  assert.ok(r.acks[0].ok);
  // duck payload field is "volume" per COMPANION_PROTOCOL.md
  assert.equal(r.contentCmds[0].params.volume, 20, "default duck volume is 20");
  assert.equal(r.contentCmds[0].params.level, undefined, "no 'level' field on duck");
});

test("duck with explicit volume passes it through", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "duck", volume: 30 });
  assert.equal(r.contentCmds[0].params.volume, 30);
});

test("restore routes to content with no params", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "restore" });
  assert.ok(r.acks[0].ok);
  assert.deepEqual(r.contentCmds[0], { action: "restore", params: {} });
});

// ── Allowlist / target guard ──────────────────────────────────────────────────
test("unknown action → action_not_allowed", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "delete_everything" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "action_not_allowed");
  assert.equal(r.navs.length, 0);
  assert.equal(r.contentCmds.length, 0);
});

test("wrong target → wrong_target", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: "other_target", action: "pause" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "wrong_target");
});

// Old action names must NOT be accepted.
test("old action name 'play_playlist' is rejected as action_not_allowed", async () => {
  const r = makeRouter();
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "play_playlist", playlist_id: "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l" });
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "action_not_allowed");
});

test("old action name 'play' with video_id arg is now navigate_video", () => {
  // Confirm the allowlist does NOT conflate old 'play+video_id' with 'navigate_video'.
  // 'play' is now a resume (no args); 'navigate_video' is the navigation action.
  assert.ok(COMPANION_ACTIONS.includes("navigate_video"));
  assert.ok(COMPANION_ACTIONS.includes("play"));
  // 'play' must be separate from 'navigate_video' in the allowlist.
  assert.notEqual(COMPANION_ACTIONS.indexOf("navigate_video"), COMPANION_ACTIONS.indexOf("play"));
});

// ── Ad gate — FULL PASSIVITY (background) ───────────────────────────────────────
test("EVERY one of the 15 actions is rejected with busy_ad during ad (background)", async () => {
  // The full action set — including next/previous, duck, restore.
  for (const action of COMPANION_ACTIONS) {
    const r = makeRouter({ adPlaying: true });
    await r.routeCommand({
      id: 1, target: TARGET_ID, action,
      video_id: "dQw4w9WgXcQ",
      playlist_id: "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l",
      volume: 50, delta: 10,
      offset_seconds: 0, target_seconds: 0,
    });
    assert.ok(!r.acks[0].ok, action + " must be blocked during ad");
    assert.equal(r.acks[0].error, "busy_ad", action + " must ack busy_ad");
    assert.equal(r.navs.length, 0, action + " must not navigate during ad");
    assert.equal(r.contentCmds.length, 0, action + " must not reach the content script during ad");
    assert.equal(r.adChecks.length, 0, action + " must not even run a pre-nav ad check (already gated)");
  }
});

test("AD_BLOCKED_ACTIONS is EXACTLY the full COMPANION_ACTIONS set", () => {
  assert.equal(AD_BLOCKED_ACTIONS.size, COMPANION_ACTIONS.length);
  for (const a of COMPANION_ACTIONS) assert.ok(AD_BLOCKED_ACTIONS.has(a), a + " must be ad-blocked");
});

test("duck IS blocked with busy_ad during ad (full passivity)", async () => {
  const r = makeRouter({ adPlaying: true });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "duck", volume: 20 });
  assert.ok(!r.acks[0].ok, "duck must be blocked during ad");
  assert.equal(r.acks[0].error, "busy_ad");
});

test("restore IS blocked with busy_ad during ad (full passivity)", async () => {
  const r = makeRouter({ adPlaying: true });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "restore" });
  assert.ok(!r.acks[0].ok, "restore must be blocked during ad");
  assert.equal(r.acks[0].error, "busy_ad");
});

// ── Navigation ad-safety (synchronous fresh ad check) ───────────────────────────
test("navigate_video to existing tab: fresh ad-check says AD → busy_ad, no navigation", async () => {
  const r = makeRouter({ existingTab: true, freshAdCheck: "ad" });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ" });
  assert.equal(r.adChecks.length, 1, "must run the pre-nav ad check");
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "busy_ad");
  assert.equal(r.navsUpdate.length, 0, "must NOT navigate over an ad");
  assert.equal(r.navsCreate.length, 0);
});

test("navigate_playlist to existing tab: fresh ad-check says AD → busy_ad", async () => {
  const r = makeRouter({ existingTab: true, freshAdCheck: "ad" });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_playlist", playlist_id: "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l" });
  assert.equal(r.acks[0].error, "busy_ad");
  assert.equal(r.navsUpdate.length, 0);
});

test("navigate to existing tab: content CANNOT confirm → busy_ad_unconfirmed, no navigation", async () => {
  const r = makeRouter({ existingTab: true, freshAdCheck: "unreachable" });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ" });
  assert.equal(r.adChecks.length, 1);
  assert.ok(!r.acks[0].ok);
  assert.equal(r.acks[0].error, "busy_ad_unconfirmed", "must refuse when ad state cannot be confirmed");
  assert.equal(r.navsUpdate.length, 0);
  assert.equal(r.navsCreate.length, 0);
});

test("navigate with NO existing target tab: open a NEW tab, no ad check needed", async () => {
  const r = makeRouter({ existingTab: false });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ" });
  assert.ok(r.acks[0].ok);
  assert.equal(r.adChecks.length, 0, "no existing tab → no ad context → no ad check");
  assert.equal(r.navsCreate.length, 1, "must create a new tab");
  assert.equal(r.navsUpdate.length, 0);
});

test("navigate to existing tab, no ad: navigates via tabs.update after passing ad check", async () => {
  const r = makeRouter({ existingTab: true, freshAdCheck: "no_ad" });
  await r.routeCommand({ id: 1, target: TARGET_ID, action: "navigate_video", video_id: "dQw4w9WgXcQ" });
  assert.ok(r.acks[0].ok);
  assert.equal(r.adChecks.length, 1);
  assert.equal(r.navsUpdate.length, 1);
  assert.equal(r.navsCreate.length, 0);
});

// ── Browser-level content simulation: every action mutates nothing during ad ────
test("content: EVERY action during an ad mutates NOTHING and acks busy_ad", () => {
  for (const action of COMPANION_ACTIONS) {
    const c = makeContentPlayer({ adPlaying: true, volume: 0.85, muted: false, currentTime: 30, paused: false });
    const before = c.snapshot();
    const res = c.applyCommand(action, { volume: 50, delta: 10, offset_seconds: -10, target_seconds: 5 });
    assert.ok(!res.accepted, action + " must be rejected during ad");
    assert.equal(res.error, "busy_ad", action + " must ack busy_ad");
    const after = c.snapshot();
    // No mutation whatsoever — including preDuck, clicks, media, and volume.
    assert.deepEqual(after, before, action + " must not mutate any player state during ad");
  }
});

// ── Browser-level content simulation: normal (no ad) behavior per action ────────
test("content: play/pause/stop/restart perform the expected media mutation (no ad)", () => {
  let c = makeContentPlayer({ paused: true });
  assert.ok(c.applyCommand("play").accepted);
  assert.equal(c.snapshot().paused, false);

  c = makeContentPlayer({ paused: false });
  assert.ok(c.applyCommand("pause").accepted);
  assert.equal(c.snapshot().paused, true);

  c = makeContentPlayer({ currentTime: 90, paused: false });
  assert.ok(c.applyCommand("stop").accepted);
  assert.equal(c.snapshot().currentTime, 0);
  assert.equal(c.snapshot().paused, true);

  c = makeContentPlayer({ currentTime: 90, paused: true });
  assert.ok(c.applyCommand("restart").accepted);
  assert.equal(c.snapshot().currentTime, 0);
  assert.equal(c.snapshot().paused, false);
});

test("content: next/previous click the native controls (no ad)", () => {
  let c = makeContentPlayer();
  assert.ok(c.applyCommand("next").accepted);
  assert.deepEqual(c.snapshot().clicks, ["next"]);
  c = makeContentPlayer();
  assert.ok(c.applyCommand("previous").accepted);
  assert.deepEqual(c.snapshot().clicks, ["previous"]);
});

test("content: seek uses target_seconds then offset_seconds (no ad)", () => {
  let c = makeContentPlayer({ currentTime: 30 });
  c.applyCommand("seek", { target_seconds: 100, offset_seconds: -5 });
  assert.equal(c.snapshot().currentTime, 100); // target wins
  c = makeContentPlayer({ currentTime: 30 });
  c.applyCommand("seek", { offset_seconds: -10 });
  assert.equal(c.snapshot().currentTime, 20);  // offset used when no target
});

test("content: set_volume / adjust_volume / mute / unmute (no ad)", () => {
  let c = makeContentPlayer({ volume: 0.5, muted: true });
  c.applyCommand("set_volume", { volume: 80 });
  assert.equal(Math.round(c.snapshot().volume * 100), 80);
  assert.equal(c.snapshot().muted, false); // volume>0 unmutes

  c = makeContentPlayer({ volume: 0.5 });
  c.applyCommand("adjust_volume", { delta: 20 });
  assert.equal(Math.round(c.snapshot().volume * 100), 70);

  c = makeContentPlayer({ muted: false });
  c.applyCommand("mute");
  assert.equal(c.snapshot().muted, true);
  c.applyCommand("unmute");
  assert.equal(c.snapshot().muted, false);
});

// ── preDuck lifecycle (browser-level content simulation) ────────────────────────
test("content: duck→restore returns to pre-duck volume/mute (voice-focus lifecycle)", () => {
  const c = makeContentPlayer({ volume: 0.9, muted: false });
  c.applyCommand("duck", { volume: 20 });
  assert.equal(Math.round(c.snapshot().volume * 100), 20);
  assert.ok(c.snapshot().preDuckPending);
  c.applyCommand("restore");
  assert.equal(Math.round(c.snapshot().volume * 100), 90, "restore returns to pre-duck volume");
  assert.ok(!c.snapshot().preDuckPending);
});

test("content: explicit set_volume between duck and restore DROPS preDuck without restore", () => {
  const c = makeContentPlayer({ volume: 0.9, muted: false });
  c.applyCommand("duck", { volume: 20 });          // duck to 20%
  c.applyCommand("set_volume", { volume: 55 });    // explicit non-voice command
  assert.ok(!c.snapshot().preDuckPending, "explicit command must drop preDuck");
  assert.equal(Math.round(c.snapshot().volume * 100), 55);
  c.applyCommand("restore");                        // must be a no-op now
  assert.equal(Math.round(c.snapshot().volume * 100), 55, "restore must NOT overwrite explicit volume");
});

test("content: explicit mute between duck and restore is preserved (restore no-ops)", () => {
  const c = makeContentPlayer({ volume: 0.9, muted: false });
  c.applyCommand("duck", { volume: 20 });
  c.applyCommand("mute");                           // explicit mute
  assert.ok(!c.snapshot().preDuckPending);
  assert.equal(c.snapshot().muted, true);
  c.applyCommand("restore");
  assert.equal(c.snapshot().muted, true, "restore must NOT un-mute an explicit mute");
});

test("content: explicit stop/navigation between duck and restore drops preDuck", () => {
  for (const explicit of ["stop", "pause", "next", "previous", "seek", "adjust_volume"]) {
    const c = makeContentPlayer({ volume: 0.9 });
    c.applyCommand("duck", { volume: 20 });
    c.applyCommand(explicit, { offset_seconds: -3, delta: 5 });
    assert.ok(!c.snapshot().preDuckPending, explicit + " must drop preDuck");
    const volAfterExplicit = c.snapshot().volume;
    c.applyCommand("restore");
    assert.equal(c.snapshot().volume, volAfterExplicit, "restore after " + explicit + " must not change volume");
  }
});

test("content: restore with no pending duck mutates nothing", () => {
  const c = makeContentPlayer({ volume: 0.9, muted: false });
  const before = c.snapshot();
  const res = c.applyCommand("restore");
  assert.ok(res.accepted);
  assert.equal(c.snapshot().volume, before.volume);
  assert.equal(c.snapshot().muted, before.muted);
});

test("content: repeated duck does not overwrite the original pre-duck snapshot", () => {
  const c = makeContentPlayer({ volume: 0.9, muted: false });
  c.applyCommand("duck", { volume: 30 }); // saves 0.9
  c.applyCommand("duck", { volume: 10 }); // must NOT re-save 0.3
  c.applyCommand("restore");
  assert.equal(Math.round(c.snapshot().volume * 100), 90, "restore returns to the ORIGINAL pre-duck volume");
});

// ── State frame ───────────────────────────────────────────────────────────────
test("state frame always has valid wire status — never 'ad_playing' as status", () => {
  // Even during an ad, the status field must be a valid wire status.
  const during = buildContentState({ adPlaying: true, status: "playing" });
  assert.ok(VALID_WIRE_STATUSES.has(during.status), "status must be a valid wire status during ad");
  assert.notEqual(during.status, "ad_playing", "status must not be 'ad_playing'");
  assert.equal(during.ad_playing, true, "ad_playing boolean must be true during ad");
});

test("state frame includes ad_playing boolean even when false", () => {
  const state = buildContentState({ adPlaying: false });
  assert.equal(typeof state.ad_playing, "boolean");
  assert.equal(state.ad_playing, false);
});

test("state frame includes playlist_id (empty string outside playlists)", () => {
  const inPlaylist = buildContentState({ playlistId: "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l" });
  assert.equal(inPlaylist.playlist_id, "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l");
  const noPlaylist = buildContentState({ playlistId: "" });
  assert.equal(noPlaylist.playlist_id, "");
});

test("state frame fencing: server drops wrong target or stale session", () => {
  const session = 5;
  assert.ok( wouldServerAccept({ target: TARGET_ID, session: 5, status: "playing" }, session));
  assert.ok(!wouldServerAccept({ target: TARGET_ID, session: 4, status: "playing" }, session));
  assert.ok(!wouldServerAccept({ target: "other",   session: 5, status: "playing" }, session));
  assert.ok(!wouldServerAccept({ target: TARGET_ID,              status: "playing" }, session)); // missing session
  assert.ok(!wouldServerAccept({ target: TARGET_ID, session: 5, status: "ad_playing" }, session)); // bad status
  assert.ok(!wouldServerAccept({ target: TARGET_ID, session: 5                       }, session)); // missing status
});

test("state frame with ad_playing=true still has valid wire status", () => {
  // When ad is playing, status is still one of the valid set (e.g. "playing"
  // if the underlying video element is playing the ad), not a custom string.
  const state = buildContentState({ adPlaying: true, status: "playing" });
  assert.ok(VALID_WIRE_STATUSES.has(state.status));
  assert.ok(!VALID_WIRE_STATUSES.has("ad_playing")); // "ad_playing" is not a wire status
});

test("playlist_id: strictly validated — private and malformed IDs are empty", () => {
  // These mirror content.js currentPlaylistId() logic.
  function extractPlaylistId(queryString) {
    try {
      const list = new URLSearchParams(queryString).get("list") || "";
      if (!PLAYLIST_ID_RE.test(list)) return "";
      if (PRIVATE_PL.includes(list.slice(0, 2))) return "";
      return list;
    } catch (_e) { return ""; }
  }
  assert.equal(extractPlaylistId("v=x&list=PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l"), "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l");
  assert.equal(extractPlaylistId("v=x"),                                         "");  // no list
  assert.equal(extractPlaylistId("v=x&list=LLxxxxxxxxxxxxxxxx"),                 "");  // LL not in prefix set
  assert.equal(extractPlaylistId("v=x&list=bad"),                                "");  // malformed
  assert.equal(extractPlaylistId("v=x&list=WLxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"),  ""); // WL not in prefix set
  assert.equal(extractPlaylistId("v=x&list=PLxxxxxxxxxxxxxxxx"),                  "PLxxxxxxxxxxxxxxxx"); // valid PL
});

// ── URL builders ──────────────────────────────────────────────────────────────
test("canonicalWatchUrl accepts only 11-char video ids", () => {
  assert.equal(canonicalWatchUrl("dQw4w9WgXcQ"), "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  assert.throws(() => canonicalWatchUrl("short"),           /Invalid video id/);
  assert.throws(() => canonicalWatchUrl("toolongggggggg"),  /Invalid video id/);
  assert.throws(() => canonicalWatchUrl(""),                /Invalid video id/);
});

test("canonicalPlaylistUrl rejects private and malformed ids", () => {
  const valid = "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l";
  assert.ok(canonicalPlaylistUrl(valid).includes("playlist?list=" + valid));
  // LL/WL/HL prefixes are not in the PLAYLIST_ID_RE prefix set — rejected as invalid.
  assert.throws(() => canonicalPlaylistUrl("LLxxxxxxxxxxxxxxxx"), /Invalid|Private/);
  assert.throws(() => canonicalPlaylistUrl("WLxxxxxxxxxxxxxxxx"), /Invalid|Private/);
  assert.throws(() => canonicalPlaylistUrl("HLxxxxxxxxxxxxxxxx"), /Invalid|Private/);
  assert.throws(() => canonicalPlaylistUrl("bad"),                /Invalid/);
  assert.throws(() => canonicalPlaylistUrl(""),                   /Invalid/);
});

// ── Bridge URL validation ─────────────────────────────────────────────────────
test("validateBridgeBase: only accepts loopback URLs, rejects external", () => {
  assert.equal(validateBridgeBase("ws://127.0.0.1:8756"),   "ws://127.0.0.1:8756");
  assert.equal(validateBridgeBase("wss://localhost:8756"),   "wss://localhost:8756");
  assert.equal(validateBridgeBase("http://127.0.0.1:8756"), "http://127.0.0.1:8756");
  assert.throws(() => validateBridgeBase("ws://192.168.1.1:8756"), /loopback/);
  assert.throws(() => validateBridgeBase("ws://evil.example/"),    /loopback/);
  assert.throws(() => validateBridgeBase("ftp://127.0.0.1/"),      /protocol/);
  assert.throws(() => validateBridgeBase(""),                       /empty/);
});

test("ws companion URL is formed as base + /ws/companion", () => {
  assert.equal("ws://127.0.0.1:8756" + "/ws/companion", "ws://127.0.0.1:8756/ws/companion");
});

// ── Ping / pong ───────────────────────────────────────────────────────────────
test("pong frame echoes the ping id", () => {
  const ping = { type: "ping",  id: 99 };
  const pong = { type: "pong",  id: ping.id };
  assert.equal(pong.id, 99);
});

// ── Protocol version ─────────────────────────────────────────────────────────
test("COMPANION_ACTIONS contains exactly the 15 actions from COMPANION_PROTOCOL.md", () => {
  const expected = new Set([
    "navigate_video", "navigate_playlist",
    "play", "pause", "stop",
    "next", "previous",
    "seek", "restart",
    "set_volume", "adjust_volume",
    "mute", "unmute",
    "duck", "restore",
  ]);
  assert.equal(COMPANION_ACTIONS.length, 15, "should have exactly 15 actions");
  for (const a of expected) assert.ok(COMPANION_ACTIONS.includes(a), "missing action: " + a);
  for (const a of COMPANION_ACTIONS) assert.ok(expected.has(a), "unexpected action: " + a);
  // Old names must NOT be present.
  assert.ok(!COMPANION_ACTIONS.includes("play_playlist"), "play_playlist must not be in allowlist");
});

// ---------------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------------
(async () => {
  console.log("Contract tests: Chat YouTube Companion ↔ CompanionBridge v1");
  console.log("Authority: apps/tool_service/COMPANION_PROTOCOL.md");
  await runAll();
  console.log("");
  if (failed) {
    console.log(failed + " test(s) FAILED, " + passed + " passed.");
    process.exit(1);
  } else {
    console.log("All " + passed + " contract tests passed.");
  }
})();
