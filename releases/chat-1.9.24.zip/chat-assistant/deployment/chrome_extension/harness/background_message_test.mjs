#!/usr/bin/env node
// Executes the real background.js module with a minimal Chrome MV3 mock.
// This specifically guards the options-page Pair now path that previously
// returned no response when Chrome's MessageSender metadata varied.

import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";

let messageListener = null;
const sockets = [];
const storageData = {};
let deferSecretWrite = false;
let releaseSecretWrite = null;
let deferConfigRead = false;
let releaseConfigRead = null;
let alarmListener = null;

class StubWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;

  constructor(url) {
    this.url = url;
    this.readyState = StubWebSocket.CONNECTING;
    this.listeners = new Map();
    this.sent = [];
    sockets.push(this);
  }

  addEventListener(type, callback) {
    this.listeners.set(type, callback);
  }

  close() {
    this.readyState = 3;
  }

  send(data) { this.sent.push(data); }
}

globalThis.WebSocket = StubWebSocket;
globalThis.chrome = {
  runtime: {
    id: "test-extension-id",
    getURL: (path = "") => "chrome-extension://test-extension-id/" + path,
    onMessage: {
      addListener(callback) {
        messageListener = callback;
      },
    },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} },
    sendMessage() {},
  },
  storage: {
    local: {
      async get(keys) {
        if (deferConfigRead && (keys || []).includes("bridge_base")) {
          await new Promise((resolve) => { releaseConfigRead = resolve; });
        }
        const selected = {};
        for (const key of keys || []) {
          if (Object.hasOwn(storageData, key)) selected[key] = storageData[key];
        }
        return selected;
      },
      async set(values) {
        if (deferSecretWrite && Object.hasOwn(values, "bridge_secret")) {
          await new Promise((resolve) => { releaseSecretWrite = resolve; });
        }
        Object.assign(storageData, values);
      },
      async remove(keys) {
        for (const key of keys || []) delete storageData[key];
      },
    },
  },
  alarms: {
    create() {},
    clear() {},
    onAlarm: { addListener(callback) { alarmListener = callback; } },
  },
  tabs: {
    async query(q) { return tabsQueryImpl(q); },
    async update() {},
    async create() {},
    async sendMessage(id, msg) { return tabsSendMessageImpl(id, msg); },
  },
};

// Mutable tab behaviors so individual scenarios below can simulate a missing
// YouTube tab, an unreachable content script, or a throwing tabs API.
let tabsQueryImpl = async () => [];
let tabsSendMessageImpl = async () => ({});

const backgroundUrl = new URL("../background.js", import.meta.url);
await import(pathToFileURL(backgroundUrl.pathname).href + "?message-test=1");

assert.equal(typeof messageListener, "function", "background listener was not registered");

let pairResponse;
const pairReturn = messageListener({
  type: "pair",
  token: "test-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {
  // Deliberately reproduce a tabbed options page while omitting optional
  // sender.id/url/origin metadata. UI routing must not depend on these fields.
  tab: { id: 42 },
}, (response) => {
  pairResponse = response;
});

assert.deepEqual(pairResponse, { ok: true }, "Pair now did not receive an immediate acceptance");
assert.equal(pairReturn, false, "synchronously answered Pair now must not hold the message port open");

// Reproduce the real pairing race: the bridge sends paired and auth_ok
// back-to-back while chrome.storage.local.set is still persisting the secret.
// The older paired handler must not overwrite the final ready status.
const pairingSocket = sockets.at(-1);
assert.ok(pairingSocket, "Pair now did not create a WebSocket");
pairingSocket.readyState = StubWebSocket.OPEN;
pairingSocket.listeners.get("open")();
deferSecretWrite = true;
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "bridge-secret-1234567890" }),
});
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 7 }),
});
await new Promise((resolve) => setImmediate(resolve));
assert.equal(typeof releaseSecretWrite, "function", "secret write was not deferred");
releaseSecretWrite();
await new Promise((resolve) => setImmediate(resolve));

const statusResponse = await new Promise((resolve) => {
  const keepPortOpen = messageListener({ type: "get_status" }, {}, resolve);
  assert.equal(keepPortOpen, true);
});
assert.equal(statusResponse.status.authenticated, true);
assert.equal(statusResponse.status.detail, "ready",
  "paired storage completion regressed ready status to awaiting auth_ok");

let contentResponse;
const contentReturn = messageListener({
  type: "content_hello",
}, {
  tab: { id: 7 },
  origin: "https://www.youtube.com",
  url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
}, (response) => {
  contentResponse = response;
});

assert.deepEqual(contentResponse, { ok: true, connected: true });
assert.equal(contentReturn, true);

console.log("Real background message test passed: Pair routing and auth status race are safe.");
// ---------------------------------------------------------------------------
// Command routing through the REAL background.js: every command id must get
// exactly ONE ack carrying a real cause — even when the browser API throws.
// ---------------------------------------------------------------------------
const flush = async (rounds = 8) => {
  for (let i = 0; i < rounds; i++) await new Promise((r) => setImmediate(r));
};
const sendCommand = (frame) =>
  pairingSocket.listeners.get("message")({ data: JSON.stringify(frame) });
const acksFor = (id) =>
  pairingSocket.sent
    .map((raw) => JSON.parse(raw))
    .filter((f) => f.type === "ack" && f.id === id);

// No YouTube tab anywhere → exactly one no_youtube_tab NACK.
sendCommand({ type: "command", id: 101, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(101), [{ type: "ack", id: 101, ok: false, error: "no_youtube_tab" }]);

// Content script unreachable → exactly one content_unreachable NACK.
tabsQueryImpl = async () => [{ id: 5, active: true }];
tabsSendMessageImpl = async () => { throw new Error("Could not establish connection"); };
sendCommand({ type: "command", id: 102, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(102), [{ type: "ack", id: 102, ok: false, error: "content_unreachable" }]);

// Unexpected exception inside routing → exactly one internal_error NACK.
tabsQueryImpl = async () => { throw new Error("tabs API exploded"); };
sendCommand({ type: "command", id: 103, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(103), [{ type: "ack", id: 103, ok: false, error: "internal_error" }]);

// Healthy path → exactly one OK ack (and no error field on success).
tabsQueryImpl = async () => [{ id: 5, active: true }];
tabsSendMessageImpl = async () => ({ accepted: true });
sendCommand({ type: "command", id: 104, session: 7, target: "browser_companion", action: "pause" });
await flush();
assert.deepEqual(acksFor(104), [{ type: "ack", id: 104, ok: true }]);

console.log("Command ack-once + failure-cause tests passed.");

// Re-pairing replaces the active socket. Delayed frames and close events from
// the old socket must not overwrite the newer authenticated ready state.
let secondPairResponse;
messageListener({
  type: "pair",
  token: "replacement-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {}, (response) => { secondPairResponse = response; });
assert.deepEqual(secondPairResponse, { ok: true });
const replacementSocket = sockets.at(-1);
assert.notEqual(replacementSocket, pairingSocket);
replacementSocket.readyState = StubWebSocket.OPEN;
replacementSocket.listeners.get("open")();
deferSecretWrite = false;
replacementSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "replacement-secret-1234567890" }),
});
replacementSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 8 }),
});
await flush();

// These events belong to the displaced socket and must be complete no-ops.
pairingSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "stale-secret-1234567890" }),
});
pairingSocket.listeners.get("close")();
await flush();

const replacementStatus = await new Promise((resolve) => {
  messageListener({ type: "get_status" }, {}, resolve);
});
assert.equal(replacementStatus.status.authenticated, true);
assert.equal(replacementStatus.status.connected, true);
assert.equal(replacementStatus.status.detail, "ready");

console.log("Stale socket auth and close events are fenced.");

// A reconnect may already be waiting on storage when the user starts a new
// pairing. Releasing that old read must not create a socket that replaces the
// newer pairing socket.
replacementSocket.listeners.get("close")();
deferConfigRead = true;
alarmListener({ name: "bridge_reconnect" });
await new Promise((resolve) => setImmediate(resolve));
assert.equal(typeof releaseConfigRead, "function", "reconnect config read was not deferred");
const socketsBeforeReadRacePair = sockets.length;
let readRacePairResponse;
messageListener({
  type: "pair",
  token: "read-race-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {}, (response) => { readRacePairResponse = response; });
assert.deepEqual(readRacePairResponse, { ok: true });
const readRacePairSocket = sockets.at(-1);
assert.equal(sockets.length, socketsBeforeReadRacePair + 1);
deferConfigRead = false;
releaseConfigRead();
await flush();
assert.equal(
  sockets.length,
  socketsBeforeReadRacePair + 1,
  "stale reconnect created a socket after a newer pairing began",
);

// A paired secret write can also be in flight when another pairing replaces
// its socket. Serialization must make the newest secret the final stored one.
readRacePairSocket.readyState = StubWebSocket.OPEN;
readRacePairSocket.listeners.get("open")();
deferSecretWrite = true;
releaseSecretWrite = null;
readRacePairSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "stale-inflight-secret-1234567890" }),
});
readRacePairSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 9 }),
});
await flush();
assert.equal(typeof releaseSecretWrite, "function", "replacement secret write was not deferred");

let finalPairResponse;
messageListener({
  type: "pair",
  token: "final-pair-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {}, (response) => { finalPairResponse = response; });
assert.deepEqual(finalPairResponse, { ok: true });
const finalSocket = sockets.at(-1);
releaseSecretWrite();
await flush();
deferSecretWrite = false;
finalSocket.readyState = StubWebSocket.OPEN;
finalSocket.listeners.get("open")();
finalSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "final-current-secret-1234567890" }),
});
finalSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 10 }),
});
await flush();

assert.equal(storageData.bridge_secret, "final-current-secret-1234567890");
const finalStatus = await new Promise((resolve) => {
  messageListener({ type: "get_status" }, {}, resolve);
});
assert.equal(finalStatus.status.authenticated, true);
assert.equal(finalStatus.status.detail, "ready");

console.log("Async reconnect and credential storage races are fenced.");

// A reconnect socket can already be OPEN while its post-open config read is
// waiting. Explicit Pair must replace it so the obsolete secret hello can
// never race the user's token on the same connection.
storageData.bridge_base = "ws://127.0.0.1:8757";
finalSocket.readyState = 3;
finalSocket.listeners.get("close")();
alarmListener({ name: "bridge_reconnect" });
await new Promise((resolve) => setImmediate(resolve));
const openReconnectSocket = sockets.at(-1);
assert.notEqual(openReconnectSocket, finalSocket);
openReconnectSocket.readyState = StubWebSocket.OPEN;
deferConfigRead = true;
releaseConfigRead = null;
openReconnectSocket.listeners.get("open")();
await new Promise((resolve) => setImmediate(resolve));
assert.equal(typeof releaseConfigRead, "function", "post-open config read was not deferred");

let postOpenPairResponse;
messageListener({
  type: "pair",
  token: "post-open-pair-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {}, (response) => { postOpenPairResponse = response; });
assert.deepEqual(postOpenPairResponse, { ok: true });
const postOpenPairSocket = sockets.at(-1);
assert.notEqual(postOpenPairSocket, openReconnectSocket);

deferConfigRead = false;
releaseConfigRead();
await flush();
assert.equal(
  openReconnectSocket.sent.length,
  0,
  "replaced reconnect socket sent an obsolete secret hello",
);

postOpenPairSocket.readyState = StubWebSocket.OPEN;
postOpenPairSocket.listeners.get("open")();
assert.deepEqual(JSON.parse(postOpenPairSocket.sent[0]), {
  type: "hello",
  token: "post-open-pair-token-12345",
});
postOpenPairSocket.listeners.get("message")({
  data: JSON.stringify({ type: "paired", secret: "post-open-current-secret-1234567890" }),
});
postOpenPairSocket.listeners.get("message")({
  data: JSON.stringify({ type: "auth_ok", target: "browser_companion", session: 11 }),
});
await flush();
const postOpenStatus = await new Promise((resolve) => {
  messageListener({ type: "get_status" }, {}, resolve);
});
assert.equal(postOpenStatus.status.authenticated, true);
assert.equal(postOpenStatus.status.detail, "ready");

console.log("Explicit pairing replaces pending reconnect handshakes.");
