/**
 * Deterministic structural checks for the remote voice controller's acoustic
 * feedback and playback lifecycle. These checks deliberately inspect the real
 * browser source so renames or protocol changes cannot leave a stale harness
 * silently testing a retired implementation.
 *
 * Run: node aec_playback_harness.mjs
 */

import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const src = readFileSync(
  join(here, "../../apps/dashboard/static/voice_controller.js"),
  "utf8",
);

let failures = 0;
function check(condition, label) {
  if (condition) {
    console.log("PASS:", label);
  } else {
    console.error("FAIL:", label);
    failures++;
  }
}

function body(start, end) {
  const from = src.indexOf(start);
  const to = src.indexOf(end, from + start.length);
  return from >= 0 && to > from ? src.slice(from, to) : "";
}

// Capture is kept alive through an inaudible gain node. Neither capture
// engine may route microphone samples directly to the speaker destination.
check(
  src.includes("let zeroGain = null") && src.includes("gain = ctx.createGain()"),
  "zero-gain capture node is declared and created",
);
check(src.includes("gain.gain.value = 0"), "capture gain is exactly zero");
check(
  src.includes("script.connect(gain)") && src.includes("worklet.connect(gain)"),
  "worklet and compatibility capture both use zero-gain output",
);
check(src.includes("gain.connect(ctx.destination)"), "zero-gain node reaches shared destination");
check(
  !src.includes("script.connect(ctx.destination)") &&
    !src.includes("worklet.connect(ctx.destination)"),
  "microphone capture never routes audibly to destination",
);

// Browser-native AEC remains requested and its actual negotiated capability is
// surfaced honestly to the user.
check(src.includes("echoCancellation: { ideal: true }"), "echo cancellation requested");
check(src.includes("noiseSuppression: { ideal: true }"), "noise suppression requested");
check(src.includes("autoGainControl: { ideal: true }"), "automatic gain control requested");
check(src.includes("function inspectAEC("), "AEC capability inspection remains present");
check(
  src.includes("getSettings") && src.includes("getCapabilities"),
  "AEC inspection checks settings and capabilities",
);
check(
  /Echo cancellation is not available/.test(src) && /headphones/.test(src),
  "AEC-unavailable warning gives a practical mitigation",
);

// One user-gesture-created AudioContext is shared by capture, cues, working
// sounds, and reply playback.
const capture = body("async function startCapture(", "\n  function stopCapture()");
const enable = body("async function enable()", "\n  function deliberateClose");
const schedule = body("function scheduleAudio(", "\n  function handleBinary");
check(
  !capture.includes("new (window.AudioContext") && !capture.includes("new AudioContext"),
  "capture reuses the shared AudioContext",
);
check(
  enable.includes("new (window.AudioContext || window.webkitAudioContext)()"),
  "AudioContext is created in the explicit enable gesture",
);
check(
  !schedule.includes("new (window.AudioContext") &&
    schedule.includes("src.connect(audioCtx.destination)"),
  "reply playback reuses the shared AudioContext",
);

// Playback state sent to the server is transition-based and therefore cannot
// flood diagnostics per audio frame.
const report = body("function maybeReportPlayback()", "\n  function scheduleAudio");
check(
  report.includes("if (playing && !playbackReported)") &&
    report.includes("else if (!playing && playbackReported)"),
  "playback reports are deduplicated by state",
);
check(
  report.includes('type: "playback", playing: true') &&
    report.includes('type: "playback", playing: false'),
  "playback true and false use the current control protocol",
);

const flushVoice = body("function flushVoicePlayback()", "\n  function flushAnnouncePlayback");
check(flushVoice.includes("stopWorkingLoop()"), "voice flush stops the working loop");
check(
  flushVoice.includes("s.stop()") && flushVoice.includes("maybeReportPlayback()"),
  "voice flush stops queued sources and updates playback state",
);

const socketClose = body("sock.onclose = (e) => {", "\n    sock.onerror");
check(
  socketClose.includes("flushVoicePlayback()") &&
    socketClose.includes("flushAnnouncePlayback()"),
  "socket close flushes all local playback",
);

const stopAction = body("if (els.stop) {", "\n  if (els.goodbye)");
check(stopAction.includes("flushVoicePlayback()"), "Stop flushes reply playback immediately");

const goodbyeAction = body("if (els.goodbye) {", "\n  if (els.mute)");
check(
  goodbyeAction.includes("flushVoicePlayback()") &&
    goodbyeAction.indexOf("flushVoicePlayback()") <
      goodbyeAction.indexOf('applyServerState("wake")'),
  "Goodbye flushes playback before returning to wake mode",
);

const sourceEnded = body("src.onended = () => {", "\n      };");
check(
  sourceEnded.includes("maybeReportPlayback()"),
  "source completion updates playback state",
);

// The local activity sound is owner-local and is stopped on every lifecycle
// boundary that can make it stale.
const accepted = body('case "utterance_accepted":', 'case "working":');
check(
  accepted.includes("playHeardCue()") && accepted.includes("startWorkingLoop()"),
  "accepted utterance plays heard cue and starts activity loop",
);
const binary = body("function handleBinary(buf)", "\n  // ---- capture");
check(
  binary.indexOf("stopWorkingLoop()") >= 0 &&
    binary.indexOf("stopWorkingLoop()") < binary.indexOf("scheduleAudio(frame.pcm, true)"),
  "first reply audio stops activity before playback",
);
const clearCase = body('case "clear":', 'case "utterance_accepted":');
const revokedCase = body('case "revoked":', 'case "state":');
check(clearCase.includes("stopWorkingLoop()"), "interruption clear stops activity");
check(revokedCase.includes("stopWorkingLoop()"), "takeover revocation stops activity");

console.log("");
if (failures) {
  console.log(`${failures} AEC/PLAYBACK FAILURE(S)`);
  process.exit(1);
}
console.log("ALL AEC/PLAYBACK HARNESS CHECKS PASSED");