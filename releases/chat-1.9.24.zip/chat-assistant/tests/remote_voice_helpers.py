"""Shared helpers for remote-native voice tests (service + socket protocol).

The remote voice stack has two layers:
  * apps.live_gateway.remote_voice.RemoteVoiceService — dedicated provider
    stack + single-owner lease (unit-testable without any transport)
  * apps.dashboard.remote_voice_socket.serve_remote_voice_socket — the
    WebSocket protocol handler (driven here through a FakeWebSocket double)
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

from apps.audio.broadcast import AudioBroadcast
from apps.live_gateway.gateway import LiveGateway
from apps.live_gateway.remote_voice import (
    FRAME_BYTES,
    UP_HEADER,
    UP_MAGIC,
    UP_VERSION,
    RemoteVoiceService,
)
from apps.dashboard.remote_voice_socket import COOKIE, serve_remote_voice_socket
from chat_core.models.state import StateMachine
from chat_core.security.auth import SessionManager


async def dummy_tools(call_id, name, args):
    return {}


def frame(payload: bytes | int, seq: int = 0, *, magic: bytes = UP_MAGIC,
          version: int = UP_VERSION) -> bytes:
    """Build one framed upstream audio message.

    *payload* is either raw PCM bytes or an int16 amplitude to fill a full
    2560-byte frame with.
    """
    if isinstance(payload, int):
        payload = payload.to_bytes(2, "little", signed=True) * (FRAME_BYTES // 2)
    return UP_HEADER.pack(magic, version, 0, seq & 0xFFFFFFFF) + payload


def loud_frames(n: int, amplitude: int = 3000, start_seq: int = 0) -> list[bytes]:
    return [frame(amplitude, seq=start_seq + i) for i in range(n)]


class FakeWebSocket:
    """ASGI-WebSocket double that drives the real handler coroutine."""

    def __init__(self, token: str | None, headers: dict | None = None) -> None:
        self.cookies = {} if token is None else {COOKIE: token}
        self.headers = headers or {}
        self.incoming: asyncio.Queue[dict] = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code: int | None = None
        self.close_reason = ""
        self.sent_bytes: list[bytes] = []
        self.sent_text: list[str] = []
        self.sent_all: list[tuple[str, object]] = []  # unified delivery order

    async def accept(self) -> None:
        self.accepted.set()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        if not self.closed.is_set():
            self.close_code = code
            self.close_reason = reason or ""
            self.closed.set()
            # ASGI contract: after a server-side close, receive() yields a
            # disconnect message — that is what unblocks the handler loop.
            self.incoming.put_nowait({"type": "websocket.disconnect"})

    async def receive(self) -> dict:
        return await self.incoming.get()

    async def send_bytes(self, payload: bytes) -> None:
        if self.closed.is_set():
            raise RuntimeError("send on closed socket")
        self.sent_bytes.append(payload)
        self.sent_all.append(("bytes", payload))

    async def send_text(self, payload: str) -> None:
        if self.closed.is_set():
            raise RuntimeError("send on closed socket")
        self.sent_text.append(payload)
        self.sent_all.append(("text", payload))

    # -- test-side drivers -------------------------------------------------
    def feed_text(self, payload) -> None:
        if not isinstance(payload, str):
            payload = json.dumps(payload)
        self.incoming.put_nowait({"type": "websocket.receive", "text": payload})

    def feed_audio(self, payload: bytes) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": payload})

    def disconnect(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})

    # -- inspection helpers --------------------------------------------------
    def json_messages(self) -> list[dict]:
        return [json.loads(t) for t in self.sent_text]

    def last_of(self, mtype: str) -> dict | None:
        found = None
        for msg in self.json_messages():
            if msg.get("type") == mtype:
                found = msg
        return found

    async def wait_for(self, mtype: str, timeout: float = 1.0) -> dict:
        deadline = asyncio.get_event_loop().time() + timeout
        while True:
            msg = self.last_of(mtype)
            if msg is not None:
                return msg
            if asyncio.get_event_loop().time() > deadline:
                raise AssertionError(f"no {mtype!r} message; got {self.sent_text}")
            await asyncio.sleep(0.01)


def build_runtime(settings, db, store, bus, *, with_host_gateway: bool = True,
                  audio=None):
    """Build a SimpleNamespace runtime with a real RemoteVoiceService."""
    state = StateMachine(bus)
    host_gateway = (
        LiveGateway(settings, db, store, bus, state, [], dummy_tools)
        if with_host_gateway else None
    )
    rt = SimpleNamespace(
        settings=settings,
        db=db,
        state=state,
        gateway=host_gateway,
        broadcast=AudioBroadcast(),           # shared host-output mirror
        announce_broadcast=AudioBroadcast(),  # typed: alarms/announcements only
        audio=audio,
        media_playing=False,
        stop_calls=0,
        ring_stops=0,
        youtube_tools=None,
        companion=None,
    )

    def stop_output() -> None:
        rt.stop_calls += 1
        if host_gateway is not None:
            host_gateway.interrupt()
        rt.broadcast.clear()

    def stop_ringing() -> bool:
        rt.ring_stops += 1
        rt.announce_broadcast.clear()
        return False

    rt.stop_output = stop_output
    rt.stop_ringing = stop_ringing
    rt.remote_voice = RemoteVoiceService(
        settings, db, store, bus, [], dummy_tools,
        host_gateway=host_gateway,
        get_audio=lambda: rt.audio,
        broadcast=rt.announce_broadcast,
        get_youtube=lambda: rt.youtube_tools,
        get_companion=lambda: rt.companion,
        on_global_stop=rt.stop_output,
        on_stop_ringing=rt.stop_ringing,
        host_state=state,
    )
    return rt


def make_sessions() -> tuple[SessionManager, str]:
    sessions = SessionManager("remote-voice-test-secret", 3600)
    return sessions, sessions.issue()


async def open_socket(rt, sessions, token, *, device: str = "Test device",
                      takeover: bool = False, resume: dict | None = None,
                      headers: dict | None = None):
    """Connect a FakeWebSocket through the full hello handshake."""
    ws = FakeWebSocket(token, headers=headers)
    task = asyncio.create_task(serve_remote_voice_socket(rt, ws, sessions))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    hello = {
        "type": "hello",
        "protocol": 1,
        "token": sessions.capability_for(token, "remote-voice"),
        "device": device,
    }
    if takeover:
        hello["takeover"] = True
    if resume:
        hello["resume"] = resume
    ws.feed_text(hello)
    return ws, task


async def ready_socket(rt, sessions, token, **kw):
    """open_socket + wait for the ready frame."""
    ws, task = await open_socket(rt, sessions, token, **kw)
    ready = await ws.wait_for("ready")
    return ws, task, ready


async def start_conversation_via_socket(ws) -> None:
    ws.feed_text({"type": "start"})
    result = await ws.wait_for("start_result")
    assert result["status"] in ("started", "already"), result


async def finish(ws, task) -> None:
    ws.disconnect()
    await asyncio.wait_for(task, timeout=1.0)
    # Let fire-and-forget cleanup (lease release db.log) run while the test
    # database is still open.
    await asyncio.sleep(0.05)
