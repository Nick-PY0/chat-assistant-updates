from __future__ import annotations

import asyncio
import array
from types import SimpleNamespace

from apps.audio.engine import AudioEngine
from apps.audio.mic_gate import PlaybackAwareMicGate
from chat_core.models.state import ChatState, StateMachine
from chat_core.runtime import Runtime


def pcm(level: int, seconds: float = 0.08) -> bytes:
    return array.array("h", [level] * int(16_000 * seconds)).tobytes()


def test_gate_is_zero_cost_passthrough_when_media_is_stopped():
    gate = PlaybackAwareMicGate(700)
    frame = pcm(100)
    assert gate.feed(frame) == (frame,)


def test_media_residue_is_withheld_but_sustained_speech_opens_with_preroll():
    gate = PlaybackAwareMicGate(700)
    gate.set_media_playing(True)
    residue = pcm(250)
    voice = pcm(2_000)

    assert gate.feed(residue) == ()
    assert gate.feed(residue) == ()
    assert gate.feed(voice) == ()
    opened = gate.feed(voice)

    assert gate.is_open
    assert opened[-2:] == (voice, voice)
    assert sum(map(len, opened)) <= int(16_000 * 2 * 0.24)
    assert gate.feed(voice) == (voice,)


def test_constant_loud_playback_is_learned_instead_of_opening_the_gate():
    gate = PlaybackAwareMicGate(700)
    gate.set_media_playing(True)
    loud_media = pcm(2_000)

    assert all(gate.feed(loud_media) == () for _ in range(20))
    assert not gate.is_open


def test_learned_playback_floor_has_bounded_suppression_bar():
    gate = PlaybackAwareMicGate(700, max_bar_multiplier=3)
    gate.set_media_playing(True)
    for _ in range(20):
        gate.feed(pcm(12_000))
    assert gate.speech_bar() <= 2_100


def test_session_close_shuts_speech_window_without_forgetting_playback_floor():
    gate = PlaybackAwareMicGate(700)
    gate.set_media_playing(True)
    media = pcm(2_000)
    voice = pcm(8_000)
    for _ in range(4):
        gate.feed(media)
    gate.feed(voice)
    gate.feed(voice)
    assert gate.is_open

    gate.close_utterance()

    assert not gate.is_open
    assert gate.feed(media) == ()


def test_gate_closes_after_trailing_silence_and_pause_resets_immediately():
    gate = PlaybackAwareMicGate(700, calibration_seconds=0)
    gate.set_media_playing(True)
    voice = pcm(2_000)
    residue = pcm(100)
    gate.feed(voice)
    gate.feed(voice)
    assert gate.is_open

    for _ in range(9):
        assert gate.feed(residue) == (residue,)
    assert not gate.is_open
    assert gate.feed(residue) == ()

    gate.set_media_playing(False)
    assert gate.feed(residue) == (residue,)


def test_runtime_media_flag_reaches_current_audio_engine(settings):
    seen: list[bool] = []
    runtime = Runtime(settings)
    runtime.audio = SimpleNamespace(set_media_playing=seen.append)

    runtime.set_media_playing(True)
    runtime.set_media_playing(False)

    assert seen == [True, False]
    assert runtime.media_playing is False


async def test_physical_audio_engine_blocks_learned_media_but_forwards_voice(settings, bus):
    audio_in: asyncio.Queue[bytes] = asyncio.Queue()
    state = StateMachine(bus)
    state.set(ChatState.LISTENING, "test")
    engine = AudioEngine(
        settings,
        bus,
        state,
        audio_in=audio_in,
        audio_out=asyncio.Queue(),
        on_wake=lambda: None,
        on_interrupt=lambda: None,
    )
    engine.set_media_playing(True)
    task = asyncio.create_task(engine._mic_loop())
    try:
        for _ in range(10):
            engine._mic_q.put_nowait(pcm(2_000))
        while not engine._mic_q.empty():
            await asyncio.sleep(0.01)
        await asyncio.sleep(0.02)
        assert audio_in.empty()

        for _ in range(5):
            engine._mic_q.put_nowait(pcm(8_000))
        await asyncio.wait_for(audio_in.get(), timeout=1)
    finally:
        await engine.stop()
        await asyncio.wait_for(task, timeout=1)
