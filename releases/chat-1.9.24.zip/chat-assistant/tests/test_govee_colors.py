"""Strict color validation from tool input through the Govee payload."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from integrations.govee.client import (
    GoveeClient,
    GoveeError,
    canonical_color,
    pack_rgb,
    parse_color,
)


@pytest.mark.parametrize(
    ("name", "rgb"),
    [
        ("red", (255, 0, 0)),
        (" BROWN ", (165, 42, 42)),
        ("black", (0, 0, 0)),
        ("green", (0, 128, 0)),
        ("pink", (255, 192, 203)),
        ("gray", (128, 128, 128)),
        ("magenta", (255, 0, 255)),
    ],
)
def test_named_colors_are_validated_and_canonicalized(name, rgb):
    assert parse_color(name) == rgb
    assert canonical_color(name) == "#{:02X}{:02X}{:02X}".format(*rgb)


@pytest.mark.parametrize(
    "color",
    [
        "#fff",
        "#1234567",
        "#12345G",
        "#123456 ",
        " #123456",
        "123456",
        "#11223344",
    ],
)
def test_hex_color_rejects_everything_except_exact_rrggbb(color):
    with pytest.raises(GoveeError, match="exactly #RRGGBB|unknown color"):
        parse_color(color)


@pytest.mark.parametrize(
    "color", [None, 123, [], "sunset orange", "warm white", ""]
)
def test_unknown_or_malformed_color_inputs_have_clear_errors(color):
    with pytest.raises(GoveeError, match="color|unknown"):
        parse_color(color)


def test_rgb_ranges_and_packed_values():
    assert pack_rgb(0, 0, 0) == 0
    assert pack_rgb(255, 255, 255) == 0xFFFFFF
    assert pack_rgb(165, 42, 42) == 0xA52A2A
    for channels in [(-1, 0, 0), (0, 256, 0), (0, 0, 999)]:
        with pytest.raises(GoveeError, match="between 0 and 255"):
            pack_rgb(*channels)
    with pytest.raises(GoveeError, match="integers"):
        pack_rgb(1, 2.5, 3)


async def test_client_sends_govee_packed_integer():
    client = GoveeClient("secret")
    client._control = AsyncMock(return_value={"ok": True})

    assert await client.set_color("sku", "device-id", "brown") == {"ok": True}
    capability = client._control.await_args.args[2]
    assert capability == {
        "type": "devices.capabilities.color_setting",
        "instance": "colorRgb",
        "value": 0xA52A2A,
    }


async def test_color_tool_validates_locally_and_returns_canonical_result(db, bus, store):
    service = ToolService(db, bus, TimerManager(db, bus), store)
    service._devices_cache = [
        {"device": "device-id", "sku": "sku", "name": "Desk Light"}
    ]
    client = AsyncMock()

    async def get_client():
        return client

    service._govee = get_client

    result = await service.dispatch(
        "", "set_govee_color", {"device": "desk", "color": "brown"}
    )
    assert result == {"device": "Desk Light", "color": "#A52A2A"}
    client.set_color.assert_awaited_once_with("sku", "device-id", "#A52A2A")

    rejected = await service.dispatch(
        "", "set_govee_color", {"device": "desk", "color": "brownish sunset"}
    )
    assert "unknown color" in rejected["error"]
    client.set_color.assert_awaited_once()


def test_color_tool_contract_requires_resolved_strict_hex_for_descriptions():
    declaration = next(
        item for item in TOOL_DECLARATIONS if item["name"] == "set_govee_color"
    )
    contract = (
        declaration["description"]
        + " "
        + declaration["parameters"]["properties"]["color"]["description"]
    )
    assert "exactly #RRGGBB" in contract
    assert "Never send" in contract
    assert "descriptive" in contract