from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from apps.tool_service.briefing_scheduler import CalendarScheduler
from apps.tool_service.calendar_tool import CalendarManager, CalendarToolError
from apps.tool_service.local_grammar import parse
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from chat_core.models.credentials import CredentialStore
from chat_core.models.google_account import GoogleAccountStore, OAuthStateError
from chat_core.runtime import Runtime
from integrations.google_calendar import CalendarEvent, GoogleCalendarClient


NOW = datetime(2030, 1, 7, 8, 0, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_account_encryption_public_shape_oauth_and_disconnect(db, vault):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("raw-client-id", "raw-client-secret")
    await store.save_tokens("raw-access", "raw-refresh", NOW + timedelta(hours=1),
                            ["openid", "email"])
    await store.save_identity("person@example.com", "Person")
    row = await db.fetchone("SELECT * FROM connected_accounts WHERE provider='google'")
    assert all(secret.encode() not in bytes(row[field]) for secret, field in (
        ("raw-client-id", "encrypted_client_id"), ("raw-client-secret", "encrypted_client_secret"),
        ("raw-access", "encrypted_access_token"), ("raw-refresh", "encrypted_refresh_token")))
    public = await store.public_metadata()
    assert set(public) == {"configured", "connected", "status", "email", "display_name",
                           "scopes", "expires_at", "last_sync_at", "failure_code",
                           "needs_reauthorization"}

    state, _ = await store.create_pending("browser")
    pending = await db.fetchone("SELECT * FROM oauth_pending")
    assert pending["state_hash"] == hashlib.sha256(state.encode()).hexdigest()
    assert state not in tuple(pending)
    with pytest.raises(OAuthStateError):
        await store.consume_pending(state, "wrong")
    assert await store.consume_pending(state, "browser")
    with pytest.raises(OAuthStateError):
        await store.consume_pending(state, "browser")
    disconnected = await store.disconnect()
    assert disconnected["configured"] and not disconnected["connected"]


@pytest.mark.asyncio
async def test_pkce_discovery_defaults_refresh_and_reauth(db, vault):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_tokens("expired", "refresh", NOW - timedelta(seconds=1), ["openid"])
    seen = []

    async def handler(request):
        seen.append(request)
        if request.url.path.endswith("/token"):
            return httpx.Response(200, json={"access_token": "new", "expires_in": 3600,
                                             "scope": "openid email"})
        return httpx.Response(200, json={"items": [
            {"id": "primary", "summary": "Main", "description": "Home",
             "timeZone": "UTC", "primary": True, "accessRole": "owner"},
            {"id": "read", "summary": "Read", "accessRole": "reader"}]})

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    client = GoogleCalendarClient(store, http=http, clock=lambda: NOW)
    url, state = await client.authorization_url("https://app/callback", "binding")
    query = parse_qs(urlparse(url).query)
    assert state and query["code_challenge_method"] == ["S256"]
    calendars = await client.calendars()
    assert set(calendars[0]) == {"id", "name", "timezone", "primary",
                                 "access_role", "selected", "write_allowed"}
    assert calendars[0]["selected"] and (await store.selection()) == (["primary"], "primary")
    assert (await store.secrets()).access_token == "new"
    with pytest.raises(Exception):
        await client.select_calendars(["read"], "read")

    async def invalid(request):
        return httpx.Response(400, json={"error": "invalid_grant"})

    client.http = httpx.AsyncClient(transport=httpx.MockTransport(invalid))
    await store.save_tokens("expired", "refresh", NOW - timedelta(seconds=1), ["openid"])
    with pytest.raises(Exception):
        await client.calendars()
    assert (await store.public_metadata())["needs_reauthorization"] is True
    await http.aclose()
    await client.http.aclose()


def event(event_id="e1", title="Meeting", start=None):
    start = start or (NOW + timedelta(minutes=10)).isoformat()
    return CalendarEvent(event_id, "primary", "Main", title, start,
                         (datetime.fromisoformat(start) + timedelta(hours=1)).isoformat(),
                         False, "UTC", None, None, "series", "confirmed")


@pytest.mark.asyncio
async def test_sync_pagination_410_cancellation_recurrence_and_cache_fallback(db, vault):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_tokens("token", "refresh", NOW + timedelta(hours=1), ["openid"])
    await store.save_calendar_selection(["primary"], "primary")
    calls = {"events": 0}

    async def handler(request):
        if request.url.path.endswith("/calendarList"):
            return httpx.Response(200, json={"items": [
                {"id": "primary", "summary": "Main", "primary": True, "accessRole": "owner"}]})
        calls["events"] += 1
        if "syncToken=old" in str(request.url):
            return httpx.Response(410, json={})
        if "pageToken=p2" in str(request.url):
            return httpx.Response(200, json={"items": [{"id": "gone", "status": "cancelled"}],
                                             "nextSyncToken": "fresh"})
        return httpx.Response(200, json={"items": [{"id": "e1", "summary": "Recurring",
            "start": {"dateTime": "2030-01-07T09:00:00+00:00", "timeZone": "UTC"},
            "end": {"dateTime": "2030-01-07T10:00:00+00:00"},
            "recurringEventId": "series",
            "htmlLink": "https://calendar.google.com/calendar/event?eid=1"}],
            "nextPageToken": "p2"})

    client = GoogleCalendarClient(store,
        http=httpx.AsyncClient(transport=httpx.MockTransport(handler)), clock=lambda: NOW)
    await client.cache_event(event("gone"))
    await db.execute("INSERT INTO calendar_sync_state VALUES('google','primary','old',?)",
                     (NOW.isoformat(),))
    synced = await client.sync("primary")
    assert synced[0].recurring_event_id == "series"
    assert calls["events"] == 3  # 410, reset first page, second page
    assert not await db.fetchone("SELECT 1 FROM calendar_event_cache WHERE event_id='gone'")

    async def offline(request):
        raise httpx.ConnectError("offline", request=request)

    await client.http.aclose()
    client.http = httpx.AsyncClient(transport=httpx.MockTransport(offline))
    cached = await client.list_events(NOW, NOW + timedelta(days=1))
    assert [item.id for item in cached] == ["e1"]
    await client.http.aclose()


class FakeProvider:
    def __init__(self, account, events=None):
        self.account, self.events = account, events or []
        self.created = self.fetched = 0

    async def calendars(self):
        return [{"id": "primary", "name": "Main", "write_allowed": True}]

    async def list_events(self, start, end):
        return self.events

    async def create_event(self, calendar_id, payload):
        self.created += 1
        return event("created", payload["summary"], payload["start"]["dateTime"])

    async def get_event(self, calendar_id, event_id):
        self.fetched += 1
        return event(event_id, "Verified", "2030-01-08T10:00:00+00:00")

    async def cache_event(self, value):
        self.cached = value


@pytest.mark.asyncio
async def test_appointment_contract_confirmation_and_verification(db, vault, bus):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_calendar_selection(["primary"], "primary")
    provider = FakeProvider(store)
    manager = CalendarManager(db, provider, bus=bus, clock=lambda: NOW)
    reviewed = await manager.review_appointment(
        "Dentist", "2030-01-08T10:00:00", 60, timezone_name="UTC")
    assert set(reviewed["draft"]) == {"id", "title", "start_at", "end_at", "when",
                                      "calendar_id", "calendar_name", "timezone", "expires_at"}
    with pytest.raises(CalendarToolError):
        await manager.confirm_appointment(reviewed["draft"]["id"], False)
    result = await manager.confirm_appointment(reviewed["draft"]["id"], True)
    assert result["event"]["title"] == "Verified"
    assert provider.created == provider.fetched == 1
    with pytest.raises(CalendarToolError):
        await manager.confirm_appointment(reviewed["draft"]["id"], True)


@pytest.mark.asyncio
async def test_scheduler_restart_quiet_busy_and_stale(db, vault):
    now = [NOW]
    store = GoogleAccountStore(db, vault, lambda: now[0])
    await store.configure("client", "secret")
    provider, spoken = FakeProvider(store), []

    async def announce(text):
        spoken.append(text)

    scheduler = CalendarScheduler(db, provider, announce, clock=lambda: now[0])
    await scheduler.set_combined_preferences(
        timezone_name="UTC", meeting_alert_enabled=False, meeting_lead_minutes=10,
        briefing_enabled=True, briefing_time="08:00", weekdays=[0],
        sections=["calendar"])
    await scheduler.tick()
    await CalendarScheduler(db, provider, announce, clock=lambda: now[0]).tick()
    assert len(spoken) == 1  # restart dedup
    now[0] += timedelta(days=7, seconds=121)
    await scheduler.tick()
    assert len(spoken) == 1  # stale
    now[0] = datetime(2030, 1, 21, 8, tzinfo=timezone.utc)
    quiet = CalendarScheduler(db, provider, announce, clock=lambda: now[0],
                              is_quiet=lambda: True)
    await quiet.tick()
    row = await db.fetchone("SELECT status FROM briefing_runs WHERE dedup_key LIKE 'briefing:2030-01-21%'")
    assert row["status"] == "suppressed_quiet"
    now[0] += timedelta(days=7)
    busy = CalendarScheduler(db, provider, announce, clock=lambda: now[0],
                             is_busy=lambda: True)
    await busy.tick()
    assert not await db.fetchone(
        "SELECT 1 FROM briefing_runs WHERE dedup_key LIKE 'briefing:2030-01-28%'")


@pytest.mark.asyncio
@pytest.mark.parametrize("restart_lag_seconds", [1, 119])
async def test_scheduler_does_not_replay_runs_missed_before_start(
    db, vault, restart_lag_seconds
):
    now = [NOW + timedelta(seconds=restart_lag_seconds)]
    store = GoogleAccountStore(db, vault, lambda: now[0])
    await store.configure("client", "secret")
    provider = FakeProvider(store, events=[
        event("restart-meeting", start=(NOW + timedelta(minutes=10)).isoformat())
    ])
    spoken = []

    async def announce(text):
        spoken.append(text)

    scheduler = CalendarScheduler(db, provider, announce, clock=lambda: now[0])
    await scheduler.set_combined_preferences(
        timezone_name="UTC",
        meeting_alert_enabled=True,
        meeting_lead_minutes=10,
        briefing_enabled=True,
        briefing_time="08:00",
        weekdays=[0],
        sections=["calendar"],
    )
    await scheduler.tick()

    assert spoken == []
    assert not await db.fetchone("SELECT 1 FROM briefing_runs")


def test_local_calendar_grammar_requires_complete_review_then_confirmation():
    assert parse("what is my next meeting") == {
        "tool": "get_next_meeting", "args": {}
    }
    assert parse("show my upcoming calendar events") == {
        "tool": "list_calendar_events", "args": {"days": 14, "limit": 20}
    }
    assert parse(
        "schedule an appointment called dentist on 2030-01-08 at 10:30 for 1 hour"
    ) == {
        "tool": "create_calendar_event",
        "args": {
            "title": "dentist",
            "start_local": "2030-01-08T10:30",
            "duration_minutes": 60,
        },
    }
    assert parse("confirm the appointment") == {
        "tool": "confirm_calendar_event", "args": {}
    }
    assert parse("schedule a dentist appointment tomorrow") is None


@pytest.mark.asyncio
async def test_tool_service_never_confirms_an_implicit_shared_draft(db, vault, bus):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_calendar_selection(["primary"], "primary")
    manager = CalendarManager(db, FakeProvider(store), bus=bus, clock=lambda: NOW)
    credentials = CredentialStore(db, vault)
    tools = ToolService(
        db, bus, TimerManager(db, bus), credentials, calendar=manager
    )
    reviewed = await tools.dispatch("", "create_calendar_event", {
        "title": "Private review",
        "start_local": "2030-01-08T10:00:00",
        "duration_minutes": 30,
        "timezone": "UTC",
    })
    assert reviewed["needs_confirmation"] is True
    assert (await tools.dispatch("", "confirm_calendar_event", {})) == {
        "error": "there is no reviewed appointment to confirm"
    }
    row = await db.fetchone(
        "SELECT status FROM calendar_drafts WHERE id=?", (reviewed["draft"]["id"],)
    )
    assert row["status"] == "pending"


@pytest.mark.asyncio
async def test_scheduler_timezone_change_updates_calendar_manager(db, vault):
    store = GoogleAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_calendar_selection(["primary"], "primary")
    provider = FakeProvider(store)
    manager = CalendarManager(
        db, provider, clock=lambda: NOW, default_timezone="America/New_York"
    )
    scheduler = CalendarScheduler(
        db,
        provider,
        lambda _: None,
        clock=lambda: NOW,
        default_timezone="America/New_York",
        on_timezone_change=lambda name: setattr(manager, "default_timezone", name),
    )
    assert (await scheduler.get_preferences())["timezone"] == "America/New_York"
    reviewed = await manager.review_appointment(
        "Local wall time", "2030-01-08T10:00:00", 30
    )
    assert reviewed["draft"]["timezone"] == "America/New_York"
    assert reviewed["draft"]["start_at"].endswith("-05:00")
    await scheduler.set_combined_preferences(
        timezone_name="America/Los_Angeles",
        meeting_alert_enabled=False,
        meeting_lead_minutes=10,
        briefing_enabled=False,
        briefing_time="08:00",
        weekdays=[0, 1, 2, 3, 4],
        sections=["calendar"],
    )
    assert manager.default_timezone == "America/Los_Angeles"


@pytest.mark.asyncio
async def test_host_local_draft_is_not_changed_by_remote_phone_presence(
    settings, db, monkeypatch
):
    runtime = Runtime(settings)
    runtime.db = db
    calls = []

    class FakeTools:
        async def dispatch(self, call_id, name, args):
            calls.append((name, dict(args)))
            if name == "create_calendar_event":
                return {
                    "needs_confirmation": True,
                    "draft": {"id": "host-draft"},
                    "summary": "Please confirm.",
                }
            return {"event": {"title": "Created"}, "summary": "Created."}

    runtime.tools = FakeTools()
    monkeypatch.setattr(runtime, "_announce", lambda *args, **kwargs: None)

    async def no_speech(text):
        return False

    monkeypatch.setattr(runtime, "_speak_dynamic", no_speech)
    reviewed = await runtime.handle_local_utterance(
        "schedule an appointment called dentist on 2030-01-08 at 10:30 for 1 hour"
    )
    assert reviewed["draft"]["id"] == "host-draft"
    assert runtime._host_calendar_draft_id == "host-draft"

    # A connected remote voice service is a separate provider/tool pipeline;
    # its mere presence cannot steal ownership from this host callback.
    runtime.remote_voice = object()
    confirmed = await runtime.handle_local_utterance("confirm the appointment")
    assert confirmed["event"]["title"] == "Created"
    assert calls[-1] == ("confirm_calendar_event", {"draft_id": "host-draft"})
    assert runtime._host_calendar_draft_id is None