"""Relay walkie-talkie sessions: capture, model routing, tools, the daily
cap, and inactivity -- all against a stub relay (no network)."""

from __future__ import annotations

import asyncio
import json

import pytest

from apps.live_gateway.relay_session import RelayVoiceSession, to_chat_tools
from apps.tool_service.schemas import TOOL_DECLARATIONS
from chat_core.models.state import StateMachine
from integrations.relay.client import RelayDiscovery, RelayError, RelayModel

LOUD = b"\x88\x13" * 1280    # constant 5000 amplitude -> RMS 5000
QUIET = b"\x00" * 2560       # digital silence


class StubRelay:
    """Scripted stand-in for RelayClient."""

    def __init__(self):
        self.text = "set a timer for five minutes"
        self.script = [
            {"reply": "", "tool_calls": [
                {"id": "t1", "type": "function",
                 "function": {"name": "start_timer",
                              "arguments": json.dumps({"duration_seconds": 300})}}],
             "usage": {"prompt_tokens": 9, "completion_tokens": 4}},
            {"reply": "Timer set.", "tool_calls": [],
             "usage": {"prompt_tokens": 12, "completion_tokens": 3}},
        ]
        self.asks: list[tuple] = []
        self.health_calls = 0

    async def health(self):
        self.health_calls += 1

    async def transcribe(self, pcm):
        return self.text

    async def ask(self, messages, tools, model, max_tokens=1600):
        self.asks.append((messages, tools, model))
        if self.script:
            item = self.script.pop(0)
            if isinstance(item, Exception):
                raise item
            return item
        return {"reply": "Anything else?", "tool_calls": [], "usage": {}}

    async def speak(self, text, voice):
        return (b"\x07\x00" * 2400, 24000)  # 0.1 s of audio at 24 kHz


@pytest.fixture
def parts(settings, db, bus):
    settings.inactivity_timeout_seconds = 1
    state = StateMachine(bus)
    audio_in: asyncio.Queue = asyncio.Queue()
    audio_out: asyncio.Queue = asyncio.Queue(maxsize=256)
    calls: list[tuple] = []

    async def tool_handler(call_id, name, args):
        calls.append((call_id, name, args))
        return {"ok": True}

    stub = StubRelay()
    session = RelayVoiceSession(
        stub, settings, db, bus, state, TOOL_DECLARATIONS,
        tool_handler, audio_in, audio_out,
    )
    return session, stub, audio_in, audio_out, calls


def speak_then_silence(audio_in):
    for _ in range(10):
        audio_in.put_nowait(LOUD)
    for _ in range(12):
        audio_in.put_nowait(QUIET)


def test_to_chat_tools_shape():
    tools = to_chat_tools(TOOL_DECLARATIONS[:1])
    assert tools[0]["type"] == "function"
    fn = tools[0]["function"]
    assert fn["name"] == "start_timer"
    assert fn["parameters"]["type"] == "object"
    assert fn["parameters"]["properties"]["duration_seconds"]["type"] == "integer"


async def test_command_conversation_with_tools(parts, settings, db):
    session, stub, audio_in, audio_out, calls = parts
    speak_then_silence(audio_in)
    reason = await asyncio.wait_for(session.run(), timeout=20)
    assert reason == "inactivity"
    assert stub.health_calls == 1
    # "timer" phrasing routed to the cheap command model
    assert stub.asks[0][2] == settings.relay_command_model
    # the tool ran, and the model got its result for the follow-up
    assert calls == [("t1", "start_timer", {"duration_seconds": 300})]
    tool_msgs = [m for m in stub.asks[1][0] if m.get("role") == "tool"]
    assert tool_msgs and json.loads(tool_msgs[0]["content"]) == {"ok": True}
    # spoken reply made it to the speaker path
    assert not audio_out.empty()
    row = await db.fetchone(
        "SELECT COUNT(*) AS n FROM usage_log WHERE event LIKE 'relay:%'")
    assert row["n"] >= 4  # transcribe + 2 asks + speak


async def test_open_question_uses_chat_model(parts, settings):
    session, stub, audio_in, _out, calls = parts
    stub.text = "please share your thoughts on dragons"
    stub.script = [{"reply": "Dragons are great.", "tool_calls": [], "usage": {}}]
    speak_then_silence(audio_in)
    reason = await asyncio.wait_for(session.run(), timeout=20)
    assert reason == "inactivity"
    assert stub.asks[0][2] == settings.relay_chat_model
    assert calls == []


async def test_empty_reply_becomes_spoken_apology(parts):
    session, stub, audio_in, audio_out, _calls = parts
    stub.script = [{"reply": "", "tool_calls": [], "usage": {}}]  # budget eaten by reasoning
    speak_then_silence(audio_in)
    await asyncio.wait_for(session.run(), timeout=20)
    assert session._history[-1]["content"].startswith("Sorry")
    assert not audio_out.empty()


async def test_silence_means_inactivity_and_no_spend(parts):
    session, stub, audio_in, _out, _calls = parts
    for _ in range(5):
        audio_in.put_nowait(QUIET)
    reason = await asyncio.wait_for(session.run(), timeout=10)
    assert reason == "inactivity"
    assert stub.asks == []


async def test_daily_cap_blocks_before_spending(parts, settings, db):
    session, stub, _in, _out, _calls = parts
    settings.relay_daily_request_cap = 1
    await db.usage(None, "relay:ask", "seed from earlier today")
    reason = await asyncio.wait_for(session.run(), timeout=10)
    assert reason == "daily relay limit reached"
    assert stub.asks == []


async def test_cap_trips_mid_turn_before_asking(parts, settings, db):
    session, stub, audio_in, _out, _calls = parts
    settings.relay_daily_request_cap = 2
    await db.usage(None, "relay:ask", "seed from earlier today")
    speak_then_silence(audio_in)
    reason = await asyncio.wait_for(session.run(), timeout=20)
    # transcribe was the 2nd call of the day; the paid ask never happened
    assert reason == "daily relay limit reached"
    assert stub.asks == []


async def test_leftover_audio_after_reply_is_dropped(parts):
    session, stub, audio_in, _out, _calls = parts
    speak_then_silence(audio_in)
    for _ in range(10):
        audio_in.put_nowait(LOUD)  # noise arriving while the reply plays
    reason = await asyncio.wait_for(session.run(), timeout=20)
    assert reason == "inactivity"
    assert len(stub.asks) == 2  # the playback-time noise never became a question


async def test_interruption_clears_both_queues(parts):
    session, _stub, audio_in, audio_out, _calls = parts
    audio_in.put_nowait(LOUD)
    audio_out.put_nowait(b"\x00\x02" * 100)
    session._drain_output()
    assert audio_out.empty()
    assert audio_in.empty()
    assert session._interrupted.is_set()


async def test_cap_of_zero_means_no_limit(parts):
    session, stub, audio_in, _out, _calls = parts
    session.settings.relay_daily_request_cap = 0
    for _ in range(5):
        audio_in.put_nowait(QUIET)
    reason = await asyncio.wait_for(session.run(), timeout=10)
    assert reason == "inactivity"  # got past the cap check to the mic


async def test_discovered_fallback_is_reused_for_remaining_tool_hops(parts):
    session, stub, _audio_in, _out, calls = parts
    discovery = RelayDiscovery(
        models=(
            RelayModel("economy-a", "chat", "low", 10, 1, False, True, ("text",)),
            RelayModel("economy-b", "chat", "low", 20, 2, False, True, ("text",)),
            RelayModel("balanced", "chat", "mid", 50, 50, False, True, ("text",)),
        ),
        defaults={"chat": "balanced"},
    )

    async def discover_models():
        return discovery

    stub.discover_models = discover_models
    stub.script = [
        RelayError("selected model rejected function tools"),
        {"reply": "", "tool_calls": [{
            "id": "t2", "function": {
                "name": "start_timer", "arguments": '{"duration_seconds": 60}'
            },
        }], "usage": {}},
        {"reply": "Done.", "tool_calls": [], "usage": {}},
    ]
    spend_checks = 0
    original_require_spend = session._require_spend

    async def counted_spend_check():
        nonlocal spend_checks
        spend_checks += 1
        await original_require_spend()

    session._require_spend = counted_spend_check
    reply = await session._think("set a timer for one minute")

    assert reply == "Done."
    assert [ask[2] for ask in stub.asks] == [
        "economy-a", "economy-b", "economy-b"
    ]
    assert spend_checks == len(stub.asks)
    assert calls == [("t2", "start_timer", {"duration_seconds": 60})]
