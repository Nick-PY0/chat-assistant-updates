"""Relay client: URL shaping, auth errors in plain words, WAV plumbing."""

from __future__ import annotations

import base64
import json

import httpx
import pytest

from integrations.relay.client import (
    RelayClient,
    RelayError,
    classify_turn,
    parse_wav,
    select_models,
    wrap_wav,
)


def test_base_url_shaping():
    assert RelayClient("https://x.replit.app", "s").base == "https://x.replit.app/api"
    assert RelayClient("x.replit.app", "s").base == "https://x.replit.app/api"
    assert RelayClient("https://x.replit.app/", "s").base == "https://x.replit.app/api"
    assert RelayClient("https://x.replit.app/api", "s").base == "https://x.replit.app/api"
    assert RelayClient("", "s").base == ""


def test_plain_http_is_refused():
    with pytest.raises(RelayError) as info:
        RelayClient("http://sketchy.example", "s")
    assert "https" in str(info.value)


def test_wav_roundtrip_mono():
    pcm = b"\x01\x02" * 1000
    blob = wrap_wav(pcm, 16000)
    out, rate = parse_wav(blob)
    assert out == pcm
    assert rate == 16000


def test_wav_stereo_folds_to_mono():
    import struct
    frames = b"".join(struct.pack("<hh", 1000, 3000) for _ in range(100))
    blob = wrap_wav(frames, 24000, channels=2)
    out, rate = parse_wav(blob)
    assert rate == 24000
    assert len(out) == 100 * 2  # one sample per frame now
    import array
    folded = array.array("h")
    folded.frombytes(out)
    assert all(v == 2000 for v in folded)


def test_parse_wav_garbage_is_a_relay_error():
    with pytest.raises(RelayError):
        parse_wav(b"this is not audio")


def make_client(handler) -> RelayClient:
    return RelayClient("https://relay.test", "pw123",
                       transport=httpx.MockTransport(handler))


def discovery_payload():
    return {
        "models": {
            "chat": [
                {"id": "cheap", "job": "chat", "tier": "low", "rank": 10,
                 "costRank": 1, "reasoning": False, "tools": True,
                 "modalities": ["text"]},
                {"id": "balanced", "job": "chat", "tier": "mid", "rank": 50,
                 "costRank": 50, "reasoning": False, "tools": True,
                 "modalities": ["text"]},
                {"id": "deep", "job": "chat", "tier": "high", "rank": 100,
                 "costRank": 100, "reasoning": True, "tools": True,
                 "modalities": ["text"]},
                {"id": "no-tools", "job": "chat", "tier": "high", "rank": 110,
                 "costRank": 80, "reasoning": True, "tools": False,
                 "modalities": ["text"]},
            ],
        },
        "defaults": {"chat": "balanced"},
    }


async def test_missing_url_fails_before_network():
    client = RelayClient("", "pw")
    with pytest.raises(RelayError) as info:
        await client.health()
    assert "no relay address" in str(info.value)


async def test_auth_errors_speak_plainly():
    def handler(request):
        return httpx.Response(401, json={"error": "bad key"})
    with pytest.raises(RelayError) as info:
        await make_client(handler).health()
    assert "password" in str(info.value)

    def handler503(request):
        return httpx.Response(503, json={"error": "relay not configured"})
    with pytest.raises(RelayError) as info:
        await make_client(handler503).health()
    assert "no password set" in str(info.value)


async def test_ask_passes_through_and_sends_auth_header():
    seen = {}

    def handler(request):
        seen["path"] = request.url.path
        seen["key"] = request.headers.get("x-chat-relay-key")
        seen["body"] = json.loads(request.content)
        return httpx.Response(200, json={
            "model": "gpt-5.6-terra", "reply": "hello", "tool_calls": [],
            "usage": {"prompt_tokens": 3, "completion_tokens": 2},
        })

    data = await make_client(handler).ask(
        [{"role": "user", "content": "hi"}], [], "gpt-5.6-terra")
    assert data["reply"] == "hello"
    assert seen["path"] == "/api/relay/ask"
    assert seen["key"] == "pw123"
    assert seen["body"]["model"] == "gpt-5.6-terra"
    assert seen["body"]["max_tokens"] >= 1000  # room for reasoning models


async def test_transcribe_wraps_pcm_into_wav():
    seen = {}

    def handler(request):
        body = json.loads(request.content)
        seen["audio"] = base64.b64decode(body["audio_b64"])
        return httpx.Response(200, json={"text": " turn on the lights "})

    text = await make_client(handler).transcribe(b"\x00\x01" * 800)
    assert text == "turn on the lights"
    assert seen["audio"][:4] == b"RIFF"
    assert b"WAVE" in seen["audio"][:16]


async def test_speak_decodes_wav():
    pcm = b"\x07\x00" * 2400

    def handler(request):
        blob = wrap_wav(pcm, 24000)
        return httpx.Response(200, json={"audio_b64": base64.b64encode(blob).decode()})

    out, rate = await make_client(handler).speak("hi there", "alloy")
    assert rate == 24000
    assert out == pcm


async def test_speak_empty_audio_is_an_error():
    def handler(request):
        return httpx.Response(200, json={"audio_b64": ""})
    with pytest.raises(RelayError):
        await make_client(handler).speak("hi", "alloy")


async def test_server_error_message_surfaces():
    def handler(request):
        return httpx.Response(429, json={"error": "daily relay budget on the server is spent"})
    with pytest.raises(RelayError) as info:
        await make_client(handler).health()
    assert "budget" in str(info.value)


def test_turn_classification_and_capability_selection():
    assert classify_turn("turn off the kitchen lights") == "command"
    assert classify_turn("Why is the sky blue?") == "normal"
    assert classify_turn("Explain the history of alarm clocks") == "normal"
    assert classify_turn("Analyze the trade-offs and derive a migration strategy") == "complex"

    discovery = RelayClient._validate_discovery(discovery_payload())
    assert select_models(
        discovery, "set a timer for ten minutes", needs_tools=True
    )[0] == "cheap"
    assert select_models(
        discovery, "What causes rain?", needs_tools=True
    )[0] == "balanced"
    route = select_models(
        discovery, "Analyze and prove the root cause step-by-step", needs_tools=True
    )
    assert route[0] == "deep"
    assert "no-tools" not in route
    assert len(route) <= 3


def test_incompatible_advertised_default_fails_closed():
    payload = discovery_payload()
    payload["models"]["chat"] = [{
        "id": "advertised-default",
        "job": "chat",
        "tier": "mid",
        "rank": 100,
        "costRank": 1,
        "reasoning": False,
        "tools": False,
        "modalities": ["text"],
    }]
    payload["defaults"]["chat"] = "advertised-default"
    discovery = RelayClient._validate_discovery(payload)

    assert select_models(
        discovery, "set a timer for ten minutes", needs_tools=True
    ) == []


def test_configured_model_and_bounded_compatible_fallbacks_are_preserved():
    payload = discovery_payload()
    payload["models"]["chat"].extend([
        {"id": "cheaper", "job": "chat", "tier": "low", "rank": 20,
         "costRank": 0, "reasoning": False, "tools": True,
         "modalities": ["text"]},
        {"id": "cheap-third", "job": "chat", "tier": "low", "rank": 5,
         "costRank": 2, "reasoning": False, "tools": True,
         "modalities": ["text"]},
        {"id": "cheap-fourth", "job": "chat", "tier": "low", "rank": 4,
         "costRank": 3, "reasoning": False, "tools": True,
         "modalities": ["text"]},
    ])
    discovery = RelayClient._validate_discovery(payload)

    route = select_models(
        discovery,
        "set a timer for ten minutes",
        needs_tools=True,
        configured_command="cheap",
    )

    assert route[0] == "cheap"
    assert len(route) == 3
    assert "no-tools" not in route


async def test_discovery_is_validated_and_cached():
    calls = 0

    def handler(request):
        nonlocal calls
        calls += 1
        return httpx.Response(200, json=discovery_payload())

    client = RelayClient(
        "https://discovery-cache.test", "unique",
        transport=httpx.MockTransport(handler),
    )
    first = await client.discover_models()
    second = await client.discover_models()
    assert first is second
    assert calls == 1


async def test_invalid_discovery_is_rejected_not_guessed():
    def handler(request):
        payload = discovery_payload()
        del payload["models"]["chat"][0]["tools"]
        return httpx.Response(200, json=payload)

    client = RelayClient(
        "https://invalid-discovery.test", "unique",
        transport=httpx.MockTransport(handler),
    )
    with pytest.raises(RelayError, match="invalid model discovery"):
        await client.discover_models()
