"""Voice-contract regressions: the user's exact Hey Jarvis / Stop / Goodbye rules.

Covered here:
  * continuous defaults (continuous_conversation=True, 1800s lease)
  * rolling 30-minute deadline resets on user/assistant activity
  * Stop only interrupts and keeps the session + microphone alive (all brains)
  * Goodbye ends the session; a fresh wake word is required afterwards
  * the stop grammar and goodbye grammar are disjoint (parser + local grammar)
  * remote Voice Controller Stop preserves the active turn; Goodbye returns
    the same transport to wake-listening mode
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from apps.live_gateway.prompts import (
    is_voice_goodbye_phrase,
    is_voice_stop_phrase,
)
from apps.tool_service.local_grammar import parse as parse_local
from chat_core.config.settings import Settings
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


# ---------------------------------------------------------------------------
# 1. Continuous-conversation defaults
# ---------------------------------------------------------------------------

def test_continuous_conversation_defaults_true_and_1800():
    s = Settings()
    assert s.continuous_conversation is True
    assert s.continuous_session_seconds == 1800


async def _dummy_tools(call_id, name, args):
    return {}


def _make_gateway(settings, db, store, bus):
    state = StateMachine(bus)
    return LiveGateway(settings, db, store, bus, state, [], _dummy_tools), state


def test_conversation_timeout_uses_1800s_rolling_lease(settings, db, store, bus):
    gw, _ = _make_gateway(settings, db, store, bus)
    # Rolling deadline is the max of inactivity and continuous lease seconds.
    assert gw._conversation_timeout() == 1800.0


def test_conversation_timeout_falls_back_when_continuous_off(settings, db, store, bus):
    settings.continuous_conversation = False
    gw, _ = _make_gateway(settings, db, store, bus)
    assert gw._conversation_timeout() == float(settings.inactivity_timeout_seconds)


# ---------------------------------------------------------------------------
# 2. Rolling deadline resets after user/assistant activity
# ---------------------------------------------------------------------------

def test_rolling_deadline_resets_on_activity(settings, db, store, bus, monkeypatch):
    import apps.live_gateway.gateway as gw_mod

    gw, _ = _make_gateway(settings, db, store, bus)
    gw.request_session()
    fake_now = [1000.0]
    monkeypatch.setattr(gw_mod.time, "monotonic", lambda: fake_now[0])

    # Time advances almost to the lease edge without activity.
    fake_now[0] = 1000.0 + 1700.0
    gw._last_interaction_at = 1000.0
    assert gw._conversation_idle_elapsed() == pytest.approx(1700.0)

    # An assistant/user turn resets the rolling window.
    gw._on_session_activity()
    assert gw._conversation_idle_elapsed() == pytest.approx(0.0)

    # ... and it accumulates again from the reset point, not from the start.
    fake_now[0] += 500.0
    assert gw._conversation_idle_elapsed() == pytest.approx(500.0)


def test_activity_ignored_when_no_active_lease(settings, db, store, bus):
    gw, _ = _make_gateway(settings, db, store, bus)
    gw._session_intent_active = False
    gw._last_interaction_at = 0.0
    gw._on_session_activity()
    # No lease -> no rolling window is started.
    assert gw._last_interaction_at == 0.0


# ---------------------------------------------------------------------------
# 3. Parser disjointness: stop vs goodbye
# ---------------------------------------------------------------------------

STOP_PHRASES = [
    "stop", "Stop.", "stop Jarvis", "Jarvis stop", "hey Jarvis stop",
    "stop now", "please stop", "be quiet", "quiet", "hush", "stop talking",
]

GOODBYE_PHRASES = [
    "goodbye", "good bye", "goodbye Jarvis", "Jarvis goodbye", "bye",
    "bye Jarvis", "stop listening", "end conversation", "end the conversation",
    "end session", "go to sleep", "that's all", "that's all Jarvis",
]

NEITHER_PHRASES = [
    "stop the timer", "stop the music", "what time is it",
    "set a timer for ten minutes", "stop the kitchen timer",
]


@pytest.mark.parametrize("text", STOP_PHRASES)
def test_stop_phrases_are_stop_only(text):
    assert is_voice_stop_phrase(text) is True
    assert is_voice_goodbye_phrase(text) is False


@pytest.mark.parametrize("text", GOODBYE_PHRASES)
def test_goodbye_phrases_are_goodbye_only(text):
    assert is_voice_goodbye_phrase(text) is True
    assert is_voice_stop_phrase(text) is False


@pytest.mark.parametrize("text", NEITHER_PHRASES)
def test_named_targets_are_neither(text):
    assert is_voice_stop_phrase(text) is False
    assert is_voice_goodbye_phrase(text) is False


def test_stop_and_goodbye_grammars_never_overlap():
    for text in STOP_PHRASES + GOODBYE_PHRASES + NEITHER_PHRASES:
        assert not (is_voice_stop_phrase(text) and is_voice_goodbye_phrase(text)), text


# ---------------------------------------------------------------------------
# 4. Local grammar honours the same split
# ---------------------------------------------------------------------------

def test_local_grammar_stop_only_flushes():
    assert parse_local("stop") == {"tool": "stop_output", "args": {}}
    assert parse_local("be quiet") == {"tool": "stop_output", "args": {}}


def test_local_grammar_goodbye_ends_session():
    assert parse_local("goodbye") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("goodbye jarvis") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("stop listening") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("go to sleep") == {"tool": "end_voice_session", "args": {}}


def test_local_grammar_named_stop_not_session():
    cmd = parse_local("stop the music")
    assert cmd is not None
    assert cmd["tool"] not in ("stop_output", "end_voice_session")


# ---------------------------------------------------------------------------
# 5. stop_speaking interrupts only; end_voice_session ends (Gemini/OpenAI)
# ---------------------------------------------------------------------------

def _live_session_common():
    return dict(
        api_key="k",
        model="models/test-live",
        system_prompt="p",
        tool_declarations=[],
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
    )


class _RecordingSocket:
    def __init__(self, messages):
        self.sent = []
        self.closed = None
        self._messages = iter(messages)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self._messages)
        except StopIteration:
            raise StopAsyncIteration

    async def send(self, raw):
        self.sent.append(json.loads(raw))

    async def close(self, code=1000, reason=""):
        self.closed = (code, reason)


async def test_gemini_stop_speaking_keeps_session_alive():
    from integrations.gemini.live_client import LiveSession

    async def stop_handler(call_id, name, args):
        return {"stopped": True}

    session = LiveSession(tool_handler=stop_handler, **_live_session_common())
    socket = _RecordingSocket([
        json.dumps({"toolCall": {"functionCalls": [
            {"id": "s1", "name": "stop_speaking", "args": {}}
        ]}}),
    ])
    # Receiver runs to natural end-of-stream (no close on stop_speaking).
    reason = await session._receiver(socket)
    assert socket.closed is None, "stop_speaking must not close the session"
    assert reason != "stopped"
    # The tool response was still acknowledged.
    assert socket.sent[0]["toolResponse"]["functionResponses"][0]["name"] == "stop_speaking"


async def test_gemini_end_voice_session_closes():
    from integrations.gemini.live_client import LiveSession

    async def end_handler(call_id, name, args):
        return {"stopped": True, "session_ended": True}

    session = LiveSession(tool_handler=end_handler, **_live_session_common())
    socket = _RecordingSocket([
        json.dumps({"toolCall": {"functionCalls": [
            {"id": "e1", "name": "end_voice_session", "args": {}}
        ]}}),
    ])
    assert await session._receiver(socket) == "stopped"
    assert socket.closed == (1000, "stopped")


async def test_openai_stop_speaking_keeps_session_alive():
    from integrations.openai_rt.live_client import RealtimeSession

    async def stop_handler(call_id, name, args):
        return {"stopped": True}

    session = RealtimeSession(
        api_key="k", model="gpt-realtime", system_prompt="p",
        tool_declarations=[], tool_handler=stop_handler,
        audio_in=asyncio.Queue(), audio_out=asyncio.Queue(),
    )
    socket = _RecordingSocket([
        json.dumps({
            "type": "response.function_call_arguments.done",
            "call_id": "s1", "name": "stop_speaking", "arguments": "{}",
        }),
    ])
    reason = await session._receiver(socket)
    assert socket.closed is None, "stop_speaking must not close the session"
    assert reason != "stopped"
    # It acknowledged the tool and asked for a fresh response, staying alive.
    kinds = [m.get("type") for m in socket.sent]
    assert "function_call_output" in [
        m.get("item", {}).get("type") for m in socket.sent
    ]
    assert "response.create" in kinds


async def test_openai_end_voice_session_closes():
    from integrations.openai_rt.live_client import RealtimeSession

    async def end_handler(call_id, name, args):
        return {"stopped": True, "session_ended": True}

    session = RealtimeSession(
        api_key="k", model="gpt-realtime", system_prompt="p",
        tool_declarations=[], tool_handler=end_handler,
        audio_in=asyncio.Queue(), audio_out=asyncio.Queue(),
    )
    socket = _RecordingSocket([
        json.dumps({
            "type": "response.function_call_arguments.done",
            "call_id": "e1", "name": "end_voice_session", "arguments": "{}",
        }),
    ])
    assert await session._receiver(socket) == "stopped"
    assert socket.closed == (1000, "stopped")


# ---------------------------------------------------------------------------
# 6. Relay behaviour: goodbye ends, stop keeps listening
# ---------------------------------------------------------------------------

_LOUD = b"\x88\x13" * 1280    # RMS ~5000
_QUIET = b"\x00" * 2560       # digital silence


def _relay_session(settings, db, bus, handler, transcript):
    from apps.live_gateway.relay_session import RelayVoiceSession

    class FakeClient:
        def __init__(self):
            self.transcribe_calls = 0

        async def health(self):
            return None

        async def transcribe(self, pcm):
            # First captured utterance is the phrase under test; after that,
            # silence (so the loop idles out).
            self.transcribe_calls += 1
            return transcript if self.transcribe_calls == 1 else ""

        async def ask(self, *a, **k):
            return {"reply": "ok", "tool_calls": [], "usage": {}}

        async def speak(self, text, voice):
            return b"\x07\x00" * 2400, 24000

    settings.inactivity_timeout_seconds = 1
    client = FakeClient()
    session = RelayVoiceSession(
        client, settings, db, bus, StateMachine(bus), [], handler,
        asyncio.Queue(), asyncio.Queue(maxsize=256),
    )
    return session, client


def _speak_then_silence(audio_in):
    for _ in range(10):
        audio_in.put_nowait(_LOUD)
    for _ in range(12):
        audio_in.put_nowait(_QUIET)


async def test_relay_goodbye_ends_session(settings, db, bus):
    calls = []

    async def handler(call_id, name, args):
        calls.append(name)
        if name == "end_voice_session":
            return {"stopped": True, "session_ended": True}
        return {}

    session, client = _relay_session(settings, db, bus, handler, "goodbye")
    _speak_then_silence(session.audio_in)
    reason = await asyncio.wait_for(session.run(), timeout=3.0)
    assert reason == "stopped"
    assert "end_voice_session" in calls


async def test_relay_stop_keeps_listening(settings, db, bus):
    calls = []

    async def handler(call_id, name, args):
        calls.append(name)
        return {"stopped": True}

    session, client = _relay_session(settings, db, bus, handler, "stop")
    _speak_then_silence(session.audio_in)
    # After the stop turn, the loop keeps listening and idles out (inactivity),
    # which proves stop did NOT end the conversation.
    reason = await asyncio.wait_for(session.run(), timeout=4.0)
    assert "stop_speaking" in calls
    assert "end_voice_session" not in calls
    # Ended by inactivity, not by the stop phrase.
    assert reason == "inactivity"


# ---------------------------------------------------------------------------
# 7. Remote Voice Controller transport preservation (new /ws/remote-voice)
# ---------------------------------------------------------------------------

from tests.remote_voice_helpers import (
    build_runtime,
    finish,
    make_sessions,
    ready_socket,
    start_conversation_via_socket,
)


async def test_stop_preserves_remote_socket_and_lease(settings, db, store, bus):
    """Stop (flush output) must NOT revoke the lease, end the conversation,
    or close the socket — it only silences the current reply."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    gen = svc.gateway.voice_session_generation
    end_gen_before = svc.lease.end_generation

    ws.feed_text({"type": "stop"})
    await ws.wait_for("clear")

    assert not ws.closed.is_set(), "Stop must keep the WebSocket open"
    assert svc.lease is not None
    assert svc.gateway.session_intent_active is True
    assert svc.gateway.voice_session_generation == gen
    assert svc.lease.end_generation == end_gen_before  # conversation not ended
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_goodbye_keeps_remote_socket_open(settings, db, store, bus):
    """Goodbye ends the provider session but keeps the socket + lease so the
    user can say Hey Jarvis (or press Start) again without reconnecting."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    gen = svc.gateway.voice_session_generation

    ws.feed_text({"type": "end"})
    await asyncio.sleep(0.1)

    assert not ws.closed.is_set(), "Socket must stay open after goodbye"
    assert svc.lease is not None
    assert not svc.gateway.session_intent_active

    # A fresh Start on the SAME socket begins a new conversation.
    ws.feed_text({"type": "start"})
    await asyncio.sleep(0.05)
    assert svc.gateway.voice_session_generation > gen
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


# ---------------------------------------------------------------------------
# 8. Voice controller UI contract (static)
# ---------------------------------------------------------------------------

from pathlib import Path

_STATIC = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "static"
_TEMPLATES = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "templates"


def test_controller_has_goodbye_button():
    html = (_TEMPLATES / "voice_controller.html").read_text()
    assert "vc-goodbye" in html
    js = (_STATIC / "voice_controller.js").read_text()
    assert "vc-goodbye" in js


def test_controller_stop_sends_stop_without_closing():
    """The Stop handler speaks the socket protocol; it never closes the
    transport or falls back to legacy host endpoints."""
    js = (_STATIC / "voice_controller.js").read_text()
    idx = js.index("els.stop.addEventListener")
    end = js.index("els.goodbye.addEventListener")
    stop_block = js[idx:end]
    assert '{ type: "stop" }' in stop_block
    assert "ws.close" not in stop_block
    assert "/api/stop" not in stop_block


def test_controller_goodbye_sends_end():
    js = (_STATIC / "voice_controller.js").read_text()
    idx = js.index("els.goodbye.addEventListener")
    goodbye_block = js[idx:idx + 600]
    assert '{ type: "end" }' in goodbye_block
    assert "/api/session/end" not in goodbye_block


def test_controller_no_legacy_host_session_endpoints():
    """The rebuilt controller must not drive the HOST session endpoints; its
    conversation lives on the dedicated remote stack."""
    js = (_STATIC / "voice_controller.js").read_text()
    for legacy in ("/ws/remote-audio", "/api/wake", "/api/session/end", "4410"):
        assert legacy not in js, f"legacy reference {legacy!r} must be gone"
    html = (_TEMPLATES / "voice_controller.html").read_text()
    assert "/api/wake" not in html


def test_controller_copy_explains_takeover_and_busy():
    """Busy and revoked states must tell the user WHICH device has voice and
    offer the takeover path — never a silent failure."""
    js = (_STATIC / "voice_controller.js").read_text()
    idx = js.index('case "busy"')
    busy_block = js[idx:idx + 500]
    assert "Another device" in busy_block
    assert '"revoked"' in js          # revoked message handler exists
    assert "Taken over" in js         # visible phase label
    assert "4409" in js and "4412" in js  # both close codes handled
