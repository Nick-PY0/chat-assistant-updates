from __future__ import annotations

import asyncio
import base64
import json
import time

import pytest

from integrations.gemini.live_client import LiveSession


def make_session(pause=1600):
    return LiveSession(
        api_key="test-key",
        model="models/test-live",
        system_prompt="be helpful",
        tool_declarations=[],
        tool_handler=lambda *_: None,
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        speech_pause_ms=pause,
    )


def test_setup_uses_patient_activity_detection():
    setup = make_session(1700)._setup_message()["setup"]
    vad = setup["realtimeInputConfig"]["automaticActivityDetection"]
    assert vad["endOfSpeechSensitivity"] == "END_SENSITIVITY_LOW"
    assert vad["silenceDurationMs"] == 1700
    assert vad["prefixPaddingMs"] == 300
    assert setup["contextWindowCompression"] == {"slidingWindow": {}}
    assert setup["sessionResumption"] == {}


async def test_sender_uses_current_audio_field_not_deprecated_media_chunks():
    session = make_session()
    await session.audio_in.put(b"\x01\x00" * 1280)

    class FakeSocket:
        def __init__(self):
            self.messages = []

        async def send(self, raw):
            self.messages.append(json.loads(raw))
            session._closing.set()

        async def close(self, *args, **kwargs):
            pass

    socket = FakeSocket()
    await session._sender(socket)
    realtime = socket.messages[0]["realtimeInput"]
    assert "mediaChunks" not in realtime
    assert realtime["audio"]["mimeType"] == "audio/pcm;rate=16000"
    assert realtime["audio"]["data"]


async def test_inactivity_close_reason_survives_receiver_shutdown():
    session = make_session()
    session._close_reason = "inactivity"

    class ClosedSocket:
        def __aiter__(self):
            return self

        async def __anext__(self):
            raise StopAsyncIteration

    assert await session._receiver(ClosedSocket()) == "inactivity"


async def test_end_voice_tool_acknowledges_then_closes_session():
    async def end_handler(call_id, name, args):
        return {"stopped": True, "session_ended": True}

    session = make_session()
    session.tool_handler = end_handler

    class ToolSocket:
        def __init__(self):
            self.sent = []
            self.closed = None
            self._messages = iter([json.dumps({
                "toolCall": {"functionCalls": [{
                    "id": "end-1", "name": "end_voice_session", "args": {},
                }]},
            })])

        def __aiter__(self):
            return self

        async def __anext__(self):
            try:
                return next(self._messages)
            except StopIteration:
                raise StopAsyncIteration

        async def send(self, raw):
            self.sent.append(json.loads(raw))

        async def close(self, code=1000, reason=""):
            self.closed = (code, reason)

    socket = ToolSocket()
    assert await session._receiver(socket) == "stopped"
    assert socket.sent[0]["toolResponse"]["functionResponses"][0]["id"] == "end-1"
    assert socket.closed == (1000, "stopped")


def test_initial_idle_is_carried_across_provider_reconnects():
    session = LiveSession(
        api_key="test-key",
        model="models/test-live",
        system_prompt="be helpful",
        tool_declarations=[],
        tool_handler=lambda *_: None,
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        initial_idle_seconds=25,
    )
    assert time.monotonic() - session._last_activity >= 25


@pytest.mark.parametrize(
    "completion",
    [
        {"serverContent": {"interrupted": True}},
        {"serverContent": {"turnComplete": True}},
    ],
    ids=["interrupted", "turn-complete"],
)
async def test_local_barge_in_drops_delayed_model_audio_until_completion(completion):
    """Late audio from the interrupted turn must not re-start local playback."""
    session = make_session()
    queued_before_interrupt = b"already queued"
    delayed_model_audio = b"late old turn"
    next_turn_audio = b"new turn"
    await session.audio_out.put(queued_before_interrupt)
    session.interrupt_locally()

    speaking_changes = []
    session.on_speaking_change = speaking_changes.append

    def model_audio(pcm: bytes) -> str:
        return json.dumps(
            {
                "serverContent": {
                    "modelTurn": {
                        "parts": [
                            {
                                "inlineData": {
                                    "mimeType": "audio/pcm;rate=24000",
                                    "data": base64.b64encode(pcm).decode(),
                                }
                            }
                        ]
                    }
                }
            }
        )

    class Messages:
        def __init__(self):
            self._messages = iter(
                [model_audio(delayed_model_audio), json.dumps(completion), model_audio(next_turn_audio)]
            )

        def __aiter__(self):
            return self

        async def __anext__(self):
            try:
                return next(self._messages)
            except StopIteration:
                raise StopAsyncIteration

    await session._receiver(Messages())

    # interrupt_locally drains existing output, and the late old-turn audio
    # neither reaches playback nor produces a transient speaking=True.
    assert await session.audio_out.get() == next_turn_audio
    assert session.audio_out.empty()
    assert speaking_changes == [True]
