from __future__ import annotations

import json

import pytest

from chat_core.models.db import Database
from chat_core.models.music import MusicStore, StaleMusicSessionError
from chat_core.security.vault import Vault


pytestmark = pytest.mark.asyncio


async def test_rooms_default_resolution_and_persistence(settings, vault):
    db = Database(settings.db_path)
    await db.open()
    store = MusicStore(db, vault)
    default = await store.ensure_default_room("Everywhere")
    kitchen = await store.create_room("Kitchen")
    assert (await store.resolve_room())["id"] == default["id"]
    assert (await store.resolve_room("kItChEn"))["id"] == kitchen["id"]
    await store.set_default_room(kitchen["id"])
    with pytest.raises(ValueError, match="default"):
        await store.delete_room(kitchen["id"])
    await db.close()

    reopened = Database(settings.db_path)
    await reopened.open()
    restored = MusicStore(reopened, vault)
    assert (await restored.resolve_room())["name"] == "Kitchen"
    assert {room["name"] for room in await restored.list_rooms()} == {
        "Everywhere", "Kitchen"
    }
    await restored.delete_room(default["id"])
    assert [room["name"] for room in await restored.list_rooms()] == ["Kitchen"]
    await reopened.close()


async def test_items_queue_favorites_and_playlists(db, vault):
    store = MusicStore(db, vault)
    room = await store.ensure_default_room()
    first = await store.upsert_item(
        "one", title="Northern Sky", artist="Nick Drake",
        metadata={"genres": ["folk"], "disc": 1})
    second = await store.upsert_item(
        "two", title="Pink Moon", artist="Nick Drake", duration_ms=129000)
    await store.upsert_item("one", title="Northern Sky", artist="Nick Drake",
                            metadata={"genres": ["folk"]})
    assert (await store.get_item("one"))["created_at"] == first["created_at"]
    assert [item["id"] for item in await store.search_items("drake")] == ["one", "two"]

    assert [item["id"] for item in
            await store.replace_queue(room["id"], ["one"])] == ["one"]
    assert [item["id"] for item in
            await store.append_queue(room["id"], [second])] == ["one", "two"]
    assert [item["id"] for item in
            await store.remove_queue(room["id"], 0)] == ["two"]
    await store.clear_queue(room["id"])
    assert await store.list_queue(room["id"]) == []

    await store.favorite(room["id"], "one")
    await store.favorite(room["id"], "one")
    assert [item["id"] for item in await store.list_favorites(room["id"])] == ["one"]
    await store.unfavorite(room["id"], "one")
    assert await store.list_favorites(room["id"]) == []

    playlist = await store.create_playlist(room["id"], "Quiet", "Late night")
    await store.replace_playlist_items(playlist["id"], ["one"])
    await store.append_playlist_items(playlist["id"], ["two"])
    loaded = await store.get_playlist(playlist["id"])
    assert loaded["item_count"] == 2
    assert [item["id"] for item in loaded["items"]] == ["one", "two"]
    await store.update_playlist(playlist["id"], name="Very Quiet")
    assert (await store.list_playlists(room["id"]))[0]["name"] == "Very Quiet"
    assert [item["id"] for item in
            await store.remove_playlist_item(playlist["id"], 0)] == ["two"]
    await store.delete_playlist(playlist["id"])
    assert await store.list_playlists(room["id"]) == []


async def test_encrypted_targets_and_local_library_never_leak(settings, vault):
    db = Database(settings.db_path)
    await db.open()
    store = MusicStore(db, vault)
    room = await store.ensure_default_room()
    item = await store.upsert_item("local-1", title="Private Song")

    public_target = await store.set_target_mapping(
        room["id"], "spotify", "speaker-secret-identifier", "Living speaker")
    assert "target_id" not in public_target
    assert "speaker-secret-identifier" not in json.dumps(public_target)
    assert await store.decrypt_target_id(room["id"], "spotify") == \
        "speaker-secret-identifier"

    root = await store.create_local_root("/home/alice/Secret Music", "My files")
    tracks = await store.replace_local_tracks(root["id"], [{
        "item_id": item["id"],
        "path": "private/recording.flac",
        "metadata": {"codec": "flac", "note": "private-note"},
    }])
    assert "/home/alice" not in json.dumps(root)
    assert "path" not in tracks[0]
    assert "metadata" not in tracks[0]
    internal = await store.decrypt_local_track_metadata(
        root["id"], tracks[0]["track_ref"])
    assert internal == {
        "codec": "flac", "note": "private-note",
        "path": "private/recording.flac",
    }

    raw_target = await db.fetchone(
        "SELECT encrypted_target_id FROM music_room_targets")
    raw_root = await db.fetchone("SELECT encrypted_path FROM music_local_roots")
    raw_track = await db.fetchone(
        "SELECT encrypted_metadata FROM music_local_tracks")
    for secret, blob in [
        (b"speaker-secret-identifier", raw_target["encrypted_target_id"]),
        (b"/home/alice/Secret Music", raw_root["encrypted_path"]),
        (b"private-note", raw_track["encrypted_metadata"]),
    ]:
        assert secret not in bytes(blob)

    await db.close()
    reopened = Database(settings.db_path)
    await reopened.open()
    persisted = MusicStore(reopened, vault)
    assert await persisted.decrypt_target_id(room["id"], "spotify") == \
        "speaker-secret-identifier"
    assert (await persisted.list_local_roots())[0]["label"] == "My files"
    restored_tracks = await persisted.list_local_tracks(root["id"])
    assert restored_tracks[0]["item_id"] == "local-1"
    assert await persisted.decrypt_local_root_path(root["id"]) == \
        "/home/alice/Secret Music"
    await reopened.close()


async def test_session_and_operation_fencing(db, vault):
    store = MusicStore(db, vault)
    room = await store.ensure_default_room()
    started = await store.begin_session(
        room["id"], "session-a", "operation-1", {"status": "starting"})
    assert started["state"]["status"] == "starting"

    updated = await store.update_session(
        room["id"], "session-a", "operation-1",
        operation_id="operation-2", state={"status": "playing"})
    assert updated is not None
    assert updated["operation_id"] == "operation-2"

    with pytest.raises(StaleMusicSessionError):
        await store.update_session(
            room["id"], "session-a", "operation-1", state={"status": "stale"})
    with pytest.raises(StaleMusicSessionError):
        await store.update_session(
            room["id"], "wrong-session", "operation-2", state={})
    assert (await store.get_active_session(room["id"]))["state"] == {
        "status": "playing"
    }
    assert await store.update_session(
        room["id"], "session-a", "operation-2", active=False) is None
    assert await store.get_active_session(room["id"]) is None


async def test_safe_json_and_collection_bounds(db, vault):
    store = MusicStore(db, vault)
    room = await store.ensure_default_room()
    with pytest.raises(ValueError, match="safe JSON"):
        await store.upsert_item("bad", title="Bad", metadata={"value": float("nan")})
    item = await store.upsert_item("bounded", title="Bounded")
    with pytest.raises(ValueError, match="queue is too large"):
        await store.replace_queue(room["id"], [item["id"]] * 501)