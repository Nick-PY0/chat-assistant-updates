"""Unit tests for PlaybackAwareMicGate.set_assistant_playing.

The WebSocket-level playback gating contract (client "playback" reports over
/ws/remote-voice) is covered in tests/test_remote_voice_socket.py; this file
keeps the pure mic-gate unit coverage:

  1. playing=true arms the gate (frames withheld while Chat speaks).
  2. playing=false releases the gate after the settling tail.
  3. Loud user speech opens the gate even during the settling tail (barge-in).
  4. Media and assistant playback combine without interfering.
"""

from __future__ import annotations

import time

from apps.audio.mic_gate import PlaybackAwareMicGate


# ---------------------------------------------------------------------------
# Unit tests for PlaybackAwareMicGate.set_assistant_playing
# ---------------------------------------------------------------------------

def pcm(level: int, seconds: float = 0.08) -> bytes:
    import array
    return array.array("h", [level] * int(16_000 * seconds)).tobytes()


class TestAssistantPlaybackGate:
    """Unit tests for the new set_assistant_playing path."""

    def test_passthrough_when_nothing_playing(self):
        gate = PlaybackAwareMicGate(700)
        frame = pcm(100)
        assert gate.feed(frame) == (frame,)

    def test_gate_armed_when_assistant_playing(self):
        """While assistant is playing, mic input is gated like media playback."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        assert gate.assistant_playing is True
        # Low-level residue must be withheld.
        assert gate.feed(pcm(100)) == ()

    def test_no_duplicate_state_change_on_same_value(self):
        """Calling set_assistant_playing with the same value twice does not
        reset the learned noise floor."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        # Feed some audio to build calibration
        for _ in range(5):
            gate.feed(pcm(300))
        floor_before = gate._noise_floor

        gate.set_assistant_playing(True)  # same value — should be no-op
        assert gate._noise_floor == floor_before

    def test_settling_tail_suppresses_immediately_after_false(self):
        """After assistant playing → false, frames are still gated during the
        settling tail (reverb window)."""
        gate = PlaybackAwareMicGate(700, assistant_settle_seconds=0.4)
        gate.set_assistant_playing(True)
        # Feed calibration during playback.
        for _ in range(5):
            gate.feed(pcm(200))
        # Stop playback.
        gate.set_assistant_playing(False)
        # Immediately after stopping, the settling tail should still gate.
        assert gate._in_settling_tail is True
        assert gate.feed(pcm(200)) == ()

    def test_settling_tail_expires_and_gate_opens(self):
        """After the settling tail expires, frames pass through normally."""
        gate = PlaybackAwareMicGate(700, assistant_settle_seconds=0.001)
        gate.set_assistant_playing(True)
        gate.set_assistant_playing(False)
        # Wait for settling tail to expire.
        time.sleep(0.05)
        frame = pcm(100)
        assert gate.feed(frame) == (frame,)

    def test_loud_speech_during_settling_tail_can_open_gate(self):
        """Even within the settling tail, clearly loud speech can open the
        gate once the onset threshold is met (barge-in path)."""
        gate = PlaybackAwareMicGate(700, calibration_seconds=0, assistant_settle_seconds=2.0)
        gate.set_assistant_playing(True)
        gate.set_assistant_playing(False)
        assert gate._in_settling_tail is True

        # Push very loud audio: should satisfy onset threshold
        very_loud = pcm(20_000)
        # Feed multiple frames to clear onset_seconds requirement.
        result = []
        for _ in range(5):
            result.extend(gate.feed(very_loud))

        assert gate.is_open, "Barge-in: gate must open for clearly loud speech in settling tail"

    def test_assistant_and_media_combined(self):
        """Both assistant and media playing combine correctly: gate stays
        armed while either is active."""
        gate = PlaybackAwareMicGate(700)
        gate.set_media_playing(True)
        gate.set_assistant_playing(True)

        # Gate is armed — residue withheld.
        assert gate.feed(pcm(100)) == ()

        # Media stops, but assistant still playing.
        gate.set_media_playing(False)
        assert gate.assistant_playing is True
        # Gate must still be armed.
        assert gate.feed(pcm(100)) == ()

    def test_assistant_stops_resets_utterance_not_noise_floor(self):
        """set_assistant_playing(False) closes the utterance window but
        does NOT wipe the learned noise floor (unlike set_media_playing)."""
        gate = PlaybackAwareMicGate(700)
        gate.set_assistant_playing(True)
        # Feed enough to build noise floor.
        for _ in range(10):
            gate.feed(pcm(1_500))
        floor_before = gate._noise_floor

        # Open the gate by feeding loud speech.
        for _ in range(5):
            gate.feed(pcm(8_000))
        assert gate.is_open

        gate.set_assistant_playing(False)
        # Utterance must be closed.
        assert not gate.is_open
        # Noise floor should be retained (not None).
        assert gate._noise_floor is not None
