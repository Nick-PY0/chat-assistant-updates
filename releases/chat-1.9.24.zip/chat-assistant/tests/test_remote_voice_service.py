"""RemoteVoiceService unit tests: ownership, conversation control, isolation.

The remote device owns a DEDICATED provider stack (private gateway + state
machine).  Nothing here may touch the host gateway's session or audio route —
that isolation is the core contract of the rebuild.
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import pytest

import apps.live_gateway.remote_voice as rv_mod
from apps.live_gateway.remote_voice import (
    DOWN_HEADER,
    DOWN_MAGIC,
    KIND_ANNOUNCE,
    KIND_VOICE,
)
from chat_core.models.state import ChatState
from chat_core.runtime import Runtime

from tests.remote_voice_helpers import build_runtime


class Sink:
    """Recording binding target."""

    def __init__(self) -> None:
        self.texts: list[dict] = []
        self.audio: list[bytes] = []
        self.closes: list[tuple[int, str]] = []

    def enqueue_text(self, payload: str) -> None:
        self.texts.append(json.loads(payload))

    def enqueue_audio(self, payload: bytes) -> None:
        self.audio.append(payload)

    def close(self, code: int, reason: str) -> None:
        self.closes.append((code, reason))


def bind(svc, lease) -> Sink:
    sink = Sink()
    binding = svc.bind(
        lease,
        enqueue_text=sink.enqueue_text,
        enqueue_audio=sink.enqueue_audio,
        close=sink.close,
    )
    assert binding is not None
    sink.binding = binding
    return sink


# ---------------------------------------------------------------------------
# ownership: claim / resume / takeover / grace
# ---------------------------------------------------------------------------

async def test_claim_grants_fresh_lease(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    status, lease = svc.claim("Pixel 9")
    assert status == "granted"
    assert lease.epoch == 1
    assert len(lease.resume_secret) == 32
    assert svc.lease is lease
    assert svc.diagnostics()["active"] is True


async def test_second_claim_is_busy_with_holder_info(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    status, holder = svc.claim("iPad")
    assert status == "busy"
    assert holder["device"] == "Pixel 9"
    assert holder["connected"] is True
    assert svc.lease is lease  # unchanged


async def test_takeover_revokes_old_binding_and_grants_new_epoch(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, old = svc.claim("Pixel 9")
    sink = bind(svc, old)
    # Old device is mid-conversation.
    await svc.start_conversation(old)
    assert svc.gateway.session_intent_active

    status, new = svc.claim("iPad", takeover=True)
    assert status == "granted"
    assert new.epoch == old.epoch + 1
    assert svc.lease is new
    # Old socket got a revoked notice and a 4412 close.
    assert any(t.get("type") == "revoked" for t in sink.texts)
    assert sink.closes and sink.closes[0][0] == 4412
    # The old conversation ended SYNCHRONOUSLY (no window for the new
    # device to join the previous device's session).
    assert not svc.gateway.session_intent_active
    await asyncio.sleep(0.05)  # let the background end_session settle


async def test_resume_within_grace_keeps_epoch(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await svc.start_conversation(lease)
    svc.detach(lease, sink.binding)         # transport dropped mid-conversation
    assert svc.lease is lease
    assert lease.connected is False
    assert svc.conversation_active          # grace window keeps the claim

    status, back = svc.claim(
        "Pixel 9", resume_epoch=lease.epoch, resume_secret=lease.resume_secret
    )
    assert status == "resumed"
    assert back is lease
    assert back.stats["reconnects"] == 1
    svc.end_conversation(lease, "test cleanup")
    await asyncio.sleep(0.05)


async def test_resume_with_wrong_secret_is_busy(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await svc.start_conversation(lease)
    svc.detach(lease, sink.binding)

    status, _ = svc.claim(
        "Evil twin", resume_epoch=lease.epoch, resume_secret="0" * 32
    )
    assert status == "busy"
    svc.end_conversation(lease, "test cleanup")
    await asyncio.sleep(0.05)


async def test_grace_expiry_releases_lease(settings, db, store, bus, monkeypatch):
    monkeypatch.setattr(rv_mod, "GRACE_SECONDS", 0.05)
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await svc.start_conversation(lease)
    svc.detach(lease, sink.binding)
    assert svc.lease is lease
    await asyncio.sleep(0.2)
    assert svc.lease is None
    assert not svc.gateway.session_intent_active
    await asyncio.sleep(0.05)


async def test_detach_without_conversation_releases_immediately(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    svc.detach(lease, sink.binding)
    assert svc.lease is None


async def test_stale_binding_cannot_detach_replacement(settings, db, store, bus):
    """A revoked socket's finally-block detach must not unbind the new owner."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, old = svc.claim("Pixel 9")
    old_sink = bind(svc, old)

    _, new = svc.claim("iPad", takeover=True)
    new_sink = bind(svc, new)

    # The old socket's cleanup fires late, with ITS OWN (stale) lease+binding.
    svc.detach(old, old_sink.binding)
    assert svc.lease is new
    # And even a stale binding with the CURRENT lease must be ignored.
    svc.detach(new, old_sink.binding)
    assert svc.lease is new
    assert new.connected is True

    svc.detach(new, new_sink.binding)
    assert svc.lease is None


async def test_release_notifies_and_closes_bound_socket(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    svc.release(lease, "shutdown")
    assert svc.lease is None
    assert any(t.get("type") == "revoked" for t in sink.texts)
    assert sink.closes and sink.closes[0][0] == 4412
    await asyncio.sleep(0.05)  # background db log


async def test_bind_marks_wake_model_exclusive(settings, db, store, bus):
    audio = SimpleNamespace(remote_mic_active=False)
    rt = build_runtime(settings, db, store, bus, audio=audio)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    assert audio.remote_mic_active is True
    svc.detach(lease, sink.binding)
    assert audio.remote_mic_active is False


# ---------------------------------------------------------------------------
# conversation control and host isolation
# ---------------------------------------------------------------------------

async def test_start_conversation_uses_private_gateway_only(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    result = await svc.start_conversation(lease)
    assert result == "started"
    assert svc.gateway.session_intent_active
    # The HOST gateway must be completely untouched.
    assert not rt.gateway.session_intent_active
    assert rt.gateway.voice_session_generation == 0
    # Second start is idempotent.
    assert await svc.start_conversation(lease) == "already"
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


async def test_start_conversation_blocked_by_global_mute(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    rt.state.set_muted(True)
    _, lease = svc.claim("Pixel 9")
    assert await svc.start_conversation(lease) == "muted"
    assert not svc.gateway.session_intent_active


async def test_start_conversation_respects_host_session(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    rt.gateway.request_session()  # host desk conversation is live
    _, lease = svc.claim("Pixel 9")
    assert await svc.start_conversation(lease) == "busy_host"
    assert not svc.gateway.session_intent_active


async def test_start_conversation_takeover_host_ends_host_session(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    rt.gateway.request_session()
    _, lease = svc.claim("Pixel 9")
    result = await svc.start_conversation(lease, takeover_host=True)
    assert result == "started"
    assert not rt.gateway.session_intent_active   # host ended
    assert svc.gateway.session_intent_active      # remote started
    assert rt.stop_calls == 1                     # host speakers silenced
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


async def test_stale_lease_cannot_start(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, old = svc.claim("Pixel 9")
    svc.claim("iPad", takeover=True)
    assert await svc.start_conversation(old) == "stale"


async def test_end_conversation_fences_synchronously(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)
    end_gen_before = svc.gateway.voice_end_generation

    svc.end_conversation(lease, "goodbye")
    # Fence must be visible IMMEDIATELY (callers re-read it on return).
    assert not svc.gateway.session_intent_active
    assert svc.gateway.voice_end_generation > end_gen_before
    # Lease + service survive: the device returns to wake mode.
    assert svc.lease is lease
    await asyncio.sleep(0.05)


async def test_interrupt_playback_bumps_turn_and_sends_clear(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    svc.gateway.audio_out.put_nowait(b"\x00" * 480)  # stale reply audio
    turn_before = svc.current_turn

    svc.interrupt_playback("barge-in")
    assert svc.current_turn != turn_before
    assert svc.gateway.audio_out.empty()
    clears = [t for t in sink.texts if t.get("type") == "clear"]
    assert clears and clears[-1]["turn"] == svc.current_turn
    assert lease.stats["clears"] == 1


async def test_accepted_utterance_emits_one_owner_cue_and_bounded_trace(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await svc.start_conversation(lease)

    assert svc.accept_utterance(lease) is True
    cues = [t for t in sink.texts if t.get("type") == "utterance_accepted"]
    assert len(cues) == 1
    assert cues[0]["epoch"] == lease.epoch
    assert cues[0]["turn"] == svc.current_turn
    assert svc.diagnostics()["timing_trace"][-1]["event"] == "utterance_accepted"
    for i in range(80):
        svc._record_trace("tool_call", lease=lease, tool=f"tool-{i}")
    assert len(svc.diagnostics()["timing_trace"]) == 64
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


async def test_accepted_utterance_is_server_idempotent_until_safe_boundary(
    settings, db, store, bus
):
    """A local gate pause/resume is not a second provider utterance."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await svc.start_conversation(lease)

    assert svc.accept_utterance(lease, sink.binding) is True
    # Models the socket's ~560 ms quiet hysteresis closing then reopening.
    await asyncio.sleep(0.56)
    assert svc.accept_utterance(lease, sink.binding) is False
    svc.record_playback(lease, False, sink.binding)  # pause is not a boundary
    assert svc.accept_utterance(lease, sink.binding) is False

    # Actual response playback safely retires the in-flight utterance.
    svc.record_playback(lease, True, sink.binding)
    svc.record_playback(lease, False, sink.binding)
    assert svc.accept_utterance(lease, sink.binding) is True
    assert sum(t.get("type") == "utterance_accepted" for t in sink.texts) == 2
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


async def test_replaced_binding_cannot_mutate_current_conversation(
    settings, db, store, bus
):
    """Every direct ingress API using a socket authority checks identity."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    old = bind(svc, lease)
    new = bind(svc, lease)  # reconnect replacement on the same epoch
    await svc.start_conversation(lease, binding=new.binding)
    turn = svc.current_turn

    assert await svc.start_conversation(lease, binding=old.binding) == "stale"
    svc.end_conversation(lease, "stale goodbye", binding=old.binding)
    assert svc.gateway.session_intent_active
    assert not svc.accept_utterance(lease, old.binding)
    svc.record_playback(lease, True, old.binding)
    assert svc.current_turn == turn
    assert not any(t.get("type") == "utterance_accepted" for t in old.texts)

    svc.end_conversation(lease, "cleanup", binding=new.binding)
    await asyncio.sleep(0.05)


# ---------------------------------------------------------------------------
# downstream framing
# ---------------------------------------------------------------------------

async def test_voice_frames_are_turn_and_seq_stamped(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)

    svc._send_audio(b"\x01\x02" * 240, KIND_VOICE)
    svc._send_audio(b"\x03\x04" * 240, KIND_VOICE)
    assert len(sink.audio) == 2
    magic, version, kind, turn, _rsvd, seq1 = DOWN_HEADER.unpack_from(sink.audio[0])
    assert (magic, version, kind) == (DOWN_MAGIC, 1, KIND_VOICE)
    assert turn == svc.current_turn
    *_, seq2 = DOWN_HEADER.unpack_from(sink.audio[1])
    assert seq2 == seq1 + 1
    assert lease.stats["frames_out"] == 2


async def test_host_conversation_audio_never_reaches_remote(
    settings, db, store, bus
):
    """The remote announce lane subscribes ONLY to the typed announce
    broadcast.  Host conversation speech (shared broadcast) must never be
    forwarded — not even tails queued while a host session winds down."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    pump = asyncio.create_task(svc._announce_pump())
    await asyncio.sleep(0.02)
    try:
        # Host speech on the SHARED broadcast: never forwarded, in any state.
        rt.gateway.request_session()
        rt.broadcast.publish(b"\x11\x22" * 240)
        rt.gateway.request_end_session("test")
        rt.broadcast.publish(b"\x33\x44" * 240)  # post-session tail
        await asyncio.sleep(0.05)
        assert sink.audio == []

        # Announcements PAUSE while the host is mid-conversation: withheld
        # (latest-wins), then delivered once the desk goes quiet.
        rt.gateway.request_session()
        rt.announce_broadcast.publish(b"\x55\x66" * 240)
        rt.announce_broadcast.publish(b"\x55\x66" * 240)  # fresher cycle
        await asyncio.sleep(0.05)
        assert sink.audio == [], "announcement must be withheld during host session"
        rt.gateway.request_end_session("desk done")
        await asyncio.sleep(0.4)                # pump re-checks every 0.25s
        assert len(sink.audio) == 1, "exactly the latest withheld cycle resumes"
        _, _, kind, _, _, _ = DOWN_HEADER.unpack_from(sink.audio[0])
        assert kind == KIND_ANNOUNCE

        # Dismissal during the pause: withheld audio must never replay, and
        # the announce-scoped clear reaches the device immediately.
        rt.gateway.request_session()
        rt.announce_broadcast.publish(b"\x77\x88" * 240)
        await asyncio.sleep(0.05)
        rt.announce_broadcast.clear()           # alarm dismissed at the desk
        await asyncio.sleep(0.05)
        assert any(
            t.get("type") == "clear" and t.get("scope") == "announce"
            for t in sink.texts
        )
        rt.gateway.request_end_session("desk done again")
        await asyncio.sleep(0.4)
        assert len(sink.audio) == 1, "dismissed alarm must never replay later"

        # Desk idle: announcements flow immediately.
        rt.announce_broadcast.publish(b"\x99\xaa" * 240)
        await asyncio.sleep(0.05)
        assert len(sink.audio) == 2
    finally:
        pump.cancel()
        await asyncio.gather(pump, return_exceptions=True)


async def test_stop_tool_dismisses_ring_but_never_touches_host(
    settings, db, store, bus
):
    """The stop/stop_speaking voice tool on a REMOTE session dismisses a
    ringing alarm (stop works anywhere) but must never invoke the global
    host stop — that would interrupt the desk conversation."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)
    rt.gateway.request_session()          # host mid-conversation

    out = await svc._dispatch_tools("c1", "stop_speaking", {})
    assert out == {"stopped": True}
    assert rt.ring_stops == 1, "alarm dismissal must fire"
    assert rt.stop_calls == 0, "global host stop must NOT fire"
    assert rt.gateway.session_intent_active, "host conversation untouched"

    out = await svc._dispatch_tools("c2", "end_voice_session", {})
    assert out["session_ended"] is True
    assert rt.ring_stops == 2
    assert rt.stop_calls == 0
    assert rt.gateway.session_intent_active


class _FakeProviderSession:
    """Stands in for a live provider socket that is slow to close."""

    def __init__(self, gateway) -> None:
        self._gateway = gateway
        self.closes = 0

    async def close(self, reason: str = "") -> None:
        self.closes += 1
        self._gateway._session = None  # what the real session task does

    def _drain_output(self) -> None:  # interrupt() drains the live session
        pass


async def test_spoken_goodbye_retires_provider_socket(settings, db, store, bus):
    """The end tool must not leave the old provider session hanging around
    after the phone has already returned to wake-listening mode."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)
    session = _FakeProviderSession(svc.gateway)
    svc.gateway._session = session

    out = await svc._dispatch_tools("goodbye", "end_voice_session", {})
    assert out["session_ended"] is True
    assert not svc.gateway.session_intent_active
    await asyncio.sleep(0.25)
    assert session.closes >= 1
    assert not svc.gateway.has_open_session


async def test_takeover_deferred_close_cannot_kill_new_conversation(
    settings, db, store, bus
):
    """Teardown schedules the provider close asynchronously.  A takeover that
    claims + starts BEFORE that task runs must keep its new conversation:
    the deferred close is generation-fenced and the new start flushes the
    dying session synchronously."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease_a = svc.claim("Pixel 9")
    bind(svc, lease_a)
    await svc.start_conversation(lease_a)
    old_session = _FakeProviderSession(svc.gateway)
    svc.gateway._session = old_session   # conversation A has a live socket

    # B takes over: _teardown_lease runs synchronously, deferred close queued.
    _, lease_b = svc.claim("iPad", takeover=True)
    bind(svc, lease_b)
    # B starts IMMEDIATELY — before the deferred end_session task runs.
    status = await svc.start_conversation(lease_b)
    assert status == "started"
    assert old_session.closes >= 1, "dying provider socket flushed before start"
    gen_b = svc.gateway.voice_session_generation
    assert svc.gateway.session_intent_active

    # Let every deferred fenced close run; B's conversation must survive.
    for _ in range(5):
        await asyncio.sleep(0.02)
    assert svc.gateway.session_intent_active, (
        "stale deferred close from A's teardown must not end B's conversation"
    )
    assert svc.gateway.voice_session_generation == gen_b
    svc.end_conversation(lease_b, "cleanup")
    await asyncio.sleep(0.05)


async def test_goodbye_then_instant_restart_survives_deferred_close(
    settings, db, store, bus
):
    """Goodbye → immediate new start on the SAME lease: the goodbye's
    background provider close must not kill the new conversation."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)
    session = _FakeProviderSession(svc.gateway)
    svc.gateway._session = session

    svc.end_conversation(lease, "goodbye")          # deferred close queued
    status = await svc.start_conversation(lease)     # user changed their mind
    assert status == "started"
    gen = svc.gateway.voice_session_generation

    for _ in range(5):
        await asyncio.sleep(0.02)
    assert svc.gateway.session_intent_active, (
        "goodbye's deferred close must not end the restarted conversation"
    )
    assert svc.gateway.voice_session_generation == gen
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


# ---------------------------------------------------------------------------
# host wake exclusion + shutdown
# ---------------------------------------------------------------------------

async def test_host_wake_ignored_while_remote_conversation_active(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)

    host = object.__new__(Runtime)     # behavior-only instance, no start()
    host.remote_voice = svc
    host.gateway = rt.gateway
    host.db = db
    host._on_host_wake()
    assert not rt.gateway.session_intent_active, (
        "host wake must not start a host session while the remote owns the "
        "conversation"
    )

    # After the remote conversation ends, the host wake works again.
    svc.end_conversation(lease, "goodbye")
    await asyncio.sleep(0.05)
    host._on_host_wake()
    assert rt.gateway.session_intent_active


async def test_service_stop_releases_lease_and_closes_socket(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    svc.start()
    _, lease = svc.claim("Pixel 9")
    sink = bind(svc, lease)
    await asyncio.sleep(0.02)
    await svc.stop()
    assert svc.lease is None
    assert sink.closes and sink.closes[0][0] == 4412
    await asyncio.sleep(0.05)


async def test_global_mute_ends_remote_conversation(settings, db, store, bus):
    """Dashboard mute must terminate a live REMOTE provider session too —
    "muted" may never leave a cloud session speaking on the phone.  The
    lease/socket survive so the device can restart after unmute."""
    rt = build_runtime(settings, db, store, bus)
    svc = rt.remote_voice
    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    await svc.start_conversation(lease)
    assert svc.gateway.session_intent_active
    svc.gateway.audio_in.put_nowait(b"\x01\x02" * 640)  # pre-mute frame

    # Real runtime linkage: Runtime.set_muted drives the remote service.
    host = object.__new__(Runtime)     # behavior-only instance, no start()
    host.state = rt.state
    host.db = db
    host._announce = lambda *a, **k: None
    host.gateway = rt.gateway
    host.remote_voice = svc
    await host.set_muted(True)

    assert not svc.gateway.session_intent_active, "remote session must end on mute"
    assert svc.gateway.audio_in.empty(), "queued pre-mute audio must be flushed"
    assert svc.lease is not None, "mute is not a revocation"
    assert await svc.start_conversation(lease) == "muted", (
        "restart while muted must be refused"
    )
    await host.set_muted(False)
    assert await svc.start_conversation(lease) == "started"
    svc.end_conversation(lease, "cleanup")
    await asyncio.sleep(0.05)


async def test_audio_reload_reapplies_remote_wake_ownership(
    settings, db, store, bus
):
    """Rebuilding the audio engine (settings reload) must not hand the shared
    wake model back to the host mic while a remote device is attached."""
    audio = SimpleNamespace(remote_mic_active=False)
    rt = build_runtime(settings, db, store, bus, audio=audio)
    svc = rt.remote_voice

    # No device attached: a rebuilt engine keeps host ownership.
    rt.audio = SimpleNamespace(remote_mic_active=False)
    svc.reapply_wake_ownership()
    assert rt.audio.remote_mic_active is False

    _, lease = svc.claim("Pixel 9")
    bind(svc, lease)
    assert rt.audio.remote_mic_active is True

    # Settings reload swaps in a fresh engine (defaults to host ownership).
    rt.audio = SimpleNamespace(remote_mic_active=False)
    svc.reapply_wake_ownership()
    assert rt.audio.remote_mic_active is True, (
        "attached device must regain wake ownership on the rebuilt engine"
    )

    # After the device detaches, a rebuilt engine stays host-owned.
    svc.detach(lease)
    rt.audio = SimpleNamespace(remote_mic_active=False)
    svc.reapply_wake_ownership()
    assert rt.audio.remote_mic_active is False
    await asyncio.sleep(0.05)
