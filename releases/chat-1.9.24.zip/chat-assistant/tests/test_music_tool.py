from __future__ import annotations

import asyncio
import json

import pytest

from apps.tool_service.music_tool import MusicError, MusicTool
from chat_core.models.music import MusicStore
from integrations.spotify import SpotifyError


class FakeYouTube:
    owner_id = "browser-client-raw-12345678"

    def __init__(self):
        self.searches = []
        self.plays = []

    def snapshot(self):
        return {
            "player_connected": True,
            "companion_connected": False,
            "target_label": "Kitchen browser",
            "status": "ready",
        }

    async def search(self, query, limit):
        self.searches.append((query, limit))
        return {"results": [{"video_id": "yt-raw", "title": "YouTube song", "channel": "YT artist"}]}

    async def search_playlists(self, query, limit):
        return {"results": []}

    async def play(self, video, title):
        self.plays.append((video, title))
        return {"playing": True}

    async def stop_media(self):
        return None


class FakeLocal:
    async def search(self, query, limit=10):
        return [{"id": "local-item", "title": "Local song", "artist": "Local artist"}]

    async def list(self, limit=500):
        return []


class FakeAccount:
    async def public_metadata(self):
        return {"connected": True}


class FakeSpotify:
    def __init__(self):
        self.account = FakeAccount()
        self.starts = []
        self.error = None

    async def discover_devices(self):
        return [{"ref": "spotify-device-public-ref", "name": "Office"}]

    async def search(self, query, types=("track", "playlist"), limit=10):
        return {
            "tracks": [{
                "id": "sp-raw-track", "name": "Spotify song", "artists": ["SP artist"],
                "uri": "spotify:track:sp-raw-track",
            }],
            "playlists": [],
        }

    async def start(self, target, **kwargs):
        if self.error:
            raise self.error
        self.starts.append((target, kwargs))
        return {"playing": True}

    async def stop(self, target):
        return {}

    async def pause(self, target):
        return {"playing": False}

    async def resume(self, target):
        return {"playing": True}

    async def next(self, target):
        return {}

    async def previous(self, target):
        return {}

    async def seek(self, target, value):
        return {}

    async def volume(self, target, value):
        return {}

    async def mute(self, target, value):
        return {}


@pytest.fixture
async def music(db, vault, bus):
    store = MusicStore(db, vault)
    youtube = FakeYouTube()
    spotify = FakeSpotify()
    tool = MusicTool(db, bus, store, youtube, spotify=spotify, local=FakeLocal())
    await tool.start()
    return tool, store, youtube, spotify


@pytest.mark.asyncio
async def test_provider_neutral_search_routes_and_publicly_normalizes(music):
    tool, _store, youtube, _spotify = music
    found = await tool.search("  song   title ", provider="all", kind="track", max_results=20)
    assert {row["provider"] for row in found} == {"youtube", "spotify", "local"}
    assert youtube.searches == [("song title", 20)]
    assert all("provider_id" not in row["metadata"] and "uri" not in row["metadata"] for row in found)
    assert all(row["id"] and row["title"] for row in found)


@pytest.mark.asyncio
async def test_spotify_mapping_is_encrypted_and_snapshot_never_leaks_raw_identifiers(music):
    tool, store, _youtube, _spotify = music
    room = await store.resolve_room()
    await tool.map_room_target(room["id"], "spotify", "spotify-device-public-ref")
    row = await tool.db.fetchone(
        "SELECT encrypted_target_id,target_ref FROM music_room_targets WHERE room_id=?",
        (room["id"],),
    )
    assert b"spotify-device-public-ref" not in bytes(row["encrypted_target_id"])
    snapshot = await tool.snapshot()
    encoded = json.dumps(snapshot)
    assert "browser-client-raw-12345678" not in encoded
    assert "client_id" not in encoded and "device_id" not in encoded
    assert await store.decrypt_target_id(room["id"], "spotify") == "spotify-device-public-ref"


@pytest.mark.asyncio
async def test_room_default_and_provider_preference_resolution(music):
    tool, store, _youtube, _spotify = music
    bedroom = await tool.create_room("Bedroom")
    await tool.set_default_room(bedroom["id"])
    assert (await store.resolve_room())["id"] == bedroom["id"]
    assert (await store.resolve_room("bedroom"))["id"] == bedroom["id"]
    assert await tool.set_provider_preference("spotify") == "spotify"
    assert await tool.get_provider_preference() == "spotify"
    await tool.db.set_setting(tool.PREFERENCE_KEY, "bogus")
    assert await tool.get_provider_preference() == "youtube"


@pytest.mark.asyncio
async def test_spotify_play_success_and_truthful_provider_failures(music):
    tool, store, _youtube, spotify = music
    room = await store.resolve_room()
    await tool.map_room_target(room["id"], "spotify", "spotify-device-public-ref")
    item = await tool._persist("spotify", {
        "id": "track", "name": "Song", "uri": "spotify:track:track",
    })
    result = await tool.play(item["id"], room=room["id"])
    assert result["state"]["status"] == "playing" and result["state"]["audible"] is True
    assert spotify.starts[-1] == ("spotify-device-public-ref", {"uri": "spotify:track:track"})
    for code, message in (
        ("premium_required", "Spotify Premium is required for playback control"),
        ("unavailable_device", "The Spotify playback device is no longer available"),
    ):
        spotify.error = SpotifyError(code, message, 403 if code == "premium_required" else 404)
        with pytest.raises(SpotifyError) as caught:
            await tool.play(item["id"], room=room["id"])
        assert caught.value.code == code
        assert str(caught.value) == message


@pytest.mark.asyncio
async def test_unified_youtube_and_local_require_default_room_mappings(music, bus):
    tool, store, youtube, _spotify = music
    youtube_item = await tool._persist(
        "youtube", {"video_id": "yt-unmapped", "title": "YouTube"}
    )
    local_item = await tool._persist(
        "local", {"id": "local-unmapped", "title": "Local"}
    )
    events = bus.subscribe("music_control")

    with pytest.raises(
        MusicError, match="no youtube target is mapped to this room"
    ):
        await tool.play(youtube_item["id"])
    with pytest.raises(
        MusicError, match="no local target is mapped to this room"
    ):
        await tool.play(local_item["id"])

    assert youtube.plays == []
    assert events.empty()
    assert await store.get_active_session() is None


@pytest.mark.asyncio
async def test_unified_youtube_and_local_reject_stale_browser_mappings(music, bus):
    tool, store, youtube, _spotify = music
    room = await store.resolve_room()
    targets = (await tool.snapshot())["targets"]
    await tool.map_room_target(
        room["id"], "youtube", targets["youtube"][0]["target_ref"]
    )
    await tool.map_room_target(
        room["id"], "local", targets["local"][0]["target_ref"]
    )
    youtube.owner_id = "replacement-browser-client"
    youtube_item = await tool._persist(
        "youtube", {"video_id": "yt-stale", "title": "YouTube"}
    )
    local_item = await tool._persist(
        "local", {"id": "local-stale", "title": "Local"}
    )
    events = bus.subscribe("music_control")

    with pytest.raises(MusicError, match="YouTube target is not connected"):
        await tool.play(youtube_item["id"], room=room["id"])
    with pytest.raises(MusicError, match="local player is not connected"):
        await tool.play(local_item["id"], room=room["id"])

    assert youtube.plays == []
    assert events.empty()
    assert await store.get_active_session(room["id"]) is None


@pytest.mark.asyncio
async def test_unified_youtube_uses_configured_current_mapping(music):
    tool, store, youtube, _spotify = music
    room = await store.resolve_room()
    target = (await tool.snapshot())["targets"]["youtube"][0]
    await tool.map_room_target(room["id"], "youtube", target["target_ref"])
    item = await tool._persist(
        "youtube", {"video_id": "yt-mapped", "title": "Mapped YouTube"}
    )

    result = await tool.play(item["id"], room=room["id"])

    assert result == {"playing": True}
    assert youtube.plays == [("yt-mapped", "Mapped YouTube")]
    active = await store.get_active_session(room["id"])
    assert active and active["state"]["target_ref"] == target["target_ref"]


@pytest.mark.asyncio
async def test_local_play_is_exactly_targeted_and_waits_for_fenced_report(music, bus):
    tool, store, youtube, _spotify = music
    room = await store.resolve_room()
    target = (await tool.snapshot())["targets"]["local"][0]
    await tool.map_room_target(room["id"], "local", target["target_ref"])
    item = await tool._persist("local", {"id": "local-1", "title": "Local"})
    events = bus.subscribe("music_control")
    result = await tool.play(item["id"])
    event = events.get_nowait()
    assert event.topic == "music_control"
    assert event.data == {
        "room_id": (await store.resolve_room())["id"],
        "session_id": result["session_id"],
        "operation_id": result["operation_id"],
        "target_id": youtube.owner_id,
        "action": "play_local",
        "item_id": item["id"],
        "title": "Local",
        "position_seconds": 0,
    }
    before = await tool.snapshot()
    assert before["status"] == "awaiting_provider"
    assert before["now_playing"]["audible"] is False
    payload = {**event.data, "status": "playing", "position_seconds": 2.5, "volume": .6}
    await tool.report_local(youtube.owner_id, payload)
    after = await tool.snapshot()
    assert after["status"] == "playing" and after["now_playing"]["audible"] is True
    for changed in ("session_id", "operation_id", "room_id"):
        stale = dict(payload)
        stale[changed] = "stale"
        with pytest.raises(MusicError, match="stale"):
            await tool.report_local(youtube.owner_id, stale)
    with pytest.raises(MusicError, match="current Media page"):
        await tool.report_local("former-owner", payload)


@pytest.mark.asyncio
async def test_takeover_release_fences_local_session(music):
    tool, store, youtube, _spotify = music
    room = await store.resolve_room()
    target = (await tool.snapshot())["targets"]["local"][0]
    await tool.map_room_target(room["id"], "local", target["target_ref"])
    item = await tool._persist("local", {"id": "local-2", "title": "Local"})
    result = await tool.play(item["id"])
    tool._last_player_owner = youtube.owner_id
    await tool.player_released("different-owner")
    assert await store.get_active_session() is not None
    await tool.player_released(youtube.owner_id)
    assert await store.get_active_session() is None
    with pytest.raises(MusicError):
        await tool.report_local(youtube.owner_id, {
            "room_id": (await store.resolve_room())["id"],
            "session_id": result["session_id"], "operation_id": result["operation_id"],
            "status": "playing",
        })


@pytest.mark.asyncio
async def test_queue_favorites_and_named_playlist_persist_and_play(music, bus):
    tool, store, _youtube, _spotify = music
    room = await store.resolve_room()
    target = (await tool.snapshot())["targets"]["local"][0]
    await tool.map_room_target(room["id"], "local", target["target_ref"])
    item = await tool._persist("local", {"id": "persisted-local", "title": "Favorite"})
    await tool.queue_add([item["id"]])
    await tool.favorite(item["id"])
    playlist = await tool.create_playlist("Evening")
    await tool.playlist_add(playlist["id"], [item["id"]])
    restored = MusicTool(tool.db, bus, MusicStore(tool.db, store.vault), tool.youtube,
                         spotify=tool.spotify, local=tool.local)
    assert [x["id"] for x in await restored.queue()] == [item["id"]]
    assert [x["id"] for x in await restored.favorites()] == [item["id"]]
    assert (await restored.play(favorites=True))["awaiting_confirmation"] is True
    assert (await restored.play(playlist_name="evening"))["awaiting_confirmation"] is True


@pytest.mark.asyncio
async def test_room_transfer_retires_previous_session(music):
    tool, store, _youtube, _spotify = music
    first = await store.resolve_room()
    second = await tool.create_room("Second")
    target = (await tool.snapshot())["targets"]["local"][0]
    for room in (first, second):
        await tool.map_room_target(room["id"], "local", target["target_ref"])
    item = await tool._persist("local", {"id": "transfer-local", "title": "Transfer"})
    await tool.play(item["id"], room=first["id"])
    await tool.play(item["id"], room=second["id"])
    assert await store.get_active_session(first["id"]) is None
    active = await store.get_active_session(second["id"])
    assert active and active["state"]["status"] == "awaiting_provider"


@pytest.mark.asyncio
async def test_overlapping_spotify_room_plays_serialize_provider_side_effects(music):
    tool, store, _youtube, spotify = music
    first_room = await store.resolve_room()
    second_room = await tool.create_room("Office")
    for room in (first_room, second_room):
        await tool.map_room_target(room["id"], "spotify", "spotify-device-public-ref")
    first_item = await tool._persist(
        "spotify", {"id": "race-one", "name": "One", "uri": "spotify:track:one"}
    )
    second_item = await tool._persist(
        "spotify", {"id": "race-two", "name": "Two", "uri": "spotify:track:two"}
    )
    entered = asyncio.Event()
    release = asyncio.Event()
    events = []
    active_calls = 0
    maximum_active = 0

    async def start(target, **kwargs):
        nonlocal active_calls, maximum_active
        active_calls += 1
        maximum_active = max(maximum_active, active_calls)
        events.append(("start", kwargs.get("uri")))
        if kwargs.get("uri") == "spotify:track:one":
            entered.set()
            await release.wait()
        active_calls -= 1
        return {"playing": True}

    async def stop(target):
        nonlocal active_calls, maximum_active
        active_calls += 1
        maximum_active = max(maximum_active, active_calls)
        events.append(("stop", target))
        await asyncio.sleep(0)
        active_calls -= 1
        return {}

    spotify.start = start
    spotify.stop = stop
    first = asyncio.create_task(tool.play(first_item["id"], room=first_room["id"]))
    await entered.wait()
    second = asyncio.create_task(tool.play(second_item["id"], room=second_room["id"]))
    await asyncio.sleep(0)
    assert events == [("start", "spotify:track:one")]
    release.set()
    await asyncio.gather(first, second)

    assert maximum_active == 1
    assert [event[0] for event in events] == ["start", "stop", "start"]
    assert events[-1] == ("start", "spotify:track:two")
    assert await store.get_active_session(first_room["id"]) is None
    active = await store.get_active_session(second_room["id"])
    assert active and active["state"]["item_id"] == second_item["id"]


@pytest.mark.asyncio
async def test_concurrent_control_and_room_transfer_are_serialized(music):
    tool, store, _youtube, spotify = music
    first_room = await store.resolve_room()
    second_room = await tool.create_room("Den")
    for room in (first_room, second_room):
        await tool.map_room_target(room["id"], "spotify", "spotify-device-public-ref")
    first_item = await tool._persist(
        "spotify", {"id": "control-one", "name": "One", "uri": "spotify:track:one"}
    )
    second_item = await tool._persist(
        "spotify", {"id": "control-two", "name": "Two", "uri": "spotify:track:two"}
    )
    await tool.play(first_item["id"], room=first_room["id"])
    events = []
    pause_entered = asyncio.Event()
    release_pause = asyncio.Event()
    active_calls = 0
    maximum_active = 0

    async def pause(target):
        nonlocal active_calls, maximum_active
        active_calls += 1
        maximum_active = max(maximum_active, active_calls)
        events.append("pause")
        pause_entered.set()
        await release_pause.wait()
        active_calls -= 1
        return {"playing": False}

    async def stop(target):
        nonlocal active_calls, maximum_active
        active_calls += 1
        maximum_active = max(maximum_active, active_calls)
        events.append("stop")
        active_calls -= 1
        return {}

    async def start(target, **kwargs):
        nonlocal active_calls, maximum_active
        active_calls += 1
        maximum_active = max(maximum_active, active_calls)
        events.append("start")
        active_calls -= 1
        return {"playing": True}

    spotify.pause, spotify.stop, spotify.start = pause, stop, start
    control = asyncio.create_task(tool.control("pause", room=first_room["id"]))
    await pause_entered.wait()
    transfer = asyncio.create_task(tool.play(second_item["id"], room=second_room["id"]))
    await asyncio.sleep(0)
    assert events == ["pause"]
    release_pause.set()
    await asyncio.gather(control, transfer)
    assert maximum_active == 1
    assert events == ["pause", "stop", "start"]
    assert await store.get_active_session(first_room["id"]) is None
    assert await store.get_active_session(second_room["id"]) is not None


@pytest.mark.asyncio
async def test_relative_volume_and_room_transfer_are_serialized(music):
    tool, store, _youtube, spotify = music
    first_room = await store.resolve_room()
    second_room = await tool.create_room("Volume room")
    for room in (first_room, second_room):
        await tool.map_room_target(room["id"], "spotify", "spotify-device-public-ref")
    first_item = await tool._persist(
        "spotify", {"id": "volume-one", "name": "One", "uri": "spotify:track:one"}
    )
    second_item = await tool._persist(
        "spotify", {"id": "volume-two", "name": "Two", "uri": "spotify:track:two"}
    )
    await tool.play(first_item["id"], room=first_room["id"])

    events = []
    discovery_entered = asyncio.Event()
    release_discovery = asyncio.Event()

    async def devices():
        events.append("discover")
        discovery_entered.set()
        await release_discovery.wait()
        return [{
            "ref": "spotify-device-public-ref",
            "name": "Office",
            "volume_percent": 40,
        }]

    async def volume(_target, value):
        events.append(f"volume:{value}")
        return {"volume_percent": value}

    async def stop(_target):
        events.append("stop")
        return {}

    async def start(_target, **_kwargs):
        events.append("start")
        return {"playing": True}

    spotify.discover_devices = devices
    spotify.volume = volume
    spotify.stop = stop
    spotify.start = start
    volume_task = asyncio.create_task(
        tool.set_volume(delta=5, room=first_room["id"])
    )
    await discovery_entered.wait()
    transfer_task = asyncio.create_task(
        tool.play(second_item["id"], room=second_room["id"])
    )
    await asyncio.sleep(0)
    assert events == ["discover"]
    release_discovery.set()
    await asyncio.gather(volume_task, transfer_task)
    assert events == ["discover", "volume:45", "stop", "start"]


@pytest.mark.asyncio
async def test_restart_retires_persisted_local_session_and_gates_false(music, bus):
    tool, store, youtube, spotify = music
    room = await store.resolve_room()
    await store.begin_session(room["id"], "persisted-local", "old-op", {
        "provider": "local", "target_ref": "old-browser", "status": "playing",
        "audible": True, "item_id": "old-item",
    })
    gates = []
    restarted = MusicTool(
        tool.db, bus, MusicStore(tool.db, store.vault), youtube,
        spotify=spotify, local=None, on_playing=gates.append,
    )
    await restarted.start()
    try:
        assert await restarted.store.get_active_session(room["id"]) is None
        assert gates == [False]
    finally:
        await restarted.close()


@pytest.mark.asyncio
async def test_restart_stops_and_retires_persisted_spotify_when_verified(music, bus):
    tool, store, youtube, spotify = music
    room = await store.resolve_room()
    await store.begin_session(room["id"], "persisted-spotify", "old-op", {
        "provider": "spotify", "target_ref": "spotify-device-public-ref",
        "status": "playing", "audible": True, "item_id": "old-item",
    })
    stopped = []

    async def stop(target):
        stopped.append(target)
        return {"playing": False}

    spotify.stop = stop
    gates = []
    restarted = MusicTool(
        tool.db, bus, MusicStore(tool.db, store.vault), youtube,
        spotify=spotify, local=None, on_playing=gates.append,
    )
    await restarted.start()
    try:
        assert stopped == ["spotify-device-public-ref"]
        assert await restarted.store.get_active_session(room["id"]) is None
        assert gates == [False]
    finally:
        await restarted.close()


@pytest.mark.asyncio
async def test_restart_keeps_explicit_unverified_spotify_state_and_gates_true(music, bus):
    tool, store, youtube, spotify = music
    room = await store.resolve_room()
    await store.begin_session(room["id"], "persisted-spotify", "old-op", {
        "provider": "spotify", "target_ref": "spotify-device-public-ref",
        "status": "playing", "audible": True, "item_id": "old-item",
    })

    async def cannot_verify(_target):
        raise SpotifyError("unavailable_device", "cannot verify", 404)

    spotify.stop = cannot_verify
    gates = []
    restarted = MusicTool(
        tool.db, bus, MusicStore(tool.db, store.vault), youtube,
        spotify=spotify, local=None, on_playing=gates.append,
    )
    await restarted.start()
    try:
        active = await restarted.store.get_active_session(room["id"])
        assert active is not None
        assert active["state"]["status"] == "restart_unverified"
        assert active["state"]["audible"] is True
        assert "could not be verified" in active["state"]["error_message"]
        assert gates == [True]
    finally:
        await restarted.close()