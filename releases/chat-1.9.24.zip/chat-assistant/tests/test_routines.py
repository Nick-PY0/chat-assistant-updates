"""Persistence, safety, runner, and clock-controlled scheduler tests."""

import asyncio
from datetime import datetime, timezone

import pytest

from apps.tool_service.routines import (
    ACTION_CATALOG, RoutineError, RoutineManager, catalog_public,
)
from apps.tool_service.schemas import TOOL_DECLARATIONS


def test_catalog_is_closed(bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(None, bus, execute)
    assert "wait" in ACTION_CATALOG and "tv_power" in ACTION_CATALOG
    with pytest.raises(RoutineError):
        manager.validate({"name": "House scene", "steps": [
            {"type": "script", "args": {"command": "echo no"}}]})


def test_strict_validation_and_reserved_alias(bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(None, bus, execute)
    with pytest.raises(RoutineError):
        manager.validate({"name": "Evening", "aliases": ["mute"], "steps": [
            {"type": "wait", "args": {"seconds": 1}}]})
    with pytest.raises(RoutineError):
        manager.validate({"name": "Evening", "steps": [
            {"type": "wait", "args": {"seconds": 301}}]})
    assert manager.validate({"name": "Morning music", "steps": [
        {"type": "wait", "args": {"seconds": 1}}]})["name"] == "Morning music"
    for phrase in ("stop everything", "mute room", "turn off tv"):
        with pytest.raises(RoutineError):
            manager.validate({"name": phrase, "steps": [
                {"type": "wait", "args": {"seconds": 1}}]})


def test_public_catalog_hides_tools():
    catalog = catalog_public()
    assert len(catalog) == len(ACTION_CATALOG)
    assert all(set(x) == {"type", "label", "description", "fields"}
               for x in catalog)
    assert "get_briefing" not in str(catalog)
    exposed = {item["name"] for item in TOOL_DECLARATIONS}
    assert {"list_routines", "run_routine"} <= exposed


@pytest.mark.asyncio
async def test_crud_run_and_dry_run(db, bus):
    calls = []
    async def execute(name, args):
        calls.append((name, args))
        return {"summary": "done"}
    manager = RoutineManager(db, bus, execute)
    item = await manager.create_routine({
        "name": "Evening scene", "aliases": ["settle in"], "enabled": True,
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    dry = await manager.run(item["id"], dry_run=True)
    assert dry["valid"] and not calls
    result = await manager.run("settle in")
    assert result["status"] == "completed"
    assert calls == [("set_quiet_mode", {"enabled": True})]
    assert len(await manager.list_routines()) == 1
    public = (await manager.list_routines())[0]
    assert {"template_draft", "validation", "updated_at", "active_run"} <= set(public)


@pytest.mark.asyncio
async def test_templates_are_disabled_drafts(db, bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(db, bus, execute)
    assert {x["id"] for x in manager.templates()} == {
        "good_morning", "movie_time", "good_night"}
    item = await manager.create_from_template("movie_time")
    assert item["draft"] and not item["enabled"]
    duplicate = await manager.duplicate_routine(item["id"])
    assert duplicate["template_draft"] and not duplicate["enabled"]
    with pytest.raises(RoutineError):
        await manager.set_enabled(item["id"], True)


@pytest.mark.asyncio
async def test_typed_reminder_and_result_errors(db, bus):
    calls = []
    async def execute(name, args):
        calls.append((name, args))
        return {"error": "secret provider body"}
    manager = RoutineManager(db, bus, execute)
    with pytest.raises(RoutineError, match="HH:MM"):
        manager.validate({"name": "Invalid clock scene", "steps": [
            {"type": "alarm", "args": {"time": "8pm"}}]})
    item = await manager.create_routine({
        "name": "Wake scene", "enabled": True, "steps": [
            {"type": "alarm", "args": {"time": "07:05", "message": "Wake up"}}]})
    result = await manager.run(item["id"])
    assert result["status"] == "failed"
    assert calls == [("set_reminder", {
        "hour": 7, "minute": 5, "message": "Wake up", "kind": "alarm", "day": ""})]
    history = await manager.get_run(result["run_id"])
    assert history["steps"][0]["summary"] == "tool reported an error"
    assert "secret provider body" not in str(history)


@pytest.mark.asyncio
async def test_summary_announcement_events_and_run_listing(db, bus):
    spoken = []
    async def announce(text):
        spoken.append(text)
    async def execute(name, args):
        return {"provider": {"secret": "not history"}}
    queue = bus.subscribe("routine_run_started", "routine_run_progress",
                          "routine_run_finished")
    manager = RoutineManager(db, bus, execute, announce=announce)
    item = await manager.create_routine({
        "name": "Summary scene", "enabled": True, "announce_summary": True,
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    result = await manager.run(item["id"])
    assert spoken == ["Routine completed."]
    run = await manager.get_run(result["run_id"])
    assert run["duration_ms"] is not None
    assert run["steps"][0]["summary"] == "completed"
    assert (await manager.list_runs(item["id"]))[0]["source"] == "manual"
    events = [queue.get_nowait() for _ in range(3)]
    assert [event.topic for event in events] == [
        "routine_run_started", "routine_run_progress", "routine_run_finished"]
    assert "secret" not in str([event.data for event in events])


@pytest.mark.asyncio
async def test_start_marks_abandoned_runs_interrupted(db, bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(db, bus, execute, poll_seconds=60)
    item = await manager.create_routine({
        "name": "Restart scene", "enabled": True,
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    await db.execute(
        """INSERT INTO routine_runs(id,routine_id,version,source,status,summary,started_at)
           VALUES('old-run',?,?,?,'running','',?)""",
        (item["id"], item["version"], "schedule",
         datetime.now(timezone.utc).isoformat()))
    await db.execute(
        """INSERT INTO routine_trigger_claims
           VALUES('old-claim',?,?,'running','old-run',?)""",
        (item["id"], datetime.now(timezone.utc).isoformat(),
         datetime.now(timezone.utc).isoformat()))
    await manager.start()
    row = await db.fetchone("SELECT status,finished_at FROM routine_runs WHERE id='old-run'")
    claim = await db.fetchone(
        "SELECT status FROM routine_trigger_claims WHERE occurrence_key='old-claim'")
    assert row["status"] == "interrupted" and row["finished_at"]
    assert claim["status"] == "interrupted"
    await manager.stop()


@pytest.mark.asyncio
async def test_partial_and_stop_policy_are_truthful(db, bus):
    calls = 0
    async def execute(name, args):
        nonlocal calls
        calls += 1
        if calls == 1:
            raise RuntimeError("provider payload must not be persisted")
        return {}
    manager = RoutineManager(db, bus, execute)
    partial = await manager.create_routine({
        "name": "Two stage scene", "enabled": True, "steps": [
            {"type": "quiet_mode", "args": {"enabled": True},
             "continue_on_error": True},
            {"type": "quiet_mode", "args": {"enabled": False}}]})
    assert (await manager.run(partial["id"]))["status"] == "partial"
    row = await db.fetchone(
        "SELECT summary FROM routine_run_steps WHERE status='failure'")
    assert "provider payload" not in row["summary"]

    calls = 0
    stopped = await manager.create_routine({
        "name": "Failure policy scene", "enabled": True, "steps": [
            {"type": "quiet_mode", "args": {"enabled": True}},
            {"type": "quiet_mode", "args": {"enabled": False}}]})
    assert (await manager.run(stopped["id"]))["status"] == "failed"
    rows = await db.fetchall(
        "SELECT status FROM routine_run_steps WHERE run_id=(SELECT id FROM routine_runs WHERE routine_id=?) ORDER BY step_index",
        (stopped["id"],))
    assert [x["status"] for x in rows] == ["failure", "skipped"]

    async def always_fail(name, args):
        return {"error": "provider details"}
    all_failed = RoutineManager(db, bus, always_fail)
    continued = await all_failed.create_routine({
        "name": "Continue every failure scene", "enabled": True, "steps": [
            {"type": "quiet_mode", "args": {"enabled": True},
             "continue_on_error": True},
            {"type": "quiet_mode", "args": {"enabled": False},
             "continue_on_error": True},
        ]})
    result = await all_failed.run(continued["id"])
    assert result["status"] == "partial"
    assert result["summary"] == "Routine completed with some failures."


@pytest.mark.asyncio
async def test_concurrent_alias_create_is_atomic(db, bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(db, bus, execute)
    payloads = [
        {
            "name": f"Atomic scene {index}",
            "aliases": ["one shared phrase"],
            "enabled": True,
            "steps": [{"type": "wait", "args": {"seconds": 0}}],
        }
        for index in (1, 2)
    ]
    results = await asyncio.gather(
        *(manager.create_routine(payload) for payload in payloads),
        return_exceptions=True,
    )
    assert sum(isinstance(result, RoutineError) for result in results) == 1
    routines = await manager.list_routines()
    assert len(routines) == 1
    assert routines[0]["aliases"] == ["one shared phrase"]
    versions = await db.fetchone("SELECT COUNT(*) AS n FROM routine_versions")
    assert versions["n"] == 1


@pytest.mark.asyncio
async def test_failed_concurrent_alias_update_rolls_back_everything(db, bus):
    async def execute(name, args):
        return {}
    manager = RoutineManager(db, bus, execute)
    first = await manager.create_routine({
        "name": "First atomic update", "aliases": ["first old phrase"],
        "steps": [{"type": "wait", "args": {"seconds": 0}}],
    })
    second = await manager.create_routine({
        "name": "Second atomic update", "aliases": ["second old phrase"],
        "steps": [{"type": "wait", "args": {"seconds": 0}}],
    })
    outcomes = await asyncio.gather(
        manager.update_routine(
            first["id"], {"aliases": ["new shared phrase"], "description": "first"},
            expected_version=first["version"],
        ),
        manager.update_routine(
            second["id"], {"aliases": ["new shared phrase"], "description": "second"},
            expected_version=second["version"],
        ),
        return_exceptions=True,
    )
    assert sum(isinstance(result, RoutineError) for result in outcomes) == 1
    current = {item["id"]: item for item in await manager.list_routines()}
    loser_id = first["id"] if isinstance(outcomes[0], RoutineError) else second["id"]
    old_alias = "first old phrase" if loser_id == first["id"] else "second old phrase"
    assert current[loser_id]["version"] == 1
    assert current[loser_id]["aliases"] == [old_alias]
    assert current[loser_id]["description"] == ""
    assert (await manager.resolve_command(old_alias)) is None  # disabled routines do not resolve
    alias = await db.fetchone(
        "SELECT routine_id FROM routine_aliases WHERE normalized_alias=?",
        (old_alias,),
    )
    assert alias["routine_id"] == loser_id


@pytest.mark.asyncio
async def test_same_routine_overlap_and_version_fence(db, bus):
    entered, release = asyncio.Event(), asyncio.Event()
    async def execute(name, args):
        entered.set()
        await release.wait()
        return {}
    manager = RoutineManager(db, bus, execute)
    item = await manager.create_routine({
        "name": "Fenced scene", "enabled": True,
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    task = asyncio.create_task(manager.run(item["id"]))
    await entered.wait()
    with pytest.raises(RoutineError, match="already running"):
        await manager.run(item["id"])
    await manager.update_routine(
        item["id"], {"description": "new"}, expected_version=item["version"])
    release.set()
    assert (await task)["status"] == "superseded"


@pytest.mark.asyncio
async def test_scheduler_timezone_and_restart_dedupe(db, bus):
    class Clock:
        value = datetime(2025, 1, 6, 7, 59, tzinfo=timezone.utc)
        def __call__(self):
            return self.value
    clock, calls = Clock(), []
    async def execute(name, args):
        calls.append(name)
        return {}
    manager = RoutineManager(db, bus, execute, clock=clock)
    item = await manager.create_routine({
        "name": "Scheduled scene", "enabled": True,
        "trigger": {"enabled": True, "time": "09:00", "weekdays": [0],
                    "timezone": "Europe/Paris"},
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    clock.value = datetime(2025, 1, 6, 8, 0, tzinfo=timezone.utc)
    await manager.tick()
    await asyncio.gather(*manager._scheduled_tasks)
    assert calls == ["set_quiet_mode"]
    restarted = RoutineManager(db, bus, execute, clock=clock)
    await restarted.tick()
    await asyncio.gather(*restarted._scheduled_tasks)
    assert calls == ["set_quiet_mode"]
    claims = await db.fetchone(
        "SELECT COUNT(*) AS n FROM routine_trigger_claims WHERE routine_id=?",
        (item["id"],))
    assert claims["n"] == 1


@pytest.mark.asyncio
async def test_stale_startup_is_not_replayed(db, bus):
    now = datetime(2025, 1, 6, 8, 5, tzinfo=timezone.utc)
    calls = []
    async def execute(name, args):
        calls.append(name)
        return {}
    manager = RoutineManager(db, bus, execute, clock=lambda: now,
                             staleness_seconds=60)
    await manager.create_routine({
        "name": "Old scheduled scene", "enabled": True,
        "trigger": {"enabled": True, "time": "08:00", "weekdays": [0],
                    "timezone": "UTC"},
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}]})
    await manager.tick()
    assert calls == []


@pytest.mark.asyncio
async def test_nonexistent_dst_trigger_is_skipped(db, bus):
    class Clock:
        value = datetime(2025, 3, 9, 5, 0, tzinfo=timezone.utc)
        def __call__(self):
            return self.value
    clock, calls = Clock(), []
    async def execute(name, args):
        calls.append(name)
        return {}
    manager = RoutineManager(db, bus, execute, clock=clock, staleness_seconds=300)
    await manager.create_routine({
        "name": "DST gap scene",
        "enabled": True,
        "trigger": {
            "enabled": True,
            "time": "02:30",
            "weekdays": [6],
            "timezone": "America/New_York",
        },
        "steps": [{"type": "quiet_mode", "args": {"enabled": True}}],
    })
    clock.value = datetime(2025, 3, 9, 7, 30, tzinfo=timezone.utc)
    await manager.tick()
    assert calls == []
    assert not manager._scheduled_tasks


@pytest.mark.asyncio
async def test_scheduler_starts_different_routines_concurrently(db, bus):
    class Clock:
        value = datetime(2025, 1, 6, 7, 59, tzinfo=timezone.utc)
        def __call__(self):
            return self.value
    clock = Clock()
    entered, release = asyncio.Event(), asyncio.Event()
    count = 0
    async def execute(name, args):
        nonlocal count
        count += 1
        if count == 2:
            entered.set()
        await release.wait()
        return {}
    manager = RoutineManager(db, bus, execute, clock=clock)
    for name in ("First concurrent scene", "Second concurrent scene"):
        await manager.create_routine({
            "name": name,
            "enabled": True,
            "trigger": {
                "enabled": True, "time": "08:00", "weekdays": [0],
                "timezone": "UTC",
            },
            "steps": [{"type": "quiet_mode", "args": {"enabled": True}}],
        })
    clock.value = datetime(2025, 1, 6, 8, 0, tzinfo=timezone.utc)
    await manager.tick()
    await asyncio.wait_for(entered.wait(), 1)
    assert count == 2
    release.set()
    await asyncio.gather(*manager._scheduled_tasks)