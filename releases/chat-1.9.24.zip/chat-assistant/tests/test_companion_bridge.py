"""Comprehensive socket integration tests for the companion bridge.

Covers: loopback enforcement, one-time pairing + persistent secret reconnect,
rotate + revoke, auth-before-anything, command/ack correlation, session + target
fencing, ad_playing gate, URL/host stripping, ping/pong, and displacement.
"""

from __future__ import annotations

import asyncio
import json

import pytest

from apps.tool_service.companion_bridge import (
    AUTH_DEADLINE_SECONDS,
    CMD_NAVIGATE_VIDEO,
    CMD_PAUSE,
    CMD_DUCK,
    CMD_RESTORE,
    CompanionBridge,
    CompanionError,
    PROTOCOL_VERSION,
    _AD_BLOCKED_ACTIONS,
)
from apps.tool_service.youtube_tool import YouTubeTool


VIDEO_A = "dQw4w9WgXcQ"


class FakeSocket:
    """In-memory companion socket double driving the real bridge coroutine."""

    def __init__(self) -> None:
        self.outgoing: list[dict] = []
        self._incoming: asyncio.Queue[str] = asyncio.Queue()
        self.closed = False
        self.close_code: int | None = None

    async def send_text(self, data: str) -> None:
        self.outgoing.append(json.loads(data))

    async def receive_text(self) -> str:
        return await self._incoming.get()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        self.closed = True
        self.close_code = code
        self._incoming.put_nowait('{"type":"__closed__"}')

    def feed(self, frame: dict) -> None:
        self._incoming.put_nowait(json.dumps(frame))

    def sent_types(self) -> list[str]:
        return [f.get("type") for f in self.outgoing]

    def last_of(self, ftype: str) -> dict | None:
        for f in reversed(self.outgoing):
            if f.get("type") == ftype:
                return f
        return None


async def _wait_for(predicate, timeout=1.0):
    for _ in range(int(timeout / 0.01)):
        if predicate():
            return True
        await asyncio.sleep(0.01)
    return predicate()


# ---------------------------------------------------------------------------
# Loopback enforcement
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("host", ["127.0.0.1", "::1", "localhost", "127.5.4.3"])
def test_loopback_hosts_accepted(host):
    assert CompanionBridge.is_loopback_host(host) is True


@pytest.mark.parametrize("host", ["192.168.1.5", "10.0.0.2", "8.8.8.8", "", "evil.com"])
def test_non_loopback_hosts_rejected(host):
    assert CompanionBridge.is_loopback_host(host) is False


# ---------------------------------------------------------------------------
# Pairing token lifecycle
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_pairing_token_is_one_time_and_hashed(db, bus):
    bridge = CompanionBridge(db, bus)
    assert await bridge.is_paired() is False
    token = await bridge.issue_pairing_token()
    assert token and len(token) > 20
    # Plaintext token is never stored; only a salted hash is.
    stored = await db.get_setting("companion_pairing_hash") or ""
    assert token not in stored
    # Correct token mints a bridge secret and clears the pending pairing.
    secret = await bridge._consume_pairing(token)
    assert secret and secret != token
    assert await bridge.is_paired() is True
    assert await bridge.has_pending_pairing() is False
    # The token cannot be reused.
    with pytest.raises(CompanionError):
        await bridge._consume_pairing(token)


@pytest.mark.asyncio
async def test_wrong_token_rejected(db, bus):
    bridge = CompanionBridge(db, bus)
    await bridge.issue_pairing_token()
    with pytest.raises(CompanionError, match="invalid"):
        await bridge._consume_pairing("wrong-token")


@pytest.mark.asyncio
async def test_revoke_drops_secret(db, bus):
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    await bridge._consume_pairing(token)
    assert await bridge.is_paired() is True
    await bridge.revoke()
    assert await bridge.is_paired() is False
    assert await bridge.has_pending_pairing() is False


@pytest.mark.asyncio
async def test_rotate_invalidates_old_secret(db, bus):
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    old_secret = await bridge._consume_pairing(token)
    assert await bridge._verify_secret(old_secret) is True
    new_token = await bridge.rotate()
    assert await bridge._verify_secret(old_secret) is False
    assert await bridge.has_pending_pairing() is True
    assert new_token and new_token != token


# ---------------------------------------------------------------------------
# Socket integration: initial pairing (one-time token)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_socket_pairs_via_token_and_receives_persistent_secret(db, bus):
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    assert sock.last_of("welcome")["protocol"] == PROTOCOL_VERSION

    sock.feed({"type": "hello", "token": token})
    # paired frame arrives BEFORE auth_ok
    await _wait_for(lambda: sock.last_of("auth_ok") is not None)
    assert bridge.connected is True
    paired = sock.last_of("paired")
    assert paired is not None
    secret = paired["secret"]
    assert secret and len(secret) > 20
    # The secret must verify against the stored hash.
    assert await bridge._verify_secret(secret) is True
    # One-time token is now consumed; the pending hash is cleared.
    assert await bridge.has_pending_pairing() is False

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_socket_reconnects_with_secret_no_new_token(db, bus):
    """After pairing the extension reconnects with the bridge secret only."""
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    secret = await bridge._consume_pairing(token)

    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "hello", "secret": secret})
    await _wait_for(lambda: sock.last_of("auth_ok") is not None)
    assert bridge.connected is True
    # No paired frame on reconnect.
    assert sock.last_of("paired") is None

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_one_time_token_cannot_be_reused_on_reconnect(db, bus):
    """The one-time token must be rejected on a second hello."""
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    # First connection: consumes the token.
    sock1 = FakeSocket()
    t1 = asyncio.ensure_future(bridge.handle(sock1))
    await _wait_for(lambda: sock1.last_of("welcome") is not None)
    sock1.feed({"type": "hello", "token": token})
    await _wait_for(lambda: sock1.last_of("auth_ok") is not None)
    t1.cancel()
    await asyncio.gather(t1, return_exceptions=True)

    # Second connection: same token must be rejected.
    sock2 = FakeSocket()
    t2 = asyncio.ensure_future(bridge.handle(sock2))
    await _wait_for(lambda: sock2.last_of("welcome") is not None)
    sock2.feed({"type": "hello", "token": token})
    await _wait_for(lambda: sock2.last_of("auth_error") is not None)
    assert bridge.connected is False
    t2.cancel()
    await asyncio.gather(t2, return_exceptions=True)


# ---------------------------------------------------------------------------
# Auth before anything
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_state_frame_before_auth_is_rejected(db, bus):
    bridge = CompanionBridge(db, bus)
    await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "state", "status": "playing", "target": "browser_companion"})
    await _wait_for(lambda: sock.last_of("auth_error") is not None)
    assert bridge.connected is False
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_invalid_secret_is_rejected(db, bus):
    bridge = CompanionBridge(db, bus)
    token = await bridge.issue_pairing_token()
    await bridge._consume_pairing(token)
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "hello", "secret": "not-the-secret"})
    await _wait_for(lambda: sock.last_of("auth_error") is not None)
    assert bridge.connected is False
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# Command / ack correlation
# ---------------------------------------------------------------------------

async def _connect_authed(db, bus, on_state=None):
    """Helper: create an authenticated companion connection."""
    bridge = CompanionBridge(db, bus, on_state=on_state)
    token = await bridge.issue_pairing_token()
    await bridge._consume_pairing(token)
    # Re-issue so we can reconnect with a fresh pairing token.
    token2 = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "hello", "token": token2})
    await _wait_for(lambda: sock.last_of("auth_ok") is not None)
    return bridge, sock, task


@pytest.mark.asyncio
async def test_command_awaits_matching_ack(db, bus):
    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()

    async def responder():
        await _wait_for(lambda: sock.last_of("command") is not None)
        cmd = sock.last_of("command")
        # Every command frame has the full canonical shape.
        assert cmd["type"] == "command"
        assert cmd["target"] == "browser_companion"
        assert cmd["session"] == bridge.session
        assert isinstance(cmd["id"], int)
        assert cmd["action"] == CMD_NAVIGATE_VIDEO
        assert cmd["video_id"] == VIDEO_A
        sock.feed({"type": "ack", "id": cmd["id"], "ok": True})

    resp_task = asyncio.ensure_future(responder())
    ack = await bridge.send_command(CMD_NAVIGATE_VIDEO, video_id=VIDEO_A)
    assert ack["ok"] is True
    await asyncio.gather(resp_task, return_exceptions=True)
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_socket_close_while_awaiting_ack_raises_connection_lost(db, bus):
    """The companion transport dies mid-command: the waiter must receive the
    coded connection_lost CompanionError, never a bare CancelledError."""
    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()

    send = asyncio.ensure_future(bridge.send_command(CMD_PAUSE))
    await _wait_for(lambda: sock.last_of("command") is not None)
    task.cancel()  # transport layer tears the connection down
    with pytest.raises(CompanionError) as ei:
        await send
    assert ei.value.code == "connection_lost"
    st = bridge.status()
    assert st["last_ack"]["error"] == "connection_lost"
    assert st["last_ack"]["ok"] is False
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_youtube_tool_reports_disconnect_during_command(db, bus, store):
    """Through the real bridge: a companion that disconnects while YouTubeTool
    awaits the ack surfaces the friendly disconnect message, not a crash."""
    from apps.tool_service.youtube_tool import YouTubeError

    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    yt.register_companion(bridge)

    call = asyncio.ensure_future(yt.set_volume(50))
    await _wait_for(lambda: sock.last_of("command") is not None)
    await bridge._disconnect(reason="displaced in test")
    with pytest.raises(YouTubeError, match="disconnected while"):
        await call
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_command_ack_negative_propagates_error(db, bus):
    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()

    async def responder():
        await _wait_for(lambda: sock.last_of("command") is not None)
        cmd = sock.last_of("command")
        sock.feed({"type": "ack", "id": cmd["id"], "ok": False, "error": "no_tab"})

    resp_task = asyncio.ensure_future(responder())
    ack = await bridge.send_command(CMD_PAUSE)
    assert ack["ok"] is False
    assert ack["error"] == "no_tab"
    await asyncio.gather(resp_task, return_exceptions=True)
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# Session + target fencing of state frames
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_state_frame_fenced_by_session_and_target(db, bus):
    received: list[dict] = []
    bridge, sock, task = await _connect_authed(db, bus, on_state=received.append)
    bridge.bump_session()
    current = bridge.session

    # Wrong target: dropped.
    sock.feed({"type": "state", "status": "playing", "target": "other", "session": current})
    # Stale session: dropped.
    sock.feed({"type": "state", "status": "playing", "target": "browser_companion",
               "session": current - 1})
    # Missing session: dropped.
    sock.feed({"type": "state", "status": "playing", "target": "browser_companion"})
    # Valid frame: accepted.
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": current, "position_seconds": 12.5, "volume": 40, "muted": False,
        "ad_playing": False,
    })
    await _wait_for(lambda: len(received) >= 1)
    await asyncio.sleep(0.05)
    assert len(received) == 1
    assert received[0]["status"] == "playing"
    assert received[0]["position_seconds"] == 12.5
    assert received[0]["volume"] == 40
    assert received[0]["muted"] is False
    assert received[0]["ad_playing"] is False

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_state_frame_never_carries_url_through(db, bus):
    received: list[dict] = []
    bridge, sock, task = await _connect_authed(db, bus, on_state=received.append)
    bridge.bump_session()
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": bridge.session, "url": "https://evil.example/x",
        "host": "evil.example", "command": "rm -rf",
    })
    await _wait_for(lambda: len(received) >= 1)
    assert "url" not in received[0]
    assert "host" not in received[0]
    assert "command" not in received[0]
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# Ad-playing gate
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ad_playing_reported_in_state(db, bus):
    received: list[dict] = []
    bridge, sock, task = await _connect_authed(db, bus, on_state=received.append)
    bridge.bump_session()
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": bridge.session, "ad_playing": True,
    })
    await _wait_for(lambda: len(received) >= 1)
    assert received[0]["ad_playing"] is True
    assert bridge.ad_playing is True
    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_ad_blocks_navigation_commands(db, bus):
    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()
    # Simulate an active ad.
    bridge._ad_playing = True

    # Blocked commands return busy_ad without sending to the socket.
    for action in ("navigate_video", "navigate_playlist", "play", "pause", "stop",
                   "seek", "restart", "set_volume", "adjust_volume", "mute", "unmute"):
        result = await bridge.send_command(action, video_id=VIDEO_A)
        assert result == {"ok": False, "error": "busy_ad"}, \
            f"Expected busy_ad for {action}, got {result}"
    # No command frames should have been sent.
    assert not any(f.get("type") == "command" for f in sock.outgoing)

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_ad_playing_true_with_valid_status_accepted(db, bus):
    """ad_playing=True alongside a valid status must flow through to on_state.

    The bridge must not drop a frame just because ad_playing=True;
    ad_playing is extracted unconditionally and the rest of the state
    (status=playing/paused/buffering/etc.) is still valid while an ad runs.
    """
    received: list[dict] = []
    bridge, sock, task = await _connect_authed(db, bus, on_state=received.append)
    bridge.bump_session()
    # Extension sends status="stopped" while ad is playing — valid combination.
    sock.feed({
        "type": "state", "status": "stopped", "target": "browser_companion",
        "session": bridge.session, "ad_playing": True,
    })
    await _wait_for(lambda: len(received) >= 1)
    assert received[0]["status"] == "stopped"
    assert received[0]["ad_playing"] is True
    assert bridge.ad_playing is True

    # A subsequent frame with ad_playing=False clears the flag.
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": bridge.session, "ad_playing": False,
    })
    await _wait_for(lambda: len(received) >= 2)
    assert received[1]["status"] == "playing"
    assert received[1]["ad_playing"] is False
    assert bridge.ad_playing is False

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_playlist_id_passes_through_state_frame(db, bus):
    """playlist_id must be included in the clean state dict passed to on_state."""
    received: list[dict] = []
    bridge, sock, task = await _connect_authed(db, bus, on_state=received.append)
    bridge.bump_session()
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": bridge.session, "playlist_id": "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l",
        "video_id": VIDEO_A,
    })
    await _wait_for(lambda: len(received) >= 1)
    assert received[0].get("playlist_id") == "PLbpi6ZahtOH6Ar_3GPy3workkkXUtly0l"
    assert received[0].get("video_id") == VIDEO_A

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_ad_blocks_every_media_command_including_next_duck_restore(db, bus):
    """During an ad the server blocks EVERY companion media command.

    The server enforces a stricter policy than the extension: next, previous,
    duck and restore are all rejected with busy_ad while an ad is playing, so
    no command frame is ever emitted to the tab.
    """
    from apps.tool_service.companion_bridge import ALL_COMPANION_ACTIONS
    bridge, sock, task = await _connect_authed(db, bus)
    bridge.bump_session()
    bridge._ad_playing = True

    for action in sorted(ALL_COMPANION_ACTIONS):
        result = await bridge.send_command(action, volume=20)
        assert result == {"ok": False, "error": "busy_ad"}, \
            f"Expected busy_ad for {action}, got {result}"
    # Not a single command frame should have been sent to the socket.
    assert not any(f.get("type") == "command" for f in sock.outgoing)

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# Rotate + revoke with live socket
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_rotate_sends_revoked_to_live_socket(db, bus):
    bridge, sock, task = await _connect_authed(db, bus)
    await bridge.rotate()
    await _wait_for(lambda: sock.last_of("revoked") is not None)
    assert sock.last_of("revoked")["reason"] == "rotated"
    assert bridge.connected is False
    await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_revoke_sends_revoked_to_live_socket(db, bus):
    bridge, sock, task = await _connect_authed(db, bus)
    await bridge.revoke()
    await _wait_for(lambda: sock.last_of("revoked") is not None)
    assert sock.last_of("revoked")["reason"] == "revoked"
    assert bridge.connected is False
    assert await bridge.is_paired() is False
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# stop_media: session bump BEFORE dispatch (integration with real bridge)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_authenticated_disconnect_clears_stale_media_gate(db, bus, store):
    audible: list[bool] = []
    yt = YouTubeTool(
        bus,
        store,
        on_playing=audible.append,
        open_browser=lambda _url: None,
    )
    bridge = CompanionBridge(db, bus, on_state=yt._ingest_companion_state)
    yt.register_companion(bridge)

    token = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "hello", "token": token})
    await _wait_for(lambda: sock.last_of("auth_ok") is not None)

    yt.playback_mode = "browser_companion"
    yt.status = "playing"
    yt.muted = False
    yt.volume = 100
    yt._refresh_audible()
    assert audible[-1] is True

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)

    assert bridge.connected is False
    assert yt.status == "stopped"
    assert yt.playback_mode == "embedded"
    assert audible[-1] is False

@pytest.mark.asyncio
async def test_stop_command_carries_new_session_and_fences_state(db, bus, store):
    """stop_media must bump the media/bridge session BEFORE dispatching stop.

    The stop command frame must carry the *new* bridge session, so the
    extension's immediate stopped/ad state (stamped with the new session) is
    accepted while any late state from the OLD media (old session) is rejected.
    """
    yt = YouTubeTool(bus, store, open_browser=lambda u: None)
    bridge = CompanionBridge(db, bus, on_state=yt._ingest_companion_state)
    yt.register_companion(bridge)

    # Authenticate a socket.
    token = await bridge.issue_pairing_token()
    await bridge._consume_pairing(token)
    token2 = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    await _wait_for(lambda: sock.last_of("welcome") is not None)
    sock.feed({"type": "hello", "token": token2})
    await _wait_for(lambda: sock.last_of("auth_ok") is not None)

    # Establish a playing video under an initial session.
    old_session = bridge.session
    yt.playback_mode = "browser_companion"
    yt.media_kind = "video"
    yt.video_id = VIDEO_A
    yt.status = "playing"

    # Auto-ack the stop command as soon as it is dispatched.
    async def responder():
        await _wait_for(lambda: sock.last_of("command") is not None)
        cmd = sock.last_of("command")
        sock.feed({"type": "ack", "id": cmd["id"], "ok": True})

    resp = asyncio.ensure_future(responder())
    result = await yt.stop_media()
    await asyncio.gather(resp, return_exceptions=True)

    assert result["action"] == "stop"

    # The stop command frame must carry the NEW (bumped) bridge session.
    stop_cmd = sock.last_of("command")
    assert stop_cmd is not None
    assert stop_cmd["action"] == "stop"
    new_session = bridge.session
    assert new_session > old_session
    assert stop_cmd["session"] == new_session, (
        f"stop command session {stop_cmd['session']} must equal new bridge "
        f"session {new_session}"
    )
    # The tool's media_session must match the bumped bridge session too.
    assert yt.media_session == new_session

    # Immediate stopped/ad state stamped with the NEW session is accepted.
    sock.feed({
        "type": "state", "status": "stopped", "target": "browser_companion",
        "session": new_session, "ad_playing": True, "video_id": VIDEO_A,
    })
    await _wait_for(lambda: yt.ad_playing is True)
    assert yt.status == "stopped"
    assert yt.ad_playing is True

    # Late state from the OLD session is rejected (fenced by the bridge).
    yt.ad_playing = False  # reset to observe rejection
    sock.feed({
        "type": "state", "status": "playing", "target": "browser_companion",
        "session": old_session, "ad_playing": True, "video_id": VIDEO_A,
    })
    await asyncio.sleep(0.05)  # give the frame time to be processed (and dropped)
    assert yt.status == "stopped", "old-session state must not revive playback"
    assert yt.ad_playing is False, "old-session state must be fully rejected"

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


# ---------------------------------------------------------------------------
# Displacement
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_new_connection_displaces_old(db, bus):
    bridge, sock1, task1 = await _connect_authed(db, bus)
    assert bridge.connected is True

    # Second connection: issue a fresh pairing token.
    token = await bridge.issue_pairing_token()
    sock2 = FakeSocket()
    task2 = asyncio.ensure_future(bridge.handle(sock2))
    await _wait_for(lambda: sock2.last_of("welcome") is not None)
    sock2.feed({"type": "hello", "token": token})
    await _wait_for(lambda: sock2.last_of("auth_ok") is not None)

    # The first socket must have received a revoked frame.
    await _wait_for(lambda: sock1.last_of("revoked") is not None)
    assert bridge.connected is True  # second socket is now the live one

    task1.cancel()
    task2.cancel()
    await asyncio.gather(task1, task2, return_exceptions=True)


# ---------------------------------------------------------------------------
# Diagnostics: status() must tell "authenticated" apart from "recently useful"
# ---------------------------------------------------------------------------

async def test_status_diagnostics_lifecycle(db, bus):
    bridge = CompanionBridge(db, bus)

    s = bridge.status()
    assert s["connected"] is False
    assert s["last_ack"] is None
    assert s["last_state_age_seconds"] is None
    assert s["last_disconnect_reason"] is None
    assert s["connected_seconds"] is None

    token = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    sock.feed({"type": "hello", "token": token})
    assert await _wait_for(lambda: bridge.connected)
    assert bridge.status()["connected_seconds"] is not None

    # a successful command/ack round-trip is recorded (action + ok only)
    async def _ack_when_seen():
        assert await _wait_for(lambda: sock.last_of("command") is not None)
        cmd = sock.last_of("command")
        sock.feed({"type": "ack", "id": cmd["id"], "ok": True})

    acker = asyncio.ensure_future(_ack_when_seen())
    ack = await bridge.send_command(CMD_PAUSE)
    await acker
    assert ack["ok"] is True
    st = bridge.status()
    assert st["last_ack"]["action"] == CMD_PAUSE
    assert st["last_ack"]["ok"] is True
    assert st["last_ack"]["age_seconds"] >= 0

    # an accepted state frame proves the content script is alive
    sock.feed({
        "type": "state", "session": bridge.session,
        "target": "browser_companion", "status": "playing",
        "ad_playing": False,
    })
    assert await _wait_for(
        lambda: bridge.status()["last_state_age_seconds"] is not None
    )

    # a negative ack keeps its error code in the diagnostics
    async def _nack_when_seen():
        assert await _wait_for(
            lambda: (sock.last_of("command") or {}).get("action") == CMD_DUCK
        )
        cmd = sock.last_of("command")
        sock.feed({"type": "ack", "id": cmd["id"], "ok": False, "error": "no_youtube_tab"})

    nacker = asyncio.ensure_future(_nack_when_seen())
    ack = await bridge.send_command(CMD_DUCK, volume=20)
    await nacker
    assert ack == {"ok": False, "error": "no_youtube_tab"}
    st = bridge.status()
    assert st["last_ack"]["action"] == CMD_DUCK
    assert st["last_ack"]["ok"] is False
    assert st["last_ack"]["error"] == "no_youtube_tab"

    # revoke drops the connection and records why it ended
    await bridge.revoke()
    st = bridge.status()
    assert st["connected"] is False
    assert st["connected_seconds"] is None
    assert st["last_disconnect_reason"] == "revoked"

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)


async def test_companion_error_codes(db, bus, monkeypatch):
    import apps.tool_service.companion_bridge as cb

    bridge = CompanionBridge(db, bus)

    with pytest.raises(CompanionError) as ei:
        await bridge.send_command(CMD_PAUSE)
    assert ei.value.code == "not_connected"

    token = await bridge.issue_pairing_token()
    sock = FakeSocket()
    task = asyncio.ensure_future(bridge.handle(sock))
    sock.feed({"type": "hello", "token": token})
    assert await _wait_for(lambda: bridge.connected)

    # never acked -> ack_timeout code, recorded in status for the dashboard
    monkeypatch.setattr(cb, "COMMAND_ACK_TIMEOUT", 0.05)
    with pytest.raises(CompanionError) as ei:
        await bridge.send_command(CMD_PAUSE)
    assert ei.value.code == "ack_timeout"
    st = bridge.status()
    assert st["last_ack"]["error"] == "ack_timeout"
    assert st["last_ack"]["ok"] is False

    task.cancel()
    await asyncio.gather(task, return_exceptions=True)
