from apps.tool_service.local_grammar import parse, words_to_number


def test_words_to_number():
    assert words_to_number("ten") == 10
    assert words_to_number("twenty five") == 25
    assert words_to_number("45") == 45
    assert words_to_number("a") == 1
    assert words_to_number("banana") is None


def test_timer_phrases():
    cmd = parse("Chat, set a timer for ten minutes")
    assert cmd == {"tool": "start_timer", "args": {"duration_seconds": 600, "label": ""}}

    cmd = parse("start a pasta timer for 8 minutes")
    assert cmd["tool"] == "start_timer"
    assert cmd["args"]["duration_seconds"] == 480
    assert cmd["args"]["label"] == "pasta"

    cmd = parse("set a timer for one hour")
    assert cmd["args"]["duration_seconds"] == 3600

    assert parse("list my timers") == {"tool": "list_timers", "args": {}}

    cmd = parse("cancel the pasta timer")
    assert cmd == {"tool": "cancel_timer", "args": {"timer_id": "pasta"}}


def test_light_phrases():
    cmd = parse("turn off the bedroom light")
    assert cmd == {"tool": "set_govee_power", "args": {"device": "bedroom", "state": "off"}}

    cmd = parse("hey chat turn the desk light on")
    assert cmd == {"tool": "set_govee_power", "args": {"device": "desk", "state": "on"}}

    cmd = parse("set the desk light to fifty percent")
    assert cmd == {"tool": "set_govee_brightness", "args": {"device": "desk", "percentage": 50}}


def test_out_of_grammar_is_rejected():
    # NOTE: "play some music" now maps to play_youtube (YouTube search) by design.
    # Verify it resolves to play_youtube rather than returning None.
    result = parse("play some music")
    assert result is not None and result["tool"] == "play_youtube"
    assert parse("delete all my files") is None
    assert parse("set a timer for banana minutes") is None


def test_tv_phrases():
    assert parse("turn on the tv") == {"tool": "tv_power", "args": {"state": "on"}}
    assert parse("hey chat turn off the tv") == {"tool": "tv_power", "args": {"state": "off"}}
    assert parse("turn the tv on") == {"tool": "tv_power", "args": {"state": "on"}}
    assert parse("tv volume up") == {"tool": "tv_set_volume", "args": {"delta": 5}}
    assert parse("turn the tv down") == {"tool": "tv_set_volume", "args": {"delta": -5}}
    assert parse("set the tv volume to fifty") == {"tool": "tv_set_volume", "args": {"percentage": 50}}
    assert parse("mute the tv") == {"tool": "tv_mute", "args": {"muted": True}}
    assert parse("unmute the tv") == {"tool": "tv_mute", "args": {"muted": False}}
    assert parse("pause the tv") == {"tool": "tv_media", "args": {"action": "pause"}}
    assert parse("resume the tv") == {"tool": "tv_media", "args": {"action": "play"}}
    assert parse("press up on the tv") == {"tool": "tv_button", "args": {"button": "up"}}
    assert parse("press home on the tv") == {"tool": "tv_button", "args": {"button": "home"}}
    assert parse("switch the tv to hdmi 2") == {"tool": "tv_set_input", "args": {"input": "hdmi 2"}}
    assert parse("switch the tv input to gaming pc") == {"tool": "tv_set_input", "args": {"input": "gaming pc"}}
    assert parse("open netflix on the tv") == {"tool": "tv_launch_app", "args": {"app": "netflix"}}
    assert parse("put on disney plus on the tv") == {"tool": "tv_launch_app", "args": {"app": "disney plus"}}
    assert parse("is youtube on the tv") == {"tool": "tv_search_apps", "args": {"query": "youtube"}}
    assert parse("what apps are on the tv") == {"tool": "tv_search_apps", "args": {"query": ""}}
    assert parse("is the tv on") == {"tool": "tv_status", "args": {}}
    assert parse("type stranger things on the tv") == {
        "tool": "tv_type_text", "args": {"text": "stranger things", "submit": False}
    }
    assert parse("type dune part two into the tv and press enter") == {
        "tool": "tv_type_text", "args": {"text": "dune part two", "submit": True}
    }
    assert parse("type breaking bad on the tv and search") == {
        "tool": "tv_type_text", "args": {"text": "breaking bad", "submit": True}
    }
    # typing must not shadow launches, buttons, or searches
    assert parse("open netflix on the tv")["tool"] == "tv_launch_app"
    assert parse("press ok on the tv")["tool"] == "tv_button"


def test_tv_does_not_shadow_other_devices():
    # lights, YouTube media, timers and reminders keep their meanings
    assert parse("turn on the bedroom light")["tool"] == "set_govee_power"
    assert parse("play blinding lights")["tool"] == "play_youtube"
    assert parse("volume up")["tool"] == "set_youtube_volume"
    assert parse("mute")["tool"] == "mute_youtube"
    assert parse("pause")["tool"] == "pause_youtube"
    assert parse("remind me to turn off the tv at 9 pm")["tool"] == "set_reminder"
    # and nonsense TV-ish phrases stay out of grammar
    assert parse("tv do something weird") is None
