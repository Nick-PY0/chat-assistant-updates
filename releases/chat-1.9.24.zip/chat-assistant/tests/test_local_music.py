from __future__ import annotations

import asyncio
import io
import os
from pathlib import Path

import pytest

import chat_core.music.local_library as local_library
from chat_core.music.local_library import LocalMusicLibrary, LocalMusicLibraryError
from chat_core.models.music import MusicStore


class FakeMusicStore:
    def __init__(self):
        self.roots = {}
        self.tracks = {}
        self.generations = {}
        self.replacements = []

    async def add_local_root(self, **root):
        root["count"] = 0
        self.roots[root["id"]] = root
        return root

    async def get_local_root(self, root_id):
        return self.roots.get(root_id)

    async def list_local_roots(self):
        return list(self.roots.values())

    async def begin_local_root_scan(self, root_id):
        self.generations[root_id] = self.generations.get(root_id, 0) + 1
        self.roots[root_id]["status"] = "scanning"
        return self.generations[root_id]

    async def set_local_root_status(self, root_id, generation, status, count):
        if generation == self.generations[root_id]:
            self.roots[root_id].update(status=status, count=count)

    async def replace_local_tracks(self, root_id, generation, tracks):
        if generation != self.generations[root_id]:
            return False
        self.tracks = {k: v for k, v in self.tracks.items() if v["root_id"] != root_id}
        self.tracks.update({track["id"]: track for track in tracks})
        self.replacements.append(generation)
        return True

    async def list_local_tracks(self, root_id, offset, limit):
        rows = [t for t in self.tracks.values() if root_id is None or t["root_id"] == root_id]
        return rows[offset : offset + limit]

    async def search_local_tracks(self, query, root_id, limit):
        query = query.casefold()
        rows = await self.list_local_tracks(root_id, 0, 1000)
        return [
            row for row in rows
            if query in " ".join((row["title"], row["artist"], row["album"])).casefold()
        ][:limit]

    async def get_local_track(self, item_id):
        return self.tracks.get(item_id)


class FakeWindowsHandle:
    def __init__(self, path, info, content=b""):
        self.path = Path(path)
        self.info = info
        self.content = content
        self.closed = False


class FakeWindowsFileSystem:
    """Deterministic stand-in for the native handle wrapper on Linux."""

    def __init__(self, root, *, root_identity=(7, 11)):
        self.root = Path(root)
        self.entries = {
            self.root: {
                "info": local_library._WindowsFileInfo(
                    *root_identity, 0x10, 0, 100
                ),
                "children": [],
                "content": b"",
            }
        }
        self.current_root_identity = root_identity
        self.stream_calls = 0

    def add_directory(self, relative, *, reparse=False, identity=(7, 12)):
        self._add(relative, b"", 0x10 | (0x400 if reparse else 0), identity)

    def add_file(self, relative, content=b"audio", *, reparse=False, identity=(7, 13)):
        self._add(relative, content, 0x400 if reparse else 0, identity)

    def _add(self, relative, content, attributes, identity):
        path = self.root.joinpath(*relative.split("/"))
        parent = path.parent
        self.entries[path] = {
            "info": local_library._WindowsFileInfo(
                *identity, attributes, len(content), 200
            ),
            "children": [],
            "content": content,
        }
        self.entries[parent]["children"].append(path.name)

    def _handle(self, path):
        entry = self.entries[Path(path)]
        return FakeWindowsHandle(path, entry["info"], entry["content"])

    def open_root(self, path):
        handle = self._handle(path)
        if handle.info.is_reparse or not handle.info.is_directory:
            raise LocalMusicLibraryError("music root is not a safe directory")
        # Model the native wrapper checking every configured path component.
        if handle.info.identity != self.current_root_identity:
            handle.info = local_library._WindowsFileInfo(
                *self.current_root_identity,
                handle.info.attributes,
                handle.info.size,
                handle.info.mtime_ns,
            )
        return handle

    def assert_current(self, handle):
        current = self.entries[handle.path]["info"].identity
        if current != handle.info.identity:
            raise LocalMusicLibraryError("local music directory changed while open")

    def open_child(self, parent, name):
        self.assert_current(parent)
        handle = self._handle(parent.path / name)
        if handle.info.is_reparse:
            raise LocalMusicLibraryError("reparse points are not allowed in music roots")
        self.assert_current(parent)
        return handle

    def names(self, directory):
        self.assert_current(directory)
        return list(self.entries[directory.path]["children"])

    def stream(self, handle):
        self.stream_calls += 1
        return io.BytesIO(handle.content)

    def close(self, handle):
        handle.closed = True


@pytest.fixture
def library(db, vault):
    store = FakeMusicStore()
    return LocalMusicLibrary(db, vault, store), store


@pytest.mark.asyncio
async def test_scan_supported_formats_off_loop_and_hides_root(tmp_path, library, monkeypatch):
    engine, store = library
    root = tmp_path / "private-library"
    (root / "Artist" / "Album").mkdir(parents=True)
    for extension in ("mp3", "m4a", "aac", "ogg", "flac", "wav"):
        (root / "Artist" / "Album" / f"Artist - Song {extension}.{extension}").write_bytes(b"audio")
    (root / "not-a-song.txt").write_text("no")
    public = await engine.setup_root(str(root))
    assert set(public) == {"id", "label", "count", "status"}
    assert str(root) not in repr(public)
    assert str(root).encode() not in store.roots[public["id"]]["encrypted_path"]

    called = False
    original = asyncio.to_thread

    async def observed(func, *args, **kwargs):
        nonlocal called
        called = True
        return await original(func, *args, **kwargs)

    monkeypatch.setattr(asyncio, "to_thread", observed)
    result = await engine.scan(public["id"])
    assert called
    assert result["count"] == 6
    assert {track["mime"] for track in store.tracks.values()} == {
        "audio/mpeg", "audio/mp4", "audio/aac", "audio/ogg", "audio/flac", "audio/wav"
    }
    assert str(root) not in repr(await engine.list())


@pytest.mark.asyncio
async def test_rejects_relative_missing_and_symlink_roots(tmp_path, library):
    engine, _store = library
    with pytest.raises(LocalMusicLibraryError):
        await engine.setup_root("relative")
    with pytest.raises(LocalMusicLibraryError):
        await engine.setup_root(str(tmp_path / "missing"))
    target = tmp_path / "target"
    target.mkdir()
    link = tmp_path / "link"
    try:
        link.symlink_to(target, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks unavailable")
    with pytest.raises(LocalMusicLibraryError):
        await engine.setup_root(str(link))


@pytest.mark.asyncio
async def test_scan_ignores_symlink_escape(tmp_path, library):
    engine, store = library
    root, outside = tmp_path / "root", tmp_path / "outside"
    root.mkdir()
    outside.mkdir()
    (outside / "secret.mp3").write_bytes(b"secret")
    try:
        (root / "escape").symlink_to(outside, target_is_directory=True)
        (root / "file.mp3").symlink_to(outside / "secret.mp3")
    except (OSError, NotImplementedError):
        pytest.skip("symlinks unavailable")
    configured = await engine.setup_root(str(root))
    await engine.scan(configured["id"])
    assert not store.tracks


@pytest.mark.asyncio
async def test_resolve_rejects_traversal_and_modified_file(tmp_path, library):
    engine, store = library
    root = tmp_path / "root"
    root.mkdir()
    song = root / "song.mp3"
    song.write_bytes(b"first")
    configured = await engine.setup_root(str(root))
    await engine.scan(configured["id"])
    item_id = next(iter(store.tracks))
    store.tracks[item_id]["relative_path"] = "../outside.mp3"
    with pytest.raises(LocalMusicLibraryError):
        await engine.resolve_for_stream(item_id)
    store.tracks[item_id]["relative_path"] = "song.mp3"
    song.write_bytes(b"modified and longer")
    with pytest.raises(LocalMusicLibraryError, match="changed"):
        await engine.resolve_for_stream(item_id)


@pytest.mark.asyncio
async def test_stream_rejects_replaced_root_or_symlinked_ancestor(tmp_path, library):
    engine, store = library
    parent = tmp_path / "configured-parent"
    root = parent / "music"
    root.mkdir(parents=True)
    song = root / "song.mp3"
    song.write_bytes(b"indexed-audio")
    configured = await engine.setup_root(str(root))
    await engine.scan(configured["id"])
    item_id = next(iter(store.tracks))

    original_parent = tmp_path / "original-parent"
    parent.rename(original_parent)
    replacement = parent / "music"
    replacement.mkdir(parents=True)
    impostor = replacement / "song.mp3"
    impostor.write_bytes(b"outside-data!")
    original_stat = (original_parent / "music" / "song.mp3").stat()
    os.utime(impostor, ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns))
    with pytest.raises(LocalMusicLibraryError, match="root changed"):
        await engine.open_for_stream(item_id)

    for child in replacement.iterdir():
        child.unlink()
    replacement.rmdir()
    parent.rmdir()
    try:
        parent.symlink_to(original_parent, target_is_directory=True)
    except (OSError, NotImplementedError):
        return
    with pytest.raises(LocalMusicLibraryError):
        await engine.open_for_stream(item_id)


@pytest.mark.asyncio
async def test_windows_handle_branch_scans_and_streams_valid_file(
    tmp_path, library, monkeypatch
):
    engine, store = library
    root = tmp_path / "windows-library"
    root.mkdir()
    windows = FakeWindowsFileSystem(root)
    windows.add_directory("Artist")
    windows.add_file("Artist/Artist - Song.mp3", b"native-audio")
    monkeypatch.setattr(local_library, "_WINDOWS", True)
    monkeypatch.setattr(
        local_library, "_WINDOWS_FILESYSTEM_FACTORY", lambda: windows
    )

    configured = await engine.setup_root(str(root), "Private")
    assert str(root) not in repr(configured)
    assert await engine.scan(configured["id"]) == {
        "id": configured["id"],
        "status": "ready",
        "count": 1,
    }
    item_id = next(iter(store.tracks))
    source, public = await engine.open_for_stream(item_id)
    try:
        assert source.read() == b"native-audio"
        assert public["size"] == len(b"native-audio")
        assert str(root) not in repr(public)
    finally:
        source.close()
    assert windows.stream_calls == 1


@pytest.mark.asyncio
async def test_windows_scan_rejects_reparse_entries(tmp_path, library, monkeypatch):
    engine, store = library
    root = tmp_path / "windows-library"
    root.mkdir()
    windows = FakeWindowsFileSystem(root)
    windows.add_directory("junction", reparse=True)
    windows.add_file("linked.mp3", reparse=True)
    monkeypatch.setattr(local_library, "_WINDOWS", True)
    monkeypatch.setattr(
        local_library, "_WINDOWS_FILESYSTEM_FACTORY", lambda: windows
    )

    configured = await engine.setup_root(str(root))
    assert (await engine.scan(configured["id"]))["count"] == 0
    assert store.tracks == {}


@pytest.mark.asyncio
async def test_windows_rejects_root_identity_mismatch(
    tmp_path, library, monkeypatch
):
    engine, _store = library
    root = tmp_path / "windows-library"
    root.mkdir()
    windows = FakeWindowsFileSystem(root)
    windows.add_file("song.mp3")
    monkeypatch.setattr(local_library, "_WINDOWS", True)
    monkeypatch.setattr(
        local_library, "_WINDOWS_FILESYSTEM_FACTORY", lambda: windows
    )

    configured = await engine.setup_root(str(root))
    windows.current_root_identity = (7, 999)
    with pytest.raises(LocalMusicLibraryError, match="root changed"):
        await engine.scan(configured["id"])


def test_windows_stream_open_rejects_traversal_and_fences_open_handle(
    tmp_path, monkeypatch
):
    root = tmp_path / "windows-library"
    root.mkdir()
    windows = FakeWindowsFileSystem(root)
    windows.add_file("song.mp3", b"indexed")
    monkeypatch.setattr(local_library, "_WINDOWS", True)
    monkeypatch.setattr(
        local_library, "_WINDOWS_FILESYSTEM_FACTORY", lambda: windows
    )

    with pytest.raises(LocalMusicLibraryError, match="invalid"):
        local_library._open_track_descriptor(
            root, "../outside.mp3", 100, 7, 200, 7, 11
        )
    source = local_library._open_track_descriptor(
        root, "song.mp3", 100, 7, 200, 7, 11
    )
    # Replacing the path after open cannot redirect the already-open stream.
    windows.entries[root / "song.mp3"]["content"] = b"replaced"
    try:
        assert source.read() == b"indexed"
    finally:
        source.close()


def test_windows_stream_rechecks_ancestor_identity_before_handoff(
    tmp_path, monkeypatch
):
    root = tmp_path / "windows-library"
    root.mkdir()
    windows = FakeWindowsFileSystem(root)
    windows.add_directory("Album")
    windows.add_file("Album/song.mp3", b"indexed")

    # The implementation's final root fence runs before ownership is handed
    # to stream(), so force a replacement during that final fence.
    checks = 0
    original_assert_current = windows.assert_current

    def fenced_assert_current(handle):
        nonlocal checks
        checks += 1
        if handle.path == root and checks >= 5:
            windows.entries[root]["info"] = local_library._WindowsFileInfo(
                7, 404, 0x10, 0, 100
            )
        original_assert_current(handle)

    windows.assert_current = fenced_assert_current
    monkeypatch.setattr(local_library, "_WINDOWS", True)
    monkeypatch.setattr(
        local_library, "_WINDOWS_FILESYSTEM_FACTORY", lambda: windows
    )

    with pytest.raises(LocalMusicLibraryError, match="changed"):
        local_library._open_track_descriptor(
            root, "Album/song.mp3", 100, 7, 200, 7, 11
        )
    assert windows.stream_calls == 0


@pytest.mark.asyncio
async def test_newer_scan_fences_stale_generation(tmp_path, library, monkeypatch):
    engine, store = library
    root = tmp_path / "root"
    root.mkdir()
    (root / "song.mp3").write_bytes(b"x")
    configured = await engine.setup_root(str(root))
    real_to_thread = asyncio.to_thread
    first_started = asyncio.Event()
    release_first = asyncio.Event()
    calls = 0

    async def controlled(func, *args, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 1:
            first_started.set()
            await release_first.wait()
        return await real_to_thread(func, *args, **kwargs)

    monkeypatch.setattr(asyncio, "to_thread", controlled)
    stale = asyncio.create_task(engine.scan(configured["id"]))
    await first_started.wait()
    fresh = await engine.scan(configured["id"])
    release_first.set()
    stale_result = await stale
    assert fresh["status"] == "ready"
    assert stale_result["status"] == "stale"
    assert store.replacements == [2]


@pytest.mark.asyncio
async def test_cancelled_scan_never_publishes(tmp_path, library, monkeypatch):
    engine, store = library
    root = tmp_path / "root"
    root.mkdir()
    (root / "song.wav").write_bytes(b"x")
    configured = await engine.setup_root(str(root))
    entered = asyncio.Event()
    blocker = asyncio.Event()

    async def blocked_to_thread(func, *args, **kwargs):
        entered.set()
        await blocker.wait()
        return func(*args, **kwargs)

    monkeypatch.setattr(asyncio, "to_thread", blocked_to_thread)
    task = asyncio.create_task(engine.scan(configured["id"]))
    await entered.wait()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task
    blocker.set()
    assert store.replacements == []
    assert store.tracks == {}


@pytest.mark.asyncio
async def test_integrates_with_music_store(db, vault, tmp_path):
    root = tmp_path / "library"
    root.mkdir()
    song = root / "Real Artist - Real Song.flac"
    song.write_bytes(b"flac")
    engine = LocalMusicLibrary(db, vault, MusicStore(db, vault))
    configured = await engine.setup_root(str(root), "Private")
    assert await engine.scan(configured["id"]) == {
        "id": configured["id"], "status": "ready", "count": 1
    }
    found = await engine.search("Real Song")
    assert len(found) == 1
    path, metadata = await engine.resolve_for_stream(found[0]["id"])
    assert path == song
    assert metadata["title"] == "Real Song"
    roots = await engine.list_roots()
    assert roots == [
        {"id": configured["id"], "label": "Private", "count": 1, "status": "ready"}
    ]
    assert str(root) not in repr(roots + found)