from __future__ import annotations

import hashlib
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qs, urlparse

import httpx
import pytest

from chat_core.models.spotify_account import SpotifyAccountStore
from integrations.spotify import SpotifyClient, SpotifyError


NOW = datetime(2030, 1, 1, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_encrypted_account_and_oauth_pkce(db, vault):
    store = SpotifyAccountStore(db, vault, lambda: NOW)
    await store.configure("client-raw", "secret-raw")
    await store.save_tokens("access-raw", "refresh-raw", NOW + timedelta(hours=1), SCOPES)
    row = await db.fetchone("SELECT * FROM connected_accounts WHERE provider='spotify'")
    for raw, field in (
        ("client-raw", "encrypted_client_id"),
        ("secret-raw", "encrypted_client_secret"),
        ("access-raw", "encrypted_access_token"),
        ("refresh-raw", "encrypted_refresh_token"),
    ):
        assert raw.encode() not in bytes(row[field])
    client = SpotifyClient(store, http=httpx.AsyncClient(transport=httpx.MockTransport(
        lambda request: httpx.Response(500))))
    url, state = await client.authorization_url("https://app.example/callback", "browser")
    query = parse_qs(urlparse(url).query)
    assert query["code_challenge_method"] == ["S256"]
    pending = await db.fetchone("SELECT * FROM oauth_pending WHERE provider='spotify'")
    assert pending["state_hash"] == hashlib.sha256(state.encode()).hexdigest()
    await client.http.aclose()


SCOPES = ["user-read-private"]


@pytest.mark.asyncio
async def test_refresh_devices_search_and_transfer(db, vault):
    store = SpotifyAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_tokens("expired", "refresh", NOW - timedelta(seconds=1), SCOPES)
    requests = []

    async def handler(request):
        requests.append(request)
        if request.url.path.endswith("/api/token"):
            return httpx.Response(200, json={"access_token": "fresh", "expires_in": 3600})
        if request.url.path.endswith("/devices"):
            return httpx.Response(200, json={"devices": [{"id": "raw-device-id",
                "name": "Kitchen", "type": "Speaker", "is_active": True,
                "supports_volume": True, "volume_percent": 30}]})
        if request.url.path.endswith("/search"):
            return httpx.Response(200, json={"tracks": {"items": [{"id": "t1",
                "name": "Song", "artists": [{"name": "Artist"}],
                "album": {"name": "Album", "images": []}, "duration_ms": 123,
                "uri": "spotify:track:t1"}]}, "playlists": {"items": []}})
        return httpx.Response(204)

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    client = SpotifyClient(store, http=http, clock=lambda: NOW)
    devices = await client.devices()
    assert devices[0]["ref"].startswith("spotify-device-")
    assert "raw-device-id" not in str(devices)
    found = await client.search("  Song   Artist ", limit=1000)
    assert found["tracks"][0]["artists"] == ["Artist"]
    await client.transfer(devices[0]["ref"], play=True)
    transfer = requests[-1]
    assert transfer.url.path.endswith("/me/player")
    assert b"raw-device-id" in transfer.content
    assert (await store.secrets()).access_token == "fresh"
    await http.aclose()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "status,body,code",
    [
        (403, {"error": {"message": "Premium required"}}, "premium_required"),
        (403, {"error": {"message": "Restriction violated"}}, "playback_restricted"),
        (404, {}, "unavailable_device"),
        (429, {}, "rate_limited"),
        (503, {}, "transient_failure"),
    ],
)
async def test_provider_errors_are_truthful(db, vault, status, body, code):
    store = SpotifyAccountStore(db, vault, lambda: NOW)
    await store.configure("client", "secret")
    await store.save_tokens("token", "refresh", NOW + timedelta(hours=1), SCOPES)
    http = httpx.AsyncClient(transport=httpx.MockTransport(
        lambda request: httpx.Response(status, json=body, headers={"Retry-After": "4"})))
    client = SpotifyClient(store, http=http, clock=lambda: NOW)
    with pytest.raises(SpotifyError) as caught:
        await client._request("GET", "/me")
    assert caught.value.code == code
    await http.aclose()