from __future__ import annotations

import json
import os
import re
from html.parser import HTMLParser
from pathlib import Path

import httpx
import pytest

from apps.dashboard.app import COOKIE, create_app
from chat_core.music.local_library import LocalMusicLibraryError
from chat_core.runtime import Runtime


@pytest.fixture
async def music_rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    async def no_devices():
        return []
    runtime.spotify.discover_devices = no_devices
    runtime.spotify.devices = no_devices
    yield runtime
    await runtime.stop()


@pytest.fixture
async def music_client(music_rt):
    app = create_app(music_rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        client.app = app
        response = await client.post(
            "/setup", data={"password": "music-password-123", "confirm": "music-password-123"}
        )
        assert response.status_code == 303
        yield client


def csrf(client):
    return client.app.state.sessions.csrf_for(client.cookies.get(COOKIE))


@pytest.mark.asyncio
@pytest.mark.parametrize("path", [
    "/api/music/claim", "/api/music/release", "/api/music/search", "/api/music/play",
    "/api/music/control", "/api/music/report", "/api/music/queue",
    "/api/music/favorites", "/api/music/playlists", "/api/music/rooms",
    "/api/music/library", "/api/spotify/oauth/start", "/api/spotify/disconnect",
])
async def test_every_music_mutation_family_requires_auth_and_csrf(music_rt, music_client, path):
    unauth = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=music_client.app), base_url="http://test"
    )
    try:
        assert (await unauth.post(path, json={})).status_code == 401
    finally:
        await unauth.aclose()
    assert (await music_client.post(path, json={})).status_code == 403


@pytest.mark.asyncio
async def test_spotify_status_is_safe_and_setup_is_loopback_only(music_client):
    status = await music_client.get("/api/spotify/status")
    assert status.status_code == 200
    text = status.text.lower()
    assert "client_secret" not in text and "access_token" not in text and "refresh_token" not in text
    remote = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=music_client.app, client=("192.168.1.20", 1234)),
        base_url="http://test",
        cookies=music_client.cookies,
    )
    try:
        response = await remote.post(
            "/api/spotify/oauth/start", json={"client_id": "raw-client", "client_secret": "raw-secret"},
            headers={"x-csrf": csrf(music_client)},
        )
        assert response.status_code == 403
        assert "raw-client" not in response.text and "raw-secret" not in response.text
    finally:
        await remote.aclose()


@pytest.mark.asyncio
async def test_local_setup_and_snapshot_never_disclose_paths(music_client, tmp_path):
    root = tmp_path / "private-music-root"
    root.mkdir()
    (root / "Artist - Song.mp3").write_bytes(b"0123456789")
    response = await music_client.post(
        "/api/music/library",
        json={"action": "add", "path": str(root), "label": "My music"},
        headers={"x-csrf": csrf(music_client)},
    )
    assert response.status_code == 200
    snapshot = await music_client.get("/api/music")
    combined = response.text + snapshot.text
    assert str(root) not in combined
    assert "Artist - Song.mp3" not in combined
    assert response.json()["root"]["label"] == "My music"


@pytest.mark.asyncio
async def test_authenticated_local_stream_supports_200_206_416_and_rejects_unauth(
    music_client, tmp_path
):
    root = tmp_path / "stream-root"
    root.mkdir()
    content = b"0123456789"
    (root / "Track.mp3").write_bytes(content)
    configured = await music_client.post(
        "/api/music/library", json={"action": "add", "path": str(root)},
        headers={"x-csrf": csrf(music_client)},
    )
    assert configured.status_code == 200
    listing = await music_client.post(
        "/api/music/library", json={"action": "tracks"},
        headers={"x-csrf": csrf(music_client)},
    )
    item_id = listing.json()["tracks"][0]["id"]
    url = f"/api/music/local/{item_id}"
    whole = await music_client.get(url)
    assert whole.status_code == 200 and whole.content == content
    assert whole.headers["accept-ranges"] == "bytes"
    partial = await music_client.get(url, headers={"range": "bytes=2-5"})
    assert partial.status_code == 206 and partial.content == b"2345"
    assert partial.headers["content-range"] == "bytes 2-5/10"
    invalid = await music_client.get(url, headers={"range": "bytes=99-100"})
    assert invalid.status_code == 416 and invalid.headers["content-range"] == "bytes */10"
    anonymous = httpx.AsyncClient(
        transport=httpx.ASGITransport(app=music_client.app), base_url="http://test"
    )
    try:
        assert (await anonymous.get(url)).status_code == 401
    finally:
        await anonymous.aclose()


@pytest.mark.asyncio
async def test_generic_music_endpoints_preserve_legacy_media_contract(music_client):
    headers = {"x-csrf": csrf(music_client)}
    legacy = await music_client.get("/api/media")
    assert legacy.status_code == 200
    before_keys = set(legacy.json())
    search = await music_client.post(
        "/api/music/search", json={"query": "test", "provider": "local"}, headers=headers
    )
    assert search.status_code == 200
    assert (await music_client.get("/api/music")).status_code == 200
    after = await music_client.get("/api/media")
    assert after.status_code == 200
    assert set(after.json()) == before_keys
    assert "/api/media" not in json.dumps((await music_client.get("/api/music")).json())


async def _indexed_track(runtime, root: Path, content: bytes = b"inside-original"):
    root.mkdir()
    track_path = root / "Track.mp3"
    track_path.write_bytes(content)
    configured = await runtime.local_music.setup_root(str(root))
    await runtime.local_music.scan(configured["id"])
    track = (await runtime.local_music.list())[0]
    return track_path, track


@pytest.mark.asyncio
async def test_open_for_stream_fd_cannot_be_redirected_by_post_open_swap(
    music_rt, tmp_path
):
    original = b"inside-original"
    outside = tmp_path / "outside.mp3"
    outside.write_bytes(b"outside-attacker")
    track_path, track = await _indexed_track(music_rt, tmp_path / "root-after", original)
    source, public = await music_rt.local_music.open_for_stream(track["id"])
    try:
        track_path.unlink()
        track_path.symlink_to(outside)
        assert source.read() == original
        assert public["size"] == len(original)
    finally:
        source.close()


@pytest.mark.asyncio
async def test_open_for_stream_rejects_symlink_swapped_before_open(music_rt, tmp_path):
    outside = tmp_path / "outside.mp3"
    outside.write_bytes(b"outside")
    track_path, track = await _indexed_track(
        music_rt, tmp_path / "root-before", b"indexed"
    )
    track_path.unlink()
    track_path.symlink_to(outside)
    with pytest.raises(LocalMusicLibraryError):
        await music_rt.local_music.open_for_stream(track["id"])


@pytest.mark.asyncio
async def test_dashboard_range_stream_uses_already_open_descriptor(
    music_client, music_rt, tmp_path, monkeypatch
):
    content = b"0123456789"
    _path, track = await _indexed_track(music_rt, tmp_path / "fd-route", content)
    original_open = music_rt.local_music.open_for_stream
    calls = []

    async def observed(item_id):
        calls.append(item_id)
        return await original_open(item_id)

    async def forbidden_resolve(_item_id):
        raise AssertionError("stream route must not resolve a path and reopen it")

    monkeypatch.setattr(music_rt.local_music, "open_for_stream", observed)
    monkeypatch.setattr(music_rt.local_music, "resolve_for_stream", forbidden_resolve)
    response = await music_client.get(
        f"/api/music/local/{track['id']}", headers={"range": "bytes=3-6"}
    )
    assert response.status_code == 206
    assert response.content == b"3456"
    assert calls == [track["id"]]


class _IdCollector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if "id" in values:
            self.ids.append(values["id"])


def test_media_dom_ids_are_unique_and_queue_selectors_remain_distinct():
    root = Path(__file__).resolve().parents[1]
    markup = (root / "apps/dashboard/templates/media.html").read_text()
    script = (root / "apps/dashboard/static/media.js").read_text()
    parser = _IdCollector()
    parser.feed(markup)
    duplicates = sorted({value for value in parser.ids if parser.ids.count(value) > 1})
    assert duplicates == []
    assert {"media-queue", "music-queue"}.issubset(parser.ids)
    assert re.search(r'const\s+queueEl\s*=\s*\$\("media-queue"\)', script)
    assert re.search(r'const\s+musicQueue\s*=\s*\$\("music-queue"\)', script)


def test_generic_paused_music_play_button_emits_resume():
    root = Path(__file__).resolve().parents[1]
    script = (root / "apps/dashboard/static/media.js").read_text()
    handler = re.search(
        r'playPauseButton\.addEventListener\("click",\s*\(\)\s*=>\s*\{'
        r'(?P<body>.*?)\n\s*\}\);',
        script,
        re.DOTALL,
    )
    assert handler is not None
    body = handler.group("body")
    assert "musicPlaybackActive()" in body
    assert 'musicState.status === "paused"' in body
    assert 'action: paused ? "resume" : "pause"' in body