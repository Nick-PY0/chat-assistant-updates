"""Client for the owner's relay on Replit -- the doorway to the second brain.

The relay holds no state and stores nothing; every call carries one turn.
Every request is authenticated with the relay password, which lives in the
laptop's encrypted vault like every other credential.
"""

from __future__ import annotations

import base64
import hashlib
import io
import inspect
import re
import struct
import time
import wave
from dataclasses import dataclass

import httpx

DEFAULT_TIMEOUT = 60.0  # voice turns carry audio both ways; give them room
DISCOVERY_TTL_SECONDS = 60.0


@dataclass(frozen=True)
class RelayModel:
    id: str
    job: str
    tier: str
    rank: int
    cost_rank: int
    reasoning: bool
    tools: bool
    modalities: tuple[str, ...]
    label: str = ""


@dataclass(frozen=True)
class RelayDiscovery:
    models: tuple[RelayModel, ...]
    defaults: dict[str, str]
    voices: tuple[str, ...] = ()


_HOUSEHOLD_RE = re.compile(
    r"\b(timer|timers|remind|reminder|alarm|light|lights|lamp|quiet|mute|"
    r"stop|cancel|pause|resume|weather|temperature|forecast|time|date)\b",
    re.IGNORECASE,
)
_COMMAND_INTENT_RE = re.compile(
    r"^(?:(?:please|could you|can you|would you)\s+)?"
    r"(?:set|start|stop|cancel|pause|resume|turn|switch|dim|mute|unmute|"
    r"remind|check|show|tell me)\b|"
    r"^(?:what(?:'s| is)|how(?:'s| is))\s+(?:the\s+)?"
    r"(?:time|date|weather|temperature|forecast)\b|"
    r"^(?:the\s+)?(?:lights?|lamp)\s+(?:on|off)\b",
    re.IGNORECASE,
)
_COMPLEX_RE = re.compile(
    r"\b(analy[sz]e|evaluate|derive|prove|debug|architect|trade-?offs?|"
    r"step[- ]by[- ]step|compare and contrast|root cause|strategy)\b",
    re.IGNORECASE,
)


def classify_turn(text: str) -> str:
    """Deterministically classify routing intent without making a paid call."""
    clean = " ".join(str(text or "").split())
    words = re.findall(r"\b[\w'-]+\b", clean)
    if (len(words) <= 18 and _HOUSEHOLD_RE.search(clean)
            and _COMMAND_INTENT_RE.search(clean)):
        return "command"
    if (_COMPLEX_RE.search(clean)
            or len(words) >= 36
            or (clean.count("?") >= 2 and len(words) >= 20)):
        return "complex"
    return "normal"


def select_models(
    discovery: RelayDiscovery,
    text: str,
    *,
    needs_tools: bool,
    configured_command: str = "",
    configured_chat: str = "",
) -> list[str]:
    """Return a bounded, compatible route in preferred then fallback order."""
    kind = classify_turn(text)
    compatible = [
        model for model in discovery.models
        if model.job == "chat" and "text" in model.modalities
        and (model.tools or not needs_tools)
    ]
    if not compatible:
        # Discovery defaults are only preferences, not capability guarantees.
        # Fail closed rather than paying for a request that cannot satisfy this
        # turn's text/tool requirements.
        return []

    if kind == "command":
        pool = [m for m in compatible if m.tier == "low"] or compatible
        primary = sorted(pool, key=lambda m: (m.cost_rank, -m.rank, m.id))
        preferred = configured_command
    elif kind == "complex":
        pool = [m for m in compatible if m.reasoning] or compatible
        primary = sorted(pool, key=lambda m: (-m.rank, m.cost_rank, m.id))
        preferred = ""
    else:
        pool = [m for m in compatible if m.tier == "mid"] or compatible
        primary = sorted(pool, key=lambda m: (-m.rank, m.cost_rank, m.id))
        preferred = configured_chat

    # Preserve an existing configured choice when it belongs to the intended
    # capability class; never trust a configured ID absent from discovery.
    if preferred and any(m.id == preferred for m in pool):
        primary.sort(key=lambda m: m.id != preferred)
    remainder = sorted(
        (model for model in compatible if model not in primary),
        key=lambda m: (-m.rank, m.cost_rank, m.id),
    )
    ordered = primary + remainder
    # At most three paid attempts, and never an incompatible model.
    return [model.id for model in ordered[:3]]


class RelayError(Exception):
    """A relay problem, always phrased so it can be shown to the owner."""


def wrap_wav(pcm: bytes, rate: int, channels: int = 1) -> bytes:
    """PCM16 -> a minimal WAV container (what the relay expects)."""
    header = io.BytesIO()
    data_size = len(pcm)
    byte_rate = rate * channels * 2
    header.write(b"RIFF")
    header.write(struct.pack("<I", 36 + data_size))
    header.write(b"WAVEfmt ")
    header.write(struct.pack("<IHHIIHH", 16, 1, channels, rate, byte_rate, channels * 2, 16))
    header.write(b"data")
    header.write(struct.pack("<I", data_size))
    return header.getvalue() + pcm


def parse_wav(blob: bytes) -> tuple[bytes, int]:
    """WAV bytes -> (pcm16 mono-ish frames, sample rate)."""
    try:
        with wave.open(io.BytesIO(blob), "rb") as wav:
            rate = wav.getframerate()
            frames = wav.readframes(wav.getnframes())
            if wav.getnchannels() == 2:  # fold stereo down so playback stays mono
                mono = bytearray()
                for i in range(0, len(frames) - 3, 4):
                    left = struct.unpack_from("<h", frames, i)[0]
                    right = struct.unpack_from("<h", frames, i + 2)[0]
                    mono += struct.pack("<h", (left + right) // 2)
                frames = bytes(mono)
            return frames, rate
    except (wave.Error, EOFError, struct.error) as exc:
        raise RelayError(f"the relay sent audio that could not be read: {exc}") from exc


class RelayClient:
    """Thin async HTTP client for the relay routes."""

    _discovery_cache: dict[tuple[str, str], tuple[float, RelayDiscovery]] = {}

    def __init__(self, base_url: str, secret: str, timeout: float = DEFAULT_TIMEOUT,
                 transport: httpx.AsyncBaseTransport | None = None,
                 on_event=None) -> None:
        base = (base_url or "").strip().rstrip("/")
        if base and not base.startswith(("http://", "https://")):
            base = "https://" + base
        if base.startswith("http://"):
            raise RelayError(
                "the relay address must start with https:// -- over plain "
                "http the relay password would travel unprotected")
        # The relay mounts under /api on the server.
        if base and not base.endswith("/api"):
            base = base + "/api"
        self.base = base
        self._secret = secret
        self._timeout = timeout
        self._transport = transport  # tests inject a fake network here
        self._on_event = on_event
        self._cache_key = (base, hashlib.sha256(secret.encode()).hexdigest())

    def emit_event(self, event: dict) -> None:
        if not self._on_event:
            return
        try:
            result = self._on_event(event)
            if inspect.isawaitable(result):
                # Timing hooks must not hold up the user-facing request.
                import asyncio
                task = asyncio.create_task(result)
                task.add_done_callback(
                    lambda done: done.exception() if not done.cancelled() else None
                )
        except Exception:
            # Observability is optional and must never break a chat turn.
            pass

    def _headers(self) -> dict:
        return {"x-chat-relay-key": self._secret}

    async def _post(self, path: str, payload: dict) -> dict:
        if not self.base:
            raise RelayError("no relay address is set (Settings -> Brain).")
        started = time.monotonic()
        try:
            async with httpx.AsyncClient(timeout=self._timeout, transport=self._transport) as client:
                resp = await client.post(self.base + path, json=payload, headers=self._headers())
        except httpx.HTTPError as exc:
            self.emit_event({"event": "relay", "operation": path, "ok": False,
                             "duration_ms": round((time.monotonic() - started) * 1000, 1)})
            raise RelayError(f"the relay could not be reached: {exc}") from exc
        data = self._decode(resp)
        duration_ms = round((time.monotonic() - started) * 1000, 1)
        self.emit_event({"event": "relay", "operation": path, "ok": True,
                         "model": data.get("model"), "duration_ms": duration_ms})
        if path == "/relay/ask":
            self.emit_event({"event": "provider", "provider": "relay",
                             "model": data.get("model"), "duration_ms": duration_ms})
        return data

    async def _get(self, path: str) -> dict:
        if not self.base:
            raise RelayError("no relay address is set (Settings -> Brain).")
        try:
            async with httpx.AsyncClient(timeout=15.0, transport=self._transport) as client:
                resp = await client.get(self.base + path, headers=self._headers())
        except httpx.HTTPError as exc:
            raise RelayError(f"the relay could not be reached: {exc}") from exc
        return self._decode(resp)

    @staticmethod
    def _decode(resp: httpx.Response) -> dict:
        if resp.status_code == 401:
            raise RelayError("the relay refused the password (check Providers -> Relay).")
        if resp.status_code == 503:
            raise RelayError("the relay is up but has no password set on the server side.")
        try:
            data = resp.json()
        except ValueError:
            data = {}
        if resp.status_code >= 400:
            raise RelayError(str(data.get("error") or f"relay error (HTTP {resp.status_code})"))
        if not isinstance(data, dict):
            raise RelayError("the relay sent something that was not JSON.")
        return data

    # -- the four calls Chat makes ------------------------------------
    async def health(self) -> None:
        await self._get("/relay/health")

    async def models(self) -> dict:
        discovery = await self.discover_models()
        groups: dict[str, list[dict]] = {}
        for model in discovery.models:
            groups.setdefault(model.job, []).append({
                "id": model.id,
                "label": model.label,
                "job": model.job,
                "tier": model.tier,
                "rank": model.rank,
                "costRank": model.cost_rank,
                "reasoning": model.reasoning,
                "tools": model.tools,
                "modalities": list(model.modalities),
            })
        return {
            "models": groups,
            "defaults": dict(discovery.defaults),
            "voices": list(discovery.voices),
        }

    async def discover_models(self, force: bool = False) -> RelayDiscovery:
        cached = self._discovery_cache.get(self._cache_key)
        now = time.monotonic()
        if not force and cached and now - cached[0] < DISCOVERY_TTL_SECONDS:
            return cached[1]
        data = await self._get("/relay/models")
        discovery = self._validate_discovery(data)
        self._discovery_cache[self._cache_key] = (now, discovery)
        return discovery

    @staticmethod
    def _validate_discovery(data: dict) -> RelayDiscovery:
        groups = data.get("models")
        defaults = data.get("defaults")
        voices = data.get("voices", [])
        if not isinstance(groups, dict) or not isinstance(defaults, dict):
            raise RelayError("the relay sent invalid model discovery metadata.")
        if (not isinstance(voices, list)
                or not all(isinstance(voice, str) and voice for voice in voices)):
            raise RelayError("the relay sent invalid model discovery metadata.")
        found: list[RelayModel] = []
        seen: set[str] = set()
        jobs_by_id: dict[str, str] = {}
        for job, entries in groups.items():
            if not isinstance(job, str) or not isinstance(entries, list):
                raise RelayError("the relay sent invalid model discovery metadata.")
            for raw in entries:
                if not isinstance(raw, dict):
                    raise RelayError("the relay sent invalid model discovery metadata.")
                model_id = raw.get("id")
                modalities = raw.get("modalities")
                tier = raw.get("tier")
                rank = raw.get("rank")
                cost_rank = raw.get("costRank")
                if (not isinstance(model_id, str) or not model_id or model_id in seen
                        or raw.get("job") != job
                        or tier not in ("low", "mid", "high")
                        or not isinstance(rank, int) or isinstance(rank, bool)
                        or not isinstance(cost_rank, int) or isinstance(cost_rank, bool)
                        or not isinstance(raw.get("reasoning"), bool)
                        or not isinstance(raw.get("tools"), bool)
                        or not isinstance(modalities, list) or not modalities
                        or not all(isinstance(item, str) and item for item in modalities)):
                    raise RelayError("the relay sent invalid model discovery metadata.")
                seen.add(model_id)
                jobs_by_id[model_id] = job
                found.append(RelayModel(
                    model_id, job, tier, rank, cost_rank, raw["reasoning"],
                    raw["tools"], tuple(modalities), str(raw.get("label") or ""),
                ))
        if not found or any(
            not isinstance(job, str) or not isinstance(model_id, str)
            or jobs_by_id.get(model_id) != job
            for job, model_id in defaults.items()
        ):
            raise RelayError("the relay sent invalid model discovery metadata.")
        return RelayDiscovery(tuple(found), dict(defaults), tuple(voices))

    async def transcribe(self, pcm16k: bytes) -> str:
        blob = wrap_wav(pcm16k, 16000)
        data = await self._post("/relay/transcribe", {
            "audio_b64": base64.b64encode(blob).decode(),
        })
        return str(data.get("text", "")).strip()

    # Reasoning models spend tokens thinking before they answer; a small
    # budget can be eaten entirely by thought, leaving an empty reply.
    async def ask(self, messages: list[dict], tools: list[dict], model: str,
                  max_tokens: int = 1600) -> dict:
        return await self._post("/relay/ask", {
            "messages": messages,
            "tools": tools,
            "model": model,
            "max_tokens": max_tokens,
        })

    async def speak(self, text: str, voice: str) -> tuple[bytes, int]:
        data = await self._post("/relay/speak", {"text": text, "voice": voice})
        blob = base64.b64decode(str(data.get("audio_b64", "")) or b"")
        if not blob:
            raise RelayError("the relay sent an empty spoken reply.")
        return parse_wav(blob)
