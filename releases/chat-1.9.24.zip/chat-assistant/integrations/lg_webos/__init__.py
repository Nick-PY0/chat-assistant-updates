"""Local LG WebOS television integration."""

from .manager import WebOSManager, WebOSTVError

__all__ = ["WebOSManager", "WebOSTVError"]