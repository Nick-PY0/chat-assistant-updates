"""SSDP discovery of LG webOS TVs on the local network.

Sends an M-SEARCH for the webOS second-screen service and collects replies
for a bounded window.  Only the responder's IP and (best effort) friendly
name are returned -- discovery never pairs, never stores anything, and a
failure simply yields an empty list plus a clear message upstream.
"""

from __future__ import annotations

import asyncio
import contextlib
import ipaddress
import re
import socket
from urllib.parse import urlsplit

SSDP_ADDR = "239.255.255.250"
SSDP_PORT = 1900
SEARCH_TARGET = "urn:lge-com:service:webos-second-screen:1"
DISCOVER_WINDOW = 3.0
MAX_LOCATION_LEN = 512

_LOCATION_RE = re.compile(rb"^location:\s*(\S+)\s*$", re.IGNORECASE | re.MULTILINE)
_ST_RE = re.compile(rb"^(?:st|nt):\s*(\S+)\s*$", re.IGNORECASE | re.MULTILINE)
_NAME_RE = re.compile(r"<friendlyName>([^<]{1,80})</friendlyName>", re.IGNORECASE)


def _safe_location(location: str, sender_ip: str) -> str:
    """Validate an SSDP LOCATION header, or return "".

    The description URL arrives in an unauthenticated UDP datagram, so it is
    attacker-controllable network input.  It is only trusted when it is plain
    http, carries no credentials, and points at exactly the device that
    answered: an IP literal equal to the UDP sender (never a hostname, never
    loopback/link-local/multicast).  Anything else is dropped so discovery
    can never be steered into other services (SSRF)."""
    if not location or len(location) > MAX_LOCATION_LEN:
        return ""
    try:
        parts = urlsplit(location)
        port = parts.port  # raises ValueError on junk like :99999 or :x
    except ValueError:
        return ""
    if parts.scheme != "http":
        return ""
    if "@" in parts.netloc:  # no user:pass@host tricks
        return ""
    if port is not None and not (1 <= port <= 65535):
        return ""
    try:
        sender = ipaddress.ip_address(sender_ip)
        literal = ipaddress.ip_address(parts.hostname or "")
    except ValueError:
        return ""  # hostnames (or a garbled sender) are never trusted
    if literal != sender:
        return ""
    if (
        literal.is_loopback
        or literal.is_link_local
        or literal.is_multicast
        or literal.is_unspecified
    ):
        return ""
    return location


def parse_ssdp_response(data: bytes, sender_ip: str) -> dict | None:
    """Return {'host', 'location'} for a webOS SSDP reply, else None.
    The location survives only if it passes _safe_location()."""
    if not data.startswith(b"HTTP/1.1 200") and not data.upper().startswith(b"NOTIFY"):
        return None
    st = _ST_RE.search(data)
    if st is None or SEARCH_TARGET.encode() not in st.group(1):
        return None
    loc = _LOCATION_RE.search(data)
    location = loc.group(1).decode("ascii", "ignore") if loc else ""
    return {"host": sender_ip, "location": _safe_location(location, sender_ip)}


class _Collector(asyncio.DatagramProtocol):
    def __init__(self) -> None:
        self.responses: list[tuple[bytes, str]] = []

    def datagram_received(self, data: bytes, addr) -> None:  # type: ignore[override]
        self.responses.append((data, addr[0]))


async def _friendly_name(location: str, sender_ip: str) -> str:
    """Fetch the UPnP description XML for a display name (best effort).
    Re-validates the URL (defense in depth) and never follows redirects,
    so the only request ever made is a plain GET to the TV itself."""
    location = _safe_location(location, sender_ip)
    if not location:
        return ""
    try:
        import httpx

        async with httpx.AsyncClient(timeout=2.0, follow_redirects=False) as client:
            resp = await client.get(location)
            if resp.status_code != 200:
                return ""  # redirects and errors are dropped, never chased
            match = _NAME_RE.search(resp.text[:20000])
            return match.group(1).strip() if match else ""
    except Exception:  # noqa: BLE001 - names are a nicety, never a failure
        return ""


async def discover(window: float = DISCOVER_WINDOW) -> list[dict]:
    """Scan for webOS TVs; returns [{'host', 'name'}] (may be empty)."""
    loop = asyncio.get_running_loop()
    try:
        transport, collector = await loop.create_datagram_endpoint(
            _Collector, family=socket.AF_INET, proto=socket.IPPROTO_UDP
        )
    except OSError:
        return []
    try:
        msearch = (
            "M-SEARCH * HTTP/1.1\r\n"
            f"HOST: {SSDP_ADDR}:{SSDP_PORT}\r\n"
            'MAN: "ssdp:discover"\r\n'
            "MX: 2\r\n"
            f"ST: {SEARCH_TARGET}\r\n\r\n"
        ).encode()
        for _ in range(3):  # repeats survive UDP loss
            with contextlib.suppress(OSError):
                transport.sendto(msearch, (SSDP_ADDR, SSDP_PORT))
            await asyncio.sleep(0.25)
        await asyncio.sleep(max(0.5, window - 0.75))
    finally:
        transport.close()

    found: dict[str, dict] = {}
    for data, sender_ip in collector.responses:
        parsed = parse_ssdp_response(data, sender_ip)
        if parsed is not None and parsed["host"] not in found:
            found[parsed["host"]] = parsed
    results = []
    for host, parsed in found.items():
        name = await _friendly_name(parsed["location"], host) if parsed["location"] else ""
        results.append({"host": host, "name": name or "LG TV"})
    return results
