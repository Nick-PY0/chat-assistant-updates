"""Wake-on-LAN sender (best effort, opt-in).

Powering an LG TV on over the network only works when the TV's own settings
allow it ("Mobile TV On" / networked standby) and the network delivers
broadcast frames.  We therefore treat WoL as a *signal*, never a guarantee,
and every failure surfaces as a clear error instead of silent success.

The MAC address is accepted, validated, and used -- but never logged and
never included in error messages.
"""

from __future__ import annotations

import asyncio
import socket

from .protocol import normalize_mac


class WoLError(Exception):
    """Wake-on-LAN could not be sent (message safe to show the user)."""


def build_magic_packet(mac: str) -> bytes:
    normalized = normalize_mac(mac)
    if normalized is None:
        raise WoLError("that MAC address doesn't look valid (expected AA:BB:CC:DD:EE:FF)")
    raw = bytes.fromhex(normalized.replace(":", ""))
    return b"\xff" * 6 + raw * 16


async def send_wol(mac: str, host: str = "") -> None:
    """Send the magic packet via broadcast (and directed at *host* if given).

    Blocking socket work runs in a thread: the voice pipeline and dashboard
    share one event loop that must never stall on network I/O.
    """
    packet = build_magic_packet(mac)

    def _send() -> None:
        targets = [("255.255.255.255", 9), ("255.255.255.255", 7)]
        if host:
            targets.append((host, 9))
        sent = 0
        last_err: OSError | None = None
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.settimeout(2.0)
                for target in targets:
                    try:
                        for _ in range(3):  # UDP is lossy; repeats are cheap
                            sock.sendto(packet, target)
                        sent += 1
                    except OSError as exc:
                        last_err = exc
        except OSError as exc:
            # socket creation/setsockopt failures are ordinary network
            # trouble and must surface as the same safe error type
            raise WoLError("could not send the wake signal on this network") from exc
        if sent == 0:
            raise WoLError("could not send the wake signal on this network") from last_err

    await asyncio.to_thread(_send)
