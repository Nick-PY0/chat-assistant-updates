"""Async Google Calendar provider, normalized bounded cache, and safe failures."""

from __future__ import annotations

import asyncio
import base64
import hashlib
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any
from urllib.parse import quote, urlencode, urlparse

import httpx

from chat_core.events import EventBus
from chat_core.models.google_account import GoogleAccountStore
from chat_core.models.credentials import iso, parse_iso

SCOPES = ("openid", "email", "https://www.googleapis.com/auth/calendar.readonly",
          "https://www.googleapis.com/auth/calendar.events")


class GoogleCalendarError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class CalendarEvent:
    id: str
    calendar_id: str
    calendar_name: str
    title: str
    start_at: str
    end_at: str
    all_day: bool
    timezone: str | None
    location: str | None
    html_link: str | None
    recurring_event_id: str | None
    status: str

    @property
    def start(self) -> str:  # compatibility for scheduler consumers
        return self.start_at

    @property
    def end(self) -> str:
        return self.end_at

    def public(self) -> dict:
        return asdict(self)


def _safe_link(value: object) -> str | None:
    try:
        parsed = urlparse(str(value))
        if parsed.scheme == "https" and (
            parsed.hostname == "google.com" or parsed.hostname.endswith(".google.com")
        ):
            return str(value)[:2000]
    except Exception:
        pass
    return None


def _normalize(calendar_id: str, raw: dict[str, Any],
               calendar_name: str = "") -> CalendarEvent:
    start, end = raw.get("start") or {}, raw.get("end") or {}
    all_day = bool(start.get("date"))
    start_at = str(start.get("date") if all_day else start.get("dateTime") or "")
    end_at = str(end.get("date") if all_day else end.get("dateTime") or "")
    # Reject malformed dates early instead of poisoning the persistent cache.
    if all_day:
        date.fromisoformat(start_at)
        date.fromisoformat(end_at)
    else:
        begins, finishes = datetime.fromisoformat(start_at), datetime.fromisoformat(end_at)
        if begins.tzinfo is None or finishes.tzinfo is None:
            raise ValueError("timed event lacks UTC offset")
    return CalendarEvent(
        str(raw.get("id") or ""), calendar_id, calendar_name[:255],
        str(raw.get("summary") or "(untitled)")[:500], start_at, end_at, all_day,
        start.get("timeZone") or end.get("timeZone"),
        str(raw.get("location"))[:500] if raw.get("location") else None,
        _safe_link(raw.get("htmlLink")), raw.get("recurringEventId"),
        "cancelled" if raw.get("status") == "cancelled" else "confirmed")


class GoogleCalendarClient:
    AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
    TOKEN_URL = "https://oauth2.googleapis.com/token"
    API = "https://www.googleapis.com/calendar/v3"
    USERINFO = "https://openidconnect.googleapis.com/v1/userinfo"

    def __init__(self, account: GoogleAccountStore, http: httpx.AsyncClient | None = None,
                 clock=lambda: datetime.now(timezone.utc), cache_limit: int = 2000,
                 bus: EventBus | None = None, sync_seconds: float = 300) -> None:
        self.account = account
        self.http = http or httpx.AsyncClient(timeout=15)
        self.clock = clock
        self._owns_http, self.cache_limit = http is None, max(100, min(cache_limit, 5000))
        self.bus, self.sync_seconds = bus, max(15, sync_seconds)
        self._task: asyncio.Task | None = None
        self._stop = asyncio.Event()

    async def start(self) -> None:
        if self._task and not self._task.done():
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._sync_loop(), name="google-calendar-sync")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None
        if self._owns_http:
            await self.http.aclose()

    async def close(self) -> None:
        await self.stop()

    async def _sync_loop(self) -> None:
        while not self._stop.is_set():
            selected, _ = await self.account.selection()
            ok = 0
            for calendar_id in selected:
                try:
                    await self.sync(calendar_id)
                    ok += 1
                except GoogleCalendarError:
                    await self.account.mark_failure("sync_unavailable")
            if self.bus:
                self.bus.publish("calendar_sync_health", ok=ok, selected=len(selected))
            await asyncio.sleep(self.sync_seconds)

    async def authorization_url(self, redirect_uri: str, binding_cookie: str) -> tuple[str, str]:
        state, verifier = await self.account.create_pending(binding_cookie)
        challenge = base64.urlsafe_b64encode(
            hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        sec = await self.account.secrets()
        query = urlencode({"client_id": sec.client_id, "redirect_uri": redirect_uri,
            "response_type": "code", "scope": " ".join(SCOPES), "state": state,
            "code_challenge": challenge, "code_challenge_method": "S256",
            "access_type": "offline", "prompt": "consent"})
        return f"{self.AUTH_URL}?{query}", state

    async def exchange_code(self, code: str, state: str, binding_cookie: str,
                            redirect_uri: str) -> dict:
        verifier = await self.account.consume_pending(state, binding_cookie)
        sec = await self.account.secrets()
        data = await self._form({"code": code, "client_id": sec.client_id,
            "client_secret": sec.client_secret, "redirect_uri": redirect_uri,
            "grant_type": "authorization_code", "code_verifier": verifier})
        await self._store_token_response(data, SCOPES)
        ident = await self._request("GET", self.USERINFO)
        if not ident.get("email"):
            raise GoogleCalendarError("Google did not return a usable account identity")
        await self.account.save_identity(ident["email"], ident.get("name") or "")
        await self.calendars()  # establishes safe primary defaults
        return await self.account.public_metadata()

    async def _form(self, data: dict) -> dict:
        try:
            response = await self.http.post(self.TOKEN_URL, data=data)
            if response.status_code >= 400:
                error = ""
                try:
                    error = str(response.json().get("error", ""))
                except Exception:
                    pass
                if error == "invalid_grant":
                    await self.account.mark_failure("invalid_grant", True)
                    raise GoogleCalendarError("Google Calendar needs to be reconnected", 401)
                if error in ("invalid_client", "unauthorized_client", "invalid_scope"):
                    await self.account.mark_failure(error, True)
                    raise GoogleCalendarError(
                        "Google OAuth client settings need to be updated", 401
                    )
                raise GoogleCalendarError("Google authorization is temporarily unavailable",
                                          response.status_code)
            value = response.json()
            if not isinstance(value, dict):
                raise ValueError
            return value
        except GoogleCalendarError:
            raise
        except Exception:
            # Never retain the request exception; its body contains credentials.
            raise GoogleCalendarError("Google authorization is temporarily unavailable") from None

    async def _store_token_response(self, data: dict, fallback_scopes=()) -> None:
        token = data.get("access_token")
        if not token:
            raise GoogleCalendarError("Google authorization failed")
        raw_scopes = data.get("scope")
        scopes = str(raw_scopes).split() if raw_scopes else list(fallback_scopes)
        expires = self.clock() + timedelta(seconds=max(0, int(data.get("expires_in", 3600)) - 30))
        await self.account.save_tokens(str(token), data.get("refresh_token"), expires, scopes)

    async def _token(self, force_refresh: bool = False) -> str:
        sec = await self.account.secrets()
        if (not force_refresh and sec.access_token and sec.expires_at
                and sec.expires_at > self.clock()):
            return sec.access_token
        if not sec.refresh_token:
            await self.account.mark_failure("missing_refresh_token", True)
            raise GoogleCalendarError("Google Calendar needs to be reconnected", 401)
        data = await self._form({"client_id": sec.client_id, "client_secret": sec.client_secret,
                                 "refresh_token": sec.refresh_token,
                                 "grant_type": "refresh_token"})
        await self._store_token_response(data, sec.scopes)
        return (await self.account.secrets()).access_token or ""

    async def _request(self, method: str, url: str, _retried=False, **kwargs) -> dict:
        token = await self._token()
        try:
            response = await self.http.request(
                method, url, headers={"Authorization": f"Bearer {token}"}, **kwargs)
            if response.status_code == 401 and not _retried:
                token = await self._token(force_refresh=True)
                return await self._request(method, url, _retried=True, **kwargs)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise ValueError
            return data
        except GoogleCalendarError:
            raise
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 401:
                await self.account.mark_failure("unauthorized", True)
                raise GoogleCalendarError("Google Calendar needs to be reconnected", 401) from None
            raise GoogleCalendarError("Google Calendar is temporarily unavailable",
                                      exc.response.status_code) from None
        except Exception:
            raise GoogleCalendarError("Google Calendar is temporarily unavailable") from None

    async def calendars(self) -> list[dict]:
        items, page = [], None
        while True:
            params = {"maxResults": 250}
            if page:
                params["pageToken"] = page
            data = await self._request("GET", f"{self.API}/users/me/calendarList", params=params)
            items.extend(data.get("items", []))
            page = data.get("nextPageToken")
            if not page:
                break
        selected, writable = await self.account.selection()
        if not selected:
            primary = next((x for x in items if x.get("primary")), None)
            if primary:
                selected = [str(primary["id"])]
                writable = (str(primary["id"]) if primary.get("accessRole") in
                            ("owner", "writer") else None)
                await self.account.save_calendar_selection(selected, writable)
        return [{"id": str(x["id"]), "name": str(x.get("summary") or "")[:255],
                 "timezone": x.get("timeZone"), "primary": bool(x.get("primary")),
                 "access_role": str(x.get("accessRole") or "reader"),
                 "selected": str(x["id"]) in selected,
                 "write_allowed": x.get("accessRole") in ("owner", "writer")}
                for x in items if x.get("id")]

    async def select_calendars(self, readable: list[str], writable: str | None = None) -> dict:
        discovered = {item["id"]: item for item in await self.calendars()}
        chosen = list(dict.fromkeys(str(x) for x in readable))
        if not chosen or any(cid not in discovered for cid in chosen):
            raise GoogleCalendarError("Select at least one available calendar")
        if writable and (writable not in chosen or not discovered[writable]["write_allowed"]):
            raise GoogleCalendarError("The default calendar is not writable")
        await self.account.save_calendar_selection(chosen, writable)
        return await self.account.public_metadata()

    async def sync(self, calendar_id: str, reset: bool = False) -> list[CalendarEvent]:
        state = None if reset else await self.account.db.fetchone(
            "SELECT sync_token FROM calendar_sync_state WHERE provider=? AND calendar_id=?",
            ("google", calendar_id))
        token = state["sync_token"] if state else None
        params: dict[str, Any] = {"maxResults": 2500, "showDeleted": "true",
                                  "singleEvents": "true"}
        if token:
            params["syncToken"] = token
        else:
            params["timeMin"] = iso(self.clock() - timedelta(days=30))
            params["timeMax"] = iso(self.clock() + timedelta(days=366))
        calendars = {x["id"]: x["name"] for x in await self.calendars()}
        name, page, events, next_sync = calendars.get(calendar_id, ""), None, [], None
        while True:
            request_params = dict(params)
            if page:
                request_params["pageToken"] = page
            try:
                data = await self._request(
                    "GET", f"{self.API}/calendars/{quote(calendar_id, safe='')}/events",
                    params=request_params)
            except GoogleCalendarError as exc:
                if exc.status_code == 410 and not reset:
                    await self.account.db.execute(
                        "DELETE FROM calendar_sync_state WHERE provider=? AND calendar_id=?",
                        ("google", calendar_id))
                    await self.account.db.execute(
                        "DELETE FROM calendar_event_cache WHERE provider=? AND calendar_id=?",
                        ("google", calendar_id))
                    return await self.sync(calendar_id, True)
                raise
            for raw in data.get("items", []):
                event_id = str(raw.get("id") or "")
                if not event_id:
                    continue
                if raw.get("status") == "cancelled":
                    await self.account.db.execute(
                        "DELETE FROM calendar_event_cache WHERE provider='google' AND calendar_id=? AND event_id=?",
                        (calendar_id, event_id))
                    continue
                try:
                    event = _normalize(calendar_id, raw, name)
                except (ValueError, TypeError):
                    continue
                events.append(event)
                await self._cache(event)
            page, next_sync = data.get("nextPageToken"), data.get("nextSyncToken") or next_sync
            if not page:
                break
        await self.account.db.execute(
            """INSERT INTO calendar_sync_state(provider,calendar_id,sync_token,updated_at)
               VALUES('google',?,?,?) ON CONFLICT(provider,calendar_id) DO UPDATE SET
               sync_token=excluded.sync_token,updated_at=excluded.updated_at""",
            (calendar_id, next_sync, iso(self.clock())))
        await self._trim_cache()
        await self.account.mark_synced()
        return events

    async def _cache(self, event: CalendarEvent) -> None:
        await self.account.db.execute(
            """INSERT INTO calendar_event_cache
               (provider,calendar_id,calendar_name,event_id,title,start_at,end_at,all_day,
                timezone,location,html_link,recurring_event_id,status,updated_at)
               VALUES('google',?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(provider,calendar_id,event_id) DO UPDATE SET
               calendar_name=excluded.calendar_name,title=excluded.title,start_at=excluded.start_at,
               end_at=excluded.end_at,all_day=excluded.all_day,timezone=excluded.timezone,
               location=excluded.location,html_link=excluded.html_link,
               recurring_event_id=excluded.recurring_event_id,status=excluded.status,
               updated_at=excluded.updated_at""",
            (event.calendar_id, event.calendar_name, event.id, event.title, event.start_at,
             event.end_at, int(event.all_day), event.timezone, event.location, event.html_link,
             event.recurring_event_id, event.status, iso(self.clock())))

    async def _trim_cache(self) -> None:
        await self.account.db.execute(
            """DELETE FROM calendar_event_cache WHERE provider='google' AND rowid NOT IN
               (SELECT rowid FROM calendar_event_cache WHERE provider='google'
                ORDER BY updated_at DESC LIMIT ?)""", (self.cache_limit,))

    async def list_events(self, start: datetime, end: datetime) -> list[CalendarEvent]:
        selected, _ = await self.account.selection()
        # Reads are deliberately cache-only.  The lifecycle sync loop and the
        # explicit dashboard "Sync now" action refresh this bounded cache.
        # Schedule questions therefore stay fast and continue working while
        # Google is offline instead of turning every voice/tool call into a
        # network round trip.
        rows = await self.account.db.fetchall(
            """SELECT * FROM calendar_event_cache WHERE provider='google'
               AND calendar_id IN ({}) AND status!='cancelled' AND end_at>? AND start_at<?
               ORDER BY start_at LIMIT 500""".format(",".join("?" for _ in selected) or "''"),
            tuple(selected) + (iso(start), iso(end)))
        return [CalendarEvent(r["event_id"], r["calendar_id"], r["calendar_name"], r["title"],
            r["start_at"], r["end_at"], bool(r["all_day"]), r["timezone"], r["location"],
            r["html_link"], r["recurring_event_id"], r["status"]) for r in rows]

    async def create_event(self, calendar_id: str, payload: dict) -> CalendarEvent:
        data = await self._request(
            "POST", f"{self.API}/calendars/{quote(calendar_id, safe='')}/events", json=payload)
        calendars = {x["id"]: x["name"] for x in await self.calendars()}
        return _normalize(calendar_id, data, calendars.get(calendar_id, ""))

    async def get_event(self, calendar_id: str, event_id: str) -> CalendarEvent:
        data = await self._request(
            "GET", f"{self.API}/calendars/{quote(calendar_id, safe='')}/events/"
                   f"{quote(event_id, safe='')}")
        calendars = {x["id"]: x["name"] for x in await self.calendars()}
        return _normalize(calendar_id, data, calendars.get(calendar_id, ""))

    async def cache_event(self, event: CalendarEvent) -> None:
        await self._cache(event)
        await self._trim_cache()