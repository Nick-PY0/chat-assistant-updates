"""Bounded, token-safe async client for Spotify's official Web API."""

from __future__ import annotations

import base64
import hashlib
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import quote, urlencode, urlparse

import httpx

from chat_core.models.google_account import OAuthStateError
from chat_core.models.spotify_account import SpotifyAccountStore
from chat_core.security.vault import Vault


SCOPES = (
    "user-read-private",
    "user-read-email",
    "user-read-playback-state",
    "user-modify-playback-state",
    "playlist-read-private",
    "playlist-read-collaborative",
)


class SpotifyError(RuntimeError):
    """A safe provider error suitable for returning to application callers."""

    def __init__(
        self,
        code: str,
        message: str,
        status_code: int | None = None,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.retry_after = retry_after

    def public(self) -> dict[str, Any]:
        result: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.retry_after is not None:
            result["retry_after"] = self.retry_after
        return result


def _redirect_uri(value: str) -> str:
    """Accept HTTPS callbacks and HTTP only on an explicit loopback host."""
    try:
        parsed = urlparse(str(value))
        loopback = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if (
            not parsed.fragment
            and not parsed.username
            and not parsed.password
            and parsed.netloc
            and (parsed.scheme == "https" or (parsed.scheme == "http" and loopback))
        ):
            return str(value)
    except (TypeError, ValueError):
        pass
    raise SpotifyError(
        "invalid_redirect_uri",
        "Spotify callback URL must use HTTPS (HTTP is allowed only for loopback hosts)",
    )


def _safe_external_url(raw: object) -> str | None:
    try:
        value = str(raw)
        parsed = urlparse(value)
        if parsed.scheme == "https" and (
            parsed.hostname == "open.spotify.com"
            or (parsed.hostname or "").endswith(".spotify.com")
        ):
            return value[:2000]
    except (TypeError, ValueError):
        pass
    return None


def _image(raw: object) -> str | None:
    if not isinstance(raw, list):
        return None
    for item in raw:
        if isinstance(item, dict):
            url = item.get("url")
            try:
                parsed = urlparse(str(url))
                if parsed.scheme == "https":
                    return str(url)[:2000]
            except (TypeError, ValueError):
                continue
    return None


def _track(raw: object) -> dict[str, Any] | None:
    if not isinstance(raw, dict) or not raw.get("id"):
        return None
    artists = raw.get("artists") if isinstance(raw.get("artists"), list) else []
    album = raw.get("album") if isinstance(raw.get("album"), dict) else {}
    external = raw.get("external_urls")
    external = external if isinstance(external, dict) else {}
    return {
        "id": str(raw["id"])[:128],
        "name": str(raw.get("name") or "")[:500],
        "artists": [
            str(item.get("name") or "")[:255]
            for item in artists[:20]
            if isinstance(item, dict) and item.get("name")
        ],
        "album": str(album.get("name") or "")[:500],
        "duration_ms": max(0, int(raw.get("duration_ms") or 0)),
        "explicit": bool(raw.get("explicit")),
        "uri": str(raw.get("uri") or "")[:500],
        "external_url": _safe_external_url(external.get("spotify")),
        "image_url": _image(album.get("images")),
    }


def _playlist(raw: object) -> dict[str, Any] | None:
    if not isinstance(raw, dict) or not raw.get("id"):
        return None
    owner = raw.get("owner") if isinstance(raw.get("owner"), dict) else {}
    tracks = raw.get("tracks") if isinstance(raw.get("tracks"), dict) else {}
    external = raw.get("external_urls")
    external = external if isinstance(external, dict) else {}
    return {
        "id": str(raw["id"])[:128],
        "name": str(raw.get("name") or "")[:500],
        "description": str(raw.get("description") or "")[:1000],
        "owner": str(owner.get("display_name") or owner.get("id") or "")[:255],
        "public": raw.get("public") if isinstance(raw.get("public"), bool) else None,
        "collaborative": bool(raw.get("collaborative")),
        "track_count": max(0, int(tracks.get("total") or 0)),
        "uri": str(raw.get("uri") or "")[:500],
        "external_url": _safe_external_url(external.get("spotify")),
        "image_url": _image(raw.get("images")),
    }


class SpotifyClient:
    AUTH_URL = "https://accounts.spotify.com/authorize"
    TOKEN_URL = "https://accounts.spotify.com/api/token"
    API = "https://api.spotify.com/v1"

    def __init__(
        self,
        account: SpotifyAccountStore,
        http: httpx.AsyncClient | None = None,
        clock=lambda: datetime.now(timezone.utc),
    ) -> None:
        self.account = account
        self.http = http or httpx.AsyncClient(timeout=15)
        self.clock = clock
        self._owns_http = http is None
        self._muted_volumes: dict[str, int] = {}

    async def close(self) -> None:
        if self._owns_http:
            await self.http.aclose()

    async def authorization_url(
        self, redirect_uri: str, binding_cookie: str
    ) -> tuple[str, str]:
        redirect_uri = _redirect_uri(redirect_uri)
        try:
            sec = await self.account.secrets()
        except LookupError:
            raise SpotifyError(
                "not_configured", "Spotify is not configured"
            ) from None
        if not sec.client_id:
            raise SpotifyError("not_configured", "Spotify is not configured")
        try:
            state, verifier = await self.account.create_pending(binding_cookie)
        except OAuthStateError:
            raise SpotifyError(
                "invalid_oauth_state", "A browser binding is required for Spotify authorization"
            ) from None
        challenge = base64.urlsafe_b64encode(
            hashlib.sha256(verifier.encode()).digest()
        ).rstrip(b"=").decode()
        query = urlencode(
            {
                "client_id": sec.client_id,
                "response_type": "code",
                "redirect_uri": redirect_uri,
                "scope": " ".join(SCOPES),
                "state": state,
                "code_challenge_method": "S256",
                "code_challenge": challenge,
                "show_dialog": "true",
            }
        )
        return f"{self.AUTH_URL}?{query}", state

    async def exchange_code(
        self,
        code: str,
        state: str,
        binding_cookie: str,
        redirect_uri: str,
    ) -> dict[str, Any]:
        redirect_uri = _redirect_uri(redirect_uri)
        if not code or len(code) > 4096 or not state or len(state) > 1024:
            raise SpotifyError("invalid_callback", "Spotify callback is invalid")
        try:
            verifier = await self.account.consume_pending(state, binding_cookie)
        except OAuthStateError:
            raise SpotifyError(
                "invalid_oauth_state",
                "Spotify authorization request is invalid, expired, or already used",
            ) from None
        sec = await self._secrets()
        data = await self._token_form(
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": verifier,
            },
            sec.client_id,
            sec.client_secret,
        )
        await self._store_token_response(data, SCOPES)
        return await self.validate_connection()

    async def validate_connection(self) -> dict[str, Any]:
        """Validate the token against /me and retain only safe account identity."""
        identity = await self._request("GET", "/me")
        if not isinstance(identity, dict) or not identity.get("id"):
            await self.account.mark_failure("invalid_identity", True)
            raise SpotifyError(
                "reauthorization_required", "Spotify needs to be reconnected", 401
            )
        await self.account.save_identity(
            str(identity.get("email") or identity["id"]),
            str(identity.get("display_name") or ""),
        )
        await self.account.mark_synced()
        return await self.account.public_metadata()

    async def refresh(self) -> str:
        return await self._token(force_refresh=True)

    async def _secrets(self):
        try:
            return await self.account.secrets()
        except LookupError:
            raise SpotifyError("not_configured", "Spotify is not configured") from None

    async def _token_form(
        self, data: dict[str, str], client_id: str, client_secret: str
    ) -> dict[str, Any]:
        basic = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
        try:
            response = await self.http.post(
                self.TOKEN_URL,
                data=data,
                headers={
                    "Authorization": f"Basic {basic}",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
            )
        except httpx.HTTPError:
            raise SpotifyError(
                "transient_failure", "Spotify authorization is temporarily unavailable"
            ) from None
        if response.status_code >= 400:
            error = ""
            try:
                body = response.json()
                error = str(body.get("error") or "") if isinstance(body, dict) else ""
            except (ValueError, TypeError):
                pass
            if error in {"invalid_grant", "invalid_client", "unauthorized_client"}:
                await self.account.mark_failure(error or "oauth_unauthorized", True)
                raise SpotifyError(
                    "reauthorization_required",
                    "Spotify needs to be reconnected",
                    401,
                )
            raise SpotifyError(
                "transient_failure",
                "Spotify authorization is temporarily unavailable",
                response.status_code,
            )
        try:
            value = response.json()
        except ValueError:
            value = None
        if not isinstance(value, dict):
            raise SpotifyError(
                "transient_failure", "Spotify authorization is temporarily unavailable"
            )
        return value

    async def _store_token_response(
        self, data: dict[str, Any], fallback_scopes: tuple[str, ...]
    ) -> None:
        token = data.get("access_token")
        if not token:
            raise SpotifyError("authorization_failed", "Spotify authorization failed")
        raw_scope = data.get("scope")
        scopes = str(raw_scope).split() if raw_scope else list(fallback_scopes)
        try:
            lifetime = max(0, int(data.get("expires_in", 3600)) - 30)
        except (TypeError, ValueError):
            lifetime = 3570
        await self.account.save_tokens(
            str(token),
            str(data["refresh_token"]) if data.get("refresh_token") else None,
            self.clock() + timedelta(seconds=lifetime),
            scopes,
        )

    async def _token(self, force_refresh: bool = False) -> str:
        sec = await self._secrets()
        if (
            not force_refresh
            and sec.access_token
            and sec.expires_at
            and sec.expires_at > self.clock()
        ):
            return sec.access_token
        if not sec.refresh_token:
            await self.account.mark_failure("missing_refresh_token", True)
            raise SpotifyError(
                "reauthorization_required", "Spotify needs to be reconnected", 401
            )
        data = await self._token_form(
            {"grant_type": "refresh_token", "refresh_token": sec.refresh_token},
            sec.client_id,
            sec.client_secret,
        )
        await self._store_token_response(data, sec.scopes)
        return (await self._secrets()).access_token or ""

    @staticmethod
    def _provider_message(response: httpx.Response) -> str:
        try:
            body = response.json()
            error = body.get("error") if isinstance(body, dict) else None
            if isinstance(error, dict):
                return str(error.get("message") or "")
            return str(error or "")
        except (ValueError, TypeError):
            return ""

    async def _raise_response(self, response: httpx.Response) -> None:
        status = response.status_code
        message = self._provider_message(response).lower()
        if status == 401:
            await self.account.mark_failure("unauthorized", True)
            raise SpotifyError(
                "reauthorization_required", "Spotify needs to be reconnected", 401
            )
        if status == 403:
            if "premium" in message:
                raise SpotifyError(
                    "premium_required",
                    "Spotify Premium is required for playback control",
                    403,
                )
            raise SpotifyError(
                "playback_restricted",
                "Spotify does not allow that playback action for this account or content",
                403,
            )
        if status == 404:
            raise SpotifyError(
                "unavailable_device",
                "The Spotify playback device is no longer available",
                404,
            )
        if status == 429:
            raw = response.headers.get("Retry-After", "")
            try:
                retry = max(0, min(int(raw), 3600))
            except ValueError:
                retry = None
            raise SpotifyError(
                "rate_limited",
                "Spotify is rate limiting requests; try again later",
                429,
                retry,
            )
        if status >= 500:
            raise SpotifyError(
                "transient_failure", "Spotify is temporarily unavailable", status
            )
        raise SpotifyError(
            "provider_error", "Spotify could not complete the request", status
        )

    async def _request(
        self, method: str, path: str, *, expect_json: bool = True, **kwargs
    ) -> dict[str, Any]:
        token = await self._token()
        url = path if path.startswith("https://") else f"{self.API}{path}"
        for attempt in range(2):
            try:
                response = await self.http.request(
                    method,
                    url,
                    headers={"Authorization": f"Bearer {token}"},
                    **kwargs,
                )
            except httpx.HTTPError:
                raise SpotifyError(
                    "transient_failure", "Spotify is temporarily unavailable"
                ) from None
            if response.status_code == 401 and attempt == 0:
                token = await self._token(force_refresh=True)
                continue
            if response.status_code >= 400:
                await self._raise_response(response)
            if response.status_code == 204 or not expect_json:
                return {}
            try:
                value = response.json()
            except ValueError:
                value = None
            if not isinstance(value, dict):
                raise SpotifyError(
                    "transient_failure", "Spotify returned an invalid response"
                )
            return value
        raise SpotifyError(
            "reauthorization_required", "Spotify needs to be reconnected", 401
        )

    @staticmethod
    def _bounded_limit(limit: int, maximum: int = 50) -> int:
        try:
            return max(1, min(int(limit), maximum))
        except (TypeError, ValueError):
            return 20

    @staticmethod
    def _device_ref(device_id: str) -> str:
        return f"spotify-device-{Vault.fingerprint(device_id)}"

    async def _live_devices(self) -> list[tuple[str, dict[str, Any]]]:
        data = await self._request("GET", "/me/player/devices")
        raw = data.get("devices")
        if not isinstance(raw, list):
            return []
        return [
            (str(item["id"]), item)
            for item in raw[:100]
            if isinstance(item, dict) and item.get("id")
        ]

    @staticmethod
    def _public_device(device_id: str, raw: dict[str, Any]) -> dict[str, Any]:
        volume = raw.get("volume_percent")
        return {
            "ref": SpotifyClient._device_ref(device_id),
            "name": str(raw.get("name") or "Spotify device")[:255],
            "type": str(raw.get("type") or "unknown")[:80],
            "is_active": bool(raw.get("is_active")),
            "is_private_session": bool(raw.get("is_private_session")),
            "is_restricted": bool(raw.get("is_restricted")),
            "volume_percent": (
                max(0, min(int(volume), 100))
                if isinstance(volume, (int, float))
                else None
            ),
            "supports_volume": bool(raw.get("supports_volume")),
        }

    async def devices(self) -> list[dict[str, Any]]:
        return [self._public_device(device_id, raw)
                for device_id, raw in await self._live_devices()]

    async def discover_devices(self) -> list[dict[str, Any]]:
        return await self.devices()

    async def _resolve_device(
        self, device_ref: str
    ) -> tuple[str, dict[str, Any]]:
        for device_id, raw in await self._live_devices():
            if self._device_ref(device_id) == device_ref:
                if raw.get("is_restricted"):
                    raise SpotifyError(
                        "unavailable_device",
                        "That Spotify device does not accept playback controls",
                        404,
                    )
                return device_id, raw
        raise SpotifyError(
            "unavailable_device",
            "The Spotify playback device is no longer available",
            404,
        )

    async def search(
        self, query: str, types: tuple[str, ...] | list[str] = ("track", "playlist"),
        limit: int = 10,
    ) -> dict[str, list[dict[str, Any]]]:
        clean_query = " ".join(str(query).split())[:250]
        if not clean_query:
            raise SpotifyError("invalid_request", "A Spotify search query is required")
        allowed = [kind for kind in dict.fromkeys(types) if kind in {"track", "playlist"}]
        if not allowed:
            raise SpotifyError("invalid_request", "Search tracks or playlists")
        limit = self._bounded_limit(limit)
        data = await self._request(
            "GET", "/search", params={"q": clean_query, "type": ",".join(allowed), "limit": limit}
        )
        tracks = data.get("tracks") if isinstance(data.get("tracks"), dict) else {}
        playlists = data.get("playlists") if isinstance(data.get("playlists"), dict) else {}
        track_items = tracks.get("items") if isinstance(tracks.get("items"), list) else []
        playlist_items = (
            playlists.get("items") if isinstance(playlists.get("items"), list) else []
        )
        return {
            "tracks": [
                item for item in (_track(raw) for raw in track_items[:limit])
                if item is not None
            ],
            "playlists": [
                item for item in (_playlist(raw) for raw in playlist_items[:limit])
                if item is not None
            ],
        }

    async def search_tracks(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        return (await self.search(query, ("track",), limit))["tracks"]

    async def search_playlists(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        return (await self.search(query, ("playlist",), limit))["playlists"]

    async def playlists(self, limit: int = 50) -> list[dict[str, Any]]:
        wanted, offset, pages, results = self._bounded_limit(limit, 200), 0, 0, []
        while len(results) < wanted and pages < 4:
            pages += 1
            size = min(50, wanted - len(results))
            data = await self._request(
                "GET", "/me/playlists", params={"limit": size, "offset": offset}
            )
            items = data.get("items") if isinstance(data.get("items"), list) else []
            results.extend(
                item for item in (_playlist(raw) for raw in items[:size])
                if item is not None
            )
            if len(items) < size or not data.get("next"):
                break
            offset += size
        return results[:wanted]

    async def current_user_playlists(self, limit: int = 50) -> list[dict[str, Any]]:
        return await self.playlists(limit)

    async def playlist_tracks(
        self, playlist_id: str, limit: int = 100
    ) -> list[dict[str, Any]]:
        playlist_id = str(playlist_id).strip()
        if not playlist_id or len(playlist_id) > 128:
            raise SpotifyError("invalid_request", "A valid Spotify playlist is required")
        wanted, offset, pages, results = self._bounded_limit(limit, 500), 0, 0, []
        while len(results) < wanted and pages < 10:
            pages += 1
            size = min(50, wanted - len(results))
            data = await self._request(
                "GET",
                f"/playlists/{quote(playlist_id, safe='')}/items",
                params={"limit": size, "offset": offset},
            )
            items = data.get("items") if isinstance(data.get("items"), list) else []
            for wrapper in items[:size]:
                raw = wrapper.get("track") if isinstance(wrapper, dict) else None
                normalized = _track(raw)
                if normalized:
                    results.append(normalized)
            if len(items) < size or not data.get("next"):
                break
            offset += size
        return results[:wanted]

    async def transfer(self, device_ref: str, play: bool = False) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        await self._request(
            "PUT",
            "/me/player",
            json={"device_ids": [device_id], "play": bool(play)},
            expect_json=False,
        )
        return {"device_ref": device_ref, "playing": bool(play)}

    async def transfer_playback(
        self, device_ref: str, play: bool = False
    ) -> dict[str, Any]:
        return await self.transfer(device_ref, play)

    async def start(
        self,
        device_ref: str,
        *,
        uri: str | None = None,
        uris: list[str] | tuple[str, ...] | None = None,
        context_uri: str | None = None,
        position_ms: int | None = None,
    ) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        body: dict[str, Any] = {}
        if context_uri:
            body["context_uri"] = str(context_uri)[:500]
        elif uris:
            body["uris"] = [str(item)[:500] for item in uris if item][:100]
        elif uri:
            body["uris"] = [str(uri)[:500]]
        if position_ms is not None:
            body["position_ms"] = max(0, min(int(position_ms), 86_400_000))
        await self._request(
            "PUT", "/me/player/play", params={"device_id": device_id},
            json=body, expect_json=False,
        )
        return {"device_ref": device_ref, "playing": True}

    async def resume(self, device_ref: str) -> dict[str, Any]:
        return await self.start(device_ref)

    async def pause(self, device_ref: str) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        await self._request(
            "PUT", "/me/player/pause", params={"device_id": device_id}, expect_json=False
        )
        return {"device_ref": device_ref, "playing": False}

    async def stop(self, device_ref: str) -> dict[str, Any]:
        # Spotify has no stop endpoint. Pause then rewind is the closest truthful operation.
        device_id, _ = await self._resolve_device(device_ref)
        await self._request(
            "PUT", "/me/player/pause", params={"device_id": device_id}, expect_json=False
        )
        await self._request(
            "PUT", "/me/player/seek",
            params={"device_id": device_id, "position_ms": 0}, expect_json=False,
        )
        return {"device_ref": device_ref, "playing": False, "position_ms": 0}

    async def _simple_playback(self, action: str, device_ref: str) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        await self._request(
            "POST", f"/me/player/{action}", params={"device_id": device_id}, expect_json=False
        )
        return {"device_ref": device_ref, "action": action}

    async def next(self, device_ref: str) -> dict[str, Any]:
        return await self._simple_playback("next", device_ref)

    async def previous(self, device_ref: str) -> dict[str, Any]:
        return await self._simple_playback("previous", device_ref)

    async def seek(self, device_ref: str, position_ms: int) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        position = max(0, min(int(position_ms), 86_400_000))
        await self._request(
            "PUT", "/me/player/seek",
            params={"device_id": device_id, "position_ms": position}, expect_json=False,
        )
        return {"device_ref": device_ref, "position_ms": position}

    async def volume(self, device_ref: str, percent: int) -> dict[str, Any]:
        device_id, raw = await self._resolve_device(device_ref)
        if not raw.get("supports_volume"):
            raise SpotifyError(
                "playback_restricted", "That Spotify device does not support volume control"
            )
        value = max(0, min(int(percent), 100))
        await self._request(
            "PUT", "/me/player/volume",
            params={"device_id": device_id, "volume_percent": value}, expect_json=False,
        )
        return {"device_ref": device_ref, "volume_percent": value}

    async def mute(self, device_ref: str, muted: bool = True) -> dict[str, Any]:
        _, raw = await self._resolve_device(device_ref)
        if muted:
            current = raw.get("volume_percent")
            if isinstance(current, (int, float)) and int(current) > 0:
                self._muted_volumes[device_ref] = max(0, min(int(current), 100))
            result = await self.volume(device_ref, 0)
            return {**result, "muted": True}
        if device_ref not in self._muted_volumes:
            raise SpotifyError(
                "volume_restore_unavailable",
                "The previous Spotify volume is unavailable; set a volume explicitly",
            )
        result = await self.volume(device_ref, self._muted_volumes.pop(device_ref))
        return {**result, "muted": False}

    async def add_to_queue(self, device_ref: str, uri: str) -> dict[str, Any]:
        device_id, _ = await self._resolve_device(device_ref)
        uri = str(uri).strip()[:500]
        if not uri:
            raise SpotifyError("invalid_request", "A Spotify track URI is required")
        await self._request(
            "POST", "/me/player/queue",
            params={"device_id": device_id, "uri": uri}, expect_json=False,
        )
        return {"device_ref": device_ref, "queued": True}


SpotifyWebAPI = SpotifyClient