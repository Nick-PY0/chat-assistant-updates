"""Spotify OAuth and Web API integration."""

from .client import SCOPES, SpotifyClient, SpotifyError, SpotifyWebAPI

__all__ = ["SCOPES", "SpotifyClient", "SpotifyError", "SpotifyWebAPI"]