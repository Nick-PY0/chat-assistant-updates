-- Durable, provider-neutral music state.  Provider identifiers and local
-- filesystem details are ciphertext; hashes are used only as stable public
-- references and are not credentials.
CREATE TABLE IF NOT EXISTS music_rooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    is_default INTEGER NOT NULL DEFAULT 0 CHECK(is_default IN (0,1)),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS music_one_default_room
    ON music_rooms(is_default) WHERE is_default=1;

CREATE TABLE IF NOT EXISTS music_items (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL DEFAULT '',
    album TEXT NOT NULL DEFAULT '',
    duration_ms INTEGER,
    artwork_url TEXT,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS music_items_title ON music_items(title);

CREATE TABLE IF NOT EXISTS music_room_targets (
    room_id TEXT NOT NULL REFERENCES music_rooms(id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    encrypted_target_id BLOB NOT NULL,
    target_ref TEXT NOT NULL,
    label TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL,
    PRIMARY KEY(room_id,provider)
);

CREATE TABLE IF NOT EXISTS music_queue (
    room_id TEXT NOT NULL REFERENCES music_rooms(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    item_id TEXT NOT NULL REFERENCES music_items(id) ON DELETE CASCADE,
    added_at TEXT NOT NULL,
    PRIMARY KEY(room_id,position)
);
CREATE INDEX IF NOT EXISTS music_queue_item ON music_queue(room_id,item_id);

CREATE TABLE IF NOT EXISTS music_favorites (
    room_id TEXT NOT NULL REFERENCES music_rooms(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES music_items(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    PRIMARY KEY(room_id,item_id)
);

CREATE TABLE IF NOT EXISTS music_playlists (
    id TEXT PRIMARY KEY,
    room_id TEXT NOT NULL REFERENCES music_rooms(id) ON DELETE CASCADE,
    name TEXT NOT NULL COLLATE NOCASE,
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(room_id,name)
);
CREATE TABLE IF NOT EXISTS music_playlist_items (
    playlist_id TEXT NOT NULL REFERENCES music_playlists(id) ON DELETE CASCADE,
    position INTEGER NOT NULL,
    item_id TEXT NOT NULL REFERENCES music_items(id) ON DELETE CASCADE,
    added_at TEXT NOT NULL,
    PRIMARY KEY(playlist_id,position)
);

CREATE TABLE IF NOT EXISTS music_sessions (
    room_id TEXT PRIMARY KEY REFERENCES music_rooms(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    state_json TEXT NOT NULL DEFAULT '{}',
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
    started_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS music_local_roots (
    id TEXT PRIMARY KEY,
    encrypted_path BLOB NOT NULL,
    path_ref TEXT NOT NULL UNIQUE,
    label TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS music_local_tracks (
    root_id TEXT NOT NULL REFERENCES music_local_roots(id) ON DELETE CASCADE,
    track_ref TEXT NOT NULL,
    item_id TEXT NOT NULL REFERENCES music_items(id) ON DELETE CASCADE,
    encrypted_metadata BLOB NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(root_id,track_ref)
);
CREATE INDEX IF NOT EXISTS music_local_tracks_item
    ON music_local_tracks(item_id);