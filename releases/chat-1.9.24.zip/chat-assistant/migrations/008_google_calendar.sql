CREATE TABLE connected_accounts (
    provider TEXT PRIMARY KEY,
    encrypted_client_id BLOB,
    encrypted_client_secret BLOB,
    encrypted_access_token BLOB,
    encrypted_refresh_token BLOB,
    scopes TEXT NOT NULL DEFAULT '[]',
    expires_at TEXT,
    email TEXT,
    display_name TEXT,
    status TEXT NOT NULL DEFAULT 'configured',
    failure_code TEXT,
    needs_reauthorization INTEGER NOT NULL DEFAULT 0,
    selected_calendar_ids TEXT NOT NULL DEFAULT '[]',
    writable_calendar_id TEXT,
    last_sync_at TEXT,
    updated_at TEXT NOT NULL
);

CREATE TABLE oauth_pending (
    provider TEXT NOT NULL,
    state_hash TEXT NOT NULL,
    binding_hash TEXT NOT NULL,
    encrypted_verifier BLOB NOT NULL,
    expires_at TEXT NOT NULL,
    consumed_at TEXT,
    PRIMARY KEY(provider,state_hash)
);
CREATE INDEX oauth_pending_expiry ON oauth_pending(provider,expires_at);

CREATE TABLE calendar_sync_state (
    provider TEXT NOT NULL,
    calendar_id TEXT NOT NULL,
    sync_token TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(provider,calendar_id)
);

CREATE TABLE calendar_event_cache (
    provider TEXT NOT NULL,
    calendar_id TEXT NOT NULL,
    calendar_name TEXT NOT NULL DEFAULT '',
    event_id TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT '',
    start_at TEXT NOT NULL,
    end_at TEXT NOT NULL,
    all_day INTEGER NOT NULL DEFAULT 0,
    timezone TEXT,
    location TEXT,
    html_link TEXT,
    recurring_event_id TEXT,
    status TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY(provider,calendar_id,event_id)
);
CREATE INDEX calendar_cache_start ON calendar_event_cache(provider,start_at);
CREATE INDEX calendar_cache_updated ON calendar_event_cache(provider,updated_at);

CREATE TABLE calendar_drafts (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    calendar_id TEXT NOT NULL,
    calendar_name TEXT NOT NULL,
    title TEXT NOT NULL,
    start_at TEXT NOT NULL,
    end_at TEXT NOT NULL,
    timezone TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('pending','claimed','created','expired','failed')),
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    finished_at TEXT
);

CREATE TABLE briefing_preferences (
    id INTEGER PRIMARY KEY CHECK(id=1),
    timezone TEXT NOT NULL DEFAULT 'UTC',
    meeting_alert_enabled INTEGER NOT NULL DEFAULT 0,
    meeting_lead_minutes INTEGER NOT NULL DEFAULT 10,
    briefing_enabled INTEGER NOT NULL DEFAULT 0,
    briefing_time TEXT NOT NULL DEFAULT '08:00',
    weekdays TEXT NOT NULL DEFAULT '[0,1,2,3,4]',
    sections TEXT NOT NULL DEFAULT '["calendar","weather","news"]',
    updated_at TEXT NOT NULL
);

CREATE TABLE briefing_runs (
    dedup_key TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    scheduled_for TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    finished_at TEXT
);
CREATE INDEX briefing_runs_created ON briefing_runs(created_at);