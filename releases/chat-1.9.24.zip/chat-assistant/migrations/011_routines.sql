-- User-authored routines.  Definitions are versioned and execution history is
-- deliberately separate from mutable routine metadata.
CREATE TABLE routines (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
    current_version INTEGER NOT NULL,
    fence INTEGER NOT NULL DEFAULT 1,
    template_draft INTEGER NOT NULL DEFAULT 0 CHECK(template_draft IN (0,1)),
    trigger_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    deleted_at TEXT
);

CREATE TABLE routine_versions (
    routine_id TEXT NOT NULL REFERENCES routines(id),
    version INTEGER NOT NULL,
    definition_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY(routine_id, version)
);
CREATE TRIGGER routine_versions_no_update
BEFORE UPDATE ON routine_versions
BEGIN
    SELECT RAISE(ABORT, 'routine versions are immutable');
END;
CREATE TRIGGER routine_versions_no_delete
BEFORE DELETE ON routine_versions
BEGIN
    SELECT RAISE(ABORT, 'routine versions are immutable');
END;

CREATE TABLE routine_aliases (
    normalized_alias TEXT PRIMARY KEY,
    routine_id TEXT NOT NULL REFERENCES routines(id) ON DELETE CASCADE,
    is_name INTEGER NOT NULL DEFAULT 0 CHECK(is_name IN (0,1))
);
CREATE INDEX routine_aliases_routine ON routine_aliases(routine_id);

CREATE TABLE routine_runs (
    id TEXT PRIMARY KEY,
    routine_id TEXT NOT NULL REFERENCES routines(id),
    version INTEGER NOT NULL,
    source TEXT NOT NULL,
    occurrence_key TEXT,
    status TEXT NOT NULL,
    summary TEXT NOT NULL DEFAULT '',
    started_at TEXT NOT NULL,
    finished_at TEXT
);
CREATE INDEX routine_runs_routine ON routine_runs(routine_id, started_at DESC);

CREATE TABLE routine_run_steps (
    run_id TEXT NOT NULL REFERENCES routine_runs(id) ON DELETE CASCADE,
    step_index INTEGER NOT NULL,
    action_type TEXT NOT NULL,
    status TEXT NOT NULL,
    duration_ms INTEGER NOT NULL DEFAULT 0,
    summary TEXT NOT NULL DEFAULT '',
    PRIMARY KEY(run_id, step_index)
);

CREATE TABLE routine_trigger_claims (
    occurrence_key TEXT PRIMARY KEY,
    routine_id TEXT NOT NULL REFERENCES routines(id),
    scheduled_for TEXT NOT NULL,
    status TEXT NOT NULL,
    run_id TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX routine_claims_created ON routine_trigger_claims(created_at);