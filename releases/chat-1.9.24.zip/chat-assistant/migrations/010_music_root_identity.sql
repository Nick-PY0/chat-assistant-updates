-- Bind configured local-library roots to the same filesystem object across
-- scans and streams. Paths remain encrypted; device/inode are internal only.
ALTER TABLE music_local_roots ADD COLUMN root_device INTEGER;
ALTER TABLE music_local_roots ADD COLUMN root_inode INTEGER;