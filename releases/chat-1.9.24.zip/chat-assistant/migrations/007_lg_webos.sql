CREATE TABLE IF NOT EXISTS lg_webos_devices (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT 'LG TV',
    host TEXT NOT NULL,
    mac_address TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 0,
    paired INTEGER NOT NULL DEFAULT 0,
    last_state_json TEXT NOT NULL DEFAULT '{}',
    last_seen_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);