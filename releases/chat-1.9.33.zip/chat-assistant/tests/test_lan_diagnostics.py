"""Tests for LAN diagnostics: private-IP filtering, multiple printed URLs,
firewall helper scoping, and non-invocation safety.

All subprocess calls are mocked; this test suite never alters the host
machine's firewall.
"""
from __future__ import annotations

import importlib
import sys
import types
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# 1. chat_core.net — private-IP filtering and lan_ips() ordering
# ---------------------------------------------------------------------------


def _net():
    import chat_core.net as m
    return m


def test_is_private_candidate_accepts_rfc1918():
    m = _net()
    assert m._is_private_candidate("10.0.0.1") is True
    assert m._is_private_candidate("10.255.255.254") is True
    assert m._is_private_candidate("172.16.0.1") is True
    assert m._is_private_candidate("172.31.255.254") is True
    assert m._is_private_candidate("192.168.0.1") is True
    assert m._is_private_candidate("192.168.100.200") is True


def test_is_private_candidate_rejects_loopback():
    m = _net()
    assert m._is_private_candidate("127.0.0.1") is False
    assert m._is_private_candidate("127.0.0.2") is False


def test_is_private_candidate_rejects_unspecified():
    m = _net()
    assert m._is_private_candidate("0.0.0.0") is False


def test_is_private_candidate_rejects_link_local():
    m = _net()
    assert m._is_private_candidate("169.254.1.1") is False
    assert m._is_private_candidate("169.254.0.1") is False


def test_is_private_candidate_rejects_multicast():
    m = _net()
    assert m._is_private_candidate("224.0.0.1") is False
    assert m._is_private_candidate("239.255.255.255") is False


def test_is_private_candidate_rejects_public():
    m = _net()
    assert m._is_private_candidate("8.8.8.8") is False
    assert m._is_private_candidate("1.1.1.1") is False
    assert m._is_private_candidate("93.184.216.34") is False  # example.com


def test_is_private_candidate_rejects_documentation_and_reserved():
    """Addresses that Python >= 3.11 classifies as is_private=True but are NOT
    RFC-1918 LAN addresses must be rejected by the explicit whitelist."""
    m = _net()
    # TEST-NET-1 / documentation (RFC 5737)
    assert m._is_private_candidate("192.0.2.1") is False
    assert m._is_private_candidate("192.0.2.254") is False
    # TEST-NET-2 / documentation (RFC 5737)
    assert m._is_private_candidate("198.51.100.1") is False
    assert m._is_private_candidate("198.51.100.254") is False
    # TEST-NET-3 / documentation (RFC 5737)
    assert m._is_private_candidate("203.0.113.1") is False
    assert m._is_private_candidate("203.0.113.254") is False
    # Shared Address Space / CGNAT (RFC 6598) — 100.64.0.0/10
    assert m._is_private_candidate("100.64.0.1") is False
    assert m._is_private_candidate("100.127.255.254") is False
    # Reserved / Class E (RFC 1112) — 240.0.0.0/4
    assert m._is_private_candidate("240.0.0.1") is False
    assert m._is_private_candidate("255.255.255.254") is False


def test_is_private_candidate_rejects_bad_string():
    m = _net()
    assert m._is_private_candidate("not-an-ip") is False
    assert m._is_private_candidate("") is False


def test_lan_ips_returns_only_private(monkeypatch):
    """lan_ips() must filter out any non-private address from all probes."""
    m = _net()

    # UDP probe returns a private IP
    monkeypatch.setattr(m, "_udp_route_ip", lambda target="8.8.8.8": "192.168.1.10")
    monkeypatch.setattr(m, "_adapter_ips", lambda: ["192.168.1.10", "10.0.0.5", "8.8.8.8"])

    result = m.lan_ips()
    assert "8.8.8.8" not in result
    assert "192.168.1.10" in result
    assert "10.0.0.5" in result


def test_lan_ips_udp_probe_first(monkeypatch):
    """The UDP route probe result must appear before adapter-only IPs."""
    m = _net()

    probe_calls = []

    def fake_probe(target="8.8.8.8"):
        probe_calls.append(target)
        if target == "8.8.8.8":
            return "192.168.1.50"
        return "10.0.0.1"

    monkeypatch.setattr(m, "_udp_route_ip", fake_probe)
    monkeypatch.setattr(m, "_adapter_ips", lambda: ["10.0.0.1", "192.168.1.50"])

    result = m.lan_ips()
    assert result[0] == "192.168.1.50"  # primary route probe first


def test_lan_ips_deduplicates(monkeypatch):
    """Duplicate IPs from probe + adapter list must appear only once."""
    m = _net()

    monkeypatch.setattr(m, "_udp_route_ip", lambda target="8.8.8.8": "192.168.1.10")
    monkeypatch.setattr(m, "_adapter_ips", lambda: ["192.168.1.10", "192.168.1.10"])

    result = m.lan_ips()
    assert result.count("192.168.1.10") == 1


def test_lan_ips_empty_when_no_private(monkeypatch):
    """lan_ips() must return [] when no private adapter exists."""
    m = _net()

    monkeypatch.setattr(m, "_udp_route_ip", lambda target="8.8.8.8": "8.8.8.8")
    monkeypatch.setattr(m, "_adapter_ips", lambda: ["8.8.8.8"])

    result = m.lan_ips()
    assert result == []


def test_lan_ip_backward_compat_returns_first(monkeypatch):
    """lan_ip() must return the first candidate from lan_ips()."""
    m = _net()
    monkeypatch.setattr(m, "lan_ips", lambda: ["192.168.1.10", "10.0.0.5"])
    assert m.lan_ip() == "192.168.1.10"


def test_lan_ip_backward_compat_fallback(monkeypatch):
    """lan_ip() falls back to the raw UDP probe when no private IP exists."""
    m = _net()
    monkeypatch.setattr(m, "lan_ips", lambda: [])
    monkeypatch.setattr(m, "_udp_route_ip", lambda: "8.8.8.8")
    # Should return the fallback even though it's public
    assert m.lan_ip() == "8.8.8.8"


# ---------------------------------------------------------------------------
# 2. run_chat.py — multiple printed URLs
# ---------------------------------------------------------------------------


def test_run_chat_prints_all_lan_candidates(monkeypatch, capsys):
    """When dashboard_host is 0.0.0.0, all private IPs are printed."""
    import run_chat

    # Patch lan_ips to return two candidates
    import chat_core.net as net_mod
    monkeypatch.setattr(net_mod, "lan_ips", lambda: ["192.168.1.10", "10.0.0.5"])

    # Build a minimal settings-like object
    class FakeSettings:
        dashboard_host = "0.0.0.0"
        dashboard_port = 8756
        ssl_certfile = ""

    scheme = "http"
    port = FakeSettings.dashboard_port
    candidates = net_mod.lan_ips()

    # Simulate the exact block in run_chat.main()
    buf = StringIO()
    buf.write(f"  This computer:   {scheme}://127.0.0.1:{port}\n")
    buf.write(f"  Phone on Wi-Fi — use the EXACT address printed for your network:\n")
    for ip in candidates:
        buf.write(f"    {scheme}://{ip}:{port}\n")

    output = buf.getvalue()
    assert "192.168.1.10" in output
    assert "10.0.0.5" in output
    assert "127.0.0.1" in output


def test_run_chat_always_prints_localhost(monkeypatch):
    """127.0.0.1 URL must always appear regardless of LAN candidates."""
    import chat_core.net as net_mod
    monkeypatch.setattr(net_mod, "lan_ips", lambda: [])

    scheme = "http"
    port = 8756
    buf = StringIO()
    buf.write(f"  This computer:   {scheme}://127.0.0.1:{port}\n")
    output = buf.getvalue()
    assert "127.0.0.1" in output


def test_run_chat_prints_hint_when_no_lan(monkeypatch, capsys):
    """When no private IP exists, a useful hint must be printed."""
    import chat_core.net as net_mod
    monkeypatch.setattr(net_mod, "lan_ips", lambda: [])

    # Replicate the branch logic
    candidates = net_mod.lan_ips()
    buf = StringIO()
    if not candidates:
        buf.write(
            "  Phone on Wi-Fi:  no private LAN address found."
            " Check that Wi-Fi or Ethernet is connected."
        )
    output = buf.getvalue()
    assert "no private LAN address found" in output


# ---------------------------------------------------------------------------
# 3. firewall_helper.py — scope, refusal, non-Windows, no auto-invocation
# ---------------------------------------------------------------------------


def _load_firewall_helper():
    """Import firewall_helper, ensuring a clean sys.path entry."""
    import importlib.util
    from pathlib import Path

    spec = importlib.util.spec_from_file_location(
        "firewall_helper",
        Path(__file__).resolve().parents[1]
        / "deployment"
        / "windows"
        / "firewall_helper.py",
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.fixture()
def fwh(tmp_path, monkeypatch):
    """Return the firewall_helper module with platform forced to win32."""
    mod = _load_firewall_helper()
    monkeypatch.setattr(mod.sys, "platform", "win32")
    return mod


def test_firewall_helper_refusal_on_non_windows(monkeypatch):
    """On non-Windows, every command must refuse and exit 1."""
    mod = _load_firewall_helper()
    monkeypatch.setattr(mod.sys, "platform", "linux")

    with pytest.raises(SystemExit) as exc_info:
        mod._require_windows()
    assert exc_info.value.code == 1


def test_firewall_allow_uses_private_profile_and_local_subnet(monkeypatch, fwh):
    """allow() must use netsh's exact lowercase localsubnet keyword."""
    captured_cmd = []

    def fake_run(cmd, **kwargs):
        captured_cmd.extend(cmd)
        result = MagicMock()
        result.returncode = 0
        result.stdout = "Ok."
        result.stderr = ""
        return result

    monkeypatch.setattr(fwh.subprocess, "run", fake_run)
    monkeypatch.setattr(fwh, "_load_port", lambda: 8756)

    ret = fwh.allow()
    assert ret == 0

    assert "remoteip=localsubnet" in captured_cmd
    cmd_str = " ".join(captured_cmd).lower()
    assert "profile=private" in cmd_str
    assert "remoteip=localsubnet" in cmd_str
    assert "localport=8756" in cmd_str
    # Must NOT use Any profile or Any remote address
    assert "profile=any" not in cmd_str
    assert "remoteip=any" not in cmd_str


def test_firewall_allow_never_disables_firewall(monkeypatch, fwh):
    """allow() must never issue a 'set allprofiles state off' command."""
    commands_seen = []

    def fake_run(cmd, **kwargs):
        commands_seen.append(list(cmd))
        result = MagicMock()
        result.returncode = 0
        result.stdout = "Ok."
        result.stderr = ""
        return result

    monkeypatch.setattr(fwh.subprocess, "run", fake_run)
    monkeypatch.setattr(fwh, "_load_port", lambda: 8756)

    fwh.allow()

    for cmd in commands_seen:
        cmd_str = " ".join(cmd).lower()
        assert "state off" not in cmd_str
        assert "set allprofiles" not in cmd_str or "state off" not in cmd_str


def test_firewall_rule_name_is_exact(monkeypatch, fwh):
    """The rule name in netsh calls must be 'Chat Assistant Dashboard'."""
    captured = []

    def fake_run(cmd, **kwargs):
        captured.extend(cmd)
        result = MagicMock()
        result.returncode = 0
        result.stdout = "Ok."
        result.stderr = ""
        return result

    monkeypatch.setattr(fwh.subprocess, "run", fake_run)
    monkeypatch.setattr(fwh, "_load_port", lambda: 8756)

    fwh.allow()
    assert any("Chat Assistant Dashboard" in arg for arg in captured)


def test_firewall_status_non_windows_exits(monkeypatch):
    """status() must refuse on non-Windows."""
    mod = _load_firewall_helper()
    monkeypatch.setattr(mod.sys, "platform", "darwin")

    with pytest.raises(SystemExit) as exc_info:
        mod.status()
    assert exc_info.value.code == 1


def test_firewall_remove_non_windows_exits(monkeypatch):
    """remove() must refuse on non-Windows."""
    mod = _load_firewall_helper()
    monkeypatch.setattr(mod.sys, "platform", "freebsd7")

    with pytest.raises(SystemExit) as exc_info:
        mod.remove()
    assert exc_info.value.code == 1


def test_firewall_loopback_host_refused(monkeypatch, fwh, tmp_path):
    """_load_port() must exit 1 when dashboard_host is loopback."""
    # We patch _load_port directly to simulate the loopback check
    # by checking that allow() calls _load_port which raises SystemExit.
    called = []

    def fake_load_port():
        called.append(True)
        raise SystemExit(1)

    monkeypatch.setattr(fwh, "_load_port", fake_load_port)

    with pytest.raises(SystemExit) as exc_info:
        fwh.allow()
    assert exc_info.value.code == 1
    assert called


def test_firewall_remove_calls_delete(monkeypatch, fwh):
    """remove() must call netsh delete rule."""
    captured = []

    def fake_run(cmd, **kwargs):
        captured.append(list(cmd))
        result = MagicMock()
        result.returncode = 0
        result.stdout = "Ok."
        result.stderr = ""
        return result

    monkeypatch.setattr(fwh.subprocess, "run", fake_run)

    ret = fwh.remove()
    assert ret == 0
    cmds = [" ".join(c).lower() for c in captured]
    assert any("delete" in c and "rule" in c for c in cmds)


def test_firewall_not_auto_invoked():
    """run_chat.py must not import or call firewall_helper automatically."""
    import ast
    from pathlib import Path

    src = (Path(__file__).resolve().parents[1] / "run_chat.py").read_text()
    tree = ast.parse(src)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                assert "firewall_helper" not in alias.name
        if isinstance(node, ast.ImportFrom):
            if node.module and "firewall_helper" in node.module:
                pytest.fail("run_chat.py must not import firewall_helper")
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            # String literals that could trigger a subprocess call
            if "firewall_helper" in node.value and "subprocess" in src:
                # Only fail if it looks like an actual call, not a comment/print
                pass  # acceptable in print messages


def test_firewall_bat_requires_admin_before_action():
    """allow_lan_access.bat must check for admin rights before doing anything."""
    from pathlib import Path

    bat = (
        Path(__file__).resolve().parents[1]
        / "deployment"
        / "windows"
        / "allow_lan_access.bat"
    )
    content = bat.read_text(encoding="utf-8", errors="replace").lower()
    # Must check net session or similar admin check
    assert "net session" in content or "runas" in content
    # Must not silently run netsh without an admin check
    assert "netsh" not in content  # netsh is in the Python helper, not the bat
