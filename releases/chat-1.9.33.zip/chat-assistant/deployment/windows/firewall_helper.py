"""Windows Defender firewall helper for the Chat dashboard.

Creates, reports, or removes a narrowly-scoped inbound TCP rule so that
phones on the same LAN can reach the dashboard without opening it to the
internet.

Rule scope (always):
  - Profile:    Private only
  - Protocol:   TCP
  - Direction:  Inbound
  - RemoteIP:   localsubnet (same subnet only, not the internet)
  - LocalPort:  current dashboard_port from settings
  - Name:       Chat Assistant Dashboard

Usage (run as Administrator)::

    python deployment/windows/firewall_helper.py allow
    python deployment/windows/firewall_helper.py status
    python deployment/windows/firewall_helper.py remove

This script NEVER:
  - Disables the firewall.
  - Uses Profile=Any or RemoteIP=Any.
  - Runs automatically at startup.
  - Touches any rule other than "Chat Assistant Dashboard".

On non-Windows platforms every command prints a clear error and exits 1.
This script must be invoked explicitly by the user; it is never called
automatically by run_chat.py or any other Chat module.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

RULE_NAME = "Chat Assistant Dashboard"
_CHAT_ROOT = Path(__file__).resolve().parents[2]


def _require_windows() -> None:
    if sys.platform != "win32":
        print(
            "ERROR: Windows Defender firewall rules can only be managed on Windows.",
            file=sys.stderr,
        )
        raise SystemExit(1)


def _load_port() -> int:
    """Read dashboard_port from Chat settings without importing the full app."""
    sys.path.insert(0, str(_CHAT_ROOT))
    try:
        from chat_core.config import load_settings

        s = load_settings()
        if s.dashboard_host in ("127.0.0.1", "::1", "localhost"):
            print(
                "ERROR: dashboard_host is set to loopback (127.0.0.1). "
                "Phone access is currently disabled in settings. "
                "Enable it (Settings -> Dashboard access -> On) and restart "
                "Chat before running this helper.",
                file=sys.stderr,
            )
            raise SystemExit(1)
        return int(s.dashboard_port)
    except ImportError as exc:
        print(
            f"ERROR: could not load Chat settings ({exc}). "
            "Run this script from the chat-assistant folder.",
            file=sys.stderr,
        )
        raise SystemExit(1)


def _netsh(*args: str) -> "subprocess.CompletedProcess[str]":
    """Run netsh with the given arguments and return the result."""
    cmd = ["netsh", "advfirewall", "firewall"] + list(args)
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=False,
    )


def allow() -> int:
    """Create or replace the Chat firewall rule (requires Administrator)."""
    _require_windows()
    port = _load_port()

    # Remove any existing rule with the same name first (idempotent).
    _netsh("delete", "rule", f'name="{RULE_NAME}"')

    result = _netsh(
        "add",
        "rule",
        f'name="{RULE_NAME}"',
        "dir=in",
        "action=allow",
        "protocol=TCP",
        f"localport={port}",
        "profile=private",
        # Some Windows/netsh builds reject the mixed-case spelling even though
        # other builds accept it. Use the exact lowercase keyword shown by
        # ``netsh advfirewall firewall add rule`` on those systems.
        "remoteip=localsubnet",
        "enable=yes",
        f'description=Chat dashboard LAN access port {port}',
    )

    if result.returncode == 0:
        print(
            f"Firewall rule created: TCP port {port}, Private profile,"
            f" RemoteIP=localsubnet. Phone must be on the same Wi-Fi network."
        )
        return 0
    else:
        print(
            f"ERROR: netsh returned exit code {result.returncode}.\n"
            f"{result.stdout.strip()}\n{result.stderr.strip()}",
            file=sys.stderr,
        )
        print(
            "Make sure you are running as Administrator"
            " (right-click -> Run as administrator).",
            file=sys.stderr,
        )
        return 1


def status() -> int:
    """Print whether the Chat firewall rule exists and what it contains."""
    _require_windows()
    result = _netsh(
        "show",
        "rule",
        f'name="{RULE_NAME}"',
    )
    output = result.stdout.strip()
    if "No rules match the specified criteria" in output or result.returncode != 0:
        print(f'Rule "{RULE_NAME}" does not exist.')
        return 0
    print(output)
    return 0


def remove() -> int:
    """Delete the Chat firewall rule if it exists."""
    _require_windows()
    result = _netsh("delete", "rule", f'name="{RULE_NAME}"')
    if result.returncode == 0:
        print(f'Rule "{RULE_NAME}" removed.')
        return 0
    # netsh returns non-zero when no rule matched — treat as success
    if "No rules match" in result.stdout or "No rules match" in result.stderr:
        print(f'Rule "{RULE_NAME}" was not present.')
        return 0
    print(
        f"ERROR: netsh returned exit code {result.returncode}.\n"
        f"{result.stdout.strip()}\n{result.stderr.strip()}",
        file=sys.stderr,
    )
    return 1


def main() -> int:
    import argparse

    p = argparse.ArgumentParser(
        prog="firewall_helper",
        description=(
            "Manage the Chat Assistant Dashboard Windows Defender firewall rule. "
            "Run as Administrator."
        ),
    )
    p.add_argument(
        "action",
        choices=["allow", "status", "remove"],
        help=(
            "allow: create/replace the inbound rule; "
            "status: show current rule; "
            "remove: delete the rule"
        ),
    )
    args = p.parse_args()
    return {"allow": allow, "status": status, "remove": remove}[args.action]()


if __name__ == "__main__":
    raise SystemExit(main())
