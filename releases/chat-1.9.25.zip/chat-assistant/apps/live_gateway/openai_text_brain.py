"""OpenAI Responses provider for durable typed conversations."""

from __future__ import annotations

import json

from apps.live_gateway.prompts import typed_system_instructions
from chat_core.models.credentials import CredentialStore, utcnow
from chat_core.models.db import Database
from integrations.openai_text import (
    OpenAIResponsesClient,
    OpenAITextError,
    response_result,
    to_responses_tools,
)


MAX_TOOL_HOPS = 4


class NoOpenAITextCredential(OpenAITextError):
    """No eligible saved credential for the selected OpenAI text route."""


def _responses_input(messages: list[dict]) -> list[dict]:
    """Translate the service's provider-neutral history to Responses input."""
    converted: list[dict] = []
    for message in messages:
        role = str(message.get("role") or "user")
        content = message.get("content", "")
        if not isinstance(content, list):
            converted.append({"role": role, "content": str(content or "")})
            continue
        parts: list[dict] = []
        for part in content:
            if not isinstance(part, dict):
                continue
            kind = part.get("type")
            if kind == "text":
                parts.append({"type": "input_text", "text": str(part.get("text") or "")})
            elif kind == "image_url":
                value = part.get("image_url")
                url = value.get("url") if isinstance(value, dict) else value
                if isinstance(url, str) and url.startswith("data:image/"):
                    parts.append({"type": "input_image", "image_url": url, "detail": "auto"})
        converted.append({"role": role, "content": parts or [{
            "type": "input_text", "text": "Describe the attached image."
        }]})
    return converted


class OpenAITextBrain:
    def __init__(
        self,
        settings,
        db: Database,
        store: CredentialStore,
        tool_declarations: list[dict],
        tool_handler,
        *,
        client_factory=OpenAIResponsesClient,
    ) -> None:
        self.settings = settings
        self.db = db
        self.store = store
        self.tools = to_responses_tools(tool_declarations)
        self.tool_handler = tool_handler
        self.client_factory = client_factory

    async def _client(self) -> tuple[OpenAIResponsesClient, str]:
        credentials = [
            credential
            for credential in await self.store.list(provider="openai")
            if credential.status not in ("invalid", "disabled")
            and not (
                credential.retry_after
                and credential.retry_after > utcnow()
            )
        ]
        if not credentials:
            raise NoOpenAITextCredential(
                "Typed chat is set to OpenAI. Save an OpenAI API key on the Providers page, "
                "or choose Relay as the typed-chat provider in Settings. Images require OpenAI."
            )
        credential = credentials[0]
        try:
            secret = await self.store.get_secret(credential.id)
        except KeyError as exc:
            raise NoOpenAITextCredential(
                "The saved OpenAI API key could not be unlocked."
            ) from exc
        return self.client_factory(secret), credential.id

    @staticmethod
    def _with_sources(reply: str, sources: list[dict]) -> str:
        fresh = [source for source in sources if source.get("url") not in reply]
        if not fresh:
            return reply
        lines = ["", "Sources:"]
        lines.extend(f"- {source.get('title') or source['url']}: {source['url']}" for source in fresh)
        return reply.rstrip() + "\n".join(lines)

    async def ask(
        self, messages: list[dict], model: str, context: str = ""
    ) -> tuple[str, str]:
        client, credential_id = await self._client()
        instructions = typed_system_instructions(self.settings.system_prompt, context)
        payload = {
            "model": model,
            "instructions": instructions,
            "input": _responses_input(messages),
            "tools": self.tools,
            "tool_choice": "auto",
            "max_output_tokens": 2400,
        }

        used_model = model
        for _ in range(MAX_TOOL_HOPS):
            data = await client.create(payload)
            parsed = response_result(data)
            used_model = parsed["model"] or used_model
            usage = parsed["usage"]
            await self.db.usage(
                credential_id,
                "openai:responses",
                f"typed {used_model} in={usage.get('input_tokens', '?')} "
                f"out={usage.get('output_tokens', '?')}",
            )
            calls = parsed["tool_calls"]
            if not calls:
                reply = parsed["text"] or "I couldn't produce an answer. Please try that again."
                return self._with_sources(reply, parsed["sources"]), used_model

            outputs = []
            for call in calls:
                result = await self.tool_handler(
                    call["call_id"], call["name"], call["arguments"]
                )
                outputs.append({
                    "type": "function_call_output",
                    "call_id": call["call_id"],
                    "output": json.dumps(result, ensure_ascii=False),
                })
            payload = {
                "model": model,
                "instructions": instructions,
                "previous_response_id": parsed["id"],
                "input": outputs,
                "tools": self.tools,
                "tool_choice": "auto",
                "max_output_tokens": 2400,
            }

        return "I got stuck while using a tool. Please try that request again.", used_model
