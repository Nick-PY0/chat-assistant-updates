"""Low-power wake inference keeps reliability while reducing call cadence."""

from __future__ import annotations

import asyncio
import threading
from types import SimpleNamespace

import pytest

import apps.audio.engine as engine_module
from apps.audio.engine import AudioEngine, CHUNK
from chat_core.models.state import StateMachine


def _engine(settings, bus) -> AudioEngine:
    return AudioEngine(
        settings,
        bus,
        StateMachine(bus),
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
        on_wake=lambda: None,
        on_interrupt=lambda: None,
    )


def test_low_power_combines_two_80ms_frames(settings, bus):
    settings.low_power = True
    engine = _engine(settings, bus)
    first = b"a" * (CHUNK * 2)   # PCM16: two bytes per sample
    second = b"b" * (CHUNK * 2)

    assert engine._prepare_wake_input(first) is None
    assert engine._prepare_wake_input(second) == first + second
    assert engine._wake_batch == []


def test_normal_profile_keeps_original_80ms_cadence(settings, bus):
    settings.low_power = False
    engine = _engine(settings, bus)
    chunk = b"x" * (CHUNK * 2)

    assert engine._prepare_wake_input(chunk) == chunk
    assert engine._wake_batch == []


def test_switching_profile_discards_partial_sleeping_audio(settings, bus):
    settings.low_power = True
    engine = _engine(settings, bus)
    stale = b"s" * (CHUNK * 2)
    current = b"c" * (CHUNK * 2)

    assert engine._prepare_wake_input(stale) is None
    settings.low_power = False

    assert engine._prepare_wake_input(current) == current
    assert engine._wake_batch == []


@pytest.mark.asyncio
async def test_remote_wake_hit_resets_while_model_lock_is_held(
    settings, bus, monkeypatch
):
    settings.low_power = False
    settings.wake_threshold = 0.5
    monkeypatch.setattr(engine_module, "_AUDIO_OK", True)
    monkeypatch.setattr(
        engine_module,
        "np",
        SimpleNamespace(int16=object(), frombuffer=lambda data, dtype: data),
        raising=False,
    )
    engine = _engine(settings, bus)
    reset_lock_states = []

    class HitModel:
        def predict(self, _arr):
            return {"hey_jarvis": 0.99}

        def reset(self):
            reset_lock_states.append(engine._remote_wake_lock.locked())

    engine._wake_model = HitModel()
    assert await engine.run_remote_wake(b"\0" * (CHUNK * 2)) is True
    assert reset_lock_states == [True]


@pytest.mark.asyncio
async def test_remote_ownership_waits_for_inflight_host_predict(
    settings, bus, monkeypatch
):
    """bind() may gate host ownership while predict() is already off-thread.

    reset_remote_wake must wait for that prediction, never overlap model
    mutation with inference, and the stale host score must not fire a wake
    after ownership moved to the phone.
    """
    settings.low_power = False
    settings.wake_threshold = 0.5
    monkeypatch.setattr(engine_module, "_AUDIO_OK", True)
    monkeypatch.setattr(
        engine_module,
        "np",
        SimpleNamespace(int16=object(), frombuffer=lambda data, dtype: data),
        raising=False,
    )
    engine = _engine(settings, bus)
    engine.state.set(engine_module.ChatState.SLEEPING, "test")

    predict_started = threading.Event()
    release_predict = threading.Event()
    overlap = []

    class BlockingModel:
        in_predict = False
        resets = 0

        def predict(self, _arr):
            self.in_predict = True
            predict_started.set()
            release_predict.wait(2.0)
            self.in_predict = False
            return {"hey_jarvis": 0.99}

        def reset(self):
            if self.in_predict:
                overlap.append(True)
            self.resets += 1

    model = BlockingModel()
    engine._wake_model = model
    wake_calls = []
    engine.on_wake = lambda: wake_calls.append(True)
    predict_task = asyncio.create_task(
        engine._run_host_wake_predict(b"\0" * (CHUNK * 2))
    )
    assert await asyncio.to_thread(predict_started.wait, 1.0)

    # This is the synchronous authority handoff performed by bind().
    engine.remote_mic_active = True
    reset_task = asyncio.create_task(engine.reset_remote_wake())
    await asyncio.sleep(0.05)
    assert not reset_task.done(), "reset must wait for in-flight host predict"
    assert model.resets == 0

    release_predict.set()
    await asyncio.wait_for(reset_task, 1.0)
    scores = await asyncio.wait_for(predict_task, 1.0)
    assert overlap == []
    assert model.resets == 1
    assert scores is None, "stale host score is discarded after phone takeover"
    assert wake_calls == []


@pytest.mark.asyncio
async def test_audio_reload_cancellation_joins_predict_before_reset(
    settings, bus, monkeypatch
):
    """Runtime reload cancels the host audio task, but to_thread keeps running.

    Cancellation must remain inside the model lock until that worker exits, so
    a newly bound phone cannot reset the old model concurrently.
    """
    settings.low_power = False
    monkeypatch.setattr(engine_module, "_AUDIO_OK", True)
    monkeypatch.setattr(
        engine_module,
        "np",
        SimpleNamespace(int16=object(), frombuffer=lambda data, dtype: data),
        raising=False,
    )
    engine = _engine(settings, bus)
    started = threading.Event()
    release = threading.Event()
    overlap = []

    class BlockingModel:
        in_predict = False
        resets = 0

        def predict(self, _arr):
            self.in_predict = True
            started.set()
            release.wait(2.0)
            self.in_predict = False
            return {"hey_jarvis": 0.1}

        def reset(self):
            if self.in_predict:
                overlap.append(True)
            self.resets += 1

    model = BlockingModel()
    engine._wake_model = model
    host_task = asyncio.create_task(
        engine._run_host_wake_predict(b"\0" * (CHUNK * 2))
    )
    assert await asyncio.to_thread(started.wait, 1.0)

    # Equivalent ordering to Runtime.reload_audio cancellation followed by a
    # remote bind/reset attempt.
    host_task.cancel()
    engine.remote_mic_active = True
    reset_task = asyncio.create_task(engine.reset_remote_wake())
    await asyncio.sleep(0.05)
    assert not host_task.done(), "cancelled task must join its worker thread"
    assert not reset_task.done(), "new owner waits for cancelled old predict"
    assert model.resets == 0

    release.set()
    with pytest.raises(asyncio.CancelledError):
        await host_task
    await asyncio.wait_for(reset_task, 1.0)
    assert overlap == []
    assert model.resets == 1
