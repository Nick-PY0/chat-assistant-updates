"""Remote-native voice: a phone/tablet/computer owns its own cloud session.

The remote device is a first-class voice endpoint, not a peripheral of the
host microphone.  This service owns:

  * a DEDICATED LiveGateway instance (private EventBus + StateMachine) so a
    remote conversation gets the full credential-rotation / provider-fallback
    / transcript / tool stack without ever touching the host's session,
    queues, speaker route, or the dashboard's host state dot;
  * the single-owner device lease (epoch-fenced, explicit takeover, and a
    short reconnect grace window so a flaky phone link resumes instead of
    killing the conversation);
  * turn-stamped output framing so late audio from an interrupted answer can
    never play after a barge-in ("turn fencing");
  * host/remote exclusion: one assistant, one conversation at a time, with
    an explicit "take over" path in both directions;
  * companion (YouTube) voice-focus duck/pause/restore with the same
    session fencing rules as the host microphone path.

Event-loop hygiene: everything here runs on the shared asyncio loop.  All
methods that mutate lease/ownership state do so WITHOUT awaiting in between
(claims are atomic on the loop); anything slow lives in the dedicated
LiveGateway/LiveSession tasks.

Provider credentials never leave the server: the browser speaks only the
dashboard WebSocket protocol; this service speaks to the provider.
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import struct
import time
from dataclasses import dataclass, field
from hmac import compare_digest
from typing import Any, Callable

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from apps.live_gateway.gateway import LiveGateway

log = logging.getLogger("remote-voice")

# Reconnect grace: how long a mid-conversation lease survives a dropped
# socket before the session is ended.  Long enough for a phone to hop
# between networks; short enough that a walked-away phone doesn't hold the
# assistant hostage.
GRACE_SECONDS = 20.0

# Upstream audio contract (browser -> server).
UP_MAGIC = b"JV"
UP_VERSION = 1
UP_HEADER = struct.Struct("<2sBBI")          # magic, version, flags, seq
FRAME_SAMPLES = 1280                          # 80 ms at 16 kHz
FRAME_BYTES = FRAME_SAMPLES * 2

# Downstream audio contract (server -> browser).
DOWN_MAGIC = b"JA"
DOWN_VERSION = 1
DOWN_HEADER = struct.Struct("<2sBBHHI")       # magic, version, kind, turn, rsvd, seq
KIND_VOICE = 0                                # dedicated remote conversation audio
KIND_ANNOUNCE = 1                             # host alarms/announcements (broadcast)

_CLIENT_STATE = {
    ChatState.SLEEPING: "wake",
    ChatState.CONNECTING: "starting",
    ChatState.LISTENING: "listening",
    ChatState.SPEAKING: "speaking",
    ChatState.LOCAL_ONLY: "local_only",
    ChatState.MUTED: "wake",  # private machine is never muted; defensive only
}


def _drain(q: asyncio.Queue) -> int:
    n = 0
    while True:
        try:
            q.get_nowait()
            n += 1
        except asyncio.QueueEmpty:
            return n


@dataclass
class RemoteVoiceLease:
    """One device's exclusive claim on the remote voice endpoint."""

    epoch: int
    device_label: str
    resume_secret: str
    created_at: float = field(default_factory=time.monotonic)
    connected: bool = True
    session_generation: int = 0     # remote-gateway generation this lease started
    end_generation: int = 0         # explicit-end fence at session start
    stats: dict[str, Any] = field(default_factory=lambda: {
        "frames_in": 0,
        "bytes_in": 0,
        "seq_gaps": 0,
        "frames_gated": 0,
        "frames_forwarded": 0,
        "queue_drops_in": 0,
        "frames_out": 0,
        "bytes_out": 0,
        "queue_drops_out": 0,
        "clears": 0,
        "barge_ins": 0,
        "conversations": 0,
        "reconnects": 0,
        "malformed_frames": 0,
        "client": {},
    })


@dataclass
class _Binding:
    """The currently attached socket for the lease (send side only)."""

    epoch: int
    enqueue_text: Callable[[str], None]
    enqueue_audio: Callable[[bytes], None]
    # Priority lane: (payload, purge_kind) — the transport purges queued
    # audio of purge_kind (None = all) and sends the payload ahead of any
    # remaining audio.  Fencing controls must never queue behind stale audio.
    enqueue_control: Callable[[str, int | None], None]
    close: Callable[[int, str], Any]   # async callable(code, reason)


class RemoteVoiceService:
    """Single-owner remote voice endpoint backed by a dedicated gateway."""

    def __init__(
        self,
        settings: Settings,
        db: Database,
        store: CredentialStore,
        global_bus: EventBus,
        tool_declarations: list[dict],
        tools_dispatch: Callable,                    # ToolService.dispatch
        *,
        host_gateway: LiveGateway | None,
        get_audio: Callable[[], Any],                # -> AudioEngine | None
        broadcast=None,                              # announce-ONLY AudioBroadcast
        get_youtube: Callable[[], Any] = lambda: None,
        get_companion: Callable[[], Any] = lambda: None,
        on_global_stop: Callable[[], None] | None = None,
        on_stop_ringing: Callable[[], Any] | None = None,
        host_state=None,                             # host StateMachine (mute flag)
    ) -> None:
        self.settings = settings
        self.db = db
        self.global_bus = global_bus
        self._tools_dispatch = tools_dispatch
        self._host_gateway = host_gateway
        self._get_audio = get_audio
        self._broadcast = broadcast
        self._get_youtube = get_youtube
        self._get_companion = get_companion
        self._on_global_stop = on_global_stop
        self._on_stop_ringing = on_stop_ringing
        self._host_state = host_state

        # Dedicated conversation stack: private bus + state machine keep the
        # dashboard's host status dot and host announcer out of remote state.
        self.bus = EventBus()
        self.state = StateMachine(self.bus)
        self.gateway = LiveGateway(
            settings, db, store, self.bus, self.state,
            tool_declarations, self._dispatch_tools,
            component="remote-voice",
        )
        self.gateway.on_transcript = self._on_transcript

        self._lease: RemoteVoiceLease | None = None
        self._binding: _Binding | None = None
        self._epoch = 0
        self._turn = 1                    # 0 is reserved for "no turn yet"
        self._voice_seq = 0
        self._announce_seq = 0
        self._grace_task: asyncio.Task | None = None
        self._tasks: list[asyncio.Task] = []
        self._stopped = False

        # Voice-focus (companion media) fencing state — mirrors the host
        # microphone path: one duck/pause per companion bridge session,
        # cooldown against rapid re-fire, restore only when Jarvis ducked.
        self._vf_cooldown_until = 0.0
        self._vf_ducked_session = -1
        self._vf_paused_session = -1

    # ------------------------------------------------------------------
    # lifecycle
    # ------------------------------------------------------------------
    def start(self) -> None:
        self._tasks.append(asyncio.create_task(self.gateway.run(), name="remote-gateway"))
        self._tasks.append(asyncio.create_task(self._audio_pump(), name="remote-audio-pump"))
        self._tasks.append(asyncio.create_task(self._event_pump(), name="remote-event-pump"))
        self._tasks.append(asyncio.create_task(self._bus_relay(), name="remote-bus-relay"))
        if self._broadcast is not None:
            self._tasks.append(asyncio.create_task(self._announce_pump(), name="remote-announce-pump"))

    async def stop(self) -> None:
        self._stopped = True
        lease = self._lease
        if lease is not None:
            self.release(lease, "shutdown")
        await self.gateway.stop()
        self._cancel_grace()
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    # ------------------------------------------------------------------
    # ownership
    # ------------------------------------------------------------------
    @property
    def lease(self) -> RemoteVoiceLease | None:
        return self._lease

    @property
    def conversation_active(self) -> bool:
        """True while the remote device owns a live conversation intent.

        Includes the reconnect grace window: the host must not steal the
        wake word from a phone that is mid-sentence on a flaky link.
        """
        return self._lease is not None and self.gateway.session_intent_active

    @property
    def current_turn(self) -> int:
        return self._turn

    def is_current(self, lease: RemoteVoiceLease | None) -> bool:
        return lease is not None and self._lease is lease

    def holder_info(self) -> dict:
        lease = self._lease
        if lease is None:
            return {}
        return {
            "device": lease.device_label,
            "connected": lease.connected,
            "since": round(time.monotonic() - lease.created_at, 1),
            "in_conversation": self.gateway.session_intent_active,
        }

    def claim(
        self,
        device_label: str,
        *,
        takeover: bool = False,
        resume_epoch: int | None = None,
        resume_secret: str | None = None,
    ) -> tuple[str, RemoteVoiceLease | dict]:
        """Claim the remote voice endpoint.  Atomic: no awaits inside.

        Returns one of:
          ("resumed", lease)   — same device re-attached within grace
          ("granted", lease)   — fresh claim
          ("busy", holder)     — another device holds the lease
        """
        old = self._lease
        if old is not None:
            if (
                not old.connected
                and resume_secret is not None
                and resume_epoch == old.epoch
                and compare_digest(old.resume_secret, resume_secret)
            ):
                old.connected = True
                old.stats["reconnects"] += 1
                self._cancel_grace()
                return "resumed", old
            if not takeover:
                return "busy", self.holder_info()
            # Explicit takeover: revoke whatever is there (connected or in
            # grace), end its conversation, and grant a fresh epoch.
            self._revoke_binding("taken_over", device_label)
            self._teardown_lease(old, "taken over by another device")

        self._epoch += 1
        lease = RemoteVoiceLease(
            epoch=self._epoch,
            device_label=device_label,
            resume_secret=secrets.token_hex(16),
        )
        self._lease = lease
        return "granted", lease

    def bind(
        self,
        lease: RemoteVoiceLease,
        *,
        enqueue_text: Callable[[str], None],
        enqueue_audio: Callable[[bytes], None],
        close: Callable[[int, str], Any],
        enqueue_control: Callable[[str, int | None], None] | None = None,
    ) -> _Binding | None:
        """Attach the socket's send side.  Returns None for a stale lease."""
        if not self.is_current(lease):
            return None
        if enqueue_control is None:
            # Transport without a priority lane: controls share text FIFO.
            def enqueue_control(payload: str, purge_kind: int | None = None) -> None:
                enqueue_text(payload)
        binding = _Binding(
            epoch=lease.epoch,
            enqueue_text=enqueue_text,
            enqueue_audio=enqueue_audio,
            enqueue_control=enqueue_control,
            close=close,
        )
        self._binding = binding
        lease.connected = True
        self._cancel_grace()
        audio = self._get_audio()
        if audio is not None:
            # The shared wake model is exclusively the remote device's while
            # a socket is attached (openwakeword keeps rolling feature state;
            # interleaving two audio streams through it corrupts detection).
            audio.remote_mic_active = True
        return binding

    def detach(self, lease: RemoteVoiceLease, binding: _Binding | None = None) -> None:
        """Socket went away.  Keep a mid-conversation lease for GRACE_SECONDS.

        *binding* fences the call: a socket that was already revoked or
        replaced (its binding is no longer current) must not unbind the new
        socket or release the new owner's lease.
        """
        if not self.is_current(lease):
            return
        if binding is not None and self._binding is not binding:
            return
        self._binding = None
        lease.connected = False
        audio = self._get_audio()
        if audio is not None:
            audio.remote_mic_active = False
        if self.gateway.session_intent_active and not self._stopped:
            self._cancel_grace()
            self._grace_task = asyncio.create_task(self._grace_expiry(lease))
        else:
            self.release(lease, "device disconnected")

    def release(self, lease: RemoteVoiceLease, reason: str) -> None:
        """Fully release the lease (idempotent, atomic)."""
        if not self.is_current(lease):
            return
        # Notify + close a still-bound socket (no-op when already detached).
        self._revoke_binding(reason, None)
        self._teardown_lease(lease, reason)
        self._lease = None
        self._cancel_grace()
        audio = self._get_audio()
        if audio is not None:
            audio.remote_mic_active = False
        stats = {k: v for k, v in lease.stats.items() if k != "client"}
        log.info("remote voice lease released (%s): %s", reason, stats)
        asyncio.ensure_future(self.db.log(
            "INFO", "remote-voice",
            f"{lease.device_label}: lease released ({reason}); "
            f"in={stats['frames_in']}f/{stats['bytes_in']}B "
            f"gaps={stats['seq_gaps']} fwd={stats['frames_forwarded']} "
            f"out={stats['frames_out']}f drops={stats['queue_drops_out']} "
            f"conversations={stats['conversations']} barge_ins={stats['barge_ins']}",
        ))

    def _teardown_lease(self, lease: RemoteVoiceLease, reason: str) -> None:
        """End the lease's conversation without awaiting (spawn slow parts)."""
        if self.gateway.session_intent_active:
            # Synchronous authority transfer FIRST: intent drops and the end
            # generation bumps before this method returns, so a takeover
            # claim can never "join" the previous device's conversation.
            # The provider socket close runs in the background, FENCED to the
            # generation we are ending — if the new owner has already started
            # a fresh conversation by the time the task runs, the stale close
            # becomes a no-op instead of killing the new session.
            gen = self.gateway.voice_session_generation
            self.gateway.request_end_session(reason)
            asyncio.ensure_future(
                self.gateway.end_session(reason, expected_generation=gen)
            )
            self._schedule_voice_focus_restore(immediate=True)
        _drain(self.gateway.audio_in)
        _drain(self.gateway.audio_out)

    def _revoke_binding(self, reason: str | None, by: str | None) -> None:
        binding = self._binding
        self._binding = None
        if binding is None:
            return
        if reason:
            try:
                # Revocation preempts EVERYTHING queued (purge all audio):
                # the device is being cut off; only the goodbye matters.
                binding.enqueue_control(_json({
                    "type": "revoked", "reason": reason,
                    **({"by": by} if by else {}),
                }), None)
            except Exception:
                pass
            try:
                asyncio.ensure_future(_maybe_await(binding.close(4412, reason)))
            except Exception:
                pass

    def _cancel_grace(self) -> None:
        if self._grace_task is not None:
            self._grace_task.cancel()
            self._grace_task = None

    async def _grace_expiry(self, lease: RemoteVoiceLease) -> None:
        try:
            await asyncio.sleep(GRACE_SECONDS)
        except asyncio.CancelledError:
            return
        if self.is_current(lease) and not lease.connected:
            self.release(lease, "device disconnected (grace expired)")

    # ------------------------------------------------------------------
    # conversation control
    # ------------------------------------------------------------------
    def _muted(self) -> bool:
        return bool(self._host_state is not None and self._host_state.muted)

    async def start_conversation(
        self,
        lease: RemoteVoiceLease,
        *,
        takeover_host: bool = False,
        source: str = "wake",
    ) -> str:
        """Start a remote conversation.  Returns a status string:

        "started" | "already" | "stale" | "muted" | "busy_host"
        """
        if not self.is_current(lease):
            return "stale"
        if self._muted():
            return "muted"
        hg = self._host_gateway
        if hg is not None and hg.session_intent_active:
            if not takeover_host:
                return "busy_host"
            await hg.end_session("remote device took over the conversation")
            if self._on_global_stop is not None:
                self._on_global_stop()  # silence host speakers immediately
            if not self.is_current(lease):
                return "stale"  # ownership changed while host was ending
        if self.gateway.session_intent_active:
            lease.session_generation = self.gateway.voice_session_generation
            lease.end_generation = self.gateway.voice_end_generation
            return "already"
        if self.gateway.has_open_session:
            # The previous conversation's provider socket is still closing in
            # the background.  request_session() would silently join that
            # dying session instead of opening a fresh one — finish the close
            # first, then re-validate ownership (it can change while awaiting).
            await self.gateway.end_session("superseded by new conversation")
            if not self.is_current(lease):
                return "stale"
        lease.session_generation = self.gateway.request_session()
        lease.end_generation = self.gateway.voice_end_generation
        lease.stats["conversations"] += 1
        await self.db.log(
            "INFO", "remote-voice",
            f"{lease.device_label}: conversation started ({source})",
        )
        await self._voice_focus_duck()
        await self._voice_focus_pause()
        return "started"

    def end_conversation(self, lease: RemoteVoiceLease, reason: str) -> None:
        """Explicit end (Goodbye button / end tool): keep the lease + socket."""
        if not self.is_current(lease):
            return
        self.interrupt_playback("session end")
        if self.gateway.session_intent_active:
            # Sync fence now (the caller reads voice_end_generation right
            # after this returns); async provider close in the background,
            # generation-fenced so it can never end a NEWER conversation the
            # user starts right after saying goodbye.
            gen = self.gateway.voice_session_generation
            self.gateway.request_end_session(reason)
            asyncio.ensure_future(
                self.gateway.end_session(reason, expected_generation=gen)
            )
        self._schedule_voice_focus_restore(immediate=True)

    def on_global_mute(self) -> None:
        """Dashboard mute: "muted" means NO live provider session anywhere.

        The runtime ends its host gateway session; this ends the remote one
        too (generation-fenced background close) and flushes both directions
        so a pre-mute frame can never reach the provider afterwards.  The
        lease and socket survive — the device shows the muted banner and can
        start a fresh conversation after unmute."""
        lease = self._lease
        if lease is None:
            return
        if self.gateway.session_intent_active:
            self.end_conversation(lease, "muted")
        else:
            self.interrupt_playback("muted")
        _drain(self.gateway.audio_in)

    def reapply_wake_ownership(self) -> None:
        """Re-assert remote ownership of the shared wake model.

        An audio-settings reload rebuilds AudioEngine with
        remote_mic_active=False; if a remote device is still attached, the
        host mic would start feeding the shared wake model alongside the
        remote stream (openwakeword keeps rolling feature state — two
        interleaved streams corrupt detection).  Called after every engine
        (re)build."""
        audio = self._get_audio()
        if audio is not None and self.has_connected_device:
            audio.remote_mic_active = True

    def interrupt_playback(self, reason: str = "") -> None:
        """Silence remote playback NOW and fence out late frames."""
        self.gateway.interrupt()
        _drain(self.gateway.audio_out)
        self._bump_turn(reason)

    @property
    def has_connected_device(self) -> bool:
        """A remote device is bound right now (announcements can be heard)."""
        lease = self._lease
        return bool(lease is not None and lease.connected and self._binding is not None)

    def _bump_turn(self, reason: str) -> None:
        self._turn = (self._turn + 1) & 0xFFFF or 1
        lease = self._lease
        if lease is not None:
            lease.stats["clears"] += 1
        # Priority + purge: every queued voice frame belongs to the turn
        # that just ended — a slow link must get the clear FIRST, never a
        # backlog of stale reply audio.
        self._send_control({
            "type": "clear", "scope": "voice", "turn": self._turn,
            **({"reason": reason} if reason else {}),
        }, purge_kind=KIND_VOICE)

    # ------------------------------------------------------------------
    # tool dispatch (wraps the shared ToolService)
    # ------------------------------------------------------------------
    async def _dispatch_tools(self, call_id: str, name: str, args: dict) -> dict:
        """Voice-control tools act on THIS session; everything else shares
        the host tool stack (reminders, memory, media, TV, weather...)."""
        if name in ("stop_speaking", "stop_output"):
            self.interrupt_playback("voice stop")
            # A ringing alarm should stop from anywhere — but ONLY the alarm.
            # Never rt.stop_output() here: that would interrupt the HOST
            # conversation and clear host playback from a remote device.
            if self._on_stop_ringing is not None:
                self._on_stop_ringing()
            return {"stopped": True}
        if name == "end_voice_session":
            self.interrupt_playback("goodbye")
            if self._on_stop_ringing is not None:
                self._on_stop_ringing()
            generation = self.gateway.voice_session_generation
            self.gateway.request_end_session(
                "voice stop command", expected_generation=generation
            )
            # Give the provider a brief chance to acknowledge the tool result,
            # then deterministically close the old socket.  Previously spoken
            # Goodbye relied on the provider to close itself; if it did not,
            # the phone appeared to return to wake mode while a stale provider
            # session remained open.  The generation fence makes this delayed
            # close harmless if a newer conversation has already started.
            asyncio.ensure_future(
                self._finish_spoken_goodbye(generation)
            )
            self._schedule_voice_focus_restore(immediate=True)
            return {"stopped": True, "session_ended": True}
        return await self._tools_dispatch(call_id, name, args)

    async def _finish_spoken_goodbye(self, generation: int) -> None:
        await asyncio.sleep(0.15)
        await self.gateway.end_session(
            "voice stop command", expected_generation=generation
        )

    # ------------------------------------------------------------------
    # outbound pumps
    # ------------------------------------------------------------------
    def _send_json(self, payload: dict) -> None:
        binding = self._binding
        if binding is None:
            return
        try:
            binding.enqueue_text(_json(payload))
        except Exception:
            log.debug("remote-voice enqueue_text failed", exc_info=True)

    def _send_control(self, payload: dict, purge_kind: int | None) -> None:
        """Send a fencing control on the priority lane (see _Binding)."""
        binding = self._binding
        if binding is None:
            return
        try:
            binding.enqueue_control(_json(payload), purge_kind)
        except Exception:
            log.debug("remote-voice enqueue_control failed", exc_info=True)

    def _send_audio(self, pcm: bytes, kind: int) -> None:
        binding = self._binding
        lease = self._lease
        if binding is None or lease is None:
            return
        if kind == KIND_VOICE:
            self._voice_seq = (self._voice_seq + 1) & 0xFFFFFFFF
            seq = self._voice_seq
        else:
            self._announce_seq = (self._announce_seq + 1) & 0xFFFFFFFF
            seq = self._announce_seq
        header = DOWN_HEADER.pack(DOWN_MAGIC, DOWN_VERSION, kind, self._turn, 0, seq)
        try:
            binding.enqueue_audio(header + pcm)
            lease.stats["frames_out"] += 1
            lease.stats["bytes_out"] += len(pcm)
        except Exception:
            log.debug("remote-voice enqueue_audio failed", exc_info=True)

    async def _audio_pump(self) -> None:
        """Dedicated remote session audio -> the bound socket, turn-stamped."""
        while True:
            pcm = await self.gateway.audio_out.get()
            if not pcm:
                continue
            self._send_audio(pcm, KIND_VOICE)

    # A withheld announcement older than this is never delivered late.
    _PENDING_TTL = 30.0

    async def _announce_pump(self) -> None:
        """Host alarms/announcements reach the phone too.

        The subscribed stream is a DEDICATED announce-only broadcast fed by
        the announcer — host conversation speech never enters it, so no
        content classification happens here (inferring "is this an
        announcement?" from host activity at dequeue time is exactly the
        pattern that leaked queued host-speech tails before the streams were
        split, and must never come back).

        Forwarding still PAUSES while the HOST gateway has an active session:
        the desk conversation takes precedence over announcement playback on
        the phone.  The pause policy is bounded latest-wins deferral — at
        most ONE announcement is withheld (a looping alarm ring keeps
        replacing it with fresher cycles), it is flushed once the desk goes
        quiet, dropped on dismissal ("clear"), and expires after
        _PENDING_TTL so a long pause can never end with a stale alert."""
        q = self._broadcast.subscribe()
        pending: tuple[float, bytes] | None = None
        loop = asyncio.get_event_loop()

        def host_busy() -> bool:
            hg = self._host_gateway
            return hg is not None and hg.session_intent_active

        try:
            while True:
                if pending is None:
                    item = await q.get()
                else:
                    try:  # withheld audio: poll for the desk going quiet
                        item = await asyncio.wait_for(q.get(), timeout=0.25)
                    except asyncio.TimeoutError:
                        item = None
                if item is not None:
                    kind, payload = item
                    if kind != "pcm":
                        # Dismissal: whatever was withheld must never replay,
                        # and a connected device flushes its announce lane NOW
                        # (clears pass through even during a host session).
                        pending = None
                        lease = self._lease
                        if lease is not None and lease.connected:
                            # Purge queued announce audio too: a dismissed
                            # alarm must stop ringing on the phone NOW, not
                            # after a backlog drains.
                            self._send_control(
                                {"type": "clear", "scope": "announce"},
                                purge_kind=KIND_ANNOUNCE,
                            )
                        continue
                    if host_busy():
                        pending = (loop.time(), payload)     # latest wins
                        continue
                    pending = None                           # superseded
                    lease = self._lease
                    if lease is None or not lease.connected:
                        continue
                    self._send_audio(payload, KIND_ANNOUNCE)
                elif not host_busy():
                    ts, payload = pending
                    pending = None
                    if loop.time() - ts > self._PENDING_TTL:
                        continue                             # stale: drop
                    lease = self._lease
                    if lease is None or not lease.connected:
                        continue
                    self._send_audio(payload, KIND_ANNOUNCE)
        finally:
            self._broadcast.unsubscribe(q)

    async def _event_pump(self) -> None:
        """Relay private gateway events to the bound client."""
        q = self.bus.subscribe("state", "interrupted", "local_only", "session")
        while True:
            ev = await q.get()
            if ev.topic == "state":
                raw = self.state.raw_state
                self._send_json({
                    "type": "state",
                    "state": _CLIENT_STATE.get(raw, "wake"),
                    "reason": ev.data.get("reason", ""),
                    "turn": self._turn,
                })
                if raw in (ChatState.SLEEPING, ChatState.LOCAL_ONLY):
                    # Natural end (inactivity/provider close) — restore media
                    # once it is clear the gateway is not mid-reconnect.
                    self._schedule_voice_focus_restore()
            elif ev.topic == "interrupted":
                # Provider confirmed a barge-in; make sure queued audio dies.
                _drain(self.gateway.audio_out)
                self._bump_turn("provider interrupt")
            elif ev.topic == "local_only":
                self._send_json({
                    "type": "local_only",
                    "quota": bool(ev.data.get("quota")),
                    "retry_at": ev.data.get("retry_at"),
                })
            elif ev.topic == "session":
                data = dict(ev.data)
                data["origin"] = "remote"
                self.global_bus.publish("session", **data)

    async def _bus_relay(self) -> None:
        """Global credential/setting changes drive the private gateway too."""
        q = self.global_bus.subscribe("credentials_changed", "quota_retry_window")
        while True:
            ev = await q.get()
            self.bus.publish(ev.topic, **ev.data)

    def _on_transcript(self, role: str, text: str) -> None:
        text = (text or "").strip()
        if text:
            self._send_json({"type": "transcript", "role": role, "text": text[:500]})

    # ------------------------------------------------------------------
    # companion voice focus (duck / pause / restore)
    # ------------------------------------------------------------------
    async def user_speech_onset(self) -> None:
        """Socket handler hook: the mic gate verified a user-speech onset."""
        await self._voice_focus_duck()

    async def _voice_focus_duck(self) -> None:
        """Duck companion volume on verified user-speech onset / wake."""
        youtube = self._get_youtube()
        if youtube is None or not youtube._companion_active():
            return
        if youtube.status not in ("playing", "buffering"):
            return
        now = time.monotonic()
        if now < self._vf_cooldown_until:
            return
        companion = self._get_companion()
        current_session = getattr(companion, "session", -1) if companion else -1
        if self._vf_ducked_session == current_session and current_session >= 0:
            return
        try:
            ducked = await youtube.voice_focus_duck()
        except Exception:
            return
        if ducked:
            self._vf_ducked_session = current_session
            self._vf_cooldown_until = now + 5.0

    async def _voice_focus_pause(self) -> None:
        """Pause companion on a confirmed conversation start (session-fenced)."""
        youtube = self._get_youtube()
        if youtube is None or not youtube._companion_active():
            return
        if youtube.status not in ("playing", "buffering"):
            return
        companion = self._get_companion()
        current_session = getattr(companion, "session", -1) if companion else -1
        if self._vf_paused_session == current_session and current_session >= 0:
            return
        try:
            paused = await youtube.voice_focus_pause()
        except Exception:
            return
        if paused:
            self._vf_paused_session = current_session

    def _schedule_voice_focus_restore(self, immediate: bool = False) -> None:
        """Restore companion media after the conversation truly ended.

        A short delay skips restores during the gateway's own maintenance
        reconnects (state dips to SLEEPING, then the same lease reconnects).
        YouTubeTool itself decides whether a restore is still valid — an
        explicit user media command in between clears its ducked flag, so a
        stale restore is a no-op (external-media fencing rule).
        """
        async def _restore(delay: float) -> None:
            if delay:
                await asyncio.sleep(delay)
            if self.gateway.session_intent_active:
                return  # conversation is live again (or still); not an end
            youtube = self._get_youtube()
            if youtube is None:
                return
            try:
                await youtube.voice_focus_restore()
            except Exception:
                pass

        asyncio.ensure_future(_restore(0.0 if immediate else 1.0))

    # ------------------------------------------------------------------
    # diagnostics
    # ------------------------------------------------------------------
    def diagnostics(self) -> dict:
        lease = self._lease
        return {
            "active": lease is not None,
            "connected": bool(lease and lease.connected),
            "device": lease.device_label if lease else None,
            "holder": self.holder_info(),
            "state": self.state.raw_state.value if lease is not None else None,
            "conversation_active": self.conversation_active,
            "turn": self._turn,
            "epoch": lease.epoch if lease else 0,
            "stats": dict(lease.stats) if lease else {},
            "provider_credential": self.gateway.current_credential_id,
        }


def _json(payload: dict) -> str:
    import json

    return json.dumps(payload, separators=(",", ":"))


async def _maybe_await(result) -> None:
    if asyncio.iscoroutine(result):
        await result
