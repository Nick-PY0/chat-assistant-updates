#!/usr/bin/env node
// Executes the real background.js module with a minimal Chrome MV3 mock.
// This specifically guards the options-page Pair now path that previously
// returned no response when Chrome's MessageSender metadata varied.

import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";

let messageListener = null;

class StubWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;

  constructor(url) {
    this.url = url;
    this.readyState = StubWebSocket.CONNECTING;
    this.listeners = new Map();
  }

  addEventListener(type, callback) {
    this.listeners.set(type, callback);
  }

  close() {
    this.readyState = 3;
  }

  send() {}
}

globalThis.WebSocket = StubWebSocket;
globalThis.chrome = {
  runtime: {
    id: "test-extension-id",
    getURL: (path = "") => "chrome-extension://test-extension-id/" + path,
    onMessage: {
      addListener(callback) {
        messageListener = callback;
      },
    },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} },
    sendMessage() {},
  },
  storage: {
    local: {
      async get() { return {}; },
      async set() {},
      async remove() {},
    },
  },
  alarms: {
    create() {},
    onAlarm: { addListener() {} },
  },
  tabs: {
    async query() { return []; },
    async update() {},
    async create() {},
    async sendMessage() { return {}; },
  },
};

const backgroundUrl = new URL("../background.js", import.meta.url);
await import(pathToFileURL(backgroundUrl.pathname).href + "?message-test=1");

assert.equal(typeof messageListener, "function", "background listener was not registered");

let pairResponse;
const pairReturn = messageListener({
  type: "pair",
  token: "test-token-12345",
  bridgeBase: "ws://127.0.0.1:8757",
}, {
  // Deliberately reproduce a tabbed options page while omitting optional
  // sender.id/url/origin metadata. UI routing must not depend on these fields.
  tab: { id: 42 },
}, (response) => {
  pairResponse = response;
});

assert.deepEqual(pairResponse, { ok: true }, "Pair now did not receive an immediate acceptance");
assert.equal(pairReturn, false, "synchronously answered Pair now must not hold the message port open");

let contentResponse;
const contentReturn = messageListener({
  type: "content_hello",
}, {
  tab: { id: 7 },
  origin: "https://www.youtube.com",
  url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
}, (response) => {
  contentResponse = response;
});

assert.deepEqual(contentResponse, { ok: true, connected: false });
assert.equal(contentReturn, true);

console.log("Real background message test passed: Pair now is synchronously accepted.");