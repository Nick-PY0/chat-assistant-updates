# Chat — a private home voice assistant

Chat runs on your own Windows laptop. Say the wake word, talk to it like a
person (powered by Gemini Live), and it can set real timers, reminders and
wake-up alarms, tell you the weather, control your Govee lights, and work
your LG TV like a voice remote. When the internet or your Gemini quota runs
out, it keeps working locally: timers, reminders, lights, the TV, and the
dashboard never depend on the cloud.

Everything lives on your machine: keys are encrypted at rest, the dashboard
runs on localhost, and nothing is sent anywhere except Google (voice) and
Govee (lights). The LG TV is talked to directly on your own Wi-Fi — no LG
account, no cloud.

## What makes this build different

**Automatic key rotation, no paid fallback.** Add as many free Gemini API
keys as you like — from different Google projects — and Chat rotates through
all of them automatically. When one project's daily quota runs out it blocks
that whole project until the documented reset time (midnight Pacific) and
moves to the next key instantly, mid-conversation reconnects included. More
keys = more daily capacity. Keys you label with the same project name are
treated as one shared quota (redundancy, not extra capacity).

**As light as possible.** One quiet Python process, below-normal CPU
priority, a nearly silent console window, no busy loops. Voice packages are
optional — without them Chat still runs the dashboard, timers, rotation,
lights, and the TV.

## Quick start (Windows)

1. Install Python 3.11+ from https://www.python.org/downloads/
   (tick **"Add python.exe to PATH"** during install).
2. Download this project folder to your laptop and open it.
3. Double-click `deployment\windows\install.bat`
   — it creates a private environment and installs the core packages.
   Say yes to the voice packages if you want the microphone side.
4. Double-click `run_chat.bat`. A small black console window opens and prints
   the control panel address.
5. Open http://127.0.0.1:8756 in your browser, create your password, and add
   your first Gemini key on the **Credentials** page
   (free keys: https://aistudio.google.com/apikey).

That's it. Say "Hey Jarvis" (the default wake word — see below) and talk.

### Getting more daily talk time

Create additional free API keys in *different* Google Cloud projects
(AI Studio → gear icon → switch project → create key). Add each one on the
Credentials page. Leave the project label empty (each key becomes its own
quota group) or use labels to mark keys that share a project.

### Wake word

Pick one in **Settings → Voice & wake word**: Hey Jarvis (default), Alexa,
Hey Mycroft, or Hey Rhasspy. The change applies live — no restart. To use a
custom "Chat" wake word, train a model at
https://github.com/dscripka/openWakeWord#training-new-models, choose
"Custom model file..." in the picker, and give the path to the `.onnx` file.

### Voice announcements (optional, offline)

Run once to generate spoken status messages with Windows' built-in TTS:

    .venv\Scripts\python.exe deployment\windows\generate_announcements.py

Without them, announcements print to the console with a bell sound. Re-run
it after an update that adds new messages (this version added the quiet mode
confirmations and the missed-reminder notice).

### Saying "stop"

Chat already goes quiet the moment you talk over it. Saying just **"stop"**
(or "be quiet", "shut up", "never mind") cancels the rest of the answer
entirely, and every dashboard page has a red **Stop talking** button that
does the same — handy from a phone. Stop works offline too if the offline
recognizer below is installed.

### Offline voice commands (optional)

Speech understanding normally runs through Gemini, so when every key is
blocked, voice commands stop. Install the offline recognizer and spoken
commands keep working with zero internet:

1. The `vosk` package is included in `requirements-voice.txt`
   (or `.venv\Scripts\pip install vosk`).
2. Download a small English model from https://alphacephei.com/vosk/models
   — `vosk-model-small-en-us-0.15` (~40 MB) is plenty.
3. Unzip it and rename the folder to `assets\vosk-model` inside the Chat
   folder, or point **Settings → Offline speech model folder** at it.

In local-only mode Chat then hears the wake word, records your sentence,
transcribes it on your own CPU, and runs it against the same safe grammar as
the dashboard command box: timers, reminders and alarms, weather, quiet mode,
lights, the TV, device refresh, remember/recall/forget, stop. Anything outside
that grammar gets a short refusal announcement.

### Memory

Say "Chat, remember that the garage code is 4417" — stored permanently on
your machine. Ask "what do you remember about the garage?" and it answers
from its stored facts; "forget the garage code" deletes them. The
dashboard's **Memory** page lists everything with add and forget buttons.
Relevant saved facts are now added automatically as a small, bounded,
clearly separated context for typed and voice conversations, so ordinary
follow-up questions do not depend on the model deciding to call the recall
tool. Explicit recall still searches more broadly. This works consistently
through Gemini, OpenAI, Relay, and offline through the local grammar
("remember that...", "what do you remember", "forget ...").

### Reminders and alarms

"Remind me at 5 to take the chicken out", "remind me to stretch at 7:30 pm",
"wake me up at 7 am". Both survive restarts; anything that came due while
the machine was off is flagged as missed. An alarm (or a reminder) rings
loud — repeating bell pulses — until you say "stop", press a Stop button,
or tap **Dismiss** on the red banner that appears on every dashboard page.
With the offline voice installed, Chat also speaks the reminder text while
ringing. The **Reminders** page schedules them with a normal time picker,
and Settings controls how long and how loud they ring.

About ambiguous times: "at 5" means the next time the clock shows 5 —
5 pm if it's morning, 5 am tomorrow if it's evening. "Tonight at 9" is 9 pm.
"Tomorrow at 5" without am/pm takes the morning reading — say "5 pm" to be
precise.

### Weather

"What's the weather", "will it rain tomorrow". Set your town once in
**Settings → Weather & location** (type it, press Search, pick a result).
Forecasts come from Open-Meteo — free, no account, no API key — and the
Status page shows a weather card. Works by voice even in local-only mode;
with the offline voice installed Chat reads the forecast out loud.

### Google Calendar and morning briefings (optional)

Chat can connect one Google account, keep a bounded local schedule cache, answer
"what is my next meeting?", create an appointment only after you review and
confirm it, announce approaching meetings, and give a scheduled morning
briefing with calendar, weather, and news.

Set it up on the Windows computer running Chat—not from a phone:

1. In Google Cloud Console, enable the **Google Calendar API** for a project.
2. Configure the project's OAuth consent screen. If the app is in testing,
   add your Google address as a test user.
3. Create an OAuth 2.0 **Web application** client.
4. Open Chat's **Providers** page and copy the exact redirect URI shown there
   into the client's **Authorized redirect URIs**. The normal default is
   `http://127.0.0.1:8756/api/calendar/oauth/callback`; use the value shown by
   your own dashboard if the port or local HTTPS setting differs.
5. Paste the client ID and client secret into Providers and press **Connect**.
   Google opens in the same local browser. Choose the account and approve the
   requested access, then return to Providers to choose readable calendars and
   one default writable calendar.

Chat requests only identity/email, Calendar read-only, and Calendar event-write
scopes. The OAuth client settings, access token, refresh token, and PKCE
verifier are encrypted in Chat's local vault. They are never shown again in
the dashboard, APIs, logs, or tool results. Normalized event occurrences are
cached locally without attendee lists so schedule reads still work during a
temporary Google outage. Disconnecting clears tokens, calendar selections,
sync state, and cached events while retaining the encrypted client
configuration for an easy reconnect.

Use the **Calendar** page to see the next 14 days, review and confirm an
appointment, choose the meeting-alert lead time, and set the briefing timezone,
time, weekdays, and sections. Quiet mode suppresses scheduled alerts and
briefings without replaying them later. Runs missed while Chat was stopped are
not replayed. Voice announcements use offline TTS when installed and the
announce-only phone lane, so host conversation audio is not broadcast.

This release intentionally supports one Google account only. It does not edit
or delete existing events, manage or answer invitations, expose attendee data,
join meetings, send mobile push notifications while Chat is stopped, or
replace reminders and alarms.

### Room-aware music (optional)

The **Media** page brings Spotify, YouTube, and music stored on this computer
into one player. Search without starting playback, choose a provider or let Chat
choose automatically, then play by voice or from the dashboard. The same page
has playback and volume controls, a queue, favorites, assistant playlists, and
named rooms.

For Spotify, create a Spotify developer **Web API** application, copy the exact
redirect URI shown on **Providers**, then connect the account there. Playback
control requires Spotify Premium and an active Spotify Connect device. For
local music, add an absolute folder on the Media page; Chat indexes supported
audio files under that folder. The folder path is encrypted and never returned
through dashboard APIs, search results, logs, or tool results.

A room is an explicit mapping from a friendly name to one currently available
Spotify, YouTube, or local-player target. Chat never guesses a speaker or sends
music to an unmapped target. Room-aware playback transfers one fenced session
between destinations; it does not claim synchronized multi-room audio. On a
restart or browser takeover, stale owners are retired or revalidated before
Chat reports that music is playing.

### Routines and starter scenes

The **Routines** page combines existing, allowlisted Chat capabilities into a
named, ordered sequence. Create a routine, add and reorder typed steps, choose
whether a failed step stops the run or lets later steps continue, validate it,
then enable it. You can run an enabled routine from its dashboard card, the
local command box, typed chat, cloud voice, or offline voice. Say the exact name
or alias, or use an explicit command such as **"run movie time"** or **"start
good morning"**. Built-in safety commands always win: a routine cannot take over
bare "stop", "mute", alarm/timer commands, device power commands, or similar
reserved phrases.

Three starter scenes are blueprints, not automatic actions:

* **Good morning** asks you to select readable calendars on the Calendar page
  and fill in your own music and room.
* **Movie time** asks for your actual Govee light and an app already installed
  on your LG TV.
* **Good night** asks for your light and a specific wake-up time.

Templates stay disabled and cannot run until every required field is filled.
Chat never guesses device names, rooms, apps, calendars, or alarm times.

The action picker is intentionally closed: calendar reads, the configured
briefing, music, Govee lights, LG TV controls, quiet mode, reminders, alarms,
bounded waits, and short announcements. A routine cannot run shell commands,
scripts, arbitrary URLs, loops, generated code, webhooks, or provider-specific
payloads. The same provider setup, confirmation boundaries, installed-app
checks, and device allowlists used by direct commands also apply inside a
routine.

An optional time-and-weekday trigger uses the timezone shown in the editor.
Triggers survive restarts, run at most once per occurrence, and do not replay
missed household actions when Chat starts after their scheduled time. A
nonexistent daylight-saving wall time is skipped; an ambiguous repeated time
uses its first occurrence.

Every run records each step as success, failure, skipped, or cancelled with its
duration. **Completed** means every executed step succeeded. **Partial** means a
step failed but its continue-on-error setting allowed later work to continue.
**Failed** means execution stopped at a failed or timed-out step. Successful
physical actions are not rolled back. The same routine cannot overlap itself,
and editing, disabling, or deleting it fences any old in-progress definition
before another step can begin. Run history deliberately excludes step arguments
and provider responses. Enable **Speak summary** only when you want a concise
completion/failure announcement; quiet mode still controls whether optional
speech is heard, while alarms retain their configured ringing behavior.

### Controlling your LG TV (optional)

Chat can act as a voice and dashboard remote for an LG webOS TV (like the
UA8000 series). It talks to the TV directly over your own Wi-Fi — no LG
account, no cloud service — and the whole feature stays off until you
enable it.

Set it up once on **Devices → LG TV**: switch it on, press **Discover**
(or type the TV's IP address), then **Pair** and accept the permission
prompt that appears on the TV screen. The TV must be on the same network
with **Settings → Network → LG Connect Apps** switched on (older models
call it "Mobile TV On" or "External device connection").

Then say things like: "pause the tv", "tv volume up", "set the tv volume
to fifty", "mute the tv", "open netflix on the tv", "switch the tv to
hdmi 2", "press home on the tv", "what apps are on the tv", "is the tv
on", "turn off the tv". The Devices page has the same controls as buttons:
a remote pad, volume and playback, an input picker, and an app search box.
Only apps *already installed on the TV* can be found and launched — if
something isn't installed, Chat says so instead of guessing, and it never
touches the LG Content Store.

Turning the TV **on** is the one best-effort command. It uses Wake-on-LAN:
save the TV's MAC address once on the Devices page and enable network
standby on the TV (**QuickStart+** on recent LG models). Whether the TV
actually listens while asleep depends on its standby settings and your
network — Chat reports that the wake signal was sent, not that the TV lit
up.

Privacy works like everything else here: the pairing key the TV issues is
encrypted at rest exactly like API keys, the MAC address is write-only
(saved, used for wake packets, never displayed again in the UI or any
API), and Chat can only send a fixed allowlist of TV commands — arbitrary
webOS commands are impossible.

### Quiet mode

"Quiet mode on" (or the sidebar button) stops all unprompted talking:
status notices, missed-timer announcements, and so on. Chat still answers
things you actually ask, and timers, reminders and alarms **still ring** —
deliberately, so a wake-up alarm can't be lost to quiet mode. If you want
those silent too, flip "In quiet mode, timers and alarms" in Settings.
Quiet mode is only ever switched by you — Chat never turns it on by itself.
It's different from the mic mute: mute stops Chat *hearing*, quiet stops it
*speaking up*.

### Listening on your phone

Open the dashboard from your phone (see LAN access below), then on
**Status → Listen on this device** tap **Start listening** — Chat's voice
now plays out of the phone. "Where the voice plays" controls the computer
side:

* **Computer speaker** — normal.
* **Phone only** — the computer stays silent. Perfect when the laptop's
  speaker is a Bluetooth box you don't want to use, or for headphones.
* **Both** — everywhere at once.

## Running modes

| Command                          | What runs                                  |
|----------------------------------|--------------------------------------------|
| `run_chat.bat`                   | Everything (voice auto-off if not installed)|
| `run_chat.bat --no-voice`        | Cloud + dashboard, microphone off           |
| `run_chat.bat --dashboard-only`  | Dashboard + timers only, no cloud at all    |
| `run_chat.bat --verbose`         | Same, with chatty console logging           |
| `deployment\windows\run_hidden.vbs` | Fully invisible (no window)              |

## Choosing who answers (brains)

Chat can use three different brains for voice conversations. Pick one in
**Settings → Brain**. Google is the default and stays the default unless
you change it.

| Brain | How it feels | What it needs | What it costs |
|-------|--------------|---------------|---------------|
| **Google (Gemini live)** | Live conversation, you can talk over it | Free Gemini keys on the Credentials page | Free (daily quota per key) |
| **OpenAI live** | Live conversation, you can talk over it | Your own OpenAI API key on the Providers page | Paid, billed by OpenAI to your OpenAI account |
| **Relay on Replit** | Walkie-talkie: say your piece, it answers, then listens again | Your published relay app's address (Settings) + the relay password (Providers page) | Replit credits, billed to your Replit account |

Notes in plain terms:

* **OpenAI live** talks straight from your laptop to OpenAI using your key.
  The key lives in the encrypted vault and is only ever sent to OpenAI.
  You need a paid OpenAI account with credit on it.
* **The relay** is a tiny server you publish on your own Replit account.
  Chat records what you said, sends it to the relay, and the relay uses
  Replit's AI service to write it down, think, and speak the answer back.
  Timers, lights, reminders and memory all still work. It is slower than
  the live brains — that is the trade for it running on Replit credits.
  The **daily call limit** in Settings is the spending guard: once Chat has
  made that many relay calls in a day, relay conversations stop until
  tomorrow.
* The relay discovers the models your authenticated relay actually offers and
  uses their capabilities for each turn: quick commands stay economical,
  normal questions use a balanced model, and genuinely difficult questions
  use the best compatible reasoning model. Settings remain preferences, while
  the relay's allowlist and daily call limit remain authoritative.
* If the brain you picked cannot start (no key saved, wrong password, no
  internet to that service), Chat says why in the Logs page and answers
  that conversation with Google instead, so the house never goes silent.

## The dashboard

* **Status** — live state (SLEEPING / LISTENING / SPEAKING / LOCAL_ONLY),
  component health, usable-key count, next quota retry, quiet mode, the
  weather card, the phone address, and the local command box.
* **Credentials** — add/disable/delete Gemini keys, grouped by project, with
  masked suffixes only. "Make active" switches keys for the *next* session —
  a live conversation is never interrupted.
* **Providers** — Govee API key, the optional OpenAI key, the optional
  relay password, Spotify and Google Calendar connections, calendar selection,
  and the rotation policy explained.
* **Usage** — session starts/ends and tool calls (sanitized, never content).
* **Devices** — your Govee lights with quick on/off, plus LG TV setup and
  control: pair/unpair, connection health, a remote pad, volume, inputs,
  and installed-app search and launch. Discovered light names and capabilities
  persist locally; explicit aliases and rooms can be saved by asking Chat.
  Say **"refresh"** to rescan the lights and safely reprobe the TV.
* **Timers** — create, pause, resume, cancel. Timers survive restarts;
  anything that expired while the machine was off is announced as missed.
* **Reminders** — clock-time reminders and loud alarms with a time picker,
  plus recent fired/missed history. A ringing alarm shows a red banner with
  a Dismiss button on every page.
* **Calendar** — upcoming events, reviewed appointment creation, meeting
  alerts, and morning briefing settings.
* **Media** — unified Spotify, YouTube, and local-library search and playback,
  queues, favorites, assistant playlists, and explicit room-to-target mappings.
* **Routines** — validated allowlisted sequences, starter-scene blueprints,
  optional schedules, and sanitized run history.
* **Memory** — every fact Chat has been asked to remember, with add and
  forget buttons.
* **Logs** — the detailed event log (the console stays quiet on purpose).
* **Settings** — everything is editable here: the brain picker, wake word
  picker, microphone and speaker choice, sound routing, alarm ring length
  and loudness, your town for weather, key rotation and quota tuning,
  health-check intervals, updates, phone access, password. Voice settings
  apply live without a restart.

Every page also has the red **Stop talking** button and the mute switch.
The pages are light-colored by default; the **Dark mode** button at the
bottom of the menu switches, and every device remembers its own choice —
your phone can stay dark while the laptop stays light.

### Reaching the dashboard from your phone

Phone access is on by default for new installs: the console window prints a
"Phone on Wi-Fi" address (also shown on the Status page and in Settings) —
open it on any device on your Wi-Fi and sign in with your dashboard
password. (The very first password creation only works on the laptop
itself — other devices are refused until the password exists.) The pages
are phone-friendly, with a slide-out menu and big Stop / Dismiss buttons. To restrict the dashboard to this computer only,
set **Settings → Dashboard access → Phone access** to Off and restart.
Upgraded installs keep their old setting — flip it to On the same way.
For HTTPS, run `python deployment\windows\make_cert.py` once and restart.
Open **Phone HTTPS setup** on the Chat laptop, download the public
certificate there, compare its fingerprint, and transfer it to the phone
using USB, AirDrop, or another trusted local method. Never install a
certificate downloaded across an untrusted Wi-Fi connection, and never
transfer `ca-key.pem` or `key.pem`.

## What's new in 1.9.32

* **YouTube searches use the keyboard shown on the TV** — YouTube's custom
  A–Z grid does not report the native webOS text focus that Chat previously
  waited for. Chat now follows the photographed Home → Search → A path, selects
  letters and spaces with bounded D-pad presses, then activates the on-screen
  Search button. Because webOS cannot read that custom screen back, Chat
  truthfully labels the sequence as sent rather than screen-verified.
* **Manual YouTube typing is explicitly confirmed** — if Search is already
  open, highlight A first. Voice tools require an explicit one-shot confirmation,
  and the Devices page shows an “A highlighted” checkbox that clears after use.
  Chat never infers keyboard readiness merely because YouTube is open.

## What's new in 1.9.31

* **Search YouTube or Netflix on the TV by voice** — requests such as
  “search Netflix for Stranger Things on the TV” now launch the chosen app,
  confirm it is actually in front, follow a short bounded path to Search, wait
  for the TV's full-screen keyboard to report focus, then type and submit.
  If an app update changes that path, Chat stops without sending the query and
  reports the layout problem instead of pretending it worked.
* **TV typing confirms a real keyboard first** — manual Type and Type + Enter
  no longer report success when YouTube, Netflix, or another app has no active
  text widget. Keyboard focus is cleared across app changes and disconnects,
  and Enter is withheld if focus changes after the text was inserted.
* **Explicit AI Expert replies stay full and unchanged** — when you say
  “Ask ChatGPT” or “Ask Claude,” Chat returns that expert's reply verbatim by
  default. It only summarizes, shortens, compares, or transforms the expert
  reply when you explicitly ask it to.
* **Phone access failures are easier to diagnose** — startup, Settings, and
  Phone HTTPS Setup now clearly show whether phone access is on, which exact
  Wi-Fi address to use, and whether to check same-network/firewall settings or
  the HTTPS certificate. Existing laptop-only settings and security boundaries
  are never changed automatically.

## What's new in 1.9.30

* **AI Expert model names stay visible** — ChatGPT and Claude model rows now
  keep compact checkboxes and reserve space for labels and reasoning badges,
  instead of allowing the global form styles to squeeze model names away.
* **Wake sensitivity feedback stays truthful** — changing the wake threshold
  starts a fresh score window, so an old peak is never compared against the new
  requirement. Above-threshold scores can no longer produce a contradictory
  “has not matched” warning.

## What's new in 1.9.29

* **Google Calendar controls stay readable** — connected calendar names,
  checkboxes, primary badges, and the save button now keep their intended
  widths instead of collapsing into narrow vertical text on the Providers page.

## What's new in 1.9.28

* **AI Experts opens correctly** — the Providers dashboard now reads the live
  ChatGPT and Claude catalog using the same response shape as its authenticated
  API. Loading, saving, and rerendering the model controls no longer fails with
  `Cannot read properties of undefined (reading 'chatgpt')`.

## What's new in 1.9.27

* **Ask ChatGPT or Claude from Jarvis** — say or type **"ask ChatGPT..."** or
  **"ask Claude..."** for an explicit consultation. Jarvis can also choose one
  expert for genuinely complex questions, with query-sensitive routing to
  high-end reasoning, Codex, Opus, or Sonnet models.
* **Thirty current expert models** — Relay now offers 20 OpenAI and 10 Claude
  text models, including GPT-5.6 Sol and Claude Opus 5. Maximum reasoning maps
  to each provider's strongest supported setting.
* **Live expert controls** — **Providers → AI Experts** can enable either
  provider, choose allowed and preferred models, set reasoning strength, and
  turn automatic use on or off. Saved changes apply without restarting Chat.
* **Private, bounded consultations** — expert tools reject supplied credentials
  and private device identifiers before any network call, obey the Relay daily
  request cap, make at most two paid attempts, and never receive ambient audio
  or full transcripts. Remote Voice Controller feedback remains generation
  fenced and stops on completion or its existing safety deadline.

## What's new in 1.9.26

* **Voice feedback cannot beep forever** — the remote Voice Controller now
  clears its working sound and message as soon as reply audio, completion,
  interruption, disconnect, or another terminal state arrives. If a provider
  loses every completion signal, the repeated sound stops after 3.5 seconds,
  changes to a quiet delay notice, and the stale notice clears after 15 seconds.
* **A roomier Calendar dashboard** — the appointment and assistant-preference
  panels now use the open desktop space instead of staying squeezed into narrow
  grid columns. They stack at smaller desktop, tablet, and phone widths so date,
  duration, briefing, and timezone controls remain easy to read and use.

## What's new in 1.9.25

* **Lights no longer depend on exact spelling** — discovered Govee lights are
  stored in a durable local catalog with safe name normalization, capabilities,
  rooms, and explicit aliases. Every typed and voice provider receives only the
  public names and supported actions; private provider IDs and credentials stay
  out of prompts and tool results. Ambiguous names are refused rather than
  controlling the wrong light.
* **One real device refresh command** — say or type **"refresh"** to force one
  serialized Govee rediscovery and safely reprobe the LG TV at the same time.
  Light and TV outcomes are reported separately, stale refreshes never claim
  success, and a sleeping or powered-off TV remains a normal offline state.
* **Memories are available on ordinary turns** — a shared bounded context
  builder selects relevant memories for typed chat and recent memories for
  voice sessions across Gemini, OpenAI, and Relay. Lookup failures fail open,
  context values are marked untrusted, and telemetry records only counts and
  sizes rather than memory contents.

## What's new in 1.9.24

* **Google Calendar and dependable morning briefings** — connect one encrypted
  Google account, ask about upcoming meetings, review and confirm new
  appointments, receive approaching-meeting alerts, and schedule a bounded
  calendar/weather/news briefing. Quiet mode suppresses scheduled speech, and
  alerts or briefings missed while Chat was stopped are never replayed later.
* **One room-aware player for Spotify, YouTube, and local music** — search,
  play, control volume, manage the queue, save favorites, and build assistant
  playlists across all three providers. Friendly room names map only to
  explicit available targets; ownership and provider operations are fenced so
  stale browsers or restarts cannot silently seize or falsely report playback.
* **Safe routines and starter scenes** — combine existing allowlisted calendar,
  briefing, music, light, TV, quiet-mode, reminder, alarm, wait, and
  announcement actions into validated sequences. Templates remain disabled
  until configured, scheduled runs do not replay missed household actions, and
  routines cannot execute arbitrary code, URLs, scripts, or provider payloads.

## What's new in 1.9.23

* **Lights understand real colors safely** — standard names such as brown now
  resolve to canonical RGB values. For a custom shade, Jarvis supplies a strict
  `#RRGGBB` value; every name or hex value is then locally validated and packed
  into the integer Govee requires before a device command is sent.
* **Hard questions get the best available relay model** — Jarvis discovers
  authenticated model capabilities, keeps short household commands economical,
  uses a balanced model for normal questions, and automatically chooses the
  highest-ranked compatible reasoning model for complex requests. Spend caps,
  server allowlists, tool compatibility, and bounded fallbacks still win.
* **Voice feels immediate on the device you chose** — each accepted utterance
  gets one short heard-you cue and a quiet working pulse that stops on the first
  reply audio, interruption, error, takeover, or session end. “Talk on this
  device” atomically revokes every older voice binding.
* **Faster, safer interruption** — speaking over Jarvis clears stale playback
  and cancels the provider quickly while echo candidates remain local and are
  never forwarded as user speech.
* **Live timing diagnostics without private content** — Logs and the voice
  controller show a bounded sequence of ownership, model, provider, tool,
  playback, interruption, cancellation, and error timing metadata. Audio,
  transcripts, keys, and unbounded per-frame events are never recorded there.

## What's new in 1.9.17

* **Companion 1.0.9 pairing is race-safe** — reconnects, re-pairing, and
  overlapping status checks can no longer let an older socket repaint a newer
  authenticated connection as “awaiting auth_ok” or disconnected.
* **Pause and resume the real YouTube tab** — typed or spoken pause/play
  commands now control the authenticated companion tab even before Jarvis has
  learned its video ID, instead of asking for an embedded Media player.
* **Wake listening recovers around music** — muted or disconnected companion
  playback cannot leave the microphone gate stuck closed. Jarvis can pause or
  duck controlled YouTube playback for a voice session and restore it only
  when Jarvis initiated that change.
* **LG YouTube search typing** — TV text entry now performs WebOS's required
  remote-keyboard registration before inserting text, while retaining the
  strict local-only IME allowlist.

## What's new in 1.9.16

(Supersedes 1.9.15, which was withdrawn minutes after publishing: its
dashboard TV text composer sent a field name the server didn't read, and two
error paths could misreport failures.)

* **A real on-screen TV remote** — the Devices page now shows a tactile
  remote: D-pad with OK, Back/Home/Menu/Exit, playback and volume keys, input
  switching, and one power key that adapts to the TV's state — press it to
  power off when the TV is on, or to send a best-effort Wake-on-LAN nudge
  when it looks off. The remote stays on screen while a paired TV is offline
  (so you can wake it); everything else re-enables when the TV answers.
* **Type on the TV** — a new composer on the remote (and a matching voice
  command, e.g. "type stranger things on the TV") sends text straight into
  whatever search or login box is focused on the TV, with an optional Enter.
  Text is capped at 120 characters and is never logged or saved. TVs paired
  before this release need **Remove pairing → Pair with TV** once so the TV
  can grant the keyboard permission.
* **Companion 1.0.8: honest YouTube failure reasons** — the browser extension
  now acknowledges every command exactly once, so "companion did not confirm"
  generic errors are replaced by the real cause: no YouTube tab open, the
  page still loading, an ad still playing, or the video player missing. A
  command that times out is reported as *uncertain* and is never re-sent
  automatically, so you'll never get a double skip or surprise second video.
  Settings → Companion now shows when the connection was last actually used
  and the last failure, not just "connected".

## What's new in 1.9.14

* **No more self-interrupted Gemini replies** — while Chat is speaking, local
  and browser microphone audio is used only to detect intentional barge-in and
  is never forwarded to the provider as a fake user turn. After a real
  interruption, listening resumes immediately, while delayed model audio is
  discarded until Gemini confirms the old turn ended.
* **LG TV power-on state fix** — a WebOS socket that remains connected briefly
  after power-off is no longer treated as proof that the panel is still on.
  Voice or typed power-on requests now send Wake-on-LAN unless live state
  positively reports the TV as on or active.

## What's new in 1.9.13

* **Companion pairing-status fix** — Companion 1.0.7 no longer lets the
  asynchronous secret-storage step overwrite the final authenticated state
  when `paired` and `auth_ok` arrive back-to-back. A successful pairing now
  settles on **ready** instead of displaying the stale “awaiting auth_ok”
  message.

## What's new in 1.9.12

* **Optional LG webOS TV control** — pair an LG TV on the local network and
  control power, Wake-on-LAN, volume, mute, playback, navigation, inputs, text
  entry, and installed apps from the dashboard, typed chat, or natural voice
  requests. Pairing keys stay encrypted, MAC addresses are write-only, and only
  fixed allowlisted TV commands can be sent.
* **Natural TV wording** — equivalent requests such as “turn off the TV,”
  “power down the TV,” “shut the TV off,” and “take off the TV” resolve to the
  same safe action instead of requiring one exact phrase.
* **Companion included** — the public update channel continues to include the
  verified Chat YouTube Companion `1.0.6` package.

## What's new in 1.9.11

* **Companion UI routing hardening** — Companion 1.0.6 routes its four private
  options/popup message types directly, instead of relying on Chrome’s optional
  `MessageSender` metadata. This removes the sender-tab classification path
  entirely, so **Pair now** receives a response regardless of how the options
  page was opened.

## What's new in 1.9.10

* **Companion options-page routing fix** — Chrome includes `sender.tab` when
  the extension options page is open as a normal browser tab. The worker used
  that field to distinguish extension UI from YouTube, so it silently routed
  **Pair now** down the content-script path and returned no response. Companion
  1.0.5 now verifies the sender's extension URL instead, with regression tests
  for both tabbed options pages and YouTube content scripts.

## What's new in 1.9.9

* **Companion pairing fix** — **Pair now** now gets an immediate response from
  the extension service worker before the WebSocket handshake begins. Chrome
  could otherwise close the one-shot message channel during pairing and report
  “The message port closed before a response was received” even though the
  bridge was available. Update to **Chat YouTube Companion 1.0.4**.

## What's new in 1.9.8

* **Companion connection test fix** — the tokenless connection test now runs
  directly in the extension options page instead of keeping a one-shot
  Chrome service-worker message open while it waits for the WebSocket. Chrome
  can close that message port even when Chat is available, producing the
  misleading “message port closed before a response was received” error.
  Update to **Chat YouTube Companion 1.0.3** and use **Test connection** again.

## What's new in 1.9.7

* **Companion connection fix** — the companion extension now asks Chrome only
  for permission to reach Chat on `127.0.0.1` / `localhost`, which Chrome needs
  before its background worker may reach the local bridge. Its connection test
  also reports the real browser or service-worker error instead of "unknown".
  Install **Chat YouTube Companion 1.0.2** after updating Chat, then use the
  plain `ws://` bridge address shown in Settings.

## What's new in 1.9.6

* **The companion extension can actually pair now** — Chat serves the
  companion bridge on its own loopback port that is always plain `ws://`, even
  when the dashboard runs on HTTPS. A browser extension cannot approve Chat's
  self-signed local certificate, so the old `wss://` address failed with an
  unexplained error and pairing never completed. The new port is bound
  strictly to `127.0.0.1`, still authenticates every frame with the bridge
  secret, and carries only media commands. Chat prints the address at startup
  and shows it in **Settings → YouTube companion extension**. Pin it with
  `companion_bridge_port` if you prefer a fixed port.
* **Chat stops going deaf when you mute the music** — muting, setting volume
  to zero, or pausing now counts as silence, so the microphone gate reopens at
  once instead of behaving as if music were still playing. This also works
  when you press mute in YouTube itself with the companion connected.
* **The microphone can no longer be ratcheted shut** — the noise floor learned
  during playback now falls back to normal within about a second of the room
  going quiet, and rises slowly, so half-heard words can no longer push the
  speech threshold further out of reach the longer you talk. Loud music is
  still filtered out and protection against Chat hearing its own reply is
  unchanged, so speaking up over a loud track is still expected.
* 1.9.5 was published briefly and replaced the same day by 1.9.6, which keeps
  the fixes above but restores full filtering of loud music.

  One limit is worth knowing, because it cannot be fixed by tuning: the filter
  measures loudness, so music that gets much louder than it was a moment ago
  can be heard as if somebody were talking, until the track quietens again.
  Every rule that would block a loud steady track also blocks a person
  speaking steadily, and being unable to talk to Chat is the worse of the two
  failures. Your speakerphone's own echo cancellation, headphones, or a lower
  media volume all avoid it.

## What's new in 1.9.4

* **Full YouTube companion mode** — the optional Chrome/Edge extension keeps
  the normal `youtube.com` page, recommendations, comments, subscriptions,
  playlists, and account features. Jarvis stays in its Voice Controller while
  the dedicated YouTube tab is reused in the background.
* **Live voice media controls** — Jarvis can play, pause, stop, seek, restart,
  move next/previous, set or adjust player volume, and mute/unmute. Manual
  changes in YouTube are reflected back to Chat.
* **Listen while music plays** — the local and browser microphone paths keep
  wake listening active. Confirmed nearby speech ducks the player, a verified
  wake/conversation turn pauses it, and Chat restores only audio changes that
  it owns. The playback-aware gate helps reject speaker lyrics; effective
  hardware echo cancellation or headphones remain the strongest protection.
* **Local and narrowly permissioned** — pairing uses a one-time token and a
  loopback-only authenticated WebSocket. The extension runs only on
  `youtube.com`, opens only server-validated canonical video/playlist IDs, and
  refuses every media command while YouTube reports an ad.

### Install the YouTube companion

1. Extract
   `deployment\chrome_extension\chat-youtube-companion-1.0.2.zip` to a
   permanent folder on the Chat computer. Version 1.0.2 is required for
   the local companion bridge permission and clear connection diagnostics.
2. Open `chrome://extensions` or `edge://extensions`, enable Developer mode,
   choose **Load unpacked**, and select that extracted folder.
3. Start Chat and open **Settings → YouTube companion extension → Generate
   pairing token**.
4. Open the extension's **Pairing & settings**, enter the bridge address shown
   by Chat, paste the one-time token, and choose **Pair now**.

The browser requires manual installation for security; Chat never installs an
extension or reads a browser profile without permission.

### 1.9.3 fixes

* **Speaker-feedback protection** — the Voice Controller now uses the
  browser's echo cancellation in one audio graph, never routes the raw
  microphone to the speakers, and tells the server exactly while Chat's own
  reply is playing. A playback-aware gate filters speaker leakage and room
  echo while still allowing a clearly louder interruption.
* **Automatic YouTube playback** — a normal play request searches for a
  canonical result and starts it without saying it was queued. The official
  dashboard embed is used first. If no player is open, embedding is blocked,
  or autoplay is blocked, Chat opens only the validated official YouTube URL
  in the computer's default browser.
* **Playlists and continuous play** — official YouTube playlist links and
  playlist searches are supported. Embedded search-result queues advance and
  loop until a media-qualified command such as “stop the music” is given.
  Bare “Stop Jarvis” still interrupts Chat's current reply only.
* **Live, honest media status** — the dashboard shows whether playback is
  embedded or in the computer browser. Controls that cannot operate a
  separate browser tab are disabled instead of pretending they worked.

### 1.9.2 fixes

* **Browser wake word fixed** — the Voice Controller converts the browser's
  real microphone rate to exact 16 kHz audio, stays in “Say Hey Jarvis”
  mode, and opens a conversation only after the wake word. Goodbye, mute,
  and timeout return to wake-listening without closing the page.
* **Fast transcripts** — long sessions open with the newest 200 lines and
  load older lines on demand instead of freezing the page.
* **Private Wi-Fi connection help** — Chat prints every usable current
  RFC1918 address. `deployment\windows\allow_lan_access.bat` can add an
  explicit Windows Firewall rule limited to Chat's TCP port, the Private
  profile, and `LocalSubnet`; it never runs automatically.

### 1.9.1 fixes

* **Clearer audio help** — microphone and speaker startup failures now name
  the device side and retain Windows/PortAudio's actual reason. Expected
  browser or phone disconnect resets no longer fill the Windows console.

### 1.9.0 features

* **Continuous Jarvis voice mode** — say “Hey Jarvis” once and keep talking.
  The rolling quiet timeout is 30 minutes. “Stop Jarvis” only interrupts
  the current reply; “Goodbye Jarvis” ends the conversation and requires a
  new wake word.
* **Voice Controller** — a separate phone/browser microphone window keeps
  voice active while you move between Chat, Media, Logs, Settings, Usage,
  and Transcripts.
* **Typed Chat and transcripts** — durable text conversations, safe image
  questions through OpenAI, and a visual history of voice conversations.
* **YouTube Media** — deterministic normal/official-result selection,
  selected-device playback controls, blocked-embed fallback to the official
  YouTube page, and no downloading or copyright bypass.
* **Web and news tools** — bounded current-time, web search, and headline
  tools that treat search text as untrusted reference material.
* **Reliable alarms** — ringing survives restarts, keeps ringing until
  dismissed, and supports 10-minute snooze.
* **Windows reliability** — valid time zones work on Windows, duplicate
  launches exit cleanly, optional Start with Windows runs hidden, and
  harmless wake-engine warnings are removed.
* **Clearer dashboard** — every provider pipeline stays visible, everyday
  settings appear first, and technical model tuning lives under Advanced
  settings.

## Automatic updates

Chat updates itself. New versions are published at

    https://raw.githubusercontent.com/Nick-PY0/chat-assistant-updates/main/latest.json

and fresh installs have that link set as the default — nothing to do. Chat
checks it quietly every 6 hours, downloads a new version in the background,
checks the publisher's tamper-proof signature on it, and swaps it in on the
next start — or right away via **Settings → Restart Chat**. An update that
is unsigned or altered in any way is refused. On an older install, open
**Settings → Updates → Update link**: if the box is empty, paste the link
above once. To opt out, turn **Automatic updates** off in Settings.

### Publishing to your own link instead

Prefer a link you control? Host a small `latest.json` anywhere public (a
GitHub release works great):

       {
         "version": "1.2.0",
         "zip_url": "https://github.com/you/chat/releases/download/v1.2.0/chat-assistant.zip",
         "notes": "what changed"
       }

Paste that link into **Settings → Updates → Update link**. To publish a
new version: bump `APP_VERSION` in `chat_core/version.py`, zip the whole
`chat-assistant` folder, upload it, and update `latest.json`.

Chat refuses unsigned updates by default. For your own channel, create
your own keys once with `python deployment/release/sign_manifest.py keygen`
(put the printed public key into `apps/updater/updater.py`), then sign
every release with
`python deployment/release/sign_manifest.py sign latest.json your.zip`
before uploading — that fills in the `sha256` and `sig` fields. If you
would rather skip signing on a private link you trust, turn **Require
signed updates** off in Settings.

Downloads are size-capped, checked to be a real Chat build, and staged in
the data folder first — a bad or half-finished download can never break the
running install.

GitHub walkthrough: create a repository → **Releases** → *Draft a new
release* → attach the zip **and** `latest.json` → publish. Then
`https://github.com/<you>/<repo>/releases/latest/download/latest.json`
always points at your newest release, so it never needs changing.

## Building Chat.exe (runs without Python)

On any Windows machine with the project and `.venv` set up:

    deployment\windows\build_exe.bat

This produces `dist\Chat\` with **Chat.exe** inside. The folder is fully
self-contained — copy it to any Windows computer and double-click the exe;
Python does not need to be installed there. Whatever is in `.venv` at build
time gets baked in, so install the voice packages first if you want voice.
A vosk model can also be dropped next to the exe later
(`Chat\assets\vosk-model`).

Notes:

* The exe must be built **on Windows** — PyInstaller cannot cross-build, so
  run the build on the laptop itself.
* Auto-update works for exe installs too: zip the new `dist\Chat` folder and
  point `zip_url` at that zip.

## Security model (short version)

* API keys are encrypted (AES-256-GCM) with a master secret held in the
  Windows Credential Locker (or a protected file if `keyring` is missing).
* The dashboard password is hashed with Argon2id; sessions are signed
  HttpOnly cookies; every write needs a CSRF token; login is rate-limited.
* First-time setup (creating that password) is only accepted from the
  computer running Chat itself, so nothing on your network can claim the
  dashboard before you do.
* Plaintext keys never appear in the UI, API responses, logs, or the console
  — only masked suffixes like `••••1234`.
* The assistant can only run allowlisted tools (timers, lights, TV). It
  cannot touch your files, run commands, or change its own configuration.
  TV control follows the same rule: a fixed command set only — the pairing
  key is encrypted at rest and the TV's MAC address is never shown again
  once saved.

## Data location

Everything Chat stores lives in `%LOCALAPPDATA%\ChatAssistant`
(config.json, chat.db, optional cert files). Set the `CHAT_DATA_DIR`
environment variable to move it. Delete that folder to factory-reset.

## Running the tests

    pip install pytest pytest-asyncio
    python -m pytest

## Project layout

    run_chat.py            single-process launcher (all services as tasks)
    run_chat.bat           Windows launcher (small black console window)
    chat_core/             config, event bus, state machine, DB, security
    apps/audio/            wake word, mic/speaker streams, announcements
    apps/live_gateway/     Gemini Live sessions + automatic key rotation
    apps/tool_service/     timers, reminders, weather, Govee + TV tools, local grammar
    apps/pulse/            isolated health checks & quota-retry scheduling
    apps/dashboard/        FastAPI control panel (this is the web UI)
    apps/updater/          background self-update (manifest -> stage -> swap)
    integrations/          Gemini, Govee and LG webOS (TV) clients
    deployment/windows/    installer, exe build, TTS + cert helpers
    migrations/            SQLite schema
    tests/                 pytest suite

## Troubleshooting

* **"voice pipeline disabled: audio packages not installed"** — run
  `pip install -r requirements-voice.txt` inside `.venv`, or ignore it if
  you only want the dashboard.
* **Wake word never triggers** — lower the sensitivity in Settings
  (e.g. 0.45), check Windows microphone permissions for Python.
* **"wake word unavailable" in the console or Logs** — the wake word model
  files were missing (they are a separate one-time download, which
  install.bat used to skip). Chat now downloads them by itself on the next
  start with internet; the message spells out anything else that is wrong.
* **"local mode" announcements** — every key is blocked or invalid. Check
  the Credentials page; Chat retries automatically at the earliest reset.
* **Dashboard unreachable from another device** — follow these steps in order:
  1. Test `https://127.0.0.1:8756` on the Chat computer itself. If that fails, Chat is not running.
  2. Use the exact address printed in the Chat console window (e.g. `https://172.16.151.131:8756`).
     Do NOT guess or use a stale address — copy it from the current console output.
  3. If localhost works but the phone times out, run `deployment\windows\allow_lan_access.bat`
     (double-click it; it requests Administrator only when needed). This creates a Windows Defender
     rule: TCP, Private profile, same subnet only.
  4. The phone must be on the same normal Wi-Fi as the Chat computer.
     Guest networks, client-isolation VLANs, VPNs, and mobile data all block direct LAN access.
  5. A certificate error (not a timeout) means the connection reached Chat successfully — install
     the local CA certificate (see Mobile HTTPS Setup in the dashboard menu).
  6. If the LAN IP changes (e.g. you reconnected to a different network), rerun
     `python deployment\windows\make_cert.py` and restart Chat.
* **An alarm didn't ring in quiet mode** — Settings → "In quiet mode,
  timers and alarms" must be "Still ring out loud" (the default).
* **Weather says "no home location set"** — pick your town in Settings →
  Weather & location, then press Save.
* **Phone listening is silent** — tap *Start listening* again after the
  phone screen was locked (browsers pause audio in the background), and
  check the routing isn't set to "Computer speaker" while you expected
  "Both".
* **Offline commands answer "that's not something I can do offline"** —
  the sentence didn't match the safe grammar (timers, lights, TV, memory,
  stop). Check Logs to see what the recognizer heard.
* **TV commands say the TV isn't responding** — the TV may be fully off
  (see the power-on notes above) or its IP address may have changed: open
  **Devices → LG TV** and press Discover again. If the TV shows the
  pairing prompt once more, accept it and Chat re-pairs automatically.
* **An update downloaded but nothing changed** — updates apply on the next
  start: use Settings → Restart Chat or close and reopen the console
  window. The Updates card shows any error text.
