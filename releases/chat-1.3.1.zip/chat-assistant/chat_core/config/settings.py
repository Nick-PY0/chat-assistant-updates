"""Application settings.

Settings load from (in order of precedence):
  1. Environment variables (CHAT_*)
  2. config.json inside the data directory
  3. Built-in defaults

The data directory defaults to a per-user location so the project folder
stays clean, and can be overridden with CHAT_DATA_DIR.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path


def default_data_dir() -> Path:
    override = os.environ.get("CHAT_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "ChatAssistant"
    return Path.home() / ".chat-assistant"


@dataclass
class Settings:
    # Storage
    data_dir: str = ""

    # Dashboard
    # 0.0.0.0 = phones/laptops on your Wi-Fi can open the dashboard (it is
    # password-protected). Set 127.0.0.1 to restrict it to this computer.
    dashboard_host: str = "0.0.0.0"
    dashboard_port: int = 8756
    ssl_certfile: str = ""              # optional; see deployment/windows/make_cert.py
    ssl_keyfile: str = ""
    session_max_age_days: int = 7

    # Power profile: keep the process as quiet as possible
    low_power: bool = True
    log_level: str = "WARNING"          # console log level in low power mode

    # Voice
    voice_enabled: bool = True          # auto-disables if audio deps/hardware missing
    wake_word_model: str = "hey_jarvis" # openwakeword model name OR path to custom "chat" .onnx/.tflite
    wake_threshold: float = 0.55
    mic_device: str = ""                # empty = system default
    speaker_device: str = ""
    interrupt_rms_threshold: int = 900  # int16 RMS above this while SPEAKING = user interruption
    inactivity_timeout_seconds: int = 75
    # Where Chat's voice plays: "speaker" (this computer), "phone" (dashboard
    # listeners only, computer stays silent), or "both".
    audio_output_route: str = "speaker"
    # Offline speech recognition for local-only voice commands (optional).
    # Empty = auto-detect assets/vosk-model next to the app.
    vosk_model_path: str = ""

    # Reminders & alarms
    alarm_ring_seconds: int = 60        # how long an alarm rings before giving up
    alarm_volume: float = 1.0           # ring loudness 0.2-1.0
    quiet_override_alarms: bool = True  # timers/alarms still ring in quiet mode

    # Weather (Open-Meteo: free, no account). Location is set in Settings.
    location_name: str = ""
    location_lat: float = 0.0
    location_lon: float = 0.0
    weather_units: str = "celsius"      # or "fahrenheit"

    # Automatic updates: link to a manifest JSON (see apps/updater/updater.py).
    # The default points at this project's release page on GitHub, so fresh
    # installs keep themselves current out of the box. Clear the link (or
    # turn auto_update off) in Settings to opt out.
    update_url: str = (
        "https://raw.githubusercontent.com/Nick-PY0/chat-assistant-updates/main/latest.json"
    )
    # Refuse updates that are not signed by the publisher's key (the matching
    # public key ships inside apps/updater). Only turn this off if you host
    # your own unsigned update link and accept the risk.
    update_require_signature: bool = True
    auto_update: bool = True

    # Gemini
    gemini_model: str = "models/gemini-2.0-flash-live-001"
    gemini_voice: str = "Puck"
    system_prompt: str = (
        "You are Chat, a friendly, concise home voice assistant. "
        "Use the provided tools for timers and lights. Keep spoken replies short."
    )

    # Rotation policy (user's variant: rotate across ALL keys, no paid fallback)
    rotation_enabled: bool = True
    rate_limit_rotate_after_failures: int = 2   # short-window 429s on same key before rotating
    unavailable_retry_seconds: int = 20         # brief backoff before trying next key
    quota_reset_timezone: str = "America/Los_Angeles"
    quota_reset_jitter_seconds: int = 300       # wait a bit past midnight before retrying
    retry_window_backoff_seconds: int = 1800    # if a retry-at-window fails, wait this long

    # Pulse intervals (seconds); low_power doubles these automatically
    pulse_internet_interval: int = 30
    pulse_govee_interval: int = 60
    pulse_credential_interval: int = 300
    pulse_timer_interval: int = 15
    pulse_audio_idle_interval: int = 60

    # Security
    login_max_attempts: int = 5
    login_window_seconds: int = 900

    extra: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    @property
    def data_path(self) -> Path:
        return Path(self.data_dir)

    @property
    def db_path(self) -> Path:
        return self.data_path / "chat.db"

    def pulse_interval(self, base: int) -> int:
        return base * 2 if self.low_power else base

    def save(self) -> None:
        path = self.data_path / "config.json"
        payload = asdict(self)
        payload.pop("extra", None)
        path.write_text(json.dumps(payload, indent=2))


_ENV_PREFIX = "CHAT_"


def load_settings() -> Settings:
    s = Settings()
    s.data_dir = str(default_data_dir())
    cfg = Path(s.data_dir) / "config.json"
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text())
            for k, v in data.items():
                if hasattr(s, k) and k != "extra":
                    setattr(s, k, v)
        except (json.JSONDecodeError, OSError):
            pass  # corrupted config falls back to defaults; never crash startup
    # env overrides (CHAT_DASHBOARD_PORT=9000 etc.)
    for f in s.__dataclass_fields__:
        env = os.environ.get(_ENV_PREFIX + f.upper())
        if env is None:
            continue
        cur = getattr(s, f)
        try:
            if isinstance(cur, bool):
                setattr(s, f, env.strip().lower() in ("1", "true", "yes", "on"))
            elif isinstance(cur, int):
                setattr(s, f, int(env))
            elif isinstance(cur, float):
                setattr(s, f, float(env))
            elif isinstance(cur, str):
                setattr(s, f, env)
        except ValueError:
            continue
    Path(s.data_dir).mkdir(parents=True, exist_ok=True)
    return s
