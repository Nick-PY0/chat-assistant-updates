# Chat — a private home voice assistant

Chat runs on your own Windows laptop. Say the wake word, talk to it like a
person (powered by Gemini Live), and it can set real timers, reminders and
wake-up alarms, tell you the weather, and control your Govee lights. When the
internet or your Gemini quota runs out, it keeps working locally: timers,
reminders, lights, and the dashboard never depend on the cloud.

Everything lives on your machine: keys are encrypted at rest, the dashboard
runs on localhost, and nothing is sent anywhere except Google (voice) and
Govee (lights).

## What makes this build different

**Automatic key rotation, no paid fallback.** Add as many free Gemini API
keys as you like — from different Google projects — and Chat rotates through
all of them automatically. When one project's daily quota runs out it blocks
that whole project until the documented reset time (midnight Pacific) and
moves to the next key instantly, mid-conversation reconnects included. More
keys = more daily capacity. Keys you label with the same project name are
treated as one shared quota (redundancy, not extra capacity).

**As light as possible.** One quiet Python process, below-normal CPU
priority, a nearly silent console window, no busy loops. Voice packages are
optional — without them Chat still runs the dashboard, timers, rotation, and
lights.

## Quick start (Windows)

1. Install Python 3.11+ from https://www.python.org/downloads/
   (tick **"Add python.exe to PATH"** during install).
2. Download this project folder to your laptop and open it.
3. Double-click `deployment\windows\install.bat`
   — it creates a private environment and installs the core packages.
   Say yes to the voice packages if you want the microphone side.
4. Double-click `run_chat.bat`. A small black console window opens and prints
   the control panel address.
5. Open http://127.0.0.1:8756 in your browser, create your password, and add
   your first Gemini key on the **Credentials** page
   (free keys: https://aistudio.google.com/apikey).

That's it. Say "Hey Jarvis" (the default wake word — see below) and talk.

### Getting more daily talk time

Create additional free API keys in *different* Google Cloud projects
(AI Studio → gear icon → switch project → create key). Add each one on the
Credentials page. Leave the project label empty (each key becomes its own
quota group) or use labels to mark keys that share a project.

### Wake word

Pick one in **Settings → Voice & wake word**: Hey Jarvis (default), Alexa,
Hey Mycroft, or Hey Rhasspy. The change applies live — no restart. To use a
custom "Chat" wake word, train a model at
https://github.com/dscripka/openWakeWord#training-new-models, choose
"Custom model file..." in the picker, and give the path to the `.onnx` file.

### Voice announcements (optional, offline)

Run once to generate spoken status messages with Windows' built-in TTS:

    .venv\Scripts\python.exe deployment\windows\generate_announcements.py

Without them, announcements print to the console with a bell sound. Re-run
it after an update that adds new messages (this version added the quiet mode
confirmations and the missed-reminder notice).

### Saying "stop"

Chat already goes quiet the moment you talk over it. Saying just **"stop"**
(or "be quiet", "shut up", "never mind") cancels the rest of the answer
entirely, and every dashboard page has a red **Stop talking** button that
does the same — handy from a phone. Stop works offline too if the offline
recognizer below is installed.

### Offline voice commands (optional)

Speech understanding normally runs through Gemini, so when every key is
blocked, voice commands stop. Install the offline recognizer and spoken
commands keep working with zero internet:

1. The `vosk` package is included in `requirements-voice.txt`
   (or `.venv\Scripts\pip install vosk`).
2. Download a small English model from https://alphacephei.com/vosk/models
   — `vosk-model-small-en-us-0.15` (~40 MB) is plenty.
3. Unzip it and rename the folder to `assets\vosk-model` inside the Chat
   folder, or point **Settings → Offline speech model folder** at it.

In local-only mode Chat then hears the wake word, records your sentence,
transcribes it on your own CPU, and runs it against the same safe grammar as
the dashboard command box: timers, reminders and alarms, weather, quiet mode,
lights, remember/recall/forget, stop. Anything outside that grammar gets a
short refusal announcement.

### Memory

Say "Chat, remember that the garage code is 4417" — stored permanently on
your machine. Ask "what do you remember about the garage?" and it answers
from its stored facts; "forget the garage code" deletes them. The
dashboard's **Memory** page lists everything with add and forget buttons.
Works through Gemini (natural phrasing) and offline through the local
grammar ("remember that...", "what do you remember", "forget ...").

### Reminders and alarms

"Remind me at 5 to take the chicken out", "remind me to stretch at 7:30 pm",
"wake me up at 7 am". Both survive restarts; anything that came due while
the machine was off is flagged as missed. An alarm (or a reminder) rings
loud — repeating bell pulses — until you say "stop", press a Stop button,
or tap **Dismiss** on the red banner that appears on every dashboard page.
With the offline voice installed, Chat also speaks the reminder text while
ringing. The **Reminders** page schedules them with a normal time picker,
and Settings controls how long and how loud they ring.

About ambiguous times: "at 5" means the next time the clock shows 5 —
5 pm if it's morning, 5 am tomorrow if it's evening. "Tonight at 9" is 9 pm.
"Tomorrow at 5" without am/pm takes the morning reading — say "5 pm" to be
precise.

### Weather

"What's the weather", "will it rain tomorrow". Set your town once in
**Settings → Weather & location** (type it, press Search, pick a result).
Forecasts come from Open-Meteo — free, no account, no API key — and the
Status page shows a weather card. Works by voice even in local-only mode;
with the offline voice installed Chat reads the forecast out loud.

### Quiet mode

"Quiet mode on" (or the sidebar button) stops all unprompted talking:
status notices, missed-timer announcements, and so on. Chat still answers
things you actually ask, and timers, reminders and alarms **still ring** —
deliberately, so a wake-up alarm can't be lost to quiet mode. If you want
those silent too, flip "In quiet mode, timers and alarms" in Settings.
Quiet mode is only ever switched by you — Chat never turns it on by itself.
It's different from the mic mute: mute stops Chat *hearing*, quiet stops it
*speaking up*.

### Listening on your phone

Open the dashboard from your phone (see LAN access below), then on
**Status → Listen on this device** tap **Start listening** — Chat's voice
now plays out of the phone. "Where the voice plays" controls the computer
side:

* **Computer speaker** — normal.
* **Phone only** — the computer stays silent. Perfect when the laptop's
  speaker is a Bluetooth box you don't want to use, or for headphones.
* **Both** — everywhere at once.

## Running modes

| Command                          | What runs                                  |
|----------------------------------|--------------------------------------------|
| `run_chat.bat`                   | Everything (voice auto-off if not installed)|
| `run_chat.bat --no-voice`        | Cloud + dashboard, microphone off           |
| `run_chat.bat --dashboard-only`  | Dashboard + timers only, no cloud at all    |
| `run_chat.bat --verbose`         | Same, with chatty console logging           |
| `deployment\windows\run_hidden.vbs` | Fully invisible (no window)              |

## The dashboard

* **Status** — live state (SLEEPING / LISTENING / SPEAKING / LOCAL_ONLY),
  component health, usable-key count, next quota retry, quiet mode, the
  weather card, the phone address, and the local command box.
* **Credentials** — add/disable/delete Gemini keys, grouped by project, with
  masked suffixes only. "Make active" switches keys for the *next* session —
  a live conversation is never interrupted.
* **Providers** — Govee API key and the rotation policy explained.
* **Usage** — session starts/ends and tool calls (sanitized, never content).
* **Devices** — your Govee lights with quick on/off.
* **Timers** — create, pause, resume, cancel. Timers survive restarts;
  anything that expired while the machine was off is announced as missed.
* **Reminders** — clock-time reminders and loud alarms with a time picker,
  plus recent fired/missed history. A ringing alarm shows a red banner with
  a Dismiss button on every page.
* **Memory** — every fact Chat has been asked to remember, with add and
  forget buttons.
* **Logs** — the detailed event log (the console stays quiet on purpose).
* **Settings** — everything is editable here: wake word picker, microphone
  and speaker choice, sound routing, alarm ring length and loudness, your
  town for weather, key rotation and quota tuning, health-check intervals,
  updates, phone access, password. Voice settings apply live without a
  restart.

Every page also has the red **Stop talking** button and the mute switch.

### Reaching the dashboard from your phone

Phone access is on by default for new installs: the console window prints a
"Phone on Wi-Fi" address (also shown on the Status page and in Settings) —
open it on any device on your Wi-Fi and sign in with your dashboard
password. (The very first password creation only works on the laptop
itself — other devices are refused until the password exists.) The pages
are phone-friendly, with a slide-out menu and big Stop / Dismiss buttons. To restrict the dashboard to this computer only,
set **Settings → Dashboard access → Phone access** to Off and restart.
Upgraded installs keep their old setting — flip it to On the same way.
For HTTPS, run `python deployment\windows\make_cert.py` once and restart —
the browser will warn once about the self-signed certificate.

## Automatic updates

Chat updates itself. New versions are published at

    https://raw.githubusercontent.com/Nick-PY0/chat-assistant-updates/main/latest.json

and fresh installs have that link set as the default — nothing to do. Chat
checks it quietly every 6 hours, downloads a new version in the background,
checks the publisher's tamper-proof signature on it, and swaps it in on the
next start — or right away via **Settings → Restart Chat**. An update that
is unsigned or altered in any way is refused. On an older install, open
**Settings → Updates → Update link**: if the box is empty, paste the link
above once. To opt out, turn **Automatic updates** off in Settings.

### Publishing to your own link instead

Prefer a link you control? Host a small `latest.json` anywhere public (a
GitHub release works great):

       {
         "version": "1.2.0",
         "zip_url": "https://github.com/you/chat/releases/download/v1.2.0/chat-assistant.zip",
         "notes": "what changed"
       }

Paste that link into **Settings → Updates → Update link**. To publish a
new version: bump `APP_VERSION` in `chat_core/version.py`, zip the whole
`chat-assistant` folder, upload it, and update `latest.json`.

Chat refuses unsigned updates by default. For your own channel, create
your own keys once with `python deployment/release/sign_manifest.py keygen`
(put the printed public key into `apps/updater/updater.py`), then sign
every release with
`python deployment/release/sign_manifest.py sign latest.json your.zip`
before uploading — that fills in the `sha256` and `sig` fields. If you
would rather skip signing on a private link you trust, turn **Require
signed updates** off in Settings.

Downloads are size-capped, checked to be a real Chat build, and staged in
the data folder first — a bad or half-finished download can never break the
running install.

GitHub walkthrough: create a repository → **Releases** → *Draft a new
release* → attach the zip **and** `latest.json` → publish. Then
`https://github.com/<you>/<repo>/releases/latest/download/latest.json`
always points at your newest release, so it never needs changing.

## Building Chat.exe (runs without Python)

On any Windows machine with the project and `.venv` set up:

    deployment\windows\build_exe.bat

This produces `dist\Chat\` with **Chat.exe** inside. The folder is fully
self-contained — copy it to any Windows computer and double-click the exe;
Python does not need to be installed there. Whatever is in `.venv` at build
time gets baked in, so install the voice packages first if you want voice.
A vosk model can also be dropped next to the exe later
(`Chat\assets\vosk-model`).

Notes:

* The exe must be built **on Windows** — PyInstaller cannot cross-build, so
  run the build on the laptop itself.
* Auto-update works for exe installs too: zip the new `dist\Chat` folder and
  point `zip_url` at that zip.

## Security model (short version)

* API keys are encrypted (AES-256-GCM) with a master secret held in the
  Windows Credential Locker (or a protected file if `keyring` is missing).
* The dashboard password is hashed with Argon2id; sessions are signed
  HttpOnly cookies; every write needs a CSRF token; login is rate-limited.
* First-time setup (creating that password) is only accepted from the
  computer running Chat itself, so nothing on your network can claim the
  dashboard before you do.
* Plaintext keys never appear in the UI, API responses, logs, or the console
  — only masked suffixes like `••••1234`.
* The assistant can only run allowlisted tools (timers, lights). It cannot
  touch your files, run commands, or change its own configuration.

## Data location

Everything Chat stores lives in `%LOCALAPPDATA%\ChatAssistant`
(config.json, chat.db, optional cert files). Set the `CHAT_DATA_DIR`
environment variable to move it. Delete that folder to factory-reset.

## Running the tests

    pip install pytest pytest-asyncio
    python -m pytest

## Project layout

    run_chat.py            single-process launcher (all services as tasks)
    run_chat.bat           Windows launcher (small black console window)
    chat_core/             config, event bus, state machine, DB, security
    apps/audio/            wake word, mic/speaker streams, announcements
    apps/live_gateway/     Gemini Live sessions + automatic key rotation
    apps/tool_service/     timers, reminders, weather, Govee tools, local grammar
    apps/pulse/            isolated health checks & quota-retry scheduling
    apps/dashboard/        FastAPI control panel (this is the web UI)
    apps/updater/          background self-update (manifest -> stage -> swap)
    integrations/          Gemini + Govee API clients
    deployment/windows/    installer, exe build, TTS + cert helpers
    migrations/            SQLite schema
    tests/                 pytest suite

## Troubleshooting

* **"voice pipeline disabled: audio packages not installed"** — run
  `pip install -r requirements-voice.txt` inside `.venv`, or ignore it if
  you only want the dashboard.
* **Wake word never triggers** — lower the sensitivity in Settings
  (e.g. 0.45), check Windows microphone permissions for Python.
* **"wake word unavailable" in the console or Logs** — the wake word model
  files were missing (they are a separate one-time download, which
  install.bat used to skip). Chat now downloads them by itself on the next
  start with internet; the message spells out anything else that is wrong.
* **"local mode" announcements** — every key is blocked or invalid. Check
  the Credentials page; Chat retries automatically at the earliest reset.
* **Dashboard unreachable from another device** — check Settings →
  Dashboard access → Phone access is On (older installs may have it Off),
  restart Chat, and allow Python through the Windows firewall prompt. Both
  devices must be on the same Wi-Fi.
* **An alarm didn't ring in quiet mode** — Settings → "In quiet mode,
  timers and alarms" must be "Still ring out loud" (the default).
* **Weather says "no home location set"** — pick your town in Settings →
  Weather & location, then press Save.
* **Phone listening is silent** — tap *Start listening* again after the
  phone screen was locked (browsers pause audio in the background), and
  check the routing isn't set to "Computer speaker" while you expected
  "Both".
* **Offline commands answer "that's not something I can do offline"** —
  the sentence didn't match the safe grammar (timers, lights, memory,
  stop). Check Logs to see what the recognizer heard.
* **An update downloaded but nothing changed** — updates apply on the next
  start: use Settings → Restart Chat or close and reopen the console
  window. The Updates card shows any error text.
