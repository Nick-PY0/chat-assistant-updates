"""Dashboard security + API behavior via in-process ASGI transport."""

from __future__ import annotations

import asyncio
import httpx
import pytest
from datetime import datetime, timedelta, timezone

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime
from integrations.google_calendar import CalendarEvent


@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def do_setup(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    assert client.cookies.get(COOKIE)


async def test_first_run_forces_setup(client):
    resp = await client.get("/")
    assert resp.status_code == 303
    assert resp.headers["location"] == "/setup"


async def test_setup_rejects_cross_site_posts(client):
    """A hostile web page must not be able to claim an unclaimed dashboard."""
    resp = await client.post(
        "/setup",
        data={"password": "attacker-pass1", "confirm": "attacker-pass1"},
        headers={"origin": "http://evil.example"},
    )
    assert resp.status_code == 403

    resp = await client.post(
        "/setup",
        data={"password": "attacker-pass1", "confirm": "attacker-pass1"},
        headers={"sec-fetch-site": "cross-site"},
    )
    assert resp.status_code == 403

    # same-origin browser post still works
    resp = await client.post(
        "/setup",
        data={"password": "legit-pass-123", "confirm": "legit-pass-123"},
        headers={"origin": "http://test", "host": "test", "sec-fetch-site": "same-origin"},
    )
    assert resp.status_code == 303


async def test_login_rejects_cross_site_posts(client):
    await do_setup(client)
    client.cookies.delete(COOKIE)
    resp = await client.post(
        "/login",
        data={"password": "hunter2secure"},
        headers={"origin": "http://evil.example"},
    )
    assert resp.status_code == 403


async def test_logout_requires_csrf(client):
    await do_setup(client)
    resp = await client.post("/logout", data={"_csrf": "forged"})
    assert resp.status_code == 403
    resp = await client.post("/logout", data={"_csrf": await csrf_of(client)})
    assert resp.status_code == 303


async def test_logout_revocation_survives_app_reload_and_denies_websocket(client, rt):
    await do_setup(client)
    stolen = client.cookies.get(COOKIE)
    csrf = await csrf_of(client)
    response = await client.post("/logout", data={"_csrf": csrf})
    assert response.status_code == 303

    reloaded = create_app(rt)
    transport = httpx.ASGITransport(app=reloaded)
    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies={COOKIE: stolen},
    ) as attacker:
        assert (await attacker.get("/api/state")).status_code == 401

    class StolenSocket:
        cookies = {COOKIE: stolen}
        close_code = None

        async def close(self, code):
            self.close_code = code

    route = next(
        route for route in reloaded.routes
        if getattr(route, "path", None) == "/ws/audio"
    )
    socket = StolenSocket()
    await route.endpoint(socket)
    assert socket.close_code == 4401


async def test_concurrent_logouts_merge_persisted_revocations(client, rt):
    await do_setup(client)
    first_token = client.cookies.get(COOKIE)
    first_csrf = await csrf_of(client)

    transport = httpx.ASGITransport(app=client.app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as second:
        response = await second.post("/login", data={"password": "hunter2secure"})
        assert response.status_code == 303
        second_token = second.cookies.get(COOKIE)
        second_csrf = client.app.state.sessions.csrf_for(second_token)
        await asyncio.gather(
            client.post("/logout", data={"_csrf": first_csrf}),
            second.post("/logout", data={"_csrf": second_csrf}),
        )

    reloaded = create_app(rt)
    for token in (first_token, second_token):
        replay = httpx.ASGITransport(app=reloaded)
        async with httpx.AsyncClient(
            transport=replay,
            base_url="http://test",
            cookies={COOKIE: token},
        ) as attacker:
            assert (await attacker.get("/api/state")).status_code == 401


async def test_api_requires_auth(client):
    resp = await client.get("/api/state")
    assert resp.status_code == 401


async def test_broadcast_toggle_requires_auth_csrf_and_loopback(client, monkeypatch):
    assert (await client.get("/api/broadcast/status")).status_code == 401
    await do_setup(client)

    response = await client.post("/api/broadcast", json={"enabled": True})
    assert response.status_code == 403

    async def no_network_start():
        return None

    monkeypatch.setattr(client.app.state.broadcast, "start", no_network_start)
    csrf = await csrf_of(client)
    response = await client.post(
        "/api/broadcast",
        json={"enabled": True},
        headers={"x-csrf": csrf},
    )
    assert response.status_code == 200
    assert response.json()["enabled"] is True

    transport = httpx.ASGITransport(app=client.app, client=("192.0.2.10", 41000))
    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies={COOKIE: client.cookies.get(COOKIE)},
        headers={"x-csrf": csrf},
    ) as remote:
        assert (await remote.get("/api/broadcast/status")).status_code == 403
        assert (
            await remote.post("/api/broadcast", json={"enabled": False})
        ).status_code == 403


async def test_experts_catalog_shape_matches_provider_page(client, rt, monkeypatch):
    await do_setup(client)

    async def fake_catalog():
        return {
            "providers": {
                "chatgpt": [{"id": "gpt-test", "label": "GPT Test"}],
                "claude": [{"id": "claude-test", "label": "Claude Test"}],
            }
        }

    monkeypatch.setattr(rt.experts, "catalog", fake_catalog)
    resp = await client.get("/api/experts")
    assert resp.status_code == 200
    data = resp.json()
    assert set(data["catalog"]) == {"chatgpt", "claude"}
    assert data["catalog"]["chatgpt"][0]["id"] == "gpt-test"
    assert "providers" not in data["catalog"]


async def test_setup_then_login_flow(client):
    await do_setup(client)
    resp = await client.get("/")
    assert resp.status_code == 200

    # sign out, wrong password rejected, right password accepted
    client.cookies.delete(COOKIE)
    resp = await client.post("/login", data={"password": "wrong-password"})
    assert resp.status_code == 401
    resp = await client.post("/login", data={"password": "hunter2secure"})
    assert resp.status_code == 303


async def test_login_rate_limit(client):
    await do_setup(client)
    client.cookies.delete(COOKIE)
    for _ in range(5):
        await client.post("/login", data={"password": "bad-guess-123"})
    resp = await client.post("/login", data={"password": "bad-guess-123"})
    assert resp.status_code == 429


async def test_csrf_required_on_writes(client):
    await do_setup(client)
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": "AIzaExampleKey001"},
        headers={"x-csrf": "forged"},
    )
    assert resp.status_code == 403

    resp = await client.post(
        "/api/calendar/preferences",
        json={
            "timezone": "UTC",
            "meeting_alert_enabled": True,
            "meeting_lead_minutes": 10,
            "briefing_enabled": True,
            "briefing_time": "08:00",
            "weekdays": [0, 1, 2, 3, 4],
            "sections": ["calendar"],
        },
        headers={"x-csrf": "forged"},
    )
    assert resp.status_code == 403


async def test_add_credential_returns_only_mask(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    secret = "AIzaSyRealSecretKey12345"
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": secret, "project_label": "proj-a"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert secret not in resp.text
    assert body["credential"]["masked_suffix"].endswith("2345")

    listing = await client.get("/api/credentials")
    assert secret not in listing.text
    projects = listing.json()["projects"]
    assert len(projects) == 1
    assert projects[0]["label"] == "proj-a"


async def test_credential_lifecycle_actions(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    resp = await client.post(
        "/api/credentials",
        json={"provider": "gemini", "secret": "AIzaKeyLifecycle1"},
        headers={"x-csrf": csrf},
    )
    cred_id = resp.json()["credential"]["id"]

    for action, expected in (("disable", "disabled"), ("enable", "standby")):
        resp = await client.post(
            f"/api/credentials/{cred_id}/action", json={"action": action}, headers={"x-csrf": csrf}
        )
        assert resp.status_code == 200
        listing = (await client.get("/api/credentials")).json()
        assert listing["projects"][0]["keys"][0]["status"] == expected

    resp = await client.post(
        f"/api/credentials/{cred_id}/action", json={"action": "delete"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200
    assert (await client.get("/api/credentials")).json()["projects"] == []


async def test_timers_and_command_box(client):
    await do_setup(client)
    csrf = await csrf_of(client)

    resp = await client.post(
        "/api/command", json={"text": "set a tea timer for 9 minutes"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200
    assert resp.json()["command"]["tool"] == "start_timer"

    timers = (await client.get("/api/timers")).json()["timers"]
    assert len(timers) == 1 and timers[0]["label"] == "tea"

    resp = await client.post(
        f"/api/timers/{timers[0]['id']}/cancel", json={}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 200

    resp = await client.post(
        "/api/command", json={"text": "order me a pizza"}, headers={"x-csrf": csrf}
    )
    assert resp.status_code == 400


async def test_routines_page_api_security_crud_run_and_command(client):
    assert (await client.get("/api/routines")).status_code == 401
    await do_setup(client)
    csrf = await csrf_of(client)

    page = await client.get("/routines")
    assert page.status_code == 200
    assert "Starter Templates" in page.text
    catalog = (await client.get("/api/routines/catalog")).json()
    assert catalog["default_timezone"]
    assert {item["type"] for item in catalog["actions"]} >= {
        "briefing", "music_play", "govee_power", "tv_app", "alarm", "wait",
    }
    assert "get_briefing" not in str(catalog)

    payload = {
        "name": "Dashboard scene",
        "aliases": ["dashboard ready"],
        "enabled": True,
        "announce_summary": False,
        "steps": [{"type": "wait", "args": {"seconds": 0}}],
        "trigger": None,
    }
    assert (await client.post("/api/routines", json=payload)).status_code == 403
    created = await client.post(
        "/api/routines", json=payload, headers={"x-csrf": csrf}
    )
    assert created.status_code == 201
    routine = created.json()["routine"]

    check = await client.post(
        f"/api/routines/{routine['id']}/test", json={}, headers={"x-csrf": csrf}
    )
    assert check.json() == {"valid": True, "errors": []}
    run = await client.post(
        f"/api/routines/{routine['id']}/run", json={}, headers={"x-csrf": csrf}
    )
    assert run.status_code == 200
    assert run.json()["run"]["status"] == "completed"
    assert run.json()["run"]["steps"][0]["status"] == "success"

    by_alias = await client.post(
        "/api/command", json={"text": "dashboard ready"}, headers={"x-csrf": csrf}
    )
    assert by_alias.status_code == 200
    assert by_alias.json()["command"]["tool"] == "run_routine"
    explicit = await client.post(
        "/api/command",
        json={"text": "run dashboard scene"},
        headers={"x-csrf": csrf},
    )
    assert explicit.status_code == 200
    assert explicit.json()["result"]["status"] == "completed"

    listing = (await client.get("/api/routines")).json()
    assert listing["routines"][0]["name"] == "Dashboard scene"
    assert listing["recent_runs"][0]["steps"][0]["duration_ms"] >= 0
    assert "args" not in listing["recent_runs"][0]["steps"][0]

    changed = dict(payload)
    changed["description"] = "Updated"
    changed["expected_version"] = routine["version"]
    updated = await client.put(
        f"/api/routines/{routine['id']}", json=changed, headers={"x-csrf": csrf}
    )
    assert updated.status_code == 200
    conflict = await client.put(
        f"/api/routines/{routine['id']}", json=changed, headers={"x-csrf": csrf}
    )
    assert conflict.status_code == 409

    deleted = await client.delete(
        f"/api/routines/{routine['id']}", headers={"x-csrf": csrf}
    )
    assert deleted.json()["deleted"] is True


async def test_routine_templates_are_guided_incomplete_drafts(client):
    await do_setup(client)
    csrf = await csrf_of(client)
    templates = (await client.get("/api/routines/templates")).json()["templates"]
    morning = next(item for item in templates if item["id"] == "good_morning")
    night = next(item for item in templates if item["id"] == "good_night")
    assert any("Calendar" in item for item in morning["setup"])
    assert night["steps"][-1]["type"] == "alarm"

    made = await client.post(
        "/api/routines/templates/good_night", json={}, headers={"x-csrf": csrf}
    )
    assert made.status_code == 201
    draft = made.json()["routine"]
    assert draft["template_draft"] and not draft["enabled"]
    enable = await client.post(
        f"/api/routines/{draft['id']}/enable",
        json={"enabled": True},
        headers={"x-csrf": csrf},
    )
    assert enable.status_code == 400


async def test_mute_toggle_persists(client, rt):
    await do_setup(client)
    csrf = await csrf_of(client)
    resp = await client.post("/api/mute", json={"muted": True}, headers={"x-csrf": csrf})
    assert resp.json()["muted"] is True
    assert await rt.db.get_setting("muted") == "1"
    state = (await client.get("/api/state")).json()
    assert state["state"]["state"] == "MUTED"


async def test_password_change_invalidates_sessions_across_reload(client, rt):
    await do_setup(client)
    old_token = client.cookies.get(COOKIE)
    csrf = await csrf_of(client)
    resp = await client.post(
        "/api/password",
        json={"current": "wrong", "new": "newpassword99"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 403
    resp = await client.post(
        "/api/password",
        json={"current": "hunter2secure", "new": "newpassword99"},
        headers={"x-csrf": csrf},
    )
    assert resp.status_code == 200
    assert (await client.get("/api/state")).status_code == 401

    reloaded = create_app(rt)
    transport = httpx.ASGITransport(app=reloaded)
    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies={COOKIE: old_token},
    ) as replay:
        assert (await replay.get("/api/state")).status_code == 401

    client.cookies.delete(COOKIE)
    resp = await client.post("/login", data={"password": "newpassword99"})
    assert resp.status_code == 303


async def test_mobile_app_page(client):
    await do_setup(client)
    resp = await client.get("/mobile-app")
    assert resp.status_code == 200

    # Verify exact platform claims are present
    assert "AlarmManager" in resp.text
    assert "AlarmKit" in resp.text
    assert "artifacts/jarvis-alarm" in resp.text
    assert "Replit Launch" in resp.text
    assert "Cannot force physical/system volume" in resp.text
    assert "not background fetch or push notifications" in resp.text

    # Verify all dashboard destinations are present exactly once in the directory
    import re
    expected_links = {
        "/", "/chat", "/media", "/reminders", "/routines", "/calendar",
        "/timers", "/memory", "/devices", "/credentials", "/providers",
        "/usage", "/logs", "/transcripts", "/github", "/settings",
        "/voice-controller", "/mobile-setup"
    }
    feature_links = re.findall(r'<a href="([^"]+)" class="[^"]*feature-link[^"]*">', resp.text)
    assert set(feature_links) == expected_links
    assert len(feature_links) == len(expected_links)


async def test_calendar_api_auth_oauth_secrecy_and_callback_binding(client, rt):
    assert (await client.get("/api/calendar/status")).status_code == 401
    await do_setup(client)
    csrf = await csrf_of(client)
    client_id = "calendar-client-id.apps.googleusercontent.com"
    client_secret = "calendar-client-secret-value"
    started = await client.post(
        "/api/calendar/oauth/start",
        json={"client_id": client_id, "client_secret": client_secret},
        headers={"x-csrf": csrf},
    )
    assert started.status_code == 200
    assert client_id not in started.text
    assert client_secret not in started.text
    local_handoff = started.json()["authorization_url"]
    assert local_handoff.startswith("/calendar/oauth/continue?handoff=")

    status = await client.get("/api/calendar/status")
    assert status.status_code == 200
    assert client_id not in status.text
    assert client_secret not in status.text
    assert "access_token" not in status.text
    assert "refresh_token" not in status.text
    assert status.json()["account"]["configured"] is True

    page = await client.get("/providers")
    assert client_id not in page.text
    assert client_secret not in page.text

    missing = await client.get("/api/calendar/oauth/callback?state=forged&code=forged")
    assert missing.status_code == 303
    assert missing.headers["location"] == "/providers?google=error"

    follow = await client.get(local_handoff, follow_redirects=False)
    assert follow.status_code == 303
    assert follow.headers["location"].startswith(
        "https://accounts.google.com/o/oauth2/v2/auth?"
    )
    replay = await client.get(local_handoff, follow_redirects=False)
    assert replay.status_code == 400


async def test_calendar_appointment_api_reviews_before_single_write(
    client, rt, monkeypatch
):
    await do_setup(client)
    csrf = await csrf_of(client)
    await rt.google_account.configure("client", "secret")
    await rt.google_account.save_tokens(
        "access", "refresh", datetime.now(timezone.utc) + timedelta(hours=1), ["openid"]
    )
    await rt.google_account.save_calendar_selection(["primary"], "primary")
    writes = {"create": 0, "get": 0}

    async def calendars():
        return [{
            "id": "primary", "name": "Main", "timezone": "UTC",
            "primary": True, "access_role": "owner", "selected": True,
            "write_allowed": True,
        }]

    async def create(calendar_id, payload):
        writes["create"] += 1
        return CalendarEvent(
            "created", calendar_id, "Main", payload["summary"],
            payload["start"]["dateTime"], payload["end"]["dateTime"], False,
            payload["start"]["timeZone"], None, None, None, "confirmed",
        )

    async def get(calendar_id, event_id):
        writes["get"] += 1
        return CalendarEvent(
            event_id, calendar_id, "Main", "Verified dentist",
            "2099-01-08T10:30:00+00:00", "2099-01-08T11:30:00+00:00", False,
            "UTC", None, None, None, "confirmed",
        )

    monkeypatch.setattr(rt.google_calendar, "calendars", calendars)
    monkeypatch.setattr(rt.google_calendar, "create_event", create)
    monkeypatch.setattr(rt.google_calendar, "get_event", get)

    review = await client.post(
        "/api/calendar/appointments/review",
        json={
            "title": "Dentist",
            "start_local": "2099-01-08T10:30",
            "duration_minutes": 60,
            "timezone": "UTC",
        },
        headers={"x-csrf": csrf},
    )
    assert review.status_code == 200
    assert writes == {"create": 0, "get": 0}
    draft_id = review.json()["draft"]["id"]

    denied = await client.post(
        "/api/calendar/appointments/confirm",
        json={"draft_id": draft_id, "confirmed": False},
        headers={"x-csrf": csrf},
    )
    assert denied.status_code == 400
    assert writes == {"create": 0, "get": 0}

    confirmed = await client.post(
        "/api/calendar/appointments/confirm",
        json={"draft_id": draft_id, "confirmed": True},
        headers={"x-csrf": csrf},
    )
    assert confirmed.status_code == 200
    assert confirmed.json()["event"]["title"] == "Verified dentist"
    assert writes == {"create": 1, "get": 1}

    replay = await client.post(
        "/api/calendar/appointments/confirm",
        json={"draft_id": draft_id, "confirmed": True},
        headers={"x-csrf": csrf},
    )
    assert replay.status_code == 400
    assert writes == {"create": 1, "get": 1}
