"""Lifecycle manager for the optional LG webOS TV integration.

One TV (single row 'default' in lg_webos_devices), local network only.

Responsibilities:
  * configuration (enable toggle, host, optional MAC for Wake-on-LAN)
  * pairing: on-screen PROMPT approval; the returned client key is encrypted
    with the vault (context ``lg_webos:pairing``) before it touches disk and
    is never logged, never returned by any API, and never shown in the UI
  * a truthful connection lifecycle: physical power state and control-channel
    health are tracked separately, so the dashboard can distinguish
    ready / connecting / degraded / offline / powering-on / powering-off /
    powered-on-but-unreachable instead of one connected flag
  * one generation-fenced connection owner (the run loop) plus one ordered
    command path (`_cmd_lock`): commands, pointer presses, and read-modify-
    write volume changes are serialized and can never apply results through
    a stale connection
  * active health probes while ready: a silent or timed-out socket is marked
    degraded, closed, and re-dialed immediately instead of staying falsely
    connected; reconnects back off with jitter and can be interrupted by
    refresh()/power_on()
  * safe state caching (volume/mute/app/inputs/apps) with generation fencing
    so events from a dead connection can never clobber a live one
  * the narrow command surface used by tools, voice grammar, and dashboard

The MAC address is write-only: accepted from the user, stored, used for WoL,
and exposed only as the boolean ``wol_ready``.  Wake-on-LAN is always
reported as "wake signal sent", never as "the TV is on"; power-on/off are
confirmed by probes, subscription pushes, or the expected socket close.
"""

from __future__ import annotations

import asyncio
import contextlib
import difflib
import json
import logging
import random
import time
from typing import Any, Callable

from chat_core.events import EventBus
from chat_core.models.db import Database
from chat_core.security.vault import Vault
from .client import (
    SSAPClient,
    SSAPError,
    SSAPNotSupported,
    SSAPPairingRejected,
)
from .protocol import (
    BUTTONS,
    MEDIA_ACTIONS,
    URI_FOREGROUND_APP,
    URI_GET_VOLUME,
    URI_INPUT_LIST,
    URI_INSERT_TEXT,
    URI_LAUNCH_APP,
    URI_LIST_APPS,
    URI_POWER_STATE,
    URI_REGISTER_REMOTE_KEYBOARD,
    URI_SEND_ENTER,
    URI_SET_MUTE,
    URI_SET_VOLUME,
    URI_SWITCH_INPUT,
    URI_SYSTEM_INFO,
    URI_TURN_OFF,
    clamp_volume,
    normalize_mac,
    valid_app_id,
    valid_host,
)
from .wol import WoLError, send_wol
from . import discovery as ssdp

log = logging.getLogger("lg_webos")

DEVICE_ID = "default"
KEY_SETTING = "lg_webos_client_key"
KEY_CONTEXT = "lg_webos:pairing"
RECONNECT_DELAYS = (2.0, 5.0, 10.0, 20.0, 40.0, 60.0)
STATE_WRITE_MIN_INTERVAL = 5.0  # seconds between last_state_json writes
TEXT_MAX_CHARS = 120  # hard cap for one type_text call (search boxes are short)

# Lifecycle timing (constructor-overridable so tests can shrink them).
HEALTH_INTERVAL = 20.0       # seconds between liveness probes while ready
PROBE_TIMEOUT = 4.0          # per-request budget for one health probe
COMMAND_TIMEOUT = 8.0        # transport budget for one user command
WAKE_WINDOW = 45.0           # eager reconnect window after a wake signal
OFF_CONFIRM_WINDOW = 12.0    # wait for power-off confirmation before deciding
REFRESH_WAIT = 6.0           # refresh(): max wait for a reconnect to land
DEGRADED_RETRY_PAUSE = 0.25  # pause before re-dialing a degraded connection

# States where the TV's own power report counts as "panel is on".
_POWER_ON_VALUES = {"on", "active"}


class WebOSTVError(Exception):
    """TV integration error with a message safe to show the user."""


def _now_iso() -> str:
    from chat_core.models.credentials import iso, utcnow

    return iso(utcnow())


class WebOSManager:
    def __init__(
        self,
        db: Database,
        bus: EventBus,
        vault: Vault,
        settings=None,
        connect_factory: Callable | None = None,
        wol_sender: Callable | None = None,
        discover_fn: Callable | None = None,
        reconnect_delays: tuple[float, ...] = RECONNECT_DELAYS,
        health_interval: float = HEALTH_INTERVAL,
        probe_timeout: float = PROBE_TIMEOUT,
        command_timeout: float = COMMAND_TIMEOUT,
        wake_window: float = WAKE_WINDOW,
        off_window: float = OFF_CONFIRM_WINDOW,
        refresh_wait: float = REFRESH_WAIT,
        keyboard_focus_wait: float = 1.5,
        app_launch_wait: float = 8.0,
        app_ready_pause: float = 0.8,
        app_nav_step_wait: float = 0.2,
        jitter: Callable[[], float] | None = None,
    ) -> None:
        self.db = db
        self.bus = bus
        self.vault = vault
        self.settings = settings
        self._connect_factory = connect_factory
        self._wol_sender = wol_sender or send_wol
        self._discover_fn = discover_fn or ssdp.discover
        self._reconnect_delays = reconnect_delays
        self._health_interval = health_interval
        self._probe_timeout = probe_timeout
        self._command_timeout = command_timeout
        self._wake_window = wake_window
        self._off_window = off_window
        self._refresh_wait = refresh_wait
        self._keyboard_focus_wait = max(0.05, float(keyboard_focus_wait))
        self._app_launch_wait = max(0.2, float(app_launch_wait))
        self._app_ready_pause = max(0.0, float(app_ready_pause))
        self._app_nav_step_wait = max(0.02, float(app_nav_step_wait))
        self._jitter = jitter or (lambda: random.uniform(0.85, 1.15))

        # config (mirrors the DB row; _mac is private and never surfaced)
        self.enabled = False
        self.paired = False
        self.host = ""
        self.name = "LG TV"
        self._mac = ""

        # live state
        self._client: SSAPClient | None = None
        self._connected = False
        self._generation = 0  # bumped on every stop/start/pair/unpair
        self._loop_task: asyncio.Task | None = None
        self._pair_task: asyncio.Task | None = None
        self._transition_task: asyncio.Task | None = None
        self._stopping = False
        self._prefer_tls: bool | None = None

        # lifecycle: offline|connecting|ready|degraded|powering_on|powering_off
        # (public view adds disabled/unpaired -- see _lifecycle_public)
        self._lifecycle = "offline"
        self._seq = 0  # bumped on every published change; UI newest-wins guard
        self._cmd_lock = asyncio.Lock()  # one ordered command path
        self._retry_now = asyncio.Event()  # interrupts reconnect backoff
        self._degrade_pending = False
        self._degrade_reason = ""
        self._recovery_attempt = 0
        self._next_retry_at = 0.0  # monotonic; 0 = no retry scheduled
        self._transition_deadline = 0.0  # monotonic; 0 = no transition window
        self._power_confirmed = False  # power value came from a live probe/event
        self._last_ok = 0.0  # monotonic time of the last confirmed TV answer
        self._busy = ""  # name of the command currently holding the lock

        self._state: dict[str, Any] = {}  # volume, muted, power, foreground, model
        self._apps: list[dict] = []
        self._apps_fresh = False
        self._inputs: list[dict] = []
        self._caps: dict[str, bool] = {}
        self._last_error = ""
        self._last_seen_at: str | None = None
        self._pairing_status = "idle"  # idle|connecting|prompt|paired|failed
        self._pairing_error = ""
        self._last_state_write = 0.0
        self._keyboard_client: SSAPClient | None = None
        self._keyboard_focused = False
        self._keyboard_focus_seq = 0
        self._keyboard_focus_event = asyncio.Event()

    # -- lifecycle ---------------------------------------------------------
    async def start(self) -> None:
        row = await self.db.fetchone("SELECT * FROM lg_webos_devices WHERE id=?", (DEVICE_ID,))
        if row is not None:
            self.name = row["name"] or "LG TV"
            self.host = row["host"] or ""
            self._mac = row["mac_address"] or ""
            self.enabled = bool(row["enabled"])
            self.paired = bool(row["paired"])
            self._last_seen_at = row["last_seen_at"]
            try:
                cached = json.loads(row["last_state_json"] or "{}")
            except ValueError:
                cached = {}
            self._state = dict(cached.get("state") or {})
            self._apps = list(cached.get("apps") or [])
            self._apps_fresh = False  # persisted app lists are always stale
            self._power_confirmed = False  # cached power is never confirmed
        if self.enabled and self.paired and self.host:
            self._spawn_loop()

    async def stop(self) -> None:
        self._stopping = True
        self._generation += 1
        await self._cancel_tasks()
        await self._close_client()

    async def _cancel_tasks(self) -> None:
        for task in (self._pair_task, self._loop_task, self._transition_task):
            if task is not None:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        self._pair_task = None
        self._loop_task = None
        self._transition_task = None

    async def _close_client(self) -> None:
        client, self._client = self._client, None
        self._connected = False
        self._keyboard_client = None
        self._clear_keyboard_focus()
        # Without a live connection no cached power value is "confirmed";
        # the run-loop teardown handles its own cases (incl. the confirmed
        # power-off close), but configure/unpair/stop land here instead.
        self._power_confirmed = False
        if client is not None:
            await client.close()

    def _reset_recovery(self) -> None:
        """Clear per-connection lifecycle machinery (callers already fenced)."""
        self._degrade_pending = False
        self._degrade_reason = ""
        self._retry_now = asyncio.Event()
        self._recovery_attempt = 0
        self._next_retry_at = 0.0
        self._transition_deadline = 0.0

    # -- configuration -------------------------------------------------------
    async def configure(
        self,
        name: str | None = None,
        host: str | None = None,
        mac: str | None = None,
        enabled: bool | None = None,
    ) -> dict:
        """Apply a partial config change, persist, and (re)start as needed."""
        if name is not None:
            name = " ".join(str(name).split())[:60]
            if name:
                self.name = name
        if host is not None:
            host = str(host).strip()
            if host and not valid_host(host):
                raise WebOSTVError("that TV address doesn't look valid (use an IP like 192.168.1.50)")
            if host != self.host:
                # same pairing key usually survives an IP change (it belongs
                # to the TV, not the address), so keep `paired`.
                self.host = host
                self._prefer_tls = None
        if mac is not None:
            raw = str(mac).strip()
            if raw == "":
                self._mac = ""
            else:
                normalized = normalize_mac(raw)
                if normalized is None:
                    raise WebOSTVError("that MAC address doesn't look valid (expected AA:BB:CC:DD:EE:FF)")
                self._mac = normalized
        if enabled is not None:
            self.enabled = bool(enabled)
        if self.enabled and not self.host:
            self.enabled = False
            await self._persist_row()
            raise WebOSTVError("enter the TV's IP address (or use Discover) before enabling")
        await self._persist_row()

        # apply the new config to the running loop (and abort any pairing
        # attempt against the old config -- its generation is now stale)
        self._generation += 1
        await self._cancel_tasks()
        if self._pairing_status in ("connecting", "prompt"):
            self._pairing_status = "idle"
            self._pairing_error = ""
        await self._close_client()
        self._reset_recovery()
        self._lifecycle = "offline"
        self._last_error = ""
        if self.enabled and self.paired and self.host:
            self._spawn_loop()
        self._publish()
        return self.snapshot()

    async def discover(self) -> list[dict]:
        """SSDP scan; works before enabling so users can find the TV first."""
        try:
            found = await self._discover_fn()
        except Exception:  # noqa: BLE001 - a scan failure is a result, not a crash
            raise WebOSTVError("network discovery failed; enter the TV's IP address manually") from None
        return [
            {"host": item.get("host", ""), "name": str(item.get("name") or "LG TV")[:60]}
            for item in found
            if valid_host(str(item.get("host", "")))
        ]

    # -- pairing ---------------------------------------------------------------
    async def start_pairing(self) -> dict:
        """Kick off pairing; progress is polled via snapshot()['pairing']."""
        if not self.host:
            raise WebOSTVError("enter the TV's IP address (or use Discover) first")
        if not self.enabled:
            raise WebOSTVError("turn the TV feature on before pairing")
        if self._pairing_status in ("connecting", "prompt"):
            return {"status": self._pairing_status}
        # fence out any existing connection work
        self._generation += 1
        generation = self._generation
        for task in (self._loop_task, self._transition_task):
            if task is not None:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
        self._loop_task = None
        self._transition_task = None
        await self._close_client()
        self._reset_recovery()
        self._lifecycle = "offline"
        self._pairing_status = "connecting"
        self._pairing_error = ""
        self._publish()
        self._pair_task = asyncio.create_task(self._pair(generation), name="lg-pair")
        return {"status": "connecting"}

    async def _pair(self, generation: int) -> None:
        """Register with the TV.  If a previously stored key turns out to be
        revoked, drop it and retry exactly once with a fresh on-screen
        prompt -- Pair must always be a working recovery action."""
        for use_stored in (True, False):
            client = self._make_client()
            stored: str | None = None
            try:
                await client.connect(self._prefer_tls)
                self._prefer_tls = client.used_tls

                def on_prompt() -> None:
                    if generation == self._generation:
                        self._pairing_status = "prompt"
                        self._publish()

                stored = await self._load_key() if use_stored else None
                key = await client.register(stored, on_prompt=on_prompt)
                if generation != self._generation:  # unpaired/reconfigured mid-flight
                    await client.close()
                    return
                await self._store_key(key)
                self.paired = True
                self._pairing_status = "paired"
                self._pairing_error = ""
                await self._persist_row()
                await self.db.log("INFO", "lg_tv", "paired with the TV (approved on screen)")
                await client.close()
                if self.enabled and self.host:
                    self._spawn_loop()
                return
            except SSAPPairingRejected as exc:
                await client.close()
                if generation != self._generation:
                    return
                if use_stored and stored is not None:
                    # the TV revoked the saved key: it is worthless now, so
                    # forget it and loop once more for a fresh prompt
                    await self.db.delete_setting(KEY_SETTING)
                    self.paired = False
                    await self._persist_row()
                    await self.db.log(
                        "WARNING", "lg_tv", "stored pairing rejected; asking for a fresh approval"
                    )
                    self._publish()
                    continue
                self._pairing_status = "failed"
                self._pairing_error = str(exc)
                await self.db.log("WARNING", "lg_tv", "pairing declined on the TV")
                return
            except (SSAPError, OSError) as exc:
                await client.close()
                if generation == self._generation:
                    self._pairing_status = "failed"
                    self._pairing_error = str(exc)[:160]
                return
            except asyncio.CancelledError:
                await client.close()
                raise
            finally:
                if generation == self._generation:
                    self._publish()

    async def unpair(self) -> dict:
        """Forget the pairing key and stop the connection (config stays)."""
        self._generation += 1
        await self._cancel_tasks()
        await self._close_client()
        await self.db.delete_setting(KEY_SETTING)
        self.paired = False
        self._reset_recovery()
        self._lifecycle = "offline"
        self._pairing_status = "idle"
        self._pairing_error = ""
        self._last_error = ""
        await self._persist_row()
        await self.db.log("INFO", "lg_tv", "TV pairing removed")
        self._publish()
        return self.snapshot()

    async def _store_key(self, key: str) -> None:
        blob = self.vault.encrypt(key, KEY_CONTEXT)
        await self.db.set_setting(KEY_SETTING, blob.hex())

    async def _load_key(self) -> str | None:
        stored = await self.db.get_setting(KEY_SETTING)
        if not stored:
            return None
        try:
            return self.vault.decrypt(bytes.fromhex(stored), KEY_CONTEXT)
        except Exception:  # noqa: BLE001 - wrong master secret / corrupt blob
            return None

    # -- connection loop -------------------------------------------------------
    def _make_client(self) -> SSAPClient:
        return SSAPClient(self.host, connect_factory=self._connect_factory)

    def _spawn_loop(self) -> None:
        self._generation += 1
        self._reset_recovery()
        self._lifecycle = "connecting"
        self._loop_task = asyncio.create_task(self._run(self._generation), name="lg-tv")

    def _set_lifecycle(self, value: str, error: str | None = None) -> None:
        if error is not None:
            self._last_error = error
        self._lifecycle = value
        self._publish()

    def _current(self, generation: int, client: SSAPClient) -> bool:
        return generation == self._generation and self._client is client

    def _mark_fresh(self) -> None:
        self._last_ok = time.monotonic()
        self._last_seen_at = _now_iso()

    def _mark_fresh_if(self, client: SSAPClient) -> None:
        if self._client is client:
            self._mark_fresh()

    async def _run(self, generation: int) -> None:
        """The single connection owner: dial, serve, decide what a disconnect
        means, repeat.  Nothing else may set _client/_connected."""
        attempt = 0
        while not self._stopping and generation == self._generation:
            waking = self._lifecycle == "powering_on" and self._transition_deadline > 0
            if not waking:
                self._set_lifecycle("connecting")
            self._recovery_attempt = attempt + 1
            client = self._make_client()
            try:
                await client.connect(self._prefer_tls)
                self._prefer_tls = client.used_tls
                key = await self._load_key()
                if not key:
                    raise WebOSTVError("not paired")
                await client.register(key, timeout=15.0)
            except SSAPPairingRejected:
                # the TV forgot us (user removed the app permission): the
                # saved key is worthless, so drop it too -- Pair on the
                # dashboard then starts a clean on-screen approval
                await client.close()
                if generation != self._generation:
                    return
                await self.db.delete_setting(KEY_SETTING)
                self.paired = False
                self._pairing_status = "idle"
                self._pairing_error = ""
                self._transition_deadline = 0.0
                self._lifecycle = "offline"
                self._last_error = "the TV no longer accepts the saved pairing; re-pair from the dashboard"
                await self._persist_row()
                await self.db.log("WARNING", "lg_tv", "stored pairing rejected by the TV; re-pair needed")
                self._publish()
                return
            except (SSAPError, WebOSTVError, OSError) as exc:
                await client.close()
                if generation != self._generation:
                    return
                waking = self._lifecycle == "powering_on" and self._transition_deadline > 0
                delay = self._reconnect_delays[min(attempt, len(self._reconnect_delays) - 1)]
                attempt += 1
                if waking:
                    # failures are expected while the panel boots: keep the
                    # powering_on state, retry eagerly, don't record errors
                    delay = min(delay, 1.0)
                else:
                    delay = delay * self._jitter()
                    self._set_lifecycle("offline", error=str(exc)[:160])
                self._next_retry_at = time.monotonic() + delay
                self._publish()
                try:
                    await self._wait_retry(delay)
                except asyncio.CancelledError:
                    await client.close()
                    raise
                continue
            except asyncio.CancelledError:
                await client.close()
                raise

            if generation != self._generation:
                await client.close()
                return
            # connected + registered
            attempt = 0
            self._recovery_attempt = 0
            self._next_retry_at = 0.0
            self._transition_deadline = 0.0  # a wake window ends when it answers
            self._client = client
            self._connected = True
            self._mark_fresh()
            self._set_lifecycle("ready", error="")
            await self.db.log("INFO", "lg_tv", "connected to the TV")
            await self._after_connect(client, generation)
            self._publish()
            await self._persist_state(force=True)

            await self._serve(client, generation)
            if generation != self._generation:
                return
            # -- decide what this disconnect means ---------------------------
            was_powering_off = self._lifecycle == "powering_off"
            degraded = self._degrade_pending
            self._degrade_pending = False
            self._connected = False
            self._client = None
            self._keyboard_client = None
            self._clear_keyboard_focus()
            self._apps_fresh = False
            await client.close()
            if was_powering_off:
                # the close we were waiting for: power-off is now confirmed
                self._transition_deadline = 0.0
                self._state["power"] = "off"
                self._power_confirmed = True
                self._set_lifecycle("offline", error="")
                await self.db.log("INFO", "lg_tv", "TV turned off (connection closed as expected)")
            elif degraded:
                self._power_confirmed = False
                self._set_lifecycle(
                    "degraded",
                    error=self._degrade_reason or "the TV stopped answering; reconnecting",
                )
                await self.db.log("WARNING", "lg_tv", "TV connection degraded; reconnecting now")
            else:
                self._power_confirmed = False
                self._set_lifecycle("offline", error="connection lost (TV off or unreachable)")
                await self.db.log("INFO", "lg_tv", "TV connection lost")
            await self._persist_state(force=True)
            if degraded:
                # fast recovery: one short pause instead of the backoff ladder
                with contextlib.suppress(asyncio.TimeoutError):
                    await asyncio.wait_for(self._retry_now.wait(), timeout=DEGRADED_RETRY_PAUSE)
                self._retry_now.clear()

    async def _wait_retry(self, delay: float) -> None:
        """Backoff sleep that refresh()/power_on() can cut short."""
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(self._retry_now.wait(), timeout=delay)
        self._retry_now.clear()

    async def _serve(self, client: SSAPClient, generation: int) -> None:
        """While connected: wait for the socket to close, probing liveness
        every health interval.  A probe that gets no answer within its budget
        marks the connection degraded and tears it down -- a silent socket
        must never keep the dashboard 'connected'."""
        while True:
            try:
                await asyncio.wait_for(client.closed.wait(), timeout=self._health_interval)
                return
            except asyncio.TimeoutError:
                pass
            if not self._current(generation, client):
                return
            if self._lifecycle == "powering_off":
                continue  # the transition watchdog owns probing right now
            ok = await self._health_probe(client, generation)
            if not self._current(generation, client):
                return
            if not ok:
                await self._trigger_degrade(client, "the TV stopped answering; reconnecting")
                return

    async def _health_probe(self, client: SSAPClient, generation: int) -> bool:
        """Bounded liveness + state refresh (volume, power, foreground app).
        True means the transport answered -- even a TV-reported error proves
        the channel is alive.  False means silent/lost: caller degrades."""
        probes: list[tuple[str, Callable[[dict], None]]] = [(URI_GET_VOLUME, self._apply_volume_payload)]
        if self._caps.get("power_state"):
            probes.append((URI_POWER_STATE, self._apply_power_payload))
        probes.append((URI_FOREGROUND_APP, self._apply_foreground_payload))
        alive = False
        for uri, apply in probes:
            try:
                payload = await client.request(uri, timeout=self._probe_timeout)
            except SSAPNotSupported:
                alive = True  # a 404 is still an answer
                continue
            except SSAPError as exc:
                if getattr(exc, "device_detail", False):
                    alive = True  # the TV answered, just with an error
                    continue
                return False  # timeout / connection lost: transport is suspect
            if not self._current(generation, client):
                return False
            apply(payload)
            alive = True
        if alive and self._current(generation, client):
            self._mark_fresh()
            self._publish()
            self._schedule_state_write()
        return alive

    async def _trigger_degrade(self, client: SSAPClient, reason: str) -> None:
        """Mark the current connection broken and close it; the run loop's
        teardown turns this into lifecycle=degraded + an immediate re-dial."""
        if self._client is not client or self._degrade_pending:
            return
        self._degrade_pending = True
        self._degrade_reason = reason
        await client.close()

    async def _suspect_transport(self, client: SSAPClient) -> None:
        if self._client is not client:
            return
        await self._trigger_degrade(client, "the TV stopped answering a command; reconnecting")

    # -- power transitions -----------------------------------------------------
    def _begin_transition(self, lifecycle: str, window: float) -> None:
        """Enter powering_on/powering_off with a bounded confirmation window
        watched by its own generation-fenced task."""
        self._transition_deadline = time.monotonic() + window
        old = self._transition_task
        if old is not None and not old.done():
            old.cancel()
        self._transition_task = asyncio.create_task(
            self._watch_transition(self._generation), name="lg-tv-transition"
        )
        self._set_lifecycle(lifecycle, error="")

    async def _watch_transition(self, generation: int) -> None:
        """Confirm a power transition instead of trusting the optimistic cache:
        probe the panel state over a live socket while the window is open, and
        settle the lifecycle honestly when the window expires."""
        while True:
            if generation != self._generation or self._stopping:
                return
            if self._lifecycle not in ("powering_on", "powering_off") or not self._transition_deadline:
                return
            remaining = self._transition_deadline - time.monotonic()
            if remaining <= 0:
                await self._transition_expired(generation)
                return
            await asyncio.sleep(min(1.0, max(0.05, remaining)))
            if generation != self._generation or self._lifecycle not in ("powering_on", "powering_off"):
                return
            client = self._client
            if client is None or not self._connected or not self._caps.get("power_state"):
                continue
            with contextlib.suppress(SSAPError, asyncio.TimeoutError):
                payload = await client.request(URI_POWER_STATE, timeout=self._probe_timeout)
                if generation != self._generation or self._client is not client:
                    return
                self._apply_power_payload(payload)
                self._mark_fresh()
                state = str(self._state.get("power", "")).lower()
                if self._lifecycle == "powering_on" and state in _POWER_ON_VALUES:
                    self._transition_deadline = 0.0
                    self._set_lifecycle("ready", error="")
                    return
                if self._lifecycle == "powering_off" and state and state not in _POWER_ON_VALUES:
                    # panel reports standby; the socket may outlive it briefly
                    self._transition_deadline = 0.0
                    self._set_lifecycle("ready", error="")
                    return
                self._publish()

    async def _transition_expired(self, generation: int) -> None:
        kind = self._lifecycle
        self._transition_deadline = 0.0
        if kind == "powering_on":
            if self._connected:
                # transport answers but the panel never reported on
                self._set_lifecycle("ready", error="the TV did not confirm it woke up")
            else:
                self._set_lifecycle(
                    "offline",
                    error="the TV did not answer after the wake signal "
                    "(it may not allow network standby)",
                )
                await self.db.log("INFO", "lg_tv", "wake signal sent but the TV never answered")
        elif kind == "powering_off":
            if self._connected:
                client = self._client
                state = ""
                if client is not None and self._caps.get("power_state"):
                    with contextlib.suppress(SSAPError, asyncio.TimeoutError):
                        payload = await client.request(URI_POWER_STATE, timeout=self._probe_timeout)
                        if generation != self._generation:
                            return
                        self._apply_power_payload(payload)
                        state = str(self._state.get("power", "")).lower()
                if state in _POWER_ON_VALUES:
                    self._set_lifecycle("ready", error="the TV did not confirm it turned off")
                else:
                    # webOS quirk: the socket can stay up in standby; the
                    # transport is genuinely usable, so stay ready with the
                    # panel reported off/unknown
                    self._set_lifecycle("ready", error="")
            else:
                self._state["power"] = "off"
                self._power_confirmed = True
                self._set_lifecycle("offline", error="")
        await self._persist_state(force=True)

    async def _after_connect(self, client: SSAPClient, generation: int) -> None:
        """Populate caches and subscriptions; every step tolerates absence."""
        async def probe(uri: str, apply: Callable[[dict], None], cap: str | None = None) -> None:
            try:
                payload = await client.request(uri, timeout=self._probe_timeout)
                if self._current(generation, client):
                    apply(payload)
                if cap:
                    self._caps[cap] = True
            except SSAPNotSupported:
                if cap:
                    self._caps[cap] = False
            except SSAPError:
                pass  # transient failure; state stays cached

        def apply_info(p: dict) -> None:
            model = str(p.get("modelName") or "")
            if model:
                self._state["model"] = model

        def apply_inputs(p: dict) -> None:
            self._inputs = [
                {"id": str(d.get("id") or ""), "label": str(d.get("label") or d.get("id") or "")[:60]}
                for d in (p.get("devices") or [])
                if d.get("id")
            ]

        await probe(URI_SYSTEM_INFO, apply_info)
        await probe(URI_GET_VOLUME, self._apply_volume_payload)
        await probe(URI_FOREGROUND_APP, self._apply_foreground_payload)
        await probe(URI_POWER_STATE, self._apply_power_payload, cap="power_state")
        if "power" not in self._state:
            self._state["power"] = "on"  # it answered the socket; it is on
            self._power_confirmed = True
        await probe(URI_INPUT_LIST, apply_inputs, cap="inputs")
        await probe(URI_LIST_APPS, self._apply_apps_payload)

        # live updates (fenced: stale connections must never write state)
        def fenced(apply: Callable[[dict], None]) -> Callable[[dict], None]:
            def handler(payload: dict) -> None:
                if self._current(generation, client):
                    apply(payload)
                    self._mark_fresh()  # a push proves the channel is alive
                    self._publish()
                    self._schedule_state_write()
            return handler

        with contextlib.suppress(SSAPError):
            await client.subscribe(URI_GET_VOLUME, fenced(self._apply_volume_payload))
        with contextlib.suppress(SSAPError):
            await client.subscribe(URI_FOREGROUND_APP, fenced(self._apply_foreground_payload))
        if self._caps.get("power_state"):
            with contextlib.suppress(SSAPError):
                await client.subscribe(URI_POWER_STATE, fenced(self._apply_power_payload))
        # LG's second-screen text protocol requires a remote-keyboard
        # registration subscription before insertText. Some apps accept
        # insertText without it, but YouTube silently ignores the request.
        with contextlib.suppress(SSAPError):
            await self._ensure_remote_keyboard(client)

    async def _ensure_remote_keyboard(self, client: SSAPClient) -> None:
        """Register this connection as the TV's active remote keyboard.

        The subscription is intentionally kept for the connection lifetime so
        it follows focus changes as the user opens or closes app text fields.
        Only the transient focused/not-focused bit is exposed; widget contents
        are never retained, persisted, logged, or returned.
        """
        if self._keyboard_client is client:
            return

        def apply_keyboard(payload: dict) -> None:
            if client is not self._client or not self._connected:
                return
            if self._apply_keyboard_payload(payload):
                self._mark_fresh()
                self._publish()

        await client.subscribe(URI_REGISTER_REMOTE_KEYBOARD, apply_keyboard)
        self._keyboard_client = client

    # -- state helpers ----------------------------------------------------------
    def _clear_keyboard_focus(self) -> bool:
        changed = self._keyboard_focused
        self._keyboard_focused = False
        if changed:
            self._keyboard_focus_seq += 1
        self._keyboard_focus_event.clear()
        return changed

    def _apply_keyboard_payload(self, p: dict) -> bool:
        widget = p.get("currentWidget")
        focused = bool(
            isinstance(widget, dict)
            and widget.get("focus") is True
        )
        changed = focused != self._keyboard_focused
        self._keyboard_focused = focused
        if changed:
            self._keyboard_focus_seq += 1
        if focused:
            self._keyboard_focus_event.set()
        else:
            self._keyboard_focus_event.clear()
        return changed

    def _apply_volume_payload(self, p: dict) -> None:
        status = p.get("volumeStatus") if isinstance(p.get("volumeStatus"), dict) else p
        vol = status.get("volume")
        mute = status.get("muteStatus", status.get("mute", status.get("muted")))
        if isinstance(vol, (int, float)):
            self._state["volume"] = int(vol)
        if isinstance(mute, bool):
            self._state["muted"] = mute

    def _apply_foreground_payload(self, p: dict) -> None:
        app_id = str(p.get("appId") or "")
        if app_id != self._state.get("app_id"):
            self._clear_keyboard_focus()
        self._state["app_id"] = app_id
        self._state["app_title"] = self._app_title(app_id) if app_id else ""

    def _apply_power_payload(self, p: dict) -> None:
        self._state["power"] = str(p.get("state") or "on").lower()
        self._power_confirmed = True  # only ever applied from a live connection

    def _apply_apps_payload(self, p: dict) -> None:
        apps = []
        for a in p.get("apps") or []:
            app_id = str(a.get("id") or "")
            title = str(a.get("title") or "").strip()
            if app_id and title and valid_app_id(app_id):
                apps.append({"id": app_id, "title": title[:80]})
        if apps:
            self._apps = apps
            self._apps_fresh = True
            if self._state.get("app_id"):
                self._state["app_title"] = self._app_title(self._state["app_id"])

    def _app_title(self, app_id: str) -> str:
        for app in self._apps:
            if app["id"] == app_id:
                return app["title"]
        return app_id

    def _publish(self) -> None:
        self._seq += 1  # every published change is observable + orderable
        with contextlib.suppress(Exception):
            self.bus.publish("tv", **self._public_state())

    def _schedule_state_write(self) -> None:
        with contextlib.suppress(RuntimeError):
            asyncio.get_running_loop().create_task(self._persist_state())

    async def _persist_state(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_state_write < STATE_WRITE_MIN_INTERVAL:
            return
        self._last_state_write = now
        blob = json.dumps({"state": self._state, "apps": self._apps})
        if self._connected:
            self._last_seen_at = _now_iso()
        await self.db.execute(
            "UPDATE lg_webos_devices SET last_state_json=?, last_seen_at=?, updated_at=? WHERE id=?",
            (blob, self._last_seen_at, _now_iso(), DEVICE_ID),
        )

    async def _persist_row(self) -> None:
        await self.db.execute(
            "INSERT INTO lg_webos_devices (id, name, host, mac_address, enabled, paired, last_state_json, last_seen_at, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, host=excluded.host, mac_address=excluded.mac_address, "
            "enabled=excluded.enabled, paired=excluded.paired, updated_at=excluded.updated_at",
            (
                DEVICE_ID,
                self.name,
                self.host,
                self._mac,
                1 if self.enabled else 0,
                1 if self.paired else 0,
                json.dumps({"state": self._state, "apps": self._apps}),
                self._last_seen_at,
                _now_iso(),
                _now_iso(),
            ),
        )

    # -- guarded command surface -------------------------------------------------
    def _require_enabled(self) -> None:
        if not self.enabled:
            raise WebOSTVError("TV control is turned off; enable it on the Devices page")

    def _require_connected(self) -> SSAPClient:
        self._require_enabled()
        if not self.paired:
            raise WebOSTVError("the TV isn't paired yet; pair it from the Devices page")
        if self._lifecycle == "powering_off":
            raise WebOSTVError("the TV is turning off; wait for it to finish (or wake it again)")
        client = self._client
        if client is None or not self._connected:
            if self._lifecycle == "powering_on":
                raise WebOSTVError("the TV is waking up; it will take commands as soon as it answers")
            if self._lifecycle in ("degraded", "connecting"):
                raise WebOSTVError("the TV is offline (reconnecting now); try again in a few seconds")
            hint = " You can try 'turn on the tv' to wake it." if self._mac else ""
            raise WebOSTVError(f"the TV is offline (off or unreachable).{hint}")
        return client

    @contextlib.asynccontextmanager
    async def _command(self, name: str):
        """The single ordered command path: every transport command (buttons,
        pointer presses, read-modify-write volume, text) runs alone, in
        arrival order, against the connection that was live when it started."""
        async with self._cmd_lock:
            self._busy = name
            try:
                yield
            finally:
                self._busy = ""

    async def _req(
        self, client: SSAPClient, uri: str, payload: dict | None = None, timeout: float | None = None
    ) -> dict:
        """One allowlisted request with every transport/TV failure translated
        into the integration's public error type. Nothing below WebOSTVError
        may escape the command surface -- callers (tools, dashboard, voice)
        only handle WebOSTVError.  A silent/lost socket additionally starts
        degraded recovery immediately instead of waiting for the next poll."""
        try:
            result = await client.request(uri, payload, timeout=timeout or self._command_timeout)
        except SSAPNotSupported:
            self._mark_fresh_if(client)  # a 404 is still an answer
            err = WebOSTVError("the TV doesn't support that command")
            err.answered = True
            raise err from None
        except SSAPError as exc:
            err = WebOSTVError(str(exc))
            # Preserve the "this message embeds TV-supplied text" marker so
            # sensitive operations (text entry) can sanitize their failures.
            err.device_detail = getattr(exc, "device_detail", False)
            # "answered" = the TV replied (even with an error), so the
            # transport is alive; without it the socket is suspect.
            err.answered = err.device_detail
            if err.device_detail:
                self._mark_fresh_if(client)  # the TV answered, just with an error
            else:
                await self._suspect_transport(client)
            raise err from None
        self._mark_fresh_if(client)
        return result

    async def power_off(self) -> dict:
        async with self._command("power_off"):
            client = self._require_connected()
            await self._req(client, URI_TURN_OFF)
            if self._client is client:
                # optimistic until the socket closes or a probe agrees
                self._state["power"] = "off"
                self._power_confirmed = False
                self._begin_transition("powering_off", self._off_window)
                self._schedule_state_write()
        return {"message": "TV turning off."}

    async def power_on(self) -> dict:
        # Deliberately outside the command lock: waking must work even while
        # another command is stuck on a dying socket, and WoL needs no
        # transport.  A WebSocket can remain alive briefly after turn-off, so
        # transport connectivity alone is not proof the panel is powered on.
        self._require_enabled()
        power = str(self._state.get("power", "")).strip().lower()
        if self._connected and self._lifecycle == "ready" and power in _POWER_ON_VALUES:
            return {"message": "The TV is already on."}
        if not self._mac:
            raise WebOSTVError(
                "power-on needs the TV's MAC address for Wake-on-LAN; add it on the Devices page"
            )
        try:
            await self._wol_sender(self._mac, self.host)
        except WoLError as exc:
            raise WebOSTVError(str(exc)) from None
        except OSError:
            # a raw socket error may still escape an injected sender; it is
            # the same ordinary network failure, so same safe error type
            raise WebOSTVError("could not send the wake signal on this network") from None
        await self.db.log("INFO", "lg_tv", "wake signal sent to the TV")
        if self.enabled and self.paired and self.host:
            # bounded eager reconnect: controls come back the moment the TV
            # answers, and the window settles honestly if it never does
            if self._loop_task is None or self._loop_task.done():
                self._spawn_loop()
            self._begin_transition("powering_on", self._wake_window)
            self._retry_now.set()
        return {
            "message": (
                "Wake signal sent. If the TV supports network standby it should turn on "
                "within a few seconds; otherwise use the TV remote."
            )
        }

    async def set_volume(self, percentage=None, delta=None) -> dict:
        if percentage is None and delta is None:
            raise WebOSTVError("provide a volume level or a change amount")
        if percentage is not None:
            try:
                target = clamp_volume(percentage)
            except (TypeError, ValueError):
                raise WebOSTVError("the volume level must be a number between 0 and 100") from None
        else:
            try:
                step = int(delta)
            except (TypeError, ValueError):
                raise WebOSTVError("volume change must be a number") from None
        async with self._command("volume"):
            client = self._require_connected()
            if percentage is None:
                # read-modify-write ordered by the command lock, against the
                # TV's actual current volume -- never a stale cached value
                payload = await self._req(client, URI_GET_VOLUME)
                status = payload.get("volumeStatus") if isinstance(payload.get("volumeStatus"), dict) else payload
                vol = status.get("volume")
                if not isinstance(vol, (int, float)):
                    raise WebOSTVError("could not read the current TV volume")
                target = max(0, min(100, int(vol) + step))
            await self._req(client, URI_SET_VOLUME, {"volume": target})
            if self._client is client:
                self._state["volume"] = target
                self._publish()
        return {"volume": target}

    async def set_mute(self, muted: bool) -> dict:
        async with self._command("mute"):
            client = self._require_connected()
            await self._req(client, URI_SET_MUTE, {"mute": bool(muted)})
            if self._client is client:
                self._state["muted"] = bool(muted)
                self._publish()
        return {"muted": bool(muted)}

    async def media(self, action: str) -> dict:
        uri = MEDIA_ACTIONS.get(str(action or "").strip().lower())
        if uri is None:
            allowed = ", ".join(sorted(MEDIA_ACTIONS))
            raise WebOSTVError(f"media action must be one of: {allowed}")
        async with self._command("media"):
            client = self._require_connected()
            await self._req(client, uri)
        return {"action": action}

    async def button(self, name: str) -> dict:
        key = str(name or "").strip().lower().replace(" ", "_")
        if key not in BUTTONS:
            allowed = ", ".join(sorted(BUTTONS))
            raise WebOSTVError(f"button must be one of: {allowed}")
        async with self._command("button"):
            client = self._require_connected()
            await self._button_on_client(client, key)
        return {"pressed": key}

    async def _button_on_client(self, client: SSAPClient, key: str) -> None:
        try:
            await client.button(key, timeout=self._command_timeout)
        except SSAPError as exc:
            if not getattr(exc, "device_detail", False):
                await self._suspect_transport(client)
            raise WebOSTVError(str(exc)) from None
        self._mark_fresh_if(client)

    @staticmethod
    def _clean_tv_text(text: str) -> str:
        if not isinstance(text, str):
            raise WebOSTVError("TV text must be a string")
        cleaned = text.strip()
        if not cleaned:
            raise WebOSTVError("there is no text to type")
        if len(cleaned) > TEXT_MAX_CHARS:
            raise WebOSTVError(
                f"TV text is limited to {TEXT_MAX_CHARS} characters"
            )
        if any(ord(ch) < 32 or ord(ch) == 127 for ch in cleaned):
            raise WebOSTVError(
                "TV text cannot contain line breaks or control characters"
            )
        return cleaned

    async def _await_keyboard_focus(
        self,
        client: SSAPClient,
        timeout: float | None = None,
        after_seq: int | None = None,
    ) -> int:
        await self._register_keyboard_on_client(client)
        deadline = time.monotonic() + (
            self._keyboard_focus_wait if timeout is None else timeout
        )
        while not (
            self._keyboard_focused
            and (after_seq is None or self._keyboard_focus_seq > after_seq)
        ):
            self._keyboard_focus_event.clear()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise WebOSTVError(
                    "open Search on the TV and select its text box, then try typing again"
                )
            try:
                await asyncio.wait_for(
                    self._keyboard_focus_event.wait(),
                    timeout=remaining,
                )
            except asyncio.TimeoutError:
                raise WebOSTVError(
                    "open Search on the TV and select its text box, then try typing again"
                ) from None
        if client is not self._client or not self._connected:
            raise WebOSTVError("the TV disconnected before text could be typed")
        if not self._keyboard_focused:
            raise WebOSTVError(
                "the TV text box lost focus; select it and try typing again"
            )
        return self._keyboard_focus_seq

    async def _register_keyboard_on_client(self, client: SSAPClient) -> None:
        try:
            await self._ensure_remote_keyboard(client)
        except SSAPError as exc:
            if not getattr(exc, "device_detail", False):
                await self._suspect_transport(client)
            raise WebOSTVError(
                "the TV rejected the text input; nothing may have been typed"
            ) from None

    async def _type_text_on_client(
        self,
        client: SSAPClient,
        cleaned: str,
        submit: bool,
        focus_timeout: float | None = None,
        focus_after_seq: int | None = None,
    ) -> None:
        focus_seq = await self._await_keyboard_focus(
            client,
            timeout=focus_timeout,
            after_seq=focus_after_seq,
        )
        try:
            await self._req(client, URI_INSERT_TEXT, {"text": cleaned, "replace": 0})
            if submit:
                if (
                    client is not self._client
                    or not self._connected
                    or not self._keyboard_focused
                    or self._keyboard_focus_seq != focus_seq
                ):
                    raise WebOSTVError(
                        "text may have been typed, but the TV text box lost focus "
                        "before Enter; Enter was not sent"
                    )
                await self._req(client, URI_SEND_ENTER)
        except WebOSTVError as exc:
            low = str(exc).lower()
            if "permission" in low or "401" in low or "insufficient" in low:
                # TVs paired before keyboard permission was requested must be
                # re-paired once so the user can approve the extra permission.
                raise WebOSTVError(
                    "the TV refused text input -- remove the pairing on the "
                    "Devices page and pair again to grant keyboard access"
                ) from None
            if getattr(exc, "device_detail", False):
                # The TV's own error text could echo what was typed; text-entry
                # failures must always use fixed wording (never device detail).
                raise WebOSTVError(
                    "the TV rejected the text input; nothing may have been typed"
                ) from None
            raise  # local, fixed-wording errors (offline, unsupported, ...)

    async def type_text(self, text: str, submit: bool = False) -> dict:
        """Type into the TV's currently focused text widget.

        Bounds: plain printable text only, hard length cap, no control
        characters. The text itself is never logged, persisted, or echoed.
        """
        cleaned = self._clean_tv_text(text)
        async with self._command("type_text"):
            client = self._require_connected()
            await self._type_text_on_client(client, cleaned, bool(submit))
        return {"typed": len(cleaned), "submitted": bool(submit)}

    async def list_inputs(self) -> dict:
        self._require_connected()
        if not self._caps.get("inputs", True):
            raise WebOSTVError("this TV does not report its inputs")
        return {"inputs": list(self._inputs)}

    async def set_input(self, query: str) -> dict:
        needle = " ".join(str(query or "").lower().split())
        if not needle:
            raise WebOSTVError("say which input, e.g. 'HDMI 1'")
        async with self._command("input"):
            client = self._require_connected()
            if not self._inputs:
                # Lazy cache fill goes through _req like every other command:
                # a silent/dead socket must raise the real transport error and
                # start degraded recovery, not masquerade as "no inputs".
                try:
                    payload = await self._req(client, URI_INPUT_LIST)
                except WebOSTVError as exc:
                    if not getattr(exc, "answered", False):
                        raise  # transport failure: recovery already started
                    payload = None  # the TV answered but cannot list inputs
                if payload is not None and self._client is client:
                    self._inputs = [
                        {"id": str(d.get("id") or ""), "label": str(d.get("label") or d.get("id") or "")[:60]}
                        for d in (payload.get("devices") or [])
                        if d.get("id")
                    ]
            if not self._inputs:
                raise WebOSTVError("this TV does not report switchable inputs")
            compact = needle.replace(" ", "").replace("-", "_")
            matches = [
                i for i in self._inputs
                if needle == i["label"].lower()
                or compact == i["id"].lower()
                or needle in i["label"].lower()
                or compact in i["id"].lower().replace("-", "_")
            ]
            if not matches:
                labels = ", ".join(i["label"] for i in self._inputs[:8])
                raise WebOSTVError(f"no input matches '{query}'. Available: {labels}")
            if len(matches) > 1:
                labels = ", ".join(i["label"] for i in matches[:8])
                raise WebOSTVError(f"'{query}' matches several inputs: {labels}")
            await self._req(client, URI_SWITCH_INPUT, {"inputId": matches[0]["id"]})
        return {"input": matches[0]["label"]}

    # -- installed apps ------------------------------------------------------------
    async def refresh_apps(self) -> dict:
        async with self._command("refresh_apps"):
            client = self._require_connected()
            payload = await self._req(client, URI_LIST_APPS)
            if self._client is client:
                self._apply_apps_payload(payload)
                await self._persist_state(force=True)
                self._publish()
        return {"count": len(self._apps)}

    def search_apps(self, query: str = "", limit: int = 12) -> dict:
        """Search the cached installed-app list (works offline, marked stale)."""
        self._require_enabled()
        apps = list(self._apps)
        if not apps:
            raise WebOSTVError(
                "no app list from the TV yet; connect to the TV once to load its apps"
            )
        needle = " ".join(str(query or "").lower().split())
        if needle:
            exact = [a for a in apps if a["title"].lower() == needle]
            contains = [a for a in apps if needle in a["title"].lower() and a not in exact]
            close_titles = difflib.get_close_matches(
                needle, [a["title"].lower() for a in apps], n=limit, cutoff=0.6
            )
            fuzzy = [
                a for a in apps
                if a["title"].lower() in close_titles and a not in exact and a not in contains
            ]
            apps = (exact + contains + fuzzy)[: max(1, min(int(limit), 30))]
        else:
            apps = sorted(apps, key=lambda a: a["title"].lower())[: max(1, min(int(limit), 30))]
        return {"apps": apps, "stale": not self._apps_fresh, "installed_count": len(self._apps)}

    def _resolve_app(self, query: str) -> dict:
        needle = " ".join(str(query or "").lower().split())
        if not needle:
            raise WebOSTVError("say which app to open")
        if not self._apps:
            raise WebOSTVError("no app list from the TV yet; try again once the TV is connected")
        exact = [a for a in self._apps if a["title"].lower() == needle]
        if len(exact) == 1:
            return exact[0]
        by_id = [a for a in self._apps if a["id"].lower() == needle]
        if len(by_id) == 1:
            return by_id[0]
        contains = [a for a in self._apps if needle in a["title"].lower()]
        if len(contains) == 1:
            return contains[0]
        if len(contains) > 1:
            titles = ", ".join(a["title"] for a in contains[:6])
            raise WebOSTVError(f"'{query}' matches several TV apps: {titles}. Be more specific.")
        close = difflib.get_close_matches(needle, [a["title"].lower() for a in self._apps], n=3, cutoff=0.75)
        if len(close) == 1:
            for a in self._apps:
                if a["title"].lower() == close[0]:
                    return a
        hints = difflib.get_close_matches(needle, [a["title"] for a in self._apps], n=3, cutoff=0.4)
        hint = f" Did you mean: {', '.join(hints)}?" if hints else ""
        raise WebOSTVError(f"'{query}' isn't installed on the TV.{hint}")

    async def launch_app(self, query: str) -> dict:
        app = self._resolve_app(query)
        if not valid_app_id(app["id"]):
            raise WebOSTVError("that app has an invalid identifier")
        async with self._command("launch"):
            client = self._require_connected()
            await self._req(client, URI_LAUNCH_APP, {"id": app["id"]})
            if self._client is client:
                self._state["app_id"] = app["id"]
                self._state["app_title"] = app["title"]
                self._publish()
        return {"launched": app["title"]}

    async def search_content(self, app_query: str, text: str) -> dict:
        """Open YouTube/Netflix, reach its search keyboard, type, and submit.

        Those third-party apps publish no stable search URI. This deliberately
        uses one short allowlisted navigation sequence and treats the TV's live
        remote-keyboard focus event as the success condition. It stops without
        sending the query if an app update changes that path.
        """
        app = self._resolve_app(app_query)
        identity = f"{app['title']} {app['id']}".lower()
        if "youtube" in identity:
            app_kind = "YouTube"
        elif "netflix" in identity:
            app_kind = "Netflix"
        else:
            raise WebOSTVError("automatic TV search is available only for YouTube or Netflix")
        if not valid_app_id(app["id"]):
            raise WebOSTVError("that app has an invalid identifier")
        cleaned = self._clean_tv_text(text)

        async with self._command("search_content"):
            client = self._require_connected()
            # A focus bit from before this launch is never proof that the
            # requested app's Search keyboard is active.
            self._clear_keyboard_focus()
            focus_baseline = self._keyboard_focus_seq
            await self._req(client, URI_LAUNCH_APP, {"id": app["id"]})

            deadline = time.monotonic() + self._app_launch_wait
            confirmed = False
            while time.monotonic() < deadline:
                if client is not self._client or not self._connected:
                    raise WebOSTVError(f"the TV disconnected while opening {app_kind}")
                remaining = max(0.05, deadline - time.monotonic())
                payload = await self._req(
                    client,
                    URI_FOREGROUND_APP,
                    timeout=min(self._command_timeout, remaining),
                )
                previous = self._state.get("app_id")
                self._apply_foreground_payload(payload)
                if self._state.get("app_id") != previous:
                    self._publish()
                if self._state.get("app_id") == app["id"]:
                    confirmed = True
                    break
                await asyncio.sleep(min(0.2, remaining))
            if not confirmed:
                raise WebOSTVError(
                    f"the TV did not confirm that {app_kind} opened, so nothing was typed"
                )

            await self._register_keyboard_on_client(client)
            if self._app_ready_pause:
                await asyncio.sleep(self._app_ready_pause)

            # Both TV apps expose Search at the top of their left navigation.
            # Repeated Up presses are harmless at the top. Stop the instant the
            # TV reports its full-screen keyboard/text widget has focus.
            sequence = ("left",) + ("up",) * 8 + ("ok",)
            for key in sequence:
                if (
                    self._keyboard_focused
                    and self._keyboard_focus_seq > focus_baseline
                ):
                    break
                await self._button_on_client(client, key)
                try:
                    await asyncio.wait_for(
                        self._keyboard_focus_event.wait(),
                        timeout=self._app_nav_step_wait,
                    )
                except asyncio.TimeoutError:
                    pass

            try:
                await self._type_text_on_client(
                    client,
                    cleaned,
                    True,
                    focus_timeout=self._keyboard_focus_wait,
                    focus_after_seq=focus_baseline,
                )
            except WebOSTVError as exc:
                if "open Search" in str(exc):
                    raise WebOSTVError(
                        f"{app_kind} did not open its search keyboard; its TV layout may have changed"
                    ) from None
                raise
        return {
            "app": app_kind,
            "searched": len(cleaned),
            "submitted": True,
            "message": f"Searched {app_kind} on the TV.",
        }

    # -- health refresh ------------------------------------------------------------
    async def refresh(self) -> dict:
        """A real health/reconnect attempt (the dashboard's Refresh button).

        Connected: run the bounded health probe right now, so a silent socket
        is detected and torn down before this returns.  Disconnected: cut the
        reconnect backoff short and briefly wait for the attempt to land.
        Always returns a fresh snapshot -- never raises for an offline TV."""
        if not (self.enabled and self.paired and self.host):
            return self.snapshot()
        client = self._client
        if self._connected and client is not None:
            if await self._health_probe(client, self._generation):
                return self.snapshot()
            await self._trigger_degrade(client, "the TV stopped answering; reconnecting")
        if self._loop_task is None or self._loop_task.done():
            # no connection owner alive (should not happen) -- heal by spawning
            await self._close_client()
            self._spawn_loop()
        else:
            self._retry_now.set()
        deadline = time.monotonic() + self._refresh_wait
        while time.monotonic() < deadline:
            if self._connected and self._lifecycle == "ready":
                break
            if not (self.enabled and self.paired):
                break  # unpaired mid-wait (stored key rejected)
            await asyncio.sleep(0.05)
        return self.snapshot()

    # -- read-only views ----------------------------------------------------------
    def status(self) -> dict:
        """Compact status for voice/typed answers.  Never includes secrets."""
        if not self.enabled:
            return {"enabled": False, "message": "TV control is turned off."}
        if not self.paired:
            return {"enabled": True, "paired": False, "message": "The TV isn't paired yet."}
        if not self._connected:
            if self._lifecycle == "powering_on":
                msg = "A wake signal was sent; the TV should come online shortly."
            elif self._lifecycle in ("degraded", "connecting"):
                msg = "The TV is not answering right now; reconnecting to it."
            else:
                msg = "The TV is offline (off or unreachable)."
                if self._mac:
                    msg += " Say 'turn on the tv' to try waking it."
            return {"enabled": True, "paired": True, "connected": False, "message": msg}
        out = {
            "enabled": True,
            "paired": True,
            "connected": True,
            "power": self._state.get("power", "on"),
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or self._state.get("app_id") or "",
            "name": self.name,
        }
        if self._lifecycle == "powering_off":
            out["message"] = "The TV is turning off."
        if self._state.get("model"):
            out["model"] = self._state["model"]
        return out

    def _lifecycle_public(self) -> str:
        if not self.enabled:
            return "disabled"
        if not self.paired:
            return "unpaired"
        if self._lifecycle in ("disabled", "unpaired"):
            return "offline"
        return self._lifecycle

    def _can_command(self) -> bool:
        """True only when the command transport is genuinely usable now."""
        return bool(self._connected and self._client is not None and self._lifecycle == "ready")

    def _public_state(self) -> dict:
        return {
            "enabled": self.enabled,
            "paired": self.paired,
            "connected": self._connected,
            "lifecycle": self._lifecycle_public(),
            "seq": self._seq,
            "power": self._state.get("power", ""),
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or "",
            "keyboard": {"focused": bool(self._connected and self._keyboard_focused)},
            "pairing": self._pairing_status,
        }

    def snapshot(self) -> dict:
        """Full dashboard view.  The MAC and pairing key are never included."""
        now = time.monotonic()
        fresh = None
        if self._connected and self._last_ok:
            fresh = max(0.0, round(now - self._last_ok, 1))
        recovery = None
        if (
            self.enabled and self.paired and self.host and not self._connected
            and self._lifecycle in ("connecting", "degraded", "offline", "powering_on")
        ):
            retry_in = max(0.0, round(self._next_retry_at - now, 1)) if self._next_retry_at else 0.0
            recovery = {"attempt": self._recovery_attempt, "retry_in": retry_in}
        transition = None
        if self._transition_deadline and self._lifecycle in ("powering_on", "powering_off"):
            transition = max(0.0, round(self._transition_deadline - now, 1))
        return {
            "enabled": self.enabled,
            "configured": bool(self.host),
            "host": self.host,
            "name": self.name,
            "paired": self.paired,
            "connected": self._connected,
            "lifecycle": self._lifecycle_public(),
            "seq": self._seq,
            "can_command": self._can_command(),
            "busy": self._busy or None,
            "pairing": {"status": self._pairing_status, "error": self._pairing_error},
            "power": self._state.get("power", ""),
            "power_confirmed": self._power_confirmed,
            "volume": self._state.get("volume"),
            "muted": self._state.get("muted"),
            "app": self._state.get("app_title") or "",
            "keyboard": {"focused": bool(self._connected and self._keyboard_focused)},
            "model": self._state.get("model", ""),
            "app_count": len(self._apps),
            "apps_stale": not self._apps_fresh,
            "inputs": list(self._inputs),
            "wol_ready": bool(self._mac),
            "last_error": self._last_error,
            "last_seen_at": self._last_seen_at,
            "fresh_seconds": fresh,
            "recovery": recovery,
            "transition_remaining": transition,
        }
