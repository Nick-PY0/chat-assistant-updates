"""Small adapter for the official YouTube Data API v3.

Only the fixed ``search`` and ``videos`` resources are called.  Playback is
performed by the browser's official IFrame Player; this module never downloads
video/audio data and never follows a user-supplied URL.
"""

from __future__ import annotations

import html
import re
from urllib.parse import parse_qs, urlparse

import httpx


SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"
VIDEOS_URL = "https://www.googleapis.com/youtube/v3/videos"
MAX_QUERY_CHARS = 160
MAX_RESULTS = 10
_VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
_YOUTUBE_HOSTS = {
    "youtube.com",
    "www.youtube.com",
    "m.youtube.com",
    "music.youtube.com",
    "youtu.be",
    "www.youtu.be",
}


class YouTubeAPIError(Exception):
    """Safe provider failure that may be shown to the user."""

    def __init__(self, message: str, code: str = "unavailable") -> None:
        super().__init__(message)
        self.code = code


def extract_video_id(value: object) -> str:
    """Return a strictly validated YouTube video id from an id or URL."""
    text = str(value or "").strip()
    if _VIDEO_ID_RE.fullmatch(text):
        return text
    if not text or len(text) > 1000 or any(ch.isspace() for ch in text):
        raise YouTubeAPIError("a valid YouTube video link or video ID is required", "invalid_video")

    # Accept convenient pasted links without a scheme, but still require an
    # exact official hostname after parsing.
    lowered = text.lower()
    if lowered.startswith(("youtube.com/", "www.youtube.com/", "m.youtube.com/", "music.youtube.com/", "youtu.be/", "www.youtu.be/")):
        text = "https://" + text
    try:
        parsed = urlparse(text)
        hostname = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port
    except ValueError as exc:
        raise YouTubeAPIError("that YouTube link is malformed", "invalid_video") from exc
    if parsed.scheme not in ("http", "https") or hostname not in _YOUTUBE_HOSTS:
        raise YouTubeAPIError("only official youtube.com or youtu.be video links are allowed", "invalid_video")
    if parsed.username or parsed.password or port not in (None, 80, 443):
        raise YouTubeAPIError("that YouTube link is malformed", "invalid_video")

    candidate = ""
    parts = [part for part in parsed.path.split("/") if part]
    if hostname in ("youtu.be", "www.youtu.be"):
        candidate = parts[0] if len(parts) == 1 else ""
    elif parsed.path.rstrip("/") == "/watch":
        values = parse_qs(parsed.query).get("v", [])
        candidate = values[0] if len(values) == 1 else ""
    elif len(parts) == 2 and parts[0] in ("embed", "shorts", "live"):
        candidate = parts[1]
    if not _VIDEO_ID_RE.fullmatch(candidate):
        raise YouTubeAPIError("that link does not contain a valid YouTube video ID", "invalid_video")
    return candidate


def canonical_video_url(value: object) -> str:
    return f"https://www.youtube.com/watch?v={extract_video_id(value)}"


def _clean(value: object, limit: int) -> str:
    return " ".join(html.unescape(str(value or "")).split())[:limit]


class YouTubeClient:
    """Official API client. The API key is held in memory for one request."""

    def __init__(
        self,
        api_key: str,
        timeout: float = 10.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._api_key = api_key
        self.timeout = timeout
        self.transport = transport

    async def _get(self, url: str, params: dict[str, str]) -> dict:
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                transport=self.transport,
                follow_redirects=False,
                headers={"User-Agent": "ChatAssistant/1.7 (+official YouTube API)"},
            ) as client:
                response = await client.get(url, params={**params, "key": self._api_key})
        except httpx.HTTPError as exc:
            raise YouTubeAPIError("YouTube search is temporarily unavailable") from exc

        if response.status_code >= 400:
            reason = ""
            try:
                errors = response.json().get("error", {}).get("errors", [])
                if errors:
                    reason = str(errors[0].get("reason", ""))
            except (ValueError, AttributeError, TypeError):
                pass
            if reason in {"keyInvalid", "accessNotConfigured", "ipRefererBlocked"}:
                raise YouTubeAPIError(
                    "YouTube rejected this API key or the YouTube Data API v3 is not enabled for it",
                    "invalid_key",
                )
            if reason in {"quotaExceeded", "dailyLimitExceeded", "rateLimitExceeded"}:
                raise YouTubeAPIError("the YouTube search quota is currently exhausted", "quota")
            raise YouTubeAPIError("YouTube search is temporarily unavailable")
        try:
            payload = response.json()
        except ValueError as exc:
            raise YouTubeAPIError("YouTube returned an unreadable response") from exc
        if not isinstance(payload, dict):
            raise YouTubeAPIError("YouTube returned an unreadable response")
        return payload

    async def validate_key(self) -> None:
        # videos.list is a minimal validation request and avoids consuming a
        # search-query operation just to check whether the key is usable.
        await self._get(
            VIDEOS_URL,
            {"part": "id", "id": "dQw4w9WgXcQ", "maxResults": "1"},
        )

    async def search(self, query: object, max_results: object = 5) -> list[dict[str, str]]:
        clean_query = " ".join(str(query or "").split()).strip()
        if not clean_query:
            raise YouTubeAPIError("a YouTube search query is required", "invalid_query")
        if len(clean_query) > MAX_QUERY_CHARS:
            raise YouTubeAPIError(
                f"YouTube searches can be at most {MAX_QUERY_CHARS} characters",
                "invalid_query",
            )
        try:
            limit = max(1, min(MAX_RESULTS, int(max_results)))
        except (TypeError, ValueError):
            limit = 5

        payload = await self._get(
            SEARCH_URL,
            {
                "part": "snippet",
                "type": "video",
                "videoEmbeddable": "true",
                "videoSyndicated": "true",
                "safeSearch": "moderate",
                "maxResults": str(limit),
                "q": clean_query,
            },
        )
        results: list[dict[str, str]] = []
        seen: set[str] = set()
        for item in payload.get("items", []):
            if not isinstance(item, dict):
                continue
            raw_id = item.get("id", {})
            video_id = raw_id.get("videoId", "") if isinstance(raw_id, dict) else ""
            if not _VIDEO_ID_RE.fullmatch(str(video_id)) or video_id in seen:
                continue
            seen.add(video_id)
            snippet = item.get("snippet", {})
            if not isinstance(snippet, dict):
                snippet = {}
            results.append(
                {
                    "video_id": video_id,
                    "title": _clean(snippet.get("title"), 240) or "YouTube video",
                    "channel": _clean(snippet.get("channelTitle"), 160),
                    "published": _clean(snippet.get("publishedAt"), 80),
                    "url": canonical_video_url(video_id),
                    "thumbnail": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
                }
            )
        if not results:
            raise YouTubeAPIError("no playable YouTube videos were found", "not_found")
        return results
