"""Official, read-only YouTube Data API integration."""

from .client import (
    YouTubeAPIError,
    YouTubeClient,
    canonical_video_url,
    extract_video_id,
)

__all__ = [
    "YouTubeAPIError",
    "YouTubeClient",
    "canonical_video_url",
    "extract_video_id",
]
