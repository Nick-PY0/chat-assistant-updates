from __future__ import annotations

import httpx
import pytest

from apps.tool_service.local_grammar import parse
from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from apps.tool_service.youtube_tool import YouTubeTool
from integrations.youtube import YouTubeAPIError, YouTubeClient, extract_video_id


VIDEO_A = "dQw4w9WgXcQ"
VIDEO_B = "aqz-KE-bpKQ"


@pytest.mark.parametrize(
    "value",
    [
        VIDEO_A,
        f"https://www.youtube.com/watch?v={VIDEO_A}",
        f"https://youtu.be/{VIDEO_A}",
        f"youtube.com/shorts/{VIDEO_A}",
        f"https://music.youtube.com/watch?v={VIDEO_A}&list=abc",
        f"https://www.youtube.com/embed/{VIDEO_A}",
    ],
)
def test_extract_video_id_accepts_only_supported_official_shapes(value):
    assert extract_video_id(value) == VIDEO_A


@pytest.mark.parametrize(
    "value",
    [
        "short",
        f"https://youtube.example/watch?v={VIDEO_A}",
        f"https://evil.youtube.com/watch?v={VIDEO_A}",
        f"https://youtube.com.evil.example/watch?v={VIDEO_A}",
        f"https://www.youtube.com/@channel/{VIDEO_A}",
        f"https://www.youtube.com/watch?v={VIDEO_A}&v={VIDEO_B}",
        f"https://youtu.be/{VIDEO_A}/extra",
    ],
)
def test_extract_video_id_rejects_non_video_or_lookalike_links(value):
    with pytest.raises(YouTubeAPIError):
        extract_video_id(value)


@pytest.mark.asyncio
async def test_official_search_uses_fixed_api_and_returns_validated_ids():
    async def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url.copy_with(query=None)) == "https://www.googleapis.com/youtube/v3/search"
        assert request.url.params["key"] == "top-secret-key"
        assert request.url.params["type"] == "video"
        assert request.url.params["videoEmbeddable"] == "true"
        return httpx.Response(
            200,
            json={
                "items": [
                    {
                        "id": {"videoId": VIDEO_A},
                        "snippet": {
                            "title": "Song &amp; official video",
                            "channelTitle": "Artist",
                            "publishedAt": "2024-01-02T03:04:05Z",
                        },
                    },
                    {"id": {"videoId": "invalid"}, "snippet": {"title": "bad"}},
                ]
            },
        )

    client = YouTubeClient("top-secret-key", transport=httpx.MockTransport(handler))
    results = await client.search("artist song", 3)
    assert results == [
        {
            "video_id": VIDEO_A,
            "title": "Song & official video",
            "channel": "Artist",
            "published": "2024-01-02T03:04:05Z",
            "url": f"https://www.youtube.com/watch?v={VIDEO_A}",
            "thumbnail": f"https://i.ytimg.com/vi/{VIDEO_A}/hqdefault.jpg",
        }
    ]


@pytest.mark.asyncio
async def test_api_errors_never_echo_secret():
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            403,
            json={"error": {"errors": [{"reason": "keyInvalid"}]}},
        )

    secret = "private-youtube-key"
    client = YouTubeClient(secret, transport=httpx.MockTransport(handler))
    with pytest.raises(YouTubeAPIError) as caught:
        await client.search("anything")
    assert caught.value.code == "invalid_key"
    assert secret not in str(caught.value)


class FakeYouTubeClient:
    def __init__(self, secret):
        assert secret == "youtube-test-key"

    async def search(self, query, max_results):
        assert query == "test song"
        return [
            {"video_id": VIDEO_A, "title": "First", "channel": "Channel A"},
            {"video_id": VIDEO_B, "title": "Second", "channel": "Channel B"},
        ]


@pytest.mark.asyncio
async def test_tool_search_queue_control_and_single_player_lease(db, bus, store):
    await store.add("youtube", "youtube-test-key")
    playing: list[bool] = []
    youtube = YouTubeTool(
        bus, store, client_factory=FakeYouTubeClient, on_playing=playing.append
    )
    tools = ToolService(
        db, bus, TimerManager(db, bus), store, youtube=youtube
    )
    events = bus.subscribe("media_control")

    found = await tools.dispatch("", "search_youtube", {"query": "test song"})
    assert [item["video_id"] for item in found["results"]] == [VIDEO_A, VIDEO_B]

    queued = await tools.dispatch("", "play_youtube", {"video": VIDEO_A})
    assert queued["player_needed"] is True
    first_event = events.get_nowait()
    assert first_event.data["target_id"] == ""

    owner = youtube.claim("browser_12345678", "Phone")
    assert owner["owner"] is True
    rebound = events.get_nowait()
    assert rebound.data["target_id"] == "browser_12345678"
    assert youtube.claim("browser_87654321", "Laptop")["owner"] is False
    assert youtube.claim("browser_87654321", "Laptop", force=True)["owner"] is True

    youtube.report("browser_87654321", {
        "status": "playing", "video_id": VIDEO_A, "position_seconds": 10,
    })
    assert playing[-1] is True
    youtube._owner_seen -= 60
    assert youtube.snapshot()["player_connected"] is False
    assert playing[-1] is False
    seeked = await tools.dispatch("", "seek_youtube", {"offset_seconds": -4})
    assert seeked["position_seconds"] == 6
    paused = await tools.dispatch("", "pause_youtube", {})
    assert paused["status"] == "paused"
    assert playing[-1] is False
    advanced = await tools.dispatch("", "next_youtube", {})
    assert advanced["video_id"] == VIDEO_B


@pytest.mark.asyncio
async def test_search_needs_key_but_direct_video_does_not(db, bus, store):
    youtube = YouTubeTool(bus, store)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=youtube)
    search = await tools.dispatch("", "search_youtube", {"query": "a song"})
    assert "Data API v3 key" in search["error"]
    direct = await tools.dispatch("", "play_youtube", {"video": VIDEO_A})
    assert direct["queued"] is True


@pytest.mark.asyncio
async def test_search_falls_back_to_validated_web_index_results(db, bus, store):
    async def web_search(query, max_results):
        assert query == "site:youtube.com/watch?v= indexed song"
        assert max_results == 8
        return {
            "results": [
                {"title": "A song — indexed version", "url": f"https://www.youtube.com/watch?v={VIDEO_A}"},
                {"title": "Lookalike", "url": f"https://youtube.example/watch?v={VIDEO_B}"},
                {"title": "Indexed song — second version", "url": f"https://youtu.be/{VIDEO_B}"},
            ]
        }

    youtube = YouTubeTool(bus, store, web_search=web_search)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=youtube)
    found = await tools.dispatch("", "search_youtube", {"query": "indexed song", "max_results": 4})
    assert [item["video_id"] for item in found["results"]] == [VIDEO_A, VIDEO_B]
    assert "key-free" in found["notice"]


def test_youtube_tool_schemas_are_shared_with_all_brains():
    names = {declaration["name"] for declaration in TOOL_DECLARATIONS}
    assert {
        "search_youtube", "play_youtube", "pause_youtube", "stop_youtube",
        "seek_youtube", "next_youtube", "previous_youtube",
    } <= names


@pytest.mark.parametrize(
    ("utterance", "tool", "args"),
    [
        ("pause the music", "pause_youtube", {}),
        ("resume video", "play_youtube", {}),
        ("stop the song", "stop_youtube", {}),
        ("next song", "next_youtube", {}),
        ("previous video", "previous_youtube", {}),
        ("rewind 30 seconds", "seek_youtube", {"offset_seconds": -30}),
        ("go back two minutes", "seek_youtube", {"offset_seconds": -120}),
        ("skip ahead 45 seconds", "seek_youtube", {"offset_seconds": 45}),
        ("Jarvis, go forward one minute", "seek_youtube", {"offset_seconds": 60}),
    ],
)
def test_local_media_controls_are_specific_and_offline(utterance, tool, args):
    assert parse(utterance) == {"tool": tool, "args": args}


def test_bare_stop_stays_general_not_media_stop():
    assert parse("stop") == {"tool": "stop_output", "args": {}}
    assert parse("stop the timer") is None


# ---------------------------------------------------------------------------
# Canonical result selection (_pick_best_result)
# ---------------------------------------------------------------------------

def test_pick_best_prefers_official_over_generic():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [
        {"video_id": VIDEO_A, "title": "Song Title (lyrics)", "channel": "SomeChannel"},
        {"video_id": VIDEO_B, "title": "Song Title (official video)", "channel": "ArtistVEVO"},
    ]
    best = _pick_best_result(results, "song title")
    assert best is not None
    assert best["video_id"] == VIDEO_B


def test_pick_best_penalises_slowed_unless_requested():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [
        {"video_id": VIDEO_A, "title": "Song slowed reverb", "channel": "SomeChannel"},
        {"video_id": VIDEO_B, "title": "Song (official audio)", "channel": "Artist"},
    ]
    best = _pick_best_result(results, "song")
    assert best is not None
    assert best["video_id"] == VIDEO_B


def test_pick_best_allows_slowed_when_requested():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [
        {"video_id": VIDEO_A, "title": "Song slowed reverb", "channel": "SomeChannel"},
        {"video_id": VIDEO_B, "title": "Song (official audio)", "channel": "Artist"},
    ]
    best = _pick_best_result(results, "song slowed")
    # when query contains 'slowed', the slowed result is not penalised;
    # may still lose to official but must not be excluded purely on that term
    assert best is not None  # some result is returned


def test_pick_best_penalises_lyrics_unless_requested():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [
        {"video_id": VIDEO_A, "title": "Song - lyrics", "channel": "LyricsChannel"},
        {"video_id": VIDEO_B, "title": "Song - official music video", "channel": "Artist"},
    ]
    best = _pick_best_result(results, "song")
    assert best is not None
    assert best["video_id"] == VIDEO_B


def test_pick_best_penalises_cover_unless_requested():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [
        {"video_id": VIDEO_A, "title": "Song (cover)", "channel": "CoverChannel"},
        {"video_id": VIDEO_B, "title": "Song", "channel": "Artist"},
    ]
    best = _pick_best_result(results, "song")
    assert best is not None
    assert best["video_id"] == VIDEO_B


def test_pick_best_returns_none_for_empty_list():
    from apps.tool_service.youtube_tool import _pick_best_result
    assert _pick_best_result([], "anything") is None


def test_pick_best_single_result_returned_regardless():
    from apps.tool_service.youtube_tool import _pick_best_result
    results = [{"video_id": VIDEO_A, "title": "Song - lyric video", "channel": "x"}]
    best = _pick_best_result(results, "song")
    assert best is not None
    assert best["video_id"] == VIDEO_A


# ---------------------------------------------------------------------------
# play_url — normalises YouTube URL to video_id; never calls webbrowser.open
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_play_url_accepts_watch_url(bus, store):
    yt = YouTubeTool(bus, store)
    result = yt.play_url(f"https://www.youtube.com/watch?v={VIDEO_A}")
    assert result["queued"] is True
    assert result["video_id"] == VIDEO_A


@pytest.mark.asyncio
async def test_play_url_accepts_youtu_be(bus, store):
    yt = YouTubeTool(bus, store)
    result = yt.play_url(f"https://youtu.be/{VIDEO_A}")
    assert result["video_id"] == VIDEO_A


@pytest.mark.asyncio
async def test_play_url_rejects_non_youtube_host(bus, store):
    from apps.tool_service.youtube_tool import YouTubeError
    yt = YouTubeTool(bus, store)
    with pytest.raises(YouTubeError, match="[Yy]ou[Tt]ube|non-YouTube|host|domain|URL"):
        yt.play_url("https://vimeo.com/12345")


@pytest.mark.asyncio
async def test_play_url_rejects_empty(bus, store):
    from apps.tool_service.youtube_tool import YouTubeError
    yt = YouTubeTool(bus, store)
    with pytest.raises(YouTubeError):
        yt.play_url("")


# ---------------------------------------------------------------------------
# play_query — search + canonical selection + auto-play; no browser open
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_play_query_routes_through_youtube_tool_not_browser(db, bus, store):
    """play_youtube with query must use YouTubeTool.play_query, never webbrowser.open."""
    import apps.tool_service.media_tool as mt
    from unittest.mock import patch

    browser_calls: list[str] = []

    async def fake_web_search(query, max_results):
        # Return a valid YouTube watch URL with a title matching the query words
        return {
            "results": [
                {
                    "title": "Blinding Lights Weeknd official",
                    "url": f"https://www.youtube.com/watch?v={VIDEO_A}",
                },
            ]
        }

    youtube = YouTubeTool(bus, store, web_search=fake_web_search)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=youtube)

    with patch.object(mt, "_open_browser_real", side_effect=lambda u: browser_calls.append(u)):
        result = await tools.dispatch("", "play_youtube", {"query": "Blinding Lights Weeknd"})

    assert len(browser_calls) == 0, "webbrowser.open must NOT be called when youtube is wired"
    assert result.get("queued") is True
    assert result.get("video_id") == VIDEO_A


@pytest.mark.asyncio
async def test_play_query_url_routes_through_youtube_tool_not_browser(db, bus, store):
    """play_youtube with a YouTube URL must use YouTubeTool.play_url, never webbrowser.open."""
    import apps.tool_service.media_tool as mt
    from unittest.mock import patch

    browser_calls: list[str] = []

    youtube = YouTubeTool(bus, store)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=youtube)

    with patch.object(mt, "_open_browser_real", side_effect=lambda u: browser_calls.append(u)):
        result = await tools.dispatch(
            "", "play_youtube",
            {"url": f"https://www.youtube.com/watch?v={VIDEO_A}"},
        )

    assert len(browser_calls) == 0, "webbrowser.open must NOT be called when youtube is wired"
    assert result.get("queued") is True
    assert result.get("video_id") == VIDEO_A


@pytest.mark.asyncio
async def test_play_youtube_non_youtube_url_returns_error_not_browser(db, bus, store):
    """Non-YouTube URL must yield an error dict, never open a browser."""
    import apps.tool_service.media_tool as mt
    from unittest.mock import patch

    browser_calls: list[str] = []

    youtube = YouTubeTool(bus, store)
    tools = ToolService(db, bus, TimerManager(db, bus), store, youtube=youtube)

    with patch.object(mt, "_open_browser_real", side_effect=lambda u: browser_calls.append(u)):
        result = await tools.dispatch(
            "", "play_youtube",
            {"url": "https://vimeo.com/42"},
        )

    assert len(browser_calls) == 0
    assert "error" in result


@pytest.mark.asyncio
async def test_play_youtube_without_youtube_tool_returns_error_never_browser(db, bus, store):
    """When no YouTubeTool is wired, ALL play_youtube variants return error; no browser."""
    import apps.tool_service.media_tool as mt
    from unittest.mock import patch

    browser_calls: list[str] = []
    tools = ToolService(db, bus, TimerManager(db, bus), store)  # no youtube=

    with patch.object(mt, "_open_browser_real", side_effect=lambda u: browser_calls.append(u)):
        for args in [
            {"query": "some song"},
            {"url": f"https://www.youtube.com/watch?v={VIDEO_A}"},
            {"video": VIDEO_A},
            {"video_id": VIDEO_A},
        ]:
            result = await tools.dispatch("", "play_youtube", args)
            assert "error" in result, f"Expected error for args={args}, got {result}"

    assert len(browser_calls) == 0, "webbrowser.open must NEVER be called from play_youtube dispatch"
