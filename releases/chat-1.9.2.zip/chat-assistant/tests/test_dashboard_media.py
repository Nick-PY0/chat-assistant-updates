from __future__ import annotations

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime


VIDEO_ID = "dQw4w9WgXcQ"


@pytest.fixture
async def media_rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def media_client(media_rt):
    app = create_app(media_rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
        client.app = app
        response = await client.post(
            "/setup", data={"password": "media-password-123", "confirm": "media-password-123"}
        )
        assert response.status_code == 303
        yield client


def _csrf(client) -> str:
    return client.app.state.sessions.csrf_for(client.cookies.get(COOKIE))


@pytest.mark.asyncio
async def test_authenticated_media_state_control_and_single_owner(media_client, media_rt):
    csrf = _csrf(media_client)
    headers = {"x-csrf": csrf}

    response = await media_client.post(
        "/api/media/control",
        json={"action": "play", "video_id": VIDEO_ID, "title": "Test video"},
        headers=headers,
    )
    assert response.status_code == 200
    assert response.json()["player_needed"] is True

    state = await media_client.get("/api/media")
    assert state.status_code == 200
    assert state.json()["video_id"] == VIDEO_ID

    owner = await media_client.post(
        "/api/media/claim",
        json={"client_id": "phone_12345678", "label": "Phone"},
        headers=headers,
    )
    assert owner.json()["owner"] is True
    assert owner.json()["command"]["target_id"] == "phone_12345678"

    viewer = await media_client.post(
        "/api/media/claim",
        json={"client_id": "laptop_12345678", "label": "Laptop"},
        headers=headers,
    )
    assert viewer.json()["owner"] is False

    report = await media_client.post(
        "/api/media/state",
        json={
            "client_id": "phone_12345678",
            "status": "playing",
            "video_id": VIDEO_ID,
            "position_seconds": 12.5,
        },
        headers=headers,
    )
    assert report.status_code == 200
    assert media_rt.media_playing is True

    paused = await media_client.post(
        "/api/media/control", json={"action": "pause"}, headers=headers
    )
    assert paused.status_code == 200
    assert media_rt.media_playing is False

    takeover = await media_client.post(
        "/api/media/claim",
        json={"client_id": "laptop_12345678", "label": "Laptop", "force": True},
        headers=headers,
    )
    assert takeover.json()["owner"] is True
    stale = await media_client.post(
        "/api/media/state",
        json={"client_id": "phone_12345678", "status": "playing"},
        headers=headers,
    )
    assert stale.status_code == 409


@pytest.mark.asyncio
async def test_media_writes_require_csrf(media_client):
    response = await media_client.post(
        "/api/media/control", json={"action": "play", "video_id": VIDEO_ID}
    )
    assert response.status_code == 403


@pytest.mark.asyncio
async def test_youtube_key_is_validated_and_only_mask_is_returned(
    media_client, media_rt, monkeypatch
):
    class FakeClient:
        def __init__(self, secret):
            assert secret == "youtube-api-key-12345"

        async def validate_key(self):
            return None

    monkeypatch.setattr(dashboard_module, "YouTubeClient", FakeClient)
    response = await media_client.post(
        "/api/credentials",
        json={"provider": "youtube", "secret": "youtube-api-key-12345"},
        headers={"x-csrf": _csrf(media_client)},
    )
    assert response.status_code == 200
    assert "youtube-api-key-12345" not in response.text
    listing = await media_client.get("/api/credentials")
    assert "youtube-api-key-12345" not in listing.text
    assert len(listing.json()["youtube"]) == 1
    row = await media_rt.db.fetchone(
        "SELECT encrypted_secret FROM credentials WHERE provider='youtube'"
    )
    assert "youtube-api-key-12345" not in str(row["encrypted_secret"])
