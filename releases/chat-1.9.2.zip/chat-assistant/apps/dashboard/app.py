"""Dashboard + authenticated management API (FastAPI).

Security baseline honored:
  * LAN/local binding only (configurable), optional HTTPS via local cert
  * Argon2id password, signed HttpOnly SameSite cookies, CSRF, login rate limit
  * No plaintext secret ever leaves the server; adds are validated then
    encrypted; UI shows only masked suffixes
  * Live status over Server-Sent Events
"""

from __future__ import annotations

import asyncio
import json
import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, Form, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    StreamingResponse,
)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from chat_core.net import lan_ip
from chat_core.pcm import rms16
from chat_core.runtime import Runtime
from chat_core.config.settings import TYPED_CHAT_PROVIDERS, valid_model_id
from chat_core.models.state import ChatState
from chat_core.version import APP_VERSION
from chat_core.security.auth import (
    LoginRateLimiter,
    SessionManager,
    hash_password,
    verify_password,
)
from apps.audio.mic_gate import PlaybackAwareMicGate
from apps.tool_service.local_grammar import parse as parse_command
from apps.live_gateway.text_chat import TextChatError
from integrations.gemini.errors import GeminiFailure
from integrations.gemini.validator import validate_key
from integrations.govee.client import GoveeClient, GoveeError
from integrations.openai_rt.validator import validate_openai_key
from integrations.relay.client import RelayClient, RelayError
from integrations.weather import WeatherError
from integrations.youtube import YouTubeAPIError, YouTubeClient
from apps.tool_service.youtube_tool import YouTubeError

BASE_DIR = Path(__file__).resolve().parent
COOKIE = "chat_session"


@dataclass(slots=True)
class _RemoteMicLease:
    """One browser microphone's authority over one voice-session generation."""

    socket: WebSocket
    owner_generation: int
    voice_session_generation: int
    voice_end_generation: int
    previous_route: str
    revoked: bool = False


def create_app(rt: Runtime) -> FastAPI:
    app = FastAPI(title="Chat", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.remote_mic_owner = None
    app.state.remote_mic_generation = 0
    templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
    app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

    limiter = LoginRateLimiter(rt.settings.login_max_attempts, rt.settings.login_window_seconds)
    https_on = bool(rt.settings.ssl_certfile and rt.settings.ssl_keyfile)

    # session secret: env wins, else generated once and stored
    async def session_mgr() -> SessionManager:
        if not hasattr(app.state, "sessions"):
            import os
            secret = os.environ.get("SESSION_SECRET") or await rt.db.get_setting("session_secret")
            if not secret:
                secret = secrets.token_hex(32)
                await rt.db.set_setting("session_secret", secret)
            app.state.sessions = SessionManager(secret, rt.settings.session_max_age_days * 86400)
        return app.state.sessions

    # -- auth plumbing ---------------------------------------------------
    async def current_session(request: Request) -> dict | None:
        sm = await session_mgr()
        return sm.validate(request.cookies.get(COOKIE))

    async def require_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        if await current_session(request) is None:
            return RedirectResponse("/login", status_code=303)
        return None

    async def require_api(request: Request) -> JSONResponse | None:
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)
        if request.method in ("POST", "PUT", "DELETE"):
            sm = await session_mgr()
            token = request.cookies.get(COOKIE)
            csrf = request.headers.get("x-csrf") or (await _form_csrf(request))
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
        return None

    async def _form_csrf(request: Request) -> str | None:
        if request.headers.get("content-type", "").startswith("application/x-www-form-urlencoded"):
            form = await request.form()
            value = form.get("_csrf")
            return value if isinstance(value, str) else None
        return None

    def same_site_ok(request: Request) -> bool:
        """Cross-site protection for the pre-auth forms (/setup, /login),
        which cannot rely on session-bound CSRF tokens. A hostile web page
        form-posting to this dashboard sends Origin and/or Sec-Fetch-Site
        headers that give it away; same-origin posts and non-browser tools
        pass."""
        origin = request.headers.get("origin")
        if origin and origin != "null":
            if urlparse(origin).netloc != request.headers.get("host", ""):
                return False
        elif origin == "null":
            return False
        fetch_site = request.headers.get("sec-fetch-site")
        if fetch_site and fetch_site.lower() == "cross-site":
            return False
        return True

    def is_loopback(request: Request) -> bool:
        """True when the request comes from this computer itself. First-time
        setup is restricted to loopback so a LAN device can never claim the
        admin password before the owner does."""
        host = request.client.host if request.client else ""
        return host.startswith("127.") or host in ("::1", "localhost")

    _lan_cache = {"ts": 0.0, "ip": ""}

    def dashboard_urls() -> dict:
        """Local + LAN URLs for 'open this on your phone' hints (cached)."""
        now = time.monotonic()
        if now - _lan_cache["ts"] > 60:
            _lan_cache["ip"] = lan_ip()
            _lan_cache["ts"] = now
        scheme = "https" if https_on else "http"
        port = rt.settings.dashboard_port
        urls = {"local": f"{scheme}://127.0.0.1:{port}"}
        if rt.settings.dashboard_host in ("0.0.0.0", "::") and _lan_cache["ip"]:
            urls["lan"] = f"{scheme}://{_lan_cache['ip']}:{port}"
        return urls

    async def page_ctx(request: Request, active: str) -> dict:
        sm = await session_mgr()
        token = request.cookies.get(COOKIE) or ""
        from dataclasses import asdict

        settings_public = asdict(rt.settings)
        settings_public.pop("extra", None)
        # Escape </script> so a stored payload in any string field cannot
        # break out of the inline <script> block that injects settings_json.
        settings_json_safe = json.dumps(settings_public).replace(
            "</", "<\\/"
        )
        return {
            "request": request,
            "active": active,
            "csrf": sm.csrf_for(token) if token else "",
            "state": rt.state.snapshot(),
            "voice_ok": bool(rt.audio and rt.audio.voice_available),
            "voice_reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            "keychain_source": rt.master.source,
            "settings_json": settings_json_safe,
            "typed_chat_provider": rt.settings.typed_chat_provider,
            "typed_chat_model": (
                rt.settings.openai_text_model
                if rt.settings.typed_chat_provider == "openai"
                else rt.settings.relay_chat_model
            ),
            "app_version": APP_VERSION,
            "quiet": rt.quiet,
            "ringing": rt.ringing,
        }

    # -- public health identity endpoint (unauthenticated; no secrets) ------
    @app.get("/api/healthz")
    async def api_healthz():
        """Unauthenticated identity endpoint used to verify this process is
        Chat before acting on a port-in-use signal. No secrets are exposed."""
        from chat_core.version import APP_VERSION as _VER

        return {"app": "chat-assistant", "version": _VER}

    # -- one-time phone HTTPS setup ----------------------------------------
    def _ca_cert_fingerprint(path: Path) -> str | None:
        """Return the colon-separated SHA-256 fingerprint of a PEM certificate,
        or None if the file cannot be read or parsed."""
        try:
            from cryptography import x509 as _x509
            from cryptography.hazmat.primitives import hashes as _hashes

            data = path.read_bytes()
            cert = _x509.load_pem_x509_certificate(data)
            digest = cert.fingerprint(_hashes.SHA256())
            return ":".join(f"{b:02X}" for b in digest)
        except Exception:
            return None

    @app.get("/ca-cert.pem")
    async def public_ca_certificate(request: Request):
        """Serve the public CA certificate for download — loopback only.

        A LAN device must not be able to pull the file anonymously: the owner
        must download it on the Chat computer and transfer it out-of-band.
        The private CA key is never served under any circumstances.
        """
        if not is_loopback(request):
            return JSONResponse(
                {
                    "error": (
                        "The CA certificate may only be downloaded directly on the computer "
                        "running Chat. Open http://127.0.0.1:<port>/mobile-setup there, "
                        "download the file, verify the fingerprint, then transfer it to your "
                        "device via USB, AirDrop, or another trusted local method."
                    )
                },
                status_code=403,
            )
        path = rt.settings.data_path / "ca-cert.pem"
        if not path.is_file():
            return JSONResponse(
                {"error": "Run deployment/windows/make_cert.py, then restart Chat."},
                status_code=404,
            )
        return FileResponse(
            path,
            media_type="application/x-x509-ca-cert",
            filename="chat-assistant-local-ca.pem",
            headers={
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/mobile-setup", response_class=HTMLResponse)
    async def mobile_setup_page(request: Request):
        urls = dashboard_urls()
        ca_path = rt.settings.data_path / "ca-cert.pem"
        ca_ready = ca_path.is_file()
        fingerprint = _ca_cert_fingerprint(ca_path) if ca_ready else None
        return templates.TemplateResponse(
            request,
            "mobile_setup.html",
            {
                "request": request,
                "lan_url": urls.get("lan", ""),
                "ca_ready": ca_ready,
                "fingerprint": fingerprint,
                "is_loopback": is_loopback(request),
            },
        )

    # -- Windows startup (per-user, loopback-only) -------------------------
    @app.get("/api/startup/status")
    async def api_startup_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        from deployment.windows.startup_helper import _get_status  # noqa: PLC0415

        return _get_status()

    @app.post("/api/startup/enable")
    async def api_startup_enable(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Startup settings may only be changed from the computer running Chat."},
                status_code=403,
            )
        from deployment.windows.startup_helper import enable as _enable  # noqa: PLC0415

        rc = _enable()
        if rc != 0:
            return JSONResponse({"error": "Failed to enable startup entry."}, status_code=500)
        return {"ok": True, "enabled": True}

    @app.post("/api/startup/disable")
    async def api_startup_disable(request: Request):
        err = await require_api(request)
        if err:
            return err
        if not is_loopback(request):
            return JSONResponse(
                {"error": "Startup settings may only be changed from the computer running Chat."},
                status_code=403,
            )
        from deployment.windows.startup_helper import disable as _disable  # noqa: PLC0415

        rc = _disable()
        if rc != 0:
            return JSONResponse({"error": "Failed to disable startup entry."}, status_code=500)
        return {"ok": True, "enabled": False}

    # -- setup & login -----------------------------------------------------
    @app.get("/setup", response_class=HTMLResponse)
    async def setup_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if not is_loopback(request):
            return HTMLResponse(
                "<p>First-time setup happens on the computer running Chat itself. "
                "Open the dashboard there (the console window shows the address), "
                "create the password, then sign in from this device.</p>",
                status_code=403,
            )
        return templates.TemplateResponse(request, "setup.html", {"request": request, "error": ""})

    @app.post("/setup")
    async def setup_submit(request: Request, password: str = Form(...), confirm: str = Form(...)):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        if not is_loopback(request):
            return JSONResponse(
                {"error": "first-time setup is only allowed on the computer running Chat"},
                status_code=403,
            )
        if await rt.db.get_setting("admin_password_hash") is not None:
            return RedirectResponse("/login", status_code=303)
        if len(password) < 8:
            return templates.TemplateResponse(
                request, "setup.html",
                {"request": request, "error": "Password must be at least 8 characters."},
            )
        if password != confirm:
            return templates.TemplateResponse(
                request, "setup.html", {"request": request, "error": "Passwords do not match."}
            )
        await rt.db.set_setting("admin_password_hash", hash_password(password))
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(
            COOKIE, sm.issue(), max_age=sm.max_age, httponly=True,
            samesite="strict", secure=https_on,
        )
        await rt.db.log("INFO", "dashboard", "admin password set")
        return resp

    @app.get("/login", response_class=HTMLResponse)
    async def login_page(request: Request):
        if await rt.db.get_setting("admin_password_hash") is None:
            return RedirectResponse("/setup", status_code=303)
        return templates.TemplateResponse(request, "login.html", {"request": request, "error": ""})

    @app.post("/login")
    async def login_submit(request: Request, password: str = Form(...)):
        if not same_site_ok(request):
            return JSONResponse({"error": "cross-site request rejected"}, status_code=403)
        ip = request.client.host if request.client else "unknown"
        if not limiter.check(ip):
            return templates.TemplateResponse(
                request, "login.html",
                {"request": request, "error": f"Too many attempts. Try again in {limiter.retry_in(ip) // 60 + 1} min."},
                status_code=429,
            )
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, password):
            limiter.record_failure(ip)
            await rt.db.log("WARNING", "dashboard", f"failed login from {ip}")
            return templates.TemplateResponse(
                request, "login.html", {"request": request, "error": "Wrong password."}, status_code=401
            )
        limiter.reset(ip)
        sm = await session_mgr()
        resp = RedirectResponse("/", status_code=303)
        resp.set_cookie(
            COOKIE, sm.issue(), max_age=sm.max_age, httponly=True,
            samesite="strict", secure=https_on,
        )
        return resp

    @app.post("/logout")
    async def logout(request: Request):
        sm = await session_mgr()
        token = request.cookies.get(COOKIE)
        if sm.validate(token) is not None:
            csrf = await _form_csrf(request)
            if not sm.csrf_ok(token, csrf):
                return JSONResponse({"error": "bad csrf token"}, status_code=403)
        resp = RedirectResponse("/login", status_code=303)
        resp.delete_cookie(COOKIE)
        return resp

    # -- pages ------------------------------------------------------------
    def page(route: str, template: str, name: str):
        @app.get(route, response_class=HTMLResponse, name=f"page_{name}")
        async def _page(request: Request):
            redirect = await require_page(request)
            if redirect:
                return redirect
            return templates.TemplateResponse(request, template, await page_ctx(request, name))
        return _page

    page("/", "status.html", "status")
    page("/chat", "chat.html", "chat")
    page("/media", "media.html", "media")
    page("/credentials", "credentials.html", "credentials")
    page("/providers", "providers.html", "providers")
    page("/usage", "usage.html", "usage")
    page("/devices", "devices.html", "devices")
    page("/timers", "timers.html", "timers")
    page("/reminders", "reminders.html", "reminders")
    page("/memory", "memory.html", "memory")
    page("/logs", "logs.html", "logs")
    page("/settings", "settings.html", "settings")
    page("/transcripts", "transcripts.html", "transcripts")

    # -- dedicated voice controller popup (owns remote-audio lease) ----------
    @app.get("/voice-controller", response_class=HTMLResponse)
    async def voice_controller_page(request: Request):
        redirect = await require_page(request)
        if redirect:
            return redirect
        sm = await session_mgr()
        token = request.cookies.get(COOKIE) or ""
        return templates.TemplateResponse(
            request, "voice_controller.html",
            {
                "request": request,
                "csrf": sm.csrf_for(token) if token else "",
                "app_version": APP_VERSION,
            },
        )

    # -- live events (SSE) ---------------------------------------------------
    @app.get("/events")
    async def sse(request: Request):
        if await current_session(request) is None:
            return JSONResponse({"error": "unauthorized"}, status_code=401)

        async def stream():
            q = rt.bus.subscribe("*", maxsize=64)
            try:
                yield f"data: {json.dumps({'topic': 'state', **rt.state.snapshot()})}\n\n"
                while True:
                    try:
                        ev = await asyncio.wait_for(q.get(), timeout=25)
                        yield f"data: {json.dumps({'topic': ev.topic, **_jsonsafe(ev.data)})}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                rt.bus.unsubscribe(q)

        return StreamingResponse(stream(), media_type="text/event-stream")

    # -- state & health APIs ---------------------------------------------
    @app.get("/api/state")
    async def api_state(request: Request):
        err = await require_api(request)
        if err:
            return err
        health = await rt.db.fetchall("SELECT * FROM health ORDER BY component")
        eligible = 0
        if rt.gateway:
            eligible = await rt.gateway.rotation.eligible_count()
        retry_at = await rt.db.get_setting("quota_retry_at")
        return {
            "state": rt.state.snapshot(),
            "health": [dict(h) for h in health],
            "eligible_keys": eligible,
            "quota_retry_at": retry_at,
            "voice": {
                "available": bool(rt.audio and rt.audio.voice_available),
                "reason": rt.audio.unavailable_reason if rt.audio else "cloud disabled",
            },
            "keychain": rt.master.source,
            "uptime_seconds": int(time.time() - rt.started_at),
            "quiet": rt.quiet,
            "ringing": rt.ringing,
            "urls": dashboard_urls(),
        }

    # -- provider availability summary ------------------------------------
    @app.get("/api/providers/summary")
    async def api_providers_summary(request: Request):
        """Return safe (no secrets) availability status of every provider."""
        err = await require_api(request)
        if err:
            return err

        # Gemini keys
        creds = await rt.store.list()
        gemini_all = [c for c in creds if c.provider == "gemini"]
        gemini_eligible = 0
        if rt.gateway:
            gemini_eligible = await rt.gateway.rotation.eligible_count()
        gemini_failure = None
        for c in gemini_all:
            if c.failure_code:
                gemini_failure = c.failure_code
                break

        # OpenAI live
        openai_creds = [c for c in creds if c.provider == "openai"]
        openai_configured = bool(openai_creds)

        # Relay
        relay_creds = [c for c in creds if c.provider == "relay"]
        relay_url = (rt.settings.relay_url or "").strip()
        relay_configured = bool(relay_creds and relay_url)

        # Voice pipeline
        voice_available = bool(rt.audio and rt.audio.voice_available)
        voice_reason = (rt.audio.unavailable_reason if rt.audio else "cloud disabled") or ""

        # Typed chat provider
        typed_provider = rt.settings.typed_chat_provider
        typed_model = (
            rt.settings.openai_text_model
            if typed_provider == "openai"
            else rt.settings.relay_chat_model
        )

        # Remote mic lease (is any device currently connected?)
        remote_mic_active = app.state.remote_mic_owner is not None

        # Media player
        media_available = rt.youtube_tools is not None

        return {
            "gemini": {
                "total_keys": len(gemini_all),
                "eligible_keys": gemini_eligible,
                "failure_reason": gemini_failure,
                "ok": gemini_eligible > 0,
            },
            "openai_live": {
                "configured": openai_configured,
                "ok": openai_configured,
            },
            "relay": {
                "configured": relay_configured,
                "address": relay_url if relay_url else None,
                "ok": relay_configured,
            },
            "voice_pipeline": {
                "available": voice_available,
                "reason": voice_reason,
                "ok": voice_available,
            },
            "typed_chat": {
                "provider": typed_provider,
                "model": typed_model,
                "ok": bool(
                    (typed_provider == "openai" and openai_configured)
                    or (typed_provider == "relay" and relay_configured)
                ),
            },
            "remote_mic": {
                "active": remote_mic_active,
            },
            "media_player": {
                "available": media_available,
                "ok": media_available,
            },
        }

    # -- selected-device YouTube player -----------------------------------
    @app.get("/api/media")
    async def api_media(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        return rt.youtube_tools.snapshot()

    @app.post("/api/media/claim")
    async def api_media_claim(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.claim(
                body.get("client_id"), body.get("label", ""), force=bool(body.get("force"))
            )
        except YouTubeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/media/release")
    async def api_media_release(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.release(body.get("client_id"))
        except YouTubeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/media/search")
    async def api_media_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "search_youtube", {
                "query": str(body.get("query", ""))[:160],
                "max_results": body.get("max_results", 5),
            }
        )
        return JSONResponse(result, status_code=400 if "error" in result else 200)

    @app.post("/api/media/control")
    async def api_media_control(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", "")).strip().lower()
        tool = {
            "play": "play_youtube",
            "resume": "play_youtube",
            "pause": "pause_youtube",
            "stop": "stop_youtube",
            "seek": "seek_youtube",
            "next": "next_youtube",
            "previous": "previous_youtube",
        }.get(action)
        if tool is None:
            return JSONResponse({"error": "unknown media action"}, status_code=400)
        args = {
            "video": body.get("video") or body.get("video_id") or "",
            "title": body.get("title", ""),
            "offset_seconds": body.get("offset_seconds"),
        }
        result = await rt.tools.dispatch("", tool, args)
        return JSONResponse(result, status_code=400 if "error" in result else 200)

    @app.post("/api/media/state")
    async def api_media_report(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.youtube_tools is None:
            return JSONResponse({"error": "media controls are unavailable"}, status_code=503)
        body = await request.json()
        try:
            return rt.youtube_tools.report(body.get("client_id"), body)
        except (YouTubeError, YouTubeAPIError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)

    # -- credentials -------------------------------------------------------
    @app.get("/api/credentials")
    async def api_credentials(request: Request):
        err = await require_api(request)
        if err:
            return err
        creds = await rt.store.list()
        groups: dict[str, dict] = {}
        for c in creds:
            if c.provider != "gemini":
                continue
            g = groups.setdefault(
                c.project_fingerprint,
                {"fingerprint": c.project_fingerprint, "label": c.project_label or "Ungrouped key", "keys": [], "exhausted_until": None},
            )
            g["keys"].append(c.public())
            if c.status == "exhausted" and c.retry_after:
                cur = g["exhausted_until"]
                iso_ra = c.retry_after.isoformat()
                g["exhausted_until"] = max(cur, iso_ra) if cur else iso_ra
        govee = [c.public() for c in creds if c.provider == "govee"]
        youtube_keys = [c.public() for c in creds if c.provider == "youtube"]
        openai_keys = [c.public() for c in creds if c.provider == "openai"]
        relay_keys = [c.public() for c in creds if c.provider == "relay"]
        return {"projects": list(groups.values()), "govee": govee,
                "youtube": youtube_keys,
                "openai": openai_keys, "relay": relay_keys}

    @app.post("/api/credentials")
    async def api_add_credential(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        provider = str(body.get("provider", "gemini")).lower()
        secret = str(body.get("secret", "")).strip()
        label = str(body.get("project_label", "")).strip()[:60]
        if provider not in ("gemini", "govee", "openai", "relay", "youtube"):
            return JSONResponse({"error": "unsupported provider"}, status_code=400)
        if len(secret) < 8 or len(secret) > 300 or any(ch.isspace() for ch in secret):
            return JSONResponse({"error": "that doesn't look like a valid key"}, status_code=400)

        warning = ""
        if provider == "gemini":
            try:
                await validate_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "Google rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "govee":
            try:
                await GoveeClient(secret).list_devices()
            except GoveeError as exc:
                if "rejected" in str(exc):
                    return JSONResponse({"error": "Govee rejected this key."}, status_code=400)
                warning = "saved without live validation (Govee unreachable)"
        elif provider == "openai":
            try:
                await validate_openai_key(secret)
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    return JSONResponse({"error": "OpenAI rejected this key (invalid)."}, status_code=400)
                warning = f"saved without live validation ({failure.code})"
        elif provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if relay_url:
                try:
                    await RelayClient(relay_url, secret).health()
                except RelayError as exc:
                    if "password" in str(exc):
                        return JSONResponse({"error": str(exc)}, status_code=400)
                    warning = f"saved without live validation ({exc})"
            else:
                warning = ("saved; set the relay address in Settings -> Brain "
                           "so it can be checked")
        elif provider == "youtube":
            try:
                await YouTubeClient(secret).validate_key()
            except YouTubeAPIError as exc:
                if exc.code == "invalid_key":
                    return JSONResponse({"error": str(exc)}, status_code=400)
                warning = f"saved without live validation ({exc})"

        cred = await rt.store.add(provider, secret, project_label=label)
        if provider in ("gemini", "youtube") and not warning:
            await rt.store.mark_validated(cred.id)
        rt.bus.publish("credentials_changed", added=cred.id)
        await rt.db.log("INFO", "credentials", f"added {provider} key {cred.masked_suffix}")
        # NOTE: the active connection is deliberately left untouched.
        return {"ok": True, "credential": cred.public(), "warning": warning}

    @app.post("/api/credentials/{cred_id}/action")
    async def api_credential_action(cred_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        action = str(body.get("action", ""))
        cred = await rt.store.get(cred_id)
        if cred is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        if action == "disable":
            await rt.store.set_status(cred_id, "disabled")
        elif action == "enable":
            await rt.store.set_status(cred_id, "standby")
        elif action == "make_active":
            if rt.gateway:
                await rt.gateway.rotation.promote(cred_id)
                rt.gateway.set_preferred(cred_id)
            else:
                await rt.store.set_status(cred_id, "active")
        elif action == "delete":
            await rt.store.remove(cred_id)
        elif action == "validate" and cred.provider == "gemini":
            try:
                await validate_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "openai":
            try:
                await validate_openai_key(await rt.store.get_secret(cred_id))
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except GeminiFailure as failure:
                if failure.code == "invalid":
                    await rt.store.set_status(cred_id, "invalid", failure.code)
                return {"ok": False, "result": failure.code}
        elif action == "validate" and cred.provider == "relay":
            relay_url = (rt.settings.relay_url or "").strip()
            if not relay_url:
                return {"ok": False, "result": "set the relay address in Settings -> Brain first"}
            try:
                await RelayClient(relay_url, await rt.store.get_secret(cred_id)).health()
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except RelayError as exc:
                if "password" in str(exc):
                    await rt.store.set_status(cred_id, "invalid", "invalid")
                return {"ok": False, "result": str(exc)}
        elif action == "validate" and cred.provider == "youtube":
            try:
                await YouTubeClient(await rt.store.get_secret(cred_id)).validate_key()
                await rt.store.mark_validated(cred_id)
                if cred.status == "invalid":
                    await rt.store.set_status(cred_id, "standby")
            except YouTubeAPIError as exc:
                if exc.code == "invalid_key":
                    await rt.store.set_status(cred_id, "invalid", "invalid")
                return {"ok": False, "result": str(exc)}
        else:
            return JSONResponse({"error": "unknown action"}, status_code=400)
        rt.bus.publish("credentials_changed", id=cred_id, action=action)
        await rt.db.log("INFO", "credentials", f"{action} on {cred.masked_suffix}")
        return {"ok": True}

    # -- timers ---------------------------------------------------------
    @app.get("/api/timers")
    async def api_timers(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {"timers": await rt.timers.list_timers()}

    @app.post("/api/timers")
    async def api_add_timer(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "start_timer",
            {"duration_seconds": body.get("duration_seconds"), "label": body.get("label", ""), "confirmed": True},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/timers/{timer_id}/{action}")
    async def api_timer_action(timer_id: str, action: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        if action not in ("cancel", "pause", "resume"):
            return JSONResponse({"error": "unknown action"}, status_code=400)
        result = await rt.tools.dispatch("", f"{action}_timer", {"timer_id": timer_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- reminders & alarms -------------------------------------------------
    @app.get("/api/reminders")
    async def api_reminders(request: Request):
        err = await require_api(request)
        if err:
            return err
        return {
            "reminders": await rt.reminders.list_reminders(include_recent=True),
            "ringing": rt.ringing,
        }

    @app.post("/api/reminders")
    async def api_add_reminder(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        time_str = str(body.get("time", "")).strip()   # "HH:MM", 24h
        date_str = str(body.get("date", "")).strip()   # optional "YYYY-MM-DD"
        try:
            hh, mm = (int(x) for x in time_str.split(":")[:2])
            if not (0 <= hh <= 23 and 0 <= mm <= 59):
                raise ValueError
        except ValueError:
            return JSONResponse({"error": "pick a time first"}, status_code=400)
        if date_str:
            at_local = f"{date_str}T{hh:02d}:{mm:02d}"
        else:
            now = datetime.now().astimezone()
            local = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            if local <= now:
                local += timedelta(days=1)  # next time the clock shows it
            at_local = local.strftime("%Y-%m-%dT%H:%M")
        result = await rt.tools.dispatch(
            "", "set_reminder",
            {"message": str(body.get("message", "")),
             "kind": str(body.get("kind", "reminder")), "at_local": at_local},
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/reminders/dismiss")
    async def api_dismiss_ring(request: Request):
        """Stop a ringing alarm/reminder and clear the persisted ring state.
        Idempotent: safe to call even when nothing is ringing."""
        err = await require_api(request)
        if err:
            return err
        dismissed = await rt.dismiss_ring()
        return {"ok": True, "dismissed": dismissed}

    @app.post("/api/reminders/snooze")
    async def api_snooze_ring(request: Request):
        """Snooze the currently ringing alarm/reminder.

        Optional JSON body: {"minutes": N}  (default: 10 minutes).
        The snooze deadline is persisted to DB so a restart resumes the wait.
        Idempotent: returns ok=True even if nothing is currently ringing."""
        err = await require_api(request)
        if err:
            return err
        body: dict = {}
        try:
            body = await request.json()
        except Exception:
            pass
        minutes = body.get("minutes")
        if minutes is not None:
            try:
                minutes = int(minutes)
            except (TypeError, ValueError):
                return JSONResponse({"error": "minutes must be an integer"}, status_code=400)
        snoozed = await rt.snooze_ring(minutes=minutes)
        return {"ok": True, "snoozed": snoozed}

    @app.post("/api/reminders/{reminder_id}/cancel")
    async def api_cancel_reminder(reminder_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        result = await rt.tools.dispatch("", "cancel_reminder", {"ref": reminder_id})
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    # -- weather & quiet mode -------------------------------------------------
    @app.get("/api/weather")
    async def api_weather(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            return await rt.weather_tool.get(str(request.query_params.get("day", "today")))
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.get("/api/location/search")
    async def api_location_search(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            results = await rt.weather_tool.client.geocode(str(request.query_params.get("q", "")))
            return {"results": results}
        except WeatherError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/quiet")
    async def api_quiet(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_quiet(bool(body.get("quiet")))
        return {"ok": True, "quiet": rt.quiet}

    # -- devices -----------------------------------------------------------
    @app.get("/api/devices")
    async def api_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        try:
            devices = await rt.tools.devices(refresh=bool(request.query_params.get("refresh")))
            return {"devices": devices}
        except GoveeError as exc:
            return {"devices": [], "error": str(exc)}

    # -- local command box -------------------------------------------------
    @app.post("/api/command")
    async def api_command(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        text = str(body.get("text", ""))[:200]
        cmd = parse_command(text)
        if cmd is None:
            return JSONResponse(
                {"error": "Not in the local grammar. Try: 'set a timer for ten minutes'."},
                status_code=400,
            )
        result = await rt.tools.dispatch("", cmd["tool"], cmd["args"])
        return {"command": cmd, "result": result}

    # -- typed chat -------------------------------------------------------
    @app.get("/api/chat/conversations")
    async def api_chat_conversations(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        try:
            limit = int(request.query_params.get("limit", "100"))
        except ValueError:
            limit = 100
        return {"conversations": await rt.text_chat.list_conversations(limit)}

    @app.post("/api/chat/conversations")
    async def api_chat_conversation_create(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        body = await request.json()
        try:
            conversation = await rt.text_chat.create_conversation(str(body.get("title", "")))
            return JSONResponse({"conversation": conversation}, status_code=201)
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.get("/api/chat/conversations/{conversation_id}")
    async def api_chat_conversation_get(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        conversation = await rt.text_chat.get_conversation(conversation_id)
        if conversation is None:
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"conversation": conversation}

    @app.post("/api/chat/conversations/{conversation_id}/rename")
    async def api_chat_conversation_rename(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        body = await request.json()
        try:
            conversation = await rt.text_chat.rename_conversation(
                conversation_id, str(body.get("title", ""))
            )
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        if conversation is None:
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"conversation": conversation}

    @app.delete("/api/chat/conversations/{conversation_id}")
    async def api_chat_conversation_delete(request: Request, conversation_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        if not await rt.text_chat.delete_conversation(conversation_id):
            return JSONResponse({"error": "conversation not found"}, status_code=404)
        return {"ok": True}

    async def _start_chat_turn(request: Request, forced_conversation_id: str | None = None):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)

        attachments = []
        try:
            content_type = request.headers.get("content-type", "").lower()
            if content_type.startswith("multipart/form-data"):
                # Reject a clearly oversized body before the multipart parser
                # spools it. Chunked bodies are still bounded while each file
                # is read below and again by the service's total-size check.
                try:
                    content_length = int(request.headers.get("content-length", "0") or 0)
                except ValueError:
                    content_length = 0
                if content_length > 13 * 1024 * 1024:
                    return JSONResponse(
                        {"error": "Images in one message can total at most 12 MB."},
                        status_code=413,
                    )
                form = await request.form()
                text = str(form.get("text", ""))
                conversation_id = (
                    forced_conversation_id or str(form.get("conversation_id", "")) or None
                )
                request_id = str(form.get("request_id", "")) or request.headers.get("idempotency-key")
                uploads = [*form.getlist("images"), *form.getlist("image")]
                if len(uploads) > 4:
                    return JSONResponse(
                        {"error": "Attach at most four images to one message."},
                        status_code=400,
                    )
                raw_files = []
                total_image_bytes = 0
                for upload in uploads:
                    if not hasattr(upload, "read"):
                        continue
                    data = await upload.read(8 * 1024 * 1024 + 1)
                    total_image_bytes += len(data)
                    if total_image_bytes > 12 * 1024 * 1024:
                        return JSONResponse(
                            {"error": "Images in one message can total at most 12 MB."},
                            status_code=413,
                        )
                    raw_files.append((
                        str(getattr(upload, "filename", "") or "image"),
                        str(getattr(upload, "content_type", "") or ""),
                        data,
                    ))
                attachments = await rt.text_chat.store_attachments(raw_files)
            else:
                body = await request.json()
                text = str(body.get("text", ""))
                conversation_id = (
                    forced_conversation_id or str(body.get("conversation_id", "")) or None
                )
                request_id = str(body.get("request_id", "")) or request.headers.get("idempotency-key")

            turn = await rt.text_chat.start_turn(
                text, conversation_id, request_id, attachments
            )
            return JSONResponse(turn, status_code=202)
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/chat/turns")
    async def api_chat_turn_create(request: Request):
        return await _start_chat_turn(request)

    @app.post("/api/chat/conversations/{conversation_id}/turns")
    async def api_chat_conversation_turn_create(request: Request, conversation_id: str):
        return await _start_chat_turn(request, conversation_id)

    @app.get("/api/chat/conversations/{conversation_id}/turns/{request_id}")
    async def api_chat_turn_get(request: Request, conversation_id: str, request_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        turn = await rt.text_chat.get_turn(conversation_id, request_id)
        if turn is None:
            return JSONResponse({"error": "chat request not found"}, status_code=404)
        return turn

    @app.get("/api/chat/attachments/{attachment_id}")
    async def api_chat_attachment(request: Request, attachment_id: str):
        err = await require_api(request)
        if err:
            return err
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        found = await rt.text_chat.attachment_file(attachment_id)
        if found is None:
            return JSONResponse({"error": "image not found"}, status_code=404)
        path, mime_type = found
        return FileResponse(
            path,
            media_type=mime_type,
            headers={
                "Cache-Control": "private, max-age=3600",
                "Content-Disposition": "inline",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.post("/api/chat")
    async def api_chat(request: Request):
        """Compatibility endpoint; new clients use the durable turn API."""
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if rt.text_chat is None:
            return JSONResponse({"error": "typed chat is unavailable"}, status_code=503)
        try:
            return await rt.text_chat.ask(
                str(body.get("text", "")),
                str(body.get("conversation_id", "")) or None,
            )
        except TextChatError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    @app.post("/api/chat/reset")
    async def api_chat_reset(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        if rt.text_chat is not None:
            await rt.text_chat.clear(str(body.get("conversation_id", "")) or None)
        return {"ok": True}

    # -- usage & logs ---------------------------------------------------------
    @app.get("/api/usage")
    async def api_usage(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT u.ts, u.event, u.detail, c.masked_suffix, c.project_label "
            "FROM usage_log u LEFT JOIN credentials c ON c.id = u.credential_id "
            "ORDER BY u.id DESC LIMIT 200"
        )
        return {"usage": [dict(r) for r in rows]}

    @app.get("/api/logs")
    async def api_logs(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall("SELECT * FROM events_log ORDER BY id DESC LIMIT 300")
        return {"logs": [dict(r) for r in rows]}

    # -- settings & controls -----------------------------------------------
    @app.post("/api/mute")
    async def api_mute(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        await rt.set_muted(bool(body.get("muted")))
        return {"ok": True, "muted": rt.state.muted}

    @app.post("/api/settings")
    async def api_settings(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        editable = {
            "low_power": bool, "voice_enabled": bool, "wake_word_model": str,
            "wake_threshold": float, "inactivity_timeout_seconds": int,
            "gemini_model": str, "gemini_voice": str, "system_prompt": str,
            # brains
            "voice_brain": str, "openai_live_model": str, "openai_voice": str,
            "typed_chat_provider": str, "openai_text_model": str,
            "relay_url": str, "relay_chat_model": str, "relay_command_model": str,
            "relay_voice": str, "relay_daily_request_cap": int,
            "dashboard_host": str, "dashboard_port": int,
            "interrupt_rms_threshold": int,
            # audio routing, devices, offline voice
            "audio_output_route": str, "mic_device": str, "speaker_device": str,
            "vosk_model_path": str,
            # updates
            "update_url": str, "auto_update": bool,
            "update_require_signature": bool,
            # reminders, weather, quiet mode
            "alarm_ring_seconds": int, "alarm_volume": float,
            "quiet_override_alarms": bool, "weather_units": str,
            "location_name": str, "location_lat": float, "location_lon": float,
            # key rotation & quota behavior
            "rotation_enabled": bool, "rate_limit_rotate_after_failures": int,
            "unavailable_retry_seconds": int, "quota_reset_timezone": str,
            "quota_reset_jitter_seconds": int, "retry_window_backoff_seconds": int,
            # health checks
            "pulse_internet_interval": int, "pulse_govee_interval": int,
            "pulse_credential_interval": int, "pulse_timer_interval": int,
            "pulse_audio_idle_interval": int,
            # dashboard access
            "session_max_age_days": int, "login_max_attempts": int,
            "login_window_seconds": int, "log_level": str,
        }
        # 1) cast everything into a candidate dict — live settings untouched
        candidate: dict = {}
        for key, caster in editable.items():
            if key in body:
                try:
                    candidate[key] = caster(body[key])
                except (TypeError, ValueError):
                    return JSONResponse({"error": f"bad value for {key}"}, status_code=400)

        # 2) validate the candidate; a rejected save must change NOTHING
        if candidate.get("audio_output_route") not in (None, "speaker", "phone", "both"):
            candidate["audio_output_route"] = "speaker"
        if candidate.get("voice_brain") not in (None, "gemini", "openai_live", "relay"):
            candidate["voice_brain"] = "gemini"
        if "typed_chat_provider" in candidate:
            candidate["typed_chat_provider"] = str(candidate["typed_chat_provider"]).strip().lower()
            if candidate["typed_chat_provider"] not in TYPED_CHAT_PROVIDERS:
                return JSONResponse(
                    {"error": "typed chat provider must be openai or relay"},
                    status_code=400,
                )
        if "openai_text_model" in candidate:
            candidate["openai_text_model"] = str(candidate["openai_text_model"]).strip()
            if not valid_model_id(candidate["openai_text_model"]):
                return JSONResponse(
                    {"error": "that OpenAI text model id looks invalid"},
                    status_code=400,
                )
        if "relay_daily_request_cap" in candidate:
            candidate["relay_daily_request_cap"] = max(0, int(candidate["relay_daily_request_cap"]))
        if candidate.get("relay_url"):
            fixed = str(candidate["relay_url"]).strip()
            if not fixed.startswith(("http://", "https://")):
                fixed = "https://" + fixed
            if fixed.startswith("http://"):
                return JSONResponse(
                    {"error": "the relay address must start with https:// "
                              "(plain http would expose the relay password)"},
                    status_code=400)
            candidate["relay_url"] = fixed
        if "quota_reset_timezone" in candidate:
            from zoneinfo import ZoneInfo
            candidate["quota_reset_timezone"] = candidate["quota_reset_timezone"].strip()
            try:
                ZoneInfo(candidate["quota_reset_timezone"])
            except Exception:
                return JSONResponse(
                    {"error": "unknown timezone (try America/Los_Angeles)"}, status_code=400
                )
        if "dashboard_port" in candidate and not (1 <= candidate["dashboard_port"] <= 65535):
            return JSONResponse({"error": "port must be 1-65535"}, status_code=400)
        if "wake_threshold" in candidate:
            candidate["wake_threshold"] = min(0.99, max(0.05, candidate["wake_threshold"]))
        if "log_level" in candidate:
            candidate["log_level"] = candidate["log_level"].upper()
            if candidate["log_level"] not in ("DEBUG", "INFO", "WARNING", "ERROR"):
                return JSONResponse({"error": "log level must be DEBUG/INFO/WARNING/ERROR"}, status_code=400)
        if "alarm_volume" in candidate:
            candidate["alarm_volume"] = min(1.0, max(0.2, candidate["alarm_volume"]))
        if "alarm_ring_seconds" in candidate:
            candidate["alarm_ring_seconds"] = min(600, candidate["alarm_ring_seconds"])
        if "weather_units" in candidate and candidate["weather_units"] not in ("celsius", "fahrenheit"):
            return JSONResponse({"error": "units must be celsius or fahrenheit"}, status_code=400)
        if "location_lat" in candidate and not -90 <= candidate["location_lat"] <= 90:
            return JSONResponse({"error": "latitude must be -90..90"}, status_code=400)
        if "location_lon" in candidate and not -180 <= candidate["location_lon"] <= 180:
            return JSONResponse({"error": "longitude must be -180..180"}, status_code=400)
        minimums = {
            "inactivity_timeout_seconds": 5, "interrupt_rms_threshold": 50,
            "rate_limit_rotate_after_failures": 1, "unavailable_retry_seconds": 0,
            "quota_reset_jitter_seconds": 0, "retry_window_backoff_seconds": 0,
            "pulse_internet_interval": 5, "pulse_govee_interval": 5,
            "pulse_credential_interval": 5, "pulse_timer_interval": 1,
            "pulse_audio_idle_interval": 5, "session_max_age_days": 1,
            "login_max_attempts": 1, "login_window_seconds": 10,
            "alarm_ring_seconds": 5,
        }
        for key, lo in minimums.items():
            if key in candidate and candidate[key] < lo:
                return JSONResponse({"error": f"{key} must be at least {lo}"}, status_code=400)

        # 3) apply atomically, then persist
        for key, value in candidate.items():
            setattr(rt.settings, key, value)
        changed = list(candidate)
        rt.settings.save()
        await rt.db.log("INFO", "settings", f"updated: {', '.join(changed) or 'nothing'}")

        # apply live where possible
        note = ""
        engine_keys = {"wake_word_model", "voice_enabled", "mic_device", "speaker_device", "vosk_model_path"}
        if engine_keys & set(changed):
            rt.schedule_audio_reload()
            note = "voice settings applied live"
        if {"dashboard_host", "dashboard_port"} & set(changed):
            note = "host/port change needs a restart"
        return {"ok": True, "changed": changed, "note": note}

    @app.post("/api/password")
    async def api_password(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        current, new = str(body.get("current", "")), str(body.get("new", ""))
        stored = await rt.db.get_setting("admin_password_hash")
        if not stored or not verify_password(stored, current):
            return JSONResponse({"error": "current password is wrong"}, status_code=403)
        if len(new) < 8:
            return JSONResponse({"error": "new password must be at least 8 characters"}, status_code=400)
        await rt.db.set_setting("admin_password_hash", hash_password(new))
        return {"ok": True}

    @app.post("/api/wake")
    async def api_wake(request: Request):
        """Manual session trigger (useful before a wake-word model is set up)."""
        err = await require_api(request)
        if err:
            return err
        if rt.gateway is None:
            return JSONResponse({"error": "cloud gateway disabled"}, status_code=400)
        rt.gateway.request_session()
        return {"ok": True}

    @app.post("/api/stop")
    async def api_stop(request: Request):
        """Immediately silence all speech output."""
        err = await require_api(request)
        if err:
            return err
        rt.stop_output()
        return {"ok": True}

    @app.post("/api/session/end")
    async def api_end_session(request: Request):
        """End hands-free listening and return to wake-word mode."""
        err = await require_api(request)
        if err:
            return err
        if rt.gateway is not None:
            await rt.gateway.end_session("ended from dashboard")
        rt.stop_output()
        return {"ok": True}

    # -- memory ------------------------------------------------------------
    @app.get("/api/memories")
    async def api_memories(request: Request):
        err = await require_api(request)
        if err:
            return err
        rows = await rt.db.fetchall(
            "SELECT id, content, source, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT 500"
        )
        return {"memories": [dict(r) for r in rows]}

    @app.post("/api/memories")
    async def api_add_memory(request: Request):
        err = await require_api(request)
        if err:
            return err
        body = await request.json()
        result = await rt.tools.dispatch(
            "", "remember_fact", {"content": str(body.get("content", ""))[:600], "source": "dashboard"}
        )
        status = 400 if "error" in result else 200
        return JSONResponse(result, status_code=status)

    @app.post("/api/memories/{mem_id}/delete")
    async def api_delete_memory(mem_id: str, request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        rt.bus.publish("memories_changed", action="deleted")
        return {"ok": True}

    # -- transcripts -------------------------------------------------------
    @app.get("/api/transcripts")
    async def api_transcripts(request: Request):
        """List voice sessions with their transcript summary (paginated, newest first).

        Pages voice_sessions first with a bounded offset, then computes line_count
        only for those page rows using the existing session/id index — no full-table
        GROUP BY scan.
        """
        err = await require_api(request)
        if err:
            return err
        try:
            limit = min(int(request.query_params.get("limit", "50")), 200)
            offset = max(int(request.query_params.get("offset", "0")), 0)
        except (ValueError, TypeError):
            return JSONResponse({"error": "limit and offset must be integers"}, status_code=400)
        # Bound offset so a huge page number cannot trigger a full-table scan.
        offset = min(offset, 10_000)
        # Page voice_sessions first (uses idx_voice_sessions_started), then
        # count lines only for the page rows via the session/id index.
        rows = await rt.db.fetchall(
            "WITH page AS ("
            "  SELECT id, provider, started_at, ended_at, close_reason"
            "  FROM voice_sessions"
            "  ORDER BY started_at DESC, id DESC"
            "  LIMIT ? OFFSET ?"
            ") "
            "SELECT p.id, p.provider, p.started_at, p.ended_at, p.close_reason,"
            "       COUNT(t.id) AS line_count"
            " FROM page p"
            " LEFT JOIN transcripts t ON t.session_id = p.id"
            " GROUP BY p.id, p.provider, p.started_at, p.ended_at, p.close_reason"
            " ORDER BY p.started_at DESC, p.id DESC",
            (limit, offset),
        )
        return {"sessions": [dict(r) for r in rows], "limit": limit, "offset": offset}

    @app.get("/api/transcripts/{session_id}")
    async def api_transcript_detail(session_id: str, request: Request):
        """Return the session metadata and a bounded page of transcript lines.

        Default (no cursor): returns the newest up-to 200 lines in chronological
        order, plus has_more=True and next_before=<oldest_id> when more exist.

        With ?before=<line_id>: returns the next older page (lines with id <
        before), newest-first internally then reversed for display, same limit.
        Never returns unlimited text.
        """
        err = await require_api(request)
        if err:
            return err
        # Validate session exists — avoids leaking timing info via error shape.
        session_row = await rt.db.fetchone(
            "SELECT id, provider, started_at, ended_at, close_reason "
            "FROM voice_sessions WHERE id = ?",
            (session_id,),
        )
        if session_row is None:
            return JSONResponse({"error": "not found"}, status_code=404)

        # Parse and validate limit.
        try:
            line_limit = min(int(request.query_params.get("limit", "200")), 200)
            if line_limit < 1:
                line_limit = 200
        except (ValueError, TypeError):
            return JSONResponse({"error": "limit must be an integer"}, status_code=400)

        # Parse and validate optional before cursor.
        before_raw = request.query_params.get("before", "")
        before_id: int | None = None
        if before_raw:
            try:
                before_id = int(before_raw)
                if before_id < 1:
                    return JSONResponse({"error": "before must be a positive integer"}, status_code=400)
            except (ValueError, TypeError):
                return JSONResponse({"error": "before must be a positive integer"}, status_code=400)

        # Fetch one extra row to detect has_more.
        fetch_limit = line_limit + 1
        if before_id is not None:
            # Older page: rows with id < before_id, descending (newest first) so
            # we take the closest older rows, then reverse for display order.
            raw_rows = await rt.db.fetchall(
                "SELECT id, ts, role, text FROM transcripts"
                " WHERE session_id = ? AND id < ?"
                " ORDER BY id DESC LIMIT ?",
                (session_id, before_id, fetch_limit),
            )
        else:
            # Default: newest rows first (descending), then reverse for display.
            raw_rows = await rt.db.fetchall(
                "SELECT id, ts, role, text FROM transcripts"
                " WHERE session_id = ?"
                " ORDER BY id DESC LIMIT ?",
                (session_id, fetch_limit),
            )

        has_more = len(raw_rows) > line_limit
        page_rows = raw_rows[:line_limit]
        # Reverse so lines are in chronological (ascending) order for display.
        page_rows = list(reversed(page_rows))

        next_before: int | None = None
        if has_more and page_rows:
            next_before = page_rows[0]["id"]

        return {
            "session": dict(session_row),
            "lines": [dict(r) for r in page_rows],
            "has_more": has_more,
            "next_before": next_before,
        }

    # -- updates & restart ---------------------------------------------------
    @app.get("/api/update/status")
    async def api_update_status(request: Request):
        err = await require_api(request)
        if err:
            return err
        return rt.updater.status() if rt.updater else {"error": "updater not running"}

    @app.post("/api/update/check")
    async def api_update_check(request: Request):
        err = await require_api(request)
        if err:
            return err
        if rt.updater is None:
            return JSONResponse({"error": "updater not running"}, status_code=400)
        return await rt.updater.check_now()

    @app.post("/api/restart")
    async def api_restart(request: Request):
        err = await require_api(request)
        if err:
            return err
        await rt.db.log("INFO", "dashboard", "restart requested")
        rt.request_restart()
        return {"ok": True, "note": "Chat is restarting; this page will reconnect."}

    # -- audio devices & phone listening -------------------------------------
    @app.get("/api/audio/devices")
    async def api_audio_devices(request: Request):
        err = await require_api(request)
        if err:
            return err
        devices = {"inputs": [], "outputs": []}
        try:
            import sounddevice as sd

            for i, d in enumerate(sd.query_devices()):
                entry = {"index": i, "name": d["name"]}
                if d.get("max_input_channels", 0) > 0:
                    devices["inputs"].append(entry)
                if d.get("max_output_channels", 0) > 0:
                    devices["outputs"].append(entry)
        except Exception:
            pass  # no sound stack on this machine; lists stay empty
        return devices

    @app.websocket("/ws/audio")
    async def ws_audio(ws: WebSocket):
        """Streams Chat's output audio (PCM16 mono 24 kHz) to the browser."""
        sm = await session_mgr()
        if sm.validate(ws.cookies.get(COOKIE)) is None:
            await ws.close(code=4401)
            return
        await ws.accept()
        q = rt.broadcast.subscribe()

        async def sink_incoming():
            try:
                while True:
                    await ws.receive_text()  # keepalives from the browser
            except Exception:
                pass

        recv_task = asyncio.create_task(sink_incoming())
        try:
            while True:
                kind, payload = await q.get()
                if kind == "pcm":
                    await ws.send_bytes(payload)
                else:
                    await ws.send_text('{"type":"clear"}')
        except (WebSocketDisconnect, RuntimeError, ConnectionError):
            pass
        finally:
            rt.broadcast.unsubscribe(q)
            recv_task.cancel()

    @app.websocket("/ws/remote-audio")
    async def ws_remote_audio(ws: WebSocket):
        """Authenticated browser microphone/speaker in wake-listening mode.

        Lifecycle:
          1. Accept claims the remote-microphone lease but does NOT start a
             provider session — the user must say Hey Jarvis.
          2. Incoming 16 kHz PCM16 mono chunks are run through the wake model
             off the event loop (AudioEngine.run_remote_wake).  On a hit,
             request_session() is called and the socket enters conversation
             mode.
          3. Goodbye, mute, or inactivity end the provider session but keep
             the WebSocket open and return to wake-listening mode.  Ordinary
             speech after an end must not reach the provider.
          4. The socket is only closed on: auth loss (4401), owner conflict
             (4409), gateway disabled (4403), transport disconnect, or app stop.

        If the wake model is unavailable the browser shows a fallback button
        (/api/wake) and the server still accepts the socket for audio output.
        """
        sm = await session_mgr()
        if sm.validate(ws.cookies.get(COOKIE)) is None:
            await ws.close(code=4401)
            return
        if rt.gateway is None:
            await ws.close(code=4403, reason="cloud gateway disabled")
            return
        await ws.accept()
        if app.state.remote_mic_owner is not None:
            await ws.close(code=4409, reason="another device is already using the microphone")
            return
        # There is no await between checking and assigning the owner: claims
        # are atomic on the app event loop.  The owner remains assigned until
        # all async disconnect cleanup is complete, preventing a stale finally
        # block from racing a newly accepted browser.
        app.state.remote_mic_generation += 1
        previous_route = rt.settings.audio_output_route
        lease = _RemoteMicLease(
            socket=ws,
            owner_generation=app.state.remote_mic_generation,
            # voice_session_generation starts at 0 -- set when a wake fires
            voice_session_generation=0,
            voice_end_generation=rt.gateway.voice_end_generation,
            previous_route=previous_route,
        )
        app.state.remote_mic_owner = lease
        q = rt.broadcast.subscribe()
        rt.settings.audio_output_route = "phone"
        if rt.audio is not None:
            rt.audio.remote_mic_active = True
        media_mic_gate = PlaybackAwareMicGate(
            max(600.0, rt.settings.interrupt_rms_threshold * 0.75)
        )

        # Whether a provider session is currently active for this browser.
        # Protected by the asyncio event loop (single-threaded) so no lock needed.
        session_active_flag: list[bool] = [False]

        WAKE_CHUNK = 2560   # 1280 samples * 2 bytes — exact 80 ms at 16 kHz
        wake_buf = bytearray()

        async def receive_mic():
            nonlocal wake_buf
            loud_chunks = 0
            media_hint = False
            last_voice_state = rt.state.raw_state

            while True:
                message = await ws.receive()
                if message.get("type") == "websocket.disconnect":
                    raise WebSocketDisconnect()

                control = message.get("text")
                if control:
                    try:
                        command = json.loads(control)
                    except (TypeError, ValueError):
                        continue
                    if (
                        isinstance(command, dict)
                        and command.get("type") == "media_state"
                        and isinstance(command.get("playing"), bool)
                    ):
                        media_hint = command["playing"]
                        media_mic_gate.set_media_playing(rt.media_playing or media_hint)
                        loud_chunks = 0
                    continue

                pcm = message.get("bytes")
                if not pcm:
                    continue
                if len(pcm) > 65536:
                    continue
                # Server-side mute: drop all incoming PCM without forwarding.
                if rt.state.muted:
                    loud_chunks = 0
                    continue

                # Check whether an explicit end has been issued since the last
                # wake fired.  Reset the session flag so further PCM is gated
                # until the next wake hit.
                if (
                    lease.voice_session_generation > 0
                    and rt.gateway.voice_end_generation != lease.voice_end_generation
                ):
                    session_active_flag[0] = False
                    lease.voice_end_generation = rt.gateway.voice_end_generation
                    # Drain audio_in so post-goodbye ordinary speech cannot
                    # sneak into the next session.
                    while not rt.gateway.audio_in.empty():
                        try:
                            rt.gateway.audio_in.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                    # Reset mic gate so the wake-word path starts clean.
                    media_mic_gate.close_utterance()
                    loud_chunks = 0
                    wake_buf = bytearray()
                    last_voice_state = rt.state.raw_state
                    continue

                # Natural inactivity/provider close: session_intent_active goes
                # False without advancing voice_end_generation.  Gate the same
                # way so ordinary speech doesn't silently re-enter the provider.
                if session_active_flag[0] and not rt.gateway.session_intent_active:
                    session_active_flag[0] = False
                    while not rt.gateway.audio_in.empty():
                        try:
                            rt.gateway.audio_in.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                    media_mic_gate.close_utterance()
                    loud_chunks = 0
                    wake_buf = bytearray()
                    last_voice_state = rt.state.raw_state
                    continue

                # ---- WAKE-LISTENING mode --------------------------------
                if not session_active_flag[0]:
                    # External session binding: /api/wake (or any out-of-band
                    # caller) may have called gateway.request_session() while
                    # this socket is the current authenticated owner.  When the
                    # wake model is unavailable the browser shows a fallback
                    # button wired to /api/wake; we must detect that here and
                    # bind to the newly active session so PCM can flow.
                    #
                    # Safety gates (all must hold):
                    #  1. This socket is still the current remote-mic owner
                    #     (not stale / replaced by a newer browser).
                    #  2. The gateway has an active session intent.
                    #  3. The session generation is newer than what we already
                    #     own (avoids double-binding the same generation).
                    #  4. We are not muted.
                    if (
                        app.state.remote_mic_owner is lease
                        and rt.gateway.session_intent_active
                        and rt.gateway.voice_session_generation
                            > lease.voice_session_generation
                        and not rt.state.muted
                    ):
                        # Bind to the externally started session.
                        lease.voice_session_generation = (
                            rt.gateway.voice_session_generation
                        )
                        lease.voice_end_generation = rt.gateway.voice_end_generation
                        session_active_flag[0] = True
                        media_mic_gate.close_utterance()
                        loud_chunks = 0
                        wake_buf = bytearray()
                        # Fall through to CONVERSATION mode below — do NOT
                        # `continue` so the current PCM chunk is processed.
                    else:
                        # Accumulate PCM in the wake buffer; run inference on
                        # every complete 80 ms (1280-sample) frame.
                        wake_buf.extend(pcm)
                        while len(wake_buf) >= WAKE_CHUNK:
                            frame = bytes(wake_buf[:WAKE_CHUNK])
                            wake_buf = wake_buf[WAKE_CHUNK:]
                            if rt.audio is not None and hasattr(rt.audio, "run_remote_wake"):
                                hit = await rt.audio.run_remote_wake(frame)
                                if hit and not rt.state.muted:
                                    # Gate: request_session() advances generation
                                    # on every fresh wake so stale listeners
                                    # cannot reuse it.
                                    session_gen = rt.gateway.request_session()
                                    lease.voice_session_generation = session_gen
                                    lease.voice_end_generation = (
                                        rt.gateway.voice_end_generation
                                    )
                                    session_active_flag[0] = True
                                    media_mic_gate.close_utterance()
                                    loud_chunks = 0
                                    break
                        continue

                # ---- CONVERSATION mode ----------------------------------
                media_mic_gate.set_media_playing(rt.media_playing or media_hint)
                voice_state = rt.state.raw_state
                if voice_state == ChatState.SLEEPING and last_voice_state != ChatState.SLEEPING:
                    media_mic_gate.close_utterance()
                    loud_chunks = 0
                last_voice_state = voice_state

                for speech_pcm in media_mic_gate.feed(pcm):
                    if rms16(speech_pcm) >= max(500, rt.settings.interrupt_rms_threshold / 2):
                        loud_chunks += 1
                    else:
                        loud_chunks = 0
                    if loud_chunks >= 2 and rt.state.raw_state == ChatState.SLEEPING:
                        # Sleeping without an active intent: do not forward.
                        loud_chunks = 0
                        continue
                    # Re-check explicit end guard before each forwarded frame.
                    if rt.gateway.voice_end_generation != lease.voice_end_generation:
                        session_active_flag[0] = False
                        break
                    try:
                        rt.gateway.audio_in.put_nowait(speech_pcm)
                    except asyncio.QueueFull:
                        try:
                            rt.gateway.audio_in.get_nowait()
                        except asyncio.QueueEmpty:
                            pass
                        rt.gateway.audio_in.put_nowait(speech_pcm)

        recv_task = asyncio.create_task(receive_mic())
        try:
            while True:
                get_audio = asyncio.create_task(q.get())
                done, _ = await asyncio.wait(
                    (get_audio, recv_task), return_when=asyncio.FIRST_COMPLETED
                )
                if recv_task in done:
                    get_audio.cancel()
                    await asyncio.gather(get_audio, return_exceptions=True)
                    await recv_task
                    break
                kind, payload = get_audio.result()
                if kind == "pcm":
                    await ws.send_bytes(payload)
                else:
                    await ws.send_text('{"type":"clear"}')
        except (WebSocketDisconnect, RuntimeError, ConnectionError):
            pass
        finally:
            rt.broadcast.unsubscribe(q)
            recv_task.cancel()
            await asyncio.gather(recv_task, return_exceptions=True)

            # Only the current owner may touch global audio routing or the
            # gateway. Keep ownership through the awaited, generation-bound
            # end so another browser cannot be claimed midway through cleanup.
            if app.state.remote_mic_owner is lease:
                rt.stop_output()
                if rt.gateway is not None:
                    await rt.gateway.end_session(
                        "remote device disconnected",
                        expected_generation=lease.voice_session_generation,
                    )
                    # Drain any residual audio frames.
                    while not rt.gateway.audio_in.empty():
                        try:
                            rt.gateway.audio_in.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                if app.state.remote_mic_owner is lease:
                    if rt.audio is not None:
                        rt.audio.remote_mic_active = False
                    if rt.settings.audio_output_route == "phone":
                        rt.settings.audio_output_route = lease.previous_route
                    app.state.remote_mic_owner = None

    return app


def _jsonsafe(data: dict) -> dict:
    out = {}
    for k, v in data.items():
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, (set, frozenset)):
            out[k] = sorted(v)
        else:
            out[k] = v
    return out
