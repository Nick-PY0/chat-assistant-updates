"use strict";

/*
 * YouTube media player for the Chat dashboard.
 *
 * Playback is performed by a plain https://www.youtube.com/embed/<id> iframe
 * with enablejsapi=1.  All player control uses the documented postMessage
 * command protocol (playVideo, pauseVideo, stopVideo, seekTo).  No external
 * script is ever loaded: no dynamic script injection,
 * and no remote JS/CSS/font import of any kind.
 *
 * The only external resources this page ever contacts are:
 *   • https://www.youtube.com/embed/<validated-id>  — the embedded player
 *   • https://i.ytimg.com/vi/<id>/mqdefault.jpg     — queue thumbnails
 *   • /api/media/*                                   — local server APIs
 *
 * When a video is blocked or unembeddable the player is removed and the user
 * is offered a direct link to https://www.youtube.com/watch?v=<id>.
 */

(() => {
  const $ = (id) => document.getElementById(id);
  const page = $("media-page");
  if (!page) return;

  const form              = $("media-request-form");
  const requestInput      = $("media-request-input");
  const requestButton     = $("media-request-button");
  const connectionEl      = $("media-connection");
  const takeoverButton    = $("media-takeover");
  const stageEl           = $("media-stage");
  const placeholder       = $("media-placeholder");
  const tapToPlay         = $("media-tap-play");
  const titleEl           = $("media-title");
  const timeEl            = $("media-time");
  const youtubeLink       = $("media-youtube-link");
  const messageEl         = $("media-message");
  const queueEl           = $("media-queue");
  const queueCount        = $("media-queue-count");
  const resultsMessage    = $("media-results-message");
  const playPauseButton   = $("media-play-pause");
  const stopButton        = $("media-stop");
  const previousButton    = $("media-previous");
  const nextButton        = $("media-next");
  const seekBackButton    = $("media-seek-back");
  const seekForwardButton = $("media-seek-forward");
  const seekSecondsInput  = $("media-seek-seconds");

  /* ── constants ─────────────────────────────────────────────────────── */
  const EMPTY_STATE = {
    revision: 0,
    status: "stopped",
    video_id: "",
    title: "",
    url: "",
    position_seconds: 0,
    duration_seconds: 0,
    queue: [],
    queue_index: -1,
    command: null,
    target_id: "",
    target_label: "",
    player_connected: false,
  };
  const MEDIA_CHANNEL = "chat-media-state-v1";
  /* YouTube postMessage state codes (YT IFrame API reference). */
  const YT_STATES = {
    "-1": "queued",     /* unstarted / video cued */
     "0": "ended",
     "1": "playing",
     "2": "paused",
     "3": "buffering",
     "5": "queued",     /* video cued */
  };
  /* Unembeddable / blocked error codes that require a watch-page fallback. */
  const UNEMBEDDABLE_ERRORS = new Set([101, 150]);
  /* Other embeddable-player error codes. */
  const PLAYER_ERROR_MESSAGES = {
    2:   "That YouTube video ID is invalid.",
    5:   "YouTube could not play this video in the browser.",
    100: "That video was removed or is private.",
    101: "The video owner has disabled embedded playback.",
    150: "The video owner has disabled embedded playback.",
  };
  const EMBED_ORIGIN = location.origin;

  /* ── mutable state ──────────────────────────────────────────────────── */
  let state            = { ...EMPTY_STATE };
  let owner            = false;
  let busy             = false;
  let iframeEl         = null;   /* the live <iframe> element, or null */
  let currentVideoId   = "";     /* video ID the iframe was built for */
  let progressTimer    = null;
  let leaseTimer       = null;
  let progressTicks    = 0;
  let reportChain      = Promise.resolve();
  let lastVoicePlaying = null;
  let lastCommandId    = "";
  /* Estimated playback position — updated each second while playing. */
  let localPosition    = 0;
  let localDuration    = 0;

  /* ── client identity (session-scoped, sessionStorage only) ─────────── */
  function makeClientId() {
    const storageKey = "chat-media-client-v1";
    try {
      const existing = sessionStorage.getItem(storageKey);
      if (/^[A-Za-z0-9_-]{8,80}$/.test(existing || "")) return existing;
    } catch (_) { /* sessionStorage can be disabled */ }
    const bytes = crypto.getRandomValues(new Uint8Array(18));
    const id = "media_" + Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    try { sessionStorage.setItem(storageKey, id); } catch (_) { /* page lifetime is enough */ }
    return id;
  }

  const clientId    = makeClientId();
  const mediaChannel = "BroadcastChannel" in window
    ? new BroadcastChannel(MEDIA_CHANNEL)
    : null;

  /* ── UI helpers ─────────────────────────────────────────────────────── */
  function setMessage(message = "", tone = "") {
    messageEl.textContent = message;
    messageEl.className = `media-message${tone ? ` ${tone}` : ""}`;
  }

  function formatTime(value) {
    const total = Math.max(0, Number.isFinite(Number(value)) ? Math.floor(Number(value)) : 0);
    const hours   = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    return hours
      ? `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
      : `${minutes}:${String(seconds).padStart(2, "0")}`;
  }

  function seekAmount() {
    const v = Math.round(Number(seekSecondsInput.value));
    return Math.max(1, Math.min(3600, Number.isFinite(v) ? v : 10));
  }

  function updateSeekLabels() {
    const s = seekAmount();
    seekSecondsInput.value = String(s);
    seekBackButton.setAttribute("aria-label", `Seek backward ${s} seconds`);
    seekBackButton.title    = `Back ${s} seconds`;
    seekForwardButton.setAttribute("aria-label", `Seek forward ${s} seconds`);
    seekForwardButton.title = `Forward ${s} seconds`;
  }

  /* ── BroadcastChannel voice bridge ─────────────────────────────────── */
  function notifyRemoteVoice(playing, force = false) {
    const next = Boolean(playing);
    if (!force && lastVoicePlaying === next) return;
    lastVoicePlaying = next;
    if (mediaChannel) mediaChannel.postMessage({ type: "media_state", playing: next });
  }

  if (mediaChannel) {
    mediaChannel.addEventListener("message", (event) => {
      if (event.data && event.data.type === "request_media_state") {
        notifyRemoteVoice(state.status === "playing", true);
      }
    });
  }

  /* ── postMessage player control ─────────────────────────────────────── */
  /*
   * Build and inject a bare <iframe> pointing at the official embed URL.
   * No external script is loaded; all control goes through postMessage.
   * The iframe is only created when there is an actual video to show.
   */
  function buildEmbedUrl(videoId, startSeconds) {
    const start = Math.max(0, Math.floor(Number(startSeconds) || 0));
    const params = new URLSearchParams({
      enablejsapi: "1",
      origin: EMBED_ORIGIN,
      autoplay: "1",
      playsinline: "1",
      rel: "0",
      modestbranding: "1",
    });
    if (start > 0) params.set("start", String(start));
    return `https://www.youtube.com/embed/${encodeURIComponent(videoId)}?${params}`;
  }

  function postToPlayer(func, args) {
    if (!iframeEl || !iframeEl.contentWindow) return;
    iframeEl.contentWindow.postMessage(
      JSON.stringify({ event: "command", func, args: args ?? [] }),
      "https://www.youtube.com"
    );
  }

  function teardownIframe() {
    if (iframeEl) {
      iframeEl.remove();
      iframeEl = null;
    }
    currentVideoId = "";
    localPosition  = 0;
    localDuration  = 0;
  }

  function ensureIframe(videoId, startSeconds) {
    /* Re-use the existing iframe if the video hasn't changed. */
    if (iframeEl && currentVideoId === videoId) {
      const start = Math.max(0, Number(startSeconds) || 0);
      if (start > 1) postToPlayer("seekTo", [start, true]);
      postToPlayer("playVideo", []);
      return;
    }
    teardownIframe();

    const iframe = document.createElement("iframe");
    iframe.id                = "youtube-iframe";
    iframe.src               = buildEmbedUrl(videoId, startSeconds);
    iframe.allow             = "autoplay; fullscreen; picture-in-picture";
    iframe.allowFullscreen   = true;
    iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
    /* Dimensions are controlled by CSS (.media-stage iframe). */
    iframe.style.cssText     = "position:absolute;inset:0;width:100%;height:100%;border:0;";
    stageEl.appendChild(iframe);
    iframeEl       = iframe;
    currentVideoId = videoId;
    placeholder.hidden = true;
    tapToPlay.hidden   = true;
  }

  /* Receive events from the embedded player. */
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://www.youtube.com") return;
    /* Ignore any message that isn't sent by the *active* iframe's window. */
    if (!iframeEl || !iframeEl.contentWindow || event.source !== iframeEl.contentWindow) return;
    let msg;
    try { msg = JSON.parse(typeof event.data === "string" ? event.data : JSON.stringify(event.data)); }
    catch (_) { return; }
    /* The YT IFrame API echoes the iframe's own `id` attribute in every
       event. Accept only events bound to the live iframe element, so a
       spoofed message carrying a wrong id (or no id) is rejected. */
    if (!msg || String(msg.id) !== iframeEl.id) return;

    if (msg.event === "onStateChange") {
      const raw    = String(msg.info);
      const status = YT_STATES[raw] || state.status;
      onPlayerStateChange(status);
    } else if (msg.event === "onError") {
      onPlayerError(Number(msg.info));
    } else if (msg.event === "onAutoplayBlocked") {
      onAutoplayBlocked();
    } else if (msg.event === "infoDelivery" && msg.info) {
      /* Position/duration updates delivered by the YT iframe. */
      if (typeof msg.info.currentTime === "number") localPosition = msg.info.currentTime;
      if (typeof msg.info.duration    === "number") localDuration = msg.info.duration;
    }
  });

  function onPlayerStateChange(status) {
    state.status = status;
    state.url    = state.video_id
      ? `https://www.youtube.com/watch?v=${encodeURIComponent(state.video_id)}`
      : "";
    renderState();
    notifyRemoteVoice(status === "playing");
    scheduleProgressUpdate();
    reportPlayerState(status);
  }

  function onAutoplayBlocked() {
    state.status = "queued";
    tapToPlay.hidden = false;
    notifyRemoteVoice(false);
    stopProgressUpdates();
    renderState();
    setMessage("Your browser blocked autoplay. Tap the play button over the video to continue.");
    reportPlayerState("queued");
  }

  function onPlayerError(code) {
    state.status = "error";
    notifyRemoteVoice(false);
    stopProgressUpdates();
    tapToPlay.hidden = true;
    renderState();

    if (UNEMBEDDABLE_ERRORS.has(code) && /^[A-Za-z0-9_-]{11}$/.test(state.video_id)) {
      /* Tear down the iframe — this video cannot be embedded. Offer the
         official watch page as a safe fallback instead. The link target is
         built from a validated 11-char video id, and the DOM is assembled with
         createElement so no untrusted string is ever parsed as HTML. */
      teardownIframe();
      placeholder.hidden = false;
      const watchUrl = `https://www.youtube.com/watch?v=${encodeURIComponent(state.video_id)}`;
      messageEl.className = "media-message";
      messageEl.textContent = "This video cannot be embedded. ";
      const link = document.createElement("a");
      link.href = watchUrl;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Open on YouTube ↗";
      messageEl.appendChild(link);
    } else {
      const msg = PLAYER_ERROR_MESSAGES[code]
        || "YouTube could not play that video.";
      setMessage(msg, "bad");
    }
    reportPlayerState("error");
  }

  /* ── progress ticker (setTimeout chain) ────────────────────────────── */
  function stopProgressUpdates() {
    clearTimeout(progressTimer);
    progressTimer = null;
    progressTicks = 0;
  }

  function scheduleProgressUpdate() {
    stopProgressUpdates();
    if (state.status !== "playing") return;
    const tick = () => {
      if (state.status !== "playing") { stopProgressUpdates(); return; }
      /* Increment local estimate by 1s; postMessage delivers real values. */
      localPosition = Math.min(
        localDuration > 0 ? localDuration : Infinity,
        localPosition + 1
      );
      state.position_seconds = localPosition;
      state.duration_seconds = localDuration;
      timeEl.textContent = `${formatTime(state.position_seconds)} / ${formatTime(state.duration_seconds)}`;
      progressTicks += 1;
      if (progressTicks % 10 === 0) reportPlayerState("playing");
      progressTimer = setTimeout(tick, 1000);
    };
    progressTimer = setTimeout(tick, 1000);
  }

  /* ── connection / UI rendering ──────────────────────────────────────── */
  function setConnection() {
    connectionEl.className = "status-pill";
    if (owner) {
      connectionEl.classList.add("ok");
      connectionEl.textContent = "This device selected";
      takeoverButton.hidden = true;
    } else if (state.player_connected) {
      connectionEl.classList.add("standby");
      connectionEl.textContent = state.target_label
        ? `Playing on ${state.target_label}`
        : "Another device selected";
      takeoverButton.hidden = false;
    } else {
      connectionEl.classList.add("unknown");
      connectionEl.textContent = "No player selected";
      takeoverButton.hidden = false;
    }
  }

  function updateControls() {
    const hasVideo = Boolean(state.video_id);
    const locked   = !owner || busy;
    requestInput.disabled    = locked;
    requestButton.disabled   = locked;
    playPauseButton.disabled = locked || !hasVideo;
    stopButton.disabled      = locked || !hasVideo;
    seekBackButton.disabled  = locked || !hasVideo;
    seekForwardButton.disabled = locked || !hasVideo;
    previousButton.disabled  = locked || state.queue_index <= 0;
    nextButton.disabled      = locked
      || state.queue_index < 0
      || state.queue_index + 1 >= state.queue.length;
    playPauseButton.textContent =
      state.status === "playing" || state.status === "buffering" ? "Pause" : "Play";
  }

  function renderQueue() {
    queueEl.replaceChildren();
    const queue = Array.isArray(state.queue) ? state.queue : [];
    queueCount.textContent = `${queue.length} ${queue.length === 1 ? "video" : "videos"}`;
    resultsMessage.hidden  = queue.length > 0;
    for (const [index, item] of queue.entries()) {
      const row    = document.createElement("li");
      row.className = "media-queue-item";
      if (index === state.queue_index) row.classList.add("active");
      const button = document.createElement("button");
      button.type     = "button";
      button.disabled = !owner || busy;
      button.addEventListener("click", () => manualControl("play", {
        video: item.video_id,
        title: item.title || "YouTube video",
      }));
      const image  = document.createElement("img");
      image.src    = item.thumbnail
        || `https://i.ytimg.com/vi/${encodeURIComponent(item.video_id)}/mqdefault.jpg`;
      image.alt    = "";
      image.loading = "lazy";
      image.referrerPolicy = "strict-origin-when-cross-origin";
      const copy    = document.createElement("span");
      copy.className = "media-queue-copy";
      const title   = document.createElement("strong");
      title.textContent = item.title || "YouTube video";
      const channel = document.createElement("span");
      channel.textContent = item.channel
        || (index === state.queue_index ? "Now selected" : "YouTube");
      copy.append(title, channel);
      button.append(image, copy);
      row.appendChild(button);
      queueEl.appendChild(row);
    }
  }

  function renderState() {
    setConnection();
    titleEl.textContent = state.title
      || (state.video_id ? "YouTube video" : "Nothing selected");
    timeEl.textContent  = `${formatTime(state.position_seconds)} / ${formatTime(state.duration_seconds)}`;
    youtubeLink.hidden  = !state.url;
    if (state.url) youtubeLink.href = state.url;
    placeholder.hidden  = Boolean(state.video_id) || Boolean(iframeEl);
    updateControls();
    renderQueue();
  }

  function applyState(next) {
    if (!next || typeof next !== "object") return;
    state = {
      ...state,
      ...next,
      queue:   Array.isArray(next.queue)  ? next.queue  : state.queue,
      command: next.command === undefined  ? state.command : next.command,
    };
    owner = state.target_id === clientId;
    updateLeaseRenewal();
    renderState();
  }

  /* ── lease renewal (timeout chain) ─────────────────────────────────── */
  function updateLeaseRenewal() {
    if (!owner) {
      clearTimeout(leaseTimer);
      leaseTimer = null;
      return;
    }
    if (leaseTimer) return;
    leaseTimer = setTimeout(async () => {
      leaseTimer = null;
      await reportPlayerState(state.status);
      updateLeaseRenewal();
    }, 20000);
  }

  /* ── server API helpers ─────────────────────────────────────────────── */
  async function claimPlayer(force = false) {
    setMessage(force ? "Selecting this browser…" : "Connecting this browser…");
    try {
      const result = await api("/api/media/claim", "POST", {
        client_id: clientId,
        label: "Media page",
        force,
      });
      owner = Boolean(result.owner);
      applyState(result);
      if (owner) {
        setMessage("This browser is ready for Jarvis media commands.", "good");
        if (result.command) await handleCommand(result.command);
      } else {
        setMessage(
          "Media is selected on another device. " +
          "Choose \"Use this device\" to move playback here."
        );
      }
      return owner;
    } catch (error) {
      owner = false;
      setMessage(error.message, "bad");
      renderState();
      return false;
    }
  }

  async function reconcileState() {
    try {
      const result = await api("/api/media");
      applyState(result);
      return result;
    } catch (error) {
      setMessage(error.message, "bad");
      return null;
    }
  }

  function reportPlayerState(status = state.status) {
    if (!owner) return Promise.resolve();
    const payload = {
      client_id:        clientId,
      status,
      video_id:         state.video_id,
      title:            state.title,
      position_seconds: localPosition,
      duration_seconds: localDuration,
      queue_index:      state.queue_index,
    };
    reportChain = reportChain.then(async () => {
      try {
        const result = await api("/api/media/state", "POST", payload);
        if (result.target_id && result.target_id !== clientId) {
          owner = false;
          applyState(result);
        }
      } catch (error) {
        if (/selected Media player/i.test(error.message)) {
          owner = false;
          await reconcileState();
        }
      }
    });
    return reportChain;
  }

  /* ── command execution ──────────────────────────────────────────────── */
  async function executePlayerCommand(command) {
    if (!owner || !command) return;
    const action = command.action;

    if (action === "play") {
      const videoId      = String(command.video_id || state.video_id || "");
      const startSeconds = Math.max(0, Number(command.start_seconds) || 0);
      if (!videoId) return;
      state.video_id = videoId;
      localPosition  = startSeconds;
      /* Build or reuse the embed iframe — the only external resource load. */
      ensureIframe(videoId, startSeconds);
    } else if (action === "pause") {
      postToPlayer("pauseVideo", []);
    } else if (action === "stop") {
      postToPlayer("stopVideo", []);
      stopProgressUpdates();
      state.position_seconds = 0;
      localPosition          = 0;
      teardownIframe();
      placeholder.hidden = false;
      renderState();
    } else if (action === "seek") {
      const target = Math.max(0, Number(command.target_seconds) || 0);
      localPosition = target;
      postToPlayer("seekTo", [target, true]);
    }
  }

  async function handleCommand(command) {
    if (!command || typeof command !== "object") return;
    if (command.target_id && command.target_id !== clientId) {
      owner = false;
      await reconcileState();
      return;
    }
    if (!command.target_id) {
      if (await claimPlayer(false)) return;
      return;
    }
    if (command.command_id && command.command_id === lastCommandId) return;
    if (command.command_id) lastCommandId = command.command_id;

    state.command   = command;
    state.revision  = Math.max(Number(state.revision) || 0, Number(command.revision) || 0);
    if (command.video_id) state.video_id = command.video_id;
    if (command.title)    state.title    = command.title;
    if (Number.isFinite(Number(command.queue_index)))
      state.queue_index = Number(command.queue_index);
    if (command.action === "play")  state.status = "queued";
    else if (command.action === "pause") state.status = "paused";
    else if (command.action === "stop")  state.status = "stopped";
    renderState();
    await executePlayerCommand(command);
  }

  /* ── event listeners ────────────────────────────────────────────────── */
  function looksLikeDirectVideo(value) {
    return /^[A-Za-z0-9_-]{11}$/.test(value)
      || /^(?:https?:\/\/)?(?:www\.|m\.|music\.)?(?:youtube\.com|youtu\.be)\//i.test(value);
  }

  async function submitRequest(event) {
    event.preventDefault();
    const value = requestInput.value.trim();
    if (!value || busy) return;
    if (!owner) {
      setMessage("Select \"Use this device\" before starting media here.", "bad");
      return;
    }
    if (looksLikeDirectVideo(value)) {
      await manualControl("play", { video: value });
      return;
    }
    busy = true;
    renderState();
    setMessage("Searching YouTube…");
    try {
      const result = await api("/api/media/search", "POST", { query: value, max_results: 8 });
      state.queue       = Array.isArray(result.results) ? result.results : [];
      state.queue_index = -1;
      resultsMessage.textContent = state.queue.length
        ? "Choose a result to play."
        : "No playable videos were found.";
      renderState();
      setMessage(state.queue.length
        ? "Choose a search result from the queue."
        : "No playable videos were found.");
    } catch (error) {
      setMessage(error.message, "bad");
    } finally {
      busy = false;
      renderState();
    }
  }

  async function manualControl(action, extra = {}) {
    if (!owner) {
      setMessage("Select \"Use this device\" before controlling playback here.", "bad");
      return null;
    }
    busy = true;
    renderState();
    setMessage();
    try {
      const result = await api("/api/media/control", "POST", { action, ...extra });
      applyState(result);
      if (result.command) await handleCommand(result.command);
      return result;
    } catch (error) {
      setMessage(error.message, "bad");
      return null;
    } finally {
      busy = false;
      renderState();
    }
  }

  form.addEventListener("submit", submitRequest);
  takeoverButton.addEventListener("click", () => claimPlayer(true));
  playPauseButton.addEventListener("click", () => {
    manualControl(
      state.status === "playing" || state.status === "buffering" ? "pause" : "play"
    );
  });
  stopButton.addEventListener("click", () => manualControl("stop"));
  previousButton.addEventListener("click", () => manualControl("previous"));
  nextButton.addEventListener("click", () => manualControl("next"));
  seekBackButton.addEventListener("click", () =>
    manualControl("seek", { offset_seconds: -seekAmount() })
  );
  seekForwardButton.addEventListener("click", () =>
    manualControl("seek", { offset_seconds: seekAmount() })
  );
  seekSecondsInput.addEventListener("change", updateSeekLabels);
  tapToPlay.addEventListener("click", () => {
    tapToPlay.hidden = true;
    setMessage();
    postToPlayer("playVideo", []);
  });

  document.addEventListener("chat-event", async (event) => {
    const detail = event.detail || {};
    if (detail.topic === "media_control") {
      await handleCommand(detail);
    } else if (detail.topic === "media_state") {
      await reconcileState();
    }
  });

  window.addEventListener("pagehide", () => {
    stopProgressUpdates();
    clearTimeout(leaseTimer);
    leaseTimer = null;
    notifyRemoteVoice(false, true);
    if (mediaChannel) mediaChannel.close();
    fetch("/api/media/release", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-csrf": csrf },
      body: JSON.stringify({ client_id: clientId }),
      keepalive: true,
    }).catch(() => {});
  });

  async function initialize() {
    updateSeekLabels();
    renderState();
    await claimPlayer(false);
    if (owner && state.video_id && state.command) await handleCommand(state.command);
  }

  initialize().catch((error) => setMessage(error.message, "bad"));
})();
