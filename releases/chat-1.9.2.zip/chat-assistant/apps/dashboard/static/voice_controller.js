"use strict";
// voice_controller.js — standalone microphone/speaker bridge for /voice-controller
// This page owns the /ws/remote-audio WebSocket lease.  The main dashboard pages
// (Chat, Status, Logs, Settings …) stay open in their own tab without destroying
// the microphone connection.
//
// Wake-first flow:
//   1. User clicks "Listen for Hey Jarvis" (one-time browser permission click).
//   2. Microphone opens; raw samples are deterministically resampled from
//      AudioContext.sampleRate (48 kHz / 44.1 kHz / etc.) to PCM16 mono 16 kHz
//      and framed into exact 1280-sample (80 ms) chunks before WebSocket send.
//   3. Server runs openWakeWord on each chunk while sleeping.
//   4. On "Hey Jarvis" hit: request_session → 30-minute rolling conversation.
//   5. Goodbye, mute, or inactivity end the session; the WebSocket stays open
//      and returns to "Say Hey Jarvis" wake-listening mode.
//   6. A later "Hey Jarvis" starts a fresh generation without pressing Start again.

(() => {
  // ---- constants ----------------------------------------------------------
  const IN_RATE   = 16000;   // server expects 16 kHz mono PCM16
  const CHUNK     = 1280;    // 80 ms at 16 kHz — must match engine.py CHUNK

  // ---- state ---------------------------------------------------------------
  let ws           = null;
  let audioCtx     = null;
  let micStream    = null;
  let micProcessor = null;
  let playCursor   = 0;
  let liveSources  = [];
  let connected    = false;
  let muted        = false;

  // ---- DOM refs ------------------------------------------------------------
  const statusEl   = document.getElementById("vc-status");
  const stateEl    = document.getElementById("vc-state");
  const startBtn   = document.getElementById("vc-start");
  const stopBtn    = document.getElementById("vc-stop");
  const goodbyeBtn = document.getElementById("vc-goodbye");
  const muteBtn    = document.getElementById("vc-mute");
  const errorEl    = document.getElementById("vc-error");
  const wakeHintEl = document.getElementById("vc-wake-hint");
  const fallbackEl = document.getElementById("vc-fallback");
  const csrf       = document.querySelector('meta[name="csrf"]')?.content || "";

  // ---- helpers -------------------------------------------------------------
  function setError(msg) {
    errorEl.textContent = msg || "";
  }

  function setStatus(label, cls) {
    stateEl.textContent = label;
    stateEl.className = "vc-state-label " + (cls || "");
    statusEl.textContent = label;
    document.title = "Voice controller — " + label;
  }

  function flushAudio() {
    for (const s of liveSources) { try { s.stop(); } catch (_) {} }
    liveSources = [];
    playCursor = 0;
  }

  // ---- Deterministic stateful resampler -----------------------------------
  // Windows browsers typically capture at 48 kHz (or 44.1 kHz) regardless of
  // the getUserMedia sampleRate constraint.  Sending raw samples to a server
  // that expects 16 kHz causes the server to play audio 3× too fast, corrupting
  // wake-word detection and transcription.
  //
  // This class implements linear-interpolation downsampling from any integer
  // source rate to IN_RATE (16 kHz), framing the output into exact CHUNK-sample
  // (1280) blocks.  State is preserved across ScriptProcessor calls so partial
  // frames are never lost and the resampled duration equals the original exactly.
  class Resampler {
    constructor(srcRate, dstRate, chunkSamples) {
      this.srcRate     = srcRate;
      this.dstRate     = dstRate;
      this.chunkSamples = chunkSamples;
      // Fractional position in the source stream corresponding to the next
      // output sample that hasn't been emitted yet.
      this._srcPos     = 0.0;
      // Last sample value carried across callback boundaries for interpolation.
      this._prevSample = 0;
      // Accumulator for the current partial output chunk.
      this._outBuf     = new Int16Array(chunkSamples);
      this._outFill    = 0;
      // Complete chunks ready to send.
      this._ready      = [];
    }

    // Feed a Float32Array of microphone samples.
    // Returns an array of ArrayBuffer (each CHUNK * 2 bytes of PCM16).
    push(f32) {
      const step   = this.srcRate / this.dstRate;  // src samples per dst sample
      const n      = f32.length;

      while (true) {
        // Position in f32 for this output sample (may be negative, meaning
        // we need the previous sample carried over from last call).
        const srcIdx = this._srcPos;

        if (srcIdx >= n) {
          // Consumed all available input; save residual position and last sample.
          this._srcPos = srcIdx - n;
          if (n > 0) this._prevSample = this._toInt16(f32[n - 1]);
          break;
        }

        // Linear interpolation between adjacent source samples.
        const j    = Math.floor(srcIdx);
        const frac = srcIdx - j;
        const a    = j < 0      ? this._prevSample : this._toInt16(f32[j]);
        const b    = j + 1 < n  ? this._toInt16(f32[j + 1]) : a;
        const s    = Math.round(a + (b - a) * frac);

        this._outBuf[this._outFill++] = s;

        if (this._outFill === this.chunkSamples) {
          this._ready.push(this._outBuf.buffer.slice(0));
          this._outBuf  = new Int16Array(this.chunkSamples);
          this._outFill = 0;
        }

        this._srcPos = srcIdx + step;
      }

      const out  = this._ready;
      this._ready = [];
      return out;
    }

    _toInt16(f) {
      const s = Math.max(-1, Math.min(1, f));
      return s < 0 ? (s * 0x8000) | 0 : (s * 0x7fff) | 0;
    }

    reset() {
      this._srcPos     = 0.0;
      this._prevSample = 0;
      this._outBuf     = new Int16Array(this.chunkSamples);
      this._outFill    = 0;
      this._ready      = [];
    }
  }

  // ---- receive Chat's voice output (PCM 16-bit mono 24 kHz) ---------------
  function handleBinaryAudio(buf) {
    if (!audioCtx) return;
    const pcm = new Int16Array(buf);
    if (!pcm.length) return;
    const abuf = audioCtx.createBuffer(1, pcm.length, 24000);
    const ch = abuf.getChannelData(0);
    for (let i = 0; i < pcm.length; i++) ch[i] = pcm[i] / 32768;
    const src = audioCtx.createBufferSource();
    src.buffer = abuf;
    src.connect(audioCtx.destination);
    const startAt = Math.max(playCursor, audioCtx.currentTime + 0.06);
    src.start(startAt);
    playCursor = startAt + abuf.duration;
    liveSources.push(src);
    src.onended = () => { liveSources = liveSources.filter((x) => x !== src); };
  }

  // ---- microphone capture (resampled to PCM16 mono 16 kHz, 1280-sample frames)
  async function startMic() {
    try {
      // Request audio with constraints — browsers may ignore sampleRate, so
      // the Resampler handles the actual rate conversion deterministically.
      micStream = await navigator.mediaDevices.getUserMedia({ audio: {
        channelCount: 1, echoCancellation: true,
        noiseSuppression: true, autoGainControl: true,
      }, video: false });
    } catch (e) {
      setError("Microphone access denied: " + e.message);
      return false;
    }

    // AudioContext.sampleRate is the real hardware capture rate.
    // Do NOT use the sampleRate constraint value — Windows often ignores it.
    const micCtx   = new (window.AudioContext || window.webkitAudioContext)();
    const actualRate = micCtx.sampleRate;
    const resampler  = new Resampler(actualRate, IN_RATE, CHUNK);

    const source   = micCtx.createMediaStreamSource(micStream);
    // ScriptProcessor is deprecated but universally available without worklets.
    micProcessor   = micCtx.createScriptProcessor(4096, 1, 1);
    micProcessor.onaudioprocess = (e) => {
      if (!ws || ws.readyState !== WebSocket.OPEN || muted) return;
      const float32 = e.inputBuffer.getChannelData(0);
      const chunks  = resampler.push(float32);
      for (const buf of chunks) {
        ws.send(buf);
      }
    };
    source.connect(micProcessor);
    micProcessor.connect(micCtx.destination);
    return true;
  }

  function stopMic() {
    try { micProcessor && micProcessor.disconnect(); } catch (_) {}
    micProcessor = null;
    if (micStream) {
      micStream.getTracks().forEach((t) => t.stop());
      micStream = null;
    }
  }

  // ---- WebSocket lifecycle ------------------------------------------------
  function connectWs() {
    const proto = location.protocol === "https:" ? "wss://" : "ws://";
    ws = new WebSocket(proto + location.host + "/ws/remote-audio");
    ws.binaryType = "arraybuffer";

    ws.onopen = () => {
      connected = true;
      // Start in wake-listening mode — no session is opened yet.
      setStatus("Say Hey Jarvis", "vc-listening");
      setError("");
      startBtn.hidden   = true;
      stopBtn.hidden    = false;
      goodbyeBtn.hidden = false;
      muteBtn.hidden    = false;
      if (wakeHintEl)   wakeHintEl.hidden = false;
      if (fallbackEl)   fallbackEl.hidden = false;
    };

    ws.onmessage = (e) => {
      if (typeof e.data === "string") {
        // Control message (e.g. {"type":"clear"})
        flushAudio();
        return;
      }
      handleBinaryAudio(e.data);
      // When audio arrives, a session is active.
      if (connected) setStatus("Speaking", "vc-speaking");
      // Reset to wake-listening after audio drains
      setTimeout(() => {
        if (connected && stateEl.classList.contains("vc-speaking")) {
          setStatus("Listening", "vc-listening");
        }
      }, 600);
    };

    ws.onclose = (e) => {
      connected = false;
      if (e.code === 4401) {
        setStatus("Not signed in", "vc-error");
        setError("Session expired — please sign in again and return here.");
      } else if (e.code === 4409) {
        setStatus("Busy", "vc-warn");
        setError("Another device is already using the microphone. Disconnect it first.");
      } else if (e.code === 4410) {
        // Server-side close after goodbye or inactivity (legacy path / defensive).
        setStatus("Say Hey Jarvis", "vc-listening");
        setError("Session ended (goodbye or inactivity). Say Hey Jarvis to start again.");
      } else if (e.code === 4403) {
        setStatus("Unavailable", "vc-error");
        setError("Cloud gateway is disabled — enable it in Settings.");
      } else if (connected || e.wasClean) {
        setStatus("Disconnected", "vc-warn");
        setError("Connection closed. Press Listen for Hey Jarvis to reconnect.");
      }
      flushAudio();
      stopMic();
      startBtn.hidden   = false;
      stopBtn.hidden    = true;
      goodbyeBtn.hidden = true;
      muteBtn.hidden    = true;
      if (wakeHintEl)   wakeHintEl.hidden = true;
      if (fallbackEl)   fallbackEl.hidden = true;
      if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
    };

    ws.onerror = () => {
      setError("WebSocket error — see browser console.");
    };
  }

  // ---- SSE state tracking — update label when server signals a wake hit ---
  function startEvents() {
    let es;
    try { es = new EventSource("/events"); } catch (_) { return; }
    const dot = document.getElementById("vc-dot");
    es.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch (_) { return; }
      if (msg.topic === "state" && dot) {
        dot.className = "brand-dot " + msg.state;
      }
      // Mirror server state in the label when a conversation is active.
      if (msg.topic === "state" && connected) {
        if (msg.state === "CONNECTING") {
          setStatus("Connecting...", "vc-connecting");
        } else if (msg.state === "LISTENING") {
          setStatus("Listening", "vc-listening");
        } else if (msg.state === "SPEAKING") {
          setStatus("Speaking", "vc-speaking");
        } else if (msg.state === "SLEEPING") {
          // Session ended (goodbye / inactivity) — return to wake mode.
          setStatus("Say Hey Jarvis", "vc-listening");
        } else if (msg.state === "MUTED") {
          setStatus("Muted", "vc-muted");
        }
      }
    };
  }

  // ---- button handlers ----------------------------------------------------

  // "Listen for Hey Jarvis" — one browser click is required by browser
  // security to create the AudioContext and grant mic permission.
  startBtn.addEventListener("click", async () => {
    setError("");
    setStatus("Connecting...", "vc-connecting");
    startBtn.disabled = true;

    // AudioContext must be created inside a user gesture.
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    await audioCtx.resume();

    const ok = await startMic();
    if (!ok) {
      setStatus("Mic error", "vc-error");
      startBtn.disabled = false;
      if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
      return;
    }

    startBtn.disabled = false;
    connectWs();
  });

  // Stop only flushes Chat's spoken output. The WebSocket, microphone, and
  // wake-listening mode all stay alive.  It must NEVER close the socket or
  // end the session.
  stopBtn.addEventListener("click", async () => {
    flushAudio();  // silence local playback immediately
    try {
      await fetch("/api/stop", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: "{}",
      });
    } catch (_) {}
    if (connected) setStatus("Listening", "vc-listening");
    setError("");
  });

  // Goodbye ends the active conversation and returns to wake-word mode.
  // The WebSocket stays open; the next Hey Jarvis starts a fresh session.
  goodbyeBtn.addEventListener("click", async () => {
    try {
      await fetch("/api/session/end", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: "{}",
      });
    } catch (_) {}
    if (connected) {
      setStatus("Say Hey Jarvis", "vc-listening");
    } else {
      setStatus("Session ended", "vc-warn");
    }
    setError("");
  });

  muteBtn.addEventListener("click", async () => {
    muted = !muted;
    muteBtn.textContent = muted ? "Unmute" : "Mute";
    muteBtn.classList.toggle("muted", muted);
    // Also tell the server mute state via the dashboard mute API so the
    // server-side mute enforcement stays consistent.
    try {
      await fetch("/api/mute", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: JSON.stringify({ muted }),
      });
    } catch (_) {}
    setStatus(muted ? "Muted" : (connected ? "Say Hey Jarvis" : "Ready"), muted ? "vc-muted" : "vc-listening");
  });

  if (document.readyState === "complete") {
    setTimeout(startEvents, 0);
  } else {
    window.addEventListener("load", () => setTimeout(startEvents, 50));
  }

  // ---- initial state -------------------------------------------------------
  setStatus("Ready — press Listen for Hey Jarvis", "");
  stopBtn.hidden    = true;
  goodbyeBtn.hidden = true;
  muteBtn.hidden    = true;
  if (wakeHintEl)   wakeHintEl.hidden = true;
  if (fallbackEl)   fallbackEl.hidden = true;
})();
