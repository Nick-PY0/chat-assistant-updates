"""Small playback-aware gate for microphone PCM.

Browser acoustic echo cancellation does the important work when media and the
microphone are on the same device.  Some speakers still leak a low-level copy
of that media into the captured stream, though.  While a player reports that
media is running, this gate withholds that residual audio until it sees a
short, sustained rise consistent with somebody speaking.  A small pre-roll
keeps the first consonant of the command.

This is deliberately an energy gate, not an acoustic echo canceller.  It is
pure stdlib, keeps only a few hundred milliseconds of bounded PCM, and is
bypassed completely whenever media is not playing.
"""

from __future__ import annotations

from collections import deque

from chat_core.pcm import rms16


class PlaybackAwareMicGate:
    """Suppress likely playback residue without closing or muting the mic."""

    def __init__(
        self,
        speech_threshold: float,
        *,
        sample_rate: int = 16_000,
        onset_seconds: float = 0.12,
        release_seconds: float = 0.72,
        preroll_seconds: float = 0.24,
        calibration_seconds: float = 0.16,
        noise_ratio: float = 1.55,
    ) -> None:
        self.speech_threshold = max(1.0, float(speech_threshold))
        self.sample_rate = max(1, int(sample_rate))
        self.onset_seconds = max(0.0, float(onset_seconds))
        self.release_seconds = max(0.0, float(release_seconds))
        self.preroll_seconds = max(0.0, float(preroll_seconds))
        self.calibration_seconds = max(0.0, float(calibration_seconds))
        self.noise_ratio = max(1.0, float(noise_ratio))
        self.media_playing = False
        self._open = False
        self._loud_seconds = 0.0
        self._quiet_seconds = 0.0
        self._preroll: deque[tuple[bytes, float]] = deque()
        self._preroll_duration = 0.0
        self._noise_floor: float | None = None
        self._calibration_elapsed = 0.0

    @property
    def is_open(self) -> bool:
        return self._open

    def set_media_playing(self, playing: bool) -> None:
        playing = bool(playing)
        if playing != self.media_playing:
            self.media_playing = playing
            self.reset()

    def reset(self) -> None:
        self._close_utterance()
        self._noise_floor = None
        self._calibration_elapsed = 0.0

    def close_utterance(self) -> None:
        """Close an open speech window while retaining learned playback."""
        self._close_utterance()

    def _close_utterance(self) -> None:
        self._open = False
        self._loud_seconds = 0.0
        self._quiet_seconds = 0.0
        self._preroll.clear()
        self._preroll_duration = 0.0

    def feed(self, pcm: bytes) -> tuple[bytes, ...]:
        """Return zero or more PCM frames that are safe to forward.

        Frames pass through one-for-one outside media playback.  During media
        playback, a likely utterance opens the gate and silence closes it.
        """
        if not pcm:
            return ()
        if not self.media_playing:
            return (pcm,)

        duration = (len(pcm) // 2) / self.sample_rate
        if duration <= 0:
            return ()
        level = rms16(pcm)
        floor = self._noise_floor or 0.0
        loud = level >= max(self.speech_threshold, floor * self.noise_ratio)

        if self._open:
            if loud:
                self._quiet_seconds = 0.0
            else:
                self._quiet_seconds += duration
                if self._quiet_seconds >= self.release_seconds:
                    # Include the natural trailing silence, then require a
                    # fresh voice onset for the next command.
                    self._close_utterance()
            return (pcm,)

        self._append_preroll(pcm, duration)
        if self._calibration_elapsed < self.calibration_seconds:
            self._learn_noise(level, duration, calibrating=True)
            self._calibration_elapsed += duration
            return ()

        if loud:
            self._loud_seconds += duration
        else:
            self._loud_seconds = 0.0
            self._learn_noise(level, duration, calibrating=False)

        if self._loud_seconds < self.onset_seconds:
            return ()

        self._open = True
        self._quiet_seconds = 0.0
        ready = tuple(frame for frame, _ in self._preroll)
        self._preroll.clear()
        self._preroll_duration = 0.0
        return ready

    def _learn_noise(self, level: float, duration: float, *, calibrating: bool) -> None:
        if self._noise_floor is None:
            self._noise_floor = level
            return
        if calibrating:
            # A short time-weighted average establishes the current playback
            # leakage. One syllable during startup cannot dominate it.
            alpha = min(0.5, max(0.05, duration / max(self.calibration_seconds, 0.01)))
        elif level > self._noise_floor:
            alpha = min(0.20, duration / 0.40)
        else:
            # Do not let one quiet beat in a song collapse the learned floor.
            alpha = min(0.02, duration / 4.0)
        self._noise_floor += (level - self._noise_floor) * alpha

    def _append_preroll(self, pcm: bytes, duration: float) -> None:
        self._preroll.append((pcm, duration))
        self._preroll_duration += duration
        while (
            len(self._preroll) > 1
            and self._preroll_duration - self._preroll[0][1] >= self.preroll_seconds
        ):
            _, removed = self._preroll.popleft()
            self._preroll_duration -= removed
