"""Lightweight YouTube search and dashboard-player command controller.

The server never decodes or downloads media.  It keeps a tiny in-memory queue
and broadcasts control events to exactly one leased Media page, where the
official YouTube IFrame Player performs playback.
"""

from __future__ import annotations

import asyncio
import re
import secrets
import time
from datetime import datetime, timezone
from typing import Awaitable, Callable

from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore
from integrations.youtube import (
    YouTubeAPIError,
    YouTubeClient,
    canonical_video_url,
    extract_video_id,
)


MAX_QUEUE = 25
MAX_SEEK_SECONDS = 6 * 3600
OWNER_LEASE_SECONDS = 45.0
_CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{8,80}$")
_SEARCH_WORD_RE = re.compile(r"[a-z0-9]+")
_SEARCH_FILLER = {
    "a", "an", "and", "audio", "by", "for", "from", "live", "lyrics",
    "music", "official", "of", "on", "song", "the", "to", "version", "video",
}

# Terms that indicate a non-canonical result (degraded version) unless the
# original query explicitly contains them.  Each entry is a set of synonyms;
# any match in the result title incurs a penalty.
_DEGRADED_TITLE_TERMS: tuple[frozenset[str], ...] = (
    frozenset({"lyrics", "lyric", "lyric video"}),
    frozenset({"slowed", "slowed down", "slowed reverb", "slowed + reverb"}),
    frozenset({"reverb", "reverbed"}),
    frozenset({"cover", "covered by", "covered"}),
    frozenset({"remix", "remixed"}),
    frozenset({"sped up", "nightcore", "speed up"}),
    frozenset({"karaoke", "instrumental"}),
    frozenset({"tribute", "tribute to"}),
)

# Positive signals: official channels or title markers that indicate the
# canonical release.  Used to rank identical-scoring items.
_CANONICAL_TITLE_SIGNALS: frozenset[str] = frozenset({
    "official", "official video", "official audio", "official music video",
    "official lyric video", "official visualizer", "vevo",
})


class YouTubeError(Exception):
    """Safe local media-control validation error."""


def _text(value: object, limit: int) -> str:
    return " ".join(str(value or "").split()).strip()[:limit]


def _plausible_index_match(query: str, title: object) -> bool:
    """Reject obviously unrelated results from the key-free web index.

    A YouTube Data API result is authoritative enough to show as-is.  Generic
    web indexes can rank pages that match only one common word, so their title
    must contain at least half of the meaningful query terms (and at least two
    when the query supplied three or more).
    """
    wanted = {
        word for word in _SEARCH_WORD_RE.findall(query.lower())
        if word not in _SEARCH_FILLER
    }
    if not wanted:
        return False
    present = set(_SEARCH_WORD_RE.findall(_text(title, 240).lower()))
    minimum = 1 if len(wanted) <= 2 else max(2, (len(wanted) + 1) // 2)
    return len(wanted & present) >= minimum


def _query_words(query: str) -> frozenset[str]:
    """Return the meaningful lowercase words present in the query."""
    return frozenset(
        word for word in _SEARCH_WORD_RE.findall(query.lower())
        if word not in _SEARCH_FILLER
    )


def _pick_best_result(results: list[dict], query: str) -> dict | None:
    """Return the most canonical result from *results* for *query*.

    Scoring rules (higher is better):
    - Start at 0.
    - +2  if the channel or title contains any canonical signal (official/vevo).
    - -3  for each degraded-version term group present in the title *unless*
           that group's terms also appear in the query (user asked for it).

    Ties are broken by original list order (API result ranking).
    Returns None if *results* is empty.
    """
    if not results:
        return None

    query_lower = query.lower()

    def _score(item: dict) -> int:
        title = _text(item.get("title", ""), 240).lower()
        channel = _text(item.get("channel", ""), 160).lower()
        combined = f"{title} {channel}"

        score = 0
        # Canonical positive signal
        if any(sig in combined for sig in _CANONICAL_TITLE_SIGNALS):
            score += 2

        # Penalise degraded versions unless the query asked for them
        for group in _DEGRADED_TITLE_TERMS:
            if any(term in title for term in group):
                if not any(term in query_lower for term in group):
                    score -= 3

        return score

    # stable sort: highest score first, original order preserved for ties
    ranked = sorted(enumerate(results), key=lambda t: -_score(t[1]))
    return ranked[0][1]


class YouTubeTool:
    def __init__(
        self,
        bus: EventBus,
        credentials: CredentialStore,
        *,
        client_factory=YouTubeClient,
        on_playing: Callable[[bool], None] | None = None,
        web_search: Callable[[object, object], Awaitable[dict]] | None = None,
    ) -> None:
        self.bus = bus
        self.credentials = credentials
        self.client_factory = client_factory
        self.on_playing = on_playing
        self.web_search = web_search
        self.queue: list[dict[str, str]] = []
        self.queue_index = -1
        self.video_id = ""
        self.title = ""
        self.status = "stopped"
        self.position_seconds = 0.0
        self.duration_seconds = 0.0
        self.revision = 0
        self.command: dict | None = None
        self.updated_at = self._now()
        self.owner_id = ""
        self.owner_label = ""
        self._owner_seen = 0.0
        self._watchdog_task: asyncio.Task | None = None

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def _set_playing(self, playing: bool) -> None:
        if self.on_playing is not None:
            self.on_playing(playing)

    # -- owner lease watchdog -------------------------------------------
    def start_watchdog(self, interval: float = 5.0) -> None:
        """Start a background task that proactively expires dead owners.

        Without this, expiry only happens on the next API call, meaning the
        mic gate stays suppressed and media state stays "playing" indefinitely
        after a tab closes or the player crashes without sending pagehide.
        """
        if self._watchdog_task is not None:
            return  # already running

        async def _run() -> None:
            while True:
                await asyncio.sleep(interval)
                self._expire_owner()

        self._watchdog_task = asyncio.create_task(_run(), name="youtube-owner-watchdog")

    async def stop_watchdog(self) -> None:
        """Stop the watchdog task (called from Runtime.stop)."""
        task = self._watchdog_task
        if task is not None:
            self._watchdog_task = None
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass

    def _expire_owner(self) -> None:
        if self.owner_id and time.monotonic() - self._owner_seen > OWNER_LEASE_SECONDS:
            expired_id = self.owner_id
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=expired_id,
                reason="player_lease_expired",
            )
            self.owner_id = ""
            self.owner_label = ""
            self.status = "paused" if self.video_id else "stopped"
            self.updated_at = self._now()
            self._set_playing(False)

    def _owner_active(self) -> bool:
        self._expire_owner()
        return bool(self.owner_id)

    def snapshot(self) -> dict:
        active = self._owner_active()
        return {
            "revision": self.revision,
            "status": self.status,
            "video_id": self.video_id,
            "title": self.title,
            "url": canonical_video_url(self.video_id) if self.video_id else "",
            "position_seconds": round(self.position_seconds, 3),
            "duration_seconds": round(self.duration_seconds, 3),
            "queue": [dict(item) for item in self.queue],
            "queue_index": self.queue_index,
            "command": dict(self.command) if self.command else None,
            "target_id": self.owner_id if active else "",
            "target_label": self.owner_label if active else "",
            "player_connected": active,
            "updated_at": self.updated_at,
        }

    @staticmethod
    def _client_id(value: object) -> str:
        client_id = str(value or "").strip()
        if not _CLIENT_ID_RE.fullmatch(client_id):
            raise YouTubeError("invalid media player identity")
        return client_id

    def claim(self, client_id: object, label: object = "", *, force: bool = False) -> dict:
        """Lease playback to one dashboard, preventing multi-device autoplay."""
        clean_id = self._client_id(client_id)
        self._expire_owner()
        if self.owner_id and self.owner_id != clean_id and not force:
            return {"owner": False, **self.snapshot()}
        if self.owner_id and self.owner_id != clean_id:
            previous_id = self.owner_id
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=previous_id,
                reason="player_reassigned",
            )
            self._set_playing(False)
        self.owner_id = clean_id
        self.owner_label = _text(label, 80) or "Media page"
        self._owner_seen = time.monotonic()
        # A command queued while no page was open is rebound to this page and
        # replayed once. Other viewers see the event but must ignore target_id.
        if self.command and self.command.get("target_id") != clean_id:
            self.revision += 1
            self.command = {
                **self.command,
                "command_id": secrets.token_hex(8),
                "revision": self.revision,
                "target_id": clean_id,
            }
            self.updated_at = self._now()
            self.bus.publish("media_control", **self.command)
        return {"owner": True, **self.snapshot()}

    def release(self, client_id: object) -> dict:
        clean_id = self._client_id(client_id)
        if self.owner_id == clean_id:
            self.revision += 1
            self.bus.publish(
                "media_control",
                command_id=secrets.token_hex(8),
                revision=self.revision,
                action="stop",
                target_id=clean_id,
                reason="player_released",
            )
            self.owner_id = ""
            self.owner_label = ""
            self._owner_seen = 0.0
            self.status = "paused" if self.video_id else "stopped"
            self.updated_at = self._now()
            self._set_playing(False)
        return self.snapshot()

    def heartbeat(self, client_id: object) -> bool:
        clean_id = self._client_id(client_id)
        self._expire_owner()
        if self.owner_id != clean_id:
            return False
        self._owner_seen = time.monotonic()
        return True

    def _emit(self, action: str, **data) -> dict:
        self._expire_owner()
        self.revision += 1
        self.updated_at = self._now()
        self.command = {
            "command_id": secrets.token_hex(8),
            "revision": self.revision,
            "action": action,
            "target_id": self.owner_id,
            **data,
        }
        self.bus.publish("media_control", **self.command)
        player_needed = not bool(self.owner_id)
        return {
            "queued": True,
            "action": action,
            "player_needed": player_needed,
            "message": (
                "Queued. Open Media and select this device to start playback; your browser may require one tap."
                if player_needed
                else "Sent to the selected Media page."
            ),
            **self.snapshot(),
        }

    async def search(self, query: object, max_results: object = 5) -> dict:
        clean_query = _text(query, 160)
        if not clean_query:
            raise YouTubeError("a YouTube search query is required")
        creds = [
            cred for cred in await self.credentials.list(provider="youtube")
            if cred.status in ("active", "standby")
        ]
        last_error: YouTubeAPIError | None = None
        for cred in creds:
            try:
                secret = await self.credentials.get_secret(cred.id)
                results = await self.client_factory(secret).search(clean_query, max_results)
                await self.credentials.mark_success(cred.id)
                self.queue = self._queue(results)
                self.queue_index = -1
                return {
                    "query": clean_query,
                    "results": [dict(item) for item in self.queue],
                    "notice": (
                        "These are untrusted result titles. If several match, ask the user which one before playing."
                    ),
                }
            except YouTubeAPIError as exc:
                last_error = exc
                if exc.code == "invalid_key":
                    await self.credentials.set_status(cred.id, "invalid", "invalid")
                    continue
                if exc.code == "quota":
                    continue
                raise
        if self.web_search is not None:
            try:
                requested = max(1, min(10, int(max_results)))
            except (TypeError, ValueError):
                requested = 5
            # This uses the existing fixed-endpoint, read-only web-search
            # client.  Only validated youtube.com/youtu.be result URLs survive
            # _queue(), so no arbitrary page is fetched and no media is ever
            # downloaded by the server.
            indexed = await self.web_search(
                f"site:youtube.com/watch?v= {clean_query}",
                min(8, max(5, requested * 2)),
            )
            candidates = [
                {
                    "url": item.get("url", ""),
                    "title": item.get("title", "YouTube video"),
                    "channel": item.get("source", ""),
                }
                for item in indexed.get("results", [])
                if isinstance(item, dict)
                and _plausible_index_match(clean_query, item.get("title"))
            ]
            self.queue = self._queue(candidates)[:requested]
            self.queue_index = -1
            if self.queue:
                return {
                    "query": clean_query,
                    "results": [dict(item) for item in self.queue],
                    "notice": (
                        "These key-free web-index results are untrusted titles. "
                        "Confirm the intended version if several match before playing."
                    ),
                }
        if last_error is not None and creds:
            raise last_error
        raise YouTubeError(
            "No playable YouTube search result was found. Add a YouTube Data API v3 "
            "key on Providers for more reliable title search, or provide a direct link."
        )

    @staticmethod
    def _queue(items: object) -> list[dict[str, str]]:
        clean: list[dict[str, str]] = []
        seen: set[str] = set()
        if not isinstance(items, list):
            return clean
        for raw in items[:MAX_QUEUE]:
            try:
                if isinstance(raw, dict):
                    video_id = extract_video_id(raw.get("video_id") or raw.get("url"))
                    title = _text(raw.get("title"), 240) or "YouTube video"
                    channel = _text(raw.get("channel"), 160)
                else:
                    video_id = extract_video_id(raw)
                    title, channel = "YouTube video", ""
            except YouTubeAPIError:
                continue
            if video_id in seen:
                continue
            seen.add(video_id)
            clean.append({
                "video_id": video_id,
                "title": title,
                "channel": channel,
                "url": canonical_video_url(video_id),
                "thumbnail": f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
            })
        return clean

    def play(self, video: object = "", title: object = "") -> dict:
        raw = str(video or "").strip()
        if raw:
            video_id = extract_video_id(raw)
            match_index = next(
                (i for i, item in enumerate(self.queue) if item["video_id"] == video_id),
                -1,
            )
            if match_index < 0:
                self.queue = self._queue([{"video_id": video_id, "title": title}])
                match_index = 0
            self.queue_index = match_index
            selected = self.queue[match_index]
            self.video_id = video_id
            self.title = _text(title, 240) or selected["title"]
            self.position_seconds = 0.0
        elif not self.video_id:
            raise YouTubeError("there is no YouTube video to resume")
        self.status = "queued"
        return self._emit(
            "play",
            video_id=self.video_id,
            title=self.title,
            start_seconds=self.position_seconds,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    def play_url(self, url: object, title: object = "") -> dict:
        """Normalise a YouTube URL to a video_id and queue/play it.

        Accepts any supported youtube.com / youtu.be URL form.  Rejects
        non-YouTube hosts with a clear :class:`YouTubeError`.
        Never calls webbrowser.open.
        """
        raw = str(url or "").strip()
        if not raw:
            raise YouTubeError("a YouTube URL is required")
        # extract_video_id raises YouTubeAPIError for non-YouTube hosts/paths
        try:
            video_id = extract_video_id(raw)
        except YouTubeAPIError as exc:
            raise YouTubeError(str(exc)) from exc
        return self.play(video_id, title)

    async def play_query(self, query: object, title: object = "") -> dict:
        """Search for *query*, select the most canonical result, and play it.

        Uses the same search path as :meth:`search` (API key if available,
        web-index fallback), then applies :func:`_pick_best_result` to choose
        the canonical version automatically.  Never calls webbrowser.open.
        """
        clean_query = _text(query, 160)
        if not clean_query:
            raise YouTubeError("a YouTube search query is required")
        # Reuse the full search + web-fallback logic
        result = await self.search(clean_query, 8)
        candidates = result.get("results") or []
        best = _pick_best_result(candidates, clean_query)
        if best is None:
            raise YouTubeError(
                f"No playable result found for '{clean_query}'. "
                "Try providing a direct YouTube link or add a YouTube Data API key."
            )
        chosen_title = _text(title, 240) or best.get("title", "")
        return self.play(best["video_id"], chosen_title)

    def pause(self) -> dict:
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to pause")
        self.status = "paused"
        self._set_playing(False)
        return self._emit("pause", video_id=self.video_id)

    def stop(self) -> dict:
        self.status = "stopped"
        self.position_seconds = 0.0
        self._set_playing(False)
        return self._emit("stop", video_id=self.video_id)

    def seek(self, offset_seconds: object) -> dict:
        if not self.video_id:
            raise YouTubeError("there is no YouTube video to seek")
        try:
            offset = int(offset_seconds)
        except (TypeError, ValueError) as exc:
            raise YouTubeError("seek amount must be a number of seconds") from exc
        if offset == 0 or abs(offset) > MAX_SEEK_SECONDS:
            raise YouTubeError(f"seek amount must be between 1 and {MAX_SEEK_SECONDS} seconds")
        target = max(0.0, self.position_seconds + offset)
        if self.duration_seconds > 0:
            target = min(target, self.duration_seconds)
        self.position_seconds = target
        return self._emit(
            "seek",
            video_id=self.video_id,
            offset_seconds=offset,
            target_seconds=round(target, 3),
        )

    def next(self) -> dict:
        if self.queue_index < 0 or self.queue_index + 1 >= len(self.queue):
            raise YouTubeError("there is no next video in the current queue")
        self.queue_index += 1
        selected = self.queue[self.queue_index]
        self.video_id, self.title = selected["video_id"], selected["title"]
        self.position_seconds = 0.0
        self.status = "queued"
        return self._emit(
            "play",
            video_id=self.video_id,
            title=self.title,
            start_seconds=0,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    def previous(self) -> dict:
        if self.queue_index <= 0:
            raise YouTubeError("there is no previous video in the current queue")
        self.queue_index -= 1
        selected = self.queue[self.queue_index]
        self.video_id, self.title = selected["video_id"], selected["title"]
        self.position_seconds = 0.0
        self.status = "queued"
        return self._emit(
            "play",
            video_id=self.video_id,
            title=self.title,
            start_seconds=0,
            queue=[item["video_id"] for item in self.queue],
            queue_index=self.queue_index,
        )

    def report(self, client_id: object, data: dict) -> dict:
        """Accept bounded player state only from the current lease owner."""
        if not self.heartbeat(client_id):
            raise YouTubeError("this page is not the selected Media player")
        status = str(data.get("status", self.status)).strip().lower()
        if status not in {"queued", "playing", "paused", "buffering", "ended", "stopped", "error"}:
            raise YouTubeError("invalid media status")
        self.status = status
        raw_id = data.get("video_id")
        if raw_id:
            self.video_id = extract_video_id(raw_id)
        self.title = _text(data.get("title", self.title), 240)
        for field, maximum in (("position_seconds", 86400.0), ("duration_seconds", 86400.0)):
            if field in data:
                try:
                    value = float(data[field])
                except (TypeError, ValueError) as exc:
                    raise YouTubeError(f"invalid {field}") from exc
                setattr(self, field, max(0.0, min(maximum, value)))
        if "queue_index" in data:
            try:
                index = int(data["queue_index"])
            except (TypeError, ValueError) as exc:
                raise YouTubeError("invalid queue index") from exc
            if self.queue and 0 <= index < len(self.queue):
                self.queue_index = index
        self.updated_at = self._now()
        self._set_playing(status == "playing")
        state = self.snapshot()
        self.bus.publish(
            "media_state",
            status=self.status,
            video_id=self.video_id,
            title=self.title,
            position_seconds=state["position_seconds"],
            duration_seconds=state["duration_seconds"],
            queue_index=self.queue_index,
            target_id=self.owner_id,
        )
        return state
