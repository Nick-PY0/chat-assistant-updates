// Behavior test for the media.js iframe-event identity contract.
//
// This runs the REAL apps/dashboard/static/{app.js,media.js} inside jsdom with
// scripts enabled, drives the page into the "active iframe" state via a stubbed
// /api/media/claim response, then exercises the window "message" listener:
//
//   1. A spoofed WRONG-ORIGIN message is ignored.
//   2. A spoofed WRONG-ID / wrong-source message is ignored.
//   3. A genuine YouTube onError 101 event from the active iframe removes the
//      iframe and renders exactly one validated
//      https://www.youtube.com/watch?v=<video_id> link with target=_blank and
//      rel="noopener noreferrer".
//   4. The same holds for onError 150.
//
// Exit code 0 = all assertions passed, 1 = a failure.
import { JSDOM, VirtualConsole } from "jsdom";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const HERE = dirname(fileURLToPath(import.meta.url));
const STATIC = resolve(HERE, "../../apps/dashboard/static");

const APP_JS = readFileSync(resolve(STATIC, "app.js"), "utf-8");
const MEDIA_JS = readFileSync(resolve(STATIC, "media.js"), "utf-8");

const VIDEO_ID = "dQw4w9WgXcQ"; // valid 11-char id
const YT_ORIGIN = "https://www.youtube.com";

let failures = 0;
function check(cond, label) {
  if (cond) {
    console.log(`PASS ${label}`);
  } else {
    console.log(`FAIL ${label}`);
    failures++;
  }
}

// Minimal page mirroring apps/dashboard/templates/media.html element IDs, plus
// the csrf meta app.js reads and the two <script> tags in load order.
const HTML = `<!doctype html><html><head>
  <meta name="csrf" content="test-csrf-token">
  <meta name="theme-color" content="#f2f4f8">
</head><body>
  <section class="media-page" id="media-page">
    <span id="media-connection">Connecting</span>
    <button id="media-takeover" type="button" hidden></button>
    <form id="media-request-form"><input id="media-request-input"><button id="media-request-button" type="submit"></button></form>
    <div class="media-stage" id="media-stage">
      <div id="media-placeholder"></div>
      <button id="media-tap-play" type="button" hidden></button>
    </div>
    <strong id="media-title">Nothing selected</strong>
    <span id="media-time">0:00 / 0:00</span>
    <a id="media-youtube-link" href="https://www.youtube.com/" target="_blank" rel="noopener" hidden></a>
    <button id="media-previous" type="button"></button>
    <button id="media-seek-back" type="button"></button>
    <button id="media-play-pause" type="button">Play</button>
    <button id="media-stop" type="button"></button>
    <button id="media-seek-forward" type="button"></button>
    <button id="media-next" type="button"></button>
    <input id="media-seek-seconds" type="number" min="1" max="3600" step="1" value="10">
    <div id="media-message" role="status"></div>
    <h2 id="media-queue-heading">Queue</h2>
    <span id="media-queue-count">0 videos</span>
    <div id="media-results-message"></div>
    <ol id="media-queue"></ol>
  </section>
  <script>${APP_JS}</script>
  <script>${MEDIA_JS}</script>
</body></html>`;

// Stubbed API: /api/media/claim reflects the posted client_id back as
// target_id (so the page becomes owner) and hands back a "play" command for
// VIDEO_ID, which drives ensureIframe() to create the active <iframe>.
function makeFetchStub() {
  return async (url, opts = {}) => {
    const path = String(url).replace(/^https?:\/\/[^/]+/, "");
    let body = {};
    try { body = opts.body ? JSON.parse(opts.body) : {}; } catch { /* ignore */ }
    const clientId = body.client_id || "";

    const baseState = {
      revision: 1,
      status: "queued",
      video_id: VIDEO_ID,
      title: "Test video",
      url: `${YT_ORIGIN}/watch?v=${VIDEO_ID}`,
      position_seconds: 0,
      duration_seconds: 0,
      queue: [],
      queue_index: -1,
      target_id: clientId,
      target_label: "Media page",
      player_connected: true,
    };

    let payload = baseState;
    if (path.startsWith("/api/media/claim")) {
      payload = {
        owner: true,
        ...baseState,
        command: {
          command_id: "cmd-1",
          revision: 1,
          action: "play",
          target_id: clientId,
          video_id: VIDEO_ID,
          title: "Test video",
          start_seconds: 0,
        },
      };
    }
    return {
      ok: true,
      status: 200,
      json: async () => payload,
      text: async () => JSON.stringify(payload),
      headers: { getSetCookie: () => [] },
    };
  };
}

async function waitFor(predicate, timeoutMs = 4000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (predicate()) return true;
    await new Promise((r) => setTimeout(r, 25));
  }
  return false;
}

// Build a fresh jsdom page driven into the "active iframe" state.
async function bootPage() {
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => console.log("jsdomError:", (e && e.message) || e));

  const dom = new JSDOM(HTML, {
    url: "http://127.0.0.1:8756/media",
    runScripts: "dangerously",
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      window.fetch = makeFetchStub();
      window.alert = () => {};
      if (!window.crypto || !window.crypto.getRandomValues) {
        window.crypto = {
          getRandomValues: (arr) => {
            for (let i = 0; i < arr.length; i++) arr[i] = (i * 7 + 3) & 0xff;
            return arr;
          },
        };
      }
    },
  });

  const { window } = dom;
  const { document } = window;
  const activeIframe = () => document.getElementById("youtube-iframe");

  const ready = await waitFor(() => activeIframe() && activeIframe().contentWindow);
  return { dom, window, document, activeIframe, ready };
}

function dispatchYouTubeMessage(window, { origin, source, data }) {
  const evt = new window.MessageEvent("message", { data, origin, source: source || null });
  window.dispatchEvent(evt);
}

const errorPayload = (code, id = "youtube-iframe") =>
  JSON.stringify({ event: "onError", id, info: code });

// Verify spoofed messages are ignored using a fresh page.
async function testSpoofedMessagesIgnored() {
  const { dom, window, document, activeIframe, ready } = await bootPage();
  check(ready, "active iframe #youtube-iframe is created after claim");
  if (!ready) { dom.window.close(); return; }
  const iframe = activeIframe();

  check(iframe.id === "youtube-iframe", "iframe id is youtube-iframe");
  check(
    iframe.src.startsWith(`${YT_ORIGIN}/embed/${VIDEO_ID}`),
    "iframe src is the official embed URL for the video id"
  );

  // 1. Wrong origin
  dispatchYouTubeMessage(window, {
    origin: "https://evil.example.com",
    source: iframe.contentWindow,
    data: errorPayload(101),
  });
  check(activeIframe() !== null, "wrong-origin onError 101 is IGNORED (iframe still present)");

  // 2. Correct origin, wrong id string
  dispatchYouTubeMessage(window, {
    origin: YT_ORIGIN,
    source: iframe.contentWindow,
    data: errorPayload(101, "player"),
  });
  check(activeIframe() !== null, "wrong-id (id=player) onError 101 is IGNORED (iframe still present)");

  // 3. Correct origin + correct id, but a DIFFERENT source window
  const otherFrame = document.createElement("iframe");
  document.body.appendChild(otherFrame);
  dispatchYouTubeMessage(window, {
    origin: YT_ORIGIN,
    source: otherFrame.contentWindow,
    data: errorPayload(101),
  });
  check(activeIframe() !== null, "wrong-source (foreign window) onError 101 is IGNORED (iframe still present)");

  dom.window.close();
}

// Verify a genuine onError removes the iframe and renders the exact fallback.
async function testGenuineError(code) {
  const { dom, window, document, activeIframe, ready } = await bootPage();
  check(ready, `[${code}] active iframe is created after claim`);
  if (!ready) { dom.window.close(); return; }
  const iframe = activeIframe();

  dispatchYouTubeMessage(window, {
    origin: YT_ORIGIN,
    source: iframe.contentWindow,
    data: errorPayload(code),
  });
  await waitFor(() => activeIframe() === null, 1000);
  check(activeIframe() === null, `genuine onError ${code} REMOVES the active iframe`);

  const links = document.querySelectorAll("#media-message a");
  check(links.length === 1, `exactly one fallback link is rendered for onError ${code}`);
  const link = links[0];
  check(!!link, `onError ${code} renders a fallback link`);
  if (link) {
    check(
      link.getAttribute("href") === `${YT_ORIGIN}/watch?v=${VIDEO_ID}`,
      `onError ${code} link href is exactly the validated watch URL`
    );
    check(link.getAttribute("target") === "_blank", `onError ${code} link target=_blank`);
    check(
      link.getAttribute("rel") === "noopener noreferrer",
      `onError ${code} link rel="noopener noreferrer"`
    );
  }

  dom.window.close();
}

async function run() {
  await testSpoofedMessagesIgnored();
  await testGenuineError(101);
  await testGenuineError(150);
}

run()
  .then(() => {
    console.log(failures === 0 ? "ALL MEDIA EVENT CHECKS PASSED" : `${failures} FAILURES`);
    process.exit(failures === 0 ? 0 : 1);
  })
  .catch((e) => {
    console.log("FATAL:", e && e.stack ? e.stack : e);
    process.exit(2);
  });
