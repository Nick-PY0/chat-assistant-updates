"""Small playback-aware gate for microphone PCM.

Browser acoustic echo cancellation does the important work when media and the
microphone are on the same device.  Some speakers still leak a low-level copy
of that media into the captured stream, though.  While a player reports that
media is running, this gate withholds that residual audio until it sees a
short, sustained rise consistent with somebody speaking.  A small pre-roll
keeps the first consonant of the command.

Assistant reply playback is also gated: after the assistant stops speaking, a
short post-playback settling tail (ASSISTANT_SETTLE_SECONDS) suppresses the
final speaker reverb before the gate opens.  This avoids the assistant's own
tail becoming the first words of the next turn.

This is deliberately an energy gate, not an acoustic echo canceller.  It is
pure stdlib, keeps only a few hundred milliseconds of bounded PCM, and is
bypassed completely whenever neither media nor the assistant is playing.
"""

from __future__ import annotations

import time
from collections import deque

from chat_core.pcm import rms16

# Post-playback settling tail for assistant TTS: suppress input for this long
# after assistant_playing transitions False, to absorb speaker reverb.
ASSISTANT_SETTLE_SECONDS: float = 0.40   # 400 ms (within 350-500 ms spec)


class PlaybackAwareMicGate:
    """Suppress likely playback residue without closing or muting the mic."""

    def __init__(
        self,
        speech_threshold: float,
        *,
        sample_rate: int = 16_000,
        onset_seconds: float = 0.12,
        release_seconds: float = 0.72,
        preroll_seconds: float = 0.24,
        calibration_seconds: float = 0.16,
        noise_ratio: float = 1.55,
        assistant_settle_seconds: float = ASSISTANT_SETTLE_SECONDS,
    ) -> None:
        self.speech_threshold = max(1.0, float(speech_threshold))
        self.sample_rate = max(1, int(sample_rate))
        self.onset_seconds = max(0.0, float(onset_seconds))
        self.release_seconds = max(0.0, float(release_seconds))
        self.preroll_seconds = max(0.0, float(preroll_seconds))
        self.calibration_seconds = max(0.0, float(calibration_seconds))
        self.noise_ratio = max(1.0, float(noise_ratio))
        self.assistant_settle_seconds = max(0.0, float(assistant_settle_seconds))

        self.media_playing = False
        self._assistant_playing = False
        # Wall-clock deadline until which post-playback settling suppresses input.
        self._settle_until: float = 0.0

        self._open = False
        self._loud_seconds = 0.0
        self._quiet_seconds = 0.0
        self._preroll: deque[tuple[bytes, float]] = deque()
        self._preroll_duration = 0.0
        self._noise_floor: float | None = None
        self._calibration_elapsed = 0.0

    @property
    def is_open(self) -> bool:
        return self._open

    @property
    def assistant_playing(self) -> bool:
        return self._assistant_playing

    def set_media_playing(self, playing: bool) -> None:
        playing = bool(playing)
        if playing != self.media_playing:
            self.media_playing = playing
            self.reset()

    def set_assistant_playing(self, playing: bool) -> None:
        """Report whether the assistant TTS is currently playing.

        When playback ends (False), a short settling tail is armed so that
        speaker reverb is suppressed before the gate re-opens for user speech.
        """
        playing = bool(playing)
        if playing == self._assistant_playing:
            return
        self._assistant_playing = playing
        if playing:
            # Assistant started speaking — activate gating immediately and
            # reset settling deadline.
            self._settle_until = 0.0
            self.reset()
        else:
            # Assistant finished — arm post-playback settling tail.
            self._settle_until = time.monotonic() + self.assistant_settle_seconds
            # Close any open utterance so a stale onset cannot carry over.
            self._close_utterance()

    @property
    def _any_playing(self) -> bool:
        """True if either media or assistant is currently playing."""
        return self.media_playing or self._assistant_playing

    @property
    def _in_settling_tail(self) -> bool:
        """True during the post-playback reverb settling window."""
        if self._any_playing:
            return False
        return time.monotonic() < self._settle_until

    def reset(self) -> None:
        self._close_utterance()
        self._noise_floor = None
        self._calibration_elapsed = 0.0

    def close_utterance(self) -> None:
        """Close an open speech window while retaining learned playback."""
        self._close_utterance()

    def _close_utterance(self) -> None:
        self._open = False
        self._loud_seconds = 0.0
        self._quiet_seconds = 0.0
        self._preroll.clear()
        self._preroll_duration = 0.0

    def feed(self, pcm: bytes) -> tuple[bytes, ...]:
        """Return zero or more PCM frames that are safe to forward.

        Frames pass through one-for-one outside media and assistant playback.
        During playback (or post-playback settling), a likely utterance opens
        the gate and silence closes it.
        """
        if not pcm:
            return ()

        # If nothing is playing and the settling tail has expired, passthrough.
        if not self._any_playing and not self._in_settling_tail:
            return (pcm,)

        duration = (len(pcm) // 2) / self.sample_rate
        if duration <= 0:
            return ()
        level = rms16(pcm)
        floor = self._noise_floor or 0.0
        loud = level >= max(self.speech_threshold, floor * self.noise_ratio)

        if self._open:
            if loud:
                self._quiet_seconds = 0.0
            else:
                self._quiet_seconds += duration
                if self._quiet_seconds >= self.release_seconds:
                    # Include the natural trailing silence, then require a
                    # fresh voice onset for the next command.
                    self._close_utterance()
            return (pcm,)

        self._append_preroll(pcm, duration)
        if self._calibration_elapsed < self.calibration_seconds:
            self._learn_noise(level, duration, calibrating=True)
            self._calibration_elapsed += duration
            return ()

        if loud:
            self._loud_seconds += duration
        else:
            self._loud_seconds = 0.0
            self._learn_noise(level, duration, calibrating=False)

        if self._loud_seconds < self.onset_seconds:
            return ()

        self._open = True
        self._quiet_seconds = 0.0
        ready = tuple(frame for frame, _ in self._preroll)
        self._preroll.clear()
        self._preroll_duration = 0.0
        return ready

    def _learn_noise(self, level: float, duration: float, *, calibrating: bool) -> None:
        if self._noise_floor is None:
            self._noise_floor = level
            return
        if calibrating:
            # A short time-weighted average establishes the current playback
            # leakage. One syllable during startup cannot dominate it.
            alpha = min(0.5, max(0.05, duration / max(self.calibration_seconds, 0.01)))
        elif level > self._noise_floor:
            alpha = min(0.20, duration / 0.40)
        else:
            # Do not let one quiet beat in a song collapse the learned floor.
            alpha = min(0.02, duration / 4.0)
        self._noise_floor += (level - self._noise_floor) * alpha

    def _append_preroll(self, pcm: bytes, duration: float) -> None:
        self._preroll.append((pcm, duration))
        self._preroll_duration += duration
        while (
            len(self._preroll) > 1
            and self._preroll_duration - self._preroll[0][1] >= self.preroll_seconds
        ):
            _, removed = self._preroll.popleft()
            self._preroll_duration -= removed
