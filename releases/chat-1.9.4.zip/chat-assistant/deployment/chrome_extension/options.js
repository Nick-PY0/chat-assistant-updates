// options.js — pairing page logic.
//
// The pairing token is NEVER persisted — it is held only in memory in this
// page while the user types and is cleared from the DOM immediately after
// the background worker sends the hello frame. Only the bridge base URL is
// stored. The bridge secret is written by the background worker after the
// server issues it.

import {
  STORAGE_KEYS,
  MSG,
  validateBridgeBase,
  validatePairingToken,
} from "./common.js";

const $ = (id) => document.getElementById(id);
const bridgeEl      = $("bridge");
const tokenEl       = $("token");
const showTokenEl   = $("showToken");
const msgEl         = $("msg");
const statusEl      = $("status");
const statusDetail  = $("statusDetail");

function setMsg(text, kind) {
  msgEl.textContent = text || "";
  msgEl.className   = "msg" + (kind ? " " + kind : "");
}

showTokenEl.addEventListener("change", () => {
  tokenEl.type = showTokenEl.checked ? "text" : "password";
});

function sendToBg(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (resp) => {
      void chrome.runtime.lastError;
      resolve(resp || { ok: false });
    });
  });
}

async function loadBridgeBase() {
  const d = await chrome.storage.local.get([STORAGE_KEYS.bridgeBase]);
  if (d[STORAGE_KEYS.bridgeBase] && !bridgeEl.value) {
    bridgeEl.value = d[STORAGE_KEYS.bridgeBase];
  }
}

async function loadStatus() {
  const res = await sendToBg({ type: MSG.GET_STATUS });
  const s   = (res && res.status) || {};
  if (s.paired && s.connected) {
    statusEl.textContent = "Connected";
    statusEl.className   = "status good";
    statusDetail.textContent = s.detail ? "Bridge: " + s.detail : "Ready.";
  } else if (s.paired && !s.connected) {
    statusEl.textContent = "Paired · reconnecting";
    statusEl.className   = "status warn";
    statusDetail.textContent = s.detail || "Trying to reach the bridge…";
  } else {
    statusEl.textContent = "Not paired";
    statusEl.className   = "status";
    statusDetail.textContent = s.detail || "Enter the bridge URL and pairing token above.";
  }
}

$("test").addEventListener("click", async () => {
  setMsg("Testing connection…");
  let base;
  try { base = validateBridgeBase(bridgeEl.value); } catch (e) { return setMsg(e.message, "err"); }
  const res = await sendToBg({ type: MSG.TEST_BRIDGE, bridgeBase: base });
  if (res && res.ok) setMsg("Bridge reachable at /ws/companion", "ok");
  else setMsg("Could not reach bridge: " + ((res && res.reason) || "unknown"), "err");
});

$("pair").addEventListener("click", async () => {
  setMsg("");
  let base, token;
  try   { base  = validateBridgeBase(bridgeEl.value); }
  catch (e) { return setMsg(e.message, "err"); }
  try   { token = validatePairingToken(tokenEl.value); }
  catch (e) { return setMsg(e.message, "err"); }

  // Store the bridge base URL. The token is NEVER stored.
  await chrome.storage.local.set({ [STORAGE_KEYS.bridgeBase]: base });

  // Clear the token field immediately — it goes only to the background worker
  // in memory, never to storage.
  tokenEl.value         = "";
  showTokenEl.checked   = false;
  tokenEl.type          = "password";

  // Ask the background worker to open the socket and send hello(token).
  const res = await sendToBg({ type: MSG.PAIR, token, bridgeBase: base });
  if (res && res.ok) {
    setMsg("Pairing initiated. Status will update below when the bridge confirms.", "ok");
  } else {
    setMsg("Background worker did not accept the request: " + ((res && res.reason) || ""), "warn");
  }
  setTimeout(loadStatus, 800);
  setTimeout(loadStatus, 2500);
});

$("unpair").addEventListener("click", async () => {
  await sendToBg({ type: MSG.UNPAIR });
  bridgeEl.value = "";
  setMsg("Unpaired. Remember to revoke the token in the Chat dashboard.", "ok");
  loadStatus();
});

loadBridgeBase();
loadStatus();
setInterval(loadStatus, 3000);
