"""Chat — single-process launcher.

Runs every service (audio, Gemini gateway, tools, pulse, dashboard) as
asyncio tasks in ONE quiet process. Designed to sit in a minimal console
window and use as close to zero resources as possible while idle.

Usage:
  python run_chat.py                  # everything (voice auto-disables if
                                      # audio packages/hardware are missing)
  python run_chat.py --dashboard-only # no voice, no cloud, no pulse
  python run_chat.py --no-voice       # cloud + dashboard, no microphone
  python run_chat.py --verbose        # more console output
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import logging
import os
import socket
import sys

RESTART_CODE = 42  # run_chat.bat relaunches when Chat exits with this code

# Windows named-mutex handle held for the lifetime of this process so that
# a second launch detects the clash atomically.
_WIN_MUTEX = None


def _install_windows_disconnect_handler() -> None:
    """Keep normal browser/socket disconnects out of the Windows console.

    The Proactor loop can report a peer's ordinary TCP reset a second time
    from its internal ``connection_lost`` callback, after the WebSocket
    coroutine has already caught the disconnect.  It is not an app crash and
    only obscures useful diagnostics such as audio-device failures.
    """
    if sys.platform != "win32":
        return
    loop = asyncio.get_running_loop()
    previous = loop.get_exception_handler()

    def handle(loop: asyncio.AbstractEventLoop, context: dict) -> None:
        exc = context.get("exception")
        if isinstance(exc, ConnectionResetError) and getattr(exc, "winerror", None) == 10054:
            logging.getLogger("asyncio").debug("peer closed a browser/network connection")
            return
        if previous is not None:
            previous(loop, context)
        else:
            loop.default_exception_handler(context)

    loop.set_exception_handler(handle)


def _acquire_windows_mutex() -> bool:
    """On Windows, create a named mutex that is held until the process exits.

    Returns True if the mutex was newly acquired (no other instance running),
    False if the mutex already existed (another instance is running).
    On non-Windows platforms always returns True (no-op).
    """
    global _WIN_MUTEX
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        import ctypes.wintypes

        _MUTEX_NAME = "Global\\ChatAssistantSingleInstance"
        handle = ctypes.windll.kernel32.CreateMutexW(None, True, _MUTEX_NAME)
        last_err = ctypes.windll.kernel32.GetLastError()
        _ERROR_ALREADY_EXISTS = 183
        if handle and last_err == _ERROR_ALREADY_EXISTS:
            ctypes.windll.kernel32.CloseHandle(handle)
            return False
        if handle:
            _WIN_MUTEX = handle  # keep alive for process lifetime
        return True
    except Exception:
        # If the mutex API fails for any reason, fall through to port probe.
        return True


def _port_already_answering(host: str, port: int) -> bool:
    """Backward-compatible alias for dashboard_port_available.

    Returns True when something is already listening (port is NOT available),
    mirroring the old semantics used by existing tests.
    """
    return not dashboard_port_available(host, port)


def dashboard_port_available(host: str, port: int) -> bool:
    """Check the dashboard bind before starting audio/cloud services.

    A second run used to initialize the whole voice stack, print that Chat
    was running, and only then fail inside uvicorn with WinError 10048.
    On non-Windows (and as a secondary check on Windows when the mutex passed)
    this confirms whether the port is free.
    """
    family = socket.AF_INET6 if ":" in host else socket.AF_INET
    try:
        with socket.socket(family, socket.SOCK_STREAM) as probe:
            if sys.platform == "win32" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            probe.bind((host, port))
    except OSError:
        return False
    return True


def _verify_chat_on_port(host: str, port: int) -> bool:
    """Return True when the process already on *port* identifies as Chat.

    Tries a lightweight HTTP probe to /api/healthz. Any failure (connection
    refused, timeout, wrong response) returns False; callers must not assume
    the service is Chat without this confirmation.
    """
    probe_host = "127.0.0.1"
    if host not in ("", "0.0.0.0", "::"):
        probe_host = host
    # Use http; the probe should succeed regardless of TLS config
    import urllib.request
    import urllib.error

    for scheme in ("http", "https"):
        try:
            import ssl
            ctx = ssl.create_default_context() if scheme == "https" else None
            if ctx:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            url = f"{scheme}://{probe_host}:{port}/api/healthz"
            with urllib.request.urlopen(url, timeout=1.5, context=ctx) as resp:
                import json
                data = json.loads(resp.read())
                return data.get("app") == "chat-assistant"
        except Exception:
            pass
    return False


def _peek_data_dir():
    """Resolve the data dir WITHOUT importing chat_core — the update swap
    below must happen before any app module is loaded."""
    from pathlib import Path

    for i, arg in enumerate(sys.argv):
        if arg == "--data-dir" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1]).expanduser()
        if arg.startswith("--data-dir="):
            return Path(arg.split("=", 1)[1]).expanduser()
    override = os.environ.get("CHAT_DATA_DIR")
    if override:
        return Path(override).expanduser()
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "ChatAssistant"
    return Path.home() / ".chat-assistant"


def apply_pending_update() -> None:
    """If the in-app updater staged a new version (data/updates/pending),
    swap it in now. Source installs copy the files over this folder and boot
    straight into the new code; exe installs hand off to a tiny helper
    script (files are locked while the exe runs) and exit."""
    import shutil
    from pathlib import Path

    pending = _peek_data_dir() / "updates" / "pending"
    if not pending.is_dir():
        return
    if not ((pending / "run_chat.py").exists() or (pending / "Chat.exe").exists()):
        return  # not a Chat build; ignore
    if getattr(sys, "frozen", False):
        _apply_update_frozen(pending)
        return
    target = Path(__file__).resolve().parent
    try:
        shutil.copytree(pending, target, dirs_exist_ok=True)
        shutil.rmtree(pending, ignore_errors=True)
        (pending.parent / "pending.json").unlink(missing_ok=True)
        print("Update applied.")
    except Exception as exc:
        print(f"Update could not be applied ({type(exc).__name__}); starting the current version.")


def _apply_update_frozen(pending) -> None:
    """Chat.exe cannot overwrite itself while running: a helper bat waits
    for this process to exit, copies the new files in, and starts Chat."""
    import subprocess
    import tempfile
    from pathlib import Path

    exe = Path(sys.executable).resolve()
    bat = Path(tempfile.gettempdir()) / "chat_apply_update.bat"
    bat.write_text(
        "@echo off\r\n"
        "timeout /t 2 /nobreak >nul\r\n"
        f'xcopy /e /y /q "{pending}\\*" "{exe.parent}\\" >nul\r\n'
        f'rmdir /s /q "{pending}"\r\n'
        f'del "{pending.parent}\\pending.json" >nul 2>&1\r\n'
        f'start "" "{exe}"\r\n'
        'del "%~f0"\r\n'
    )
    subprocess.Popen(
        ["cmd", "/c", str(bat)],
        creationflags=0x00000008 | 0x00000200,  # DETACHED | NEW_PROCESS_GROUP
        close_fds=True,
    )
    print("Applying the downloaded update... Chat restarts itself in a few seconds.")
    raise SystemExit(0)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Chat voice assistant")
    p.add_argument("--dashboard-only", action="store_true", help="dashboard + timers only")
    p.add_argument("--no-voice", action="store_true", help="disable microphone/wake word")
    p.add_argument("--verbose", action="store_true", help="chatty console logging")
    p.add_argument("--host", default=None, help="dashboard bind address")
    p.add_argument("--port", type=int, default=None, help="dashboard port")
    p.add_argument("--data-dir", default=None, help="data directory override")
    return p.parse_args()


async def main() -> int:
    args = parse_args()
    if args.data_dir:
        os.environ["CHAT_DATA_DIR"] = args.data_dir

    from chat_core.config import load_settings

    settings = load_settings()
    if args.host:
        settings.dashboard_host = args.host
    if args.port:
        settings.dashboard_port = args.port
    if args.verbose:
        settings.log_level = "INFO"
        settings.low_power = False

    # Primary check: atomic named mutex (Windows only). If this process gets
    # the mutex, it can proceed. A second launch will fail here immediately,
    # before any audio or cloud services start.
    if not _acquire_windows_mutex():
        print(
            "Chat is already running. Only one instance at a time is supported."
        )
        return 0

    # Secondary check: port availability. On non-Windows the mutex is a no-op
    # so this is the main guard. On Windows this gives a friendlier message if
    # something unrelated already occupies the port.
    if not dashboard_port_available(settings.dashboard_host, settings.dashboard_port):
        # Attempt to confirm the occupant is actually Chat before assuming so.
        is_chat = _verify_chat_on_port(settings.dashboard_host, settings.dashboard_port)
        if is_chat:
            print(
                f"Chat is already running on port {settings.dashboard_port}. "
                "Only one instance at a time is supported."
            )
        else:
            print(
                f"Port {settings.dashboard_port} is already in use by another application. "
                "Change the dashboard port in settings or stop the other application."
            )
        return 0

    from chat_core.runtime import Runtime
    from apps.dashboard.app import create_app
    import uvicorn

    rt = Runtime(settings)
    await rt.start(
        voice=not (args.no_voice or args.dashboard_only),
        cloud=not args.dashboard_only,
        monitoring=not args.dashboard_only,
    )
    _install_windows_disconnect_handler()

    app = create_app(rt)
    uv_kwargs: dict = dict(
        host=settings.dashboard_host,
        port=settings.dashboard_port,
        log_level="warning" if settings.low_power else "info",
        access_log=not settings.low_power,
    )
    if settings.ssl_certfile and settings.ssl_keyfile:
        uv_kwargs.update(ssl_certfile=settings.ssl_certfile, ssl_keyfile=settings.ssl_keyfile)
    config = uvicorn.Config(app, **uv_kwargs)
    server = uvicorn.Server(config)
    # lets the dashboard's Restart button stop the server loop cleanly
    rt.on_uvicorn_exit = lambda: setattr(server, "should_exit", True)

    from chat_core.version import APP_VERSION

    scheme = "https" if settings.ssl_certfile else "http"
    print(f"Chat {APP_VERSION} is running.")
    if settings.dashboard_host in ("0.0.0.0", "::"):
        from chat_core.net import lan_ips

        port = settings.dashboard_port
        print(f"  This computer:   {scheme}://127.0.0.1:{port}")
        candidates = lan_ips()
        if candidates:
            print(f"  Phone on Wi-Fi — use the EXACT address printed for your network:")
            for ip in candidates:
                print(f"    {scheme}://{ip}:{port}")
            if len(candidates) > 1:
                print(
                    "  (Multiple adapters detected. Use the address matching your"
                    " phone's Wi-Fi — try the first one first.)"
                )
        else:
            print(
                "  Phone on Wi-Fi:  no private LAN address found."
                " Check that Wi-Fi or Ethernet is connected."
                " If this computer only has a VPN or public address, phone"
                " access from the same LAN is not possible."
            )
    else:
        print(f"  Control panel: {scheme}://{settings.dashboard_host}:{settings.dashboard_port}")
    print(f"  Data folder:   {settings.data_dir}")
    print("  Press Ctrl+C to stop.")

    try:
        await server.serve()
    finally:
        with contextlib.suppress(Exception):
            await rt.stop()

    code = rt.restart_exit_code or 0
    if code == RESTART_CODE and getattr(sys, "frozen", False):
        # exe has no .bat loop around it: relaunch ourselves after a beat
        import subprocess

        subprocess.Popen(
            ["cmd", "/c", f'timeout /t 2 /nobreak >nul & start "" "{sys.executable}"'],
            creationflags=0x00000008,
            close_fds=True,
        )
        return 0
    return code


if __name__ == "__main__":
    apply_pending_update()  # must run before chat_core/apps are imported
    if sys.platform == "win32":
        # ProactorEventLoop is the default on Python 3.8+; no explicit policy
        # call is needed and the deprecated setter was removed from 3.12+.
        # Only set the process priority to below-normal.
        try:
            import ctypes

            ctypes.windll.kernel32.SetPriorityClass(
                ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000  # BELOW_NORMAL
            )
        except Exception:
            pass
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        print("\nChat stopped.")
