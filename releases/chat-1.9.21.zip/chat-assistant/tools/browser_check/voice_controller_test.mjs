// Voice controller browser-level test: loads the real /voice-controller page
// in jsdom with scripts enabled and exercises the pure helpers the page
// exposes on window.__vc. Guards:
//   * page boots without touching mic/WebSocket (idle until user gesture)
//   * JV upstream frame pack + JA downstream header parse round-trip
//   * deterministic resampler produces exact 1280-sample frames
//   * bounded RingQueue drops oldest, counts drops
//   * reconnect backoff stays within [base, max+jitter]
//   * control-message state machine: ready → wake, busy shows holder + takeover,
//     revoked disarms auto-reconnect, stale-turn voice frames rejected
import assert from "node:assert/strict";
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = "http://127.0.0.1:8756";
let cookie = "";

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}
async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// ---- session: harness.mjs already ran /setup with this password ----
{
  const form = new URLSearchParams();
  form.set("password", "Testpass123");
  const r = await req("/login", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", origin: BASE, referer: BASE + "/login" },
    body: form.toString(),
  });
  if (![200, 302, 303].includes(r.status)) { console.log("FATAL: login failed:", r.status); process.exit(2); }
}

const resp = await req("/voice-controller");
if (resp.status !== 200) { console.log("FATAL: /voice-controller HTTP", resp.status); process.exit(2); }
const html = await resp.text();

const errors = [];
const vcons = new VirtualConsole();
vcons.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
vcons.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(html, {
  url: BASE + "/voice-controller",
  runScripts: "dangerously",
  resources: "usable",
  pretendToBeVisual: true,
  virtualConsole: vcons,
  beforeParse(window) {
    window.alert = () => {};
    window.fetch = (p, o = {}) => {
      const { signal, ...rest } = o;
      rest.headers = { ...(rest.headers || {}), cookie };
      return fetch(new URL(p, BASE + "/voice-controller").href, rest);
    };
    // NO WebSocket / AudioContext / mediaDevices stubs on purpose: the page
    // must boot to idle without needing any of them.
  },
});

await new Promise((res) => {
  let done = false;
  const finish = () => { if (!done) { done = true; setTimeout(res, 600); } };
  dom.window.addEventListener("load", finish);
  setTimeout(finish, 3000);
});

const w = dom.window;
const vc = w.__vc;
assert.ok(vc, "window.__vc helpers must be exposed");
assert.equal(vc.state.phase, "idle", "page must boot to idle without mic/socket");
for (const e of errors) assert.fail("page error at boot: " + e);

// ---- 1. JV upstream frame packing ------------------------------------------
{
  const pcm = new Int16Array(1280);
  for (let i = 0; i < pcm.length; i++) pcm[i] = (i * 17) % 32767 - 16384;
  const framed = new Uint8Array(vc.packFrame(pcm.buffer, 4242));
  assert.equal(framed.byteLength, 8 + 2560, "8-byte header + 1280 samples");
  assert.equal(framed[0], 0x4a); // 'J'
  assert.equal(framed[1], 0x56); // 'V'
  assert.equal(framed[2], 1);    // version
  const dv = new DataView(framed.buffer);
  assert.equal(dv.getUint32(4, true), 4242, "little-endian sequence");
  console.log("PASS pack JV frame");
}

// ---- 2. JA downstream header parse -------------------------------------------
{
  const pcm = new Int16Array(480).fill(1234);
  const buf = new ArrayBuffer(12 + pcm.byteLength);
  const dv = new DataView(buf);
  dv.setUint8(0, 0x4a); dv.setUint8(1, 0x41); dv.setUint8(2, 1); dv.setUint8(3, 2);
  dv.setUint16(4, 7, true);      // turn
  dv.setUint32(8, 99, true);     // seq
  new Uint8Array(buf, 12).set(new Uint8Array(pcm.buffer));
  const frame = vc.parseDownHeader(buf);
  assert.ok(frame, "valid JA frame must parse");
  assert.equal(frame.kind, 2);
  assert.equal(frame.turn, 7);
  assert.equal(frame.seq, 99);
  assert.equal(frame.pcm.byteLength, pcm.byteLength);
  assert.equal(vc.parseDownHeader(new ArrayBuffer(4)), null, "short buffer rejected");
  const badMagic = buf.slice(0);
  new DataView(badMagic).setUint8(0, 0x58);
  assert.equal(vc.parseDownHeader(badMagic), null, "wrong magic rejected");
  console.log("PASS parse JA header");
}

// ---- 3. deterministic resampler ------------------------------------------------
{
  const r = new vc.Resampler(48000, 16000, 1280);
  // 48000→16000 is 3:1, so 3×1280 input samples per output frame.
  const sine = new Float32Array(1280 * 3);
  for (let i = 0; i < sine.length; i++) sine[i] = Math.sin(i / 20) * 0.5;
  const frames = [];
  for (let off = 0; off < sine.length; off += 512) {
    const got = r.push(sine.subarray(off, Math.min(off + 512, sine.length)));
    frames.push(...got);
  }
  const total = frames.reduce((n, f) => n + f.byteLength, 0);
  assert.ok(frames.length >= 1, "must emit at least one full frame");
  for (const f of frames) assert.equal(f.byteLength, 2560, "every frame exactly 1280 samples");
  assert.ok(total <= sine.length / 3 * 2 + 2560, "no sample invention");
  // Determinism: same input, same output.
  const r2 = new vc.Resampler(48000, 16000, 1280);
  const frames2 = [];
  for (let off = 0; off < sine.length; off += 512) frames2.push(...r2.push(sine.subarray(off, Math.min(off + 512, sine.length))));
  assert.equal(frames2.length, frames.length);
  assert.deepEqual(new Int16Array(frames2[0]), new Int16Array(frames[0]), "byte-identical resample");
  console.log("PASS resampler frames + determinism");
}

// ---- 4. bounded ring queue ---------------------------------------------------
{
  const q = new vc.RingQueue(3);
  for (let i = 1; i <= 5; i++) q.push(i);
  assert.equal(q.length, 3, "bounded at capacity");
  assert.equal(q.dropped, 2, "drops counted");
  const out = [];
  q.drain((x) => out.push(x));
  assert.deepEqual(out, [3, 4, 5], "oldest dropped first");
  console.log("PASS bounded ring queue");
}

// ---- 5. reconnect backoff ------------------------------------------------------
{
  for (let attempt = 1; attempt <= 8; attempt++) {
    const d = vc.reconnectDelay(attempt);
    assert.ok(d >= 1000, `attempt ${attempt}: at least base delay`);
    assert.ok(d <= 10000 + 250, `attempt ${attempt}: capped + jitter`);
  }
  console.log("PASS reconnect backoff bounds");
}

// ---- 6. control-message state machine ----------------------------------------
{
  const { handleControl, applyServerState, playWakeAck } = vc._internals;

  // Pleasant local-only cue: generated only from the confirmed wake event.
  const cue = { started: 0, stopped: 0, frequencies: [] };
  const param = {
    setValueAtTime(v) { cue.frequencies.push(v); },
    exponentialRampToValueAtTime(v) { cue.frequencies.push(v); },
  };
  const fakeCtx = {
    currentTime: 1,
    state: "running",
    destination: {},
    createOscillator() {
      return {
        type: "", frequency: param, connect() {}, disconnect() {},
        start() { cue.started++; }, stop() { cue.stopped++; }, onended: null,
      };
    },
    createGain() {
      return { gain: param, connect() {}, disconnect() {} };
    },
  };
  assert.equal(playWakeAck(fakeCtx), true);
  assert.equal(cue.started, 1);
  assert.equal(cue.stopped, 1);
  assert.ok(cue.frequencies.includes(587.33) && cue.frequencies.includes(880));

  handleControl({ type: "ready", state: "wake", turn: 3, wake: { available: true }, muted: false });
  assert.equal(vc.state.phase, "wake");
  assert.equal(vc.state.currentTurn, 3);
  assert.equal(vc.state.wakeAvailable, true);
  assert.equal(w.document.getElementById("vc-state").textContent.includes("Hey Jarvis")
    || w.document.getElementById("vc-hint").textContent.includes("Hey Jarvis"), true,
    "wake copy mentions the wake phrase");

  // wake unavailable → push-to-talk guidance, never a dead end
  handleControl({ type: "ready", state: "wake", turn: 3, wake: { available: false }, muted: false });
  const hint = w.document.getElementById("vc-hint").textContent;
  assert.ok(/button|push-to-talk/i.test(hint), "PTT fallback offered when wake unavailable");

  // The model loads asynchronously. An already-open controller must switch
  // from manual-only to wake listening without reconnecting.
  handleControl({ type: "wake_status", available: true });
  assert.equal(vc.state.wakeAvailable, true);
  assert.ok(w.document.getElementById("vc-main-label").textContent.includes("Hey Jarvis"),
    "live wake readiness updates the primary control");

  handleControl({ type: "mic_status", status: "streaming" });
  assert.ok(w.document.getElementById("vc-banner").textContent.includes("reaching Jarvis"),
    "server-confirmed microphone streaming is visible");
  handleControl({ type: "pong", t: Date.now(), frames_in: 12, frames_forwarded: 4 });
  assert.equal(vc.state.stats.server_frames_in, 12);
  assert.equal(vc.state.stats.server_frames_forwarded, 4);

  applyServerState("listening");
  assert.equal(vc.state.phase, "listening");
  assert.equal(vc.state.conversation, true);

  handleControl({ type: "state", state: "speaking", turn: 4 });
  assert.equal(vc.state.phase, "speaking");
  assert.equal(vc.state.currentTurn, 4);

  // busy: shows WHICH device and offers takeover
  handleControl({ type: "busy", holder: { device: "Kitchen tablet", in_conversation: true } });
  assert.equal(vc.state.phase, "busy");
  assert.ok(w.document.getElementById("vc-banner").textContent.includes("Kitchen tablet"));
  const takeover = w.document.getElementById("vc-takeover");
  assert.equal(takeover.hidden, false, "takeover button visible when busy");

  // revoked: disarms auto-reconnect, offers take-back
  handleControl({ type: "revoked" });
  assert.equal(vc.state.phase, "revoked");
  assert.equal(takeover.hidden, false, "take-back offered after revocation");

  console.log("PASS control-message state machine");
}

// ---- 7. transcript rendering ---------------------------------------------------
{
  const { handleControl } = vc._internals;
  handleControl({ type: "transcript", role: "user", text: "what time is it" });
  handleControl({ type: "transcript", role: "assistant", text: "It is noon." });
  const t = w.document.getElementById("vc-transcript");
  assert.equal(t.hidden, false, "transcript unhidden once content arrives");
  assert.ok(t.textContent.includes("what time is it"));
  assert.ok(t.textContent.includes("It is noon."));
  console.log("PASS transcript rendering");
}

// ---- 8. stale setup fencing + silent-worklet recovery --------------------------
{
  const { enable, deliberateClose, stopCapture } = vc._internals;
  let resolveFirstMic;
  let micCalls = 0;
  const makeStream = () => {
    const track = {
      stopped: false,
      stop() { this.stopped = true; },
      getSettings() { return { echoCancellation: true }; },
      getCapabilities() { return { echoCancellation: [true, false] }; },
    };
    return {
      track,
      getTracks() { return [track]; },
      getAudioTracks() { return [track]; },
    };
  };
  const firstStream = makeStream();
  const secondStream = makeStream();
  Object.defineProperty(w.navigator, "mediaDevices", {
    configurable: true,
    value: {
      getUserMedia() {
        micCalls++;
        if (micCalls === 1) {
          return new Promise((resolve) => { resolveFirstMic = resolve; });
        }
        return Promise.resolve(secondStream);
      },
    },
  });

  class FakeNode {
    constructor() { this.port = { onmessage: null }; this.onaudioprocess = null; }
    connect() {}
    disconnect() {}
  }
  class FakeAudioContext {
    constructor() {
      this.sampleRate = 48000;
      this.currentTime = 0;
      this.state = "running";
      this.destination = {};
      this.audioWorklet = { addModule: async () => {} };
    }
    resume() { return Promise.resolve(); }
    createMediaStreamSource() { return new FakeNode(); }
    createGain() {
      const param = {
        value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {},
      };
      return { gain: param, connect() {}, disconnect() {} };
    }
    createScriptProcessor() { return new FakeNode(); }
    createOscillator() {
      return {
        type: "", frequency: {
          setValueAtTime() {}, exponentialRampToValueAtTime() {},
        },
        connect() {}, disconnect() {}, start() {}, stop() {}, onended: null,
      };
    }
  }
  class FakeWorkletNode extends FakeNode {}
  const sockets = [];
  class FakeWebSocket {
    static OPEN = 1;
    constructor() {
      this.readyState = FakeWebSocket.OPEN;
      this.bufferedAmount = 0;
      sockets.push(this);
    }
    send() {}
    close() { this.readyState = 3; }
  }
  w.AudioContext = FakeAudioContext;
  w.AudioWorkletNode = FakeWorkletNode;
  w.WebSocket = FakeWebSocket;

  const oldSetup = enable();
  await new Promise((r) => setTimeout(r, 0));
  const newestSetup = enable();
  await newestSetup;
  resolveFirstMic(firstStream);
  await oldSetup;

  assert.equal(sockets.length, 1, "stale setup must never create a socket");
  assert.equal(firstStream.track.stopped, true, "stale mic track is stopped");
  assert.equal(secondStream.track.stopped, false, "newest mic track remains active");
  assert.equal(vc.state.stats.engine, "worklet");

  await new Promise((r) => setTimeout(r, 2700));
  assert.equal(vc.state.stats.engine, "scriptprocessor",
    "silent worklet falls back to compatibility capture");
  assert.equal(vc.state.stats.capture_stalls, 1);

  deliberateClose();
  stopCapture();
  assert.equal(secondStream.track.stopped, true, "active mic stops on close");
  console.log("PASS stale setup fencing + capture watchdog");
}

dom.window.close();
console.log("ALL VOICE CONTROLLER CHECKS PASSED");
process.exit(0);
