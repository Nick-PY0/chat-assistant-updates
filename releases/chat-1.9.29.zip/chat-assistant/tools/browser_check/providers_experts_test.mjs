import assert from "node:assert/strict";
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = process.env.CHAT_BROWSER_CHECK_BASE || "http://127.0.0.1:8756";
let cookie = "";

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}

async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// Login
{
  const form = new URLSearchParams();
  form.set("password", "Testpass123");
  const r = await req("/login", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", origin: BASE, referer: BASE + "/login" },
    body: form.toString(),
  });
  if (![200, 302, 303].includes(r.status)) { console.log("FATAL: login failed:", r.status); process.exit(2); }
}

const resp = await req("/providers");
if (resp.status !== 200) { console.log("FATAL: /providers HTTP", resp.status); process.exit(2); }
const html = await resp.text();

let expertsData = {
  config: {
    auto_use: true,
    reasoning: "high",
    providers: {
      chatgpt: {
        enabled: true,
        preferred_model: "gpt-4o",
        enabled_models: [] // Empty means all discovered allowed
      },
      claude: {
        enabled: false,
        preferred_model: "claude-3-opus",
        enabled_models: ["claude-3-opus", "claude-3-sonnet"]
      }
    }
  },
  catalog: {
    chatgpt: [
      { id: "gpt-4o", label: "GPT-4o <span>HTML</span>", rank: 1, cost_rank: 2, reasoning: false },
      { id: "gpt-4o-mini", label: "GPT-4o Mini", rank: 2, cost_rank: 1, reasoning: false },
      { id: "o1-preview", label: "o1 Preview", rank: 3, cost_rank: 3, reasoning: true },
    ],
    claude: [
      { id: "claude-3-opus", label: "Claude 3 Opus", rank: 1, cost_rank: 3, reasoning: false },
      { id: "claude-3-sonnet", label: "Claude 3.5 Sonnet", rank: 2, cost_rank: 2, reasoning: false },
      { id: "claude-3-haiku", label: "Claude 3 Haiku", rank: 3, cost_rank: 1, reasoning: false },
    ]
  }
};

const patches = [];

const errors = [];
const vc = new VirtualConsole();
vc.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

const dom = new JSDOM(html, {
  url: BASE + "/providers",
  runScripts: "dangerously",
  resources: "usable",
  pretendToBeVisual: true,
  virtualConsole: vc,
  beforeParse(window) {
    window.alert = () => {};
    window.confirm = () => true;
    window.fetch = async (p, o = {}) => {
      const path = new URL(p, BASE + "/providers").pathname;
      if (path === "/api/experts") {
        if (!o.method || o.method === "GET") {
          return new Response(JSON.stringify(expertsData), { status: 200, headers: { "content-type": "application/json" } });
        } else if (o.method === "PATCH") {
          const body = JSON.parse(o.body || "{}");
          patches.push(body);
          expertsData.config = body;
          return new Response(JSON.stringify(expertsData), { status: 200, headers: { "content-type": "application/json" } });
        }
      }
      
      // Mock other APIs to prevent errors/credits
      if (path === "/api/credentials") {
        return new Response(JSON.stringify({ openai: [], relay: [], govee: [] }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (path === "/api/spotify/status") {
        return new Response(JSON.stringify({ account: { connected: false } }), { status: 200, headers: { "content-type": "application/json" } });
      }
      if (path === "/api/calendar/status") {
        return new Response(JSON.stringify({ account: { configured: false } }), { status: 200, headers: { "content-type": "application/json" } });
      }
      
      return new Response(JSON.stringify({}), { status: 200, headers: { "content-type": "application/json" } });
    };
  },
});

await new Promise((res) => {
  let done = false;
  const finish = () => { if (!done) { done = true; setTimeout(res, 300); } };
  dom.window.addEventListener("load", finish);
  setTimeout(finish, 1000);
});

const doc = dom.window.document;
const el = (id) => doc.getElementById(id);

let failures = 0;
const check = (name, fn) => {
  try { fn(); console.log("  ok  " + name); }
  catch (e) { console.log("FAIL  " + name + ": " + e.message); failures++; }
};

// Start tests
const chatGptContainer = el("expert-chatgpt");
const claudeContainer = el("expert-claude");

check("GET config renders provider toggles and basic state", () => {
  assert.ok(chatGptContainer, "chatgpt container missing");
  const chatGptToggle = chatGptContainer.querySelector('input[type="checkbox"]');
  assert.equal(chatGptToggle.checked, true, "chatgpt toggle should be checked");
  
  const claudeToggle = claudeContainer.querySelector('input[type="checkbox"]');
  assert.equal(claudeToggle.checked, false, "claude toggle should be unchecked");
  
  assert.equal(el("expert-auto-use").checked, true);
  assert.equal(el("expert-reasoning").value, "high");
});

check("catalog labels render as text, not HTML", () => {
  // We passed label: "GPT-4o <span>HTML</span>"
  // If it was rendered as HTML, a span element would exist
  const models = Array.from(chatGptContainer.querySelectorAll("label")).filter(l => l.textContent.includes("GPT-4o"));
  assert.ok(models.length > 0);
  const spanInject = chatGptContainer.querySelector("span > span"); // Inner span
  assert.equal(spanInject, null, "Should not render raw HTML from catalog labels");
  assert.ok(models[0].textContent.includes("<span>HTML</span>"), "Should contain raw string text");
});

check("empty enabled_models renders all discovered checkboxes checked", () => {
  // chatgpt has empty enabled_models on load
  const cbs = chatGptContainer.querySelectorAll('input[type="checkbox"]');
  // First checkbox is the provider toggle, remaining are models
  const modelCbs = Array.from(cbs).slice(1);
  assert.equal(modelCbs.length, 3);
  modelCbs.forEach(cb => assert.equal(cb.checked, true, "Model cb should be checked"));
  
  const note = chatGptContainer.querySelector("div > div > div:nth-child(2)"); // "All discovered models are allowed" note
  assert.ok(note && note.textContent.includes("All discovered models are allowed"));
});

check("unchecking one materializes all-except-one", () => {
  const cbs = chatGptContainer.querySelectorAll('input[type="checkbox"]');
  const modelCbs = Array.from(cbs).slice(1);
  
  // Uncheck o1-preview (value: o1-preview)
  const o1Cb = modelCbs.find(c => c.value === "o1-preview");
  assert.ok(o1Cb);
  
  o1Cb.checked = false;
  o1Cb.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  
  // The 'Save Changes' button should now be enabled
  assert.equal(el("experts-save").disabled, false);
  
  // The note should be hidden
  const note = Array.from(chatGptContainer.querySelectorAll("div")).find(d => d.textContent === "All discovered models are allowed.");
  assert.equal(note.style.display, "none", "Note should be hidden");
});

check("unchecking the preferred model moves preferred to the highest-ranked allowed model", () => {
  const cbs = chatGptContainer.querySelectorAll('input[type="checkbox"]');
  const modelCbs = Array.from(cbs).slice(1);
  
  const prefSelect = el("pref-select-chatgpt");
  assert.equal(prefSelect.value, "gpt-4o", "Initial preferred model");
  
  // Uncheck gpt-4o
  const gpt4oCb = modelCbs.find(c => c.value === "gpt-4o");
  gpt4oCb.checked = false;
  gpt4oCb.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  
  // Highest ranked remaining is gpt-4o-mini (rank 2, since gpt-4o rank 1 is unchecked and o1-preview is also unchecked from before)
  assert.equal(prefSelect.value, "gpt-4o-mini");
});

check("enabled provider cannot uncheck its final model", () => {
  const cbs = chatGptContainer.querySelectorAll('input[type="checkbox"]');
  const modelCbs = Array.from(cbs).slice(1);
  
  // Only gpt-4o-mini is checked right now. Let's uncheck it.
  const miniCb = modelCbs.find(c => c.value === "gpt-4o-mini");
  miniCb.checked = false;
  miniCb.dispatchEvent(new dom.window.Event("change", { bubbles: true }));
  
  // Should revert to checked
  assert.equal(miniCb.checked, true);
  
  // Error message should be visible
  const errors = Array.from(chatGptContainer.querySelectorAll(".error")).filter(e => e.textContent.includes("least one allowed model"));
  assert.ok(errors.length > 0);
  assert.notEqual(errors[0].style.display, "none");
});

check("save PATCH sends the actual config and saved state remains after rerender/reload", async () => {
  const saveBtn = el("experts-save");
  saveBtn.click();
  
  await new Promise(r => setTimeout(r, 100)); // Wait for fetch
  
  assert.equal(patches.length, 1);
  const patch = patches[0];
  
  assert.equal(patch.providers.chatgpt.enabled_models.length, 1);
  assert.equal(patch.providers.chatgpt.enabled_models[0], "gpt-4o-mini");
  assert.equal(patch.providers.chatgpt.preferred_model, "gpt-4o-mini");
});

if (failures > 0) {
  console.log(`\n${failures} tests failed.`);
  process.exit(1);
} else {
  console.log("\nAll AI Experts tests passed!");
  process.exit(0);
}
