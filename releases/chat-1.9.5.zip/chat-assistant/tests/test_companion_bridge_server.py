"""The companion bridge must be reachable by a browser extension.

A browser extension cannot approve a self-signed certificate, so when the
dashboard runs HTTPS the extension can never open wss://127.0.0.1 — pairing
fails with an opaque error.  The bridge therefore runs on its own loopback
port, always plain HTTP, and the dashboard advertises that address.
"""

from __future__ import annotations

import socket

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from apps.dashboard.companion_server import (
    COMPANION_WS_PATH,
    CompanionBridgeServer,
    choose_bridge_port,
    create_companion_app,
)
from chat_core.runtime import Runtime


@pytest.fixture
async def rt(settings):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def _login(client) -> str:
    resp = await client.post(
        "/setup", data={"password": "hunter2secure", "confirm": "hunter2secure"}
    )
    assert resp.status_code == 303
    return client.app.state.sessions.csrf_for(client.cookies.get(COOKIE))


# ---------------------------------------------------------------------------
# Port selection
# ---------------------------------------------------------------------------

def test_auto_port_follows_the_dashboard_port():
    assert choose_bridge_port(0, 8756) == 8757


def test_auto_port_walks_past_a_busy_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen(1)
        busy = taken.getsockname()[1]
        chosen = choose_bridge_port(0, busy - 1)
        assert chosen != busy


def test_configured_port_is_never_silently_moved():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as taken:
        taken.bind(("127.0.0.1", 0))
        taken.listen(1)
        busy = taken.getsockname()[1]
        assert choose_bridge_port(busy, 8756) is None


# ---------------------------------------------------------------------------
# The bridge app itself
# ---------------------------------------------------------------------------

async def test_bridge_app_exposes_only_health_and_the_socket(rt):
    app = create_companion_app(rt)
    paths = {route.path for route in app.routes if hasattr(route, "path")}
    assert COMPANION_WS_PATH in paths
    assert "/companion/health" in paths
    # No dashboard surface may be reachable on the plain-HTTP bridge port.
    for leaked in ("/", "/login", "/settings", "/api/companion/pair"):
        assert leaked not in paths


async def test_bridge_health_reports_liveness_without_secrets(rt):
    app = create_companion_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        resp = await c.get("/companion/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True
    assert "token" not in str(body).lower()
    assert "secret" not in str(body).lower()


async def test_bridge_server_binds_loopback_only(rt):
    server = CompanionBridgeServer(rt)
    assert await server.start() is True
    try:
        assert server.running
        assert rt.companion_bridge_port == server.port
        # Reachable on loopback...
        async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{server.port}") as c:
            assert (await c.get("/companion/health")).status_code == 200
        # ...and bound to loopback only, whatever dashboard_host says, so no
        # LAN device can ever reach the bridge.
        assert rt.settings.dashboard_host == "0.0.0.0"
        assert server.bound_host == "127.0.0.1"
    finally:
        await server.stop()
    assert rt.companion_bridge_port is None


# ---------------------------------------------------------------------------
# What the dashboard tells the owner to type into the extension
# ---------------------------------------------------------------------------

async def test_status_advertises_the_plain_ws_bridge_port(client, rt):
    csrf = await _login(client)
    rt.companion_bridge_port = 8757
    resp = await client.get("/api/companion/status", headers={"x-csrf": csrf})
    body = resp.json()
    assert body["bridge_base"] == "ws://127.0.0.1:8757"
    assert body["bridge_tls_blocked"] is False


async def test_pair_advertises_the_plain_ws_bridge_port(client, rt):
    csrf = await _login(client)
    rt.companion_bridge_port = 8757
    resp = await client.post("/api/companion/pair", json={}, headers={"x-csrf": csrf})
    body = resp.json()
    assert body["pairing_token"]
    assert body["bridge_base"] == "ws://127.0.0.1:8757"


async def test_https_dashboard_without_bridge_port_warns_instead_of_lying(settings, monkeypatch):
    """Falling back to wss must be reported as blocked, not offered silently."""
    settings.ssl_certfile = "cert.pem"
    settings.ssl_keyfile = "key.pem"
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    try:
        async def fake_validate(secret, timeout=5.0):
            return None

        monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
        app = create_app(runtime)
        transport = httpx.ASGITransport(app=app)
        # https base URL: with TLS configured the session cookie is Secure, so
        # a plain-http test client would silently drop it.
        async with httpx.AsyncClient(transport=transport, base_url="https://test") as c:
            c.app = app
            csrf = await _login(c)
            body = (await c.get("/api/companion/status", headers={"x-csrf": csrf})).json()
        assert body["bridge_base"].startswith("wss://")
        assert body["bridge_tls_blocked"] is True
    finally:
        await runtime.stop()
