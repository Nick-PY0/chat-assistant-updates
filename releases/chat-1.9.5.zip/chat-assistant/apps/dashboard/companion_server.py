"""Dedicated loopback-only companion bridge server (plain HTTP).

Why this exists
---------------
The dashboard can run as HTTPS with a locally generated certificate.  A browser
extension cannot approve such a certificate: there is no page, no interstitial
and no "Advanced → Proceed" button for a WebSocket opened inside a service
worker, so ``wss://127.0.0.1`` simply fails with an opaque error and pairing can
never complete.

The companion therefore always gets its own tiny server, bound strictly to the
loopback interface and always plain HTTP, so the extension can reach
``ws://127.0.0.1:<port>/ws/companion`` whether or not the dashboard uses TLS.

Why plain HTTP is safe *here* (and only here)
---------------------------------------------
  * The listening socket is bound to 127.0.0.1, never to the LAN, regardless of
    ``dashboard_host``.  Nothing outside this computer can open it.
  * Every connection is rejected before the WebSocket upgrade unless the peer
    address is itself loopback.
  * The protocol authenticates with the bridge secret (or a one-time pairing
    token) before any command or state frame is honoured.
  * The traffic carries media commands for the local browser, never passwords,
    credentials or personal data, and it never leaves the machine.

This server exposes exactly two routes: the companion socket and an unauthenticated
liveness probe used by the extension's "Test connection" button.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import socket

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from apps.tool_service.companion_bridge import CompanionBridge
from chat_core.runtime import Runtime

log = logging.getLogger("chat.companion_server")

COMPANION_WS_PATH = "/ws/companion"
# Ports tried when no explicit companion_bridge_port is configured.
AUTO_PORT_ATTEMPTS = 8


class _StarletteCompanionSocket:
    """Adapt a Starlette WebSocket to the bridge's duck-typed socket."""

    __slots__ = ("_ws",)

    def __init__(self, ws: WebSocket) -> None:
        self._ws = ws

    async def send_text(self, data: str) -> None:
        await self._ws.send_text(data)

    async def receive_text(self) -> str:
        return await self._ws.receive_text()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        await self._ws.close(code=code, reason=reason)


async def serve_companion_socket(rt: Runtime, ws: WebSocket) -> None:
    """Handle one companion WebSocket connection.

    Shared by the dashboard route and the dedicated bridge server so both
    enforce exactly the same loopback rule and protocol handling.
    """
    client_host = ws.client.host if ws.client else ""
    if rt.companion is None or not CompanionBridge.is_loopback_host(client_host):
        await ws.close(code=4403)
        return
    await ws.accept()
    try:
        await rt.companion.handle(_StarletteCompanionSocket(ws))
    except WebSocketDisconnect:
        pass


def create_companion_app(rt: Runtime) -> FastAPI:
    """Build the minimal companion-only application."""
    app = FastAPI(title="Chat companion bridge", docs_url=None, redoc_url=None, openapi_url=None)

    @app.get("/companion/health")
    async def companion_health():
        """Liveness probe for the extension's Test connection button.

        Deliberately unauthenticated and contentless: it proves only that the
        bridge is listening on loopback.  It exposes no pairing state, no
        secret and no media information.
        """
        return {"ok": True, "service": "chat-companion-bridge"}

    @app.websocket(COMPANION_WS_PATH)
    async def ws_companion(ws: WebSocket):
        await serve_companion_socket(rt, ws)

    return app


def _port_free(port: int) -> bool:
    """True when the loopback port can be bound right now."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            probe.bind(("127.0.0.1", port))
        except OSError:
            return False
    return True


def choose_bridge_port(configured: int, dashboard_port: int) -> int | None:
    """Pick the loopback port for the bridge.

    A configured port is honoured exactly (and reported unavailable if taken),
    so an owner who opened a firewall rule or wrote the port into the extension
    never has it silently moved.  Otherwise the port after the dashboard is
    used, walking forward if it is busy.
    """
    if configured:
        return int(configured) if _port_free(int(configured)) else None
    first = int(dashboard_port) + 1
    for candidate in range(first, first + AUTO_PORT_ATTEMPTS):
        if 0 < candidate < 65536 and _port_free(candidate):
            return candidate
    return None


class CompanionBridgeServer:
    """Runs the companion bridge on its own loopback port alongside the dashboard."""

    # Never configurable: the bridge is loopback-only by design, whatever
    # dashboard_host is set to.
    bound_host = "127.0.0.1"

    def __init__(self, rt: Runtime) -> None:
        self._rt = rt
        self._server = None
        self._task: asyncio.Task | None = None
        self.port: int | None = None
        self.error: str = ""

    @property
    def running(self) -> bool:
        return self.port is not None and self._task is not None and not self._task.done()

    async def start(self) -> bool:
        """Start the bridge.  Returns False (without raising) if it cannot run.

        A failure here must never stop Chat: the dashboard, voice and all other
        features work without the companion extension.
        """
        import uvicorn

        settings = self._rt.settings
        port = choose_bridge_port(
            int(getattr(settings, "companion_bridge_port", 0) or 0),
            int(settings.dashboard_port),
        )
        if port is None:
            self.error = (
                "No free loopback port for the YouTube companion bridge. "
                "Set companion_bridge_port in settings to a free port."
            )
            log.warning("%s", self.error)
            return False

        config = uvicorn.Config(
            create_companion_app(self._rt),
            host=self.bound_host,      # never the LAN, whatever dashboard_host says
            port=port,
            log_level="warning",
            access_log=False,
        )
        self._server = uvicorn.Server(config)
        self._task = asyncio.ensure_future(self._server.serve())

        # Wait for the socket to be listening (or for an early failure).
        for _ in range(100):
            if getattr(self._server, "started", False):
                self.port = port
                self._rt.companion_bridge_port = port
                self.error = ""
                return True
            if self._task.done():
                break
            await asyncio.sleep(0.05)

        self.error = "The YouTube companion bridge did not start."
        with contextlib.suppress(Exception):
            await self.stop()
        log.warning("%s", self.error)
        return False

    async def stop(self) -> None:
        if self._server is not None:
            self._server.should_exit = True
        if self._task is not None:
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.wait_for(asyncio.shield(self._task), timeout=5)
            if not self._task.done():
                self._task.cancel()
                await asyncio.gather(self._task, return_exceptions=True)
        self._task = None
        self._server = None
        self.port = None
        self._rt.companion_bridge_port = None
