// background.js — Manifest V3 module service worker.
//
// Implements the CLIENT side of the CompanionBridge v1 protocol.
// Authority: apps/tool_service/COMPANION_PROTOCOL.md
//
// Key responsibilities
// -------------------
// 1. Own the loopback WebSocket to <bridge_base>/ws/companion.
// 2. Handshake: hello(token) → paired(secret) + auth_ok on first pair;
//    hello(secret) → auth_ok on reconnect.
//    - "paired" secret is stored immediately; pairing token is NEVER stored.
//    - "auth_error" on a secret attempt: clear secret, report unpaired.
//    - "revoked": clear secret, suppress reconnect (must re-pair).
// 3. Receive "command" frames; validate (allowlist, target, ad gate); route:
//    - navigate_video / navigate_playlist → canonical URL navigation HERE.
//    - All other actions → content script via chrome.runtime.sendMessage.
//    - duck / restore → content script; NOT blocked during ads (per spec).
//    - All other actions blocked locally during ads (defense-in-depth).
// 4. Send "ack" for every command.
// 5. Relay content-script state as "state" frames (with session + target fencing).
//    State frames include ad_playing boolean and playlist_id.
// 6. Maintain adPlaying flag from content state; use it to gate commands.
// 7. Reply to "ping" with "pong".
// 8. Keepalive / reconnect via chrome.alarms with exponential backoff.

import {
  YOUTUBE_ORIGIN,
  COMPANION_WS_PATH,
  STORAGE_KEYS,
  MSG,
  COMPANION_ACTIONS,
  AD_BLOCKED_ACTIONS,
  validateBridgeBase,
  validateBridgeSecret,
  validateVideoId,
  validatePlaylistId,
  canonicalWatchUrl,
  canonicalPlaylistUrl,
} from "./common.js";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const RECONNECT_ALARM   = "bridge_reconnect";
const KEEPALIVE_ALARM   = "bridge_keepalive";
const RECONNECT_BACKOFF = [1000, 2000, 5000, 10000, 20000, 30000, 60000];
const TARGET_ID         = "browser_companion"; // CompanionBridge.TARGET_ID

// ---------------------------------------------------------------------------
// Worker-lifetime state (re-established after worker wakes)
// ---------------------------------------------------------------------------
let socket          = null;
let connecting      = false;
let reconnectAttempt = 0;
let currentSession  = 0;     // mirrored from auth_ok / command frames
let authenticated   = false;
let adPlaying       = false; // maintained from content state; gates commands
let lastStatus      = { connected: false, paired: false, detail: "not started" };

// ---------------------------------------------------------------------------
// Storage helpers
// ---------------------------------------------------------------------------
async function readConfig() {
  const d = await chrome.storage.local.get([
    STORAGE_KEYS.bridgeBase,
    STORAGE_KEYS.bridgeSecret,
    STORAGE_KEYS.paired,
  ]);
  return {
    bridgeBase:   d[STORAGE_KEYS.bridgeBase]   || "",
    bridgeSecret: d[STORAGE_KEYS.bridgeSecret] || "",
    paired:       !!d[STORAGE_KEYS.paired],
  };
}

async function storeSecret(secret) {
  await chrome.storage.local.set({
    [STORAGE_KEYS.bridgeSecret]: secret,
    [STORAGE_KEYS.paired]: true,
  });
}

async function clearSecret() {
  await chrome.storage.local.remove([STORAGE_KEYS.bridgeSecret, STORAGE_KEYS.paired]);
}

function setStatus(patch) {
  lastStatus = { ...lastStatus, ...patch };
}

// ---------------------------------------------------------------------------
// WebSocket connection
// ---------------------------------------------------------------------------
async function connectBridge() {
  if (connecting || (socket && socket.readyState === WebSocket.OPEN)) return;

  const { bridgeBase, bridgeSecret, paired } = await readConfig();
  if (!bridgeBase) {
    setStatus({ connected: false, paired: false, detail: "no bridge URL configured" });
    return;
  }
  let base;
  try { base = validateBridgeBase(bridgeBase); } catch (_e) {
    setStatus({ connected: false, detail: "invalid bridge URL" });
    return;
  }
  if (!paired) {
    setStatus({ connected: false, paired: false, detail: "not paired" });
    return;
  }

  const wsUrl = toWsUrl(base);
  connecting  = true;
  authenticated = false;
  adPlaying   = false;
  setStatus({ paired: true, detail: "connecting…" });

  let ws;
  try { ws = new WebSocket(wsUrl); } catch (_e) {
    connecting = false;
    setStatus({ connected: false, detail: "could not open socket" });
    scheduleReconnect();
    return;
  }
  socket = ws;

  ws.addEventListener("open", () => {
    connecting = false;
    // Reconnect path: send hello with the stored bridge secret.
    readConfig().then(({ bridgeSecret: sec, paired: p }) => {
      if (!p || !sec) {
        // No secret yet — waiting for PAIR message from options page.
        setStatus({ connected: true, paired: false, detail: "waiting for pairing token" });
        return;
      }
      ws.send(JSON.stringify({ type: "hello", secret: sec }));
      setStatus({ connected: true, paired: true, detail: "authenticating…" });
    });
  });

  ws.addEventListener("message", (ev) => { handleBridgeMessage(ws, ev.data).catch(() => {}); });
  ws.addEventListener("close",   ()     => {
    if (socket === ws) socket = null;
    authenticated = false;
    connecting    = false;
    setStatus({ connected: false, detail: "disconnected" });
    scheduleReconnect();
  });
  ws.addEventListener("error", () => { try { ws.close(); } catch (_e) {} });
}

// Open a new socket explicitly for pairing (hello with token).
// Called by the PAIR message handler after the options page stores the base URL.
async function openPairingSocket(token, bridgeBase) {
  let base;
  try { base = validateBridgeBase(bridgeBase); } catch (_e) {
    setStatus({ connected: false, detail: "invalid bridge URL" });
    return;
  }
  const wsUrl = toWsUrl(base);

  // If already open and unauthenticated, send on existing socket.
  if (socket && socket.readyState === WebSocket.OPEN && !authenticated) {
    socket.send(JSON.stringify({ type: "hello", token }));
    setStatus({ detail: "pairing…" });
    return;
  }
  if (socket) { try { socket.close(); } catch (_e) {} socket = null; }

  connecting    = true;
  authenticated = false;
  setStatus({ detail: "connecting for pairing…" });

  let ws;
  try { ws = new WebSocket(wsUrl); } catch (_e) {
    connecting = false;
    setStatus({ connected: false, detail: "could not open socket" });
    return;
  }
  socket = ws;

  ws.addEventListener("open", () => {
    connecting = false;
    ws.send(JSON.stringify({ type: "hello", token }));
    setStatus({ connected: true, detail: "pairing…" });
  });
  ws.addEventListener("message", (ev) => { handleBridgeMessage(ws, ev.data).catch(() => {}); });
  ws.addEventListener("close",   ()     => {
    if (socket === ws) socket = null;
    authenticated = false;
    connecting    = false;
    setStatus({ connected: false, detail: "disconnected" });
    scheduleReconnect();
  });
  ws.addEventListener("error", () => { try { ws.close(); } catch (_e) {} });
}

function toWsUrl(origin) {
  // Convert http(s):// origin to ws(s):// for the WebSocket constructor.
  return (origin + COMPANION_WS_PATH)
    .replace(/^http:/, "ws:")
    .replace(/^https:/, "wss:");
}

function scheduleReconnect() {
  const delay = RECONNECT_BACKOFF[Math.min(reconnectAttempt, RECONNECT_BACKOFF.length - 1)];
  reconnectAttempt++;
  chrome.alarms.create(RECONNECT_ALARM, { when: Date.now() + delay });
}

function bridgeSend(obj) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(obj));
    return true;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Inbound bridge message handling
// ---------------------------------------------------------------------------
async function handleBridgeMessage(ws, raw) {
  let frame;
  try { frame = JSON.parse(raw); } catch (_e) { return; }
  if (!frame || typeof frame !== "object") return;

  switch (frame.type) {
    case "welcome":
      // Server ready; hello already sent (for secret reconnect) or will be
      // sent after PAIR message supplies the token.
      break;

    case "paired": {
      // Server accepted the one-time token. Persist the bridge secret NOW.
      // The pairing token is never stored — only the secret.
      const rawSecret = String(frame.secret || "");
      let secret;
      try { secret = validateBridgeSecret(rawSecret); } catch (_e) {
        try { ws.close(); } catch (_e2) {}
        return;
      }
      await storeSecret(secret);
      // auth_ok follows immediately from the server.
      setStatus({ paired: true, detail: "secret stored, awaiting auth_ok" });
      break;
    }

    case "auth_ok": {
      reconnectAttempt = 0;
      authenticated    = true;
      try { currentSession = parseInt(frame.session, 10) || 0; } catch (_e) { currentSession = 0; }
      setStatus({ connected: true, paired: true, detail: "ready" });
      break;
    }

    case "auth_error": {
      authenticated = false;
      const reason  = String(frame.reason || "auth failed");
      // If the reason does NOT contain "pairing" / "token", this was a secret
      // rejection — the stored secret is invalid; clear it so the user knows
      // they must re-pair.
      const isSecretRejection = !reason.includes("token") && !reason.includes("pairing");
      if (isSecretRejection) {
        await clearSecret();
        setStatus({ connected: false, paired: false, detail: "secret rejected — re-pair required" });
      } else {
        setStatus({ connected: false, detail: "pairing failed: " + reason });
      }
      // Socket is closed by the server after auth_error; close handler will
      // schedule reconnect — but only if still paired. If secret was cleared
      // above, reconnect is futile and will be skipped by connectBridge().
      break;
    }

    case "revoked": {
      // Owner rotated or revoked. Erase secret immediately. Do NOT reconnect.
      authenticated = false;
      await clearSecret();
      reconnectAttempt = 999; // suppress reconnect until user re-pairs
      setStatus({ connected: false, paired: false, detail: "revoked by server" });
      break;
    }

    case "command": {
      if (!authenticated) return; // must not happen; ignore defensively
      // Update currentSession if the server advanced it.
      const fSession = frame.session;
      if (typeof fSession === "number" && fSession > currentSession) {
        currentSession = fSession;
      }
      await routeCommand(frame);
      break;
    }

    case "ping": {
      bridgeSend({ type: "pong", id: frame.id });
      break;
    }

    default:
      break;
  }
}

// ---------------------------------------------------------------------------
// Command routing
// ---------------------------------------------------------------------------
async function routeCommand(frame) {
  const cmdId  = frame.id;
  const action = String(frame.action || "");

  const ackOk  = ()      => bridgeSend({ type: "ack", id: cmdId, ok: true });
  const ackErr = (error) => bridgeSend({ type: "ack", id: cmdId, ok: false, error });

  // 1. Target fencing: must be "browser_companion" (TARGET_ID).
  if (String(frame.target || "") !== TARGET_ID) return ackErr("wrong_target");

  // 2. Action must be in the canonical allowlist.
  if (!COMPANION_ACTIONS.includes(action)) return ackErr("action_not_allowed");

  // 3. FULL AD PASSIVITY: while an ad is playing every action is blocked.
  //    AD_BLOCKED_ACTIONS === COMPANION_ACTIONS (no exceptions, incl. duck/restore,
  //    next/previous). Ack "busy_ad" (backend's error code) and touch nothing.
  if (adPlaying && AD_BLOCKED_ACTIONS.has(action)) return ackErr("busy_ad");

  // 4. Navigation: performed HERE using canonical URLs re-derived from validated IDs.
  //    Ad safety for navigation to an EXISTING target tab is enforced with a
  //    synchronous fresh ad check against the content script immediately before
  //    tabs.update. New-tab creation is only permitted when there is NO existing
  //    target tab (i.e. no ad context can exist).
  if (action === "navigate_video") {
    let videoId;
    try   { videoId = validateVideoId(frame.video_id); }
    catch (_e) { return ackErr("invalid_video_id"); }
    const url          = canonicalWatchUrl(videoId);
    const startSeconds = typeof frame.start_seconds === "number" ? frame.start_seconds : 0;
    return navigateYouTubeGuarded(url, startSeconds, /*isVideo=*/true, ackOk, ackErr);
  }

  if (action === "navigate_playlist") {
    let playlistId;
    try   { playlistId = validatePlaylistId(frame.playlist_id); }
    catch (_e) { return ackErr("invalid_playlist_id"); }
    const url = canonicalPlaylistUrl(playlistId);
    return navigateYouTubeGuarded(url, 0, /*isVideo=*/false, ackOk, ackErr);
  }

  // 5. All other actions → content script.
  const tab = await resolveYouTubeTab();
  if (!tab) return ackErr("no_youtube_tab");

  const envelope = {
    type:   MSG.COMMAND,
    action,
    params: extractParams(action, frame),
  };

  try {
    const result = await chrome.tabs.sendMessage(tab.id, envelope);
    if (result && result.accepted) return ackOk();
    return ackErr(String((result && result.error) || "rejected"));
  } catch (_e) {
    return ackErr("content_unreachable");
  }
}

// Synchronously ask a content script for a FRESH ad-state reading.
// Returns:
//   { adPlaying: bool, ok: true }  on a confirmed answer, or
//   { ok: false }                  when the answer cannot be confirmed safely
//                                  (content unreachable / malformed reply).
// Callers treat any non-confirmation as "unsafe → do not navigate".
async function freshAdCheck(tabId) {
  try {
    const reply = await chrome.tabs.sendMessage(tabId, { type: MSG.AD_CHECK });
    if (reply && typeof reply.ad_playing === "boolean") {
      return { ok: true, adPlaying: reply.ad_playing };
    }
    return { ok: false };
  } catch (_e) {
    return { ok: false };
  }
}

// Guarded navigation:
//   - If an existing target tab is present, do a synchronous fresh ad check
//     against it IMMEDIATELY before tabs.update. If content reports an ad, or
//     cannot confirm safely, reject with busy_ad — never navigate over an ad.
//   - If NO existing target tab is present, open a NEW tab (no ad context can
//     exist yet, so this is safe).
async function navigateYouTubeGuarded(url, startSeconds, isVideo, ackOk, ackErr) {
  let dest = url;
  if (isVideo && startSeconds > 0) dest += `&t=${Math.round(startSeconds)}`;

  const tab = await resolveYouTubeTab();

  if (tab) {
    // Existing target tab — must confirm no ad is playing, synchronously, now.
    const check = await freshAdCheck(tab.id);
    if (!check.ok)       return ackErr("busy_ad_unconfirmed"); // cannot confirm → refuse
    if (check.adPlaying) { adPlaying = true; return ackErr("busy_ad"); }
    try {
      await chrome.tabs.update(tab.id, { url: dest });
      return ackOk();
    } catch (_e) { return ackErr("navigation_failed"); }
  }

  // No existing target tab → no ad context possible. Opening a fresh tab is safe.
  try {
    await chrome.tabs.create({ url: dest });
    return ackOk();
  } catch (_e) { return ackErr("navigation_failed"); }
}

// Extract bounded, type-checked params for a given action from the command frame.
// No URLs or free-form strings ever pass through to the content script.
function extractParams(action, frame) {
  const numClamp = (v, lo, hi) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : undefined;
  };
  switch (action) {
    case "seek":
      return {
        offset_seconds: numClamp(frame.offset_seconds, -86400, 86400),
        target_seconds: numClamp(frame.target_seconds, 0, 86400),
      };
    case "set_volume":
      return { volume: numClamp(frame.volume, 0, 100) };
    case "adjust_volume":
      return { delta: numClamp(frame.delta, -100, 100) };
    case "duck":
      // COMPANION_PROTOCOL.md: duck payload field is "volume" (default 20).
      return { volume: numClamp(frame.volume, 0, 100) !== undefined
                         ? numClamp(frame.volume, 0, 100)
                         : 20 };
    default:
      return {}; // play/pause/stop/next/previous/restart/mute/unmute/restore
  }
}

// Return the most-recently-accessed YouTube tab, or null.
async function resolveYouTubeTab() {
  const tabs = await chrome.tabs.query({ url: `${YOUTUBE_ORIGIN}/*` });
  if (!tabs.length) return null;
  const active = tabs.find((t) => t.active);
  if (active) return active;
  return tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
}

// ---------------------------------------------------------------------------
// Content-script state → bridge relay
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // No tab = popup or options page.
  if (!sender.tab) {
    // A rejected async handler used to leave the options page with no response,
    // which it could only report as “unknown”. Return a safe, actionable error
    // without ever including a pairing token or bridge secret.
    handleUiMessage(message).then(
      sendResponse,
      (error) => sendResponse({
        ok: false,
        reason: "extension service worker error: " +
          (error && error.message ? error.message : String(error)),
      }),
    );
    return true;
  }

  // Validate content-script origin.
  const originOk =
    sender.origin === YOUTUBE_ORIGIN ||
    (sender.url && sender.url.startsWith(`${YOUTUBE_ORIGIN}/`));
  if (!originOk) return false;

  if (message && message.type === MSG.CONTENT_STATE) {
    const cs = message.state || {};

    // Update the background ad flag — used to gate ALL ad-blocked commands.
    adPlaying = !!cs.ad_playing;

    // Relay to bridge as a "state" frame with session + target fencing.
    // Include ad_playing boolean as per COMPANION_PROTOCOL.md §state.
    if (authenticated && socket && socket.readyState === WebSocket.OPEN) {
      const stateFrame = {
        type:      "state",
        session:   currentSession,
        target:    TARGET_ID,
        status:    cs.status || "stopped",
        ad_playing: !!cs.ad_playing,
      };
      if (typeof cs.video_id === "string" && cs.video_id)
        stateFrame.video_id = cs.video_id;
      if (typeof cs.playlist_id === "string" && cs.playlist_id)
        stateFrame.playlist_id = cs.playlist_id;
      if (typeof cs.position_seconds === "number")
        stateFrame.position_seconds = cs.position_seconds;
      if (typeof cs.duration_seconds === "number")
        stateFrame.duration_seconds = cs.duration_seconds;
      if (typeof cs.volume === "number")
        stateFrame.volume = Math.round(cs.volume);
      if (typeof cs.muted === "boolean")
        stateFrame.muted = cs.muted;
      bridgeSend(stateFrame);
    }

    sendResponse({ ok: true });
    return true;
  }

  if (message && message.type === MSG.CONTENT_HELLO) {
    sendResponse({ ok: true, connected: authenticated });
    return true;
  }
  return false;
});

// ---------------------------------------------------------------------------
// UI (popup / options) message handler
// ---------------------------------------------------------------------------
async function handleUiMessage(message) {
  if (!message || typeof message !== "object") return { ok: false };
  switch (message.type) {
    case MSG.GET_STATUS: {
      const { bridgeBase, paired } = await readConfig();
      return {
        ok: true,
        status: {
          ...lastStatus,
          paired,
          hasBridgeBase: !!bridgeBase,
          authenticated,
        },
      };
    }

    case MSG.PAIR: {
      // Options page validated the URL (and stored it) then passes the
      // one-time token here in memory — it is NEVER written to storage.
      const { token, bridgeBase } = message;
      if (!token || !bridgeBase) return { ok: false, reason: "missing token or bridgeBase" };
      reconnectAttempt = 0;
      await openPairingSocket(String(token), String(bridgeBase));
      return { ok: true };
    }

    case MSG.UNPAIR: {
      try { socket && socket.close(); } catch (_e) {}
      socket        = null;
      authenticated = false;
      adPlaying     = false;
      reconnectAttempt = 0;
      await clearSecret();
      await chrome.storage.local.remove([STORAGE_KEYS.bridgeBase]);
      setStatus({ connected: false, paired: false, detail: "unpaired" });
      return { ok: true };
    }

    case MSG.TEST_BRIDGE: {
      return probeBridge(message.bridgeBase);
    }

    default:
      return { ok: false };
  }
}

// ---------------------------------------------------------------------------
// Reachability probe (no token, no secret sent)
// ---------------------------------------------------------------------------
async function probeBridge(rawBase) {
  let base;
  try { base = validateBridgeBase(rawBase); } catch (e) { return { ok: false, reason: e.message }; }
  const wsUrl = toWsUrl(base);
  return new Promise((resolve) => {
    let ws;
    const done = (ok, reason) => { try { ws && ws.close(); } catch (_e) {} resolve({ ok, reason }); };
    const timer = setTimeout(() => done(false, "timed out"), 4000);
    try { ws = new WebSocket(wsUrl); } catch (_e) { clearTimeout(timer); return done(false, "cannot open socket"); }
    // Server sends "welcome" before auth — that's enough to confirm reachability.
    ws.addEventListener("message", () => { clearTimeout(timer); done(true, "reachable"); });
    ws.addEventListener("error",   () => { clearTimeout(timer); done(false, "unreachable"); });
    ws.addEventListener("close",   (ev) => { clearTimeout(timer); done(ev.code !== 1006, "reachable (closed early)"); });
  });
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RECONNECT_ALARM || alarm.name === KEEPALIVE_ALARM) {
    connectBridge().catch(() => {});
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 1 });
  connectBridge().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 1 });
  connectBridge().catch(() => {});
});

chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 1 });
connectBridge().catch(() => {});
