# Chat — a private home voice assistant

Chat runs on your own Windows laptop. Say the wake word, talk to it like a
person (powered by Gemini Live), and it can set real timers, reminders and
wake-up alarms, tell you the weather, and control your Govee lights. When the
internet or your Gemini quota runs out, it keeps working locally: timers,
reminders, lights, and the dashboard never depend on the cloud.

Everything lives on your machine: keys are encrypted at rest, the dashboard
runs on localhost, and nothing is sent anywhere except Google (voice) and
Govee (lights).

## What makes this build different

**Automatic key rotation, no paid fallback.** Add as many free Gemini API
keys as you like — from different Google projects — and Chat rotates through
all of them automatically. When one project's daily quota runs out it blocks
that whole project until the documented reset time (midnight Pacific) and
moves to the next key instantly, mid-conversation reconnects included. More
keys = more daily capacity. Keys you label with the same project name are
treated as one shared quota (redundancy, not extra capacity).

**As light as possible.** One quiet Python process, below-normal CPU
priority, a nearly silent console window, no busy loops. Voice packages are
optional — without them Chat still runs the dashboard, timers, rotation, and
lights.

## Quick start (Windows)

1. Install Python 3.11+ from https://www.python.org/downloads/
   (tick **"Add python.exe to PATH"** during install).
2. Download this project folder to your laptop and open it.
3. Double-click `deployment\windows\install.bat`
   — it creates a private environment and installs the core packages.
   Say yes to the voice packages if you want the microphone side.
4. Double-click `run_chat.bat`. A small black console window opens and prints
   the control panel address.
5. Open http://127.0.0.1:8756 in your browser, create your password, and add
   your first Gemini key on the **Credentials** page
   (free keys: https://aistudio.google.com/apikey).

That's it. Say "Hey Jarvis" (the default wake word — see below) and talk.

### Getting more daily talk time

Create additional free API keys in *different* Google Cloud projects
(AI Studio → gear icon → switch project → create key). Add each one on the
Credentials page. Leave the project label empty (each key becomes its own
quota group) or use labels to mark keys that share a project.

### Wake word

Pick one in **Settings → Voice & wake word**: Hey Jarvis (default), Alexa,
Hey Mycroft, or Hey Rhasspy. The change applies live — no restart. To use a
custom "Chat" wake word, train a model at
https://github.com/dscripka/openWakeWord#training-new-models, choose
"Custom model file..." in the picker, and give the path to the `.onnx` file.

### Voice announcements (optional, offline)

Run once to generate spoken status messages with Windows' built-in TTS:

    .venv\Scripts\python.exe deployment\windows\generate_announcements.py

Without them, announcements print to the console with a bell sound. Re-run
it after an update that adds new messages (this version added the quiet mode
confirmations and the missed-reminder notice).

### Saying "stop"

Chat already goes quiet the moment you talk over it. Saying just **"stop"**
(or "be quiet", "shut up", "never mind") cancels the rest of the answer
entirely, and every dashboard page has a red **Stop talking** button that
does the same — handy from a phone. Stop works offline too if the offline
recognizer below is installed.

### Offline voice commands (optional)

Speech understanding normally runs through Gemini, so when every key is
blocked, voice commands stop. Install the offline recognizer and spoken
commands keep working with zero internet:

1. The `vosk` package is included in `requirements-voice.txt`
   (or `.venv\Scripts\pip install vosk`).
2. Download a small English model from https://alphacephei.com/vosk/models
   — `vosk-model-small-en-us-0.15` (~40 MB) is plenty.
3. Unzip it and rename the folder to `assets\vosk-model` inside the Chat
   folder, or point **Settings → Offline speech model folder** at it.

In local-only mode Chat then hears the wake word, records your sentence,
transcribes it on your own CPU, and runs it against the same safe grammar as
the dashboard command box: timers, reminders and alarms, weather, quiet mode,
lights, remember/recall/forget, stop. Anything outside that grammar gets a
short refusal announcement.

### Memory

Say "Chat, remember that the garage code is 4417" — stored permanently on
your machine. Ask "what do you remember about the garage?" and it answers
from its stored facts; "forget the garage code" deletes them. The
dashboard's **Memory** page lists everything with add and forget buttons.
Works through Gemini (natural phrasing) and offline through the local
grammar ("remember that...", "what do you remember", "forget ...").

### Reminders and alarms

"Remind me at 5 to take the chicken out", "remind me to stretch at 7:30 pm",
"wake me up at 7 am". Both survive restarts; anything that came due while
the machine was off is flagged as missed. An alarm (or a reminder) rings
loud — repeating bell pulses — until you say "stop", press a Stop button,
or tap **Dismiss** on the red banner that appears on every dashboard page.
With the offline voice installed, Chat also speaks the reminder text while
ringing. The **Reminders** page schedules them with a normal time picker,
and Settings controls how long and how loud they ring.

About ambiguous times: "at 5" means the next time the clock shows 5 —
5 pm if it's morning, 5 am tomorrow if it's evening. "Tonight at 9" is 9 pm.
"Tomorrow at 5" without am/pm takes the morning reading — say "5 pm" to be
precise.

### Weather

"What's the weather", "will it rain tomorrow". Set your town once in
**Settings → Weather & location** (type it, press Search, pick a result).
Forecasts come from Open-Meteo — free, no account, no API key — and the
Status page shows a weather card. Works by voice even in local-only mode;
with the offline voice installed Chat reads the forecast out loud.

### Quiet mode

"Quiet mode on" (or the sidebar button) stops all unprompted talking:
status notices, missed-timer announcements, and so on. Chat still answers
things you actually ask, and timers, reminders and alarms **still ring** —
deliberately, so a wake-up alarm can't be lost to quiet mode. If you want
those silent too, flip "In quiet mode, timers and alarms" in Settings.
Quiet mode is only ever switched by you — Chat never turns it on by itself.
It's different from the mic mute: mute stops Chat *hearing*, quiet stops it
*speaking up*.

### Listening on your phone

Open the dashboard from your phone (see LAN access below), then on
**Status → Listen on this device** tap **Start listening** — Chat's voice
now plays out of the phone. "Where the voice plays" controls the computer
side:

* **Computer speaker** — normal.
* **Phone only** — the computer stays silent. Perfect when the laptop's
  speaker is a Bluetooth box you don't want to use, or for headphones.
* **Both** — everywhere at once.

## Running modes

| Command                          | What runs                                  |
|----------------------------------|--------------------------------------------|
| `run_chat.bat`                   | Everything (voice auto-off if not installed)|
| `run_chat.bat --no-voice`        | Cloud + dashboard, microphone off           |
| `run_chat.bat --dashboard-only`  | Dashboard + timers only, no cloud at all    |
| `run_chat.bat --verbose`         | Same, with chatty console logging           |
| `deployment\windows\run_hidden.vbs` | Fully invisible (no window)              |

## Choosing who answers (brains)

Chat can use three different brains for voice conversations. Pick one in
**Settings → Brain**. Google is the default and stays the default unless
you change it.

| Brain | How it feels | What it needs | What it costs |
|-------|--------------|---------------|---------------|
| **Google (Gemini live)** | Live conversation, you can talk over it | Free Gemini keys on the Credentials page | Free (daily quota per key) |
| **OpenAI live** | Live conversation, you can talk over it | Your own OpenAI API key on the Providers page | Paid, billed by OpenAI to your OpenAI account |
| **Relay on Replit** | Walkie-talkie: say your piece, it answers, then listens again | Your published relay app's address (Settings) + the relay password (Providers page) | Replit credits, billed to your Replit account |

Notes in plain terms:

* **OpenAI live** talks straight from your laptop to OpenAI using your key.
  The key lives in the encrypted vault and is only ever sent to OpenAI.
  You need a paid OpenAI account with credit on it.
* **The relay** is a tiny server you publish on your own Replit account.
  Chat records what you said, sends it to the relay, and the relay uses
  Replit's AI service to write it down, think, and speak the answer back.
  Timers, lights, reminders and memory all still work. It is slower than
  the live brains — that is the trade for it running on Replit credits.
  The **daily call limit** in Settings is the spending guard: once Chat has
  made that many relay calls in a day, relay conversations stop until
  tomorrow.
* The relay can use different models for different jobs: quick commands go
  to a cheap fast model, open questions to a smarter one. Both are
  changeable in Settings.
* If the brain you picked cannot start (no key saved, wrong password, no
  internet to that service), Chat says why in the Logs page and answers
  that conversation with Google instead, so the house never goes silent.

## The dashboard

* **Status** — live state (SLEEPING / LISTENING / SPEAKING / LOCAL_ONLY),
  component health, usable-key count, next quota retry, quiet mode, the
  weather card, the phone address, and the local command box.
* **Credentials** — add/disable/delete Gemini keys, grouped by project, with
  masked suffixes only. "Make active" switches keys for the *next* session —
  a live conversation is never interrupted.
* **Providers** — Govee API key, the optional OpenAI key, the optional
  relay password, and the rotation policy explained.
* **Usage** — session starts/ends and tool calls (sanitized, never content).
* **Devices** — your Govee lights with quick on/off.
* **Timers** — create, pause, resume, cancel. Timers survive restarts;
  anything that expired while the machine was off is announced as missed.
* **Reminders** — clock-time reminders and loud alarms with a time picker,
  plus recent fired/missed history. A ringing alarm shows a red banner with
  a Dismiss button on every page.
* **Memory** — every fact Chat has been asked to remember, with add and
  forget buttons.
* **Logs** — the detailed event log (the console stays quiet on purpose).
* **Settings** — everything is editable here: the brain picker, wake word
  picker, microphone and speaker choice, sound routing, alarm ring length
  and loudness, your town for weather, key rotation and quota tuning,
  health-check intervals, updates, phone access, password. Voice settings
  apply live without a restart.

Every page also has the red **Stop talking** button and the mute switch.
The pages are light-colored by default; the **Dark mode** button at the
bottom of the menu switches, and every device remembers its own choice —
your phone can stay dark while the laptop stays light.

### Reaching the dashboard from your phone

Phone access is on by default for new installs: the console window prints a
"Phone on Wi-Fi" address (also shown on the Status page and in Settings) —
open it on any device on your Wi-Fi and sign in with your dashboard
password. (The very first password creation only works on the laptop
itself — other devices are refused until the password exists.) The pages
are phone-friendly, with a slide-out menu and big Stop / Dismiss buttons. To restrict the dashboard to this computer only,
set **Settings → Dashboard access → Phone access** to Off and restart.
Upgraded installs keep their old setting — flip it to On the same way.
For HTTPS, run `python deployment\windows\make_cert.py` once and restart.
Open **Phone HTTPS setup** on the Chat laptop, download the public
certificate there, compare its fingerprint, and transfer it to the phone
using USB, AirDrop, or another trusted local method. Never install a
certificate downloaded across an untrusted Wi-Fi connection, and never
transfer `ca-key.pem` or `key.pem`.

## What's new in 1.9.8

* **Companion connection test fix** — the tokenless connection test now runs
  directly in the extension options page instead of keeping a one-shot
  Chrome service-worker message open while it waits for the WebSocket. Chrome
  can close that message port even when Chat is available, producing the
  misleading “message port closed before a response was received” error.
  Update to **Chat YouTube Companion 1.0.3** and use **Test connection** again.

## What's new in 1.9.7

* **Companion connection fix** — the companion extension now asks Chrome only
  for permission to reach Chat on `127.0.0.1` / `localhost`, which Chrome needs
  before its background worker may reach the local bridge. Its connection test
  also reports the real browser or service-worker error instead of "unknown".
  Install **Chat YouTube Companion 1.0.2** after updating Chat, then use the
  plain `ws://` bridge address shown in Settings.

## What's new in 1.9.6

* **The companion extension can actually pair now** — Chat serves the
  companion bridge on its own loopback port that is always plain `ws://`, even
  when the dashboard runs on HTTPS. A browser extension cannot approve Chat's
  self-signed local certificate, so the old `wss://` address failed with an
  unexplained error and pairing never completed. The new port is bound
  strictly to `127.0.0.1`, still authenticates every frame with the bridge
  secret, and carries only media commands. Chat prints the address at startup
  and shows it in **Settings → YouTube companion extension**. Pin it with
  `companion_bridge_port` if you prefer a fixed port.
* **Chat stops going deaf when you mute the music** — muting, setting volume
  to zero, or pausing now counts as silence, so the microphone gate reopens at
  once instead of behaving as if music were still playing. This also works
  when you press mute in YouTube itself with the companion connected.
* **The microphone can no longer be ratcheted shut** — the noise floor learned
  during playback now falls back to normal within about a second of the room
  going quiet, and rises slowly, so half-heard words can no longer push the
  speech threshold further out of reach the longer you talk. Loud music is
  still filtered out and protection against Chat hearing its own reply is
  unchanged, so speaking up over a loud track is still expected.
* 1.9.5 was published briefly and replaced the same day by 1.9.6, which keeps
  the fixes above but restores full filtering of loud music.

  One limit is worth knowing, because it cannot be fixed by tuning: the filter
  measures loudness, so music that gets much louder than it was a moment ago
  can be heard as if somebody were talking, until the track quietens again.
  Every rule that would block a loud steady track also blocks a person
  speaking steadily, and being unable to talk to Chat is the worse of the two
  failures. Your speakerphone's own echo cancellation, headphones, or a lower
  media volume all avoid it.

## What's new in 1.9.4

* **Full YouTube companion mode** — the optional Chrome/Edge extension keeps
  the normal `youtube.com` page, recommendations, comments, subscriptions,
  playlists, and account features. Jarvis stays in its Voice Controller while
  the dedicated YouTube tab is reused in the background.
* **Live voice media controls** — Jarvis can play, pause, stop, seek, restart,
  move next/previous, set or adjust player volume, and mute/unmute. Manual
  changes in YouTube are reflected back to Chat.
* **Listen while music plays** — the local and browser microphone paths keep
  wake listening active. Confirmed nearby speech ducks the player, a verified
  wake/conversation turn pauses it, and Chat restores only audio changes that
  it owns. The playback-aware gate helps reject speaker lyrics; effective
  hardware echo cancellation or headphones remain the strongest protection.
* **Local and narrowly permissioned** — pairing uses a one-time token and a
  loopback-only authenticated WebSocket. The extension runs only on
  `youtube.com`, opens only server-validated canonical video/playlist IDs, and
  refuses every media command while YouTube reports an ad.

### Install the YouTube companion

1. Extract
   `deployment\chrome_extension\chat-youtube-companion-1.0.2.zip` to a
   permanent folder on the Chat computer. Version 1.0.2 is required for
   the local companion bridge permission and clear connection diagnostics.
2. Open `chrome://extensions` or `edge://extensions`, enable Developer mode,
   choose **Load unpacked**, and select that extracted folder.
3. Start Chat and open **Settings → YouTube companion extension → Generate
   pairing token**.
4. Open the extension's **Pairing & settings**, enter the bridge address shown
   by Chat, paste the one-time token, and choose **Pair now**.

The browser requires manual installation for security; Chat never installs an
extension or reads a browser profile without permission.

### 1.9.3 fixes

* **Speaker-feedback protection** — the Voice Controller now uses the
  browser's echo cancellation in one audio graph, never routes the raw
  microphone to the speakers, and tells the server exactly while Chat's own
  reply is playing. A playback-aware gate filters speaker leakage and room
  echo while still allowing a clearly louder interruption.
* **Automatic YouTube playback** — a normal play request searches for a
  canonical result and starts it without saying it was queued. The official
  dashboard embed is used first. If no player is open, embedding is blocked,
  or autoplay is blocked, Chat opens only the validated official YouTube URL
  in the computer's default browser.
* **Playlists and continuous play** — official YouTube playlist links and
  playlist searches are supported. Embedded search-result queues advance and
  loop until a media-qualified command such as “stop the music” is given.
  Bare “Stop Jarvis” still interrupts Chat's current reply only.
* **Live, honest media status** — the dashboard shows whether playback is
  embedded or in the computer browser. Controls that cannot operate a
  separate browser tab are disabled instead of pretending they worked.

### 1.9.2 fixes

* **Browser wake word fixed** — the Voice Controller converts the browser's
  real microphone rate to exact 16 kHz audio, stays in “Say Hey Jarvis”
  mode, and opens a conversation only after the wake word. Goodbye, mute,
  and timeout return to wake-listening without closing the page.
* **Fast transcripts** — long sessions open with the newest 200 lines and
  load older lines on demand instead of freezing the page.
* **Private Wi-Fi connection help** — Chat prints every usable current
  RFC1918 address. `deployment\windows\allow_lan_access.bat` can add an
  explicit Windows Firewall rule limited to Chat's TCP port, the Private
  profile, and `LocalSubnet`; it never runs automatically.

### 1.9.1 fixes

* **Clearer audio help** — microphone and speaker startup failures now name
  the device side and retain Windows/PortAudio's actual reason. Expected
  browser or phone disconnect resets no longer fill the Windows console.

### 1.9.0 features

* **Continuous Jarvis voice mode** — say “Hey Jarvis” once and keep talking.
  The rolling quiet timeout is 30 minutes. “Stop Jarvis” only interrupts
  the current reply; “Goodbye Jarvis” ends the conversation and requires a
  new wake word.
* **Voice Controller** — a separate phone/browser microphone window keeps
  voice active while you move between Chat, Media, Logs, Settings, Usage,
  and Transcripts.
* **Typed Chat and transcripts** — durable text conversations, safe image
  questions through OpenAI, and a visual history of voice conversations.
* **YouTube Media** — deterministic normal/official-result selection,
  selected-device playback controls, blocked-embed fallback to the official
  YouTube page, and no downloading or copyright bypass.
* **Web and news tools** — bounded current-time, web search, and headline
  tools that treat search text as untrusted reference material.
* **Reliable alarms** — ringing survives restarts, keeps ringing until
  dismissed, and supports 10-minute snooze.
* **Windows reliability** — valid time zones work on Windows, duplicate
  launches exit cleanly, optional Start with Windows runs hidden, and
  harmless wake-engine warnings are removed.
* **Clearer dashboard** — every provider pipeline stays visible, everyday
  settings appear first, and technical model tuning lives under Advanced
  settings.

## Automatic updates

Chat updates itself. New versions are published at

    https://raw.githubusercontent.com/Nick-PY0/chat-assistant-updates/main/latest.json

and fresh installs have that link set as the default — nothing to do. Chat
checks it quietly every 6 hours, downloads a new version in the background,
checks the publisher's tamper-proof signature on it, and swaps it in on the
next start — or right away via **Settings → Restart Chat**. An update that
is unsigned or altered in any way is refused. On an older install, open
**Settings → Updates → Update link**: if the box is empty, paste the link
above once. To opt out, turn **Automatic updates** off in Settings.

### Publishing to your own link instead

Prefer a link you control? Host a small `latest.json` anywhere public (a
GitHub release works great):

       {
         "version": "1.2.0",
         "zip_url": "https://github.com/you/chat/releases/download/v1.2.0/chat-assistant.zip",
         "notes": "what changed"
       }

Paste that link into **Settings → Updates → Update link**. To publish a
new version: bump `APP_VERSION` in `chat_core/version.py`, zip the whole
`chat-assistant` folder, upload it, and update `latest.json`.

Chat refuses unsigned updates by default. For your own channel, create
your own keys once with `python deployment/release/sign_manifest.py keygen`
(put the printed public key into `apps/updater/updater.py`), then sign
every release with
`python deployment/release/sign_manifest.py sign latest.json your.zip`
before uploading — that fills in the `sha256` and `sig` fields. If you
would rather skip signing on a private link you trust, turn **Require
signed updates** off in Settings.

Downloads are size-capped, checked to be a real Chat build, and staged in
the data folder first — a bad or half-finished download can never break the
running install.

GitHub walkthrough: create a repository → **Releases** → *Draft a new
release* → attach the zip **and** `latest.json` → publish. Then
`https://github.com/<you>/<repo>/releases/latest/download/latest.json`
always points at your newest release, so it never needs changing.

## Building Chat.exe (runs without Python)

On any Windows machine with the project and `.venv` set up:

    deployment\windows\build_exe.bat

This produces `dist\Chat\` with **Chat.exe** inside. The folder is fully
self-contained — copy it to any Windows computer and double-click the exe;
Python does not need to be installed there. Whatever is in `.venv` at build
time gets baked in, so install the voice packages first if you want voice.
A vosk model can also be dropped next to the exe later
(`Chat\assets\vosk-model`).

Notes:

* The exe must be built **on Windows** — PyInstaller cannot cross-build, so
  run the build on the laptop itself.
* Auto-update works for exe installs too: zip the new `dist\Chat` folder and
  point `zip_url` at that zip.

## Security model (short version)

* API keys are encrypted (AES-256-GCM) with a master secret held in the
  Windows Credential Locker (or a protected file if `keyring` is missing).
* The dashboard password is hashed with Argon2id; sessions are signed
  HttpOnly cookies; every write needs a CSRF token; login is rate-limited.
* First-time setup (creating that password) is only accepted from the
  computer running Chat itself, so nothing on your network can claim the
  dashboard before you do.
* Plaintext keys never appear in the UI, API responses, logs, or the console
  — only masked suffixes like `••••1234`.
* The assistant can only run allowlisted tools (timers, lights). It cannot
  touch your files, run commands, or change its own configuration.

## Data location

Everything Chat stores lives in `%LOCALAPPDATA%\ChatAssistant`
(config.json, chat.db, optional cert files). Set the `CHAT_DATA_DIR`
environment variable to move it. Delete that folder to factory-reset.

## Running the tests

    pip install pytest pytest-asyncio
    python -m pytest

## Project layout

    run_chat.py            single-process launcher (all services as tasks)
    run_chat.bat           Windows launcher (small black console window)
    chat_core/             config, event bus, state machine, DB, security
    apps/audio/            wake word, mic/speaker streams, announcements
    apps/live_gateway/     Gemini Live sessions + automatic key rotation
    apps/tool_service/     timers, reminders, weather, Govee tools, local grammar
    apps/pulse/            isolated health checks & quota-retry scheduling
    apps/dashboard/        FastAPI control panel (this is the web UI)
    apps/updater/          background self-update (manifest -> stage -> swap)
    integrations/          Gemini + Govee API clients
    deployment/windows/    installer, exe build, TTS + cert helpers
    migrations/            SQLite schema
    tests/                 pytest suite

## Troubleshooting

* **"voice pipeline disabled: audio packages not installed"** — run
  `pip install -r requirements-voice.txt` inside `.venv`, or ignore it if
  you only want the dashboard.
* **Wake word never triggers** — lower the sensitivity in Settings
  (e.g. 0.45), check Windows microphone permissions for Python.
* **"wake word unavailable" in the console or Logs** — the wake word model
  files were missing (they are a separate one-time download, which
  install.bat used to skip). Chat now downloads them by itself on the next
  start with internet; the message spells out anything else that is wrong.
* **"local mode" announcements** — every key is blocked or invalid. Check
  the Credentials page; Chat retries automatically at the earliest reset.
* **Dashboard unreachable from another device** — follow these steps in order:
  1. Test `https://127.0.0.1:8756` on the Chat computer itself. If that fails, Chat is not running.
  2. Use the exact address printed in the Chat console window (e.g. `https://172.16.151.131:8756`).
     Do NOT guess or use a stale address — copy it from the current console output.
  3. If localhost works but the phone times out, run `deployment\windows\allow_lan_access.bat`
     (double-click it; it requests Administrator only when needed). This creates a Windows Defender
     rule: TCP, Private profile, same subnet only.
  4. The phone must be on the same normal Wi-Fi as the Chat computer.
     Guest networks, client-isolation VLANs, VPNs, and mobile data all block direct LAN access.
  5. A certificate error (not a timeout) means the connection reached Chat successfully — install
     the local CA certificate (see Mobile HTTPS Setup in the dashboard menu).
  6. If the LAN IP changes (e.g. you reconnected to a different network), rerun
     `python deployment\windows\make_cert.py` and restart Chat.
* **An alarm didn't ring in quiet mode** — Settings → "In quiet mode,
  timers and alarms" must be "Still ring out loud" (the default).
* **Weather says "no home location set"** — pick your town in Settings →
  Weather & location, then press Save.
* **Phone listening is silent** — tap *Start listening* again after the
  phone screen was locked (browsers pause audio in the background), and
  check the routing isn't set to "Computer speaker" while you expected
  "Both".
* **Offline commands answer "that's not something I can do offline"** —
  the sentence didn't match the safe grammar (timers, lights, memory,
  stop). Check Logs to see what the recognizer heard.
* **An update downloaded but nothing changed** — updates apply on the next
  start: use Settings → Restart Chat or close and reopen the console
  window. The Updates card shows any error text.
