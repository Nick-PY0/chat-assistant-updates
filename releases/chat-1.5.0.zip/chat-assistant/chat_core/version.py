"""Single source of truth for the app version.

Bump this when publishing an update (see README "Automatic updates"):
the updater compares this against the version in your update manifest.
"""

APP_VERSION = "1.5.0"


def parse_version(text: str) -> tuple[int, ...] | None:
    """'v1.2.3' -> (1, 2, 3). Returns None if unparseable."""
    text = str(text or "").strip().lstrip("vV")
    if not text:
        return None
    parts = []
    for piece in text.split("."):
        piece = piece.strip()
        if not piece.isdigit():
            return None
        parts.append(int(piece))
    return tuple(parts) if parts else None


def is_newer(candidate: str, current: str) -> bool:
    a, b = parse_version(candidate), parse_version(current)
    if a is None or b is None:
        return False
    # pad to equal length so 1.2 == 1.2.0
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))
