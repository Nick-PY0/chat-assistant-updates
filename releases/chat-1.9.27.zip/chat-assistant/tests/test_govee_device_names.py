from unittest.mock import AsyncMock

from chat_core.identifiers import provider_secret_key
from integrations.govee.client import GoveeClient


async def test_discovery_replaces_exact_normalized_and_cross_device_secret_names():
    client = GoveeClient("secret")
    client._get = AsyncMock(return_value={
        "data": [
            {
                "device": "AA:BB-11",
                "sku": "H6001",
                "deviceName": "AA:BB-11",  # exact own identity
                "capabilities": [],
            },
            {
                "device": "Second_Device",
                "sku": "H-7000",
                "deviceName": "aa bb 11",  # normalized first identity
                "capabilities": [],
            },
            {
                "device": "ThirdDevice",
                "sku": "SKU-3",
                "deviceName": "h_6001",  # normalized other device's SKU
                "capabilities": [],
            },
            {
                "device": "Fourth",
                "sku": "SKU-4",
                "deviceName": "third-device",  # normalized other identity
                "capabilities": [],
            },
            {
                "device": "Fifth",
                "sku": "SKU-5",
                "deviceName": "Kitchen lights",
                "capabilities": [],
            },
        ]
    })

    devices = await client.list_devices()
    secret_keys = {
        provider_secret_key(value)
        for item in devices
        for value in (item["device"], item["sku"])
    }
    assert [item["name"] for item in devices[:4]] == [
        "Govee light 1",
        "Govee light 2",
        "Govee light 3",
        "Govee light 4",
    ]
    assert devices[4]["name"] == "Kitchen lights"
    assert all(provider_secret_key(item["name"]) not in secret_keys for item in devices)


async def test_discovery_replaces_nfkc_equivalent_own_and_cross_device_names():
    client = GoveeClient("secret")
    client._get = AsyncMock(return_value={
        "data": [
            {
                "device": "ABC123",
                "sku": "MODEL-ONE",
                "deviceName": "ＡＢＣ１２３",
                "capabilities": [],
            },
            {
                "device": "SECOND",
                "sku": "SKU99",
                "deviceName": "ＭＯＤＥＬ＿ＯＮＥ",
                "capabilities": [],
            },
            {
                "device": "THIRD",
                "sku": "MODEL-THREE",
                "deviceName": "ＳＫＵ９９",
                "capabilities": [],
            },
        ]
    })

    devices = await client.list_devices()
    assert [item["name"] for item in devices] == [
        "Govee light 1", "Govee light 2", "Govee light 3",
    ]
    output = str(devices)
    assert "ＡＢＣ１２３" not in output
    assert "ＭＯＤＥＬ＿ＯＮＥ" not in output
    assert "ＳＫＵ９９" not in output