from types import SimpleNamespace
import json

import httpx
import pytest

from apps.live_gateway.prompts import PROMPT_TOOLS_SUFFIX
from apps.tool_service.expert_tool import (
    ExpertError,
    ExpertRelayService,
    MAX_QUERY_CHARS,
    MAX_TOKENS,
    select_expert_models,
)
from apps.tool_service.local_grammar import parse
from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.schemas import online_tool_declarations
from chat_core.config.settings import Settings
from chat_core.runtime import Runtime
from integrations.relay.client import RelayClient, RelayDiscovery, RelayModel


def model(model_id, provider, rank=1, *, reasoning=True, enabled=True,
          modalities=("text",)):
    return RelayModel(
        model_id, "chat", "high", rank, rank, reasoning, False, modalities,
        provider=provider, enabled=enabled,
    )


def test_expert_selection_is_provider_text_enabled_and_bounded():
    models = (
        model("gpt-best", "openai", 100),
        model("gpt-off", "openai", 200, enabled=False),
        model("gpt-audio", "openai", 300, modalities=("audio",)),
        model("claude-best", "anthropic", 400),
    )
    selected = select_expert_models(
        models, "chatgpt", ["gpt-best", "gpt-off"], "gpt-best"
    )
    assert [item.id for item in selected] == ["gpt-best"]


def test_auto_selection_uses_suitable_model_families():
    chatgpt = (
        model("gpt-5.6-sol", "openai", 90),
        model("gpt-5.6-codex", "openai", 100),
        model("gpt-reasoner", "openai", 110),
    )
    assert select_expert_models(
        chatgpt, "chatgpt", [], "gpt-5.6-sol", query="debug this Python code"
    )[0].id == "gpt-5.6-codex"
    assert select_expert_models(
        chatgpt, "chatgpt", [], "gpt-5.6-sol",
        query="analyze the architectural trade-offs step-by-step",
    )[0].id == "gpt-reasoner"
    assert select_expert_models(
        chatgpt, "chatgpt", [], "gpt-5.6-sol", requested="gpt-5.6-sol",
        query="debug code",
    )[0].id == "gpt-5.6-sol"

    claude = (
        model("claude-opus-5", "anthropic", 100),
        model("claude-sonnet-5", "anthropic", 90),
    )
    assert select_expert_models(
        claude, "claude", [], "claude-opus-5",
        query="evaluate this strategy and trade-offs step-by-step",
    )[0].id == "claude-opus-5"
    assert select_expert_models(
        claude, "claude", [], "claude-opus-5", query="write Python code",
    )[0].id == "claude-sonnet-5"


def test_explicit_expert_grammar_preserves_query_and_rejects_blank():
    assert parse("Jarvis, ask ChatGPT Explain HTTP/2") == {
        "tool": "ask_chatgpt",
        "args": {"query": "Explain HTTP/2", "model": "auto"},
    }
    assert parse("ask Claude compare these designs")["tool"] == "ask_claude"
    assert parse("ask ChatGPT") is None


def test_declarations_and_prompt_have_privacy_and_one_expert_policy():
    declarations = {
        item["name"]: item for item in TOOL_DECLARATIONS
        if item["name"].startswith("ask_")
    }
    assert set(declarations) == {"ask_chatgpt", "ask_claude"}
    assert declarations["ask_chatgpt"]["parameters"]["properties"]["query"]["maxLength"] == 12000
    assert "ONE enabled expert" in PROMPT_TOOLS_SUFFIX
    assert "never call both" in PROMPT_TOOLS_SUFFIX
    assert "secrets" in PROMPT_TOOLS_SUFFIX


def test_fresh_defaults_enable_both_experts_at_max_reasoning():
    settings = Settings()
    assert settings.expert_auto_use is True
    assert settings.expert_chatgpt_enabled is True
    assert settings.expert_claude_enabled is True
    assert settings.expert_chatgpt_model == "gpt-5.6-sol"
    assert settings.expert_claude_model == "claude-opus-5"
    assert settings.expert_reasoning == "max"


def test_online_declarations_enforce_auto_use_and_provider_toggles():
    settings = Settings()
    names = {item["name"] for item in online_tool_declarations(settings)}
    assert {"ask_chatgpt", "ask_claude"} <= names
    settings.expert_auto_use = False
    names = {item["name"] for item in online_tool_declarations(settings)}
    assert "ask_chatgpt" not in names
    assert "ask_claude" not in names
    # Explicit grammar remains independent of online advertisement.
    assert parse("ask ChatGPT explain this")["tool"] == "ask_chatgpt"
    settings.expert_auto_use = True
    settings.expert_claude_enabled = False
    names = {item["name"] for item in online_tool_declarations(settings)}
    assert "ask_chatgpt" in names
    assert "ask_claude" not in names


class FakeCredentials:
    async def list(self, provider):
        assert provider == "relay"
        return [SimpleNamespace(
            id="relay-credential", status="active", retry_after=None
        )]

    async def get_secret(self, credential_id):
        assert credential_id == "relay-credential"
        return "encrypted-store-result"


class FakeDB:
    def __init__(self, prior_paid=0):
        self.events = []
        self.prior_paid = prior_paid

    async def usage(self, credential_id, event, detail):
        self.events.append((event, detail))

    async def fetchone(self, sql):
        assert "event LIKE 'relay:%'" in sql
        assert "event LIKE 'expert:%'" in sql
        return {"n": self.prior_paid + len(self.events)}


class FakeClient:
    def __init__(self, fail=False):
        self.calls = []
        self.fail = fail

    async def discover_models(self):
        return RelayDiscovery((
            model("gpt-5.6-sol", "openai", 100),
            model("gpt-fallback", "openai", 90),
            model("claude-opus-5", "anthropic", 100),
        ), {})

    async def ask(self, messages, tools, model, max_tokens, reasoning_effort=None):
        self.calls.append((messages, tools, model, max_tokens, reasoning_effort))
        if self.fail:
            from integrations.relay.client import RelayError
            raise RelayError("provider unavailable")
        return {"model": model, "reply": " expert answer "}


@pytest.mark.asyncio
async def test_expert_sends_only_question_without_tools_or_transcript():
    client = FakeClient()
    db = FakeDB()
    settings = SimpleNamespace(
        relay_url="https://relay.test",
        expert_chatgpt_enabled=True,
        expert_claude_enabled=True,
        expert_chatgpt_model="gpt-5.6-sol",
        expert_claude_model="claude-opus-5",
        expert_chatgpt_models=["gpt-5.6-sol"],
        expert_claude_models=["claude-opus-5"],
        expert_reasoning="max",
        relay_daily_request_cap=300,
    )
    service = ExpertRelayService(
        settings, FakeCredentials(), db,
        client_factory=lambda *args, **kwargs: client,
    )
    result = await service.ask("chatgpt", "Focused question")
    assert result == {
        "provider": "chatgpt", "model": "gpt-5.6-sol",
        "reply": "expert answer",
    }
    messages, tools, _, tokens, reasoning = client.calls[0]
    assert messages == [{"role": "user", "content": "Focused question"}]
    assert tools == []
    assert tokens == MAX_TOKENS
    assert reasoning == "max"
    assert all("Focused question" not in detail for _, detail in db.events)
    assert db.events == [("expert:chatgpt", "attempt model=gpt-5.6-sol")]


@pytest.mark.asyncio
async def test_dashboard_reasoning_setting_reaches_relay_payload():
    seen = {}

    def handler(request):
        if request.url.path.endswith("/relay/models"):
            return httpx.Response(200, json={
                "models": {"chat": [{
                    "id": "gpt-5.6-sol", "label": "GPT Sol", "job": "chat",
                    "tier": "high", "rank": 100, "costRank": 10,
                    "reasoning": True, "tools": False,
                    "modalities": ["text"], "provider": "openai",
                }]},
                "defaults": {"chat": "gpt-5.6-sol"},
                "voices": [],
            })
        seen.update(json.loads(request.content))
        return httpx.Response(200, json={"model": "gpt-5.6-sol", "reply": "ok"})

    transport = httpx.MockTransport(handler)
    service = ExpertRelayService(
        enabled_settings(expert_reasoning="high"),
        FakeCredentials(), FakeDB(),
        client_factory=lambda url, secret, timeout: RelayClient(
            url, secret, timeout=timeout, transport=transport
        ),
    )
    await service.ask("chatgpt", "Analyze this")
    assert seen["reasoning_effort"] == "high"
    assert "reasoning" not in seen
    assert seen["max_tokens"] == 8192


@pytest.mark.asyncio
async def test_expert_fails_closed_for_disabled_blank_oversize_and_secrets():
    settings = SimpleNamespace(
        relay_url="https://relay.test",
        expert_chatgpt_enabled=False,
        relay_daily_request_cap=300,
    )
    service = ExpertRelayService(
        settings, FakeCredentials(), FakeDB(),
        client_factory=lambda *args, **kwargs: FakeClient(),
    )
    with pytest.raises(ExpertError, match="blank"):
        await service.ask("chatgpt", " ")
    with pytest.raises(ExpertError, match="at most"):
        await service.ask("chatgpt", "x" * (MAX_QUERY_CHARS + 1))
    with pytest.raises(ExpertError, match="secret"):
        await service.ask("chatgpt", "API key = abc")
    with pytest.raises(ExpertError, match="disabled"):
        await service.ask("chatgpt", "safe question")


@pytest.mark.asyncio
@pytest.mark.parametrize("query", [
    "my API key is sk-abcdefghijklmnopqrstuvwxyz123456",
    "password is hunter2",
    "use token abcdefghijklmnop",
    "device id is device-12345",
    "Authorization: Bearer abcdefghijklmnop",
    "-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----",
    "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.signature123",
    "connect to https://alice:supersecret@example.test/database",
    "postgresql://dbuser:dbpassword@db.example.test/app",
    "Server=db.example;User Id=alice;Password=secret123",
    "AIzaabcdefghijklmnopqrstuvwxyz123456",
    "ghp_abcdefghijklmnopqrstuvwxyz123456",
])
async def test_sensitive_shapes_are_blocked_before_client_or_discovery(query):
    calls = []

    def factory(*args, **kwargs):
        calls.append("client")
        return FakeClient()

    service = ExpertRelayService(
        enabled_settings(), FakeCredentials(), FakeDB(), client_factory=factory
    )
    with pytest.raises(ExpertError, match="secret|private"):
        await service.ask("chatgpt", query)
    assert calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("query", [
    "How do API keys work?",
    "What makes a password secure?",
    "Compare bearer tokens with session cookies conceptually.",
    "How should device IDs be represented in a database schema?",
    "Explain how to rotate API keys without showing an actual key.",
    "An API key is used to authenticate a software client.",
    "A device ID is a unique identifier, conceptually.",
])
async def test_benign_security_concepts_can_be_consulted(query):
    client = FakeClient()
    service = ExpertRelayService(
        enabled_settings(), FakeCredentials(), FakeDB(),
        client_factory=lambda *args, **kwargs: client,
    )
    result = await service.ask("chatgpt", query)
    assert result["reply"] == "expert answer"
    assert len(client.calls) == 1


def enabled_settings(**updates):
    values = dict(
        relay_url="https://relay.test",
        relay_daily_request_cap=300,
        expert_auto_use=True,
        expert_chatgpt_enabled=True,
        expert_claude_enabled=True,
        expert_chatgpt_model="gpt-5.6-sol",
        expert_claude_model="claude-opus-5",
        expert_chatgpt_models=[],
        expert_claude_models=[],
        expert_reasoning="max",
    )
    values.update(updates)
    return SimpleNamespace(**values)


@pytest.mark.asyncio
async def test_daily_cap_blocks_before_first_paid_expert_call():
    client = FakeClient()
    service = ExpertRelayService(
        enabled_settings(relay_daily_request_cap=2),
        FakeCredentials(), FakeDB(prior_paid=2),
        client_factory=lambda *args, **kwargs: client,
    )
    with pytest.raises(ExpertError, match="daily Relay request cap"):
        await service.ask("chatgpt", "Focused question")
    assert client.calls == []


@pytest.mark.asyncio
async def test_daily_cap_is_rechecked_before_paid_fallback():
    client = FakeClient(fail=True)
    db = FakeDB()
    service = ExpertRelayService(
        enabled_settings(relay_daily_request_cap=1),
        FakeCredentials(), db,
        client_factory=lambda *args, **kwargs: client,
    )
    with pytest.raises(ExpertError, match="daily Relay request cap"):
        await service.ask("chatgpt", "Focused question")
    assert len(client.calls) == 1
    assert db.events == [("expert:chatgpt", "attempt model=gpt-5.6-sol")]


@pytest.mark.asyncio
async def test_auto_off_does_not_block_explicit_dispatch_but_provider_off_does():
    service = ExpertRelayService(
        enabled_settings(expert_auto_use=False),
        FakeCredentials(), FakeDB(),
        client_factory=lambda *args, **kwargs: FakeClient(),
    )
    assert (await service.ask("chatgpt", "Explicit request"))["reply"] == "expert answer"
    service.settings.expert_chatgpt_enabled = False
    with pytest.raises(ExpertError, match="disabled"):
        await service.ask("chatgpt", "Explicit request")


@pytest.mark.asyncio
async def test_runtime_refresh_applies_to_typed_host_and_private_remote():
    class Typed:
        def update_tool_declarations(self, declarations):
            self.names = {item["name"] for item in declarations}

    class Gateway:
        def __init__(self, active):
            self.active = active
            self.names = set()

        async def update_tool_declarations(self, declarations):
            self.names = {item["name"] for item in declarations}
            return self.active

    runtime = Runtime.__new__(Runtime)
    runtime.settings = Settings()
    runtime.text_chat = Typed()
    runtime.gateway = Gateway(True)
    runtime.remote_voice = SimpleNamespace(gateway=Gateway(False))

    result = await runtime.refresh_online_tool_declarations()
    assert {"ask_chatgpt", "ask_claude"} <= runtime.text_chat.names
    assert runtime.gateway.names == runtime.remote_voice.gateway.names
    assert result["reconnecting"] == ["host_voice"]

    runtime.settings.expert_auto_use = False
    result = await runtime.refresh_online_tool_declarations()
    assert "ask_chatgpt" not in runtime.text_chat.names
    assert "ask_claude" not in runtime.gateway.names
    assert "ask_chatgpt" not in runtime.remote_voice.gateway.names
    assert result["expert_tools"] == []