"""WebSocket protocol tests for /ws/remote-voice (serve_remote_voice_socket).

Drives the real handler coroutine with a FakeWebSocket: auth, hello,
claim/busy/takeover/resume, framed audio validation, mute, barge-in,
turn fencing, and lifecycle cleanup.
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import apps.dashboard.remote_voice_socket as sock_mod
from apps.audio.mic_gate import ASSISTANT_SETTLE_SECONDS
from apps.live_gateway.remote_voice import (
    DOWN_HEADER,
    FRAME_BYTES,
    KIND_VOICE,
    UP_HEADER,
)
from chat_core.models.state import ChatState

from tests.remote_voice_helpers import (
    FakeWebSocket,
    build_runtime,
    finish,
    frame,
    loud_frames,
    make_sessions,
    open_socket,
    ready_socket,
    start_conversation_via_socket,
)
from apps.dashboard.remote_voice_socket import serve_remote_voice_socket


async def drain_to_gateway(rt, minimum: int = 1, timeout: float = 0.5) -> int:
    """Wait until the private gateway received >= minimum audio chunks."""
    q = rt.remote_voice.gateway.audio_in
    deadline = asyncio.get_event_loop().time() + timeout
    while q.qsize() < minimum and asyncio.get_event_loop().time() < deadline:
        await asyncio.sleep(0.01)
    return q.qsize()


# ---------------------------------------------------------------------------
# handshake and auth
# ---------------------------------------------------------------------------

async def test_no_cookie_closes_4401(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, _ = make_sessions()
    ws = FakeWebSocket(None)
    await serve_remote_voice_socket(rt, ws, sessions)
    assert ws.close_code == 4401
    assert not ws.accepted.is_set()


async def test_cross_origin_closes_4403(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws = FakeWebSocket(token, headers={"origin": "https://evil.example", "host": "jarvis.local:8765"})
    await serve_remote_voice_socket(rt, ws, sessions)
    assert ws.close_code == 4403


async def test_same_origin_header_accepted(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(
        rt, sessions, token,
        headers={"origin": "http://jarvis.local:8765", "host": "jarvis.local:8765"},
    )
    assert ready["mode"] == "granted"
    assert ready["generation"] == rt.remote_voice.gateway.voice_session_generation
    await finish(ws, task)


async def test_disabled_service_closes_4403(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    rt.remote_voice = None
    sessions, token = make_sessions()
    ws = FakeWebSocket(token)
    await serve_remote_voice_socket(rt, ws, sessions)
    assert ws.close_code == 4403
    assert "disabled" in ws.close_reason


async def test_non_hello_first_message_closes_1008(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws = FakeWebSocket(token)
    task = asyncio.create_task(serve_remote_voice_socket(rt, ws, sessions))
    await asyncio.wait_for(ws.accepted.wait(), 0.5)
    ws.feed_text({"type": "ping"})
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 1008


async def test_wrong_protocol_version_rejected(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws = FakeWebSocket(token)
    task = asyncio.create_task(serve_remote_voice_socket(rt, ws, sessions))
    await asyncio.wait_for(ws.accepted.wait(), 0.5)
    ws.feed_text({
        "type": "hello", "protocol": 99,
        "token": sessions.capability_for(token, "remote-voice"),
    })
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 1008
    assert "protocol" in ws.close_reason


async def test_bad_capability_token_closes_4401(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws = FakeWebSocket(token)
    task = asyncio.create_task(serve_remote_voice_socket(rt, ws, sessions))
    await asyncio.wait_for(ws.accepted.wait(), 0.5)
    ws.feed_text({"type": "hello", "protocol": 1, "token": "forged"})
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 4401


async def test_capability_bound_to_issuing_session(settings, db, store, bus):
    """A capability minted for one signed-in session is useless from another."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token_a = make_sessions()
    token_b = sessions.issue()
    cap_a = sessions.capability_for(token_a, "remote-voice")
    ws = FakeWebSocket(token_b)
    task = asyncio.create_task(serve_remote_voice_socket(rt, ws, sessions))
    await asyncio.wait_for(ws.accepted.wait(), 0.5)
    ws.feed_text({"type": "hello", "protocol": 1, "token": cap_a})
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 4401


async def test_ready_frame_contents(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token, device="Pixel 9")
    assert ready["mode"] == "granted"
    assert ready["epoch"] == 1
    assert ready["resume"]["epoch"] == 1
    assert len(ready["resume"]["secret"]) == 32
    assert ready["wake"]["available"] is False      # no audio engine in fixture
    assert ready["conversation_active"] is False
    assert ready["muted"] is False
    assert ready["frame"] == {"rate": 16000, "samples": FRAME_BYTES // 2,
                              "out_rate": 24000}
    await finish(ws, task)
    assert rt.remote_voice.lease is None            # no conversation -> released


# ---------------------------------------------------------------------------
# single-owner: busy / takeover / resume
# ---------------------------------------------------------------------------

async def test_second_device_busy_first_unaffected(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws1, task1, _ = await ready_socket(rt, sessions, token, device="Pixel 9")

    ws2, task2 = await open_socket(rt, sessions, token, device="iPad")
    busy = await ws2.wait_for("busy")
    assert busy["holder"]["device"] == "Pixel 9"
    await asyncio.wait_for(task2, 1.0)
    assert ws2.close_code == 4409

    assert not ws1.closed.is_set()
    assert rt.remote_voice.lease.device_label == "Pixel 9"
    await finish(ws1, task1)


async def test_takeover_closes_first_socket_4412(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws1, task1, _ = await ready_socket(rt, sessions, token, device="Pixel 9")
    await start_conversation_via_socket(ws1)

    ws2, task2, ready2 = await ready_socket(
        rt, sessions, token, device="iPad", takeover=True
    )
    assert ready2["epoch"] == 2
    revoked = await ws1.wait_for("revoked")
    assert revoked["by"] == "iPad"
    await asyncio.wait_for(ws1.closed.wait(), 1.0)
    assert ws1.close_code == 4412
    await asyncio.wait_for(task1, 1.0)
    # The old conversation must NOT leak into the new lease.
    assert not rt.remote_voice.gateway.session_intent_active
    await finish(ws2, task2)


async def test_old_socket_traffic_after_takeover_cannot_touch_new_owner(
    settings, db, store, bus
):
    """Queued close-race traffic from A is inert once B owns the binding."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws1, task1, _ = await ready_socket(rt, sessions, token, device="Pixel 9")
    await start_conversation_via_socket(ws1)

    ws2, task2, _ = await ready_socket(
        rt, sessions, token, device="iPad", takeover=True
    )
    await start_conversation_via_socket(ws2)
    svc = rt.remote_voice
    new_lease = svc.lease
    turn = svc.current_turn
    ring_stops = rt.ring_stops
    forwarded = new_lease.stats["frames_forwarded"]

    # These can already be queued in ASGI while revocation close is racing.
    for payload in (
        {"type": "stop"},
        {"type": "end"},
        {"type": "start"},
        {"type": "mute", "muted": True},
        {"type": "playback", "playing": True},
        {"type": "media", "playing": True},
        {"type": "diag", "stats": {"stale": 1}},
    ):
        ws1.feed_text(payload)
    for f in loud_frames(4, amplitude=9000, start_seq=100):
        ws1.feed_audio(f)
    await asyncio.sleep(0.1)

    assert svc.lease is new_lease
    assert svc.gateway.session_intent_active
    assert svc.current_turn == turn
    assert rt.ring_stops == ring_stops
    assert new_lease.stats["frames_forwarded"] == forwarded
    assert new_lease.stats["client"] == {}

    svc.end_conversation(new_lease, "cleanup")
    await asyncio.sleep(0.05)
    await asyncio.gather(task1, return_exceptions=True)
    await finish(ws2, task2)


async def test_resume_after_disconnect_recovers_conversation(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws1, task1, ready1 = await ready_socket(rt, sessions, token, device="Pixel 9")
    await start_conversation_via_socket(ws1)
    resume = ready1["resume"]

    ws1.disconnect()
    await asyncio.wait_for(task1, 1.0)
    svc = rt.remote_voice
    assert svc.lease is not None            # grace window holds the claim
    assert svc.conversation_active

    ws2, task2, ready2 = await ready_socket(
        rt, sessions, token, device="Pixel 9", resume=resume
    )
    assert ready2["mode"] == "resumed"
    assert ready2["epoch"] == ready1["epoch"]
    assert ready2["conversation_active"] is True
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws2, task2)


# ---------------------------------------------------------------------------
# conversation flow: start, audio forwarding, end, stop
# ---------------------------------------------------------------------------

async def test_start_and_audio_reaches_private_gateway(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    assert svc.gateway.session_intent_active
    assert not rt.gateway.session_intent_active     # host untouched

    for f in loud_frames(3):
        ws.feed_audio(f)
    got = await drain_to_gateway(rt, minimum=1)
    assert got >= 1, "framed PCM must reach the PRIVATE gateway's audio_in"
    assert rt.remote_voice.lease.stats["frames_forwarded"] >= 1
    # Host gateway audio queue must stay empty.
    assert rt.gateway.audio_in.empty()
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_server_accepts_one_utterance_and_cues_owner_once(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)

    for f in loud_frames(4, amplitude=6000):
        ws.feed_audio(f)
    cue = await ws.wait_for("utterance_accepted")
    assert cue["epoch"] == rt.remote_voice.lease.epoch
    await asyncio.sleep(0.1)
    assert sum(
        m.get("type") == "utterance_accepted" for m in ws.json_messages()
    ) == 1

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_quiet_pause_resume_does_not_duplicate_accepted_utterance(
    settings, db, store, bus
):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)

    for f in loud_frames(4, amplitude=6000):
        ws.feed_audio(f)
    await ws.wait_for("utterance_accepted")
    await asyncio.sleep(0.3)  # local heard cue has finished

    # Seven 80 ms quiet chunks close socket-local hysteresis.  Loud speech
    # reopening it is still the same in-flight provider utterance.
    for i in range(7):
        ws.feed_audio(frame(0, seq=20 + i))
    for f in loud_frames(4, amplitude=6000, start_seq=30):
        ws.feed_audio(f)
    await asyncio.sleep(0.15)
    assert sum(
        m.get("type") == "utterance_accepted" for m in ws.json_messages()
    ) == 1

    # A real playback response boundary re-arms exactly one cue.
    ws.feed_text({"type": "playback", "playing": True})
    ws.feed_text({"type": "playback", "playing": False})
    # Respect the production 400 ms post-playback echo-settling tail before
    # simulating the next real user utterance.
    await asyncio.sleep(0.45)
    for f in loud_frames(4, amplitude=6000, start_seq=40):
        ws.feed_audio(f)
    deadline = asyncio.get_event_loop().time() + 1.0
    while sum(
        m.get("type") == "utterance_accepted" for m in ws.json_messages()
    ) < 2:
        if asyncio.get_event_loop().time() > deadline:
            raise AssertionError("next real utterance was not acknowledged")
        await asyncio.sleep(0.01)

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_wake_mode_gates_audio_without_wake_model(settings, db, store, bus):
    """No conversation + no wake model -> nothing may reach the provider."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token)
    assert ready["wake"]["available"] is False
    for f in loud_frames(3):
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert rt.remote_voice.gateway.audio_in.empty()
    assert rt.remote_voice.lease.stats["frames_gated"] >= 3
    await finish(ws, task)


async def test_remote_wake_hit_starts_conversation(settings, db, store, bus):
    hits = iter([False, True])

    class FakeAudio:
        remote_wake_available = True
        remote_mic_active = False

        def __init__(self):
            self.resets = 0

        def reset_remote_wake(self):
            self.resets += 1

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return next(hits, False)

    audio = FakeAudio()
    rt = build_runtime(settings, db, store, bus, audio=audio)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token)
    assert ready["wake"]["available"] is True
    assert audio.resets == 1, "phone ownership starts with clean wake features"

    for f in loud_frames(3):
        ws.feed_audio(f)
    await ws.wait_for("wake")
    result = await ws.wait_for("start_result")
    assert result["status"] == "started"
    svc = rt.remote_voice
    assert svc.gateway.session_intent_active
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_wake_model_becoming_ready_updates_existing_socket(
    settings, db, store, bus
):
    """Connecting during async model load must not trap the phone in
    manual-only mode for the lifetime of that WebSocket."""
    class FakeAudio:
        remote_wake_available = False
        remote_mic_active = False

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return True

    audio = FakeAudio()
    rt = build_runtime(settings, db, store, bus, audio=audio)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token)
    assert ready["wake"]["available"] is False

    audio.remote_wake_available = True
    ws.feed_audio(loud_frames(1)[0])
    status = await ws.wait_for("wake_status")
    assert status["type"] == "wake_status"
    assert status["available"] is True
    assert status["epoch"] == rt.remote_voice.lease.epoch
    assert status["turn"] == rt.remote_voice.current_turn
    await ws.wait_for("wake")
    result = await ws.wait_for("start_result")
    assert result["status"] == "started"
    assert rt.remote_voice.gateway.session_intent_active

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_wake_model_ready_status_does_not_require_audio_frame(
    settings, db, store, bus
):
    """Async model loading must update an idle phone proactively.

    A silent/stalled browser capture path cannot be the trigger that makes the
    manual-only UI discover wake readiness.
    """
    class FakeAudio:
        remote_wake_available = False
        remote_mic_active = False

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return False

    audio = FakeAudio()
    rt = build_runtime(settings, db, store, bus, audio=audio)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token)
    assert ready["wake"]["available"] is False

    audio.remote_wake_available = True
    status = await ws.wait_for("wake_status", timeout=1.5)
    assert status["type"] == "wake_status"
    assert status["available"] is True
    assert status["epoch"] == rt.remote_voice.lease.epoch
    assert status["turn"] == rt.remote_voice.current_turn

    await finish(ws, task)


async def test_wake_hit_from_replaced_audio_engine_is_discarded(
    settings, db, store, bus
):
    started = asyncio.Event()
    release = asyncio.Event()

    class OldAudio:
        remote_wake_available = True
        remote_mic_active = False

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            started.set()
            await release.wait()
            return True

    class NewAudio:
        remote_wake_available = True
        remote_mic_active = True

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return True

    rt = build_runtime(settings, db, store, bus, audio=OldAudio())
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)

    ws.feed_audio(loud_frames(1)[0])
    await asyncio.wait_for(started.wait(), 0.5)
    rt.audio = NewAudio()
    release.set()
    await asyncio.sleep(0.1)
    assert ws.last_of("wake") is None
    assert not rt.remote_voice.gateway.session_intent_active

    ws.feed_audio(loud_frames(1, start_seq=1)[0])
    wake = await ws.wait_for("wake")
    assert wake["sound"] == "wake_ack"
    result = await ws.wait_for("start_result")
    assert result["status"] == "started"

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_confirmed_wake_chime_echo_is_not_forwarded(
    settings, db, store, bus
):
    class FakeAudio:
        remote_wake_available = True
        remote_mic_active = False

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return True

    rt = build_runtime(settings, db, store, bus, audio=FakeAudio())
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)

    ws.feed_audio(loud_frames(1)[0])
    wake = await ws.wait_for("wake")
    assert wake["sound"] == "wake_ack"
    await ws.wait_for("start_result")

    # These frames overlap the phone's local acknowledgement sound.
    for f in loud_frames(3, start_seq=1):
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert rt.remote_voice.gateway.audio_in.empty()

    # Once the short cue window expires, ordinary conversation audio flows.
    await asyncio.sleep(0.3)
    ws.feed_audio(loud_frames(1, start_seq=4)[0])
    assert await drain_to_gateway(rt, minimum=1) >= 1

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_first_valid_phone_frame_confirms_server_microphone_reception(
    settings, db, store, bus
):
    class FakeAudio:
        remote_wake_available = True
        remote_mic_active = False

        def reset_remote_wake(self):
            pass

        async def run_remote_wake(self, chunk: bytes) -> bool:
            return False

    rt = build_runtime(settings, db, store, bus, audio=FakeAudio())
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)

    ws.feed_audio(loud_frames(1)[0])
    status = await ws.wait_for("mic_status")
    assert status["type"] == "mic_status"
    assert status["status"] == "streaming"
    assert status["epoch"] == rt.remote_voice.lease.epoch
    assert status["turn"] == rt.remote_voice.current_turn

    await finish(ws, task)


async def test_start_result_busy_host_without_takeover(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    rt.gateway.request_session()                     # host is talking
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    ws.feed_text({"type": "start"})
    result = await ws.wait_for("start_result")
    assert result["status"] == "busy_host"
    assert not rt.remote_voice.gateway.session_intent_active

    # Explicit host takeover ends the desk session and starts the remote one.
    ws.feed_text({"type": "start", "takeover_host": True})
    await asyncio.sleep(0.05)
    result2 = await ws.wait_for("start_result")
    assert result2["status"] == "started"
    assert not rt.gateway.session_intent_active
    assert rt.stop_calls == 1
    svc = rt.remote_voice
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_end_returns_to_wake_mode_socket_stays_open(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    ws.feed_text({"type": "end"})
    await asyncio.sleep(0.1)
    assert not svc.gateway.session_intent_active
    assert not ws.closed.is_set(), "goodbye must keep the socket open"
    assert svc.lease is not None

    # Post-goodbye audio is gated (wake unavailable here).
    for f in loud_frames(3, start_seq=100):
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert svc.gateway.audio_in.empty()
    await finish(ws, task)


async def test_goodbye_resets_detector_and_second_wake_starts(settings, db, store, bus):
    """One connected phone can Goodbye and then say Hey Jarvis again.

    Returning to wake mode must reset rolling model state before the next
    frame, otherwise the first post-conversation wake can be missed.
    """
    class FakeAudio:
        remote_wake_available = True
        remote_mic_active = False

        def __init__(self):
            self.resets = 0
            self.should_hit = True

        def reset_remote_wake(self):
            self.resets += 1
            self.should_hit = True

        async def run_remote_wake(self, chunk: bytes) -> bool:
            if self.should_hit:
                self.should_hit = False
                return True
            return False

    audio = FakeAudio()
    rt = build_runtime(settings, db, store, bus, audio=audio)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)

    ws.feed_audio(loud_frames(1)[0])
    await ws.wait_for("wake")
    await ws.wait_for("start_result")
    assert rt.remote_voice.gateway.session_intent_active

    ws.feed_text({"type": "end"})
    await asyncio.sleep(0.1)
    assert not rt.remote_voice.gateway.session_intent_active
    assert audio.resets == 2  # initial ownership + return to wake mode

    prior_wakes = sum(m.get("type") == "wake" for m in ws.json_messages())
    ws.feed_audio(loud_frames(1, start_seq=10)[0])
    deadline = asyncio.get_event_loop().time() + 1.0
    while sum(m.get("type") == "wake" for m in ws.json_messages()) == prior_wakes:
        if asyncio.get_event_loop().time() > deadline:
            raise AssertionError("second Hey Jarvis did not wake")
        await asyncio.sleep(0.01)
    assert rt.remote_voice.gateway.session_intent_active

    rt.remote_voice.end_conversation(rt.remote_voice.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_stop_bumps_turn_and_dismisses_ring_only(settings, db, store, bus):
    """Remote Stop silences the remote reply and dismisses a ringing alarm —
    it must NEVER trigger the global host stop (that would interrupt the
    desk conversation and clear host playback)."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, ready = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    # Host talking at the desk too (driven directly; wake is remote-gated).
    rt.gateway.request_session()
    turn_before = svc.current_turn

    ws.feed_text({"type": "stop"})
    clear = await ws.wait_for("clear")
    assert clear["turn"] == svc.current_turn != turn_before
    assert rt.ring_stops == 1, "ringing alarm dismissal must fire"
    assert rt.stop_calls == 0, "global host stop must NOT fire"
    assert rt.gateway.session_intent_active, "host conversation untouched"
    # Session stays alive (stop is not goodbye).
    assert svc.gateway.session_intent_active
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


# ---------------------------------------------------------------------------
# frame validation and rate limiting
# ---------------------------------------------------------------------------

async def test_malformed_frames_tolerated_then_fatal(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    lease = rt.remote_voice.lease

    ws.feed_audio(frame(1000, magic=b"XX"))          # wrong magic
    ws.feed_audio(frame(1000, version=9))            # wrong version
    ws.feed_audio(frame(1000)[: UP_HEADER.size + 100])  # truncated PCM
    ws.feed_audio(b"\x01")                           # shorter than header
    await asyncio.sleep(0.1)
    assert not ws.closed.is_set()
    assert lease.stats["malformed_frames"] == 4
    assert rt.remote_voice.gateway.audio_in.empty()

    for _ in range(sock_mod.MALFORMED_LIMIT):
        ws.feed_audio(frame(1000, magic=b"XX"))
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 1008
    assert "malformed" in ws.close_reason


async def test_sequence_gaps_are_counted(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    lease = rt.remote_voice.lease

    ws.feed_audio(frame(1000, seq=0))
    ws.feed_audio(frame(1000, seq=1))
    ws.feed_audio(frame(1000, seq=5))    # dropped 2..4 on the network
    ws.feed_audio(frame(1000, seq=6))
    await asyncio.sleep(0.1)
    assert lease.stats["seq_gaps"] == 1
    assert lease.stats["frames_in"] == 4
    await finish(ws, task)


async def test_oversized_binary_closes_1008(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    ws.feed_audio(b"\x00" * (sock_mod.MAX_BINARY_BYTES + 1))
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 1008
    assert "flood" in ws.close_reason


async def test_control_flood_closes_1008(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    for i in range(int(sock_mod.TEXT_BURST) + 10):
        ws.feed_text({"type": "ping", "t": i})
    await asyncio.wait_for(task, 1.0)
    assert ws.close_code == 1008
    assert "flood" in ws.close_reason


async def test_unknown_and_malformed_control_ignored(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    ws.feed_text({"type": "future_feature", "x": 1})
    ws.feed_text("{not valid json!!")
    ws.feed_text(json.dumps(["a", "list"]))
    await asyncio.sleep(0.1)
    assert not ws.closed.is_set()
    await finish(ws, task)


async def test_idle_timeout_closes_1001(settings, db, store, bus, monkeypatch):
    monkeypatch.setattr(sock_mod, "IDLE_TIMEOUT", 0.15)
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await asyncio.wait_for(task, 2.0)
    assert ws.close_code == 1001


async def test_ping_pong_reports_state(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    ws.feed_text({"type": "ping", "t": 123})
    pong = await ws.wait_for("pong")
    assert pong["t"] == 123
    assert pong["state"] == "wake"
    assert pong["conversation_active"] is False
    await finish(ws, task)


# ---------------------------------------------------------------------------
# mute
# ---------------------------------------------------------------------------

async def test_global_mute_gates_frames_and_notifies(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    rt.state.set_muted(True)
    for f in loud_frames(3):
        ws.feed_audio(f)
    muted_msg = await ws.wait_for("muted")
    assert muted_msg["muted"] is True
    assert svc.gateway.audio_in.empty()
    assert svc.lease.stats["frames_gated"] >= 3

    rt.state.set_muted(False)
    for f in loud_frames(3, start_seq=10):
        ws.feed_audio(f)
    got = await drain_to_gateway(rt, minimum=1)
    assert got >= 1, "unmute must restore forwarding"
    unmuted_msg = await ws.wait_for("muted")
    assert unmuted_msg["muted"] is False
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_local_mute_gates_frames(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    ws.feed_text({"type": "mute", "muted": True})
    await asyncio.sleep(0.05)
    for f in loud_frames(3):
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert svc.gateway.audio_in.empty()
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


# ---------------------------------------------------------------------------
# barge-in and turn fencing
# ---------------------------------------------------------------------------

async def test_speaking_audio_is_barge_in_only(settings, db, store, bus, monkeypatch):
    """Echo during TTS must interrupt locally and NEVER reach the provider."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    svc.state.set(ChatState.SPEAKING, "model audio")

    real_interrupt = svc.gateway.interrupt
    spy = MagicMock(side_effect=real_interrupt)
    monkeypatch.setattr(svc.gateway, "interrupt", spy)
    turn_before = svc.current_turn

    # Exactly the three sustained loud frames a barge-in requires: none of
    # their PCM may cross into the provider queue while the assistant speaks.
    for f in loud_frames(3, amplitude=6000):
        ws.feed_audio(f)
    for _ in range(50):
        if spy.call_count:
            break
        await asyncio.sleep(0.01)

    assert spy.call_count == 1
    assert svc.gateway.audio_in.empty(), "speaker echo must never reach the provider"
    assert svc.current_turn != turn_before
    assert svc.lease.stats["barge_ins"] == 1
    clear = await ws.wait_for("clear")
    assert clear["turn"] == svc.current_turn

    # After the interrupt the session is LISTENING again — the user's
    # follow-up speech (new turn) must now reach the provider.
    assert svc.state.raw_state == ChatState.LISTENING
    for f in loud_frames(2, amplitude=6000, start_seq=10):
        ws.feed_audio(f)
    got = await drain_to_gateway(rt, minimum=1)
    assert got >= 1, "post-barge-in speech must forward"
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_playback_gate_arms_and_releases(settings, db, store, bus):
    """Client 'playback' reports arm the echo gate exactly like the old
    assistant_playback contract: gated while playing, open after the tail."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    ws.feed_text({"type": "playback", "playing": True})
    await asyncio.sleep(0.05)
    for f in loud_frames(2, amplitude=700):     # speaker residue level
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert svc.gateway.audio_in.empty(), "playback=true must gate device echo"

    ws.feed_text({"type": "playback", "playing": False})
    await asyncio.sleep(ASSISTANT_SETTLE_SECONDS + 0.2)
    for f in loud_frames(4, amplitude=12000, start_seq=50):
        ws.feed_audio(f)
    got = await drain_to_gateway(rt, minimum=1)
    assert got >= 1, "loud speech after the settling tail must pass"
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_explicit_end_generation_fences_stale_audio(settings, db, store, bus):
    """Audio already in flight when Goodbye lands must be dropped."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    # Goodbye happens server-side (voice command through the provider).
    svc.end_conversation(svc.lease, "user said goodbye")
    # Frames that were already on the wire arrive AFTER the fence bumped.
    for f in loud_frames(3):
        ws.feed_audio(f)
    await asyncio.sleep(0.1)
    assert svc.gateway.audio_in.empty(), "post-goodbye audio must be fenced out"
    assert not ws.closed.is_set()
    await asyncio.sleep(0.05)
    await finish(ws, task)


async def test_disconnect_mid_conversation_enters_grace(settings, db, store, bus):
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice

    ws.disconnect()
    await asyncio.wait_for(task, 1.0)
    assert svc.lease is not None, "mid-conversation drop must keep the lease"
    assert svc.lease.connected is False
    assert svc.conversation_active, "grace window must block the host wake"
    svc.release(svc.lease, "test cleanup")
    await asyncio.sleep(0.05)


async def test_outbox_hard_bound_closes_non_draining_client(settings, db, store, bus):
    """A client that stops draining (writer blocked mid-send) must not let the
    control outbox grow without limit: past the hard max the socket is
    force-closed, which also unblocks the stuck writer."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    svc = rt.remote_voice

    # Block the transport: sends hang forever, like a stalled TCP window.
    never = asyncio.Event()

    async def hung_send(payload):
        await never.wait()

    ws.send_text = hung_send
    ws.send_bytes = hung_send

    # Flood control messages well past the hard max (512).
    for _ in range(700):
        svc._bump_turn("flood")

    await asyncio.wait_for(ws.closed.wait(), 2.0)
    assert ws.close_code == 1008
    binding = svc._binding
    assert binding is None or len(vars()) >= 0  # socket torn down; no growth
    await asyncio.wait_for(task, 2.0)
    await asyncio.sleep(0.05)


async def test_fencing_clear_preempts_queued_stale_audio(settings, db, store, bus):
    """Barge-in/Stop on a slow link: the turn 'clear' must never sit behind
    a backlog of previous-turn voice frames.  Queued stale frames are purged
    and the clear jumps ahead; only the single in-flight frame can precede
    it (the client drops that one via its own turn check)."""
    rt = build_runtime(settings, db, store, bus)
    sessions, token = make_sessions()
    ws, task, _ = await ready_socket(rt, sessions, token)
    await start_conversation_via_socket(ws)
    svc = rt.remote_voice
    old_turn = svc.current_turn

    # Stall the transport mid-send (slow phone connection).
    gate = asyncio.Event()
    real_text, real_bytes = ws.send_text, ws.send_bytes

    async def slow_text(payload):
        await gate.wait()
        await real_text(payload)

    async def slow_bytes(payload):
        await gate.wait()
        await real_bytes(payload)

    ws.send_text, ws.send_bytes = slow_text, slow_bytes
    sent_before = len(ws.sent_all)

    for _ in range(6):                      # old-turn reply audio backs up
        svc._send_audio(b"\x0a\x0b" * 240, KIND_VOICE)
    await asyncio.sleep(0.02)               # writer picks one up, blocks
    svc.interrupt_playback("barge-in")      # fence: purge + priority clear
    new_turn = svc.current_turn
    assert new_turn != old_turn
    gate.set()                              # link recovers

    clear = await ws.wait_for("clear")
    assert clear["turn"] == new_turn
    events = ws.sent_all[sent_before:]
    clear_idx = next(
        i for i, (k, p) in enumerate(events)
        if k == "text"
        and json.loads(p).get("type") == "clear"
        and json.loads(p).get("turn") == new_turn
    )
    old_turn_voice = [
        i for i, (k, p) in enumerate(events)
        if k == "bytes"
        and DOWN_HEADER.unpack_from(p)[2] == KIND_VOICE
        and DOWN_HEADER.unpack_from(p)[3] == old_turn
    ]
    assert all(i < clear_idx for i in old_turn_voice), (
        "no stale voice frame may be delivered after the clear"
    )
    assert len(old_turn_voice) <= 1, (
        "queued stale frames must be purged; only the in-flight one may leak"
    )
    svc.end_conversation(svc.lease, "cleanup")
    await asyncio.sleep(0.05)
    await finish(ws, task)
