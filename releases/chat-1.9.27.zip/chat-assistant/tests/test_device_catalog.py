from __future__ import annotations

import asyncio
import sqlite3
from unittest.mock import AsyncMock

from apps.tool_service.schemas import TOOL_DECLARATIONS
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from chat_core.models.db import Database


def make_service(db, bus, store, *, tv=None):
    return ToolService(db, bus, TimerManager(db, bus), store, tv=tv)


def discovered(name="Desk Lights", capabilities=None):
    return [{
        "device": "private-provider-identity",
        "sku": "private-sku",
        "name": name,
        "capabilities": capabilities or ["powerSwitch", "brightness"],
    }]


def test_configure_light_schema_accepts_only_human_metadata():
    declaration = next(
        item for item in TOOL_DECLARATIONS if item["name"] == "configure_light"
    )
    properties = declaration["parameters"]["properties"]
    assert set(properties) == {"device", "aliases", "room"}
    assert declaration["parameters"]["required"] == ["device"]
    contract = declaration["description"]
    assert "explicitly asks" in contract
    assert "Never pass a provider device ID" in contract
    assert "cannot change device identity or capabilities" in contract


async def test_device_catalog_migration_recovers_after_partial_application(settings):
    # Simulate a process dying after DDL committed but before schema_migrations
    # recorded 012. Reopening must safely replay that migration.
    conn = sqlite3.connect(settings.db_path)
    conn.executescript(
        """
        CREATE TABLE device_catalog (
            id TEXT PRIMARY KEY,
            provider TEXT NOT NULL,
            provider_identity TEXT NOT NULL,
            provider_sku TEXT NOT NULL,
            canonical_name TEXT NOT NULL,
            aliases_json TEXT NOT NULL DEFAULT '[]',
            room TEXT,
            enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
            capabilities_json TEXT NOT NULL DEFAULT '[]',
            last_seen TEXT,
            stale INTEGER NOT NULL DEFAULT 0 CHECK(stale IN (0,1)),
            UNIQUE(provider, provider_identity)
        );
        CREATE INDEX device_catalog_provider
        ON device_catalog(provider, enabled, stale);
        """
    )
    conn.close()

    recovered = Database(settings.db_path)
    await recovered.open()
    try:
        row = await recovered.fetchone(
            "SELECT name FROM schema_migrations WHERE name='012_device_catalog.sql'"
        )
        assert row is not None
        indexes = await recovered.fetchall("PRAGMA index_list(device_catalog)")
        assert "device_catalog_provider" in {item["name"] for item in indexes}
    finally:
        await recovered.close()


async def test_catalog_persists_and_public_view_hides_provider_ids(db, bus, store):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)
    first = await service.devices(refresh=True)
    assert first[0]["name"] == "Desk Lights"
    assert "device" not in first[0] and "sku" not in first[0]
    assert "private-provider-identity" not in str(first)

    restarted = make_service(db, bus, store)
    assert await restarted.devices() == first
    restarted._govee = AsyncMock(return_value=None)
    resolved = await restarted._resolve_device("the desk lamps")
    assert resolved["name"] == "Desk Lights"


async def test_refresh_preserves_alias_and_room_and_resolution_is_deterministic(
    db, bus, store
):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)
    await service.devices(refresh=True)
    ref = service._devices_cache[0]["catalog_ref"]
    await service.update_device_metadata(ref, aliases=["work-lamp"], room="Office")

    client.list_devices.return_value = discovered(name="Provider Renamed It")
    refreshed = await service.devices(refresh=True)
    assert refreshed[0]["name"] == "Desk Lights"
    assert refreshed[0]["aliases"] == ["work-lamp"]
    assert refreshed[0]["room"] == "Office"
    assert (await service._resolve_device("the work lamps"))["name"] == "Desk Lights"
    assert (await service._resolve_device("office desk light"))["name"] == "Desk Lights"


async def test_configure_light_dispatch_uses_name_and_returns_only_public_metadata(
    db, bus, store
):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)
    await service.devices(refresh=True)

    result = await service.dispatch("", "configure_light", {
        "device": "the desk lamp",
        "aliases": ["work light", "task lamp"],
        "room": "Office",
    })
    assert result == {
        "name": "Desk Lights",
        "aliases": ["work light", "task lamp"],
        "room": "Office",
        "capabilities": ["brightness", "powerSwitch"],
        "actions": ["brightness", "power"],
        "enabled": True,
        "stale": False,
        "last_seen": result["last_seen"],
    }
    assert result["last_seen"]
    serialized = str(result)
    assert "catalog_ref" not in serialized
    assert "private-provider-identity" not in serialized
    assert "private-sku" not in serialized
    assert (await service._resolve_device("office task lights"))["name"] == "Desk Lights"

    # Provider identities are never resolver candidates, even for metadata.
    rejected = await service.dispatch("", "configure_light", {
        "device": "private-provider-identity",
        "room": "Bedroom",
    })
    assert "no light named" in rejected["error"]


async def test_configure_light_cannot_change_private_or_discovered_fields(db, bus, store):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)
    await service.devices(refresh=True)

    result = await service.dispatch("", "configure_light", {
        "device": "desk",
        "aliases": ["reading"],
        "provider_identity": "attacker-id",
        "sku": "attacker-sku",
        "capabilities": ["lightScene"],
    })
    assert result["aliases"] == ["reading"]
    internal = service._devices_cache[0]
    assert internal["device"] == "private-provider-identity"
    assert internal["sku"] == "private-sku"
    assert internal["capabilities"] == ["brightness", "powerSwitch"]


async def test_metadata_rejects_all_catalog_secret_collisions_without_partial_write(
    db, bus, store
):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = [
        *discovered(),
        {
            "device": "OTHER:Device-ID",
            "sku": "Other-SKU_99",
            "name": "Hall Light",
            "capabilities": ["powerSwitch"],
        },
    ]
    service._govee = AsyncMock(return_value=client)
    await service.devices(refresh=True)

    attempts = [
        {"aliases": ["private-provider-identity"]},
        {"aliases": ["PRIVATE provider_identity"]},
        {"room": "private sku"},
        {"aliases": ["other device id"]},
        {"room": "OTHER sku-99"},
        {"aliases": ["ＰＲＩＶＡＴＥ－ＰＲＯＶＩＤＥＲ－ＩＤＥＮＴＩＴＹ"]},
        {"room": "ＯＴＨＥＲ＿ＳＫＵ－９９"},
        {"aliases": ["safe alias", "OTHER:Device-ID"], "room": "Office"},
    ]
    for metadata in attempts:
        rejected = await service.dispatch(
            "", "configure_light", {"device": "desk", **metadata}
        )
        assert "private provider identifiers" in rejected["error"]

    row = await db.fetchone(
        "SELECT aliases_json, room FROM device_catalog WHERE canonical_name='Desk Lights'"
    )
    assert row["aliases_json"] == "[]"
    assert row["room"] is None


async def test_malformed_catalog_metadata_is_sanitized_for_all_public_paths(
    db, bus, store
):
    await db.execute(
        "INSERT INTO device_catalog "
        "(id, provider, provider_identity, provider_sku, canonical_name, aliases_json, "
        "room, capabilities_json, last_seen, stale) "
        "VALUES (?, 'govee', ?, ?, ?, ?, ?, '[]', NULL, 0)",
        (
            "malformed-one",
            "SECRET:Device-01",
            "SKU_Private-77",
            "other device 02",
            '["other sku 88", "Safe alias"]',
            "SECRET_DEVICE-01",
        ),
    )
    await db.execute(
        "INSERT INTO device_catalog "
        "(id, provider, provider_identity, provider_sku, canonical_name, aliases_json, "
        "room, capabilities_json, last_seen, stale) "
        "VALUES (?, 'govee', ?, ?, ?, '[]', NULL, '[]', NULL, 0)",
        (
            "malformed-two",
            "OTHER:Device-02",
            "Other_SKU-88",
            "ZZZ Hall Light",
        ),
    )
    service = make_service(db, bus, store)
    public = await service.devices()
    malformed_public = next(item for item in public if item["aliases"] == ["Safe alias"])
    assert malformed_public["name"].startswith("Govee light ")
    assert malformed_public["room"] is None
    for secret in (
        "SECRET:Device-01", "SKU_Private-77", "other device 02", "other sku 88",
    ):
        assert secret not in str(public)

    for secret_input in (
        "secret-device-01", "SKU private 77", "other device 02", "other sku 88",
    ):
        rejected = await service.dispatch(
            "", "configure_light", {"device": secret_input, "room": "Office"}
        )
        assert "no light named" in rejected["error"]

    # Failed refresh results also project the already-stored catalog safely.
    client = AsyncMock()
    client.list_devices.side_effect = RuntimeError("offline")
    service._govee = AsyncMock(return_value=client)
    refreshed = await service.dispatch("", "refresh_devices", {})
    assert refreshed["lights"]["ok"] is False
    assert "SECRET:Device-01" not in str(refreshed)
    assert "SKU_Private-77" not in str(refreshed)

    configured = await service.dispatch(
        "", "configure_light", {
            "device": malformed_public["name"],
            "room": "Office",
        }
    )
    assert configured["room"] == "Office"
    assert "catalog_ref" not in configured
    assert "SECRET:Device-01" not in str(configured)
    assert "SKU_Private-77" not in str(configured)


async def test_nfkc_equivalent_preexisting_metadata_never_becomes_public_or_resolvable(
    db, bus, store
):
    await db.execute(
        "INSERT INTO device_catalog "
        "(id, provider, provider_identity, provider_sku, canonical_name, aliases_json, "
        "room, capabilities_json, last_seen, stale) "
        "VALUES ('nfkc-one', 'govee', 'ABC123', 'OWN-SKU', 'ＡＢＣ１２３', "
        "'[\"ＳＫＵ９９\", \"Reading\"]', 'ＣＲＯＳＳ４２', '[]', NULL, 0)"
    )
    await db.execute(
        "INSERT INTO device_catalog "
        "(id, provider, provider_identity, provider_sku, canonical_name, aliases_json, "
        "room, capabilities_json, last_seen, stale) "
        "VALUES ('nfkc-two', 'govee', 'CROSS42', 'SKU99', 'Hall Light', "
        "'[]', NULL, '[]', NULL, 0)"
    )
    service = make_service(db, bus, store)

    public = await service.devices()
    sanitized = next(item for item in public if item["aliases"] == ["Reading"])
    assert sanitized["name"].startswith("Govee light ")
    assert sanitized["room"] is None
    for private in ("ＡＢＣ１２３", "ＳＫＵ９９", "ＣＲＯＳＳ４２", "ABC123", "SKU99", "CROSS42"):
        assert private not in str(public)

    for label in ("ＡＢＣ１２３", "ＳＫＵ９９", "ＣＲＯＳＳ４２"):
        rejected = await service.dispatch(
            "", "configure_light", {"device": label, "room": "Office"}
        )
        assert "error" in rejected

    client = AsyncMock()
    client.list_devices.side_effect = RuntimeError("offline")
    service._govee = AsyncMock(return_value=client)
    refresh = await service.dispatch("", "refresh_devices", {})
    for private in ("ＡＢＣ１２３", "ＳＫＵ９９", "ＣＲＯＳＳ４２", "ABC123", "SKU99", "CROSS42"):
        assert private not in str(refresh)

    configured = await service.dispatch(
        "", "configure_light", {"device": sanitized["name"], "room": "Library"}
    )
    assert configured["room"] == "Library"
    for private in ("ＡＢＣ１２３", "ＳＫＵ９９", "ＣＲＯＳＳ４２", "ABC123", "SKU99", "CROSS42"):
        assert private not in str(configured)


async def test_govee_status_is_strictly_projected_without_cloud_metadata(db, bus, store):
    service = make_service(db, bus, store)
    service._devices_cache = [{
        "catalog_ref": "private-ref",
        "device": "private-provider-identity",
        "sku": "private-sku",
        "name": "Desk Light",
        "aliases": [],
        "room": None,
        "enabled": True,
        "stale": False,
        "capabilities": ["powerSwitch", "brightness", "colorRgb", "lightScene"],
    }]
    client = AsyncMock()
    client.get_state.return_value = {
        "requestId": "private-request-id",
        "code": 200,
        "payload": {
            "device": "private-provider-identity",
            "sku": "private-sku",
            "nested": {"deviceId": "nested-private-id"},
            "capabilities": [
                {
                    "type": "devices.capabilities.on_off",
                    "instance": "powerSwitch",
                    "state": {"value": 1, "deviceId": "state-private-id"},
                },
                {
                    "instance": "brightness",
                    "state": {"value": 42},
                    "requestId": "capability-private-id",
                },
                {"instance": "colorRgb", "state": {"value": 0xA52A2A}},
                {"instance": "lightScene", "state": {"value": "Sunset"}},
                {
                    "instance": "unknownCapability",
                    "state": {"value": {"id": "unknown-private-id"}},
                },
            ],
        },
    }
    service._govee = AsyncMock(return_value=client)

    result = await service.dispatch("", "get_govee_status", {"device": "desk"})
    assert result == {
        "device": "Desk Light",
        "state": {
            "available": True,
            "power": "on",
            "brightness": 42,
            "color": "#A52A2A",
            "scene": "Sunset",
        },
    }
    serialized = str(result)
    for secret_value in (
        "private-provider-identity",
        "private-sku",
        "private-request-id",
        "nested-private-id",
        "state-private-id",
        "capability-private-id",
        "unknown-private-id",
    ):
        assert secret_value not in serialized

    client.get_state.return_value = {
        "payload": {
            "device": "private-provider-identity",
            "capabilities": [{"instance": "mystery", "state": {"value": "secret"}}],
        }
    }
    unknown = await service.dispatch("", "get_govee_status", {"device": "desk"})
    assert unknown == {
        "device": "Desk Light",
        "state": {"available": False, "state": "unknown"},
    }


async def test_ambiguity_and_unsupported_capability_are_safe(db, bus, store):
    service = make_service(db, bus, store)
    service._devices_cache = [
        {
            "device": "one", "sku": "one", "name": "Left Light",
            "aliases": ["reading"], "enabled": True, "stale": False,
            "capabilities": ["powerSwitch"],
        },
        {
            "device": "two", "sku": "two", "name": "Right Light",
            "aliases": ["reading"], "enabled": True, "stale": False,
            "capabilities": ["powerSwitch"],
        },
    ]
    ambiguous = await service.dispatch("", "set_govee_power", {
        "device": "reading lights", "state": "on",
    })
    assert "ambiguous" in ambiguous["error"]

    unsupported = await service.dispatch("", "set_govee_brightness", {
        "device": "left", "percentage": 50,
    })
    assert "does not support brightness" in unsupported["error"]


async def test_concurrent_refresh_is_single_flight(db, bus, store):
    service = make_service(db, bus, store)
    calls = 0
    release = asyncio.Event()

    async def list_devices():
        nonlocal calls
        calls += 1
        await release.wait()
        return discovered()

    client = AsyncMock()
    client.list_devices.side_effect = list_devices
    service._govee = AsyncMock(return_value=client)
    requests = [asyncio.create_task(service.devices(refresh=True)) for _ in range(4)]
    await asyncio.sleep(0)
    release.set()
    await asyncio.gather(*requests)
    assert calls == 1


async def test_failed_refresh_reports_failure_and_keeps_prior_catalog(db, bus, store):
    service = make_service(db, bus, store)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)
    before = await service.devices(refresh=True)
    client.list_devices.side_effect = RuntimeError("must not leak")

    result = await service.dispatch("", "refresh_devices", {})
    assert result["lights"]["ok"] is False
    assert result["lights"]["error"] == "Govee discovery failed"
    assert result["lights"]["devices"] == before
    assert await service.devices() == before


async def test_combined_refresh_treats_offline_tv_as_normal(db, bus, store):
    tv = AsyncMock()
    from integrations.lg_webos import WebOSTVError

    tv.refresh.side_effect = WebOSTVError("TV is offline")
    service = make_service(db, bus, store, tv=tv)
    client = AsyncMock()
    client.list_devices.return_value = discovered()
    service._govee = AsyncMock(return_value=client)

    result = await service.dispatch("", "refresh_devices", {})
    assert result["lights"]["ok"] is True
    assert result["tv"]["ok"] is True
    assert result["tv"]["status"] == "offline"
    assert "private-provider-identity" not in str(result)
    tv.refresh.assert_awaited_once_with()