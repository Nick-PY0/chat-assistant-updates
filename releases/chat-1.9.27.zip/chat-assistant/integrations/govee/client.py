"""Govee official cloud API adapter with strict input validation."""

from __future__ import annotations

import re
import secrets
from typing import Any

import httpx

from chat_core.identifiers import provider_secret_key

BASE = "https://openapi.api.govee.com"

COLOR_NAMES = {
    "black": (0, 0, 0),
    "red": (255, 0, 0),
    "green": (0, 128, 0),
    "blue": (0, 0, 255),
    "white": (255, 255, 255),
    "yellow": (255, 255, 0),
    "orange": (255, 165, 0),
    "purple": (128, 0, 128),
    "pink": (255, 192, 203),
    "cyan": (0, 255, 255),
    "aqua": (0, 255, 255),
    "teal": (0, 128, 128),
    "brown": (165, 42, 42),
    "gray": (128, 128, 128),
    "grey": (128, 128, 128),
    "lime": (0, 255, 0),
    "magenta": (255, 0, 255),
    "fuchsia": (255, 0, 255),
    "maroon": (128, 0, 0),
    "navy": (0, 0, 128),
    "olive": (128, 128, 0),
    "silver": (192, 192, 192),
}

_HEX_COLOR_RE = re.compile(r"#[0-9A-Fa-f]{6}\Z")


class GoveeError(Exception):
    pass


def parse_color(color: str) -> tuple[int, int, int]:
    if not isinstance(color, str):
        raise GoveeError("color must be a named color or exactly #RRGGBB")
    c = color.strip().lower()
    if c in COLOR_NAMES:
        return COLOR_NAMES[c]
    # Hex is intentionally stricter than names: surrounding whitespace,
    # shorthand forms, missing '#', and alpha channels are all rejected.
    if color.startswith("#"):
        if not _HEX_COLOR_RE.fullmatch(color):
            raise GoveeError("hex color must be exactly #RRGGBB")
        return int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    if not c:
        raise GoveeError("color is required")
    raise GoveeError(
        f"unknown color '{color}'; use a supported named color or exactly #RRGGBB"
    )


def canonical_color(color: str) -> str:
    """Validate *color* and return its canonical uppercase #RRGGBB form."""
    red, green, blue = parse_color(color)
    return f"#{red:02X}{green:02X}{blue:02X}"


def pack_rgb(red: int, green: int, blue: int) -> int:
    """Pack validated RGB channels into the integer required by Govee."""
    channels = (red, green, blue)
    if any(isinstance(channel, bool) or not isinstance(channel, int) for channel in channels):
        raise GoveeError("RGB channels must be integers")
    if any(not 0 <= channel <= 255 for channel in channels):
        raise GoveeError("RGB channels must be between 0 and 255")
    return (red << 16) | (green << 8) | blue


def validate_percentage(value: Any) -> int:
    try:
        pct = int(value)
    except (TypeError, ValueError) as exc:
        raise GoveeError("percentage must be a number") from exc
    if not 0 <= pct <= 100:
        raise GoveeError("percentage must be between 0 and 100")
    return pct


class GoveeClient:
    def __init__(self, api_key: str, timeout: float = 3.0) -> None:
        self._key = api_key
        self.timeout = timeout

    def _headers(self) -> dict:
        return {"Govee-API-Key": self._key, "Content-Type": "application/json"}

    async def _post(self, path: str, payload: dict) -> dict:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.post(BASE + path, json=payload, headers=self._headers())
        except httpx.HTTPError as exc:
            raise GoveeError(f"network: {type(exc).__name__}") from exc
        if resp.status_code == 401:
            raise GoveeError("Govee API key rejected")
        if resp.status_code == 429:
            raise GoveeError("Govee rate limit hit; try again shortly")
        if resp.status_code >= 400:
            raise GoveeError(f"Govee error HTTP {resp.status_code}")
        try:
            return resp.json()
        except ValueError as exc:
            raise GoveeError("Govee returned invalid JSON") from exc

    async def _get(self, path: str) -> dict:
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                resp = await client.get(BASE + path, headers=self._headers())
        except httpx.HTTPError as exc:
            raise GoveeError(f"network: {type(exc).__name__}") from exc
        if resp.status_code == 401:
            raise GoveeError("Govee API key rejected")
        if resp.status_code >= 400:
            raise GoveeError(f"Govee error HTTP {resp.status_code}")
        try:
            return resp.json()
        except ValueError as exc:
            raise GoveeError("Govee returned invalid JSON") from exc

    # ------------------------------------------------------------------
    async def list_devices(self) -> list[dict]:
        data = await self._get("/router/api/v1/user/devices")
        valid_items = []
        secret_keys = set()
        for item in data.get("data", []) or []:
            if not isinstance(item, dict):
                continue
            identity = item.get("device")
            sku = item.get("sku")
            if not isinstance(identity, str) or not identity or not isinstance(sku, str) or not sku:
                continue
            valid_items.append((item, identity, sku))
            secret_keys.update((provider_secret_key(identity), provider_secret_key(sku)))

        devices = []
        for index, (item, identity, sku) in enumerate(valid_items, 1):
            candidate = item.get("deviceName")
            if (
                not isinstance(candidate, str)
                or not candidate.strip()
                or provider_secret_key(candidate) in secret_keys
            ):
                candidate = f"Govee light {index}"
                suffix = index
                while provider_secret_key(candidate) in secret_keys:
                    suffix += 1
                    candidate = f"Govee light {suffix}"
            devices.append(
                {
                    "device": identity,
                    "sku": sku,
                    "name": candidate.strip(),
                    "capabilities": sorted({
                        c.get("instance")
                        for c in item.get("capabilities", []) or []
                        if isinstance(c, dict) and isinstance(c.get("instance"), str)
                    }),
                }
            )
        return devices

    async def _control(self, sku: str, device: str, capability: dict) -> dict:
        payload = {
            "requestId": secrets.token_hex(8),
            "payload": {"sku": sku, "device": device, "capability": capability},
        }
        return await self._post("/router/api/v1/device/control", payload)

    async def set_power(self, sku: str, device: str, on: bool) -> dict:
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.on_off", "instance": "powerSwitch", "value": 1 if on else 0},
        )

    async def set_brightness(self, sku: str, device: str, percentage: int) -> dict:
        pct = validate_percentage(percentage)
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.range", "instance": "brightness", "value": max(pct, 1)},
        )

    async def set_color(self, sku: str, device: str, color: str) -> dict:
        r, g, b = parse_color(color)
        return await self._control(
            sku,
            device,
            {
                "type": "devices.capabilities.color_setting",
                "instance": "colorRgb",
                "value": pack_rgb(r, g, b),
            },
        )

    async def activate_scene(self, sku: str, device: str, scene_value: Any) -> dict:
        return await self._control(
            sku,
            device,
            {"type": "devices.capabilities.dynamic_scene", "instance": "lightScene", "value": scene_value},
        )

    async def get_state(self, sku: str, device: str) -> dict:
        payload = {
            "requestId": secrets.token_hex(8),
            "payload": {"sku": sku, "device": device},
        }
        return await self._post("/router/api/v1/device/state", payload)
