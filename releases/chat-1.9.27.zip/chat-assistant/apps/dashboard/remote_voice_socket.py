"""WebSocket transport for the remote-native voice endpoint (/ws/remote-voice).

Protocol v1 (all control frames are compact JSON text; audio is binary):

  Browser -> server
    hello     first frame: {type, protocol, token, device, takeover?, resume?}
    binary    "JV" v1 header (8 bytes: magic, ver, flags, u32 seq) + exactly
              2560 bytes PCM16LE mono 16 kHz (one 80 ms frame)
    start     begin a conversation manually {takeover_host?: bool}
    end       goodbye — end the conversation, keep wake listening
    stop      silence playback now (also dismisses a ringing alarm)
    mute      {muted: bool} — gates THIS device's mic server-side
    playback  {playing: bool} — assistant audio actually playing on device
    media     {playing: bool} — other media audible near the device
    diag      client-side capture/playback metrics (numbers only)
    ping      {t} -> pong

  Server -> browser
    ready     lease granted/resumed: epoch, resume token, wake availability
    busy      another device owns the endpoint (socket then closes 4409)
    busy_host the HOST is mid-conversation; offer explicit takeover
    state     {state: wake|starting|listening|speaking|local_only, reason}
    wake      the wake word was detected (UI feedback)
    clear     {scope: voice|announce, turn?} — flush scheduled playback
    transcript, local_only, muted, revoked, start_result, pong
    binary    "JA" v1 header (12 bytes: magic, ver, kind, u16 turn, rsvd,
              u32 seq) + PCM16LE mono 24 kHz

  Close codes: 4401 auth, 4403 origin/disabled, 4409 busy, 4412 revoked,
  1008 protocol/rate violation, 1001 idle timeout.

Security: cookie session + fresh scoped capability (fetched over an
authenticated CSRF-protected endpoint) + same-origin check. Provider
credentials never appear in this protocol.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import time
from collections import deque
from urllib.parse import urlparse

from fastapi import WebSocket, WebSocketDisconnect

from chat_core.pcm import rms16
from chat_core.models.state import ChatState
from chat_core.security.auth import SessionManager
from apps.audio.mic_gate import PlaybackAwareMicGate
from apps.live_gateway.remote_voice import (
    DOWN_HEADER,
    FRAME_BYTES,
    KIND_VOICE,
    UP_HEADER,
    UP_MAGIC,
    UP_VERSION,
    _CLIENT_STATE,
    RemoteVoiceService,
)

COOKIE = "chat_session"
CAPABILITY_SCOPE = "remote-voice"
CAPABILITY_MAX_AGE = 120          # seconds a fetched token stays presentable
HELLO_TIMEOUT = 8.0               # seconds to present hello after connect
IDLE_TIMEOUT = 90.0               # client pings every ~20 s; silence = dead
MAX_TEXT_BYTES = 4096
MAX_BINARY_BYTES = UP_HEADER.size + FRAME_BYTES
AUDIO_BACKLOG_MAX = 96            # outbound audio frames queued before drop
OUTBOX_HARD_MAX = 512             # any outbound backlog beyond this is fatal
MALFORMED_LIMIT = 20              # bad binary frames tolerated before close

# Upstream budget: nominal mic rate is 32 KB/s; allow 3x sustained for
# reconnect bursts, with a ~4 s burst bucket.
AUDIO_RATE_BYTES = 96_000
AUDIO_BURST_BYTES = 384_000
TEXT_RATE = 30.0                  # control messages per second (burst 60)
TEXT_BURST = 60.0


class _Bucket:
    """Token bucket; cost units are arbitrary (bytes or messages)."""

    __slots__ = ("rate", "burst", "tokens", "last")

    def __init__(self, rate: float, burst: float) -> None:
        self.rate = rate
        self.burst = burst
        self.tokens = burst
        self.last = time.monotonic()

    def take(self, cost: float) -> bool:
        now = time.monotonic()
        self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)
        self.last = now
        if self.tokens < cost:
            return False
        self.tokens -= cost
        return True


def _clean_label(value, fallback: str = "Remote device") -> str:
    if not isinstance(value, str):
        return fallback
    cleaned = "".join(ch for ch in value.strip() if ch.isprintable())
    return cleaned[:48] or fallback


def _same_origin(ws: WebSocket) -> bool:
    """WebSocket handshakes from browsers must come from our own pages.

    Non-browser clients (tests, curl) omit Origin entirely — that is fine:
    the cookie + capability requirement still gates them.
    """
    origin = ws.headers.get("origin")
    if not origin:
        return True
    host = (ws.headers.get("host") or "").strip().lower()
    netloc = (urlparse(origin).netloc or "").strip().lower()
    return bool(host) and netloc == host


async def serve_remote_voice_socket(
    rt, ws: WebSocket, sessions: SessionManager
) -> None:
    """Handle one remote-voice device connection end to end."""
    svc: RemoteVoiceService | None = getattr(rt, "remote_voice", None)

    cookie = ws.cookies.get(COOKIE)
    if sessions.validate(cookie) is None:
        await ws.close(code=4401)
        return
    if not _same_origin(ws):
        await ws.close(code=4403, reason="origin mismatch")
        return
    if svc is None:
        await ws.close(code=4403, reason="cloud voice is disabled")
        return

    await ws.accept()

    # ---- hello ---------------------------------------------------------
    try:
        first = await asyncio.wait_for(ws.receive(), timeout=HELLO_TIMEOUT)
    except asyncio.TimeoutError:
        await ws.close(code=1008, reason="hello timeout")
        return
    if first.get("type") == "websocket.disconnect":
        return
    try:
        hello = json.loads(first.get("text") or "")
    except (TypeError, ValueError):
        hello = None
    if not isinstance(hello, dict) or hello.get("type") != "hello":
        await ws.close(code=1008, reason="expected hello")
        return
    if hello.get("protocol") != 1:
        await ws.close(code=1008, reason="unsupported protocol")
        return
    if not sessions.capability_ok(
        cookie, hello.get("token"), CAPABILITY_SCOPE, max_age=CAPABILITY_MAX_AGE
    ):
        await ws.close(code=4401, reason="invalid or expired token")
        return

    device_label = _clean_label(hello.get("device"))
    resume = hello.get("resume") if isinstance(hello.get("resume"), dict) else {}
    resume_epoch = resume.get("epoch") if isinstance(resume.get("epoch"), int) else None
    resume_secret = resume.get("secret") if isinstance(resume.get("secret"), str) else None

    status, granted = svc.claim(
        device_label,
        takeover=bool(hello.get("takeover")),
        resume_epoch=resume_epoch,
        resume_secret=resume_secret,
    )
    if status == "busy":
        await ws.send_text(json.dumps({"type": "busy", "holder": granted}))
        await ws.close(code=4409, reason="another device is connected")
        return
    lease = granted  # type: ignore[assignment]

    # ---- outbox (control has priority over audio via never-drop rule) ---
    outbox: deque[tuple[str, object]] = deque()
    outbox_wake = asyncio.Event()
    audio_pending = 0
    overflowed = False

    def enqueue_text(payload: str) -> None:
        nonlocal overflowed
        if overflowed:
            return  # already fatal; never grow the queue further
        if len(outbox) >= OUTBOX_HARD_MAX:
            # Hard bound: the client is not draining at all.  Stop queueing
            # (the deque must never grow behind a writer blocked mid-send)
            # and force the transport closed — closing unblocks the stuck
            # send and the reader exits via the disconnect message.
            overflowed = True
            outbox_wake.set()
            asyncio.ensure_future(close_socket(1008, "client not draining"))
            return
        outbox.append(("text", payload))
        outbox_wake.set()

    def enqueue_audio(frame: bytes) -> None:
        nonlocal audio_pending
        if overflowed:
            return
        if audio_pending >= AUDIO_BACKLOG_MAX:
            for i, (kind, _) in enumerate(outbox):
                if kind == "bytes":
                    del outbox[i]
                    audio_pending -= 1
                    lease.stats["queue_drops_out"] += 1
                    break
        outbox.append(("bytes", frame))
        audio_pending += 1
        outbox_wake.set()

    def _purge_audio(kind_byte: int | None) -> None:
        """Drop queued audio of one downstream kind (None = all)."""
        nonlocal audio_pending
        kept: list[tuple[str, object]] = []
        removed = 0
        for item in outbox:
            if item[0] == "bytes" and (
                kind_byte is None
                or DOWN_HEADER.unpack_from(item[1])[2] == kind_byte  # type: ignore[arg-type]
            ):
                removed += 1
                continue
            kept.append(item)
        if removed:
            outbox.clear()
            outbox.extend(kept)
            audio_pending -= removed
            lease.stats["queue_drops_out"] += removed

    def enqueue_control(payload: str, purge_kind: int | None = KIND_VOICE) -> None:
        """Priority lane for fencing controls (turn clear / lane clear /
        revocation).  Queued audio of the fenced kind is stale by definition
        the moment the control is issued — purge it, then deliver the
        control ahead of any remaining audio (text FIFO order preserved).
        Without this, Stop/barge-in on a slow link sits behind a backlog of
        old-turn frames and the phone plays them before learning the turn
        changed."""
        nonlocal overflowed
        if overflowed:
            return
        if len(outbox) >= OUTBOX_HARD_MAX:
            overflowed = True
            outbox_wake.set()
            asyncio.ensure_future(close_socket(1008, "client not draining"))
            return
        _purge_audio(purge_kind)
        try:
            revoking = json.loads(payload).get("type") == "revoked"
        except (TypeError, ValueError):
            revoking = False
        if revoking:
            # Nothing queued by the former owner remains authoritative.
            outbox.clear()
            outbox.append(("text", payload))
            outbox_wake.set()
            return
        texts = [i for i in outbox if i[0] == "text"]
        audio_items = [i for i in outbox if i[0] == "bytes"]
        outbox.clear()
        outbox.extend(texts)
        outbox.append(("text", payload))
        outbox.extend(audio_items)
        outbox_wake.set()

    async def close_socket(code: int, reason: str) -> None:
        try:
            await ws.close(code=code, reason=(reason or "")[:110])
        except Exception:
            pass

    binding = svc.bind(
        lease,
        enqueue_text=enqueue_text,
        enqueue_audio=enqueue_audio,
        enqueue_control=enqueue_control,
        close=close_socket,
    )
    if binding is None:  # revoked between claim and bind (rare but possible)
        await ws.close(code=4412, reason="lease revoked")
        return

    def owns_binding() -> bool:
        return svc.is_current_binding(lease, binding)

    def sendj(payload: dict) -> None:
        """Queue a direct reply only for this exact, still-current socket."""
        if not owns_binding():
            return
        enqueue_text(json.dumps({
            "epoch": lease.epoch,
            "turn": svc.current_turn,
            **payload,
        }, separators=(",", ":")))

    prepared_wake_audio = None
    wake_prepare_lock = asyncio.Lock()

    def wake_audio():
        """Return the CURRENT wake-capable engine, if ready."""
        current = rt.audio
        if (
            current is not None
            and getattr(current, "remote_wake_available", False)
            and hasattr(current, "run_remote_wake")
        ):
            return current
        return None

    async def prepare_wake_audio(*, force: bool = False):
        """Reset each newly ready/reloaded engine before advertising it."""
        nonlocal prepared_wake_audio
        if not owns_binding():
            return None
        current = wake_audio()
        if current is None:
            prepared_wake_audio = None
            return None
        async with wake_prepare_lock:
            current = wake_audio()
            if current is None:
                prepared_wake_audio = None
                return None
            if not force and current is prepared_wake_audio:
                return current
            audio = current
            reset_wake = getattr(audio, "reset_remote_wake", None)
            if callable(reset_wake):
                result = reset_wake()
                if inspect.isawaitable(result):
                    await result
            if not owns_binding():
                return None
            # A settings reload may replace the engine while reset awaited.
            if audio is not wake_audio():
                prepared_wake_audio = None
                return None
            prepared_wake_audio = audio
            return audio

    # bind() gates the host synchronously. Wait for any host inference already
    # off-thread, then reset before the phone is told wake listening is ready.
    current_wake_audio = await prepare_wake_audio(force=True)
    if not owns_binding():
        svc.detach(lease, binding)
        return

    async def reset_current_wake() -> None:
        await prepare_wake_audio(force=True)

    last_wake_available = current_wake_audio is not None
    raw_state = svc.state.raw_state
    sendj({
        "type": "ready",
        "mode": status,  # granted | resumed
        "epoch": lease.epoch,
        "resume": {"epoch": lease.epoch, "secret": lease.resume_secret},
        "wake": {"available": last_wake_available},
        "state": _CLIENT_STATE.get(raw_state, "wake"),
        "conversation_active": svc.gateway.session_intent_active,
        "generation": svc.gateway.voice_session_generation,
        "turn": svc.current_turn,
        "muted": rt.state.muted,
        "frame": {"rate": 16000, "samples": FRAME_BYTES // 2, "out_rate": 24000},
    })

    async def writer() -> None:
        nonlocal audio_pending
        while True:
            await outbox_wake.wait()
            outbox_wake.clear()
            if overflowed:
                await close_socket(1008, "client not draining")
                return
            while outbox:
                kind, payload = outbox.popleft()
                if not owns_binding():
                    # Revocation is the sole intentional message from a
                    # binding after authority is removed.  It carries that
                    # binding's old epoch/turn and cannot mutate the new owner.
                    if kind != "text":
                        return
                    try:
                        is_revoked = json.loads(payload).get("type") == "revoked"
                    except (TypeError, ValueError):
                        is_revoked = False
                    if not is_revoked:
                        return
                if kind == "bytes":
                    audio_pending -= 1
                    await ws.send_bytes(payload)  # type: ignore[arg-type]
                else:
                    await ws.send_text(payload)  # type: ignore[arg-type]

    writer_task = asyncio.create_task(writer())

    # ---- receive loop ----------------------------------------------------
    mic_gate = PlaybackAwareMicGate(
        max(600.0, rt.settings.interrupt_rms_threshold * 0.75)
    )
    audio_bucket = _Bucket(AUDIO_RATE_BYTES, AUDIO_BURST_BYTES)
    text_bucket = _Bucket(TEXT_RATE, TEXT_BURST)

    in_conversation = False
    wake_buf = bytearray()
    client_muted = False
    media_hint = False
    last_muted_sent = rt.state.muted
    expected_seq: int | None = None
    malformed = 0
    loud_chunks = 0
    interrupt_loud_chunks = 0
    last_voice_state = svc.state.raw_state
    wake_ack_until = 0.0
    utterance_cue_until = 0.0
    utterance_active = False
    utterance_quiet_chunks = 0
    barge_candidate_tail = 0
    close_code = 0
    close_reason = ""

    def reset_utterance() -> None:
        nonlocal loud_chunks, interrupt_loud_chunks
        nonlocal utterance_active, utterance_quiet_chunks
        mic_gate.close_utterance()
        loud_chunks = 0
        interrupt_loud_chunks = 0
        utterance_active = False
        utterance_quiet_chunks = 0
        wake_buf.clear()

    def enter_conversation() -> None:
        nonlocal in_conversation, last_voice_state
        in_conversation = True
        last_voice_state = svc.state.raw_state
        reset_utterance()

    async def leave_conversation() -> None:
        nonlocal in_conversation
        if not owns_binding():
            return
        in_conversation = False
        lease.end_generation = svc.gateway.voice_end_generation
        while not svc.gateway.audio_in.empty():
            try:
                svc.gateway.audio_in.get_nowait()
            except asyncio.QueueEmpty:
                break
        reset_utterance()
        await reset_current_wake()
        if not owns_binding():
            return

    async def handle_start(msg: dict, source: str) -> None:
        result = await svc.start_conversation(
            lease,
            takeover_host=bool(msg.get("takeover_host")),
            source=source,
            binding=binding,
        )
        if not owns_binding():
            return
        if result in ("started", "already"):
            enter_conversation()
        payload = {"type": "start_result", "status": result}
        if result == "busy_host":
            payload["holder"] = {"device": "host microphone"}
        sendj(payload)

    async def wake_status_monitor() -> None:
        """Advertise model readiness without depending on mic frames/pings."""
        nonlocal last_wake_available
        last_diag_sent = 0.0
        while True:
            await asyncio.sleep(0.5)
            if not owns_binding():
                return
            current = await prepare_wake_audio()
            if not owns_binding():
                return
            available = current is not None
            if available != last_wake_available:
                last_wake_available = available
                sendj({"type": "wake_status", "available": available})
            now = time.monotonic()
            if now - last_diag_sent >= 2.0:
                last_diag_sent = now
                diagnostics = getattr(rt.audio, "wake_diagnostics", None)
                if callable(diagnostics):
                    snapshot = diagnostics()
                    if isinstance(snapshot, dict):
                        sendj({"type": "wake_diagnostics", **snapshot})

    wake_status_task = asyncio.create_task(wake_status_monitor())

    try:
        while True:
            try:
                message = await asyncio.wait_for(ws.receive(), timeout=IDLE_TIMEOUT)
            except asyncio.TimeoutError:
                close_code, close_reason = 1001, "idle timeout"
                break
            if message.get("type") == "websocket.disconnect":
                raise WebSocketDisconnect()
            # A close and a takeover can race with an already queued receive.
            # No stale socket may perform even a bookkeeping side effect.
            if not owns_binding():
                raise WebSocketDisconnect()

            # ---------------- control ---------------------------------
            text = message.get("text")
            if text is not None:
                if len(text) > MAX_TEXT_BYTES or not text_bucket.take(1.0):
                    close_code, close_reason = 1008, "control flood"
                    break
                try:
                    msg = json.loads(text)
                except (TypeError, ValueError):
                    continue
                if not isinstance(msg, dict):
                    continue
                mtype = msg.get("type")
                if mtype == "ping":
                    current_wake_available = (
                        await prepare_wake_audio()
                    ) is not None
                    if not owns_binding():
                        raise WebSocketDisconnect()
                    if current_wake_available != last_wake_available:
                        last_wake_available = current_wake_available
                        sendj({
                            "type": "wake_status",
                            "available": current_wake_available,
                        })
                    sendj({
                        "type": "pong",
                        "t": msg.get("t"),
                        "state": _CLIENT_STATE.get(svc.state.raw_state, "wake"),
                        "turn": svc.current_turn,
                        "conversation_active": svc.gateway.session_intent_active,
                        "muted": rt.state.muted,
                        "wake_available": current_wake_available,
                        "frames_in": lease.stats["frames_in"],
                        "frames_forwarded": lease.stats["frames_forwarded"],
                    })
                elif mtype == "start":
                    await handle_start(msg, source="manual")
                elif mtype == "end":
                    svc.end_conversation(
                        lease, "user said goodbye", binding=binding
                    )
                    await leave_conversation()
                elif mtype == "stop":
                    if not owns_binding():
                        raise WebSocketDisconnect()
                    svc.interrupt_playback("user stop")
                    # Dismiss a ringing alarm from anywhere — but ONLY that.
                    # rt.stop_output() would interrupt the HOST conversation
                    # and clear host playback, which a remote device must
                    # never do implicitly.
                    rt.stop_ringing()
                elif mtype == "mute":
                    client_muted = bool(msg.get("muted"))
                    if client_muted:
                        reset_utterance()
                elif mtype == "playback":
                    playing = bool(msg.get("playing"))
                    mic_gate.set_assistant_playing(playing)
                    svc.record_playback(lease, playing, binding)
                    if not playing:
                        loud_chunks = 0
                        interrupt_loud_chunks = 0
                elif mtype == "media":
                    media_hint = bool(msg.get("playing"))
                    mic_gate.set_media_playing(rt.media_playing or media_hint)
                elif mtype == "diag":
                    stats = msg.get("stats")
                    if isinstance(stats, dict):
                        lease.stats["client"] = {
                            str(k)[:40]: v for k, v in list(stats.items())[:24]
                            if isinstance(v, (int, float, str, bool))
                        }
                continue

            # ---------------- audio -----------------------------------
            frame = message.get("bytes")
            if not frame:
                continue
            if len(frame) > MAX_BINARY_BYTES or not audio_bucket.take(len(frame)):
                close_code, close_reason = 1008, "audio flood"
                break
            if len(frame) < UP_HEADER.size:
                malformed += 1
                lease.stats["malformed_frames"] += 1
                if malformed > MALFORMED_LIMIT:
                    close_code, close_reason = 1008, "malformed frames"
                    break
                continue
            magic, version, _flags, seq = UP_HEADER.unpack_from(frame)
            pcm = frame[UP_HEADER.size:]
            if magic != UP_MAGIC or version != UP_VERSION or len(pcm) != FRAME_BYTES:
                malformed += 1
                lease.stats["malformed_frames"] += 1
                if malformed > MALFORMED_LIMIT:
                    close_code, close_reason = 1008, "malformed frames"
                    break
                continue
            lease.stats["frames_in"] += 1
            lease.stats["bytes_in"] += len(pcm)
            if lease.stats["frames_in"] == 1:
                sendj({"type": "mic_status", "status": "streaming"})
            if expected_seq is not None and seq != expected_seq:
                lease.stats["seq_gaps"] += 1
            expected_seq = (seq + 1) & 0xFFFFFFFF

            # Global mute wins over everything; notify transitions.
            if rt.state.muted != last_muted_sent:
                last_muted_sent = rt.state.muted
                sendj({"type": "muted", "muted": rt.state.muted})
            if rt.state.muted or client_muted:
                lease.stats["frames_gated"] += 1
                loud_chunks = 0
                interrupt_loud_chunks = 0
                continue

            # Explicit end (goodbye/tool) fences out queued speech.
            if in_conversation and (
                svc.gateway.voice_end_generation != lease.end_generation
            ):
                await leave_conversation()
                continue
            # Natural end: inactivity or provider close without explicit end.
            if in_conversation and not svc.gateway.session_intent_active:
                await leave_conversation()
                continue

            # ---- wake-listening mode ------------------------------------
            if not in_conversation:
                current_audio = await prepare_wake_audio()
                if not owns_binding():
                    raise WebSocketDisconnect()
                current_wake_available = current_audio is not None
                if current_wake_available != last_wake_available:
                    last_wake_available = current_wake_available
                    sendj({
                        "type": "wake_status",
                        "available": current_wake_available,
                    })
                if current_audio is None:
                    lease.stats["frames_gated"] += 1
                    continue
                wake_buf.extend(pcm)
                while len(wake_buf) >= FRAME_BYTES:
                    chunk = bytes(wake_buf[:FRAME_BYTES])
                    del wake_buf[:FRAME_BYTES]
                    hit = await current_audio.run_remote_wake(chunk)
                    if not owns_binding():
                        raise WebSocketDisconnect()  # taken over mid-inference
                    if current_audio is not rt.audio:
                        # Settings reload replaced the model during inference.
                        # Never act on a stale engine's rolling state.
                        prepared_wake_audio = None
                        wake_buf.clear()
                        break
                    if hit and not rt.state.muted:
                        wake_ack_until = time.monotonic() + 0.35
                        sendj({"type": "wake", "sound": "wake_ack"})
                        await handle_start({}, source="wake")
                        if not owns_binding():
                            raise WebSocketDisconnect()
                        break
                continue

            # ---- conversation mode --------------------------------------
            if barge_candidate_tail:
                # One already-in-flight frame after the local interrupt still
                # belongs to the echo/candidate window, never provider input.
                barge_candidate_tail -= 1
                lease.stats["frames_gated"] += 1
                continue
            if time.monotonic() < max(wake_ack_until, utterance_cue_until):
                # The phone plays a short local acknowledgement cue. Keep its
                # speaker echo out of provider input without extending the
                # normal assistant-playback settling tail.
                lease.stats["frames_gated"] += 1
                mic_gate.close_utterance()
                loud_chunks = 0
                interrupt_loud_chunks = 0
                continue
            mic_gate.set_media_playing(rt.media_playing or media_hint)
            voice_state = svc.state.raw_state
            if (
                voice_state == ChatState.SLEEPING
                and last_voice_state != ChatState.SLEEPING
            ):
                reset_utterance()
            last_voice_state = voice_state

            gate_was_open = mic_gate.is_open
            frame_level = rms16(pcm)
            forwarded_this_frame = False
            if voice_state == ChatState.SPEAKING:
                # Fast local candidate path. Candidate PCM is intentionally
                # never fed onward: two sustained frames trigger an immediate
                # local clear/provider cancel, while AEC + the bounded learned
                # playback bar retain echo protection.
                candidate_bar = max(
                    rt.settings.interrupt_rms_threshold,
                    mic_gate.speech_bar(),
                )
                if frame_level > candidate_bar:
                    interrupt_loud_chunks += 1
                else:
                    interrupt_loud_chunks = 0
                if interrupt_loud_chunks >= 2:
                    interrupt_loud_chunks = 0
                    barge_candidate_tail = 1
                    lease.stats["barge_ins"] += 1
                    if not owns_binding():
                        raise WebSocketDisconnect()
                    svc.interrupt_playback("barge-in")
                continue
            for speech_pcm in mic_gate.feed(pcm):
                interrupt_loud_chunks = 0
                if svc.gateway.voice_end_generation != lease.end_generation:
                    await leave_conversation()
                    break
                lease.stats["frames_forwarded"] += 1
                forwarded_this_frame = True
                try:
                    svc.gateway.audio_in.put_nowait(speech_pcm)
                except asyncio.QueueFull:
                    lease.stats["queue_drops_in"] += 1
                    try:
                        svc.gateway.audio_in.get_nowait()
                    except asyncio.QueueEmpty:
                        pass
                    svc.gateway.audio_in.put_nowait(speech_pcm)
            # Utterance acceptance is based on sustained local energy, but is
            # only acknowledged after at least one safe frame could be
            # forwarded. During assistant playback candidates remain
            # echo-only and are never provider input.
            if voice_state != ChatState.SPEAKING and forwarded_this_frame:
                if frame_level >= max(500, rt.settings.interrupt_rms_threshold / 2):
                    utterance_quiet_chunks = 0
                    if not utterance_active:
                        loud_chunks += 1
                        if loud_chunks >= 2:
                            utterance_active = svc.accept_utterance(
                                lease, binding
                            )
                            loud_chunks = 0
                            if utterance_active:
                                utterance_cue_until = time.monotonic() + 0.28
                else:
                    loud_chunks = 0
                    if utterance_active:
                        utterance_quiet_chunks += 1
                        if utterance_quiet_chunks >= 7:
                            utterance_active = False
                            utterance_quiet_chunks = 0
            if not gate_was_open and mic_gate.is_open and not mic_gate.assistant_playing:
                await svc.user_speech_onset(lease, binding)
                if not owns_binding():
                    raise WebSocketDisconnect()

    except (WebSocketDisconnect, RuntimeError, ConnectionError):
        pass
    finally:
        if close_reason:
            svc.record_error(lease, close_reason)
        writer_task.cancel()
        wake_status_task.cancel()
        await asyncio.gather(writer_task, wake_status_task, return_exceptions=True)
        svc.detach(lease, binding)
        if close_code:
            await close_socket(close_code, close_reason)
