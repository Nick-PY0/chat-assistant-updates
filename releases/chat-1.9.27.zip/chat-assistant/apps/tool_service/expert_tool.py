"""Bounded, read-only consultations with Relay-backed expert models."""

from __future__ import annotations

import asyncio
import logging
import re

from chat_core.logging_setup import contains_supplied_secret
from chat_core.models.credentials import utcnow
from integrations.relay.client import RelayClient, RelayError, RelayModel

log = logging.getLogger("expert_tools")

MAX_QUERY_CHARS = 12_000
MAX_REPLY_CHARS = 24_000
MAX_TOKENS = 8_192
MAX_ATTEMPTS = 2
TIMEOUT_SECONDS = 45.0

_PROVIDERS = {
    "chatgpt": ("openai", "expert_chatgpt_enabled", "expert_chatgpt_model",
                "expert_chatgpt_models"),
    "claude": ("anthropic", "expert_claude_enabled", "expert_claude_model",
               "expert_claude_models"),
}
class ExpertError(Exception):
    pass


def select_expert_models(models: tuple[RelayModel, ...], provider: str,
                         enabled_ids: list[str], preferred: str,
                         requested: str = "auto", query: str = "") -> list[RelayModel]:
    upstream = _PROVIDERS[provider][0]
    allowed = set(enabled_ids)
    pool = [
        model for model in models
        if model.enabled and model.provider == upstream and model.job == "chat"
        and "text" in model.modalities and (not allowed or model.id in allowed)
    ]
    if not pool:
        return []
    def quality(model: RelayModel) -> tuple:
        return (not model.reasoning, -model.rank, model.cost_rank, model.id)

    ordered = sorted(pool, key=quality)
    choice = str(requested or "auto").strip()
    if choice != "auto":
        if not any(model.id == choice for model in pool):
            return []
        ordered.sort(key=lambda model: model.id != choice)
    else:
        from integrations.relay.client import classify_turn

        kind = classify_turn(query)
        coding = bool(re.search(
            r"(?i)\b(code|coding|debug|bug|program(?:ming)?|python|javascript|"
            r"typescript|sql|compiler|api|refactor|algorithm)\b", query
        ))
        if provider == "chatgpt":
            specialist = (
                [model for model in pool if "codex" in model.id.lower()]
                if coding else []
            )
            if not specialist and kind == "complex":
                specialist = [model for model in pool if model.reasoning]
            if not specialist and preferred:
                specialist = [model for model in pool if model.id == preferred]
        else:
            family = "opus" if kind == "complex" and not coding else "sonnet"
            specialist = [
                model for model in pool
                if family in (model.id + " " + model.label).lower()
            ]
        specialist = sorted(specialist, key=quality)
        ordered = specialist + [
            model for model in ordered if model not in specialist
        ]
    return ordered[:MAX_ATTEMPTS]


class ExpertRelayService:
    def __init__(self, settings, credentials, db, client_factory=RelayClient):
        self.settings = settings
        self.credentials = credentials
        self.db = db
        self.client_factory = client_factory

    async def _client(self) -> RelayClient:
        url = str(getattr(self.settings, "relay_url", "") or "").strip()
        if not url:
            raise ExpertError("Relay is not configured")
        credentials = [
            item for item in await self.credentials.list(provider="relay")
            if item.status not in ("invalid", "disabled")
            and not (item.retry_after and item.retry_after > utcnow())
        ]
        if not credentials:
            raise ExpertError("Relay credential is unavailable")
        try:
            secret = await self.credentials.get_secret(credentials[0].id)
        except KeyError as exc:
            raise ExpertError("Relay credential could not be unlocked") from exc
        return self.client_factory(url, secret, timeout=TIMEOUT_SECONDS)

    async def catalog(self) -> dict:
        client = await self._client()
        discovery = await client.discover_models()
        providers = {}
        for provider, (upstream, _, _, _) in _PROVIDERS.items():
            providers[provider] = [
                {"id": model.id, "label": model.label, "rank": model.rank,
                 "cost_rank": model.cost_rank, "reasoning": model.reasoning}
                for model in discovery.models
                if model.enabled and model.provider == upstream
                and model.job == "chat" and "text" in model.modalities
            ]
        return {"providers": providers}

    async def _require_paid_capacity(self) -> None:
        cap = int(getattr(self.settings, "relay_daily_request_cap", 0) or 0)
        if cap <= 0:
            return
        row = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM usage_log "
            "WHERE (event LIKE 'relay:%' OR event LIKE 'expert:%') "
            "AND ts >= date('now')"
        )
        if int(row["n"] if row else 0) >= cap:
            raise ExpertError("daily Relay request cap reached")

    async def ask(self, provider: str, query: object, model: object = "auto") -> dict:
        if provider not in _PROVIDERS:
            raise ExpertError("unknown expert provider")
        text = str(query or "").strip()
        if not text:
            raise ExpertError("query must not be blank")
        if len(text) > MAX_QUERY_CHARS:
            raise ExpertError(f"query must be at most {MAX_QUERY_CHARS} characters")
        if contains_supplied_secret(text):
            raise ExpertError("query appears to contain a secret or private device identifier")
        _, enabled_key, preferred_key, list_key = _PROVIDERS[provider]
        if not bool(getattr(self.settings, enabled_key, False)):
            raise ExpertError(f"{provider} expert is disabled")
        requested = str(model or "auto").strip() or "auto"
        client = await self._client()
        discovery = await client.discover_models()
        choices = select_expert_models(
            discovery.models, provider, list(getattr(self.settings, list_key, []) or []),
            str(getattr(self.settings, preferred_key, "") or ""), requested, text,
        )
        if not choices:
            raise ExpertError("no enabled discovered text model matches that expert")
        last_error = None
        for choice in choices:
            await self._require_paid_capacity()
            # Record the paid attempt before network dispatch. This both avoids
            # undercounting cancellation/unexpected failures and lets the cap
            # stop a fallback after the preceding paid attempt.
            await self.db.usage(
                None, f"expert:{provider}", f"attempt model={choice.id}"
            )
            try:
                data = await asyncio.wait_for(
                    client.ask(
                        [{"role": "user", "content": text}], [], choice.id,
                        max_tokens=MAX_TOKENS,
                        reasoning_effort=str(
                            getattr(self.settings, "expert_reasoning", "max")
                        ),
                    ),
                    timeout=TIMEOUT_SECONDS,
                )
                reply = str(data.get("reply") or "").strip()
                if not reply:
                    raise RelayError("the expert returned an empty reply")
                reply = "".join(
                    char for char in reply
                    if char in "\n\t" or ord(char) >= 32
                )[:MAX_REPLY_CHARS]
                return {"provider": provider, "model": choice.id, "reply": reply}
            except (RelayError, asyncio.TimeoutError) as exc:
                last_error = exc
        raise ExpertError(f"expert consultation failed: {last_error}")