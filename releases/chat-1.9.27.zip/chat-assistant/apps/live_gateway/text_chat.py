"""Durable typed conversations through the owner's authenticated relay.

The dashboard writes both halves of a turn before starting network work. A
per-conversation worker then finishes pending replies in the background, so a
page navigation or a phone going to sleep does not throw the conversation
away. ``request_id`` is unique per conversation/role and makes browser
retries harmless.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import inspect
import re
import secrets
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from apps.live_gateway.context import AssistantContextBuilder
from apps.live_gateway.prompts import typed_system_instructions
from apps.live_gateway.openai_text_brain import (
    NoOpenAITextCredential,
    OpenAITextBrain,
)
from apps.live_gateway.relay_session import (
    to_chat_tools,
)
from chat_core.models.credentials import CredentialStore, utcnow
from chat_core.models.db import Database
from integrations.relay.client import RelayClient, RelayError, classify_turn, select_models
from integrations.openai_text import OpenAITextError

log = logging.getLogger("text_chat")

HISTORY_LIMIT = 24
MAX_TOOL_HOPS = 4
MAX_MESSAGE_CHARS = 8_000
MAX_CONVERSATION_TITLE_CHARS = 120
MAX_IMAGE_FILES = 4
MAX_IMAGE_BYTES = 8 * 1024 * 1024
MAX_IMAGE_BYTES_PER_TURN = 12 * 1024 * 1024
MAX_HISTORY_IMAGE_FILES = 4
MAX_HISTORY_IMAGE_BYTES = 16 * 1024 * 1024

_ID_RE = re.compile(r"^[A-Za-z0-9._~-]{1,128}$")
_IMAGE_EXTENSIONS = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
}


class TextChatError(Exception):
    """A safe message that may be shown in the dashboard."""


@dataclass(frozen=True)
class PreparedAttachment:
    id: str
    original_name: str
    mime_type: str
    byte_size: int
    sha256: str
    storage_path: str


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _detected_image_type(data: bytes) -> str | None:
    """Recognize the small, non-executable raster allowlist by magic bytes."""
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


class TextChatService:
    def __init__(
        self,
        settings,
        db: Database,
        store: CredentialStore,
        tool_declarations: list[dict],
        tool_handler,
    ) -> None:
        self.settings = settings
        self.db = db
        self.store = store
        self.tools = to_chat_tools(tool_declarations)
        self.tool_handler = tool_handler
        self.context_builder = AssistantContextBuilder(db)
        self.openai_brain: OpenAITextBrain | None = OpenAITextBrain(
            settings, db, store, tool_declarations, tool_handler
        )
        self._ready = False
        self._ready_lock = asyncio.Lock()
        self._start_lock = asyncio.Lock()
        self._conversation_locks: dict[str, asyncio.Lock] = {}
        self._workers: dict[str, asyncio.Task] = {}
        self._turn_events: dict[tuple[str, str], asyncio.Event] = {}

    def update_tool_declarations(self, declarations: list[dict]) -> None:
        """Apply schemas to the next typed turn without restarting workers."""
        self.tools = to_chat_tools(declarations)
        if self.openai_brain is not None:
            self.openai_brain.update_tool_declarations(declarations)

    @property
    def upload_root(self) -> Path:
        return Path(self.settings.data_path) / "chat_uploads"

    async def _ensure_ready(self) -> None:
        if self._ready:
            return
        async with self._ready_lock:
            if self._ready:
                return
            # Never replay a request after restart: a tool action may already
            # have happened just before the old process stopped.
            now = _now()
            await self.db.execute(
                "UPDATE chat_messages SET status='error', "
                "content='This reply was interrupted when Jarvis stopped. Please send it again.', "
                "error='interrupted by restart', updated_at=? "
                "WHERE role='assistant' AND status='pending'",
                (now,),
            )
            self._ready = True

    async def stop(self) -> None:
        """Stop background turns cleanly before the shared database closes."""
        workers = list(self._workers.values())
        self._workers.clear()
        for worker in workers:
            worker.cancel()
        if workers:
            await asyncio.gather(*workers, return_exceptions=True)
        now = _now()
        await self.db.execute(
            "UPDATE chat_messages SET status='error', "
            "content='This reply was interrupted when Jarvis stopped. Please send it again.', "
            "error='interrupted by shutdown', updated_at=? "
            "WHERE role='assistant' AND status='pending'",
            (now,),
        )
        for event in self._turn_events.values():
            event.set()

    async def _client(self) -> RelayClient:
        url = str(getattr(self.settings, "relay_url", "") or "").strip()
        if not url:
            raise TextChatError("Set the Relay address in Settings -> Brain first.")
        creds = [
            c for c in await self.store.list(provider="relay")
            if c.status not in ("invalid", "disabled")
            and not (c.retry_after and c.retry_after > utcnow())
        ]
        if not creds:
            raise TextChatError("Save the Relay password on the Providers page first.")
        try:
            password = await self.store.get_secret(creds[0].id)
        except KeyError as exc:
            raise TextChatError("The saved Relay password could not be unlocked.") from exc
        return RelayClient(url, password)

    async def _require_spend(self) -> None:
        cap = int(getattr(self.settings, "relay_daily_request_cap", 0) or 0)
        if cap <= 0:
            return
        row = await self.db.fetchone(
            "SELECT COUNT(*) AS n FROM usage_log "
            "WHERE event LIKE 'relay:%' AND ts >= date('now')"
        )
        if row and row["n"] >= cap:
            raise TextChatError("The daily Relay request limit has been reached.")

    # -- conversations -------------------------------------------------
    @staticmethod
    def _clean_title(title: str | None, fallback: str = "New chat") -> str:
        clean = " ".join(str(title or "").split()).strip()
        return (clean or fallback)[:MAX_CONVERSATION_TITLE_CHARS]

    async def create_conversation(
        self, title: str | None = None, *, conversation_id: str | None = None
    ) -> dict:
        await self._ensure_ready()
        if conversation_id is not None and not _ID_RE.fullmatch(conversation_id):
            raise TextChatError("That conversation ID is invalid.")
        conversation_id = conversation_id or secrets.token_urlsafe(18)
        now = _now()
        await self.db.execute(
            "INSERT OR IGNORE INTO chat_conversations "
            "(id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (conversation_id, self._clean_title(title), now, now),
        )
        row = await self.db.fetchone(
            "SELECT id, title, created_at, updated_at FROM chat_conversations WHERE id=?",
            (conversation_id,),
        )
        assert row is not None
        return dict(row)

    async def list_conversations(self, limit: int = 100) -> list[dict]:
        await self._ensure_ready()
        limit = max(1, min(int(limit), 200))
        rows = await self.db.fetchall(
            "SELECT c.id, c.title, c.created_at, c.updated_at, "
            "(SELECT COUNT(*) FROM chat_messages m "
            " WHERE m.conversation_id=c.id) AS message_count, "
            "COALESCE((SELECT m.content FROM chat_messages m "
            " WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1), '') AS last_message, "
            "EXISTS(SELECT 1 FROM chat_messages m WHERE m.conversation_id=c.id "
            " AND m.role='assistant' AND m.status='pending') AS pending "
            "FROM chat_conversations c "
            "ORDER BY c.updated_at DESC, c.id DESC LIMIT ?",
            (limit,),
        )
        return [
            {
                **dict(row),
                "message_count": int(row["message_count"]),
                "pending": bool(row["pending"]),
            }
            for row in rows
        ]

    async def get_conversation(self, conversation_id: str) -> dict | None:
        await self._ensure_ready()
        row = await self.db.fetchone(
            "SELECT id, title, created_at, updated_at FROM chat_conversations WHERE id=?",
            (conversation_id,),
        )
        if row is None:
            return None
        messages = await self.db.fetchall(
            "SELECT id, conversation_id, request_id, role, content, status, model, error, "
            "created_at, updated_at FROM chat_messages WHERE conversation_id=? ORDER BY id",
            (conversation_id,),
        )
        attachments = await self.db.fetchall(
            "SELECT a.id, a.message_id, a.original_name, a.mime_type, a.byte_size, "
            "a.sha256, a.created_at FROM chat_attachments a "
            "JOIN chat_messages m ON m.id=a.message_id "
            "WHERE m.conversation_id=? ORDER BY a.created_at, a.id",
            (conversation_id,),
        )
        by_message: dict[int, list[dict]] = {}
        for attachment in attachments:
            item = dict(attachment)
            item["url"] = f"/api/chat/attachments/{item['id']}"
            by_message.setdefault(int(item.pop("message_id")), []).append(item)
        result = dict(row)
        result["messages"] = [
            {**dict(message), "attachments": by_message.get(int(message["id"]), [])}
            for message in messages
        ]
        return result

    async def rename_conversation(self, conversation_id: str, title: str) -> dict | None:
        await self._ensure_ready()
        clean = self._clean_title(title, "")
        if not clean:
            raise TextChatError("Give the conversation a title first.")
        changed = await self.db.execute(
            "UPDATE chat_conversations SET title=?, updated_at=? WHERE id=?",
            (clean, _now(), conversation_id),
        )
        if not changed:
            return None
        row = await self.db.fetchone(
            "SELECT id, title, created_at, updated_at FROM chat_conversations WHERE id=?",
            (conversation_id,),
        )
        return dict(row) if row else None

    async def delete_conversation(self, conversation_id: str) -> bool:
        await self._ensure_ready()
        paths = await self.db.fetchall(
            "SELECT a.storage_path FROM chat_attachments a "
            "JOIN chat_messages m ON m.id=a.message_id WHERE m.conversation_id=?",
            (conversation_id,),
        )
        changed = await self.db.execute(
            "DELETE FROM chat_conversations WHERE id=?", (conversation_id,)
        )
        if not changed:
            return False
        root = self.upload_root.resolve()
        for row in paths:
            try:
                path = Path(row["storage_path"]).resolve()
                if path.parent == root:
                    path.unlink(missing_ok=True)
            except OSError:
                log.warning("could not remove deleted chat attachment", exc_info=True)
        worker = self._workers.pop(conversation_id, None)
        if worker is not None:
            worker.cancel()
        self._conversation_locks.pop(conversation_id, None)
        for key in [key for key in self._turn_events if key[0] == conversation_id]:
            self._turn_events.pop(key, None)
        return True

    # -- image attachments --------------------------------------------
    def _validated_attachment(
        self, filename: str, declared_type: str, data: bytes
    ) -> tuple[str, str, bytes]:
        if not data:
            raise TextChatError("That image is empty.")
        if len(data) > MAX_IMAGE_BYTES:
            raise TextChatError("Each image can be at most 8 MB.")
        actual_type = _detected_image_type(data)
        if actual_type is None:
            raise TextChatError("Use a JPEG, PNG, WebP, or GIF image.")
        declared_type = str(declared_type or "").lower().split(";", 1)[0].strip()
        if declared_type and declared_type not in _IMAGE_EXTENSIONS and declared_type != "image/jpg":
            raise TextChatError("Use a JPEG, PNG, WebP, or GIF image.")
        if declared_type and declared_type != actual_type:
            if not (declared_type == "image/jpg" and actual_type == "image/jpeg"):
                raise TextChatError("The selected file does not match its image type.")
        leaf = Path(str(filename or "image").replace("\\", "/")).name
        leaf = re.sub(r"[^A-Za-z0-9._ -]+", "_", leaf).strip(" .") or "image"
        return leaf[:160], actual_type, data

    async def store_attachments(
        self, files: list[tuple[str, str, bytes]]
    ) -> list[PreparedAttachment]:
        if len(files) > MAX_IMAGE_FILES:
            raise TextChatError("Attach at most four images to one message.")
        if sum(len(data) for _, _, data in files) > MAX_IMAGE_BYTES_PER_TURN:
            raise TextChatError("Images in one message can total at most 12 MB.")
        validated = [self._validated_attachment(*item) for item in files]
        if not validated:
            return []
        root = self.upload_root
        await asyncio.to_thread(root.mkdir, parents=True, exist_ok=True)
        prepared: list[PreparedAttachment] = []
        try:
            for original_name, mime_type, data in validated:
                attachment_id = secrets.token_urlsafe(18)
                path = root / f"{attachment_id}{_IMAGE_EXTENSIONS[mime_type]}"
                await asyncio.to_thread(path.write_bytes, data)
                prepared.append(PreparedAttachment(
                    id=attachment_id,
                    original_name=original_name,
                    mime_type=mime_type,
                    byte_size=len(data),
                    sha256=hashlib.sha256(data).hexdigest(),
                    storage_path=str(path.resolve()),
                ))
        except Exception:
            await self._discard_attachments(prepared)
            raise
        return prepared

    async def _discard_attachments(self, attachments: list[PreparedAttachment]) -> None:
        for attachment in attachments:
            try:
                await asyncio.to_thread(Path(attachment.storage_path).unlink, missing_ok=True)
            except OSError:
                log.warning("could not remove unused chat attachment", exc_info=True)

    async def attachment_file(self, attachment_id: str) -> tuple[Path, str] | None:
        await self._ensure_ready()
        row = await self.db.fetchone(
            "SELECT storage_path, mime_type FROM chat_attachments WHERE id=?", (attachment_id,)
        )
        if row is None:
            return None
        root = self.upload_root.resolve()
        path = Path(row["storage_path"]).resolve()
        if path.parent != root or not path.is_file():
            return None
        return path, str(row["mime_type"])

    # -- durable turns -------------------------------------------------
    async def start_turn(
        self,
        text: str,
        conversation_id: str | None = None,
        request_id: str | None = None,
        attachments: list[PreparedAttachment] | None = None,
    ) -> dict:
        await self._ensure_ready()
        text = str(text or "").strip()
        attachments = list(attachments or [])
        if not text and not attachments:
            raise TextChatError("Type a message or attach an image first.")
        if len(text) > MAX_MESSAGE_CHARS:
            await self._discard_attachments(attachments)
            raise TextChatError(f"Messages can be at most {MAX_MESSAGE_CHARS:,} characters.")
        request_id = str(request_id or "").strip() or secrets.token_urlsafe(18)
        if not _ID_RE.fullmatch(request_id):
            await self._discard_attachments(attachments)
            raise TextChatError("That request ID is invalid.")

        if conversation_id is None:
            seed = text or (f"Image: {attachments[0].original_name}" if attachments else "New chat")
            try:
                conversation = await self.create_conversation(self._clean_title(seed)[:72])
            except Exception:
                await self._discard_attachments(attachments)
                raise
            conversation_id = conversation["id"]
        elif await self.db.fetchone(
            "SELECT 1 FROM chat_conversations WHERE id=?", (conversation_id,)
        ) is None:
            await self._discard_attachments(attachments)
            raise TextChatError("That conversation no longer exists.")

        async with self._start_lock:
            existing = await self._get_turn(conversation_id, request_id)
            if existing is not None:
                await self._discard_attachments(attachments)
                self._ensure_worker_locked(conversation_id)
                return existing

            now = _now()
            try:
                await self.db.execute(
                    "INSERT INTO chat_messages "
                    "(conversation_id, request_id, role, content, status, created_at, updated_at) "
                    "VALUES (?, ?, 'user', ?, 'completed', ?, ?)",
                    (conversation_id, request_id, text, now, now),
                )
                user = await self.db.fetchone(
                    "SELECT id FROM chat_messages WHERE conversation_id=? AND request_id=? "
                    "AND role='user'",
                    (conversation_id, request_id),
                )
                assert user is not None
                for attachment in attachments:
                    await self.db.execute(
                        "INSERT INTO chat_attachments "
                        "(id, message_id, original_name, mime_type, byte_size, sha256, "
                        "storage_path, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            attachment.id, int(user["id"]), attachment.original_name,
                            attachment.mime_type, attachment.byte_size, attachment.sha256,
                            attachment.storage_path, now,
                        ),
                    )
                await self.db.execute(
                    "INSERT INTO chat_messages "
                    "(conversation_id, request_id, role, content, status, created_at, updated_at) "
                    "VALUES (?, ?, 'assistant', '', 'pending', ?, ?)",
                    (conversation_id, request_id, now, now),
                )
                title_seed = self._clean_title(text or f"Image: {attachments[0].original_name}")[:72]
                await self.db.execute(
                    "UPDATE chat_conversations SET "
                    "title=CASE WHEN title='New chat' THEN ? ELSE title END, updated_at=? "
                    "WHERE id=?",
                    (title_seed, now, conversation_id),
                )
            except Exception:
                # Keep a turn all-or-nothing even though the small Database
                # wrapper commits each statement individually.
                await self.db.execute(
                    "DELETE FROM chat_messages WHERE conversation_id=? AND request_id=?",
                    (conversation_id, request_id),
                )
                await self._discard_attachments(attachments)
                raise

            event = self._turn_events.setdefault((conversation_id, request_id), asyncio.Event())
            event.clear()
            self._ensure_worker_locked(conversation_id)
            created = await self._get_turn(conversation_id, request_id)
            assert created is not None
            return created

    def _ensure_worker_locked(self, conversation_id: str) -> None:
        worker = self._workers.get(conversation_id)
        if worker is None or worker.done():
            self._workers[conversation_id] = asyncio.create_task(
                self._drain_conversation(conversation_id),
                name=f"typed-chat-{conversation_id[:12]}",
            )

    async def _drain_conversation(self, conversation_id: str) -> None:
        current = asyncio.current_task()
        try:
            lock = self._conversation_locks.setdefault(conversation_id, asyncio.Lock())
            async with lock:
                while True:
                    pending = await self.db.fetchone(
                        "SELECT id, request_id FROM chat_messages WHERE conversation_id=? "
                        "AND role='assistant' AND status='pending' ORDER BY id LIMIT 1",
                        (conversation_id,),
                    )
                    if pending is None:
                        async with self._start_lock:
                            pending = await self.db.fetchone(
                                "SELECT id, request_id FROM chat_messages WHERE conversation_id=? "
                                "AND role='assistant' AND status='pending' ORDER BY id LIMIT 1",
                                (conversation_id,),
                            )
                            if pending is None:
                                if self._workers.get(conversation_id) is current:
                                    self._workers.pop(conversation_id, None)
                                return
                    await self._process_turn(conversation_id, int(pending["id"]), pending["request_id"])
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("typed conversation worker failed")
        finally:
            async with self._start_lock:
                if self._workers.get(conversation_id) is current:
                    self._workers.pop(conversation_id, None)
                    pending = await self.db.fetchone(
                        "SELECT 1 FROM chat_messages WHERE conversation_id=? "
                        "AND role='assistant' AND status='pending' LIMIT 1",
                        (conversation_id,),
                    )
                    if pending is not None:
                        self._ensure_worker_locked(conversation_id)

    async def _process_turn(
        self, conversation_id: str, assistant_message_id: int, request_id: str
    ) -> None:
        try:
            user = await self.db.fetchone(
                "SELECT content FROM chat_messages WHERE conversation_id=? AND request_id=? "
                "AND role='user'",
                (conversation_id, request_id),
            )
            if user is None:
                raise TextChatError("The matching user message is missing.")
            reply, model = await self._generate_reply(
                conversation_id, assistant_message_id, str(user["content"])
            )
            status, error = "completed", ""
        except asyncio.CancelledError:
            raise
        except TextChatError as exc:
            error = str(exc)
            reply = f"I couldn't finish that reply: {error}"
            model = ""
            status = "error"
        except Exception:
            log.exception("typed chat turn failed")
            error = "An unexpected error stopped this reply."
            reply = error
            model = ""
            status = "error"

        now = _now()
        await self.db.execute(
            "UPDATE chat_messages SET content=?, status=?, model=?, error=?, updated_at=? "
            "WHERE id=? AND status='pending'",
            (reply, status, model, error, now, assistant_message_id),
        )
        await self.db.execute(
            "UPDATE chat_conversations SET updated_at=? WHERE id=?", (now, conversation_id)
        )
        self._turn_events.setdefault((conversation_id, request_id), asyncio.Event()).set()

    async def _provider_content(
        self, message_id: int, text: str, image_budget: dict[str, int]
    ) -> str | list[dict]:
        attachments = await self.db.fetchall(
            "SELECT mime_type, byte_size, storage_path FROM chat_attachments WHERE message_id=? "
            "ORDER BY created_at, id",
            (message_id,),
        )
        if not attachments:
            return text
        image_parts: list[dict] = []
        skipped = 0
        root = self.upload_root.resolve()
        for attachment in attachments:
            size = int(attachment["byte_size"])
            if (image_budget["files"] >= MAX_HISTORY_IMAGE_FILES
                    or image_budget["bytes"] + size > MAX_HISTORY_IMAGE_BYTES):
                skipped += 1
                continue
            path = Path(attachment["storage_path"]).resolve()
            if path.parent != root or not path.is_file():
                skipped += 1
                continue
            data = await asyncio.to_thread(path.read_bytes)
            if image_budget["bytes"] + len(data) > MAX_HISTORY_IMAGE_BYTES:
                skipped += 1
                continue
            image_budget["files"] += 1
            image_budget["bytes"] += len(data)
            encoded = base64.b64encode(data).decode("ascii")
            image_parts.append({
                "type": "image_url",
                "image_url": {"url": f"data:{attachment['mime_type']};base64,{encoded}"},
            })
        label = text or "Describe this image."
        if skipped:
            label += f"\n[{skipped} older attached image(s) omitted from this request.]"
        if not image_parts:
            return label
        return [{"type": "text", "text": label}, *image_parts]

    async def _history_messages(
        self, conversation_id: str, before_assistant_id: int
    ) -> list[dict]:
        rows = await self.db.fetchall(
            "SELECT id, role, content FROM ("
            " SELECT id, role, content FROM chat_messages WHERE conversation_id=? AND id<? "
            " AND (role='user' OR (role='assistant' AND status='completed')) "
            " ORDER BY id DESC LIMIT ?"
            ") ORDER BY id",
            (conversation_id, before_assistant_id, HISTORY_LIMIT),
        )
        # Allocate the bounded image budget newest-first, then restore normal
        # chronological message order for the model.
        newest_first: list[dict] = []
        image_budget = {"files": 0, "bytes": 0}
        for row in reversed(rows):
            content = str(row["content"])
            if row["role"] == "user":
                content = await self._provider_content(int(row["id"]), content, image_budget)
            newest_first.append({"role": row["role"], "content": content})
        return list(reversed(newest_first))

    async def _generate_reply(
        self, conversation_id: str, assistant_message_id: int, current_text: str
    ) -> tuple[str, str]:
        provider = str(
            getattr(self.settings, "typed_chat_provider", "openai") or ""
        ).strip().lower()
        history = await self._history_messages(conversation_id, assistant_message_id)
        context = (await self.context_builder.for_typed_turn(current_text)).text

        if provider == "openai":
            model = str(
                getattr(self.settings, "openai_text_model", "gpt-5-mini") or ""
            ).strip()
            if self.openai_brain is None:
                raise TextChatError(
                    "The OpenAI typed-chat provider is unavailable. Restart Jarvis, "
                    "or choose Relay in Settings."
                )
            try:
                parameters = inspect.signature(self.openai_brain.ask).parameters
                supports_context = (
                    "context" in parameters
                    or any(
                        parameter.kind in (
                            inspect.Parameter.VAR_POSITIONAL,
                            inspect.Parameter.VAR_KEYWORD,
                        )
                        for parameter in parameters.values()
                    )
                )
                if supports_context:
                    return await self.openai_brain.ask(history, model, context)
                # Preserve compatibility with injected/custom legacy brains
                # without swallowing a TypeError raised inside their method.
                return await self.openai_brain.ask(history, model)
            except NoOpenAITextCredential as exc:
                raise TextChatError(str(exc)) from exc
            except OpenAITextError as exc:
                raise TextChatError(str(exc)) from exc

        if provider != "relay":
            raise TextChatError(
                "Choose OpenAI or Relay as the typed-chat provider in Settings."
            )
        if any(isinstance(message.get("content"), list) for message in history):
            raise TextChatError(
                "Image questions require the OpenAI typed-chat provider. "
                "Choose OpenAI in Settings and save an OpenAI API key on Providers."
            )

        client = await self._client()
        if hasattr(client, "discover_models"):
            try:
                route = select_models(
                    await client.discover_models(),
                    current_text,
                    needs_tools=bool(self.tools),
                    configured_command=self.settings.relay_command_model,
                    configured_chat=self.settings.relay_chat_model,
                )
            except RelayError as exc:
                raise TextChatError(str(exc)) from exc
            if not route:
                raise TextChatError("The Relay advertises no compatible text model.")
        else:
            # Compatibility with custom clients; the relay remains the final
            # authority and substitutes its own default for unknown IDs.
            route = [
                self.settings.relay_command_model
                if classify_turn(current_text) == "command"
                else self.settings.relay_chat_model
            ]
        route_index = 0
        model = route[route_index]
        emit = getattr(client, "emit_event", None)
        if emit:
            emit({"event": "model", "classification": classify_turn(current_text),
                  "model": model, "fallbacks": route[1:], "duration_ms": 0.0})
        messages = [{
            "role": "system",
            "content": typed_system_instructions(self.settings.system_prompt, context),
        }, *history]

        for _ in range(MAX_TOOL_HOPS):
            while True:
                pending = await self.db.fetchone(
                    "SELECT 1 FROM chat_messages WHERE id=? AND status='pending'",
                    (assistant_message_id,),
                )
                if pending is None:
                    raise TextChatError("This reply is no longer pending.")
                await self._require_spend()
                try:
                    data = await client.ask(messages, self.tools, model, max_tokens=2400)
                    break
                except RelayError as exc:
                    route_index += 1
                    if route_index >= len(route):
                        raise TextChatError(str(exc)) from exc
                    model = route[route_index]

            usage = data.get("usage") or {}
            used_model = str(data.get("model") or model)
            await self.db.usage(
                None,
                "relay:ask",
                f"typed {used_model} in={usage.get('prompt_tokens', '?')} "
                f"out={usage.get('completion_tokens', '?')}",
            )
            calls = data.get("tool_calls") or []
            reply = str(data.get("reply") or "").strip()
            if not calls:
                return reply or "I couldn't produce an answer. Please try that again.", used_model

            messages.append({
                "role": "assistant", "content": reply or None, "tool_calls": calls,
            })
            for call in calls:
                pending = await self.db.fetchone(
                    "SELECT 1 FROM chat_messages WHERE id=? AND status='pending'",
                    (assistant_message_id,),
                )
                if pending is None:
                    raise TextChatError("This reply is no longer pending.")
                fn = call.get("function") or {}
                call_id = str(call.get("id", ""))
                name = str(fn.get("name", ""))
                try:
                    args = json.loads(fn.get("arguments") or "{}")
                except (TypeError, ValueError):
                    args = {}
                tool_started = time.monotonic()
                try:
                    result = await self.tool_handler(call_id, name, args)
                finally:
                    if emit:
                        emit({
                            "event": "tool", "tool": name,
                            "duration_ms": round(
                                (time.monotonic() - tool_started) * 1000, 1
                            ),
                        })
                messages.append({
                    "role": "tool",
                    "tool_call_id": call_id,
                    "content": json.dumps(result),
                })

        return "I got stuck while using a tool. Please try that request again.", model

    async def _get_turn(self, conversation_id: str, request_id: str) -> dict | None:
        rows = await self.db.fetchall(
            "SELECT id, conversation_id, request_id, role, content, status, model, error, "
            "created_at, updated_at FROM chat_messages WHERE conversation_id=? "
            "AND request_id=? ORDER BY id",
            (conversation_id, request_id),
        )
        if not rows:
            return None
        messages = [dict(row) for row in rows]
        assistant = next((row for row in messages if row["role"] == "assistant"), None)
        return {
            "conversation_id": conversation_id,
            "request_id": request_id,
            "status": assistant["status"] if assistant else "pending",
            "messages": messages,
        }

    async def get_turn(self, conversation_id: str, request_id: str) -> dict | None:
        await self._ensure_ready()
        return await self._get_turn(conversation_id, request_id)

    async def wait_turn(self, conversation_id: str, request_id: str) -> dict:
        turn = await self.get_turn(conversation_id, request_id)
        if turn is None:
            raise TextChatError("That chat request was not found.")
        if turn["status"] == "pending":
            event = self._turn_events.setdefault((conversation_id, request_id), asyncio.Event())
            async with self._start_lock:
                self._ensure_worker_locked(conversation_id)
            await event.wait()
            turn = await self._get_turn(conversation_id, request_id)
            assert turn is not None
        return turn

    # Compatibility for the original synchronous /api/chat endpoint.
    async def ask(self, text: str, conversation_id: str | None = None) -> dict:
        if conversation_id and await self.db.fetchone(
            "SELECT 1 FROM chat_conversations WHERE id=?", (conversation_id,)
        ) is None:
            await self.create_conversation(conversation_id=conversation_id)
        turn = await self.start_turn(text, conversation_id)
        finished = await self.wait_turn(turn["conversation_id"], turn["request_id"])
        assistant = next(
            message for message in finished["messages"] if message["role"] == "assistant"
        )
        if assistant["status"] == "error":
            raise TextChatError(assistant["error"] or assistant["content"])
        return {
            "conversation_id": finished["conversation_id"],
            "reply": assistant["content"],
            "model": assistant["model"],
        }

    async def clear(self, conversation_id: str | None) -> None:
        if conversation_id:
            await self.delete_conversation(conversation_id)
