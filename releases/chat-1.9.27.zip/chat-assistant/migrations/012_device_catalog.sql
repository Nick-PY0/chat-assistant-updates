-- Durable, user-editable device names. Provider command identifiers are kept
-- private in this table and are never returned by the public catalog API.
CREATE TABLE IF NOT EXISTS device_catalog (
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    provider_identity TEXT NOT NULL,
    provider_sku TEXT NOT NULL,
    canonical_name TEXT NOT NULL,
    aliases_json TEXT NOT NULL DEFAULT '[]',
    room TEXT,
    enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
    capabilities_json TEXT NOT NULL DEFAULT '[]',
    last_seen TEXT,
    stale INTEGER NOT NULL DEFAULT 0 CHECK(stale IN (0,1)),
    UNIQUE(provider, provider_identity)
);
CREATE INDEX IF NOT EXISTS device_catalog_provider
ON device_catalog(provider, enabled, stale);