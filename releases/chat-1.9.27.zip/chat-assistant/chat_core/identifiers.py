"""Shared normalization for identifiers that must never become display data."""

from __future__ import annotations

import unicodedata


def provider_secret_key(value: object) -> str:
    """Return a compatibility-, case-, and separator-insensitive collision key."""
    normalized = unicodedata.normalize("NFKC", str(value)).casefold()
    return "".join(character for character in normalized if character.isalnum())