"""Runtime wiring: builds every service and connects them.

Everything runs inside ONE low-priority asyncio process by default, which
keeps the footprint tiny (the "as light as possible" requirement). The
architecture still keeps audio isolated: audio bytes move only through
dedicated bounded queues and the audio callbacks never touch the DB, the
network, or the event bus.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from tzlocal import get_localzone_name

from chat_core.config import Settings
from chat_core.events import EventBus
from chat_core.logging_setup import setup_logging
from chat_core.models.credentials import CredentialStore
from chat_core.models.db import Database
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.keychain import MasterSecret
from chat_core.security.vault import Vault
from apps.audio.announcements import Announcer
from apps.audio.broadcast import RATE as BROADCAST_RATE, AudioBroadcast, resample_pcm16
from apps.audio.engine import AudioEngine
from apps.audio.stt import build_transcriber
from apps.live_gateway.gateway import LiveGateway
from apps.live_gateway.remote_voice import RemoteVoiceService
from apps.live_gateway.text_chat import TextChatService
from apps.pulse.pulse import Pulse
from apps.tool_service.local_grammar import parse as parse_local
from apps.tool_service.reminders import ReminderManager
from apps.tool_service.routines import RoutineManager
from apps.tool_service.schemas import online_tool_declarations
from apps.tool_service.service import ToolService
from apps.tool_service.timers import TimerManager
from apps.tool_service.weather_tool import WeatherTool
from apps.tool_service.web_tool import WebResearchTool
from apps.tool_service.youtube_tool import YouTubeTool
from apps.tool_service.companion_bridge import CompanionBridge
from apps.tool_service.calendar_tool import CalendarManager
from apps.tool_service.briefing_scheduler import CalendarScheduler
from apps.updater.updater import Updater
from chat_core.models.google_account import GoogleAccountStore
from chat_core.models.spotify_account import SpotifyAccountStore
from chat_core.models.music import MusicStore
from chat_core.music import LocalMusicLibrary
from integrations.google_calendar import GoogleCalendarClient
from integrations.spotify import SpotifyClient
from integrations.lg_webos import WebOSManager
from apps.tool_service.music_tool import MusicTool
from apps.tool_service.expert_tool import ExpertRelayService

log = logging.getLogger("runtime")

RESTART_EXIT_CODE = 42  # run_chat.bat relaunches on this code


class Runtime:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.bus = EventBus()
        self.db = Database(settings.db_path)
        self.state = StateMachine(self.bus)
        self.master = MasterSecret(settings.data_path)
        self.vault: Vault | None = None
        self.store: CredentialStore | None = None
        self.timers: TimerManager | None = None
        self.reminders: ReminderManager | None = None
        self.routines: RoutineManager | None = None
        self.google_account: GoogleAccountStore | None = None
        self.google_calendar: GoogleCalendarClient | None = None
        self.spotify_account: SpotifyAccountStore | None = None
        self.spotify: SpotifyClient | None = None
        self.music_store: MusicStore | None = None
        self.local_music: LocalMusicLibrary | None = None
        self.music: MusicTool | None = None
        self.calendar: CalendarManager | None = None
        self.calendar_scheduler: CalendarScheduler | None = None
        self.weather_tool: WeatherTool | None = None
        self.web_tool: WebResearchTool | None = None
        self.youtube_tools: YouTubeTool | None = None
        self.companion: CompanionBridge | None = None
        # Loopback port of the dedicated companion bridge server, set by
        # run_chat once it is listening.  None = not running.
        self.companion_bridge_port: int | None = None
        self.tools: ToolService | None = None
        self.tv: WebOSManager | None = None
        self._media_playing = False
        self._media_sources: dict[str, bool] = {}
        self.text_chat: TextChatService | None = None
        self.gateway: LiveGateway | None = None
        self.remote_voice: RemoteVoiceService | None = None
        self.audio: AudioEngine | None = None
        self.pulse: Pulse | None = None
        self.updater: Updater | None = None
        self.announcer = Announcer()
        self.broadcast = AudioBroadcast()  # dashboard/phone audio listeners
        # Typed announce-only stream (alarms/announcements, never host
        # conversation speech) — the remote-voice service forwards THIS to
        # phones, so a queued host-speech tail can never leak to a remote
        # device the way it could when remotes tapped the shared broadcast.
        self.announce_broadcast = AudioBroadcast()
        self.transcriber = None
        # handle_local_utterance is the host AudioEngine callback only.
        # Remote/cloud/typed flows must carry the explicit random draft id.
        self._host_calendar_draft_id: str | None = None
        self.started_at = time.time()
        self.restart_exit_code = 0
        self.on_uvicorn_exit = None  # set by run_chat: asks the server to stop
        self._voice_flag = False
        self._audio_task: asyncio.Task | None = None
        self._pump_task: asyncio.Task | None = None
        self._reload_lock = asyncio.Lock()
        self._reload_task: asyncio.Task | None = None
        self._tasks: list[asyncio.Task] = []
        self._announce_cooldowns: dict[str, float] = {}
        self.quiet = False
        self.ringing: dict | None = None  # reminder currently ringing (dashboard)
        self._ring_task: asyncio.Task | None = None
        self._ring_stop = asyncio.Event()
        self._ring_pending: list[dict] = []  # reminders that came due mid-ring
        self._ring_dismissed = False  # True only when explicitly dismissed (not on process stop)

    async def refresh_online_tool_declarations(self) -> dict:
        """Apply expert policy live and recycle schema-caching voice sessions."""
        declarations = online_tool_declarations(self.settings)
        if self.text_chat is not None:
            self.text_chat.update_tool_declarations(declarations)
        reconnecting = []
        if self.gateway is not None:
            if await self.gateway.update_tool_declarations(declarations):
                reconnecting.append("host_voice")
        if self.remote_voice is not None:
            if await self.remote_voice.gateway.update_tool_declarations(declarations):
                reconnecting.append("remote_voice")
        return {
            "applied": True,
            "reconnecting": reconnecting,
            "expert_tools": [
                item["name"] for item in declarations
                if item["name"] in ("ask_chatgpt", "ask_claude")
            ],
        }
    # ------------------------------------------------------------------
    async def start(self, voice: bool = True, cloud: bool = True, monitoring: bool = True) -> None:
        setup_logging(self.settings.log_level if self.settings.low_power else "INFO")
        await self.db.open()
        self.vault = Vault(self.master.load_or_create())
        self.store = CredentialStore(self.db, self.vault)

        self.timers = TimerManager(self.db, self.bus)
        self.reminders = ReminderManager(self.db, self.bus)
        self.weather_tool = WeatherTool(self.settings)
        self.web_tool = WebResearchTool()
        self.google_account = GoogleAccountStore(self.db, self.vault)
        self.google_calendar = GoogleCalendarClient(
            self.google_account, bus=self.bus
        )
        self.spotify_account = SpotifyAccountStore(self.db, self.vault)
        self.spotify = SpotifyClient(self.spotify_account)
        self.music_store = MusicStore(self.db, self.vault)
        self.local_music = LocalMusicLibrary(
            self.db, self.vault, self.music_store
        )
        # tzlocal maps Windows timezone ids to IANA names.  Some minimal
        # containers expose no canonical local name; UTC is honest there.
        local_timezone = get_localzone_name() or "UTC"
        self.calendar = CalendarManager(
            self.db,
            self.google_calendar,
            bus=self.bus,
            default_timezone=local_timezone,
        )
        self.youtube_tools = YouTubeTool(
            self.bus,
            self.store,
            on_playing=lambda playing: self.set_media_playing(
                playing, source="youtube"
            ),
            web_search=self.web_tool.search,
        )
        self.youtube_tools.start_watchdog()
        # Local-only, authenticated companion bridge.  Fenced state events flow
        # back into the tool's own state via _ingest_companion_state.
        self.companion = CompanionBridge(
            self.db,
            self.bus,
            on_state=self.youtube_tools._ingest_companion_state,
        )
        self.youtube_tools.register_companion(self.companion)
        self.music = MusicTool(
            self.db,
            self.bus,
            self.music_store,
            self.youtube_tools,
            spotify=self.spotify,
            local=self.local_music,
            on_playing=lambda playing: self.set_media_playing(
                playing, source="music"
            ),
        )
        await self.music.start()
        # Optional local LG TV control; does nothing until enabled + paired.
        self.tv = WebOSManager(self.db, self.bus, self.vault, self.settings)
        await self.tv.start()
        self.experts = ExpertRelayService(
            self.settings, self.store, self.db,
            client_factory=lambda url, secret, timeout: __import__(
                "integrations.relay.client", fromlist=["RelayClient"]
            ).RelayClient(
                url, secret, timeout=timeout,
                on_event=lambda event: self.bus.publish("timing", **event),
            ),
        )
        online_tools = online_tool_declarations(self.settings)
        self.tools = ToolService(
            self.db, self.bus, self.timers, self.store, on_stop=self.stop_output,
            reminders=self.reminders, weather=self.weather_tool, web=self.web_tool,
            youtube=self.youtube_tools,
            music=self.music,
            tv=self.tv,
            calendar=self.calendar,
            briefing=None,
            routines=None,
            on_quiet=self.set_quiet,
            on_end_session=self.end_voice_session,
            experts=self.experts,
        )
        self.text_chat = TextChatService(
            self.settings, self.db, self.store, online_tools, self.tools.dispatch
        )
        await self.timers.start()
        await self.reminders.start()
        await self._restore_ring()

        muted = (await self.db.get_setting("muted", "0")) == "1"
        self.state.set_muted(muted)
        self.quiet = (await self.db.get_setting("quiet_mode", "0")) == "1"

        self.calendar_scheduler = CalendarScheduler(
            self.db,
            self.google_calendar,
            self._announce_calendar_text,
            bus=self.bus,
            weather=lambda: self.weather_tool.get("today"),
            news=lambda: self.web_tool.news("", 3),
            is_busy=self._calendar_voice_busy,
            is_quiet=lambda: self.quiet,
            default_timezone=local_timezone,
            on_timezone_change=self._set_calendar_timezone,
        )
        calendar_preferences = await self.calendar_scheduler.get_preferences()
        self._set_calendar_timezone(calendar_preferences["timezone"])
        await self.google_calendar.start()
        await self.calendar_scheduler.start()
        self.tools.briefing = self.calendar_scheduler
        self.routines = RoutineManager(
            self.db,
            self.bus,
            self._execute_routine_action,
            announce=self._announce_calendar_text,
            default_timezone=calendar_preferences["timezone"],
        )
        self.tools.routines = self.routines
        await self.routines.start()

        if cloud:
            self.gateway = LiveGateway(
                self.settings, self.db, self.store, self.bus, self.state,
                online_tools, self.tools.dispatch,
            )
            self._tasks.append(asyncio.create_task(self.gateway.run(), name="gateway"))
            # Remote devices (phone/tablet/another computer) get their OWN
            # conversation stack — never a bridge into the host session.
            self.remote_voice = RemoteVoiceService(
                self.settings, self.db, self.store, self.bus,
                online_tools, self.tools.dispatch,
                host_gateway=self.gateway,
                get_audio=lambda: self.audio,
                broadcast=self.announce_broadcast,   # typed: alarms only
                get_youtube=lambda: self.youtube_tools,
                get_companion=lambda: self.companion,
                on_global_stop=self.stop_output,     # host TAKEOVER only
                on_stop_ringing=self.stop_ringing,
                host_state=self.state,
            )
            self.remote_voice.start()

        self._voice_flag = voice
        self._wire_audio(voice)

        if monitoring:
            self.pulse = Pulse(self.settings, self.db, self.store, self.bus, self.state, tv=self.tv)
            self._tasks.append(asyncio.create_task(self.pulse.run(), name="pulse"))

        self.updater = Updater(self.settings, self.db, self.bus)
        self._tasks.append(asyncio.create_task(self.updater.run(), name="updater"))

        self._tasks.append(asyncio.create_task(self._event_pump(), name="event-pump"))
        await self.db.log("INFO", "runtime", "Jarvis started")

    async def stop(self) -> None:
        if self.routines:
            await self.routines.stop()
        if self.calendar_scheduler:
            await self.calendar_scheduler.stop()
        if self.google_calendar:
            await self.google_calendar.stop()
        if self.remote_voice:
            await self.remote_voice.stop()
        if self.gateway:
            await self.gateway.stop()
        if self.text_chat:
            await self.text_chat.stop()
        if self.audio:
            await self.audio.stop()
        if self.pulse:
            await self.pulse.stop()
        if self.updater:
            await self.updater.stop()
        if self.timers:
            await self.timers.stop()
        if self.reminders:
            await self.reminders.stop()
        if self.music is not None:
            await self.music.stop()
        elif self.spotify is not None:
            await self.spotify.close()
        if self.youtube_tools is not None:
            await self.youtube_tools.stop_watchdog()
        if self.tv is not None:
            await self.tv.stop()
        self._ring_stop.set()
        if self._ring_task is not None:
            self._ring_task.cancel()
            await asyncio.gather(self._ring_task, return_exceptions=True)
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        await self.db.log("INFO", "runtime", "Jarvis stopped")
        await self.db.close()

    # -- audio wiring ----------------------------------------------------
    def _wire_audio(self, voice: bool) -> None:
        """Attach the consumer of Gemini's audio output. With voice, that is
        the audio engine (which also feeds phone listeners); without it, a
        tiny pump keeps phone listening working anyway."""
        if self.gateway is None:
            return
        if voice:
            self.transcriber = build_transcriber(self.settings)
            # Wire companion voice-focus callbacks from YouTubeTool.  All three
            # are optional and guarded inside AudioEngine; missing companion
            # makes them no-ops via YouTubeTool's own guards.
            music = self.music
            yt = self.youtube_tools
            self.audio = AudioEngine(
                self.settings, self.bus, self.state,
                self.gateway.audio_in, self.gateway.audio_out,
                on_wake=self._on_host_wake,
                on_interrupt=self.gateway.interrupt,
                broadcast=self.broadcast,
                transcriber=self.transcriber,
                on_local_command=self.handle_local_utterance,
                on_voice_duck=(
                    music.voice_focus_duck if music is not None
                    else (yt.voice_focus_duck if yt is not None else None)
                ),
                on_voice_pause=(
                    music.voice_focus_pause if music is not None
                    else (yt.voice_focus_pause if yt is not None else None)
                ),
                on_voice_restore=(
                    music.voice_focus_restore if music is not None
                    else (yt.voice_focus_restore if yt is not None else None)
                ),
            )
            self.audio.set_media_playing(self._media_playing)
            self.announcer.play_wav_bytes = self._announce_fanout(self.audio.play_wav_bytes)
            if self.remote_voice is not None:
                # A rebuilt engine starts with remote_mic_active=False; an
                # attached remote device must keep exclusive wake ownership
                # or host+remote streams interleave through the wake model.
                self.remote_voice.reapply_wake_ownership()
            self._audio_task = asyncio.create_task(self.audio.run(), name="audio")
            self._tasks.append(self._audio_task)
        else:
            self.announcer.play_wav_bytes = self._announce_fanout(self._broadcast_wav)
            self._pump_task = asyncio.create_task(self._audio_out_pump(), name="audio-pump")
            self._tasks.append(self._pump_task)

    def schedule_audio_reload(self) -> None:
        """Fire-and-forget reload for the dashboard. The task reference is
        kept (an untracked task can be garbage-collected mid-flight) and the
        lock inside reload_audio serializes rapid repeated saves."""
        self._reload_task = asyncio.create_task(self.reload_audio())

    async def reload_audio(self) -> None:
        """Rebuild the audio engine so wake word / device / offline-voice
        setting changes apply without restarting Chat. Serialized: two
        overlapping reloads must not each wire an engine (double audio)."""
        async with self._reload_lock:
            if self.gateway is None:
                return
            if self.audio is not None:
                await self.audio.stop()
            for task in (self._audio_task, self._pump_task):
                if task is not None:
                    task.cancel()
                    await asyncio.gather(task, return_exceptions=True)
                    if task in self._tasks:
                        self._tasks.remove(task)
            self._audio_task = None
            self._pump_task = None
            self.audio = None
            self._wire_audio(self._voice_flag)
            await self.db.log("INFO", "audio", "audio settings applied; engine reloaded")

    async def _audio_out_pump(self) -> None:
        """No audio engine: still drain Gemini audio into the phone stream."""
        assert self.gateway is not None
        while True:
            pcm = await self.gateway.audio_out.get()
            self.broadcast.publish(pcm)

    def _broadcast_wav(self, pcm: bytes, rate: int) -> None:
        """Announcer output when no speaker exists: phone listeners only."""
        if not self.broadcast.has_listeners:
            raise RuntimeError("no listeners")  # announcer falls back to console
        self.broadcast.publish(resample_pcm16(pcm, rate, BROADCAST_RATE))

    def _announce_fanout(self, base):
        """Wrap an announcer sink so announcement PCM ALSO reaches the typed
        announce broadcast (what remote devices hear), without changing the
        base sink's own delivery/failure semantics.

        If the base sink has nobody to play to (dashboard-only mode with no
        shared-broadcast listeners) but a remote device is connected, the
        announcement counts as delivered — the phone heard it."""
        def sink(pcm: bytes, rate: int, *args, **kwargs):
            remote = self.remote_voice
            phone = remote is not None and remote.has_connected_device
            if phone:
                try:
                    self.announce_broadcast.publish(
                        pcm if rate == BROADCAST_RATE
                        else resample_pcm16(pcm, rate, BROADCAST_RATE)
                    )
                except Exception:
                    log.debug("announce fanout failed", exc_info=True)
            try:
                return base(pcm, rate, *args, **kwargs)
            except RuntimeError:
                if not phone:
                    raise  # nobody heard it anywhere -> console fallback
        return sink

    # -- actions ---------------------------------------------------------
    @property
    def media_playing(self) -> bool:
        return self._media_playing

    def set_media_playing(self, playing: bool, *, source: str = "media") -> None:
        """Share audible provider state with the physical microphone gate.

        Provider callbacks are independent and can arrive late.  Track them by
        source so a stale YouTube lease expiry cannot reopen the microphone
        while Spotify or the owned local player is still audibly playing.
        """
        self._media_sources[str(source)] = bool(playing)
        self._media_playing = any(self._media_sources.values())
        if self.audio is not None:
            self.audio.set_media_playing(self._media_playing)

    def _on_host_wake(self) -> None:
        """Host microphone wake: one assistant, one conversation at a time.

        While a remote device owns a live conversation (including its short
        reconnect grace window), the host wake word is ignored instead of
        opening a second competing session. The remote UI offers an explicit
        takeover in the other direction.
        """
        if self.remote_voice is not None and self.remote_voice.conversation_active:
            asyncio.ensure_future(self.db.log(
                "INFO", "gateway",
                "host wake ignored: a remote device conversation is active",
            ))
            return
        if self.gateway is not None:
            self.gateway.request_session()

    def end_voice_session(self) -> None:
        """Voice-tool hook: revoke the hands-free lease before socket close."""
        if self.gateway is not None:
            self.gateway.request_end_session("voice stop command")

    def stop_ringing(self) -> bool:
        """Dismiss a ringing alarm/reminder WITHOUT touching the host
        conversation, host playback, or media.

        This is the ONLY stop a remote device may trigger implicitly ("stop"
        while an alarm rings should work from anywhere) — everything else a
        remote stop silences lives in its own dedicated session.  The
        persistent ring state is cleared via a fire-and-forget coroutine so
        the synchronous call site remains non-blocking.
        Returns True if something was ringing.
        """
        was_ringing = self.ringing is not None
        self._ring_dismissed = True  # mark before setting stop so _ring_runner sees it
        self._ring_stop.set()  # dismisses a ringing alarm/reminder too
        self.ringing = None    # clear in-memory immediately
        if was_ringing:
            # Fire-and-forget DB clear; errors are non-fatal
            asyncio.get_event_loop().create_task(self._clear_ring_db())
            self.bus.publish("reminders_changed")
        self.announce_broadcast.clear()  # remote announce lanes flush instantly
        return was_ringing

    def stop_output(self) -> None:
        """User said stop / pressed the HOST Stop button: silence output NOW.

        This also dismisses a ringing alarm/reminder, interrupts the host
        conversation, and clears host playback.  Remote devices must call
        stop_ringing() instead — their conversation/playback is private.
        """
        self.stop_ringing()
        if self.gateway is not None:
            self.gateway.interrupt()
            while not self.gateway.audio_out.empty():
                try:
                    self.gateway.audio_out.get_nowait()
                except asyncio.QueueEmpty:
                    break
        if self.audio is not None:
            self.audio.clear_playback()  # also clears phone listeners
        else:
            self.broadcast.clear()

    # -- alarm/reminder ringing ------------------------------------------

    # Default snooze duration in seconds (10 minutes).
    SNOOZE_SECONDS: int = 600

    async def _persist_ring(self, data: dict) -> None:
        """Write the current ring to DB so a restart can resume it."""
        from chat_core.models.credentials import iso, utcnow
        await self.db.execute(
            "INSERT INTO active_ring (id, reminder_id, kind, message, started_at, snoozed_until) "
            "VALUES ('current', ?, ?, ?, ?, NULL) "
            "ON CONFLICT(id) DO UPDATE SET "
            "  reminder_id=excluded.reminder_id, kind=excluded.kind, "
            "  message=excluded.message, started_at=excluded.started_at, "
            "  snoozed_until=NULL",
            (
                str(data.get("id") or ""),
                str(data.get("kind") or "reminder"),
                str(data.get("message") or ""),
                iso(utcnow()),
            ),
        )

    async def _clear_ring_db(self) -> None:
        """Remove the persisted ring row (called after dismiss/snooze)."""
        await self.db.execute("DELETE FROM active_ring WHERE id='current'")

    async def _restore_ring(self) -> None:
        """On startup: if a ring was persisted (process crashed mid-ring),
        resume it immediately so the user is not silently left waiting."""
        from chat_core.models.credentials import parse_iso, utcnow
        row = await self.db.fetchone("SELECT * FROM active_ring WHERE id='current'")
        if row is None:
            return
        # If the row has a snoozed_until in the future, wait for it instead
        # of ringing immediately.
        snoozed_until_raw = row["snoozed_until"]
        if snoozed_until_raw:
            snoozed_until = parse_iso(snoozed_until_raw)
            if snoozed_until and snoozed_until > utcnow():
                wait = (snoozed_until - utcnow()).total_seconds()
                await self.db.log(
                    "INFO", "reminders",
                    f"restored snoozed ring for '{row['message'] or row['kind']}'; "
                    f"resuming in {int(wait)}s"
                )
                asyncio.create_task(self._snooze_resume_after(dict(row), wait))
                return
        data = {
            "id": row["reminder_id"],
            "kind": row["kind"],
            "message": row["message"],
        }
        await self.db.log(
            "INFO", "reminders",
            f"resuming ring after restart: {row['message'] or row['kind']}"
        )
        await self._begin_ring(data, _from_restore=True)

    async def _snooze_resume_after(self, row: dict, wait: float) -> None:
        """Fire the snoozed ring once the snooze timer expires."""
        try:
            await asyncio.sleep(max(0.0, wait))
        except asyncio.CancelledError:
            return
        data = {
            "id": row.get("reminder_id", ""),
            "kind": row.get("kind", "reminder"),
            "message": row.get("message", ""),
        }
        await self._begin_ring(data, _from_restore=True)

    async def _begin_ring(self, data: dict, *, _from_restore: bool = False) -> None:
        """A reminder/alarm is due: ring loudly until explicitly dismissed or
        snoozed.  The ring state is written to DB before audio starts so a
        process restart automatically resumes ringing."""
        if self.quiet and not self.settings.quiet_override_alarms:
            await self.db.log("INFO", "reminders", "quiet mode: ring suppressed")
            return
        if self._ring_task is not None and not self._ring_task.done():
            # One ring at a time. This one rings as soon as the current one
            # is dismissed -- like an alarm clock, each needs its own stop.
            self._ring_pending.append(dict(data))
            await self.db.log("INFO", "reminders", "another ring is active; queued")
            return
        self._ring_stop.clear()
        self.ringing = dict(data)  # banner appears immediately
        if not _from_restore:
            await self._persist_ring(data)
        self.bus.publish("reminders_changed")
        self._ring_task = asyncio.create_task(self._ring_runner(dict(data)), name="ring")

    async def snooze_ring(self, minutes: int | None = None) -> bool:
        """Snooze the currently ringing alarm/reminder.

        Persists the snooze deadline to DB so a restart waits for it too.
        Returns True if a ring was snoozed, False if nothing was ringing.
        Idempotent: calling while already snoozed is a no-op (returns False).
        """
        if self.ringing is None or (self._ring_task is not None and self._ring_task.done()):
            return False
        secs = int(minutes * 60) if minutes is not None else self.SNOOZE_SECONDS
        secs = max(60, secs)  # minimum 1-minute snooze

        from chat_core.models.credentials import iso, utcnow
        from datetime import timedelta
        snooze_until = utcnow() + timedelta(seconds=secs)
        data = dict(self.ringing)

        # Update persisted row with snoozed_until before stopping audio
        await self.db.execute(
            "UPDATE active_ring SET snoozed_until=? WHERE id='current'",
            (iso(snooze_until),),
        )

        # Stop audio / current ring loop.
        # We do NOT set _ring_dismissed=True here because the ring row in DB
        # should stay (with snoozed_until set) for restart recovery.
        # _ring_runner's finally will skip _clear_ring_db because _ring_dismissed=False.
        self._ring_stop.set()
        if self._ring_task is not None:
            await asyncio.gather(self._ring_task, return_exceptions=True)
        # ringing is cleared by _ring_runner's finally; ensure it is None
        self.ringing = None
        self.bus.publish("reminders_changed")

        await self.db.log(
            "INFO", "reminders",
            f"snoozed for {secs}s: {data.get('message') or data.get('kind')}"
        )
        # Schedule resume
        asyncio.create_task(self._snooze_resume_after(
            {"reminder_id": data.get("id", ""),
             "kind": data.get("kind", "reminder"),
             "message": data.get("message", "")},
            float(secs),
        ))
        return True

    async def dismiss_ring(self) -> bool:
        """Idempotent: stop the current ring and clear the persisted state.

        Returns True if something was ringing and was dismissed, False if
        nothing was ringing (safe to call multiple times).
        """
        was_ringing = self.ringing is not None
        self._ring_dismissed = True  # mark before stopping so _ring_runner sees it
        self._ring_stop.set()  # no-op if already set
        if self._ring_task is not None and not self._ring_task.done():
            await asyncio.gather(self._ring_task, return_exceptions=True)
        # Clear persisted ring from DB (idempotent; safe if already cleared)
        await self._clear_ring_db()
        self.ringing = None
        if was_ringing:
            self.bus.publish("reminders_changed")
            await self.db.log("INFO", "reminders", "ring dismissed")
        return was_ringing

    async def _ring_runner(self, first: dict) -> None:
        """Ring each due reminder in turn; each needs its own dismissal."""
        data: dict | None = first
        while data is not None:
            self._ring_dismissed = False
            try:
                await self._ring_loop(data)
            finally:
                self.ringing = None
                # Only remove the persisted row if the ring was explicitly
                # dismissed/snoozed (not if the process is shutting down).
                # On process shutdown the row stays so a restart resumes it.
                if self._ring_dismissed:
                    await self._clear_ring_db()
                self.bus.publish("reminders_changed")
            data = self._ring_pending.pop(0) if self._ring_pending else None
            if data is not None:
                self._ring_stop.clear()
                self._ring_dismissed = False
                self.ringing = dict(data)
                await self._persist_ring(data)
                self.bus.publish("reminders_changed")  # banner shows next ring

    async def _ring_loop(self, data: dict) -> None:
        from apps.audio.ring import RING_RATE, build_ring_cycle
        from apps.audio.speak import synth_text

        kind = str(data.get("kind") or "reminder")
        message = str(data.get("message") or "").strip()
        pcm = build_ring_cycle(self.settings.alarm_volume)
        say = message or ("This is your alarm." if kind == "alarm" else "")
        if say and kind != "alarm":
            say = f"Reminder: {say}"
        spoken = await asyncio.to_thread(synth_text, say) if say else None
        # No deadline: ring forever until explicitly stopped/snoozed/dismissed.
        cycles = 0
        try:
            while not self._ring_stop.is_set():
                self._play_alert(pcm, RING_RATE)
                await self._ring_wait(2.05)
                cycles += 1
                if cycles == 2 and not self._ring_stop.is_set():
                    if spoken is not None:
                        self._play_alert(spoken[0], spoken[1])
                        await self._ring_wait(len(spoken[0]) / 2 / max(spoken[1], 1) + 0.4)
                    elif message:
                        # no offline voice; a canned pointer at the dashboard
                        self._announce("reminder_fallback", cooldown=0)
                        await self._ring_wait(4.0)
        finally:
            await self.db.log("INFO", "reminders", f"ring ended: {message or kind}")

    async def _ring_wait(self, seconds: float) -> None:
        with contextlib.suppress(asyncio.TimeoutError):
            await asyncio.wait_for(self._ring_stop.wait(), timeout=seconds)

    def _play_alert(self, pcm: bytes, rate: int) -> None:
        """Alarms ring on the speaker AND phone listeners, whatever the
        configured audio route -- they must be heard."""
        if self.audio is not None:
            self.audio.play_wav_bytes(pcm, rate, force_speaker=True)
        else:
            try:
                self._broadcast_wav(pcm, rate)
            except RuntimeError:
                print("\a[Chat] An alarm or reminder is due -- see the dashboard.")

    async def _speak_dynamic(self, text: str) -> bool:
        """Speak an arbitrary sentence with the offline voice (pyttsx3).
        Returns False when no offline TTS is available."""
        from apps.audio.speak import synth_text

        text = str(text or "").strip()
        if not text:
            return False
        spoken = await asyncio.to_thread(synth_text, text)
        if spoken is None:
            return False
        try:
            self.announcer.play_wav_bytes(spoken[0], spoken[1])
        except Exception:
            return False
        return True

    def _calendar_voice_busy(self) -> bool:
        host_busy = self.state.raw_state in (
            ChatState.CONNECTING,
            ChatState.LISTENING,
            ChatState.SPEAKING,
        )
        remote_busy = bool(
            self.remote_voice is not None and self.remote_voice.conversation_active
        )
        return host_busy or remote_busy

    async def _announce_calendar_text(self, text: str) -> None:
        """Dynamic scheduler speech.  TTS stays off the shared event loop and
        the announcer sink fans out only through the typed announcement lane."""
        if self.quiet:
            return
        if not await self._speak_dynamic(text):
            self.announcer.announce(text)

    async def _execute_routine_action(self, name: str, args: dict) -> dict:
        """Run one catalogued routine action through the normal tool boundary."""
        if self.tools is None:
            return {"error": "tools are unavailable"}
        return await self.tools.dispatch("routine", name, args)

    def _set_calendar_timezone(self, timezone_name: str) -> None:
        if self.calendar is not None:
            self.calendar.default_timezone = timezone_name

    async def handle_local_utterance(self, text: str) -> dict | None:
        """A spoken command transcribed offline (vosk) while in local mode."""
        text = (text or "").strip()
        await self.db.log("INFO", "voice", f"offline command: {text or '(nothing recognized)'}")
        cmd = parse_local(text) if text else None
        if cmd is None and text and self.routines is not None:
            routine = await self.routines.resolve_command(text)
            if routine is not None:
                cmd = {
                    "tool": "run_routine",
                    "args": {
                        "routine": routine["routine_id"],
                        "source": "offline_voice",
                    },
                }
        if cmd is None:
            self._announce("not_understood", cooldown=0)
            return None
        if cmd["tool"] == "stop_output":
            # A bare stop only flushes output; the conversation stays alive.
            self.stop_output()
            return {"stopped": True}
        if cmd["tool"] == "end_voice_session":
            # A goodbye ends the conversation and returns to wake-word mode.
            self.stop_output()
            self.end_voice_session()
            self._announce("ok", cooldown=0)
            return {"stopped": True, "session_ended": True}
        assert self.tools is not None
        if cmd["tool"] == "confirm_calendar_event":
            draft_id = self._host_calendar_draft_id
            if not draft_id:
                self._announce("not_understood", cooldown=0)
                return {"error": "there is no appointment reviewed on this computer"}
            cmd["args"]["draft_id"] = draft_id
        result = await self.tools.dispatch("local", cmd["tool"], cmd["args"])
        if (
            cmd["tool"] == "create_calendar_event"
            and result.get("needs_confirmation")
            and result.get("draft", {}).get("id")
        ):
            self._host_calendar_draft_id = result["draft"]["id"]
        elif cmd["tool"] == "confirm_calendar_event" and "error" not in result:
            self._host_calendar_draft_id = None
        if "error" in result:
            self._announce("not_understood", cooldown=0)
        elif cmd["tool"] == "set_quiet_mode":
            pass  # set_quiet speaks its own confirmation
        elif cmd["tool"] == "get_weather":
            if not await self._speak_dynamic(str(result.get("summary", ""))):
                self._announce("see_dashboard", cooldown=0)
        elif cmd["tool"] in (
            "recall_memories",
            "list_reminders",
            "list_calendar_events",
            "get_next_meeting",
            "create_calendar_event",
            "confirm_calendar_event",
            "list_routines",
            "run_routine",
        ):
            # dynamic answers; without TTS, point at the dashboard instead
            if not await self._speak_dynamic(str(result.get("summary", ""))):
                self._announce("see_dashboard", cooldown=0)
        else:
            self._announce("ok", cooldown=0)
        return result

    def request_restart(self) -> None:
        """Dashboard asked for a restart (e.g. to apply a staged update)."""
        self.restart_exit_code = RESTART_EXIT_CODE
        cb = self.on_uvicorn_exit
        if cb is not None:
            asyncio.get_running_loop().call_later(0.3, cb)

    async def set_muted(self, muted: bool) -> None:
        self.state.set_muted(muted)
        await self.db.set_setting("muted", "1" if muted else "0")
        self._announce("muted" if muted else "unmuted", cooldown=0)
        if muted and self.gateway is not None:
            # Revoke any active remote-mic session and drain queued audio so
            # pre-mute frames cannot reach the gateway after the user mutes.
            self.gateway.request_end_session("muted")
            while not self.gateway.audio_in.empty():
                try:
                    self.gateway.audio_in.get_nowait()
                except asyncio.QueueEmpty:
                    break
        if muted and self.remote_voice is not None:
            # Mute is global: a live remote-device conversation must end too
            # — otherwise a provider session keeps running (and speaking on
            # the phone) after the user muted the assistant.
            self.remote_voice.on_global_mute()

    async def set_quiet(self, enabled: bool) -> None:
        """Quiet mode: no unprompted speech (status notices, missed alerts).
        Replies to things the user asks still play, and timers/alarms still
        ring unless quiet_override_alarms is turned off. Manual only."""
        enabled = bool(enabled)
        changed = enabled != self.quiet
        if enabled and changed:
            self._announce("quiet_on", cooldown=0)  # confirm BEFORE going quiet
        self.quiet = enabled
        await self.db.set_setting("quiet_mode", "1" if enabled else "0")
        if not enabled and changed:
            self._announce("quiet_off", cooldown=0)
        if changed:
            self.bus.publish("quiet_changed", quiet=enabled)
            await self.db.log("INFO", "runtime", f"quiet mode {'on' if enabled else 'off'}")

    # Direct responses to something the user just did -- always audible.
    _QUIET_EXEMPT = {"quiet_on", "quiet_off", "ok", "not_understood", "see_dashboard",
                     "muted", "unmuted"}
    # Things the user explicitly scheduled -- ring through quiet mode when
    # quiet_override_alarms is on (reminder/alarm rings are gated separately).
    _QUIET_RINGERS = {"timer_done", "reminder_fallback"}

    def _announce(self, key: str, cooldown: float = 60.0) -> None:
        if self.quiet and key not in self._QUIET_EXEMPT:
            if not (key in self._QUIET_RINGERS and self.settings.quiet_override_alarms):
                return  # quiet mode: swallow unprompted announcements
        now = time.monotonic()
        if cooldown and now - self._announce_cooldowns.get(key, 0) < cooldown:
            return
        self._announce_cooldowns[key] = now
        self.announcer.announce(key)

    async def _event_pump(self) -> None:
        """Central place that reacts to events with announcements/logs.
        Audio playback of announcements happens via the speaker queue only."""
        q = self.bus.subscribe(
            "local_only", "timer_fired", "timer_missed", "credential_alert", "wake_word",
            "reminder_fired", "reminder_missed",
        )
        while True:
            ev = await q.get()
            if ev.topic == "local_only":
                self._announce("quota_exhausted" if ev.data.get("quota") else "service_unavailable")
            elif ev.topic == "timer_fired":
                self._announce("timer_done", cooldown=0)
                await self.db.log("INFO", "timers", f"finished: {ev.data.get('label') or ev.data.get('id')}")
            elif ev.topic == "timer_missed":
                self._announce("timer_missed")
            elif ev.topic == "reminder_fired":
                await self._begin_ring(dict(ev.data))
            elif ev.topic == "reminder_missed":
                self._announce("reminder_missed")
            elif ev.topic == "credential_alert":
                await self.db.log(
                    "WARNING", "credentials",
                    f"{ev.data.get('code')} on credential {ev.data.get('id')}"
                    + (f", {ev.data.get('keys_blocked')} key(s) blocked until {ev.data.get('retry_after')}"
                       if ev.data.get("keys_blocked") else ""),
                )
            elif ev.topic == "wake_word":
                # in capture mode the user is mid-sentence; don't talk over them
                if self.state.raw_state == ChatState.LOCAL_ONLY and ev.data.get("mode") != "capture":
                    self._announce("local_mode", cooldown=30)
