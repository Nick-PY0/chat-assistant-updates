"""Local tool service: validates and executes allowlisted tool calls from
Gemini, the local grammar, or the dashboard command box. Records sanitized
outcomes only -- never spoken content."""

from __future__ import annotations

import logging
import uuid
from typing import Callable

from chat_core.events import EventBus
from chat_core.models.credentials import CredentialStore, iso, utcnow
from chat_core.models.db import Database
from apps.tool_service.media_tool import MediaError, media_control
from apps.tool_service.reminders import ReminderError, ReminderManager
from apps.tool_service.timers import TimerError, TimerManager
from integrations.govee.client import GoveeClient, GoveeError, validate_percentage
from integrations.weather import WeatherError
from integrations.web_search import WebSearchError
from integrations.youtube import YouTubeAPIError
from apps.tool_service.youtube_tool import YouTubeError

log = logging.getLogger("tools")

CONFIRM_TIMER_SECONDS = 4 * 3600
MAX_MEMORIES = 500
MAX_MEMORY_CHARS = 500


class ToolError(Exception):
    """Invalid arguments for a local tool (safe to show the user)."""


class ToolService:
    def __init__(
        self,
        db: Database,
        bus: EventBus,
        timers: TimerManager,
        credentials: CredentialStore,
        on_stop: Callable[[], None] | None = None,
        reminders: ReminderManager | None = None,
        weather=None,      # object with async get(day) -> dict
        web=None,          # read-only current-time, search, and news tools
        youtube=None,      # official YouTube search + dashboard player controller
        on_quiet=None,     # async callable(enabled: bool)
        on_end_session: Callable[[], None] | None = None,
    ) -> None:
        self.db = db
        self.bus = bus
        self.timers = timers
        self.credentials = credentials
        self.on_stop = on_stop
        self.reminders = reminders
        self.weather = weather
        self.web = web
        self.youtube = youtube
        self.on_quiet = on_quiet
        self.on_end_session = on_end_session
        self._devices_cache: list[dict] = []

    # ------------------------------------------------------------------
    async def _govee(self) -> GoveeClient | None:
        for cred in await self.credentials.list(provider="govee"):
            if cred.status in ("active", "standby"):
                try:
                    key = await self.credentials.get_secret(cred.id)
                except KeyError:
                    continue
                return GoveeClient(key)
        return None

    async def devices(self, refresh: bool = False) -> list[dict]:
        if self._devices_cache and not refresh:
            return self._devices_cache
        client = await self._govee()
        if client is None:
            return []
        self._devices_cache = await client.list_devices()
        return self._devices_cache

    async def _resolve_device(self, name: str) -> dict:
        name = str(name or "").strip().lower()
        if not name:
            raise GoveeError("device name required")
        devices = await self.devices()
        if not devices:
            raise GoveeError("no Govee devices available (is a Govee API key saved?)")
        for d in devices:
            if str(d["name"]).lower() == name or str(d["device"]).lower() == name:
                return d
        # fuzzy: substring match, e.g. "desk" -> "Desk Light"
        matches = [d for d in devices if name in str(d["name"]).lower()]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise GoveeError(f"'{name}' matches multiple devices; be more specific")
        raise GoveeError(f"no device named '{name}'")

    # ------------------------------------------------------------------
    async def dispatch(self, call_id: str, name: str, args: dict) -> dict:
        """Single entry point for every tool call. Validates against the
        allowlist and returns a JSON-safe result dict."""
        try:
            result = await self._dispatch_inner(name, args or {})
            await self.db.usage(None, f"tool:{name}", "ok")
            return result
        except (
            TimerError, GoveeError, ToolError, ReminderError, WeatherError, WebSearchError,
            MediaError, YouTubeError, YouTubeAPIError,
        ) as exc:
            await self.db.usage(None, f"tool:{name}", f"rejected: {exc}")
            return {"error": str(exc)}
        except Exception as exc:  # sanitized failure
            log.warning("tool %s failed: %s", name, type(exc).__name__)
            await self.db.usage(None, f"tool:{name}", f"failed: {type(exc).__name__}")
            return {"error": "tool execution failed"}

    async def _dispatch_inner(self, name: str, args: dict) -> dict:
        if name == "start_timer":
            seconds = args.get("duration_seconds")
            confirmed = bool(args.get("confirmed"))
            try:
                seconds_int = int(seconds)
            except (TypeError, ValueError) as exc:
                raise TimerError("duration must be a number of seconds") from exc
            if seconds_int > CONFIRM_TIMER_SECONDS and not confirmed:
                return {
                    "needs_confirmation": True,
                    "message": f"That's over {CONFIRM_TIMER_SECONDS // 3600} hours. Ask the user to confirm, then retry with confirmed=true.",
                }
            return await self.timers.start_timer(seconds_int, args.get("label", ""))

        if name == "list_timers":
            return {"timers": await self.timers.list_timers()}

        if name == "cancel_timer":
            return await self.timers.cancel_timer(args.get("timer_id", ""))

        if name == "pause_timer":
            return await self.timers.pause_timer(args.get("timer_id", ""))

        if name == "resume_timer":
            return await self.timers.resume_timer(args.get("timer_id", ""))

        if name == "set_govee_power":
            state = str(args.get("state", "")).strip().lower()
            if state not in ("on", "off"):
                raise GoveeError("state must be 'on' or 'off'")
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_power(device["sku"], device["device"], state == "on")
            return {"device": device["name"], "power": state}

        if name == "set_govee_brightness":
            pct = validate_percentage(args.get("percentage"))
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_brightness(device["sku"], device["device"], pct)
            return {"device": device["name"], "brightness": pct}

        if name == "set_govee_color":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            await client.set_color(device["sku"], device["device"], str(args.get("color", "")))
            return {"device": device["name"], "color": str(args.get("color", ""))}

        if name == "activate_govee_scene":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            scene = str(args.get("scene", "")).strip()
            if not scene or len(scene) > 60:
                raise GoveeError("invalid scene name")
            await client.activate_scene(device["sku"], device["device"], scene)
            return {"device": device["name"], "scene": scene}

        if name == "get_govee_status":
            device = await self._resolve_device(args.get("device", ""))
            client = await self._govee()
            assert client is not None
            state = await client.get_state(device["sku"], device["device"])
            return {"device": device["name"], "state": state.get("payload", state)}

        if name in ("stop_speaking", "stop_output"):
            if self.on_stop:
                self.on_stop()
            return {"stopped": True}

        if name == "end_voice_session":
            if self.on_stop:
                self.on_stop()
            if self.on_end_session:
                self.on_end_session()
            return {"stopped": True, "session_ended": True}

        if name == "set_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return await self.reminders.set_reminder(
                message=str(args.get("message", "")),
                hour=args.get("hour"),
                minute=args.get("minute", 0),
                ampm=str(args.get("ampm", "")),
                day=str(args.get("day", "")),
                kind=str(args.get("kind", "reminder")),
                at_local=str(args.get("at_local", "")),
            )

        if name == "list_reminders":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            return {"reminders": await self.reminders.list_reminders()}

        if name == "cancel_reminder":
            if self.reminders is None:
                raise ToolError("reminders are not available")
            ref = str(args.get("ref", "") or args.get("reminder_id", ""))
            return await self.reminders.cancel_reminder(ref)

        if name == "get_weather":
            if self.weather is None:
                raise ToolError("weather is not available")
            return await self.weather.get(str(args.get("day", "today")))

        if name == "get_current_time":
            if self.web is None:
                raise ToolError("current time is not available")
            return self.web.current_time()

        if name == "search_web":
            if self.web is None:
                raise ToolError("web search is not available")
            return await self.web.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "get_latest_news":
            if self.web is None:
                raise ToolError("news search is not available")
            return await self.web.news(
                args.get("query", ""), args.get("max_results", 6)
            )

        if name == "set_quiet_mode":
            if self.on_quiet is None:
                raise ToolError("quiet mode is not available")
            enabled = bool(args.get("enabled"))
            await self.on_quiet(enabled)
            return {"quiet": enabled}

        if name == "search_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.search(
                args.get("query", ""), args.get("max_results", 5)
            )

        if name == "play_youtube":
            # All production play_youtube requests route through YouTubeTool.
            # If a Media page owns the lease, the official embedded player runs
            # the video.  If no embedded owner is available, YouTubeTool opens
            # the selected canonical https watch URL in the host computer's
            # default browser (webbrowser.open_new_tab) — never a shell command,
            # never an arbitrary URL.  The 101/150 embed-error fallback is a
            # separate authenticated CSRF-protected endpoint on the Media page.
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            video = str(args.get("video", "") or args.get("video_id", "")).strip()
            query = str(args.get("query", "")).strip()
            url = str(args.get("url", "")).strip()
            title = str(args.get("title", "")).strip()
            playlist_url = str(args.get("playlist_url", "")).strip()
            playlist_id = str(args.get("playlist_id", "")).strip()
            playlist_query = str(args.get("playlist_query", "")).strip()
            # Playlist request takes precedence over ordinary video args.
            if playlist_url or playlist_id or playlist_query:
                return await self.youtube.play_playlist(
                    playlist_id=playlist_id,
                    playlist_url=playlist_url,
                    query=playlist_query,
                    title=title,
                )
            if url:
                return await self.youtube.play_url(url, title)
            if query:
                return await self.youtube.play_query(query, title)
            # Direct video_id / resume
            return await self.youtube.play(video, title)

        if name == "play_playlist":
            if self.youtube is None:
                raise ToolError(
                    "The YouTube Media player is not available. "
                    "Open the Media page in the dashboard to enable playback."
                )
            return await self.youtube.play_playlist(
                playlist_id=str(args.get("playlist_id", "")).strip(),
                playlist_url=str(args.get("playlist_url", "")).strip(),
                query=str(args.get("playlist_query", "") or args.get("query", "")).strip(),
                title=str(args.get("title", "")).strip(),
            )

        if name == "pause_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return self.youtube.pause()

        if name == "stop_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return self.youtube.stop()

        if name == "seek_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return self.youtube.seek(args.get("offset_seconds"))

        if name == "next_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.next()

        if name == "previous_youtube":
            if self.youtube is None:
                raise ToolError("YouTube is not available")
            return await self.youtube.previous()

        if name == "media_control":
            action = str(args.get("action", "")).strip()
            if not action:
                raise MediaError("action is required (play, pause, stop, next, previous)")
            return media_control(action)

        if name == "remember_fact":
            return await self.remember(str(args.get("content", "")), source=str(args.get("source", "voice")))

        if name == "recall_memories":
            return await self.recall(str(args.get("query", "")))

        if name == "forget_memory":
            return await self.forget(str(args.get("query", "")))

        raise GoveeError(f"unknown tool: {name}")  # not on the allowlist

    # -- persistent memory -------------------------------------------------
    async def remember(self, content: str, source: str = "voice") -> dict:
        content = " ".join(content.split()).strip()
        if not content:
            raise ToolError("nothing to remember")
        if len(content) > MAX_MEMORY_CHARS:
            content = content[:MAX_MEMORY_CHARS]
        mem_id = uuid.uuid4().hex[:12]
        await self.db.execute(
            "INSERT INTO memories (id, content, source, created_at) VALUES (?, ?, ?, ?)",
            (mem_id, content, source[:20], iso(utcnow())),
        )
        # cap total memories: oldest fall off
        await self.db.execute(
            "DELETE FROM memories WHERE id NOT IN "
            "(SELECT id FROM memories ORDER BY created_at DESC, id DESC LIMIT ?)",
            (MAX_MEMORIES,),
        )
        self.bus.publish("memories_changed", action="added")
        return {"remembered": content, "id": mem_id}

    async def recall(self, query: str = "", limit: int = 20) -> dict:
        query = " ".join(query.split()).strip()
        if query:
            words = [w for w in query.lower().split() if len(w) > 1][:8]
            if words:
                clause = " OR ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content, created_at FROM memories WHERE {clause} "
                    "ORDER BY created_at DESC, id DESC LIMIT ?",
                    tuple(f"%{w}%" for w in words) + (limit,),
                )
            else:
                rows = []
        else:
            rows = await self.db.fetchall(
                "SELECT id, content, created_at FROM memories ORDER BY created_at DESC, id DESC LIMIT ?",
                (limit,),
            )
        memories = [dict(r) for r in rows]
        return {"memories": memories, "count": len(memories)}

    async def forget(self, query: str) -> dict:
        query = " ".join(query.split()).strip()
        if not query:
            raise ToolError("say what to forget")
        rows = await self.db.fetchall(
            "SELECT id, content FROM memories WHERE LOWER(content) LIKE ?",
            (f"%{query.lower()}%",),
        )
        if not rows:
            # fall back to all-words match so "forget the parking spot" works
            words = [w for w in query.lower().split() if len(w) > 2][:8]
            if words:
                clause = " AND ".join("LOWER(content) LIKE ?" for _ in words)
                rows = await self.db.fetchall(
                    f"SELECT id, content FROM memories WHERE {clause}",
                    tuple(f"%{w}%" for w in words),
                )
        if not rows:
            return {"forgotten": 0, "items": []}
        ids = [r["id"] for r in rows]
        marks = ",".join("?" for _ in ids)
        await self.db.execute(f"DELETE FROM memories WHERE id IN ({marks})", tuple(ids))
        self.bus.publish("memories_changed", action="forgot")
        return {"forgotten": len(ids), "items": [r["content"] for r in rows]}
