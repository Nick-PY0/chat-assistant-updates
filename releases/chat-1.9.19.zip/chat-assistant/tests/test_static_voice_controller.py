"""Static / browser-harness tests for voice_controller.js and related HTML.

These tests verify structural and security properties without needing a running
browser — they inspect the file contents directly.
"""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

import apps.dashboard.app as dashboard_module
from apps.dashboard.app import COOKIE, create_app
from chat_core.runtime import Runtime

STATIC = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "static"
TEMPLATES = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "templates"


# ---- static JS structural checks ------------------------------------------

def test_voice_controller_js_exists():
    assert (STATIC / "voice_controller.js").exists()


def test_voice_controller_js_uses_dedicated_endpoint():
    """The controller speaks the dedicated remote-voice protocol — never the
    host output stream (/ws/audio) or the legacy remote-audio route."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "/ws/remote-voice" in src
    assert "/ws/audio" not in src
    assert "/ws/remote-audio" not in src


def test_voice_controller_js_uses_audio_worklet_with_fallback():
    """AudioWorklet is the primary capture path; ScriptProcessor only as
    compatibility fallback.  The worklet module file must exist."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "audioWorklet" in src
    assert "voice_worklet.js" in src
    assert "createScriptProcessor" in src  # documented fallback
    assert (STATIC / "voice_worklet.js").exists()


def test_voice_controller_js_frames_upstream_audio():
    """Upstream audio must be framed (JV magic + sequence numbers), 16 kHz."""
    src = (STATIC / "voice_controller.js").read_text()
    assert '"JV"' in src or "'JV'" in src or "0x4a" in src.lower() or "JV" in src
    assert "16000" in src
    assert "24000" in src  # downstream playback rate


def test_voice_controller_js_fetches_capability_token():
    """The socket handshake requires a short-lived capability token."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "/api/remote-voice/token" in src


def test_voice_controller_js_no_mic_in_app_js():
    """app.js must not open a microphone — that is voice_controller.js's job."""
    src = (STATIC / "app.js").read_text()
    assert "getUserMedia" not in src
    assert "remote-audio" not in src
    assert "remote-voice" not in src


def test_voice_controller_js_has_stop_and_mute():
    """The controller must expose explicit Stop and Mute controls."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "vc-stop" in src
    assert "vc-mute" in src


def test_voice_controller_js_uses_csrf():
    """The controller must include the CSRF token when calling the mute API."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "x-csrf" in src
    assert "csrf" in src


def test_voice_controller_js_handles_4401():
    """The controller must handle close code 4401 (unauthorized)."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "4401" in src


def test_voice_controller_js_handles_4409():
    """The controller must handle close code 4409 (already occupied)."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "4409" in src


def test_voice_controller_js_handles_4412_not_4410():
    """Lease revocation is close code 4412 now; the old 4410 is gone."""
    src = (STATIC / "voice_controller.js").read_text()
    assert "4412" in src
    assert "4410" not in src


def test_voice_controller_js_supports_push_to_talk():
    src = (STATIC / "voice_controller.js").read_text()
    assert "vc-ptt" in src


def test_voice_controller_js_updates_wake_readiness_live():
    """A socket opened while the model loads must leave manual-only mode
    without forcing the user to reconnect the phone."""
    src = (STATIC / "voice_controller.js").read_text()
    assert 'case "wake_status"' in src
    assert "msg.wake_available" in src


def test_voice_controller_js_never_reads_provider_keys():
    """Provider credentials stay server-side; the browser never sees them."""
    src = (STATIC / "voice_controller.js").read_text()
    for needle in ("api_key", "apiKey", "GEMINI", "OPENAI"):
        assert needle not in src


def test_chat_js_no_mic_capture():
    """chat.js must not open a microphone — it delegates to voice_controller."""
    src = (STATIC / "chat.js").read_text()
    assert "getUserMedia" not in src
    assert "remote-audio" not in src


def test_chat_js_no_jarvis():
    """chat.js must not mention Jarvis as product name in user-visible strings."""
    src = (STATIC / "chat.js").read_text()
    assert "Jarvis" not in src


# ---- template structural checks -------------------------------------------

def test_voice_controller_template_exists():
    assert (TEMPLATES / "voice_controller.html").exists()


def test_voice_controller_template_no_sidebar():
    """The voice-controller popup must not include the full navigation sidebar."""
    html = (TEMPLATES / "voice_controller.html").read_text()
    assert "nav-toggle" not in html
    assert 'href="/credentials"' not in html


def test_voice_controller_template_has_csrf_meta():
    """The page must carry the CSRF meta tag so voice_controller.js can read it."""
    html = (TEMPLATES / "voice_controller.html").read_text()
    assert 'name="csrf"' in html


def test_voice_controller_template_includes_app_js():
    """The page must load app.js so the api() helper is available."""
    html = (TEMPLATES / "voice_controller.html").read_text()
    assert "app.js" in html


def test_base_template_has_voice_ctrl_btn():
    """Every page (via base.html) must expose the voice-controller opener."""
    html = (TEMPLATES / "base.html").read_text()
    assert "voice-ctrl-btn" in html
    assert "Talk on this device" in html


def test_app_js_opens_named_popup():
    """app.js must open voice-controller in a named window (focus/reuse)."""
    src = (STATIC / "app.js").read_text()
    assert "chat-voice-controller" in src
    assert "window.open" in src


def test_settings_template_has_details_element():
    """settings.html must wrap advanced fields in a <details> element."""
    html = (TEMPLATES / "settings.html").read_text()
    assert "<details" in html
    assert "Advanced settings" in html


def test_settings_template_primary_before_advanced():
    """Voice brain and relay address must appear before the advanced block."""
    html = (TEMPLATES / "settings.html").read_text()
    brain_pos = html.find("s-brain")
    relay_pos = html.find("s-relay-url")
    details_pos = html.find("<details")
    assert brain_pos != -1 and brain_pos < details_pos
    assert relay_pos != -1 and relay_pos < details_pos


def test_settings_template_typed_provider_selector():
    """The typed-chat-provider selector must be in the primary (non-advanced) area."""
    html = (TEMPLATES / "settings.html").read_text()
    typed_pos = html.find("s-typed-provider")
    details_pos = html.find("<details")
    assert typed_pos != -1 and typed_pos < details_pos


def test_chat_template_no_jarvis_branding():
    """chat.html must not use Jarvis as a visible product label."""
    html = (TEMPLATES / "chat.html").read_text()
    assert 'placeholder="Message Jarvis"' not in html
    assert 'aria-label="Jarvis chat"' not in html
    assert "Message Chat" in html or 'aria-label="Chat"' in html


# ---- API endpoint test (requires fixture) ----------------------------------

@pytest.fixture
async def rt(settings, monkeypatch):
    runtime = Runtime(settings)
    await runtime.start(voice=False, cloud=False, monitoring=False)
    yield runtime
    await runtime.stop()


@pytest.fixture
async def client(rt, monkeypatch):
    async def fake_validate(secret, timeout=5.0):
        return None

    monkeypatch.setattr(dashboard_module, "validate_key", fake_validate)
    app = create_app(rt)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        c.app = app
        yield c


async def csrf_of(client) -> str:
    app = client.app
    token = client.cookies.get(COOKIE)
    return app.state.sessions.csrf_for(token)


async def signed_in(client, password="hunter2secure"):
    resp = await client.post("/setup", data={"password": password, "confirm": password})
    assert resp.status_code == 303
    return {"x-csrf": await csrf_of(client)}


async def test_providers_summary_healthy_even_when_voice_off(client, rt):
    """Gemini and typed-chat cards must be present even when voice is off."""
    await signed_in(client)
    # Simulate voice unavailable
    rt.audio = None
    data = (await client.get("/api/providers/summary")).json()
    # Should still return all sections; no missing sections
    for key in ("gemini", "openai_live", "relay", "voice_pipeline", "typed_chat"):
        assert key in data, f"Missing section: {key}"
    # voice down must not hide other providers
    assert "gemini" in data


async def test_settings_save_typed_chat_provider(client, rt):
    """The typed-chat provider must be saveable via /api/settings."""
    hdrs = await signed_in(client)
    # openai is valid
    resp = await client.post(
        "/api/settings",
        json={"typed_chat_provider": "openai"},
        headers=hdrs,
    )
    assert resp.status_code == 200
    assert rt.settings.typed_chat_provider == "openai"
    # relay is valid
    resp = await client.post(
        "/api/settings",
        json={"typed_chat_provider": "relay"},
        headers=hdrs,
    )
    assert resp.status_code == 200
    assert rt.settings.typed_chat_provider == "relay"
    # garbage is rejected
    resp = await client.post(
        "/api/settings",
        json={"typed_chat_provider": "gpt5"},
        headers=hdrs,
    )
    assert resp.status_code == 400
