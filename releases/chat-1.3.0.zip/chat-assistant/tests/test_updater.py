"""Auto-updater: version comparison, staging, and zip safety."""

from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import pytest

from apps.updater.updater import Updater
from chat_core.version import APP_VERSION, is_newer, parse_version


def _zip_bytes(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


class FakeUpdater(Updater):
    """Network calls replaced; everything else is the real code path."""

    manifest: dict = {}
    zip_bytes: bytes = b""

    async def _http_get_json(self, url: str) -> dict:
        return self.manifest

    async def _http_download(self, url: str, dest: Path) -> None:
        dest.write_bytes(self.zip_bytes)


def test_version_parsing():
    assert parse_version("1.2.3") == (1, 2, 3)
    assert parse_version("v2.0") == (2, 0)
    assert parse_version("dev") is None
    assert is_newer("1.2.0", "1.1.9")
    assert is_newer("2.0", "1.9.9")
    assert not is_newer("1.1.0", "1.1.0")
    assert not is_newer("1.0.9", "1.1.0")
    assert not is_newer("garbage", "1.0.0")


@pytest.fixture
async def updater(settings, db, bus):
    settings.update_url = "https://example.test/latest.json"
    return FakeUpdater(settings, db, bus)


async def test_stages_newer_version(updater):
    updater.manifest = {"version": "9.9.9", "zip_url": "https://example.test/x.zip", "notes": "big"}
    updater.zip_bytes = _zip_bytes({
        "chat-assistant/run_chat.py": "print('new version')",
        "chat-assistant/chat_core/version.py": "APP_VERSION='9.9.9'",
    })
    status = await updater.check_now()
    assert status["pending"] == "9.9.9"
    assert (updater.pending_dir / "run_chat.py").exists()
    assert (updater.pending_dir / "chat_core" / "version.py").exists()
    meta = json.loads((updater.updates_dir / "pending.json").read_text())
    assert meta["version"] == "9.9.9"
    # no leftovers
    assert not (updater.updates_dir / "download.zip").exists()
    assert not (updater.updates_dir / "extract").exists()


async def test_ignores_older_and_equal_versions(updater):
    updater.manifest = {"version": APP_VERSION, "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] is None
    updater.manifest = {"version": "0.0.1", "zip_url": "https://example.test/x.zip"}
    status = await updater.check_now()
    assert status["pending"] is None


async def test_rejects_zip_without_marker(updater):
    updater.manifest = {"version": "9.9.9", "zip_url": "https://example.test/x.zip"}
    updater.zip_bytes = _zip_bytes({"random.txt": "not a chat build"})
    status = await updater.check_now()
    assert status["pending"] is None
    assert "download failed" in status["error"]


@pytest.mark.parametrize("evil", [
    "../evil.txt",                     # classic traversal
    "../extract_evil/payload.txt",     # sibling dir sharing the name prefix
    "/etc/evil.txt",                   # absolute path
])
async def test_zip_with_traversal_member_is_rejected_entirely(updater, evil):
    updater.manifest = {"version": "9.9.9", "zip_url": "https://example.test/x.zip"}
    updater.zip_bytes = _zip_bytes({
        "run_chat.py": "print('ok')",
        evil: "escaped!",
    })
    status = await updater.check_now()
    assert status["pending"] is None  # one bad member poisons the whole zip
    assert "download failed" in status["error"]
    updates = updater.updates_dir
    assert not (updates / "evil.txt").exists()
    assert not (updates.parent / "evil.txt").exists()
    assert not (updates / "extract_evil").exists()
    assert not (updates.parent / "extract_evil").exists()


async def test_manifest_without_url_reports_error(updater):
    updater.settings.update_url = ""
    status = await updater.check_now()
    assert status["error"] == "no update link configured"
