"""Voice-contract regressions: the user's exact Hey Jarvis / Stop / Goodbye rules.

Covered here:
  * continuous defaults (continuous_conversation=True, 1800s lease)
  * rolling 30-minute deadline resets on user/assistant activity
  * Stop only interrupts and keeps the session + microphone alive (all brains)
  * Goodbye ends the session; a fresh wake word is required afterwards
  * the stop grammar and goodbye grammar are disjoint (parser + local grammar)
  * remote Voice Controller Stop preserves transport; Goodbye revokes it
"""

from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from apps.live_gateway.prompts import (
    is_voice_goodbye_phrase,
    is_voice_stop_phrase,
)
from apps.tool_service.local_grammar import parse as parse_local
from chat_core.config.settings import Settings
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


# ---------------------------------------------------------------------------
# 1. Continuous-conversation defaults
# ---------------------------------------------------------------------------

def test_continuous_conversation_defaults_true_and_1800():
    s = Settings()
    assert s.continuous_conversation is True
    assert s.continuous_session_seconds == 1800


async def _dummy_tools(call_id, name, args):
    return {}


def _make_gateway(settings, db, store, bus):
    state = StateMachine(bus)
    return LiveGateway(settings, db, store, bus, state, [], _dummy_tools), state


def test_conversation_timeout_uses_1800s_rolling_lease(settings, db, store, bus):
    gw, _ = _make_gateway(settings, db, store, bus)
    # Rolling deadline is the max of inactivity and continuous lease seconds.
    assert gw._conversation_timeout() == 1800.0


def test_conversation_timeout_falls_back_when_continuous_off(settings, db, store, bus):
    settings.continuous_conversation = False
    gw, _ = _make_gateway(settings, db, store, bus)
    assert gw._conversation_timeout() == float(settings.inactivity_timeout_seconds)


# ---------------------------------------------------------------------------
# 2. Rolling deadline resets after user/assistant activity
# ---------------------------------------------------------------------------

def test_rolling_deadline_resets_on_activity(settings, db, store, bus, monkeypatch):
    import apps.live_gateway.gateway as gw_mod

    gw, _ = _make_gateway(settings, db, store, bus)
    gw.request_session()
    fake_now = [1000.0]
    monkeypatch.setattr(gw_mod.time, "monotonic", lambda: fake_now[0])

    # Time advances almost to the lease edge without activity.
    fake_now[0] = 1000.0 + 1700.0
    gw._last_interaction_at = 1000.0
    assert gw._conversation_idle_elapsed() == pytest.approx(1700.0)

    # An assistant/user turn resets the rolling window.
    gw._on_session_activity()
    assert gw._conversation_idle_elapsed() == pytest.approx(0.0)

    # ... and it accumulates again from the reset point, not from the start.
    fake_now[0] += 500.0
    assert gw._conversation_idle_elapsed() == pytest.approx(500.0)


def test_activity_ignored_when_no_active_lease(settings, db, store, bus):
    gw, _ = _make_gateway(settings, db, store, bus)
    gw._session_intent_active = False
    gw._last_interaction_at = 0.0
    gw._on_session_activity()
    # No lease -> no rolling window is started.
    assert gw._last_interaction_at == 0.0


# ---------------------------------------------------------------------------
# 3. Parser disjointness: stop vs goodbye
# ---------------------------------------------------------------------------

STOP_PHRASES = [
    "stop", "Stop.", "stop Jarvis", "Jarvis stop", "hey Jarvis stop",
    "stop now", "please stop", "be quiet", "quiet", "hush", "stop talking",
]

GOODBYE_PHRASES = [
    "goodbye", "good bye", "goodbye Jarvis", "Jarvis goodbye", "bye",
    "bye Jarvis", "stop listening", "end conversation", "end the conversation",
    "end session", "go to sleep", "that's all", "that's all Jarvis",
]

NEITHER_PHRASES = [
    "stop the timer", "stop the music", "what time is it",
    "set a timer for ten minutes", "stop the kitchen timer",
]


@pytest.mark.parametrize("text", STOP_PHRASES)
def test_stop_phrases_are_stop_only(text):
    assert is_voice_stop_phrase(text) is True
    assert is_voice_goodbye_phrase(text) is False


@pytest.mark.parametrize("text", GOODBYE_PHRASES)
def test_goodbye_phrases_are_goodbye_only(text):
    assert is_voice_goodbye_phrase(text) is True
    assert is_voice_stop_phrase(text) is False


@pytest.mark.parametrize("text", NEITHER_PHRASES)
def test_named_targets_are_neither(text):
    assert is_voice_stop_phrase(text) is False
    assert is_voice_goodbye_phrase(text) is False


def test_stop_and_goodbye_grammars_never_overlap():
    for text in STOP_PHRASES + GOODBYE_PHRASES + NEITHER_PHRASES:
        assert not (is_voice_stop_phrase(text) and is_voice_goodbye_phrase(text)), text


# ---------------------------------------------------------------------------
# 4. Local grammar honours the same split
# ---------------------------------------------------------------------------

def test_local_grammar_stop_only_flushes():
    assert parse_local("stop") == {"tool": "stop_output", "args": {}}
    assert parse_local("be quiet") == {"tool": "stop_output", "args": {}}


def test_local_grammar_goodbye_ends_session():
    assert parse_local("goodbye") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("goodbye jarvis") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("stop listening") == {"tool": "end_voice_session", "args": {}}
    assert parse_local("go to sleep") == {"tool": "end_voice_session", "args": {}}


def test_local_grammar_named_stop_not_session():
    cmd = parse_local("stop the music")
    assert cmd is not None
    assert cmd["tool"] not in ("stop_output", "end_voice_session")


# ---------------------------------------------------------------------------
# 5. stop_speaking interrupts only; end_voice_session ends (Gemini/OpenAI)
# ---------------------------------------------------------------------------

def _live_session_common():
    return dict(
        api_key="k",
        model="models/test-live",
        system_prompt="p",
        tool_declarations=[],
        audio_in=asyncio.Queue(),
        audio_out=asyncio.Queue(),
    )


class _RecordingSocket:
    def __init__(self, messages):
        self.sent = []
        self.closed = None
        self._messages = iter(messages)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self._messages)
        except StopIteration:
            raise StopAsyncIteration

    async def send(self, raw):
        self.sent.append(json.loads(raw))

    async def close(self, code=1000, reason=""):
        self.closed = (code, reason)


async def test_gemini_stop_speaking_keeps_session_alive():
    from integrations.gemini.live_client import LiveSession

    async def stop_handler(call_id, name, args):
        return {"stopped": True}

    session = LiveSession(tool_handler=stop_handler, **_live_session_common())
    socket = _RecordingSocket([
        json.dumps({"toolCall": {"functionCalls": [
            {"id": "s1", "name": "stop_speaking", "args": {}}
        ]}}),
    ])
    # Receiver runs to natural end-of-stream (no close on stop_speaking).
    reason = await session._receiver(socket)
    assert socket.closed is None, "stop_speaking must not close the session"
    assert reason != "stopped"
    # The tool response was still acknowledged.
    assert socket.sent[0]["toolResponse"]["functionResponses"][0]["name"] == "stop_speaking"


async def test_gemini_end_voice_session_closes():
    from integrations.gemini.live_client import LiveSession

    async def end_handler(call_id, name, args):
        return {"stopped": True, "session_ended": True}

    session = LiveSession(tool_handler=end_handler, **_live_session_common())
    socket = _RecordingSocket([
        json.dumps({"toolCall": {"functionCalls": [
            {"id": "e1", "name": "end_voice_session", "args": {}}
        ]}}),
    ])
    assert await session._receiver(socket) == "stopped"
    assert socket.closed == (1000, "stopped")


async def test_openai_stop_speaking_keeps_session_alive():
    from integrations.openai_rt.live_client import RealtimeSession

    async def stop_handler(call_id, name, args):
        return {"stopped": True}

    session = RealtimeSession(
        api_key="k", model="gpt-realtime", system_prompt="p",
        tool_declarations=[], tool_handler=stop_handler,
        audio_in=asyncio.Queue(), audio_out=asyncio.Queue(),
    )
    socket = _RecordingSocket([
        json.dumps({
            "type": "response.function_call_arguments.done",
            "call_id": "s1", "name": "stop_speaking", "arguments": "{}",
        }),
    ])
    reason = await session._receiver(socket)
    assert socket.closed is None, "stop_speaking must not close the session"
    assert reason != "stopped"
    # It acknowledged the tool and asked for a fresh response, staying alive.
    kinds = [m.get("type") for m in socket.sent]
    assert "function_call_output" in [
        m.get("item", {}).get("type") for m in socket.sent
    ]
    assert "response.create" in kinds


async def test_openai_end_voice_session_closes():
    from integrations.openai_rt.live_client import RealtimeSession

    async def end_handler(call_id, name, args):
        return {"stopped": True, "session_ended": True}

    session = RealtimeSession(
        api_key="k", model="gpt-realtime", system_prompt="p",
        tool_declarations=[], tool_handler=end_handler,
        audio_in=asyncio.Queue(), audio_out=asyncio.Queue(),
    )
    socket = _RecordingSocket([
        json.dumps({
            "type": "response.function_call_arguments.done",
            "call_id": "e1", "name": "end_voice_session", "arguments": "{}",
        }),
    ])
    assert await session._receiver(socket) == "stopped"
    assert socket.closed == (1000, "stopped")


# ---------------------------------------------------------------------------
# 6. Relay behaviour: goodbye ends, stop keeps listening
# ---------------------------------------------------------------------------

_LOUD = b"\x88\x13" * 1280    # RMS ~5000
_QUIET = b"\x00" * 2560       # digital silence


def _relay_session(settings, db, bus, handler, transcript):
    from apps.live_gateway.relay_session import RelayVoiceSession

    class FakeClient:
        def __init__(self):
            self.transcribe_calls = 0

        async def health(self):
            return None

        async def transcribe(self, pcm):
            # First captured utterance is the phrase under test; after that,
            # silence (so the loop idles out).
            self.transcribe_calls += 1
            return transcript if self.transcribe_calls == 1 else ""

        async def ask(self, *a, **k):
            return {"reply": "ok", "tool_calls": [], "usage": {}}

        async def speak(self, text, voice):
            return b"\x07\x00" * 2400, 24000

    settings.inactivity_timeout_seconds = 1
    client = FakeClient()
    session = RelayVoiceSession(
        client, settings, db, bus, StateMachine(bus), [], handler,
        asyncio.Queue(), asyncio.Queue(maxsize=256),
    )
    return session, client


def _speak_then_silence(audio_in):
    for _ in range(10):
        audio_in.put_nowait(_LOUD)
    for _ in range(12):
        audio_in.put_nowait(_QUIET)


async def test_relay_goodbye_ends_session(settings, db, bus):
    calls = []

    async def handler(call_id, name, args):
        calls.append(name)
        if name == "end_voice_session":
            return {"stopped": True, "session_ended": True}
        return {}

    session, client = _relay_session(settings, db, bus, handler, "goodbye")
    _speak_then_silence(session.audio_in)
    reason = await asyncio.wait_for(session.run(), timeout=3.0)
    assert reason == "stopped"
    assert "end_voice_session" in calls


async def test_relay_stop_keeps_listening(settings, db, bus):
    calls = []

    async def handler(call_id, name, args):
        calls.append(name)
        return {"stopped": True}

    session, client = _relay_session(settings, db, bus, handler, "stop")
    _speak_then_silence(session.audio_in)
    # After the stop turn, the loop keeps listening and idles out (inactivity),
    # which proves stop did NOT end the conversation.
    reason = await asyncio.wait_for(session.run(), timeout=4.0)
    assert "stop_speaking" in calls
    assert "end_voice_session" not in calls
    # Ended by inactivity, not by the stop phrase.
    assert reason == "inactivity"


# ---------------------------------------------------------------------------
# 7. Remote Voice Controller transport preservation
# ---------------------------------------------------------------------------

class FakeWebSocket:
    def __init__(self, token):
        self.cookies = {COOKIE: token}
        self.incoming = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code = None
        self.close_reason = ""
        self.sent_bytes = []
        self.sent_text = []

    async def accept(self):
        self.accepted.set()

    async def close(self, code=1000, reason=None):
        self.close_code = code
        self.close_reason = reason or ""
        self.closed.set()

    async def receive(self):
        return await self.incoming.get()

    async def send_bytes(self, p):
        self.sent_bytes.append(p)

    async def send_text(self, p):
        self.sent_text.append(p)

    def feed_audio(self, p):
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": p})

    def disconnect(self):
        self.incoming.put_nowait({"type": "websocket.disconnect"})


@pytest.fixture
def remote_app(settings, db, store, bus):
    state = StateMachine(bus)
    gateway = LiveGateway(settings, db, store, bus, state, [], _dummy_tools)
    runtime = SimpleNamespace(
        settings=settings, db=db, state=state, gateway=gateway,
        broadcast=AudioBroadcast(), audio=None, media_playing=False, stop_calls=0,
    )

    def stop_output():
        runtime.stop_calls += 1
        gateway.interrupt()
        runtime.broadcast.clear()

    runtime.stop_output = stop_output
    app = create_app(runtime)
    sessions = SessionManager("voice-contract-secret", 3600)
    app.state.sessions = sessions
    token = sessions.issue()
    endpoint = next(
        r.endpoint for r in app.routes if r.path == "/ws/remote-audio"
    )
    return app, runtime, token, endpoint


async def _open_socket(app, token, endpoint):
    ws = FakeWebSocket(token)
    task = asyncio.create_task(endpoint(ws))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    for _ in range(20):
        owner = app.state.remote_mic_owner
        if owner is not None and owner.socket is ws:
            break
        if ws.closed.is_set():
            break
        await asyncio.sleep(0)
    return ws, task


async def test_stop_preserves_remote_socket_and_lease(remote_app):
    """Stop (flush output) must NOT revoke the lease or close the socket."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    gen = rt.gateway.voice_session_generation
    end_gen = rt.gateway.voice_end_generation

    # This is what /api/stop does: flush output only.
    rt.stop_output()
    await asyncio.sleep(0.1)

    assert not ws.closed.is_set(), "Stop must keep the WebSocket open"
    assert app.state.remote_mic_owner is not None
    assert app.state.remote_mic_owner.socket is ws
    assert rt.gateway.session_intent_active is True
    assert rt.gateway.voice_session_generation == gen
    assert rt.gateway.voice_end_generation == end_gen  # lease not revoked

    ws.disconnect()
    await asyncio.wait_for(task, timeout=0.5)


async def test_goodbye_revokes_remote_socket(remote_app):
    """Goodbye (end_session) revokes the lease and closes the socket 4410."""
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    gen = rt.gateway.voice_session_generation

    # This is what /api/session/end does.
    await rt.gateway.end_session("goodbye from controller")
    ws.feed_audio((2400).to_bytes(2, "little", signed=True) * 1600)

    await asyncio.wait_for(ws.closed.wait(), timeout=0.5)
    await asyncio.wait_for(task, timeout=0.5)
    assert ws.close_code == 4410
    assert not rt.gateway.session_intent_active
    assert app.state.remote_mic_owner is None

    # A fresh wake (Start voice) is required and owns a NEW generation.
    fresh, fresh_task = await _open_socket(app, token, endpoint)
    assert rt.gateway.voice_session_generation > gen
    fresh.disconnect()
    await asyncio.wait_for(fresh_task, timeout=0.5)


# ---------------------------------------------------------------------------
# 8. Voice controller UI contract (static)
# ---------------------------------------------------------------------------

from pathlib import Path

_STATIC = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "static"
_TEMPLATES = Path(__file__).resolve().parent.parent / "apps" / "dashboard" / "templates"


def test_controller_has_goodbye_button():
    html = (_TEMPLATES / "voice_controller.html").read_text()
    assert "vc-goodbye" in html
    js = (_STATIC / "voice_controller.js").read_text()
    assert "vc-goodbye" in js


def test_controller_stop_does_not_close_socket():
    """The Stop handler must call /api/stop and never ws.close()."""
    js = (_STATIC / "voice_controller.js").read_text()
    # locate the stop handler block
    idx = js.index('stopBtn.addEventListener("click"')
    end = js.index('goodbyeBtn.addEventListener("click"')
    stop_block = js[idx:end]
    assert "/api/stop" in stop_block
    assert "ws.close" not in stop_block


def test_controller_goodbye_ends_session():
    js = (_STATIC / "voice_controller.js").read_text()
    idx = js.index('goodbyeBtn.addEventListener("click"')
    goodbye_block = js[idx:idx + 600]
    assert "/api/session/end" in goodbye_block


def test_controller_close_status_never_blames_stop():
    """The 4410 close copy must attribute ending to goodbye/inactivity, not Stop."""
    js = (_STATIC / "voice_controller.js").read_text()
    idx = js.index("4410")
    block = js[idx:idx + 400]
    assert "goodbye" in block.lower()
    assert "inactivity" in block.lower()
    # It must not tell the user that the Stop button ended the session.
    assert "or Stop" not in block
