"""Remote microphone ownership and voice-lease lifecycle regressions."""

from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from apps.audio.broadcast import AudioBroadcast
from apps.dashboard.app import COOKIE, create_app
from apps.live_gateway.gateway import LiveGateway
from chat_core.models.state import ChatState, StateMachine
from chat_core.security.auth import SessionManager


async def _dummy_tools(call_id, name, args):
    return {}


class FakeWebSocket:
    """Small ASGI-WebSocket double that exercises the real route coroutine."""

    def __init__(self, token: str) -> None:
        self.cookies = {COOKIE: token}
        self.incoming: asyncio.Queue[dict] = asyncio.Queue()
        self.accepted = asyncio.Event()
        self.closed = asyncio.Event()
        self.close_code: int | None = None
        self.close_reason = ""
        self.sent_bytes: list[bytes] = []
        self.sent_text: list[str] = []

    async def accept(self) -> None:
        self.accepted.set()

    async def close(self, code: int = 1000, reason: str | None = None) -> None:
        self.close_code = code
        self.close_reason = reason or ""
        self.closed.set()

    async def receive(self) -> dict:
        return await self.incoming.get()

    async def send_bytes(self, payload: bytes) -> None:
        self.sent_bytes.append(payload)

    async def send_text(self, payload: str) -> None:
        self.sent_text.append(payload)

    def feed_audio(self, payload: bytes) -> None:
        self.incoming.put_nowait({"type": "websocket.receive", "bytes": payload})

    def disconnect(self) -> None:
        self.incoming.put_nowait({"type": "websocket.disconnect"})


@pytest.fixture
def remote_app(settings, db, store, bus):
    state = StateMachine(bus)
    gateway = LiveGateway(settings, db, store, bus, state, [], _dummy_tools)
    runtime = SimpleNamespace(
        settings=settings,
        db=db,
        state=state,
        gateway=gateway,
        broadcast=AudioBroadcast(),
        audio=None,
        media_playing=False,
        stop_calls=0,
    )

    def stop_output() -> None:
        runtime.stop_calls += 1
        gateway.interrupt()
        runtime.broadcast.clear()

    runtime.stop_output = stop_output
    app = create_app(runtime)
    sessions = SessionManager("remote-audio-test-secret", 3600)
    app.state.sessions = sessions
    token = sessions.issue()
    endpoint = next(
        route.endpoint for route in app.routes if route.path == "/ws/remote-audio"
    )
    return app, runtime, token, endpoint


async def _open_socket(app, token, endpoint) -> tuple[FakeWebSocket, asyncio.Task]:
    ws = FakeWebSocket(token)
    task = asyncio.create_task(endpoint(ws))
    await asyncio.wait_for(ws.accepted.wait(), timeout=0.5)
    # Accepted happens just before the synchronous ownership claim.
    for _ in range(20):
        owner = app.state.remote_mic_owner
        if owner is not None and owner.socket is ws:
            break
        if ws.closed.is_set():
            break
        await asyncio.sleep(0)
    return ws, task


async def test_explicit_voice_stop_revokes_open_remote_socket(remote_app):
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    first_generation = rt.gateway.voice_session_generation
    assert first_generation > 0

    # Race loud room audio against the explicit stop. The old bug saw the
    # sleeping state and immediately opened a new provider conversation.
    rt.gateway.request_end_session("voice stop command")
    rt.state.set(ChatState.SLEEPING, "explicit stop")
    loud = (2400).to_bytes(2, "little", signed=True) * 1600
    ws.feed_audio(loud)
    ws.feed_audio(loud)

    await asyncio.wait_for(ws.closed.wait(), timeout=0.5)
    await asyncio.wait_for(task, timeout=0.5)
    assert ws.close_code == 4410
    assert "start voice again" in ws.close_reason
    assert rt.gateway.voice_session_generation == first_generation
    assert not rt.gateway._session_intent_active
    assert rt.gateway.audio_in.empty()
    assert app.state.remote_mic_owner is None

    # The explicit user action is now required: a new Start voice connection
    # owns a new generation and is allowed to listen again.
    fresh, fresh_task = await _open_socket(app, token, endpoint)
    assert rt.gateway.voice_session_generation > first_generation
    assert rt.gateway._session_intent_active
    fresh.disconnect()
    await asyncio.wait_for(fresh_task, timeout=0.5)


async def test_natural_timeout_closes_remote_talk_lease_without_reopening(remote_app):
    app, rt, token, endpoint = remote_app
    ws, task = await _open_socket(app, token, endpoint)
    first_generation = rt.gateway.voice_session_generation
    end_generation = rt.gateway.voice_end_generation

    # Model the gateway's normal inactivity completion. It does not advance
    # the explicit-end generation, but it still closes the browser lease so
    # ordinary room speech cannot silently start another 30-minute session.
    rt.gateway._session_intent_active = False
    rt.gateway._keep_listening = False
    rt.gateway._wanted.clear()
    rt.state.set(ChatState.SLEEPING, "provider inactivity")
    loud = (2400).to_bytes(2, "little", signed=True) * 1600
    ws.feed_audio(loud)
    ws.feed_audio(loud)

    await asyncio.wait_for(ws.closed.wait(), timeout=0.5)
    await asyncio.wait_for(task, timeout=0.5)
    assert rt.gateway.voice_end_generation == end_generation
    assert rt.gateway.voice_session_generation == first_generation
    assert not rt.gateway._session_intent_active
    assert rt.gateway.audio_in.empty()
    assert ws.close_code == 4410
    assert app.state.remote_mic_owner is None


async def test_disconnect_cleanup_serializes_owner_claims(remote_app, monkeypatch):
    app, rt, token, endpoint = remote_app
    first, first_task = await _open_socket(app, token, endpoint)
    first_generation = rt.gateway.voice_session_generation
    cleanup_entered = asyncio.Event()
    release_cleanup = asyncio.Event()
    real_end = rt.gateway.end_session

    async def delayed_end(reason="requested", *, expected_generation=None):
        cleanup_entered.set()
        await release_cleanup.wait()
        return await real_end(reason, expected_generation=expected_generation)

    monkeypatch.setattr(rt.gateway, "end_session", delayed_end)
    first.disconnect()
    await asyncio.wait_for(cleanup_entered.wait(), timeout=0.5)

    # Ownership is deliberately retained across the await above. A competing
    # device receives a bounded busy response instead of being claimed and
    # then killed by the first socket's stale finally block.
    competing, competing_task = await _open_socket(app, token, endpoint)
    await asyncio.wait_for(competing.closed.wait(), timeout=0.5)
    await asyncio.wait_for(competing_task, timeout=0.5)
    assert competing.close_code == 4409
    assert app.state.remote_mic_owner.socket is first

    release_cleanup.set()
    await asyncio.wait_for(first_task, timeout=0.5)
    assert app.state.remote_mic_owner is None

    replacement, replacement_task = await _open_socket(app, token, endpoint)
    assert app.state.remote_mic_owner.socket is replacement
    assert rt.gateway.voice_session_generation > first_generation
    assert rt.gateway._session_intent_active
    replacement.disconnect()
    await asyncio.wait_for(replacement_task, timeout=0.5)
