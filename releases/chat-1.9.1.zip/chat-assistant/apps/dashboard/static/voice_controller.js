"use strict";
// voice_controller.js — standalone microphone/speaker bridge for /voice-controller
// This page owns the /ws/remote-audio WebSocket lease.  The main dashboard pages
// (Chat, Status, Logs, Settings …) stay open in their own tab without destroying
// the microphone connection.

(() => {
  // ---- state ---------------------------------------------------------------
  let ws = null;
  let audioCtx = null;
  let micStream = null;
  let micProcessor = null;
  let playCursor = 0;
  let liveSources = [];
  let connected = false;
  let muted = false;

  // ---- DOM refs ------------------------------------------------------------
  const statusEl   = document.getElementById("vc-status");
  const stateEl    = document.getElementById("vc-state");
  const startBtn   = document.getElementById("vc-start");
  const stopBtn    = document.getElementById("vc-stop");
  const goodbyeBtn = document.getElementById("vc-goodbye");
  const muteBtn    = document.getElementById("vc-mute");
  const errorEl    = document.getElementById("vc-error");
  const csrf       = document.querySelector('meta[name="csrf"]')?.content || "";

  // ---- helpers -------------------------------------------------------------
  function setError(msg) {
    errorEl.textContent = msg || "";
  }

  function setStatus(label, cls) {
    stateEl.textContent = label;
    stateEl.className = "vc-state-label " + (cls || "");
    statusEl.textContent = label;
    document.title = "Voice controller — " + label;
  }

  function flushAudio() {
    for (const s of liveSources) { try { s.stop(); } catch (_) {} }
    liveSources = [];
    playCursor = 0;
  }

  // ---- receive Chat's voice output (PCM 16-bit mono 24 kHz) ---------------
  function handleBinaryAudio(buf) {
    if (!audioCtx) return;
    const pcm = new Int16Array(buf);
    if (!pcm.length) return;
    const abuf = audioCtx.createBuffer(1, pcm.length, 24000);
    const ch = abuf.getChannelData(0);
    for (let i = 0; i < pcm.length; i++) ch[i] = pcm[i] / 32768;
    const src = audioCtx.createBufferSource();
    src.buffer = abuf;
    src.connect(audioCtx.destination);
    const startAt = Math.max(playCursor, audioCtx.currentTime + 0.06);
    src.start(startAt);
    playCursor = startAt + abuf.duration;
    liveSources.push(src);
    src.onended = () => { liveSources = liveSources.filter((x) => x !== src); };
  }

  // ---- microphone capture (PCM 16-bit mono 16 kHz) -----------------------
  async function startMic() {
    try {
      micStream = await navigator.mediaDevices.getUserMedia({ audio: {
        sampleRate: 16000, channelCount: 1, echoCancellation: true,
        noiseSuppression: true, autoGainControl: true,
      }, video: false });
    } catch (e) {
      setError("Microphone access denied: " + e.message);
      return false;
    }
    const micCtx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
    const source = micCtx.createMediaStreamSource(micStream);
    // ScriptProcessor is deprecated but has no dependency on worklets and is
    // universally available without extra setup.
    micProcessor = micCtx.createScriptProcessor(4096, 1, 1);
    micProcessor.onaudioprocess = (e) => {
      if (!ws || ws.readyState !== WebSocket.OPEN || muted) return;
      const float32 = e.inputBuffer.getChannelData(0);
      const int16 = new Int16Array(float32.length);
      for (let i = 0; i < float32.length; i++) {
        const s = Math.max(-1, Math.min(1, float32[i]));
        int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      ws.send(int16.buffer);
    };
    source.connect(micProcessor);
    micProcessor.connect(micCtx.destination);
    return true;
  }

  function stopMic() {
    try { micProcessor && micProcessor.disconnect(); } catch (_) {}
    micProcessor = null;
    if (micStream) {
      micStream.getTracks().forEach((t) => t.stop());
      micStream = null;
    }
  }

  // ---- WebSocket lifecycle ------------------------------------------------
  function connectWs() {
    const proto = location.protocol === "https:" ? "wss://" : "ws://";
    ws = new WebSocket(proto + location.host + "/ws/remote-audio");
    ws.binaryType = "arraybuffer";

    ws.onopen = () => {
      connected = true;
      setStatus("Listening", "vc-listening");
      setError("");
      startBtn.hidden = true;
      stopBtn.hidden = false;
      goodbyeBtn.hidden = false;
      muteBtn.hidden = false;
    };

    ws.onmessage = (e) => {
      if (typeof e.data === "string") {
        // Control message (e.g. {"type":"clear"})
        flushAudio();
        return;
      }
      handleBinaryAudio(e.data);
      setStatus("Speaking", "vc-speaking");
      // Reset to listening after audio drains
      setTimeout(() => {
        if (connected && stateEl.classList.contains("vc-speaking")) {
          setStatus("Listening", "vc-listening");
        }
      }, 600);
    };

    ws.onclose = (e) => {
      connected = false;
      if (e.code === 4401) {
        setStatus("Not signed in", "vc-error");
        setError("Session expired — please sign in again and return here.");
      } else if (e.code === 4409) {
        setStatus("Busy", "vc-warn");
        setError("Another device is already using the microphone. Disconnect it first.");
      } else if (e.code === 4410) {
        // The lease is only revoked by an explicit goodbye or the rolling
        // inactivity timeout -- never by the Stop button, which keeps the
        // socket and lease alive.
        setStatus("Session ended", "vc-warn");
        setError("Voice session ended (goodbye or inactivity). Press Start voice again.");
      } else if (e.code === 4403) {
        setStatus("Unavailable", "vc-error");
        setError("Cloud gateway is disabled — enable it in Settings.");
      } else if (connected || e.wasClean) {
        setStatus("Disconnected", "vc-warn");
        setError("Connection closed. Press Start voice to reconnect.");
      }
      flushAudio();
      stopMic();
      startBtn.hidden = false;
      stopBtn.hidden = true;
      goodbyeBtn.hidden = true;
      muteBtn.hidden = true;
      if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
    };

    ws.onerror = () => {
      setError("WebSocket error — see browser console.");
    };
  }

  // ---- button handlers ----------------------------------------------------
  startBtn.addEventListener("click", async () => {
    setError("");
    setStatus("Connecting...", "vc-connecting");
    startBtn.disabled = true;

    // AudioContext must be created in a user gesture.
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    await audioCtx.resume();

    const ok = await startMic();
    if (!ok) {
      setStatus("Mic error", "vc-error");
      startBtn.disabled = false;
      if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
      return;
    }

    startBtn.disabled = false;
    connectWs();
  });

  // Stop only flushes Chat's spoken output. The WebSocket, microphone, and
  // voice-session lease all stay alive: Chat keeps listening and the next turn
  // needs no wake word. It must NEVER close the socket or end the session.
  stopBtn.addEventListener("click", async () => {
    flushAudio();  // silence local playback immediately
    try {
      await fetch("/api/stop", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: "{}",
      });
    } catch (_) {}
    if (connected) setStatus("Listening", "vc-listening");
    setError("");
  });

  // Goodbye ends the active conversation and revokes the lease. Chat returns
  // to wake-word mode; the server closes this socket with code 4410.
  goodbyeBtn.addEventListener("click", async () => {
    try {
      await fetch("/api/session/end", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: "{}",
      });
    } catch (_) {}
    setStatus("Session ended", "vc-warn");
    setError("Voice session ended (goodbye). Press Start voice again.");
  });

  muteBtn.addEventListener("click", async () => {
    muted = !muted;
    muteBtn.textContent = muted ? "Unmute" : "Mute";
    muteBtn.classList.toggle("muted", muted);
    // Also tell the server mute state via the dashboard mute API so the
    // server-side mute enforcement stays consistent.
    try {
      await fetch("/api/mute", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-csrf": csrf },
        body: JSON.stringify({ muted }),
      });
    } catch (_) {}
    setStatus(muted ? "Muted" : "Listening", muted ? "vc-muted" : "vc-listening");
  });

  // ---- live state via SSE (update state dot) ------------------------------
  function startEvents() {
    let es;
    try { es = new EventSource("/events"); } catch (_) { return; }
    const dot = document.getElementById("vc-dot");
    es.onmessage = (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch (_) { return; }
      if (msg.topic === "state" && dot) {
        dot.className = "brand-dot " + msg.state;
      }
    };
  }

  if (document.readyState === "complete") {
    setTimeout(startEvents, 0);
  } else {
    window.addEventListener("load", () => setTimeout(startEvents, 50));
  }

  // ---- initial state -------------------------------------------------------
  setStatus("Ready — press Start voice", "");
  stopBtn.hidden = true;
  goodbyeBtn.hidden = true;
  muteBtn.hidden = true;
})();
