// Real-execution check of the Chat dashboard: loads every page in jsdom with
// scripts ENABLED (same ordering rules as a browser), lets the page's own
// fetches run against the live server, then inspects the rendered DOM for
// failures like "api is not defined".
import { JSDOM, VirtualConsole } from "jsdom";

const BASE = "http://127.0.0.1:8756";
let cookie = "";

function saveCookies(r) {
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  for (const c of sc) {
    const kv = c.split(";")[0];
    const name = kv.split("=")[0];
    const parts = cookie ? cookie.split("; ").filter((p) => !p.startsWith(name + "=")) : [];
    parts.push(kv);
    cookie = parts.join("; ");
  }
}

async function req(path, opts = {}) {
  const r = await fetch(BASE + path, { redirect: "manual", ...opts, headers: { ...(opts.headers || {}), cookie } });
  saveCookies(r);
  return r;
}

// ---- wait for server ----
let up = false;
for (let i = 0; i < 30; i++) {
  try { await fetch(BASE + "/setup"); up = true; break; } catch { await new Promise((r) => setTimeout(r, 500)); }
}
if (!up) { console.log("FATAL: server not reachable"); process.exit(2); }

// ---- first-run setup ----
const form = new URLSearchParams();
form.set("password", "Testpass123");
form.set("confirm", "Testpass123");
let r = await req("/setup", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: form.toString() });
console.log("setup POST:", r.status, "(303 = ok)");

// ---- per-page browser-like test ----
const pages = ["/", "/credentials", "/usage", "/logs", "/timers", "/reminders", "/memory", "/devices", "/providers", "/settings", "/voice-controller"];
const mustContain = {
  "/credentials": "No Gemini keys yet",
  "/usage": "Nothing yet",
};
let failures = 0;

for (const path of pages) {
  const resp = await req(path);
  if (resp.status !== 200) { console.log(`FAIL ${path}: HTTP ${resp.status}`); failures++; continue; }
  const html = await resp.text();

  // static ordering guarantees, independent of jsdom behavior
  const headScript = html.indexOf('src="/static/app.js');
  const firstInline = html.indexOf("<script>");
  if (headScript === -1) { console.log(`FAIL ${path}: app.js tag missing`); failures++; continue; }
  if (firstInline !== -1 && headScript > firstInline) { console.log(`FAIL ${path}: app.js loads AFTER inline scripts`); failures++; continue; }
  if (!/app\.js\?v=\d+\.\d+\.\d+/.test(html)) { console.log(`WARN ${path}: cache-buster version missing on app.js tag`); }

  const errors = [];
  const vc = new VirtualConsole();
  vc.on("jsdomError", (e) => errors.push("jsdomError: " + ((e && e.message) || e)));
  vc.on("error", (...a) => errors.push("console.error: " + a.join(" ")));

  const dom = new JSDOM(html, {
    url: BASE + path,
    runScripts: "dangerously",
    resources: "usable",
    pretendToBeVisual: true,
    virtualConsole: vc,
    beforeParse(window) {
      window.alert = () => {};
      window.fetch = (p, o = {}) => {
        const { signal, ...rest } = o; // node fetch rejects jsdom's AbortSignal
        rest.headers = { ...(rest.headers || {}), cookie };
        return fetch(new URL(p, BASE + path).href, rest);
      };
      // no EventSource stub on purpose: app.js must survive its absence
    },
  });

  await new Promise((res) => {
    let done = false;
    const finish = () => { if (!done) { done = true; setTimeout(res, 900); } }; // settle fetches after load
    dom.window.addEventListener("load", finish);
    setTimeout(finish, 3000); // in case load never fires
  });

  const text = dom.serialize();
  const bad = [];
  if (/is not defined/i.test(text)) bad.push('page shows "... is not defined"');
  if (/Could not reach Chat/i.test(text)) bad.push("page shows could-not-reach error");
  if (mustContain[path] && !text.includes(mustContain[path])) bad.push(`missing expected content: "${mustContain[path]}"`);
  // The theme toggle shows its visible label through CSS content, which screen
  // readers cannot rely on -- so the button must carry a real name in the DOM.
  const themeBtn = dom.window.document.getElementById("theme-btn");
  if (themeBtn && !(themeBtn.getAttribute("aria-label") || "").trim() && !themeBtn.textContent.trim()) {
    bad.push("theme toggle has no accessible name (needs aria-label or text)");
  }
  for (const e of errors) bad.push(e);

  if (bad.length) { console.log(`FAIL ${path}:\n   - ` + bad.join("\n   - ")); failures++; }
  else console.log(`PASS ${path}`);
  dom.window.close();
}

// ---- end-to-end: add a Gemini key exactly like the page's Add button ----
r = await req("/credentials");
const meta = (await r.text()).match(/name="csrf" content="([^"]+)"/);
const csrf = meta ? meta[1] : "";
r = await req("/api/credentials", {
  method: "POST",
  headers: { "content-type": "application/json", "x-csrf": csrf },
  body: JSON.stringify({ provider: "gemini", secret: "AIzaSyFakeKeyForHarness0000000000000000", project_label: "harness" }),
});
const bodyText = await r.text();
console.log("add-key POST:", r.status, bodyText.slice(0, 140));
if (r.status === 200) {
  const list = await (await req("/api/credentials")).json();
  console.log("keys now stored:", list.projects.length);
} else if (r.status === 400 && bodyText.includes("rejected")) {
  console.log("(Google reachable from sandbox and rejected the fake key -- endpoint + csrf flow work)");
} else {
  console.log("UNEXPECTED add-key result"); failures++;
}

console.log(failures === 0 ? "ALL PAGE CHECKS PASSED" : `${failures} FAILURES`);
process.exit(failures === 0 ? 0 : 1);
