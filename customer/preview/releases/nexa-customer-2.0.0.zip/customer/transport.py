"""Typed HTTP transport for protocol 2 customer installations."""

from __future__ import annotations

import json
import platform as host_platform
import re
from dataclasses import dataclass
from typing import Any

import httpx

from .protocol import (
    MAX_COMMAND_BYTES,
    PROTOCOL_VERSION,
    ProtocolError,
    cloud_origin,
    sanitize_result,
)


class TransportError(RuntimeError):
    """A temporary or authoritative cloud transport failure."""

    def __init__(self, message: str, *, status: int | None = None, revoked: bool = False):
        super().__init__(message)
        self.status = status
        self.revoked = revoked


@dataclass(frozen=True)
class Enrollment:
    installation_id: str
    workspace_id: str
    credential: str
    protocol_version: int


class RuntimeTransport:
    """No arbitrary HTTP surface: paths and JSON bodies are fixed here."""

    def __init__(
        self,
        server: str,
        credential: str | None = None,
        *,
        worker_nonce: str | None = None,
        timeout: float = 35.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.server = cloud_origin(server)
        self.credential = credential
        self.installation_id: str | None = None
        self.workspace_id: str | None = None
        self.worker_nonce = worker_nonce
        self.timeout = max(1.0, min(90.0, float(timeout)))
        self._client = client
        self._owns_client = client is None
        self.last_inventory_generations: dict[str, int] = {}

    async def open(self) -> None:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.server,
                timeout=httpx.Timeout(self.timeout, connect=min(10.0, self.timeout)),
                follow_redirects=False,
                headers={"Accept": "application/json", "X-Nexa-Protocol": "2"},
            )

    async def close(self) -> None:
        if self._owns_client and self._client is not None:
            await self._client.aclose()
        self._client = None if self._owns_client else self._client

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("runtime transport is not open")
        return self._client

    @staticmethod
    def _json(response: httpx.Response) -> dict[str, Any]:
        if len(response.content) > MAX_COMMAND_BYTES:
            raise TransportError("cloud response is too large", status=response.status_code)
        try:
            body = response.json()
        except (ValueError, json.JSONDecodeError) as exc:
            raise TransportError("cloud returned invalid JSON", status=response.status_code) from exc
        if not isinstance(body, dict):
            raise TransportError("cloud returned an invalid object", status=response.status_code)
        return body

    @staticmethod
    def _canonical_arch() -> str:
        machine = host_platform.machine().strip().lower()
        return {
            "x86_64": "x64",
            "amd64": "x64",
            "aarch64": "arm64",
            "armv8": "arm64",
            "arm64": "arm64",
            "i386": "x86",
            "i686": "x86",
        }.get(machine, machine[:32] or "unknown")

    def _headers(self) -> dict[str, str]:
        if not self.credential:
            raise TransportError("installation is not enrolled")
        headers = {"Authorization": f"Bearer {self.credential}"}
        if self.worker_nonce:
            headers["X-Nexa-Update-Worker"] = self.worker_nonce
        return headers

    @staticmethod
    def _raise(response: httpx.Response) -> None:
        detail = ""
        try:
            body = response.json()
            error = body.get("error") if isinstance(body, dict) else None
            if isinstance(error, dict):
                code = error.get("code")
                message = error.get("message")
                if isinstance(code, str) or isinstance(message, str):
                    detail = f": {code or 'request_failed'} {message or ''}".rstrip()
        except (ValueError, TypeError):
            pass
        if response.status_code in (401, 403):
            raise TransportError(
                f"installation credential is revoked or unauthorized{detail}",
                status=response.status_code,
                revoked=True,
            )
        if response.status_code >= 400:
            raise TransportError(
                f"cloud request failed ({response.status_code}){detail}",
                status=response.status_code,
            )

    async def enroll(
        self,
        *,
        token: str,
        name: str,
        kind: str = "connector",
        platform: str,
        version: str,
        arch: str | None = None,
        schema_version: int = 2,
    ) -> Enrollment:
        if not isinstance(token, str) or not 1 <= len(token) <= 200:
            raise ProtocolError("pairing token is invalid")
        if kind not in {"connector", "native"}:
            raise ProtocolError("installation kind is not permitted")
        if platform not in {"windows", "linux", "macos", "android", "ios"}:
            raise ProtocolError("installation platform is not permitted")
        if not isinstance(version, str) or not version or len(version) > 64:
            raise ProtocolError("installation version is invalid")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 80:
            raise ProtocolError("installation name is invalid")
        if not isinstance(schema_version, int) or isinstance(schema_version, bool) or schema_version != 2:
            raise ProtocolError("runtime schema version is invalid")
        canonical_arch = arch.strip() if isinstance(arch, str) and arch.strip() else self._canonical_arch()
        if not 1 <= len(canonical_arch) <= 32 or not re.fullmatch(r"[A-Za-z0-9._-]+", canonical_arch):
            raise ProtocolError("runtime architecture is invalid")
        response = await self.client.post(
            "/api/platform/runtime/enroll",
            json={
                "token": token,
                "name": " ".join(name.split())[:80],
                "kind": kind,
                "platform": platform,
                "arch": canonical_arch,
                "schemaVersion": schema_version,
                "version": version,
                "protocolVersion": PROTOCOL_VERSION,
            },
        )
        self._raise(response)
        body = self._json(response)
        if set(body) - {"installationId", "workspaceId", "credential", "protocolVersion"}:
            raise ProtocolError("enrollment response contains unknown fields")
        if (
            not isinstance(body.get("installationId"), str)
            or not isinstance(body.get("workspaceId"), str)
            or not isinstance(body.get("credential"), str)
            or body.get("protocolVersion") != PROTOCOL_VERSION
        ):
            raise ProtocolError("enrollment response is not protocol 2")
        return Enrollment(
            body["installationId"],
            body["workspaceId"],
            body["credential"],
            PROTOCOL_VERSION,
        )

    async def poll(self, *, wait_seconds: int = 25) -> dict[str, Any]:
        """Poll also serves as the heartbeat; the server timestamps it."""

        wait_seconds = max(0, min(25, int(wait_seconds)))
        response = await self.client.get(
            "/api/platform/runtime/poll",
            params={"waitSeconds": wait_seconds, "limit": 20},
            headers=self._headers(),
        )
        self._raise(response)
        body = self._json(response)
        allowed = {"commands", "serverTime"}
        if (
            set(body) != allowed
            or not isinstance(body.get("serverTime"), str)
            or not body["serverTime"]
        ):
            raise ProtocolError("poll response contains unknown fields")
        commands = body.get("commands", [])
        if not isinstance(commands, list) or len(commands) > 100:
            raise ProtocolError("poll commands are invalid or too many")
        return body

    async def ack_command(
        self,
        command_id: str,
        *,
        lease_token: str,
        state: str,
        result: Any = None,
        error: str | None = None,
    ) -> None:
        if state not in {"succeeded", "failed"}:
            raise ProtocolError("ACK state is invalid")
        body: dict[str, Any] = {"leaseToken": lease_token, "state": state}
        if result is not None:
            body["result"] = sanitize_result(result)
        if error:
            body["error"] = str(error)[:500]
        response = await self.client.post(
            f"/api/platform/runtime/commands/{command_id}/ack",
            json=body,
            headers=self._headers(),
        )
        self._raise(response)
        parsed = self._json(response) if response.content else {}
        if set(parsed) - {
            "id",
            "workspaceId",
            "installationId",
            "type",
            "status",
            "payload",
            "result",
            "error",
            "createdAt",
            "expiresAt",
            "claimedAt",
            "completedAt",
        }:
            raise ProtocolError("command ACK response contains unknown fields")

    async def authorize_command(self, command_id: str, *, lease_token: str) -> dict[str, Any]:
        response = await self.client.post(
            f"/api/platform/runtime/commands/{command_id}/authorize",
            json={"leaseToken": lease_token},
            headers=self._headers(),
        )
        self._raise(response)
        body = self._json(response)
        if set(body) != {"executionToken", "nonCancellable", "expiresAt"}:
            raise ProtocolError("command authorization response contains unknown fields")
        if (
            not isinstance(body["executionToken"], str)
            or not isinstance(body["nonCancellable"], bool)
            or not isinstance(body["expiresAt"], str)
        ):
            raise ProtocolError("command authorization response is invalid")
        return body

    async def inventory(self, devices: list[dict[str, Any]]) -> dict[str, str]:
        """Publish only the public device shape; local target data is excluded."""

        clean: list[dict[str, Any]] = []
        for device in devices[:100]:
            allowed = {"id", "name", "provider", "capabilities", "online"}
            if not isinstance(device, dict) or set(device) - allowed - {"installationId", "generation"}:
                raise ProtocolError("inventory contains private or unknown fields")
            if not isinstance(device.get("id"), str) or not device["id"]:
                raise ProtocolError("inventory device has no local id")
            if (
                not isinstance(device.get("name"), str)
                or not 1 <= len(device["name"]) <= 120
                or device.get("provider") not in {"lg", "roku"}
                or not isinstance(device.get("capabilities"), list)
                or len(device["capabilities"]) > 32
                or any(not isinstance(capability, str) for capability in device["capabilities"])
                or not isinstance(device.get("online"), bool)
                or (
                    "generation" in device
                    and (
                        isinstance(device["generation"], bool)
                        or not isinstance(device["generation"], int)
                        or device["generation"] < 0
                    )
                )
            ):
                raise ProtocolError("inventory device metadata is invalid")
            clean.append(
                {
                    "localId": device["id"],
                    **{key: device[key] for key in allowed - {"id"} if key in device},
                    **({"generation": device["generation"]} if "generation" in device else {}),
                }
            )
        response = await self.client.post(
            "/api/platform/runtime/inventory",
            json={"devices": clean},
            headers=self._headers(),
        )
        self._raise(response)
        body = self._json(response)
        values = body.get("devices")
        if set(body) != {"devices"} or not isinstance(values, list) or len(values) > 100:
            raise ProtocolError("inventory response is invalid")
        mapping: dict[str, str] = {}
        generations: dict[str, int] = {}
        for device in values:
            if (
                not isinstance(device, dict)
                or set(device)
                - {"id", "installationId", "localId", "name", "provider", "capabilities", "online", "generation"}
                or not isinstance(device.get("id"), str)
                or not isinstance(device.get("localId"), str)
                or not isinstance(device.get("installationId"), str)
                or (
                    "generation" in device
                    and (
                        isinstance(device["generation"], bool)
                        or not isinstance(device["generation"], int)
                        or device["generation"] < 0
                    )
                )
                or (
                    self.installation_id is not None
                    and device["installationId"] != self.installation_id
                )
            ):
                raise ProtocolError("inventory response contains unknown or private fields")
            if device["id"] in mapping or device["localId"] in mapping.values():
                raise ProtocolError("inventory response contains duplicate device mappings")
            mapping[device["id"]] = device["localId"]
            if "generation" in device:
                generations[device["localId"]] = device["generation"]
        if len(mapping) != len(clean):
            raise ProtocolError("inventory response omitted a device mapping")
        self.last_inventory_generations = generations
        return mapping

    async def desired_update(self) -> dict[str, Any] | None:
        response = await self.client.get(
            "/api/platform/runtime/updates",
            headers=self._headers(),
        )
        self._raise(response)
        body = self._json(response)
        if set(body) - {"updates", "terminal", "busy"}:
            raise ProtocolError("update response contains unknown fields")
        values = body.get("updates")
        if not isinstance(values, list) or len(values) > 20:
            raise ProtocolError("desired updates are invalid")
        terminal = body.get("terminal", [])
        if not isinstance(terminal, list) or len(terminal) > 20:
            raise ProtocolError("terminal update proofs are invalid")
        busy = body.get("busy", [])
        if not isinstance(busy, list) or len(busy) > 20:
            raise ProtocolError("busy update proofs are invalid")
        for value in [*values, *terminal]:
            self._validate_update_assignment(value)
            if (
                self.installation_id is not None
                and value["installationId"] != self.installation_id
            ):
                raise ProtocolError("update assignment belongs to another installation")
        for value in busy:
            if (
                not isinstance(value, dict)
                or set(value) != {"assignmentId", "rolloutId", "reason"}
                or not isinstance(value["assignmentId"], str)
                or not value["assignmentId"]
                or not isinstance(value["rolloutId"], str)
                or not value["rolloutId"]
                or value["reason"] not in {
                    "owned_by_other_worker",
                    "lease_token_unavailable",
                    "installation_has_active_update",
                }
            ):
                raise ProtocolError("busy update proof is invalid")
        if not values:
            return None
        return dict(values[0])

    @staticmethod
    def _validate_update_assignment(value: Any) -> None:
        if not isinstance(value, dict):
            raise ProtocolError("desired update is invalid")
        allowed = {
            "assignmentId",
            "rolloutId",
            "installationId",
            "assignmentEpoch",
            "generation",
            "leaseToken",
            "state",
            "version",
            "sha256",
            "url",
            "size",
            "protocolVersion",
            "schemaMin",
            "schemaMax",
            "actualVersion",
            "actualSha256",
            "error",
            # Signed manifest fields are included by the release worker when
            # it hands a catalog target to a connector.
            "edition",
            "channel",
            "platform",
            "arch",
            "signature",
            "rollbackOf",
            "approvedTargetAuthority",
            "previousVersion",
        }
        if set(value) - allowed:
            raise ProtocolError("desired update contains unknown fields")
        required = {
            "assignmentId",
            "rolloutId",
            "installationId",
            "assignmentEpoch",
            "generation",
            "leaseToken",
            "state",
            "edition",
            "channel",
            "platform",
            "arch",
            "version",
            "url",
            "sha256",
            "size",
            "protocolVersion",
            "schemaMin",
            "schemaMax",
            "signature",
        }
        if not required.issubset(value):
            raise ProtocolError("desired update is missing signed assignment fields")
        if (
            not isinstance(value["assignmentId"], str)
            or not value["assignmentId"]
            or not isinstance(value["installationId"], str)
            or isinstance(value["assignmentEpoch"], bool)
            or not isinstance(value["assignmentEpoch"], int)
            or value["assignmentEpoch"] < 1
            or isinstance(value["generation"], bool)
            or not isinstance(value["generation"], int)
            or value["generation"] < 1
            or not isinstance(value["leaseToken"], str)
            or not value["leaseToken"]
            or not isinstance(value["state"], str)
            or value["state"] not in {
                "pending",
                "downloading",
                "verified",
                "staged",
                "restarting",
                "running",
                "failed",
                "rolled_back",
            }
            or not isinstance(value["edition"], str)
            or not isinstance(value["channel"], str)
            or not isinstance(value["platform"], str)
            or not isinstance(value["arch"], str)
            or not isinstance(value["version"], str)
            or not value["version"]
            or not isinstance(value["url"], str)
            or not value["url"]
            or not isinstance(value["sha256"], str)
            or not value["sha256"]
            or isinstance(value["size"], bool)
            or not isinstance(value["size"], int)
            or value["size"] < 0
            or value["protocolVersion"] != PROTOCOL_VERSION
            or isinstance(value["schemaMin"], bool)
            or not isinstance(value["schemaMin"], int)
            or value["schemaMin"] < 0
            or isinstance(value["schemaMax"], bool)
            or not isinstance(value["schemaMax"], int)
            or value["schemaMax"] < value["schemaMin"]
            or not isinstance(value["signature"], str)
        ):
            raise ProtocolError("desired update lease or signature metadata is invalid")
        if "rolloutId" in value and (
            not isinstance(value["rolloutId"], str) or not value["rolloutId"]
        ):
            raise ProtocolError("desired update rollout metadata is invalid")
        for field in ("actualVersion", "actualSha256", "error", "previousVersion", "rollbackOf"):
            if field in value and value[field] is not None and (
                not isinstance(value[field], str) or not value[field]
            ):
                raise ProtocolError("update metadata contains an invalid optional field")
        if value.get("error") is not None and len(value["error"]) > 1000:
            raise ProtocolError("update error metadata is too long")
        authority = value.get("approvedTargetAuthority")
        if authority is not None:
            if not isinstance(authority, dict) or set(authority) != {
                "rolloutId",
                "releaseId",
                "target",
                "percentage",
                "revision",
            }:
                raise ProtocolError("rollback authority metadata is invalid")
            target = authority["target"]
            if (
                not isinstance(authority["rolloutId"], str)
                or not authority["rolloutId"]
                or not isinstance(authority["releaseId"], str)
                or not authority["releaseId"]
                or not isinstance(target, dict)
                or set(target) != {"type", "id"}
                or target["type"] not in {"workspace", "installation", "group", "fleet"}
                or not isinstance(target["id"], str)
                or not target["id"]
                or isinstance(authority["percentage"], bool)
                or not isinstance(authority["percentage"], (int, float))
                or authority["percentage"] < 0
                or authority["percentage"] > 100
                or isinstance(authority["revision"], bool)
                or not isinstance(authority["revision"], int)
                or authority["revision"] < 1
            ):
                raise ProtocolError("rollback authority metadata is invalid")
        if value.get("rollbackOf") is None:
            if authority is not None:
                raise ProtocolError("rollback authority is not valid for a forward update")
        elif (
            authority is None
            or not isinstance(value.get("previousVersion"), str)
            or not value["previousVersion"]
            or authority.get("rolloutId") != value["rollbackOf"]
        ):
            raise ProtocolError("rollback authority metadata is incomplete")
        return

    async def ack_update(
        self,
        *,
        assignment_id: str,
        assignment_epoch: int,
        generation: int,
        lease_token: str,
        state: str,
        version: str | None = None,
        sha256: str | None = None,
        error: str | None = None,
    ) -> None:
        if state not in {
            "pending",
            "downloading",
            "verified",
            "staged",
            "restarting",
            "running",
            "failed",
            "rolled_back",
        }:
            raise ProtocolError("update state is invalid")
        body: dict[str, Any] = {
            "assignmentId": assignment_id,
            "assignmentEpoch": assignment_epoch,
            "generation": generation,
            "leaseToken": lease_token,
            "state": state,
        }
        if version is not None:
            body["actualVersion"] = version
        if sha256 is not None:
            body["actualSha256"] = sha256
        if error:
            body["error"] = str(error)[:1000]
        response = await self.client.post(
            "/api/platform/runtime/updates",
            json=body,
            headers=self._headers(),
        )
        self._raise(response)