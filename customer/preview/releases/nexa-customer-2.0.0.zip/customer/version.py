"""Customer connector version; release packaging owns the final 2.0.0 value."""

APP_VERSION = "2.0.0"