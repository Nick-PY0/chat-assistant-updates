"""Command dispatch with validation, generation fencing, and ACK semantics."""

from __future__ import annotations

from typing import Any, Awaitable, Callable
import re

from .devices import DeviceRegistry
from .ledger import CommandLedger
from .protocol import Command, ProtocolError, sanitize_result
from .transport import RuntimeTransport


class CommandProcessor:
    def __init__(
        self,
        devices: DeviceRegistry,
        ledger: CommandLedger,
        transport: RuntimeTransport,
    ) -> None:
        self.devices = devices
        self.ledger = ledger
        self.transport = transport
        self._inventory_callback: Callable[[], Awaitable[None]] | None = None

    def set_inventory_callback(self, callback: Callable[[], Awaitable[None]]) -> None:
        self._inventory_callback = callback

    @staticmethod
    def _retry_safe(command: Command) -> bool:
        if command.command_type in {"device.discover", "device.status", "device.apps", "device.remove"}:
            return True
        if command.command_type == "device.link":
            return False
        # Never replay any physical control after an uncertain process crash.
        return False

    @staticmethod
    def _safe_error(exc: Exception) -> str:
        """Do not let adapter error wording publish private LAN targets."""

        message = str(exc)[:4096] or "customer command failed"
        message = re.sub(
            r"(?<![\w:])(?:\d{1,3}\.){3}\d{1,3}(?![\w:])",
            "<private-device>",
            message,
        )
        message = re.sub(r"(?i)\b(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b", "<private-device>", message)
        return message

    async def process(self, wire: Any) -> None:
        try:
            command = Command.from_wire(wire)
        except ProtocolError:
            # A malformed command has no trusted command identity.  It is
            # discarded; importantly, malformed payloads never reach an
            # adapter and no guessed ACK can be forged for another command.
            return
        if (
            self.transport.installation_id
            and command.installation_id != self.transport.installation_id
        ):
            # A bearer alone is not permission to execute a command belonging
            # to another installation.
            return
        if self.transport.workspace_id and command.workspace_id != self.transport.workspace_id:
            return

        decision = self.ledger.begin(
            command.idempotency_key,
            command.command_id,
            command.command_type,
            retry_safe=self._retry_safe(command),
        )
        if not decision.execute:
            if decision.state == "duplicate":
                await self.transport.ack_command(
                    command.command_id,
                    lease_token=command.lease_token,
                    state="succeeded" if not decision.error else "failed",
                    result=decision.result,
                    error=decision.error or None,
                )
            else:
                await self.transport.ack_command(
                    command.command_id,
                    lease_token=command.lease_token,
                    state="failed",
                    error=decision.error,
                )
            return

        try:
            # The lease is not sufficient authorization for a physical
            # operation.  The backend rechecks revocation, expiry, installation
            # epoch, and non-cancellable status in one transaction immediately
            # before this connector touches a LAN adapter.
            await self.transport.authorize_command(
                command.command_id, lease_token=command.lease_token
            )
            result = await self._dispatch(command)
            result = sanitize_result(result)
            self.ledger.finish(command.idempotency_key, succeeded=True, result=result)
            await self.transport.ack_command(
                command.command_id,
                lease_token=command.lease_token,
                state="succeeded",
                result=result,
            )
            if command.command_type in {
                "device.discover",
                "device.link",
                "device.remove",
            } and self._inventory_callback is not None:
                await self._inventory_callback()
        except Exception as exc:
            message = self._safe_error(exc)
            self.ledger.finish(command.idempotency_key, succeeded=False, error=message)
            await self.transport.ack_command(
                command.command_id,
                lease_token=command.lease_token,
                state="failed",
                error=message,
            )

    async def _dispatch(self, command: Command) -> dict[str, Any]:
        payload = dict(command.payload)
        if "deviceId" in payload:
            payload["deviceId"] = self.devices.local_id(payload["deviceId"])
        kind = command.command_type
        if kind == "device.discover":
            return {"devices": await self.devices.discover(payload["provider"])}
        if kind == "device.link":
            return await self.devices.link(payload["deviceId"], payload["generation"])
        if kind == "device.status":
            return await self.devices.status(payload["deviceId"], payload["generation"])
        if kind == "device.control":
            return await self.devices.control(payload)
        if kind == "device.apps":
            return await self.devices.apps(
                payload["deviceId"], payload["generation"], payload["refresh"]
            )
        if kind == "device.remove":
            return await self.devices.remove(payload["deviceId"], payload["generation"])
        raise ProtocolError("command type is not permitted")