"""The Nexa customer-only LAN connector.

This package is intentionally separate from the owner desktop runtime.  It
contains only the enrolled runtime transport, the two permitted TV adapters,
and the customer updater.  In particular it does not import ``Runtime``,
dashboard, voice, broadcast, or owner credentials.
"""

from .protocol import PROTOCOL_VERSION

__all__ = ["PROTOCOL_VERSION"]