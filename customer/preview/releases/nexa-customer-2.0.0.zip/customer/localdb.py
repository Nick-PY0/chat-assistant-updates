"""A deliberately small private store for customer LAN state.

It is not the owner database and does not run owner migrations.  The existing
LG/Roku managers are reused against this narrow compatibility layer, which
provides only the tables and methods those adapters need.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import aiosqlite


class CustomerDatabase:
    """Private customer-only SQLite database.

    No credentials, transcripts, schedules, broadcast rows, or owner settings
    are present in this schema.  The LG pairing blob is encrypted by the
    customer runtime before it reaches ``app_settings``.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser().resolve()
        self._conn: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(mode=0o600, exist_ok=True)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA synchronous=FULL")
        await self._conn.execute("PRAGMA foreign_keys=ON")
        await self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS events_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL DEFAULT (datetime('now')),
                level TEXT NOT NULL,
                component TEXT NOT NULL,
                message TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS lg_webos_devices (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL DEFAULT 'LG TV',
                host TEXT NOT NULL,
                mac_address TEXT NOT NULL DEFAULT '',
                enabled INTEGER NOT NULL DEFAULT 0,
                paired INTEGER NOT NULL DEFAULT 0,
                last_state_json TEXT NOT NULL DEFAULT '{}',
                last_seen_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS roku_ecp_devices (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL DEFAULT 'Roku TV',
                host TEXT NOT NULL DEFAULT '',
                enabled INTEGER NOT NULL DEFAULT 0,
                linked INTEGER NOT NULL DEFAULT 0,
                last_seen_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            """
        )
        await self._conn.commit()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("customer database is not open")
        return self._conn

    async def execute(self, sql: str, params: tuple = ()) -> int:
        async with self._lock:
            cursor = await self.conn.execute(sql, params)
            await self.conn.commit()
            return cursor.rowcount

    async def fetchone(self, sql: str, params: tuple = ()):
        async with self._lock:
            cursor = await self.conn.execute(sql, params)
            return await cursor.fetchone()

    async def fetchall(self, sql: str, params: tuple = ()) -> list:
        async with self._lock:
            cursor = await self.conn.execute(sql, params)
            return list(await cursor.fetchall())

    async def get_setting(self, key: str, default: str | None = None) -> str | None:
        row = await self.fetchone("SELECT value FROM app_settings WHERE key=?", (key,))
        return row["value"] if row else default

    async def set_setting(self, key: str, value: str) -> None:
        await self.execute(
            "INSERT INTO app_settings(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )

    async def delete_setting(self, key: str) -> None:
        await self.execute("DELETE FROM app_settings WHERE key=?", (key,))

    async def log(self, level: str, component: str, message: str) -> None:
        # Adapter messages are bounded before they enter this private log.
        await self.execute(
            "INSERT INTO events_log(level,component,message) VALUES(?,?,?)",
            (str(level)[:16], str(component)[:64], str(message)[:1000]),
        )
        await self.execute(
            "DELETE FROM events_log WHERE id NOT IN "
            "(SELECT id FROM events_log ORDER BY id DESC LIMIT 500)"
        )


def ensure_customer_directory(path: str | Path) -> Path:
    root = Path(path).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    try:
        root.chmod(0o700)
    except OSError:
        pass
    if root.is_symlink():
        raise ValueError("customer data directory may not be a symlink")
    return root