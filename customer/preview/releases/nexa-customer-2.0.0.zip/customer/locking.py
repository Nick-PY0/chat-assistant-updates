"""Dependency-free OS locks used by the customer package."""

from __future__ import annotations

import contextlib
import errno
import os
from pathlib import Path


class LockError(RuntimeError):
    pass


class FileLock:
    def __init__(self, path: Path, fd: int) -> None:
        self.path, self.fd = path, fd
        self.released = False

    def release(self) -> None:
        if self.released:
            return
        try:
            if os.name == "nt":
                import msvcrt

                os.lseek(self.fd, 0, os.SEEK_SET)
                with contextlib.suppress(OSError):
                    msvcrt.locking(self.fd, msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                with contextlib.suppress(OSError):
                    fcntl.flock(self.fd, fcntl.LOCK_UN)
        finally:
            os.close(self.fd)
            self.released = True

    def __enter__(self) -> "FileLock":
        return self

    def __exit__(self, *_args) -> None:
        self.release()


def acquire(path: str | Path) -> FileLock | None:
    raw_target = Path(path).expanduser()
    if raw_target.is_symlink():
        raise LockError("customer lock may not be a symlink")
    target = raw_target.resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(target, os.O_RDWR | os.O_CREAT, 0o600)
    except OSError as exc:
        raise LockError(f"cannot open customer lock: {exc}") from exc
    try:
        if os.name == "nt":
            import msvcrt

            if os.fstat(fd).st_size == 0:
                os.write(fd, b"\0")
            os.lseek(fd, 0, os.SEEK_SET)
            msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        os.close(fd)
        if exc.errno not in {errno.EACCES, errno.EAGAIN, errno.EWOULDBLOCK} and getattr(
            exc, "winerror", None
        ) not in {32, 33}:
            raise LockError(f"cannot lock customer directory: {exc}") from exc
        return None
    return FileLock(target, fd)