"""Crash-durable command idempotency for the connector."""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any


class LedgerDecision:
    __slots__ = ("execute", "state", "result", "error")

    def __init__(self, execute: bool, state: str, result: Any = None, error: str = "") -> None:
        self.execute = execute
        self.state = state
        self.result = result
        self.error = error


class CommandLedger:
    """Persist every command claim before making a physical device request.

    A ``processing`` row is intentionally not silently retried after a process
    crash.  A button/key press is non-idempotent and might have reached the TV
    just before power loss.  Read/status/link-removal operations are safe to
    retry explicitly, but the connector still returns an ``uncertain`` result
    for a non-idempotent replay.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).expanduser().resolve()
        self._lock = threading.RLock()
        self._db: sqlite3.Connection | None = None

    def open(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(mode=0o600, exist_ok=True)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass
        self._db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.execute(
            """
            CREATE TABLE IF NOT EXISTS command_ledger (
                idempotency_key TEXT PRIMARY KEY,
                command_id TEXT NOT NULL,
                command_type TEXT NOT NULL,
                state TEXT NOT NULL,
                result_json TEXT,
                error TEXT NOT NULL DEFAULT '',
                updated_at REAL NOT NULL
            )
            """
        )

    def close(self) -> None:
        if self._db is not None:
            self._db.close()
            self._db = None

    @property
    def db(self) -> sqlite3.Connection:
        if self._db is None:
            raise RuntimeError("command ledger is not open")
        return self._db

    def begin(self, key: str, command_id: str, command_type: str, *, retry_safe: bool) -> LedgerDecision:
        with self._lock:
            row = self.db.execute(
                "SELECT command_id,command_type,state,result_json,error FROM command_ledger "
                "WHERE idempotency_key=?",
                (key,),
            ).fetchone()
            if row is not None:
                old_id, old_type, state, result_json, error = row
                if state == "succeeded":
                    return LedgerDecision(
                        False,
                        "duplicate",
                        json.loads(result_json) if result_json else None,
                        str(error or ""),
                    )
                if state == "failed":
                    return LedgerDecision(
                        False,
                        "duplicate",
                        json.loads(result_json) if result_json else None,
                        str(error or "command previously failed"),
                    )
                if not retry_safe:
                    return LedgerDecision(
                        False,
                        "uncertain",
                        error="command outcome is uncertain after interruption; "
                        "non-idempotent action was not repeated",
                    )
                # Safe reads can be retried, but the same idempotency key still
                # has one durable row and one eventual ACK.
                self.db.execute(
                    "UPDATE command_ledger SET command_id=?,command_type=?,state='processing',"
                    "result_json=NULL,error='',updated_at=? WHERE idempotency_key=?",
                    (command_id, command_type, time.time(), key),
                )
                return LedgerDecision(True, "retry")
            self.db.execute(
                "INSERT INTO command_ledger(idempotency_key,command_id,command_type,state,updated_at) "
                "VALUES(?,?,?,'processing',?)",
                (key, command_id, command_type, time.time()),
            )
            return LedgerDecision(True, "new")

    def finish(self, key: str, *, succeeded: bool, result: Any = None, error: str = "") -> None:
        with self._lock:
            self.db.execute(
                "UPDATE command_ledger SET state=?,result_json=?,error=?,updated_at=? "
                "WHERE idempotency_key=?",
                (
                    "succeeded" if succeeded else "failed",
                    json.dumps(result, ensure_ascii=False, separators=(",", ":"))
                    if result is not None
                    else None,
                    str(error)[:4096],
                    time.time(),
                    key,
                ),
            )

    def forget_old(self, age_seconds: float = 30 * 24 * 3600) -> None:
        with self._lock:
            self.db.execute(
                "DELETE FROM command_ledger WHERE updated_at < ?",
                (time.time() - max(3600, age_seconds),),
            )