"""Installation and private-storage boundaries for the customer runtime.

The customer process is deliberately given a directory of its own.  This
module keeps that boundary in one place so that credentials, SQLite files,
adapter state, update journals, and the instance lock all receive the same
permissions.  In particular, ``chmod`` is not an ACL on Windows: refusing to
start when the Windows ACL cannot be made private is safer than silently
putting a bearer token in an inherited directory.
"""

from __future__ import annotations

import getpass
import json
import os
from pathlib import Path
from typing import Any


CUSTOMER_INSTALL_MARKER = "customer-installation.json"
PRIVATE_DATA_MARKER = ".nexa-private-data"


class PrivateStorageError(RuntimeError):
    """The selected customer storage is not private enough to use."""


def _windows_account() -> str:
    value = os.environ.get("USERNAME") or getpass.getuser()
    if not value:
        raise PrivateStorageError("Windows account name is unavailable")
    return value


def _windows_acl(path: Path, *, directory: bool) -> None:
    """Replace and verify the complete Windows DACL.

    ``icacls /grant:r`` only replaces the named trustee and leaves unrelated
    explicit ACEs (including a pre-existing Everyone grant) in place.  Use the
    native ACL API to replace the DACL with exactly the current user and
    SYSTEM, mark it protected from inheritance, then inspect the resulting ACL
    before allowing credentials or databases to be opened.
    """

    try:
        import ctypes
        from ctypes import wintypes

        advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        SE_FILE_OBJECT = 1
        DACL_SECURITY_INFORMATION = 0x00000004
        PROTECTED_DACL_SECURITY_INFORMATION = 0x80000000
        FILE_ALL_ACCESS = 0x001F01FF
        SET_ACCESS = 2
        NO_INHERITANCE = 0
        SUB_CONTAINERS_AND_OBJECTS_INHERIT = 0x3
        TRUSTEE_IS_SID = 0
        ACCESS_ALLOWED_ACE_TYPE = 0
        SE_DACL_PROTECTED = 0x1000

        class TRUSTEE_W(ctypes.Structure):
            _fields_ = [
                ("pMultipleTrustee", wintypes.LPVOID),
                ("MultipleTrusteeOperation", wintypes.DWORD),
                ("TrusteeForm", wintypes.DWORD),
                ("TrusteeType", wintypes.DWORD),
                ("ptstrName", wintypes.LPVOID),
            ]

        class EXPLICIT_ACCESS_W(ctypes.Structure):
            _fields_ = [
                ("grfAccessPermissions", wintypes.DWORD),
                ("grfAccessMode", wintypes.DWORD),
                ("grfInheritance", wintypes.DWORD),
                ("Trustee", TRUSTEE_W),
            ]

        class ACE_HEADER(ctypes.Structure):
            _fields_ = [
                ("AceType", wintypes.BYTE),
                ("AceFlags", wintypes.BYTE),
                ("AceSize", wintypes.WORD),
            ]

        class ACCESS_ALLOWED_ACE(ctypes.Structure):
            _fields_ = [
                ("Header", ACE_HEADER),
                ("Mask", wintypes.DWORD),
                ("SidStart", wintypes.DWORD),
            ]

        class ACL_SIZE_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("AceCount", wintypes.DWORD),
                ("AclBytesInUse", wintypes.DWORD),
                ("AclBytesFree", wintypes.DWORD),
            ]

        advapi32.LookupAccountNameW.argtypes = [
            wintypes.LPCWSTR,
            wintypes.LPCWSTR,
            wintypes.LPVOID,
            ctypes.POINTER(wintypes.DWORD),
            wintypes.LPWSTR,
            ctypes.POINTER(wintypes.DWORD),
            ctypes.POINTER(wintypes.DWORD),
        ]
        advapi32.LookupAccountNameW.restype = wintypes.BOOL
        advapi32.OpenProcessToken.argtypes = [
            wintypes.HANDLE,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.HANDLE),
        ]
        advapi32.OpenProcessToken.restype = wintypes.BOOL
        advapi32.GetTokenInformation.argtypes = [
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.DWORD),
        ]
        advapi32.GetTokenInformation.restype = wintypes.BOOL
        advapi32.SetEntriesInAclW.argtypes = [
            wintypes.DWORD,
            ctypes.POINTER(EXPLICIT_ACCESS_W),
            wintypes.LPVOID,
            ctypes.POINTER(wintypes.LPVOID),
        ]
        advapi32.SetEntriesInAclW.restype = wintypes.DWORD
        advapi32.SetNamedSecurityInfoW.argtypes = [
            wintypes.LPWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.LPVOID,
            wintypes.LPVOID,
            wintypes.LPVOID,
            wintypes.LPVOID,
        ]
        advapi32.SetNamedSecurityInfoW.restype = wintypes.DWORD
        advapi32.GetNamedSecurityInfoW.argtypes = [
            wintypes.LPWSTR,
            wintypes.DWORD,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.LPVOID),
            ctypes.POINTER(wintypes.LPVOID),
            ctypes.POINTER(wintypes.LPVOID),
            ctypes.POINTER(wintypes.LPVOID),
            ctypes.POINTER(wintypes.LPVOID),
        ]
        advapi32.GetNamedSecurityInfoW.restype = wintypes.DWORD
        advapi32.GetAclInformation.argtypes = [
            wintypes.LPVOID,
            wintypes.LPVOID,
            wintypes.DWORD,
            wintypes.DWORD,
        ]
        advapi32.GetAclInformation.restype = wintypes.BOOL
        advapi32.GetAce.argtypes = [
            wintypes.LPVOID,
            wintypes.DWORD,
            ctypes.POINTER(wintypes.LPVOID),
        ]
        advapi32.GetAce.restype = wintypes.BOOL
        advapi32.GetSecurityDescriptorControl.argtypes = [
            wintypes.LPVOID,
            ctypes.POINTER(wintypes.WORD),
            ctypes.POINTER(wintypes.DWORD),
        ]
        advapi32.GetSecurityDescriptorControl.restype = wintypes.BOOL
        advapi32.EqualSid.argtypes = [wintypes.LPVOID, wintypes.LPVOID]
        advapi32.EqualSid.restype = wintypes.BOOL
        kernel32.LocalFree.argtypes = [wintypes.LPVOID]
        kernel32.LocalFree.restype = wintypes.LPVOID
        kernel32.GetCurrentProcess.restype = wintypes.HANDLE
        kernel32.GetLengthSid.argtypes = [wintypes.LPVOID]
        kernel32.GetLengthSid.restype = wintypes.DWORD
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL

        def lookup(name: str) -> ctypes.Array:
            sid_size = wintypes.DWORD(0)
            domain_size = wintypes.DWORD(0)
            sid_type = wintypes.DWORD(0)
            advapi32.LookupAccountNameW(
                None, name, None, ctypes.byref(sid_size), None,
                ctypes.byref(domain_size), ctypes.byref(sid_type)
            )
            if not sid_size.value:
                raise PrivateStorageError(f"cannot resolve Windows account {name!r}")
            sid = ctypes.create_string_buffer(sid_size.value)
            domain = ctypes.create_unicode_buffer(max(1, domain_size.value))
            if not advapi32.LookupAccountNameW(
                None, name, sid, ctypes.byref(sid_size), domain,
                ctypes.byref(domain_size), ctypes.byref(sid_type)
            ):
                raise ctypes.WinError(ctypes.get_last_error())
            return sid

        class SID_AND_ATTRIBUTES(ctypes.Structure):
            _fields_ = [
                ("Sid", wintypes.LPVOID),
                ("Attributes", wintypes.DWORD),
            ]

        class TOKEN_USER(ctypes.Structure):
            _fields_ = [("User", SID_AND_ATTRIBUTES)]

        token = wintypes.HANDLE()
        if not advapi32.OpenProcessToken(
            kernel32.GetCurrentProcess(), 0x0008, ctypes.byref(token)
        ):
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            required = wintypes.DWORD(0)
            advapi32.GetTokenInformation(token, 1, None, 0, ctypes.byref(required))
            if not required.value:
                raise ctypes.WinError(ctypes.get_last_error())
            token_data = ctypes.create_string_buffer(required.value)
            if not advapi32.GetTokenInformation(
                token, 1, token_data, required, ctypes.byref(required)
            ):
                raise ctypes.WinError(ctypes.get_last_error())
            token_user = ctypes.cast(
                token_data, ctypes.POINTER(TOKEN_USER)
            ).contents
            sid_length = kernel32.GetLengthSid(token_user.User.Sid)
            if not sid_length:
                raise ctypes.WinError(ctypes.get_last_error())
            user_sid = ctypes.create_string_buffer(sid_length)
            ctypes.memmove(user_sid, token_user.User.Sid, sid_length)
        finally:
            kernel32.CloseHandle(token)
        system_sid = lookup("NT AUTHORITY\\SYSTEM")
        entries = (EXPLICIT_ACCESS_W * 2)()
        inherit = SUB_CONTAINERS_AND_OBJECTS_INHERIT if directory else NO_INHERITANCE
        for entry, sid in zip(entries, (user_sid, system_sid)):
            entry.grfAccessPermissions = FILE_ALL_ACCESS
            entry.grfAccessMode = SET_ACCESS
            entry.grfInheritance = inherit
            entry.Trustee.TrusteeForm = TRUSTEE_IS_SID
            entry.Trustee.TrusteeType = 0
            entry.Trustee.ptstrName = ctypes.cast(sid, wintypes.LPVOID)
        new_acl = wintypes.LPVOID()
        error = advapi32.SetEntriesInAclW(2, entries, None, ctypes.byref(new_acl))
        if error:
            raise ctypes.WinError(error)
        try:
            error = advapi32.SetNamedSecurityInfoW(
                str(path),
                SE_FILE_OBJECT,
                DACL_SECURITY_INFORMATION | PROTECTED_DACL_SECURITY_INFORMATION,
                None,
                None,
                new_acl,
                None,
            )
        finally:
            kernel32.LocalFree(new_acl)
        if error:
            raise ctypes.WinError(error)

        descriptor = wintypes.LPVOID()
        dacl = wintypes.LPVOID()
        error = advapi32.GetNamedSecurityInfoW(
            str(path), SE_FILE_OBJECT, DACL_SECURITY_INFORMATION,
            None, None, ctypes.byref(dacl), None, ctypes.byref(descriptor)
        )
        if error:
            raise ctypes.WinError(error)
        try:
            control = wintypes.WORD()
            revision = wintypes.DWORD()
            if not advapi32.GetSecurityDescriptorControl(
                descriptor, ctypes.byref(control), ctypes.byref(revision)
            ) or not (control.value & SE_DACL_PROTECTED):
                raise PrivateStorageError(f"Windows DACL is not protected: {path}")
            info = ACL_SIZE_INFORMATION()
            if not advapi32.GetAclInformation(
                dacl, ctypes.byref(info), ctypes.sizeof(info), 2
            ) or info.AceCount != 2:
                raise PrivateStorageError(f"Windows DACL contains unexpected ACEs: {path}")
            seen: list[wintypes.LPVOID] = []
            for index in range(info.AceCount):
                ace = wintypes.LPVOID()
                if not advapi32.GetAce(dacl, index, ctypes.byref(ace)):
                    raise ctypes.WinError(ctypes.get_last_error())
                allowed = ctypes.cast(ace, ctypes.POINTER(ACCESS_ALLOWED_ACE)).contents
                if (
                    allowed.Header.AceType != ACCESS_ALLOWED_ACE_TYPE
                    or allowed.Mask != FILE_ALL_ACCESS
                ):
                    raise PrivateStorageError(f"Windows DACL ACE is not private: {path}")
                sid_ptr = ctypes.cast(
                    ctypes.addressof(allowed) + ACCESS_ALLOWED_ACE.SidStart.offset,
                    wintypes.LPVOID,
                )
                if not (
                    advapi32.EqualSid(sid_ptr, user_sid)
                    or advapi32.EqualSid(sid_ptr, system_sid)
                ):
                    raise PrivateStorageError(f"Windows DACL grants an unexpected SID: {path}")
                seen.append(sid_ptr)
            if not (
                any(advapi32.EqualSid(value, user_sid) for value in seen)
                and any(advapi32.EqualSid(value, system_sid) for value in seen)
            ):
                raise PrivateStorageError(f"Windows DACL is missing required principals: {path}")
        finally:
            kernel32.LocalFree(descriptor)
    except PrivateStorageError:
        raise
    except (OSError, AttributeError, ctypes.error) as exc:
        raise PrivateStorageError(
            f"cannot replace and verify the Windows DACL for {path}"
        ) from exc


def secure_directory(path: str | Path) -> Path:
    """Create and verify a private customer directory."""

    raw = Path(path).expanduser()
    if raw.exists() and raw.is_symlink():
        raise PrivateStorageError("customer private directory may not be a symlink")
    root = raw.resolve()
    root.mkdir(parents=True, exist_ok=True)
    if root.is_symlink():
        raise PrivateStorageError("customer private directory may not be a symlink")
    if os.name == "nt":
        _windows_acl(root, directory=True)
        # A protected parent does not repair explicit ACLs already present on
        # children.  Walk the existing tree so pre-created credentials,
        # databases, and update journals receive the same complete DACL.
        try:
            children = list(root.rglob("*"))
        except OSError as exc:
            raise PrivateStorageError(
                f"cannot inspect customer private directory: {root}"
            ) from exc
        for child in children:
            if child.is_symlink():
                raise PrivateStorageError(
                    f"customer private directory contains a symlink: {child}"
                )
            _windows_acl(child, directory=child.is_dir())
    else:
        try:
            root.chmod(0o700)
            mode = root.stat().st_mode & 0o777
        except OSError as exc:
            raise PrivateStorageError(
                f"cannot make customer private directory private: {root}"
            ) from exc
        if mode & 0o077:
            raise PrivateStorageError(
                f"customer private directory has group/world permissions: {root}"
            )
    # This marker is not a secret.  It makes accidental use of an owner data
    # directory distinguishable even before any credential or database exists.
    marker = root / PRIVATE_DATA_MARKER
    if marker.is_symlink():
        raise PrivateStorageError("customer private-storage marker may not be a symlink")
    if not marker.exists():
        try:
            marker.write_text("nexa customer private storage\n", encoding="utf-8")
            secure_file(marker)
        except OSError as exc:
            raise PrivateStorageError(
                f"cannot create customer private-storage marker: {root}"
            ) from exc
    else:
        secure_file(marker)
    return root


def secure_file(path: str | Path) -> Path:
    """Apply and verify private permissions to an existing file."""

    target = Path(path).expanduser()
    if target.is_symlink():
        raise PrivateStorageError("customer private file may not be a symlink")
    if not target.exists() or not target.is_file():
        raise PrivateStorageError(f"customer private file does not exist: {target}")
    if os.name == "nt":
        _windows_acl(target, directory=False)
    else:
        try:
            target.chmod(0o600)
            mode = target.stat().st_mode & 0o777
        except OSError as exc:
            raise PrivateStorageError(
                f"cannot make customer private file private: {target}"
            ) from exc
        if mode & 0o077:
            raise PrivateStorageError(
                f"customer private file has group/world permissions: {target}"
            )
    return target


def _marker_payload(value: dict[str, Any]) -> dict[str, Any]:
    if (
        not isinstance(value, dict)
        or value.get("edition") != "customer"
        or value.get("entrypoint") != "run_customer.py"
        or value.get("protocolVersion") != 2
    ):
        raise ValueError("customer installation marker is invalid")
    return value


def read_install_marker(root: str | Path) -> dict[str, Any] | None:
    """Read the explicit customer-only installation marker, if present."""

    path = Path(root) / CUSTOMER_INSTALL_MARKER
    if path.is_symlink():
        raise ValueError("customer installation marker may not be a symlink")
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError("customer installation marker is invalid") from exc
    return _marker_payload(value)


def write_install_marker(
    root: str | Path, *, version: str | None = None
) -> Path:
    """Create the small non-secret marker shipped with customer releases."""

    directory = Path(root)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / CUSTOMER_INSTALL_MARKER
    if path.is_symlink():
        raise ValueError("customer installation marker may not be a symlink")
    payload: dict[str, Any] = {
        "edition": "customer",
        "entrypoint": "run_customer.py",
        "protocolVersion": 2,
    }
    if version:
        payload["version"] = str(version)
    temporary = path.with_name(f".{path.name}.tmp")
    if temporary.is_symlink():
        raise ValueError("customer installation marker temporary file may not be a symlink")
    temporary.write_text(
        json.dumps(payload, sort_keys=True, separators=(",", ":")),
        encoding="utf-8",
    )
    if os.name != "nt":
        temporary.chmod(0o600)
    os.replace(temporary, path)
    if os.name == "nt":
        secure_file(path)
    else:
        path.chmod(0o600)
    return path
