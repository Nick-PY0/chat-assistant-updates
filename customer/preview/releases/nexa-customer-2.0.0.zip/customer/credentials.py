"""Private, one-way-in transport credential storage."""

from __future__ import annotations

import json
import os
import tempfile
import contextlib
from pathlib import Path
from typing import Any

from .installation import PrivateStorageError, secure_directory, secure_file


class CredentialStore:
    """Store the installation credential in an OS-private file.

    The file lives in the explicitly selected customer data directory, never
    in an update archive or source tree.  On POSIX it is mode 0600 and the
    directory is 0700.  Windows ACL inheritance is tightened through
    ``icacls``; failure to apply that ACL is a hard error rather than a
    plaintext fallback.
    """

    FILENAME = "installation-credential.json"

    def __init__(self, data_dir: str | Path) -> None:
        try:
            self.root = secure_directory(data_dir)
        except PrivateStorageError as exc:
            raise ValueError(str(exc)) from exc
        self.path = self.root / self.FILENAME

    def load(self) -> dict[str, Any] | None:
        try:
            if self.path.is_symlink():
                raise ValueError("credential file may not be a symlink")
            if self.path.exists():
                secure_file(self.path)
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return None
        except (OSError, ValueError, TypeError, PrivateStorageError) as exc:
            raise ValueError("stored customer credential is invalid") from exc
        if not isinstance(raw, dict):
            raise ValueError("stored customer credential is invalid")
        credential = raw.get("credential")
        installation_id = raw.get("installationId")
        if (
            not isinstance(credential, str)
            or not credential
            or len(credential) > 1024
            or not isinstance(installation_id, str)
            or not installation_id
        ):
            raise ValueError("stored customer credential is invalid")
        return raw

    def save(self, value: dict[str, Any]) -> None:
        credential = value.get("credential")
        installation_id = value.get("installationId")
        if not isinstance(credential, str) or not credential:
            raise ValueError("enrollment did not return a credential")
        if not isinstance(installation_id, str) or not installation_id:
            raise ValueError("enrollment did not return an installation id")
        try:
            self.root = secure_directory(self.root)
        except PrivateStorageError as exc:
            raise ValueError(str(exc)) from exc
        payload = {
            "installationId": installation_id,
            "workspaceId": value.get("workspaceId"),
            "credential": credential,
            "protocolVersion": 2,
        }
        fd, temporary = tempfile.mkstemp(prefix=".credential-", dir=self.root)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, sort_keys=True, separators=(",", ":"))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            try:
                secure_file(self.path)
            except PrivateStorageError as exc:
                with contextlib.suppress(OSError):
                    self.path.unlink(missing_ok=True)
                raise ValueError(str(exc)) from exc
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass

    def clear(self) -> None:
        self.path.unlink(missing_ok=True)