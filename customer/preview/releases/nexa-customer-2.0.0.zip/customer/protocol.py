"""Strict protocol constants and validation for the customer connector.

The cloud is authoritative about *which* command is queued.  This module is
the second boundary: it accepts only the small, typed command vocabulary
needed by customer LAN TV control.  A command that contains an unknown
parameter is rejected before an adapter is called.
"""

from __future__ import annotations

import ipaddress
import math
import re
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

PROTOCOL_VERSION = 2
MAX_COMMAND_BYTES = 64 * 1024
MAX_RESULT_BYTES = 128 * 1024
MAX_COMMAND_AGE_SECONDS = 15 * 60
MAX_NAME_LENGTH = 80
MAX_TEXT_LENGTH = 120
MAX_QUERY_LENGTH = 120

COMMAND_TYPES = frozenset(
    {
        "device.discover",
        "device.link",
        "device.status",
        "device.control",
        "device.apps",
        "device.remove",
    }
)
PROVIDERS = frozenset({"lg", "roku"})
CONTROL_ACTIONS = frozenset(
    {
        "powerOn",
        "powerOff",
        "volumeUp",
        "volumeDown",
        "mute",
        "input",
        "button",
        "media",
        "volume",
        "app",
        "text",
    }
)
BUTTONS = frozenset(
    {
        "up",
        "down",
        "left",
        "right",
        "ok",
        "select",
        "enter",
        "back",
        "home",
        "info",
        "menu",
        "exit",
        "play",
        "pause",
        "stop",
        "rewind",
        "fast_forward",
        "channel_up",
        "channel_down",
        "replay",
    }
)
MEDIA_ACTIONS = frozenset({"play", "pause", "stop", "rewind", "fast_forward"})

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$")


class ProtocolError(ValueError):
    """A protocol or authorization failure safe to return to the cloud."""


def bounded_string(value: Any, field: str, *, max_length: int = 256) -> str:
    if not isinstance(value, str) or not value or len(value) > max_length:
        raise ProtocolError(f"{field} must be a non-empty bounded string")
    if any(ord(ch) < 0x20 and ch not in "\t\n" for ch in value):
        raise ProtocolError(f"{field} contains control characters")
    return value


def _no_url(value: str, field: str) -> str:
    lowered = value.lower()
    if "://" in lowered or lowered.startswith(("www.", "http:", "https:", "file:")):
        raise ProtocolError(f"{field} may not contain a URL")
    return value


def _safe_value(value: Any, field: str, *, max_length: int) -> str:
    return _no_url(bounded_string(value, field, max_length=max_length), field)


def opaque_id(value: Any, field: str = "deviceId") -> str:
    value = bounded_string(value, field, max_length=128)
    if not _ID_RE.fullmatch(value):
        raise ProtocolError(f"{field} is not a valid opaque identifier")
    return value


def private_lan_ip(value: Any) -> str:
    """Accept only a literal, routable private LAN address.

    The adapters use unauthenticated/local protocols.  Hostnames, loopback,
    link-local, multicast, unspecified, and public addresses are therefore
    never accepted, even if DNS currently resolves them to a LAN address.
    """

    if not isinstance(value, str) or len(value) > 64 or value.strip() != value:
        raise ProtocolError("device target must be a private IP literal")
    try:
        address = ipaddress.ip_address(value)
    except ValueError as exc:
        raise ProtocolError("device target must be a private IP literal") from exc
    if (
        not address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_multicast
        or address.is_unspecified
    ):
        raise ProtocolError("device target must be a routable private LAN IP")
    return str(address)


def cloud_origin(value: str) -> str:
    """Validate the cloud origin used by the connector.

    Production transport is HTTPS.  Plain HTTP is deliberately available only
    for loopback test fixtures; it cannot be used to send a credential over a
    LAN or the public internet.
    """

    if not isinstance(value, str) or len(value) > 512:
        raise ProtocolError("server must be a bounded HTTPS origin")
    parts = urlsplit(value)
    if (
        parts.scheme not in {"https", "http"}
        or not parts.netloc
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
        or parts.path not in {"", "/"}
    ):
        raise ProtocolError("server must be a bare HTTPS origin")
    host = parts.hostname or ""
    if parts.scheme == "http":
        try:
            address = ipaddress.ip_address(host)
        except ValueError as exc:
            raise ProtocolError("plain HTTP is permitted only for loopback tests") from exc
        if not address.is_loopback:
            raise ProtocolError("plain HTTP is permitted only for loopback tests")
    if parts.port is not None and not (1 <= parts.port <= 65535):
        raise ProtocolError("server port is invalid")
    return value.rstrip("/")


def _exact_keys(obj: dict, allowed: set[str], field: str) -> None:
    unknown = set(obj) - allowed
    if unknown:
        names = ", ".join(sorted(str(k) for k in unknown)[:5])
        raise ProtocolError(f"{field} contains unknown parameter(s): {names}")


def _bounded_int(value: Any, field: str, low: int, high: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
        raise ProtocolError(f"{field} is outside its permitted range")
    return value


def _device_ref(payload: dict, *, field: str = "payload") -> tuple[str, int]:
    _exact_keys(payload, {"deviceId", "generation"}, field)
    return opaque_id(payload.get("deviceId")), _bounded_int(
        payload.get("generation"), "generation", 0, 2**31 - 1
    )


def validate_payload(command_type: str, payload: Any) -> dict:
    """Return a normalized command payload or raise ``ProtocolError``."""

    if command_type not in COMMAND_TYPES:
        raise ProtocolError("command type is not permitted")
    if not isinstance(payload, dict):
        raise ProtocolError("command payload must be an object")
    if command_type == "device.discover":
        _exact_keys(payload, {"provider"}, "payload")
        provider = payload.get("provider", "all")
        if provider not in {"all", *PROVIDERS}:
            raise ProtocolError("provider is not permitted")
        return {"provider": provider}
    if command_type in {"device.link", "device.status", "device.remove"}:
        device_id, generation = _device_ref(payload)
        return {"deviceId": device_id, "generation": generation}
    if command_type == "device.apps":
        # Refresh is an explicit read operation.  It is not accepted for
        # control, and is bounded to a boolean rather than arbitrary options.
        _exact_keys(payload, {"deviceId", "generation", "refresh"}, "payload")
        device_id = opaque_id(payload.get("deviceId"))
        generation = _bounded_int(payload.get("generation"), "generation", 0, 2**31 - 1)
        if "refresh" in payload and not isinstance(payload["refresh"], bool):
            raise ProtocolError("refresh must be boolean")
        return {
            "deviceId": device_id,
            "generation": generation,
            "refresh": bool(payload.get("refresh", False)),
        }
    # device.control. These are the exact typed operation/value pairs consumed
    # by DeviceRegistry.control and the LG/Roku managers.
    _exact_keys(payload, {"deviceId", "generation", "action", "value"}, "payload")
    device_id, generation = _device_ref(
        {"deviceId": payload.get("deviceId"), "generation": payload.get("generation")}
    )
    action = payload.get("action")
    if action not in CONTROL_ACTIONS:
        raise ProtocolError("control action is not permitted")
    value = payload.get("value")
    if action in {"powerOn", "powerOff", "volumeUp", "volumeDown"}:
        if "value" in payload and value is not None:
            raise ProtocolError("power actions do not accept value")
        normalized = None
    elif action == "mute":
        if not isinstance(value, bool):
            raise ProtocolError("mute value must be boolean")
        normalized = value
    elif action == "button":
        normalized = _safe_value(value, action, max_length=40).lower().replace(" ", "_")
        if normalized not in BUTTONS:
            raise ProtocolError("button is not permitted")
    elif action == "media":
        normalized = _safe_value(value, action, max_length=40).lower()
        if normalized not in MEDIA_ACTIONS:
            raise ProtocolError("media action is not permitted")
    elif action in {"input", "app"}:
        normalized = _safe_value(value, action, max_length=128)
    elif action == "text":
        normalized = _safe_value(value, action, max_length=120)
    elif action == "volume":
        if not isinstance(value, dict) or set(value) not in ({"percentage"}, {"delta"}):
            raise ProtocolError("volume requires exactly one percentage or delta")
        amount = value[next(iter(value))]
        if isinstance(amount, bool) or not isinstance(amount, (int, float)) or not math.isfinite(float(amount)):
            raise ProtocolError("volume value must be numeric")
        if next(iter(value)) == "percentage" and not 0 <= amount <= 100:
            raise ProtocolError("volume percentage is outside its permitted range")
        if next(iter(value)) == "delta" and not -20 <= amount <= 20:
            raise ProtocolError("volume delta is outside its permitted range")
        normalized = {next(iter(value)): amount}
    return {"deviceId": device_id, "generation": generation, "action": action, "value": normalized}


def _reject_unknown(payload: dict, allowed: set[str]):
    _exact_keys(payload, allowed, "payload")
    raise ProtocolError("invalid payload")


@dataclass(frozen=True)
class Command:
    """A validated cloud command envelope."""

    command_id: str
    idempotency_key: str
    command_type: str
    payload: dict
    lease_token: str
    installation_id: str
    workspace_id: str
    lease_expires_at: str

    @classmethod
    def from_wire(cls, value: Any) -> "Command":
        if not isinstance(value, dict):
            raise ProtocolError("command must be an object")
        _exact_keys(
            value,
            {
                "id",
                "workspaceId",
                "installationId",
                "idempotencyKey",
                "type",
                "payload",
                "status",
                "result",
                "error",
                "createdAt",
                "expiresAt",
                "claimedAt",
                "completedAt",
                "leaseToken",
                "leaseExpiresAt",
            },
            "command",
        )
        command_id = value.get("id")
        command_id = opaque_id(command_id, "commandId")
        command_type = bounded_string(value.get("type"), "type", max_length=64)
        key = opaque_id(value.get("idempotencyKey", command_id), "idempotencyKey")
        payload = validate_payload(command_type, value.get("payload", {}))
        lease = bounded_string(value.get("leaseToken"), "leaseToken", max_length=512)
        workspace = bounded_string(value.get("workspaceId"), "workspaceId", max_length=200)
        installation = bounded_string(
            value.get("installationId"), "installationId", max_length=200
        )
        lease_expires = bounded_string(value.get("leaseExpiresAt"), "leaseExpiresAt", max_length=80)
        return cls(command_id, key, command_type, payload, lease, installation, workspace, lease_expires)


def sanitize_result(value: Any, *, max_bytes: int = MAX_RESULT_BYTES) -> Any:
    """Bound result data before it is acknowledged to the cloud."""

    if value is None or isinstance(value, (str, int, float, bool)):
        result = value
    elif isinstance(value, list):
        result = [sanitize_result(item, max_bytes=max_bytes) for item in value[:300]]
    elif isinstance(value, dict):
        result = {
            str(key)[:80]: sanitize_result(item, max_bytes=max_bytes)
            for key, item in list(value.items())[:100]
            if isinstance(key, (str, int))
        }
    else:
        result = str(value)[:256]
    # JSON sizing is intentionally done here instead of relying on response
    # transport limits, so an adapter can never fill the command queue.
    import json

    if len(json.dumps(result, ensure_ascii=False, separators=(",", ":")).encode()) > max_bytes:
        raise ProtocolError("command result is too large")
    return result