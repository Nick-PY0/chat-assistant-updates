"""External parent process for the customer connector.

The source directory is replaced atomically during a release.  A child that
has imported the old source must therefore exit and let a process whose CWD
and lock are outside that directory launch the new entrypoint.  This module
contains only process-boundary mechanics; cloud protocol and update decisions
remain in :mod:`customer.runtime` and :mod:`customer.updater`.
"""

from __future__ import annotations

import subprocess
import json
import secrets
import sys
import time
from pathlib import Path
from typing import Callable


RESTART_EXIT_CODE = 75
MAX_READINESS_RETRIES = 3


def _child_command(script: Path, argv: list[str]) -> list[str]:
    return [sys.executable, str(script), "--customer-child", *argv]


def _worker_nonce(state_dir: Path) -> str:
    """Reuse a pending lease owner across parent/child process restarts."""

    state_path = state_dir / "updates" / "state.json"
    try:
        state = json.loads(state_path.read_text(encoding="utf-8"))
        value = state.get("workerNonce")
        if (
            state.get("phase") in {
                "downloading",
                "verified",
                "staged",
                "restarting",
                "ready",
                "rolled_back",
            }
            and isinstance(value, str)
            and 20 <= len(value) <= 200
        ):
            return value
    except (OSError, ValueError, TypeError):
        pass
    return secrets.token_urlsafe(32)


def run_child_supervisor(
    *,
    script: str | Path,
    data_dir: str | Path,
    argv: list[str],
    pending_readiness: Callable[[], bool],
    rollback: Callable[[], None],
) -> int:
    """Run customer children until a clean exit or a safe rollback.

    ``script`` is intentionally kept as the original absolute path string,
    rather than resolved after each child.  The parent survives the rename of
    the old source directory and the new source is then visible at that same
    installation path.
    """

    entrypoint = Path(script).absolute()
    state_dir = Path(data_dir).expanduser().resolve()
    state_dir.mkdir(parents=True, exist_ok=True)
    worker_nonce = _worker_nonce(state_dir)
    retries = 0
    while True:
        child_argv = [*argv, "--update-worker", worker_nonce]
        child = subprocess.Popen(
            _child_command(entrypoint, child_argv),
            cwd=str(state_dir),
            close_fds=True,
        )
        result = child.wait()
        if result == RESTART_EXIT_CODE:
            retries = 0
            continue
        if not pending_readiness():
            return result
        if retries < MAX_READINESS_RETRIES:
            retries += 1
            # Keep the journal and backup while retrying running ACK.  A
            # bounded delay avoids a tight loop when the lease is unavailable.
            time.sleep(min(2.0, 0.25 * retries))
            continue
        try:
            rollback()
        except Exception:
            # The caller cannot safely claim recovery when the backup could
            # not be restored.
            return result or 1
        retries = 0


def external_working_directory(data_dir: str | Path) -> Path:
    """Return a validated CWD outside the source tree."""

    root = Path(data_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root
