"""Customer release updater (signed manifest v2, no owner updater coupling)."""

from __future__ import annotations

import base64
import ast
import binascii
import contextlib
import hashlib
import importlib.metadata
import json
import os
import secrets
import shutil
import stat
import tempfile
import re
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Callable
from urllib.parse import unquote, urlsplit

import httpx
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519

from .protocol import PROTOCOL_VERSION, ProtocolError
from .installation import (
    CUSTOMER_INSTALL_MARKER,
    PrivateStorageError,
    read_install_marker,
    secure_directory,
    write_install_marker,
)
from .locking import LockError, acquire

MAX_ARCHIVE_BYTES = 300 * 1024 * 1024
MAX_MEMBER_BYTES = 50 * 1024 * 1024
UPDATE_DOMAIN = "nexa.customer.release.v2"
ALLOWED_RELEASE_HOST = "raw.githubusercontent.com"
ALLOWED_RELEASE_REPOSITORY = "Nick-PY0/chat-assistant-updates"
PUBLIC_KEY_HEX = "5c8494033508642010da1e8978f9c86fb7ee12579d88e1d27ae9816b6fc9647f"
_SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$")

PRIVATE_NAMES = {
    "installation-credential.json",
    "adapter-vault.key",
    "devices.json",
    "customer.db",
    "command-ledger.db",
    ".nexa-instance.lock",
    ".nexa-update.lock",
    ".nexa-private-data",
}


def _private_archive_name(relative: str) -> bool:
    path = PurePosixPath(relative)
    if any(
        part in {
            "updates",
            ".git",
            ".local",
            ".cache",
            "__pycache__",
            "apps",
            "artifacts",
            "deployment",
            "admin",
            "operator",
            "owner",
            "releases",
            "scripts",
            "tests",
            "tools",
        }
        for part in path.parts
    ):
        return True
    if path.name == "run_chat.py":
        return True
    return path.name in PRIVATE_NAMES or path.name in {
        ".env",
        ".env.json",
        "credentials.json",
        "secrets.json",
    } or path.suffix.lower() in {".db", ".sqlite", ".sqlite3", ".key", ".pem"}


class UpdateError(RuntimeError):
    """Safe update rejection/failure."""


def _required(manifest: dict[str, Any], key: str) -> Any:
    value = manifest.get(key)
    if value is None or value == "":
        raise UpdateError(f"manifest missing {key}")
    return value


def _unsigned_int(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise UpdateError(f"manifest {field} must be an unsigned integer")
    return value


def canonical_manifest(manifest: dict[str, Any]) -> bytes:
    """Canonical v2 signature payload from platform-releases/protocol.md.

    This is the protocol's one deliberately fixed JSON object.  Do not replace
    it with a generic canonical-JSON implementation: the TypeScript release
    importer signs these exact bytes.
    """

    if not isinstance(manifest, dict):
        raise UpdateError("manifest must be an object")
    minimum = _unsigned_int(_required(manifest, "schemaMin"), "schemaMin")
    maximum = _unsigned_int(_required(manifest, "schemaMax"), "schemaMax")
    size = _unsigned_int(_required(manifest, "size"), "size")
    payload = {
        "arch": _required(manifest, "arch"),
        "channel": _required(manifest, "channel"),
        "domain": UPDATE_DOMAIN,
        "edition": _required(manifest, "edition"),
        "platform": _required(manifest, "platform"),
        "protocolVersion": 2,
        "schemaMax": maximum,
        "schemaMin": minimum,
        "sha256": str(_required(manifest, "sha256")).lower(),
        "size": size,
        "url": _required(manifest, "url"),
        "version": _required(manifest, "version"),
    }
    return json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def _release_url(url: Any, channel: str) -> str:
    if not isinstance(url, str) or len(url) > 1000:
        raise UpdateError("release URL is invalid")
    try:
        parts = urlsplit(url)
        hostname = parts.hostname
        port = parts.port
    except ValueError as exc:
        raise UpdateError("release URL is outside the customer release allowlist") from exc
    prefix = f"/{ALLOWED_RELEASE_REPOSITORY}/main/customer/{channel}/releases/"
    asset_path = parts.path[len(prefix):] if parts.path.startswith(prefix) else ""
    if (
        parts.scheme != "https"
        or hostname != ALLOWED_RELEASE_HOST
        or port is not None
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
        or parts.path.startswith(prefix) is False
        or "\\" in parts.path
        or not asset_path
        or asset_path.startswith("/")
        or "//" in asset_path
        or any(part in {"", ".", ".."} for part in PurePosixPath(asset_path).parts)
        or any(ord(char) <= 0x20 for char in asset_path)
    ):
        raise UpdateError("release URL is outside the customer release allowlist")
    try:
        if asset_path != unquote(asset_path):
            raise UpdateError("release URL is outside the customer release allowlist")
    except (UnicodeDecodeError, ValueError):
        raise UpdateError("release URL is outside the customer release allowlist")
    return url


def verify_manifest(
    manifest: dict[str, Any],
    *,
    public_key_hex: str = PUBLIC_KEY_HEX,
    platform: str | None = None,
    arch: str | None = None,
    current_schema: int = 2,
) -> dict[str, Any]:
    """Validate all immutable v2 release fields and return normalized metadata."""

    if set(manifest) - {
        "edition",
        "channel",
        "platform",
        "arch",
        "version",
        "url",
        "sha256",
        "size",
        "protocolVersion",
        "schemaMin",
        "schemaMax",
        "signature",
        "dependencies",
        "assignmentId",
    }:
        raise UpdateError("manifest contains unknown fields")
    if manifest.get("edition") != "customer":
        raise UpdateError("manifest is not a customer release")
    channel = manifest.get("channel")
    if channel not in {"stable", "preview"}:
        raise UpdateError("manifest channel is invalid")
    for field in ("platform", "arch"):
        value = manifest.get(field)
        if (
            not isinstance(value, str)
            or not 1 <= len(value) <= 32
            or value != value.lower()
            or not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", value)
        ):
            raise UpdateError(f"manifest {field} is invalid")
    if platform is not None and manifest.get("platform") != platform:
        raise UpdateError("manifest platform does not match this installation")
    if arch is not None and manifest.get("arch") != arch:
        raise UpdateError("manifest architecture does not match this installation")
    if manifest.get("protocolVersion") != PROTOCOL_VERSION:
        raise UpdateError("manifest protocol compatibility is invalid")
    try:
        size = _unsigned_int(manifest["size"], "size")
        schema_min = _unsigned_int(manifest["schemaMin"], "schemaMin")
        schema_max = _unsigned_int(manifest["schemaMax"], "schemaMax")
    except (KeyError, TypeError, ValueError) as exc:
        raise UpdateError("manifest numeric fields are invalid") from exc
    if not 0 < size <= MAX_ARCHIVE_BYTES:
        raise UpdateError("manifest archive size is invalid")
    if not 0 <= schema_min <= schema_max or not schema_min <= current_schema <= schema_max:
        raise UpdateError("manifest schema is incompatible")
    sha256 = str(manifest.get("sha256", "")).lower()
    if len(sha256) != 64 or any(char not in "0123456789abcdef" for char in sha256):
        raise UpdateError("manifest SHA-256 is invalid")
    version = str(manifest.get("version", ""))
    if not version or len(version) > 64 or not _SEMVER_RE.fullmatch(version):
        raise UpdateError("manifest version is invalid")
    _release_url(manifest.get("url"), channel)
    signature_value = manifest.get("signature")
    if not isinstance(signature_value, str) or not signature_value:
        raise UpdateError("manifest is unsigned")
    try:
        signature = base64.b64decode(signature_value, validate=True)
        if len(signature) != 64:
            raise UpdateError("manifest signature is invalid")
        key = ed25519.Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex))
        key.verify(signature, canonical_manifest(manifest))
    except (ValueError, binascii.Error, InvalidSignature) as exc:
        raise UpdateError("manifest signature is invalid") from exc
    return {
        "edition": "customer",
        "channel": channel,
        "platform": str(manifest["platform"]),
        "arch": str(manifest["arch"]),
        "version": version,
        "url": str(manifest["url"]),
        "sha256": sha256,
        "size": size,
        "protocolVersion": PROTOCOL_VERSION,
        "schemaMin": schema_min,
        "schemaMax": schema_max,
    }


def _safe_member(name: str) -> PurePosixPath:
    if not name or "\\" in name or "\x00" in name:
        raise UpdateError("archive contains an invalid path")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise UpdateError("archive contains a path traversal")
    return path


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK((info.external_attr >> 16) & 0xFFFF)


def _archive_root(names: list[str]) -> str:
    """Allow a flat package or one wrapper directory, never arbitrary nesting."""

    roots = [name.split("/", 1)[0] for name in names if name]
    if "run_customer.py" in names:
        return ""
    if roots and all(name.startswith(roots[0] + "/") for name in names):
        return roots[0] + "/"
    raise UpdateError("customer archive must contain run_customer.py at package root")


def _write_state(path: Path, value: dict[str, Any]) -> None:
    if path.is_symlink():
        raise UpdateError("customer update state may not be a symlink")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name("." + path.name + ".tmp")
    if temporary.is_symlink():
        raise UpdateError("customer update state temporary file may not be a symlink")
    temporary.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")), encoding="utf-8")
    try:
        temporary.chmod(0o600)
    except OSError:
        pass
    os.replace(temporary, path)


def _requirement_specs(root: Path) -> list[str]:
    """Read the release's requirements without invoking a package installer."""

    candidates = [root / "customer" / "requirements.txt", root / "requirements.txt"]
    requirements = next((path for path in candidates if path.is_file()), None)
    if requirements is None:
        # Older development fixtures contain only the entrypoint.  Production
        # packages always ship the file; the bundled customer requirements are
        # still a real gate for those fixtures, never an empty no-op check.
        requirements = Path(__file__).with_name("requirements.txt")
    try:
        lines = requirements.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise UpdateError("customer release requirements cannot be read") from exc
    result: list[str] = []
    for line in lines:
        value = line.split("#", 1)[0].strip()
        if not value:
            continue
        if value.startswith(("-r", "--", "git+", "http:", "https:")):
            raise UpdateError("customer release requirements contain an unsafe option")
        # Requirement files are intentionally limited to named distributions.
        # Extras and normal version specifiers remain valid and are checked by
        # importlib.metadata below.
        if not re.fullmatch(r"[A-Za-z0-9_.-]+(?:\[[A-Za-z0-9_,.-]+\])?(?:\s*[<>=!~]=?\s*[A-Za-z0-9.*+!_-]+(?:\s*,\s*[<>=!~]=?\s*[A-Za-z0-9.*+!_-]+)*)?", value):
            raise UpdateError("customer release requirements contain an invalid entry")
        result.append(value)
    return result


def _distribution_name(spec: str) -> str:
    return re.split(r"[\[<>=!~\s]", spec, maxsplit=1)[0].replace("_", "-").lower()


def _version_satisfies(version: str, spec: str) -> bool:
    """Small PEP-440 gate for the release's ordinary requirement syntax."""

    constraints = re.findall(r"([<>=!~]{1,2})\s*([A-Za-z0-9.*+!_-]+)", spec)
    if not constraints:
        return True
    # ``packaging`` is a dependency of the supported customer environment, but
    # do not import or install it just to check a release.  This conservative
    # comparison handles the operators used by customer/requirements.txt.
    def parse(value: str) -> tuple[tuple[int, Any], ...]:
        return tuple(
            (0, int(part)) if part.isdigit() else (1, part.lower())
            for part in re.split(r"[.\-_+]", value)
            if part
        )

    current = parse(version)
    for operator, wanted in constraints:
        if wanted.endswith(".*"):
            if not version.startswith(wanted[:-2]):
                return False
            continue
        expected = parse(wanted)
        if operator in {"=", "=="} and current != expected:
            return False
        if operator == "!=" and current == expected:
            return False
        if operator == ">=" and current < expected:
            return False
        if operator == ">" and current <= expected:
            return False
        if operator == "<=" and current > expected:
            return False
        if operator == "<" and current >= expected:
            return False
        if operator == "~=" and (current < expected or current[:1] != expected[:1]):
            return False
    return True


def check_customer_dependencies(requirements: list[str]) -> bool:
    """Return whether every release dependency is already installed.

    Updates never mutate the owner Python environment.  A customer deployment
    can arrange an isolated ``--target`` directory before this gate, but this
    updater only consumes an environment that is already ready.
    """

    if not requirements:
        return False
    for spec in requirements:
        name = _distribution_name(spec)
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            return False
        if not _version_satisfies(version, spec):
            return False
    return True


class CustomerUpdater:
    """Download, stage, apply, and readiness-fence one customer release."""

    def __init__(
        self,
        install_root: str | Path,
        data_dir: str | Path,
        *,
        platform: str,
        arch: str,
        current_version: str,
        worker_nonce: str | None = None,
        public_key_hex: str = PUBLIC_KEY_HEX,
        dependency_check: Callable[[list[str]], bool] | None = None,
        validate_install_root: bool = True,
    ) -> None:
        raw_install_root = Path(install_root).expanduser()
        raw_data_dir = Path(data_dir).expanduser()
        if raw_install_root.is_symlink() or raw_data_dir.is_symlink():
            raise ValueError("customer updater paths may not be symlinks")
        self.install_root = raw_install_root.resolve()
        self.data_dir = raw_data_dir.resolve()
        if self.install_root == self.data_dir or self.data_dir in self.install_root.parents:
            raise ValueError("customer updater data directory must be separate")
        try:
            self.data_dir = secure_directory(self.data_dir)
            self.updates_dir = secure_directory(self.data_dir / "updates")
        except PrivateStorageError as exc:
            raise ValueError(str(exc)) from exc
        self.staging_dir = self.updates_dir / "staging"
        self.state_path = self.updates_dir / "state.json"
        self.receipt_path = self.updates_dir / "verified-receipt.json"
        self.platform = platform
        self.arch = arch
        self.current_version = current_version
        self.worker_nonce = worker_nonce
        self.public_key_hex = public_key_hex
        self._custom_dependency_check = dependency_check
        self.dependency_check = dependency_check or check_customer_dependencies
        if validate_install_root and self.install_root.exists():
            self._validate_install_root(self.install_root)

    def state(self) -> dict[str, Any]:
        try:
            if self.state_path.is_symlink():
                raise ValueError("customer update state may not be a symlink")
            value = json.loads(self.state_path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (FileNotFoundError, OSError, ValueError):
            return {}

    def _save(self, **changes: Any) -> dict[str, Any]:
        value = self.state()
        value.update(changes)
        _write_state(self.state_path, value)
        return value

    @staticmethod
    def _newer(version: str, current: str) -> bool:
        def parse(value: str) -> tuple[int, ...]:
            return tuple(int(part) for part in value.split("-", 1)[0].split("+", 1)[0].split("."))

        try:
            return parse(version) > parse(current)
        except (TypeError, ValueError):
            return False

    def _validate_install_root(self, root: Path, *, allow_unmarked: bool = True) -> None:
        """Reject the owner checkout before any source directory is renamed."""

        owner_names = {
            "run_chat.py",
            "pyproject.toml",
            "package.json",
            ".git",
            "apps",
            "admin",
            "operator",
            "owner",
            "deployment",
        }
        present = {item.name for item in root.iterdir()} if root.is_dir() else set()
        if present & owner_names:
            raise UpdateError(
                "customer update root is the owner checkout; use an extracted customer installation"
            )
        try:
            marker = read_install_marker(root)
        except ValueError as exc:
            raise UpdateError(str(exc)) from exc
        if marker is not None:
            return
        if present & {"chat_core", "integrations"}:
            raise UpdateError(
                "customer update root is an unmarked owner checkout; "
                f"missing {CUSTOMER_INSTALL_MARKER}"
            )
        if not allow_unmarked:
            raise UpdateError(
                f"customer update root is missing {CUSTOMER_INSTALL_MARKER}"
            )
        if root.exists() and not (root / "run_customer.py").is_file():
            raise UpdateError("customer update root has no customer entrypoint")

    @staticmethod
    def _installed_version(root: Path) -> str | None:
        """Read a literal APP_VERSION without importing installed code."""

        candidates = [root / "customer" / "version.py", root / "version.py"]
        path = next((candidate for candidate in candidates if candidate.is_file()), None)
        if path is None:
            return None
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (OSError, SyntaxError, UnicodeError) as exc:
            raise UpdateError("installed customer VERSION is not readable") from exc
        for node in tree.body:
            if isinstance(node, ast.Assign):
                names = [
                    target.id
                    for target in node.targets
                    if isinstance(target, ast.Name)
                ]
                if "APP_VERSION" in names and isinstance(node.value, ast.Constant):
                    return node.value.value if isinstance(node.value.value, str) else None
        raise UpdateError("installed customer VERSION is missing")

    def _prepare_customer_marker(self, root: Path, version: str) -> None:
        try:
            marker = read_install_marker(root)
        except ValueError as exc:
            raise UpdateError(str(exc)) from exc
        if marker is not None:
            marker_version = marker.get("version")
            if marker_version is not None and str(marker_version) != version:
                raise UpdateError("customer installation marker version is inconsistent")
            return
        self._validate_install_root(root)
        try:
            write_install_marker(root, version=version)
        except (OSError, ValueError) as exc:
            raise UpdateError("cannot create customer installation marker") from exc

    def _verify_installed_receipt(
        self, *, version: str, archive_sha256: str, tree_sha256: str
    ) -> dict[str, Any]:
        try:
            receipt = json.loads(self.receipt_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise UpdateError("verified customer release receipt is missing") from exc
        if (
            not isinstance(receipt, dict)
            or receipt.get("version") != version
            or receipt.get("sha256") != archive_sha256
            or receipt.get("treeSha256") != tree_sha256
        ):
            raise UpdateError("installed customer receipt does not match launch intent")
        try:
            marker = read_install_marker(self.install_root)
        except ValueError as exc:
            raise UpdateError(str(exc)) from exc
        if marker is None:
            raise UpdateError(f"installed customer source has no {CUSTOMER_INSTALL_MARKER}")
        marker_version = marker.get("version")
        if marker_version is not None and str(marker_version) != version:
            raise UpdateError("installed customer marker does not match receipt")
        actual_version = self._installed_version(self.install_root)
        # Minimal historical fixtures have no customer package and are kept
        # readable for migration diagnostics.  A real extracted customer
        # release has a customer/ package, where VERSION is mandatory.
        if actual_version is None and (self.install_root / "customer").is_dir():
            raise UpdateError("installed customer VERSION is missing")
        if actual_version is not None and actual_version != version:
            raise UpdateError("installed customer VERSION does not match receipt")
        actual_tree = self._tree_hash(self.install_root)
        if actual_tree != tree_sha256:
            raise UpdateError("installed customer tree does not match receipt")
        return {
            "actualVersion": actual_version or version,
            "actualSha256": archive_sha256,
            "actualTreeSha256": actual_tree,
        }

    async def stage(self, manifest: dict[str, Any]) -> Path:
        pending = self.state()
        pending_worker = pending.get("workerNonce")
        if (
            pending.get("phase") in {"downloading", "verified", "staged", "restarting", "ready"}
            and pending_worker
            and self.worker_nonce
            and pending_worker != self.worker_nonce
        ):
            raise UpdateError("another update worker owns the pending customer lease")
        assignment_id = manifest.get("assignmentId")
        manifest_fields = {
            key: manifest[key]
            for key in (
                "edition",
                "channel",
                "platform",
                "arch",
                "version",
                "url",
                "sha256",
                "size",
                "protocolVersion",
                "schemaMin",
                "schemaMax",
                "signature",
            )
            if key in manifest
        }
        verified = verify_manifest(
            manifest_fields,
            public_key_hex=self.public_key_hex,
            platform=self.platform,
            arch=self.arch,
        )
        authority = manifest.get("approvedTargetAuthority")
        if authority is not None and (
            not isinstance(authority, dict)
            or set(authority) != {
                "rolloutId",
                "releaseId",
                "target",
                "percentage",
                "revision",
            }
        ):
            raise UpdateError("rollback authority metadata is invalid")
        if authority is not None:
            target = authority.get("target")
            if (
                not isinstance(authority.get("rolloutId"), str)
                or not authority["rolloutId"]
                or not isinstance(authority.get("releaseId"), str)
                or not authority["releaseId"]
                or not isinstance(target, dict)
                or set(target) != {"type", "id"}
                or target.get("type") not in {"workspace", "installation", "group", "fleet"}
                or not isinstance(target.get("id"), str)
                or not target["id"]
                or isinstance(authority.get("percentage"), bool)
                or not isinstance(authority.get("percentage"), (int, float))
                or not 0 <= authority["percentage"] <= 100
                or isinstance(authority.get("revision"), bool)
                or not isinstance(authority.get("revision"), int)
                or authority["revision"] < 1
            ):
                raise UpdateError("rollback authority metadata is invalid")
        rollback = (
            self._newer(self.current_version, verified["version"])
            and manifest.get("rollbackOf")
            and manifest.get("previousVersion") == self.current_version
            and (
                (
                    authority is not None
                    and authority.get("rolloutId") == manifest.get("rollbackOf")
                )
            )
        )
        if not self._newer(verified["version"], self.current_version) and not rollback:
            raise UpdateError(
                "release is not newer than the running customer version "
                "without authenticated rollback authority"
            )
        if self._custom_dependency_check is not None:
            # A test/deployment hook gets a real requirement list here, not
            # the historical empty-list stub.  The extracted release is
            # checked again immediately before the source swap below.
            if not self.dependency_check(_requirement_specs(self.install_root)):
                raise UpdateError("customer release dependencies are not satisfied")
        self._save(
            assignmentId=assignment_id,
            assignmentEpoch=manifest.get("assignmentEpoch"),
            generation=manifest.get("generation"),
            leaseToken=manifest.get("leaseToken"),
            workerNonce=self.worker_nonce,
            rollbackOf=manifest.get("rollbackOf"),
            approvedTargetAuthority=authority,
            previousVersion=manifest.get("previousVersion") or self.current_version,
            version=verified["version"],
            sha256=verified["sha256"],
            phase="downloading",
        )
        self.staging_dir.mkdir(parents=True, exist_ok=True)
        archive = self.staging_dir / f"{verified['version']}.zip"
        received = 0
        digest = hashlib.sha256()
        try:
            async with httpx.AsyncClient(
                timeout=httpx.Timeout(35.0, connect=10.0),
                follow_redirects=False,
            ) as client:
                async with client.stream("GET", verified["url"]) as response:
                    if response.status_code != 200 or response.is_redirect:
                        raise UpdateError("release download was refused")
                    content_length = response.headers.get("content-length")
                    if content_length and int(content_length) > verified["size"]:
                        raise UpdateError("release download is larger than its manifest")
                    with archive.open("wb") as stream:
                        async for chunk in response.aiter_bytes(64 * 1024):
                            received += len(chunk)
                            if received > verified["size"] or received > MAX_ARCHIVE_BYTES:
                                raise UpdateError("release download is too large")
                            digest.update(chunk)
                            stream.write(chunk)
                            if received == verified["size"]:
                                # Keep reading one bounded chunk to detect a
                                # server lying about Content-Length.
                                continue
            if received != verified["size"] or digest.hexdigest() != verified["sha256"]:
                raise UpdateError("release archive hash or size does not match")
            self._save(phase="verified")
            target = self.staging_dir / verified["version"]
            shutil.rmtree(target, ignore_errors=True)
            self._safe_extract(archive, target)
            self._prepare_customer_marker(target, verified["version"])
            metadata = dict(verified)
            metadata["assignmentId"] = assignment_id
            metadata["treeSha256"] = self._tree_hash(target)
            _write_state(target / ".customer-release.json", metadata)
            _write_state(self.receipt_path, metadata)
            self._save(phase="staged", stage=str(target), treeSha256=metadata["treeSha256"])
            return target
        except Exception:
            archive.unlink(missing_ok=True)
            self._save(phase="failed", error="release failed verification or staging")
            raise

    def _safe_extract(self, archive: Path, target: Path) -> None:
        if target.is_symlink():
            raise UpdateError("staging target may not be a symlink")
        target.mkdir(parents=True, exist_ok=False)
        with zipfile.ZipFile(archive) as bundle:
            infos = bundle.infolist()
            if not infos or len(infos) > 10000:
                raise UpdateError("release archive is empty or too large")
            names = [_safe_member(info.filename).as_posix() for info in infos]
            if len(names) != len(set(names)):
                raise UpdateError("archive contains duplicate paths")
            root = _archive_root(names)
            if not any(name.removeprefix(root) == "run_customer.py" for name in names):
                raise UpdateError("release archive has no customer entrypoint")
            total = 0
            for info, name in zip(infos, names):
                if _is_symlink(info):
                    raise UpdateError("release archive contains a symlink")
                relative = name[len(root):] if root and name.startswith(root) else name
                if not relative or _private_archive_name(relative):
                    raise UpdateError("release archive contains private customer data")
                if info.is_dir():
                    continue
                if info.file_size > MAX_MEMBER_BYTES:
                    raise UpdateError("release archive member is too large")
                total += info.file_size
                if total > MAX_ARCHIVE_BYTES:
                    raise UpdateError("release archive expands beyond its limit")
                destination = target / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                with bundle.open(info) as source, destination.open("wb") as stream:
                    shutil.copyfileobj(source, stream, length=64 * 1024)
                destination.chmod(0o700 if destination.suffix == ".py" else 0o600)

    @staticmethod
    def _tree_hash(root: Path) -> str:
        digest = hashlib.sha256()
        for item in root.rglob("*"):
            if item.is_symlink():
                raise UpdateError("customer source contains a symlink")
        for path in sorted(
            item
            for item in root.rglob("*")
            if item.is_file()
            and item.name != ".customer-release.json"
            and "__pycache__" not in item.parts
            and item.suffix != ".pyc"
        ):
            relative = path.relative_to(root).as_posix()
            digest.update(relative.encode())
            digest.update(path.read_bytes())
        return digest.hexdigest()

    def apply_staged(self) -> dict[str, Any]:
        state = self.state()
        stage_value = str(state.get("stage", ""))
        stage = Path(stage_value).expanduser()
        staging_root = self.staging_dir.resolve()
        if (
            state.get("phase") != "staged"
            or not stage_value
            or stage.is_symlink()
            or stage.resolve().parent != staging_root
            or stage.resolve().name != str(state.get("version", ""))
            or not stage.is_dir()
        ):
            raise UpdateError("no safely staged customer release")
        metadata_path = stage / ".customer-release.json"
        try:
            staged_metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise UpdateError("staged release metadata is invalid") from exc
        if (
            not isinstance(staged_metadata, dict)
            or staged_metadata.get("version") != state.get("version")
            or staged_metadata.get("sha256") != state.get("sha256")
            or staged_metadata.get("treeSha256") != state.get("treeSha256")
            or self._tree_hash(stage) != state.get("treeSha256")
        ):
            raise UpdateError("staged release is stale or modified")
        try:
            receipt = json.loads(self.receipt_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise UpdateError("verified customer release receipt is missing") from exc
        if (
            not isinstance(receipt, dict)
            or receipt.get("version") != staged_metadata.get("version")
            or receipt.get("sha256") != staged_metadata.get("sha256")
            or receipt.get("treeSha256") != staged_metadata.get("treeSha256")
        ):
            raise UpdateError("verified customer release receipt is inconsistent")
        requirements = _requirement_specs(stage)
        if not self.dependency_check(requirements):
            raise UpdateError("customer release dependencies are not satisfied")
        version = str(state.get("version", ""))
        if not (stage / "run_customer.py").is_file():
            raise UpdateError("staged release has no customer entrypoint")
        self._validate_install_root(self.install_root)
        self._prepare_customer_marker(self.install_root, self.current_version)
        self._prepare_customer_marker(stage, version)
        # A pre-v2 installation may leave a legacy in-tree lock behind.  Do
        # not open it (opening it would recreate the Windows rename bug);
        # refuse safely until that stale/active operation is removed.
        legacy_lock = self.install_root / ".nexa-update.lock"
        if legacy_lock.exists() or legacy_lock.is_symlink():
            raise UpdateError("another customer installation operation is active")
        try:
            # The lock must not be inside the directory being renamed.  An
            # open lock handle there prevents Windows from moving the source.
            lock = acquire(self.updates_dir / ".nexa-update.lock")
        except LockError as exc:
            raise UpdateError("customer update lock is unavailable") from exc
        if lock is None:
            raise UpdateError("another customer installation operation is active")
        nonce = secrets.token_urlsafe(32)
        backup = self.updates_dir / "backups" / nonce
        swapped = False
        try:
            backup.parent.mkdir(parents=True, exist_ok=True)
            try:
                backup.parent.chmod(0o700)
            except OSError as exc:
                raise UpdateError("customer update backup directory is not private") from exc
            launch = {
                "nonce": nonce,
                "version": version,
                "sha256": state.get("sha256"),
                "treeSha256": state.get("treeSha256"),
                "assignmentId": state.get("assignmentId"),
                "assignmentEpoch": state.get("assignmentEpoch"),
                "generation": state.get("generation"),
                "leaseToken": state.get("leaseToken"),
                "workerNonce": self.worker_nonce,
                "rollbackOf": state.get("rollbackOf"),
                "approvedTargetAuthority": state.get("approvedTargetAuthority"),
                "previousVersion": state.get("previousVersion", self.current_version),
                "backup": str(backup),
            }
            # Both records exist before the first rename.  A crash at any
            # point after this line has enough information for rollback.
            self._save(
                phase="restarting",
                version=version,
                nonce=nonce,
                backup=str(backup),
            )
            _write_state(self.data_dir / "updates" / "launch.json", launch)
            if self.install_root.exists():
                os.replace(self.install_root, backup)
            os.replace(stage, self.install_root)
            swapped = True
            return self.state()
        except Exception as exc:
            # Restore the old source even when failure happened after the
            # swap (for example, a full data directory or a failed marker
            # write).  A process crash in this window is handled by
            # recover_interrupted on the next start.
            with contextlib.suppress(OSError):
                if swapped and self.install_root.exists():
                    failed = self.updates_dir / "backups" / f"{nonce}.failed"
                    if failed.is_dir() and not failed.is_symlink():
                        shutil.rmtree(failed, ignore_errors=True)
                    else:
                        failed.unlink(missing_ok=True)
                    os.replace(self.install_root, failed)
            with contextlib.suppress(OSError):
                if backup.exists() and not self.install_root.exists():
                    os.replace(backup, self.install_root)
            (self.data_dir / "updates" / "launch.json").unlink(missing_ok=True)
            self._save(
                phase="rolled_back",
                reconciliationPending=True,
                error=str(exc)[:4096],
            )
            raise UpdateError("customer update was rolled back") from exc
        finally:
            lock.release()

    def mark_running(self, *, version: str, nonce: str) -> dict[str, Any]:
        launch = self.data_dir / "updates" / "launch.json"
        try:
            if launch.is_symlink():
                raise UpdateError("customer launch marker may not be a symlink")
            marker = json.loads(launch.read_text(encoding="utf-8"))
            if not isinstance(marker, dict):
                raise UpdateError("customer launch marker is invalid")
        except (OSError, ValueError) as exc:
            raise UpdateError("no pending customer launch readiness marker") from exc
        state = self.state()
        if (
            state.get("phase") not in {"restarting", "ready"}
            or not nonce
            or marker.get("nonce") != nonce
            or marker.get("version") != version
            or state.get("version") != version
            or state.get("sha256") != marker.get("sha256")
            or (
                marker.get("workerNonce")
                and self.worker_nonce
                and marker.get("workerNonce") != self.worker_nonce
            )
        ):
            raise UpdateError("running customer build does not match launch intent")
        receipt = self._verify_installed_receipt(
            version=version,
            archive_sha256=str(marker.get("sha256") or ""),
            tree_sha256=str(marker.get("treeSha256") or ""),
        )
        self.current_version = version
        return self._save(phase="ready", version=version, **receipt)

    def commit_running(self) -> dict[str, Any]:
        """Commit the swap only after the lease-fenced running ACK succeeds."""

        state = self.state()
        if state.get("phase") != "ready":
            raise UpdateError("customer source is not locally ready to commit")
        launch = self.data_dir / "updates" / "launch.json"
        if launch.is_symlink():
            raise UpdateError("customer launch marker may not be a symlink")
        try:
            marker = json.loads(launch.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise UpdateError("customer launch receipt is missing") from exc
        if (
            not isinstance(marker, dict)
            or marker.get("nonce") != state.get("nonce")
            or marker.get("version") != state.get("version")
        ):
            raise UpdateError("customer launch receipt is inconsistent")
        self._verify_installed_receipt(
            version=str(state["version"]),
            archive_sha256=str(state.get("sha256") or ""),
            tree_sha256=str(marker.get("treeSha256") or ""),
        )
        launch.unlink(missing_ok=True)
        backup_value = str(state.get("backup", ""))
        backup = Path(backup_value)
        backup_root = (self.updates_dir / "backups").resolve()
        if (
            not backup_value
            or backup.is_symlink()
            or backup.resolve().parent != backup_root
        ):
            raise UpdateError("customer update backup path is invalid")
        if backup.is_dir():
            shutil.rmtree(backup)
        elif backup.exists():
            backup.unlink()
        return self._save(phase="running", version=state.get("version"))

    def commit_rollback_reconciliation(self) -> dict[str, Any]:
        """Mark a durable rollback receipt accepted without changing source."""

        state = self.state()
        if state.get("phase") != "rolled_back":
            raise UpdateError("customer source is not durably rolled back")
        if state.get("reconciliationPending") is False:
            return state
        return self._save(reconciliationPending=False)

    def recover_interrupted(self) -> dict[str, Any]:
        """Recover a process crash between source swap and readiness ACK."""

        state = self.state()
        if state.get("phase") not in {"restarting", "ready"}:
            return state
        backup_value = str(state.get("backup", ""))
        backup = Path(backup_value)
        backup_root = (self.updates_dir / "backups").resolve()
        if (
            not backup_value
            or backup.is_symlink()
            or backup.resolve().parent != backup_root
            or not backup.is_dir()
        ):
            self._save(phase="failed", error="customer restart had no recoverable backup")
            return self.state()
        # A process that reaches this method has not proven the target build
        # ready. Restore the prior source before trying another update.
        failed = self.updates_dir / "backups" / f"{state.get('nonce', 'interrupted')}.failed"
        if self.install_root.exists() or self.install_root.is_symlink():
            if failed.is_dir() and not failed.is_symlink():
                shutil.rmtree(failed, ignore_errors=True)
            else:
                failed.unlink(missing_ok=True)
            os.replace(self.install_root, failed)
        os.replace(backup, self.install_root)
        (self.data_dir / "updates" / "launch.json").unlink(missing_ok=True)
        shutil.rmtree(failed, ignore_errors=True)
        self._save(
            phase="rolled_back",
            reconciliationPending=True,
            error="customer restart readiness was interrupted",
        )
        return self.state()