"""Customer LAN device registry and the closed LG/Roku adapter bridge."""

from __future__ import annotations

import json
import os
import secrets
import uuid
from pathlib import Path
from typing import Any
import ipaddress
import re

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from chat_core.events import EventBus
from chat_core.identifiers import provider_secret_key
from chat_core.security.vault import Vault
from integrations.tv import TVManager

from .localdb import CustomerDatabase
from .protocol import (
    CONTROL_ACTIONS,
    PROVIDERS,
    ProtocolError,
    opaque_id,
    private_lan_ip,
    sanitize_result,
)


def _private_key(path: Path) -> bytes:
    """Load/create the customer-only adapter encryption key."""

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError("customer vault key may not be a symlink")
    try:
        value = path.read_bytes()
    except FileNotFoundError:
        value = os.urandom(32)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        fd = os.open(path, flags, 0o600)
        try:
            os.write(fd, value)
        finally:
            os.close(fd)
    if len(value) != 32:
        raise ValueError("customer vault key is invalid")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return value


class DeviceRegistry:
    """Maps public opaque IDs to private local adapter targets."""

    def __init__(self, data_dir: str | Path, db: CustomerDatabase) -> None:
        self.root = Path(data_dir).expanduser().resolve()
        self.db = db
        self.path = self.root / "devices.json"
        self.records: dict[str, dict[str, Any]] = {}
        self._cloud_ids: dict[str, str] = {}
        self._load()
        self.bus = EventBus()
        self.vault = Vault(_private_key(self.root / "adapter-vault.key"))
        # A settings object is intentionally not loaded: TV adapters only use
        # the DB, and customer runtime has no owner settings/config surface.
        self.tv = TVManager(self.db, self.bus, self.vault, settings=None)

    def _load(self) -> None:
        try:
            if self.path.is_symlink():
                raise ValueError("customer device registry may not be a symlink")
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            raise ValueError("customer device registry is invalid") from exc
        if not isinstance(value, list):
            raise ValueError("customer device registry is invalid")
        for item in value:
            if not isinstance(item, dict):
                continue
            try:
                device_id = opaque_id(item["id"])
                provider = item["provider"]
                host = private_lan_ip(item["host"])
            except (KeyError, ProtocolError):
                continue
            if provider not in PROVIDERS:
                continue
            self.records[device_id] = {
                "id": device_id,
                "provider": provider,
                "host": host,
                "name": str(item.get("name") or f"{provider.upper()} TV")[:80],
                "generation": max(0, int(item.get("generation", 0))),
                "linked": bool(item.get("linked", False)),
            }

    def _persist(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(f".{self.path.name}.tmp")
        temporary.write_text(
            json.dumps(list(self.records.values()), sort_keys=True, separators=(",", ":")),
            encoding="utf-8",
        )
        try:
            temporary.chmod(0o600)
        except OSError:
            pass
        os.replace(temporary, self.path)
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    @staticmethod
    def _provider(value: str) -> str:
        value = str(value).strip().lower()
        if value == "lg_webos":
            value = "lg"
        if value not in PROVIDERS:
            raise ProtocolError("provider is not permitted")
        return value

    @staticmethod
    def _public_name(item: dict[str, Any], provider: str) -> str:
        """Return a display label with every adapter identifier removed.

        Discovery adapters are allowed to return rich local rows.  Only the
        bounded label crosses the runtime boundary, and the shared Unicode
        collision key is applied to every identifier so confusable forms
        cannot be smuggled into a public name.
        """

        fallback = f"{provider.upper()} device"
        raw_name = item.get("name") or item.get("title")
        if not isinstance(raw_name, str):
            return fallback
        name = " ".join(raw_name.split())[:80]
        if not name:
            return fallback
        try:
            if ipaddress.ip_address(name).version in (4, 6):
                return fallback
        except ValueError:
            pass
        if re.search(r"(?i)(?:https?://|(?:\d{1,3}\.){3}\d{1,3}|(?:[0-9a-f]{2}:){5}[0-9a-f]{2})", name):
            return fallback
        identifiers: list[str] = []

        def collect(value: Any, key: str = "") -> None:
            if isinstance(value, dict):
                for child_key, child in value.items():
                    collect(child, str(child_key))
            elif isinstance(value, list):
                for child in value:
                    collect(child, key)
            elif isinstance(value, str):
                normalized_key = key.casefold().replace("_", "").replace("-", "")
                if normalized_key not in {"name", "title", "label", "displayname"}:
                    identifiers.append(value)

        collect(item)
        name_key = provider_secret_key(name)
        for identifier in identifiers:
            identifier_key = provider_secret_key(identifier)
            if len(identifier_key) > 3 and (
                identifier_key == name_key
                or identifier_key in name_key
                or name_key in identifier_key
            ):
                return fallback
        return name

    def _new_id(self) -> str:
        # UUIDs are opaque cloud identifiers.  Nothing about a MAC, hostname,
        # private IP, client key, or adapter protocol is encoded in them.
        while True:
            value = "dev_" + uuid.uuid4().hex
            if value not in self.records:
                return value

    async def start(self) -> None:
        await self.tv.start()

    async def stop(self) -> None:
        await self.tv.stop()

    def set_cloud_mapping(self, mapping: dict[str, str]) -> None:
        """Install the authenticated cloud-id to private-local-id mapping."""

        if not isinstance(mapping, dict):
            raise ProtocolError("device mapping is invalid")
        next_mapping: dict[str, str] = {}
        for cloud_id, local_id in mapping.items():
            cloud_id = opaque_id(cloud_id, "cloudDeviceId")
            local_id = opaque_id(local_id, "deviceId")
            if local_id not in self.records or cloud_id in next_mapping:
                raise ProtocolError("device mapping references an unknown local device")
            next_mapping[cloud_id] = local_id
        self._cloud_ids = next_mapping

    async def load_cloud_mapping(self) -> None:
        """Restore the last authenticated mapping before polling can begin."""

        raw = await self.db.get_setting("runtime.cloud_device_mapping")
        if raw is None:
            return
        try:
            mapping = json.loads(raw)
        except (TypeError, ValueError) as exc:
            raise ProtocolError("durable device mapping is invalid") from exc
        self.set_cloud_mapping(mapping)

    async def persist_cloud_mapping(self) -> None:
        await self.db.set_setting(
            "runtime.cloud_device_mapping",
            json.dumps(self._cloud_ids, sort_keys=True, separators=(",", ":")),
        )

    def local_id(self, device_id: str) -> str:
        device_id = opaque_id(device_id)
        local_id = self._cloud_ids.get(device_id)
        if local_id is None:
            raise ProtocolError("device is not present in the authenticated inventory")
        return local_id

    async def discover(self, provider: str = "all") -> list[dict]:
        provider = "all" if provider == "all" else self._provider(provider)
        found = await self.tv.discover(provider)
        result = []
        for item in found[:100]:
            adapter_provider = self._provider(item.get("platform", provider))
            host = private_lan_ip(str(item.get("host", "")))
            existing = next(
                (
                    row
                    for row in self.records.values()
                    if row["provider"] == adapter_provider and row["host"] == host
                ),
                None,
            )
            if existing is None:
                existing = {
                    "id": self._new_id(),
                    "provider": adapter_provider,
                    "host": host,
                    "name": self._public_name(item, adapter_provider),
                    "generation": 0,
                    "linked": False,
                }
                self.records[existing["id"]] = existing
            else:
                existing["name"] = self._public_name(item, adapter_provider)
            result.append(self.public(existing, online=False))
        self._persist()
        return result

    def public(self, record: dict, *, online: bool | None = None) -> dict:
        provider = record["provider"]
        capabilities = (
            ["power", "volume", "mute", "media", "buttons", "apps", "input", "text"]
            if provider == "lg"
            else ["media", "buttons", "volume", "apps"]
        )
        return {
            "id": record["id"],
            "installationId": "",
            "name": self._public_name(record, provider),
            "provider": provider,
            "capabilities": capabilities,
            "online": bool(record.get("linked", False)) if online is None else bool(online),
        }

    def inventory(self, installation_id: str) -> list[dict]:
        return [
            dict(self.public(row), installationId=installation_id, generation=int(row["generation"]))
            for row in self.records.values()
        ]

    def apply_server_generations(self, generations: dict[str, int]) -> None:
        """Apply only server-issued generations to known local records."""

        for local_id, generation in generations.items():
            record = self.records.get(opaque_id(local_id, "deviceId"))
            if record is None or not isinstance(generation, int) or generation < 0:
                continue
            record["generation"] = max(int(record["generation"]), generation)
        if generations:
            self._persist()

    def _record(self, device_id: str, generation: int) -> dict:
        device_id = opaque_id(device_id)
        record = self.records.get(device_id)
        if record is None:
            raise ProtocolError("device is not known to this installation")
        if int(record["generation"]) != int(generation):
            raise ProtocolError("device generation is stale; refresh inventory")
        # Target authorization occurs before the adapter is selected or any
        # physical request can be made.
        private_lan_ip(record["host"])
        return record

    async def _select(self, record: dict) -> None:
        platform = "lg_webos" if record["provider"] == "lg" else "roku"
        snapshot = self.tv.snapshot()
        if (
            self.tv.platform != platform
            or snapshot.get("host") != record["host"]
            or not snapshot.get("enabled")
        ):
            await self.tv.configure(
                platform=platform,
                host=record["host"],
                name=record["name"],
                enabled=True,
            )

    @staticmethod
    def _sanitize_snapshot(snapshot: dict) -> dict:
        # Adapter snapshots contain the private configured host.  They never
        # cross the inventory/command boundary.
        result = dict(snapshot)
        for key in ("host", "mac", "mac_address", "client_key", "pairing_key"):
            result.pop(key, None)
        result["online"] = bool(
            result.get("connected") or result.get("lifecycle") in {"ready", "linked"}
        )
        return sanitize_result(result)

    async def link(self, device_id: str, generation: int) -> dict:
        record = self._record(device_id, generation)
        await self._select(record)
        # LG's pairing prompt and Roku's bounded probe are both explicit link
        # actions.  No link happens merely because discovery found an IP.
        result = await self.tv.start_pairing()
        record["linked"] = True
        self._persist()
        return {"device": self.public(record, online=False), "status": sanitize_result(result)}

    async def status(self, device_id: str, generation: int) -> dict:
        record = self._record(device_id, generation)
        await self._select(record)
        snapshot = self._sanitize_snapshot(self.tv.status())
        record["linked"] = bool(snapshot.get("paired"))
        self._persist()
        return {"device": self.public(record, online=snapshot.get("online")), "status": snapshot}

    async def control(self, payload: dict) -> dict:
        record = self._record(payload["deviceId"], payload["generation"])
        await self._select(record)
        action, value = payload["action"], payload["value"]
        if action in {"power_on", "powerOn"}:
            result = await self.tv.power_on()
        elif action in {"power_off", "powerOff"}:
            result = await self.tv.power_off()
        elif action == "button":
            result = await self.tv.button(value)
        elif action == "media":
            result = await self.tv.media(value)
        elif action == "volume":
            result = await self.tv.set_volume(**value)
        elif action == "volumeUp":
            result = await self.tv.set_volume(delta=1)
        elif action == "volumeDown":
            result = await self.tv.set_volume(delta=-1)
        elif action == "mute":
            result = await self.tv.set_mute(value)
        elif action == "input":
            result = await self.tv.set_input(value)
        elif action == "app":
            result = await self.tv.launch_app(value)
        elif action == "text":
            result = await self.tv.type_text(value)
        else:
            raise ProtocolError("control action is not permitted")
        return {"device": self.public(record), "result": sanitize_result(result)}

    async def apps(self, device_id: str, generation: int, refresh: bool = False) -> dict:
        record = self._record(device_id, generation)
        await self._select(record)
        if refresh:
            await self.tv.refresh_apps()
        active = self.tv._active
        apps = getattr(active, "_apps", [])
        clean = [
            {
                "id": str(item.get("id", ""))[:64],
                "title": str(item.get("title", ""))[:120],
            }
            for item in apps[:300]
            if isinstance(item, dict) and item.get("id") and item.get("title")
        ]
        return {"device": self.public(record), "apps": sanitize_result(clean)}

    async def remove(self, device_id: str, generation: int) -> dict:
        record = self._record(device_id, generation)
        await self._select(record)
        await self.tv.unpair()
        # Keep the discovery mapping (and its opaque ID) but fence all queued
        # commands.  A subsequent fresh discovery can explicitly link again.
        record["linked"] = False
        record["generation"] = int(record["generation"]) + 1
        self._persist()
        return {"device": self.public(record, online=False), "removed": True}