"""Async customer connector runtime.

The runtime owns only an enrolled bearer credential, a private LAN registry,
and protocol-2 polling.  It intentionally has no web server, shell bridge,
microphone, speaker, provider key, or owner/admin bootstrap path.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import platform as host_platform
import sys
import time
from pathlib import Path
from typing import Any, Callable

import httpx

from .commands import CommandProcessor
from .credentials import CredentialStore
from .devices import DeviceRegistry
from .installation import PrivateStorageError, secure_directory, secure_file
from .ledger import CommandLedger
from .localdb import CustomerDatabase
from .protocol import PROTOCOL_VERSION, ProtocolError, cloud_origin
from .transport import RuntimeTransport, TransportError
from .updater import CustomerUpdater, UpdateError
from .version import APP_VERSION


def _platform_name() -> str:
    value = sys.platform
    if value.startswith("win"):
        return "windows"
    if value == "darwin":
        return "macos"
    if value.startswith("linux"):
        return "linux"
    return "linux"


def _architecture_name() -> str:
    value = host_platform.machine().lower()
    return {
        "amd64": "x64",
        "x86_64": "x64",
        "aarch64": "arm64",
        "arm64": "arm64",
        "i386": "x86",
        "i686": "x86",
    }.get(value, value[:32] or "unknown")


class CustomerRuntime:
    """One isolated connector instance."""

    def __init__(
        self,
        *,
        server: str,
        data_dir: str | Path,
        pairing_token: str | None = None,
        name: str = "Nexa customer connector",
        kind: str = "connector",
        platform: str | None = None,
        version: str = APP_VERSION,
        install_root: str | Path | None = None,
        worker_nonce: str | None = None,
        transport: RuntimeTransport | None = None,
        on_restart: Callable[[], Any] | None = None,
    ) -> None:
        self.server = cloud_origin(server)
        try:
            self.data_dir = secure_directory(data_dir)
        except PrivateStorageError as exc:
            raise ValueError(str(exc)) from exc
        self.pairing_token = pairing_token
        self.name = " ".join(str(name).split())[:80] or "Nexa customer connector"
        self.kind = kind
        self.platform = platform or _platform_name()
        self.version = version
        self.install_root = Path(install_root or Path(__file__).resolve().parents[1]).resolve()
        if self.install_root == self.data_dir or self.data_dir in self.install_root.parents:
            raise ValueError("customer data directory must be separate from the installation")
        self.on_restart = on_restart
        self.worker_nonce = worker_nonce
        self.credentials = CredentialStore(self.data_dir)
        self.transport = transport or RuntimeTransport(
            self.server, worker_nonce=worker_nonce
        )
        if worker_nonce:
            self.transport.worker_nonce = worker_nonce
        self.db = CustomerDatabase(self.data_dir / "customer.db")
        for private_name in ("devices.json", "adapter-vault.key"):
            private_path = self.data_dir / private_name
            if private_path.exists():
                try:
                    secure_file(private_path)
                except PrivateStorageError as exc:
                    raise ValueError(str(exc)) from exc
        self.devices = DeviceRegistry(self.data_dir, self.db)
        self.ledger = CommandLedger(self.data_dir / "command-ledger.db")
        self.processor: CommandProcessor | None = None
        self.updater = CustomerUpdater(
            self.install_root,
            self.data_dir,
            platform=self.platform,
            arch=_architecture_name(),
            current_version=version,
            worker_nonce=worker_nonce,
        )
        self.installation_id: str | None = None
        self.workspace_id: str | None = None
        self._stop = asyncio.Event()
        self._started = False
        self._ready_update: dict[str, Any] | None = None
        self._running_ack: dict[str, Any] | None = None
        self._authority_lost = False
        self._restart_requested = False
        self._rollback_reconcile_delay = 1.0
        self._rollback_reconcile_next = 0.0

    @property
    def restart_requested(self) -> bool:
        """Whether the external supervisor must launch the swapped source."""

        return self._restart_requested

    def request_restart(self) -> None:
        """Stop this child after a durable source swap.

        The parent supervisor owns the process boundary.  A runtime must not
        ``exec`` from a directory that the updater is concurrently renaming.
        """

        self._restart_requested = True
        self._stop.set()

    async def start(self) -> None:
        if self._started:
            return
        await self.db.open()
        try:
            secure_file(self.db.path)
        except PrivateStorageError as exc:
            raise RuntimeError(str(exc)) from exc
        await self.devices.load_cloud_mapping()
        self.ledger.open()
        try:
            secure_file(self.ledger.path)
        except PrivateStorageError as exc:
            raise RuntimeError(str(exc)) from exc
        await self.transport.open()
        stored = self.credentials.load()
        if stored is None:
            if not self.pairing_token:
                raise RuntimeError(
                    "this customer connector is not enrolled; provide a fresh 10-minute pairing token"
                )
            enrollment = await self.transport.enroll(
                token=self.pairing_token,
                name=self.name,
                kind=self.kind,
                platform=self.platform,
                version=self.version,
                arch=_architecture_name(),
                schema_version=2,
            )
            self.credentials.save(
                {
                    "installationId": enrollment.installation_id,
                    "workspaceId": enrollment.workspace_id,
                    "credential": enrollment.credential,
                }
            )
            # Do not retain the single-use pairing token beyond enrollment.
            self.pairing_token = None
            stored = self.credentials.load()
        assert stored is not None
        self.installation_id = str(stored["installationId"])
        self.workspace_id = str(stored.get("workspaceId") or "")
        self.transport.credential = str(stored["credential"])
        self.transport.installation_id = self.installation_id
        self.transport.workspace_id = self.workspace_id
        await self.devices.start()
        self.processor = CommandProcessor(self.devices, self.ledger, self.transport)
        self.processor.set_inventory_callback(self.publish_inventory)
        self._started = True
        # A crash after source swap must restore the previous source before
        # this process starts acknowledging commands.
        launch_state = self.updater.state()
        await self._complete_launch_readiness(launch_state)
        await self._try_rollback_reconciliation()
        try:
            await self.publish_inventory()
        except TransportError as exc:
            if exc.revoked:
                self.credentials.clear()
                self.transport.credential = None
                self.transport.installation_id = None
                self.transport.workspace_id = None
                raise RuntimeError("customer installation was revoked") from exc
            raise
        try:
            await self.sync_update()
        except TransportError as exc:
            if exc.revoked:
                self.credentials.clear()
                self.transport.credential = None
                self.transport.installation_id = None
                self.transport.workspace_id = None
                raise RuntimeError("customer installation was revoked") from exc
        except (UpdateError, ProtocolError, OSError):
            pass

    async def stop(self) -> None:
        self._stop.set()
        with contextlib.suppress(Exception):
            await self.devices.stop()
        self.ledger.close()
        await self.db.close()
        await self.transport.close()
        self._started = False

    async def publish_inventory(self) -> None:
        if self.installation_id:
            mapping = await self.transport.inventory(self.devices.inventory(self.installation_id))
            self.devices.set_cloud_mapping(mapping)
            # Inventory generations are authoritative cloud fencing metadata,
            # not display data.  RuntimeTransport validates their shape and
            # stores them by local device id; apply them to the current
            # DeviceRegistry records before persisting the authenticated
            # mapping.  The registry mapping signature intentionally remains
            # mapping-only, so generation application stays at this boundary.
            generations = getattr(self.transport, "last_inventory_generations", {})
            if not isinstance(generations, dict):
                raise ProtocolError("inventory generations are invalid")
            for local_id, generation in generations.items():
                record = self.devices.records.get(local_id)
                if record is None:
                    raise ProtocolError("inventory generation references an unknown device")
                if (
                    isinstance(generation, bool)
                    or not isinstance(generation, int)
                    or generation < 0
                ):
                    raise ProtocolError("inventory generation is invalid")
                record["generation"] = generation
            if generations:
                self.devices._persist()
            await self.devices.persist_cloud_mapping()

    async def _complete_launch_readiness(self, state: dict[str, Any]) -> None:
        if state.get("phase") not in {"restarting", "ready"}:
            return
        nonce = str(state.get("nonce") or "")
        version = str(state.get("version") or "")
        assignment = state.get("assignmentId")
        try:
            actual = self.updater.mark_running(version=self.version, nonce=nonce)
        except UpdateError:
            # mark_running has not ACKed anything.  The durable updater state
            # remains failure/rollback evidence for the supervisor.
            self._ready_update = None
            raise
        self._ready_update = actual
        if not assignment:
            # Unit-level source swaps may be inspected locally, but a
            # production update is not committed without its lease-fenced
            # running ACK.
            return
        self._running_ack = {
            "assignment_id": str(assignment),
            "assignment_epoch": int(state.get("assignmentEpoch", 0)),
            "generation": int(state.get("generation", 0)),
            "lease_token": str(state.get("leaseToken", "")),
            "version": str(actual.get("actualVersion") or self.version),
            "sha256": str(actual.get("actualSha256") or ""),
        }
        try:
            await self._try_running_ack()
        except TransportError as exc:
            # Local code is proven ready.  A timeout/5xx/response loss is
            # receipt uncertainty, not a startup failure; keep the journal and
            # replay the exact terminal receipt later.
            if exc.revoked:
                self._authority_lost = True

    async def _try_running_ack(self) -> bool:
        pending = self._running_ack
        if not pending or self._authority_lost:
            return False
        try:
            await self.transport.ack_update(
                assignment_id=pending["assignment_id"],
                assignment_epoch=pending["assignment_epoch"],
                generation=pending["generation"],
                lease_token=pending["lease_token"],
                state="running",
                version=pending["version"],
                sha256=pending["sha256"],
            )
        except (httpx.HTTPError, OSError) as exc:
            raise TransportError("running receipt response was uncertain") from exc
        # The launch journal and external backup are the rollback boundary.
        # Keep both until the cloud has accepted the running receipt.
        self.updater.commit_running()
        self._running_ack = None
        return True

    async def _try_rollback_reconciliation(self) -> bool:
        """Replay a durable rollback receipt while this worker stays alive."""

        state = self.updater.state()
        if (
            state.get("phase") != "rolled_back"
            or state.get("reconciliationPending") is False
            or self._authority_lost
            or time.monotonic() < self._rollback_reconcile_next
        ):
            return False
        journal_worker = state.get("workerNonce")
        if journal_worker and journal_worker != self.worker_nonce:
            return False
        assignment = state.get("assignmentId")
        previous = state.get("previousVersion")
        try:
            assignment_epoch = int(state.get("assignmentEpoch"))
            generation = int(state.get("generation"))
            lease_token = str(state.get("leaseToken") or "")
        except (TypeError, ValueError):
            return False
        if (
            not isinstance(assignment, str)
            or not assignment
            or not isinstance(previous, str)
            or not previous
            or assignment_epoch < 1
            or generation < 1
            or not lease_token
        ):
            return False
        try:
            await self.transport.ack_update(
                assignment_id=assignment,
                assignment_epoch=assignment_epoch,
                generation=generation,
                lease_token=lease_token,
                state="rolled_back",
                version=previous,
            )
        except TransportError as exc:
            if exc.revoked:
                self._authority_lost = True
            self._rollback_reconcile_next = time.monotonic() + self._rollback_reconcile_delay
            self._rollback_reconcile_delay = min(self._rollback_reconcile_delay * 2, 60.0)
            return False
        except (httpx.HTTPError, OSError):
            self._rollback_reconcile_next = time.monotonic() + self._rollback_reconcile_delay
            self._rollback_reconcile_delay = min(self._rollback_reconcile_delay * 2, 60.0)
            return False
        self.updater.commit_rollback_reconciliation()
        self._rollback_reconcile_delay = 1.0
        self._rollback_reconcile_next = 0.0
        return True

    async def sync_update(self) -> None:
        """Fetch and stage one server-assigned target; no arbitrary URL input."""

        desired = await self.transport.desired_update()
        if desired is None:
            return
        if desired.get("state") in {"cancelled", "paused", "failed", "rolled_back"}:
            # A lease can be cancelled while still pre-commit.  Do not stage
            # or rename source in response to a terminal assignment.
            return
        assignment = desired.get("assignmentId")
        if not isinstance(assignment, str) or not assignment:
            raise UpdateError("assigned update has no assignment id")
        desired = dict(desired)
        desired["assignmentId"] = assignment
        try:
            assignment_epoch = int(desired["assignmentEpoch"])
            generation = int(desired["generation"])
            lease_token = str(desired["leaseToken"])
        except (KeyError, TypeError, ValueError) as exc:
            raise UpdateError("assigned update lease metadata is invalid") from exc
        if assignment_epoch < 1 or generation < 1 or not lease_token:
            raise UpdateError("assigned update lease metadata is invalid")
        ack = {
            "assignment_epoch": assignment_epoch,
            "generation": generation,
            "lease_token": lease_token,
        }
        try:
            await self.transport.ack_update(
                assignment_id=assignment, state="downloading", **ack
            )
            heartbeat_lost = asyncio.Event()

            async def downloading_heartbeat() -> None:
                while True:
                    await asyncio.sleep(5)
                    try:
                        await self.transport.ack_update(
                            assignment_id=assignment,
                            **ack,
                            state="downloading",
                        )
                    except (TransportError, httpx.HTTPError, OSError):
                        heartbeat_lost.set()
                        return

            heartbeat = asyncio.create_task(downloading_heartbeat())
            try:
                await self.updater.stage(desired)
            finally:
                heartbeat.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await heartbeat
            if heartbeat_lost.is_set():
                raise TransportError("update lease was lost while downloading")
            await self.transport.ack_update(
                assignment_id=assignment, state="verified", **ack
            )
            await self.transport.ack_update(
                assignment_id=assignment,
                **ack,
                state="staged",
                version=str(desired.get("version") or ""),
                sha256=str(desired.get("sha256") or ""),
            )
            await self.transport.ack_update(
                assignment_id=assignment,
                **ack,
                state="restarting",
                version=str(desired.get("version") or ""),
                sha256=str(desired.get("sha256") or ""),
            )
            # `restarting` is the commit intent.  It must be accepted before
            # any source rename; once the rename succeeds, request process
            # exit unconditionally even if a later network operation fails.
            self.updater.apply_staged()
            self._restart_requested = True
            self._stop.set()
            if self.on_restart is not None:
                with contextlib.suppress(Exception):
                    result = self.on_restart()
                    if asyncio.iscoroutine(result):
                        await result
        except Exception as exc:
            with contextlib.suppress(Exception):
                await self.transport.ack_update(
                    assignment_id=assignment,
                    **ack,
                    state="failed",
                    error=str(exc)[:4096],
                )
            raise

    async def poll_once(self, *, wait_seconds: int = 25) -> dict[str, Any]:
        if not self.processor:
            raise RuntimeError("customer runtime is not started")
        body = await self.transport.poll(wait_seconds=wait_seconds)
        await self._try_rollback_reconciliation()
        if self._running_ack:
            try:
                await self._try_running_ack()
            except TransportError as exc:
                if exc.revoked:
                    self._authority_lost = True
                # Keep the new source, journal, and backup.  Running is an
                # idempotent terminal receipt; this is not local code failure.
                return body
        for wire in body.get("commands", []):
            await self.processor.process(wire)
        # Reconnect boundaries are update boundaries too.  The desired endpoint
        # is authenticated by this installation credential.
        try:
            await self.sync_update()
        except TransportError as exc:
            if exc.revoked:
                raise
        except UpdateError:
            pass
        return body

    async def run(self) -> None:
        if not self._started:
            await self.start()
        delay = 1.0
        while not self._stop.is_set():
            try:
                await self.poll_once()
                delay = 1.0
            except TransportError as exc:
                if exc.revoked:
                    with contextlib.suppress(Exception):
                        self.credentials.clear()
                    self.transport.credential = None
                    self.transport.installation_id = None
                    self.transport.workspace_id = None
                    raise RuntimeError("customer installation was revoked") from exc
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=delay)
                    break
                except asyncio.TimeoutError:
                    delay = min(delay * 2, 60.0)
            except (ProtocolError, OSError):
                # Protocol violations are surfaced to logs by the entrypoint,
                # but a malformed/temporarily incompatible poll cannot trigger
                # physical effects or a tight reconnect loop.
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=delay)
                    break
                except asyncio.TimeoutError:
                    delay = min(delay * 2, 60.0)