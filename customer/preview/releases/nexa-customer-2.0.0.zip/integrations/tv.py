"""One active-TV facade over the independently persisted local TV adapters."""

from __future__ import annotations

import asyncio

from integrations.lg_webos import WebOSManager
from integrations.roku import RokuManager

PLATFORMS = frozenset({"lg_webos", "roku"})
ACTIVE_PLATFORM_SETTING = "tv_active_platform"


class TVManager:
    """Keeps the old single active-TV model while retaining each adapter's setup.

    This deliberately does not merge devices: voice grammar has always named
    one TV, so selecting a platform is safer than silently sending a command
    to two screens. Switching back preserves the LG pairing key and Roku link.
    """
    def __init__(self, db, bus, vault, settings=None, **lg_kwargs) -> None:
        self.db = db
        self.lg = WebOSManager(db, bus, vault, settings, **lg_kwargs)
        self.roku = RokuManager(db, bus, settings)
        self.platform = "lg_webos"

    def __getattr__(self, name):
        """Keep test/injection hooks and existing internal callers compatible."""
        return getattr(self._active, name)

    def __setattr__(self, name, value) -> None:
        # Existing LG tests inject transport fakes directly on rt.tv.  Only
        # delegate unknown private implementation hooks after both adapters
        # have been created; facade state remains local.
        if (
            name.startswith("_") and name not in {"_active"}
            and "lg" in self.__dict__ and "roku" in self.__dict__
            and not hasattr(type(self), name)
        ):
            setattr(self._active, name, value)
            return
        object.__setattr__(self, name, value)

    @property
    def _active(self):
        return self.roku if self.platform == "roku" else self.lg

    async def start(self) -> None:
        saved = await self.db.get_setting(ACTIVE_PLATFORM_SETTING, "lg_webos")
        self.platform = saved if saved in PLATFORMS else "lg_webos"
        await self._active.start()

    async def stop(self) -> None:
        await self._active.stop()

    def _with_contract(self, snapshot: dict) -> dict:
        out = dict(snapshot)
        out["platform"] = self.platform
        out["platforms"] = ["lg_webos", "roku"]
        if "capabilities" not in out:
            out["capabilities"] = {
                "power": True, "volume_set": True, "volume_delta": True, "mute": True,
                "media": True, "buttons": True, "apps": True, "input": True, "text": True,
                "pairing": True,
            }
        return out

    def snapshot(self) -> dict:
        return self._with_contract(self._active.snapshot())

    async def configure(self, platform: str | None = None, **kwargs) -> dict:
        target = str(platform or self.platform).strip().lower()
        if target not in PLATFORMS:
            from integrations.lg_webos import WebOSTVError
            raise WebOSTVError("TV platform must be LG webOS or Roku")
        if target != self.platform:
            await self._active.stop()
            self.platform = target
            await self.db.set_setting(ACTIVE_PLATFORM_SETTING, target)
            await self._active.start()
        return self._with_contract(await self._active.configure(**kwargs))

    async def discover(self, platform: str | None = None) -> list[dict]:
        target = str(platform or self.platform).strip().lower()
        if target == "all":
            lg, roku = await asyncio.gather(self.lg.discover(), self.roku.discover())
            return (
                [dict(item, platform="lg_webos") for item in lg]
                + [dict(item, platform="roku") for item in roku]
            )
        if target not in PLATFORMS:
            from integrations.lg_webos import WebOSTVError
            raise WebOSTVError("TV platform must be LG webOS or Roku")
        # Preserve the old one-adapter discovery response for callers that do
        # not ask to scan all platforms; the Devices UI requests "all" when
        # it needs an explicit chooser.
        return await (self.roku if target == "roku" else self.lg).discover()

    async def refresh(self):
        return self._with_contract(await self._active.refresh())

    async def start_pairing(self): return await self._active.start_pairing()
    async def unpair(self): return self._with_contract(await self._active.unpair())
    async def power_on(self): return await self._active.power_on()
    async def power_off(self): return await self._active.power_off()
    async def set_volume(self, **kwargs): return await self._active.set_volume(**kwargs)
    async def set_mute(self, value): return await self._active.set_mute(value)
    async def media(self, value): return await self._active.media(value)
    async def button(self, value): return await self._active.button(value)
    async def type_text(self, text, **kwargs): return await self._active.type_text(text, **kwargs)
    async def set_input(self, value): return await self._active.set_input(value)
    async def launch_app(self, value): return await self._active.launch_app(value)
    async def refresh_apps(self): return await self._active.refresh_apps()
    async def search_content(self, app, query): return await self._active.search_content(app, query)
    async def play_youtube_video(self, video_id): return await self._active.play_youtube_video(video_id)
    def search_apps(self, query): return self._active.search_apps(query)
    def status(self): return self.snapshot()
