"""Small, deliberately closed Roku ECP protocol surface."""

from __future__ import annotations

import ipaddress
import re

ECP_PORT = 8060
MAX_BODY_BYTES = 64 * 1024
MAX_TEXT_BYTES = 8 * 1024

# ECP key names are part of the URL path, so accepting arbitrary names would
# turn the dashboard into an ECP request proxy.  Keep the public vocabulary
# separate from Roku's spelling.
BUTTONS = {
    "up": "Up", "down": "Down", "left": "Left", "right": "Right",
    "ok": "Select", "select": "Select", "enter": "Enter",
    "back": "Back", "home": "Home", "info": "Info", "menu": "Info",
    "replay": "InstantReplay",
}
MEDIA_KEYS = {
    # Roku exposes one Play remote key, not independent pause/stop state
    # commands. Do not relabel that toggle as commands it cannot guarantee.
    "play": "Play", "rewind": "Rev", "fast_forward": "Fwd",
}
VOLUME_KEYS = {"up": "VolumeUp", "down": "VolumeDown"}
INPUT_KEYS = {
    "antenna": "InputTuner", "tv": "InputTuner", "av": "InputAV1",
    "hdmi 1": "InputHDMI1", "hdmi 2": "InputHDMI2",
    "hdmi 3": "InputHDMI3", "hdmi 4": "InputHDMI4",
}

_APP_ID = re.compile(r"^[0-9]{1,12}$")


def valid_host(value: str) -> bool:
    """Only a private IPv4 literal may be used for Roku ECP.

    ECP is unauthenticated HTTP.  Requiring a literal prevents DNS rebinding,
    and rejecting every non-private range keeps this local control feature
    from becoming an SSRF primitive.
    """
    try:
        ip = ipaddress.IPv4Address(str(value).strip())
    except ipaddress.AddressValueError:
        return False
    return ip.is_private and not (
        ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_unspecified
    )


def valid_app_id(value: str) -> bool:
    return bool(_APP_ID.fullmatch(str(value).strip()))