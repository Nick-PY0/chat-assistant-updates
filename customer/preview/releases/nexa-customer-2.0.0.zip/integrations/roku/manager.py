"""Roku/TCL Roku OS local ECP manager.

Roku ECP uses unauthenticated HTTP on a local TV.  There is no pairing key,
Wake-on-LAN contract, keyboard insertion, or reliable power/state-volume API;
this manager intentionally exposes none of those as if they existed.
"""

from __future__ import annotations

import asyncio
import contextlib
import difflib
import time
import xml.etree.ElementTree as ET
from typing import Any, Awaitable, Callable

from integrations.lg_webos import WebOSTVError
from . import discovery as ssdp
from .protocol import (
    BUTTONS, ECP_PORT, MAX_BODY_BYTES, MEDIA_KEYS, VOLUME_KEYS,
    valid_app_id, valid_host,
)

DEVICE_ID = "default"
POLL_SECONDS = 20.0
REQUEST_TIMEOUT = 4.0


class RokuTVError(WebOSTVError):
    """An error suitable for dashboard/voice display."""


def _now_iso() -> str:
    from chat_core.models.credentials import iso, utcnow
    return iso(utcnow())


def _xml(data: bytes) -> ET.Element:
    if not data or len(data) > MAX_BODY_BYTES:
        raise RokuTVError("the Roku returned an invalid response")
    # stdlib ElementTree does not resolve external entities, but reject DTDs
    # outright as a second bound against entity-expansion parser work.
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise RokuTVError("the Roku returned an invalid response")
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        raise RokuTVError("the Roku returned an invalid response") from None


class RokuManager:
    def __init__(
        self,
        db,
        bus,
        settings=None,
        request_fn: Callable[[str, str], Awaitable[tuple[int, bytes]]] | None = None,
        discover_fn: Callable[[], Awaitable[list[dict]]] | None = None,
        poll_seconds: float = POLL_SECONDS,
    ) -> None:
        self.db, self.bus, self.settings = db, bus, settings
        self._request_fn = request_fn
        self._discover_fn = discover_fn or ssdp.discover
        self._poll_seconds = max(2.0, float(poll_seconds))
        self.enabled = False
        self.paired = False  # "linked": retained for the common TV contract.
        self.host = ""
        self.name = "Roku TV"
        self._connected = False
        self._lifecycle = "offline"
        self._last_error = ""
        self._last_seen_at: str | None = None
        self._model = ""
        self._app = ""
        self._apps: list[dict] = []
        self._apps_fresh = False
        self._is_tv = False
        self._seq = 0
        # Fences poll/command results across host changes, unlink, and active
        # platform switches. Never reset this counter on start().
        self._generation = 0
        self._cmd_lock = asyncio.Lock()
        self._poll_task: asyncio.Task | None = None
        self._stopping = False

    async def start(self) -> None:
        # TVManager stops inactive adapters during a platform switch. Reopen
        # the manager before restoring persisted linked configuration, or a
        # newly created poll loop would immediately exit on _stopping.
        self._stopping = False
        row = await self.db.fetchone("SELECT * FROM roku_ecp_devices WHERE id=?", (DEVICE_ID,))
        if row is not None:
            self.name = row["name"] or "Roku TV"
            self.host = row["host"] or ""
            self.enabled = bool(row["enabled"])
            self.paired = bool(row["linked"])
            self._last_seen_at = row["last_seen_at"]
        if self.enabled and self.paired and self.host:
            self._spawn_poll()

    async def stop(self) -> None:
        self._stopping = True
        self._generation += 1
        if self._poll_task is not None:
            self._poll_task.cancel()
            await asyncio.gather(self._poll_task, return_exceptions=True)
            self._poll_task = None
        self._connected = False

    def _spawn_poll(self) -> None:
        if self._poll_task is None or self._poll_task.done():
            self._poll_task = asyncio.create_task(
                self._poll_loop(self._generation), name="roku-tv"
            )

    async def _poll_loop(self, generation: int) -> None:
        while (
            not self._stopping and generation == self._generation
            and self.enabled and self.paired and self.host
        ):
            await self._refresh_network(generation)
            try:
                await asyncio.sleep(self._poll_seconds)
            except asyncio.CancelledError:
                raise

    async def configure(
        self, name: str | None = None, host: str | None = None,
        enabled: bool | None = None, **_ignored,
    ) -> dict:
        restart_poll = False
        if name is not None:
            value = " ".join(str(name).split())[:60]
            if value:
                self.name = value
        if host is not None:
            value = str(host).strip()
            if value and not valid_host(value):
                raise RokuTVError("enter a private IPv4 Roku address, such as 192.168.1.50")
            if value != self.host:
                self._generation += 1
                restart_poll = True
                self.host = value
                self._connected = False
                self._apps_fresh = False
        if enabled is not None:
            next_enabled = bool(enabled)
            if next_enabled != self.enabled:
                self._generation += 1
                restart_poll = True
            self.enabled = next_enabled
        if restart_poll and self._poll_task is not None:
            self._poll_task.cancel()
            await asyncio.gather(self._poll_task, return_exceptions=True)
            self._poll_task = None
        if self.enabled and not self.host:
            self.enabled = False
            await self._persist()
            raise RokuTVError("enter the Roku TV's private IP address (or use Discover) before enabling")
        await self._persist()
        if self.enabled and self.paired and self.host:
            self._spawn_poll()
        self._publish()
        return self.snapshot()

    async def discover(self) -> list[dict]:
        try:
            found = await self._discover_fn()
        except Exception:
            raise RokuTVError("Roku discovery failed; enter its private IP address manually") from None
        return [
            {"host": str(item.get("host", "")), "name": str(item.get("name") or "Roku TV")[:60],
             "platform": "roku"}
            for item in found if valid_host(str(item.get("host", "")))
        ]

    async def start_pairing(self) -> dict:
        """ECP needs no on-screen approval: link only after a bounded probe."""
        if not self.enabled:
            raise RokuTVError("turn the TV feature on before linking the Roku")
        if not self.host:
            raise RokuTVError("enter the Roku TV's IP address (or use Discover) first")
        generation = self._generation
        await self._refresh_network(generation, raise_on_error=True)
        if generation != self._generation or self._stopping:
            raise RokuTVError("Roku configuration changed while linking; try again")
        self.paired = True
        await self._persist()
        self._spawn_poll()
        self._publish()
        return {"status": "linked"}

    async def unpair(self) -> dict:
        self._generation += 1
        self.paired = False
        self._connected = False
        self._lifecycle = "offline"
        if self._poll_task is not None:
            self._poll_task.cancel()
            await asyncio.gather(self._poll_task, return_exceptions=True)
            self._poll_task = None
        await self._persist()
        self._publish()
        return self.snapshot()

    async def _http(self, method: str, path: str) -> tuple[int, bytes]:
        if not valid_host(self.host):
            raise RokuTVError("the saved Roku address is invalid")
        if self._request_fn is not None:
            try:
                return await self._request_fn(method, path)
            except RokuTVError:
                raise
            except Exception:
                raise RokuTVError("the Roku is offline or unreachable") from None
        try:
            import httpx
            url = f"http://{self.host}:{ECP_PORT}{path}"
            async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT, follow_redirects=False) as client:
                async with client.stream(
                    method, url, headers={"Accept": "application/xml"}
                ) as response:
                    if response.is_redirect:
                        raise RokuTVError("the Roku returned an unexpected redirect")
                    # Do not let an HTTP peer make discovery/status parsing
                    # consume arbitrary memory. One extra byte lets _xml()
                    # reject an oversized body without parsing it.
                    body = bytearray()
                    async for chunk in response.aiter_bytes():
                        room = MAX_BODY_BYTES + 1 - len(body)
                        if room <= 0:
                            break
                        body.extend(chunk[:room])
                        if len(body) > MAX_BODY_BYTES:
                            break
                    return response.status_code, bytes(body)
        except RokuTVError:
            raise
        except Exception:
            raise RokuTVError("the Roku is offline or unreachable") from None

    async def _get_xml(self, path: str) -> ET.Element:
        status, body = await self._http("GET", path)
        if status != 200:
            raise RokuTVError("the Roku did not accept that request")
        return _xml(body)

    async def _refresh_network(
        self, generation: int | None = None, raise_on_error: bool = False
    ) -> None:
        generation = self._generation if generation is None else generation
        if generation != self._generation or self._stopping:
            return
        if not self.host:
            return
        self._lifecycle = "connecting"
        self._publish()
        try:
            info = await self._get_xml("/query/device-info")
            if generation != self._generation or self._stopping:
                return
            model = (info.findtext("model-name") or info.findtext("friendly-model-name") or "").strip()
            is_tv = (info.findtext("is-tv") or "").strip().lower() == "true"
            app = ""
            with contextlib.suppress(RokuTVError):
                active = await self._get_xml("/query/active-app")
                if generation != self._generation or self._stopping:
                    return
                child = next(iter(active), None)
                app = (child.text or "").strip()[:80] if child is not None else ""
            if not self._apps_fresh:
                with contextlib.suppress(RokuTVError):
                    apps = self._apps_from_xml(await self._get_xml("/query/apps"))
                    if generation != self._generation or self._stopping:
                        return
                    self._apps = apps
                    self._apps_fresh = True
            self._connected, self._lifecycle, self._last_error = True, "ready", ""
            self._model, self._is_tv, self._app = model[:80], is_tv, app
            self._last_seen_at = _now_iso()
        except RokuTVError as exc:
            if generation != self._generation or self._stopping:
                return
            self._connected, self._lifecycle = False, "offline"
            self._last_error = str(exc)[:160]
            if raise_on_error:
                self._publish()
                raise
        finally:
            if generation == self._generation and not self._stopping:
                self._publish()

    @staticmethod
    def _apps_from_xml(root: ET.Element) -> list[dict]:
        apps = []
        for node in root.findall("app"):
            app_id, title = str(node.attrib.get("id", "")), (node.text or "").strip()
            if valid_app_id(app_id) and title:
                apps.append({"id": app_id, "title": title[:80]})
        return apps[:300]

    async def refresh(self) -> dict:
        if self.enabled and self.paired and self.host:
            await self._refresh_network(self._generation)
        return self.snapshot()

    def _require_connected(self) -> None:
        if not self.enabled:
            raise RokuTVError("TV control is turned off; enable it on the Devices page")
        if not self.paired:
            raise RokuTVError("the Roku isn't linked yet; link it from the Devices page")
        if not self._connected:
            raise RokuTVError("the Roku is offline or unreachable")

    async def _keypress(self, key: str) -> None:
        status, _body = await self._http("POST", f"/keypress/{key}")
        if status not in (200, 204):
            raise RokuTVError("the Roku did not accept that command")

    async def button(self, name: str) -> dict:
        key = str(name).strip().lower().replace(" ", "_")
        remote = BUTTONS.get(key)
        if remote is None:
            raise RokuTVError(f"button must be one of: {', '.join(sorted(BUTTONS))}")
        generation = self._generation
        async with self._cmd_lock:
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
            self._require_connected()
            await self._keypress(remote)
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
        return {"pressed": key}

    async def media(self, action: str) -> dict:
        key = str(action).strip().lower()
        remote = MEDIA_KEYS.get(key)
        if remote is None:
            raise RokuTVError(f"media action must be one of: {', '.join(sorted(MEDIA_KEYS))}")
        generation = self._generation
        async with self._cmd_lock:
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
            self._require_connected()
            await self._keypress(remote)
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
        return {"action": key}

    async def set_volume(self, percentage=None, delta=None) -> dict:
        if percentage is not None:
            raise RokuTVError("Roku ECP cannot read or set an exact volume percentage")
        try:
            change = int(delta)
        except (TypeError, ValueError):
            raise RokuTVError("volume change must be a number") from None
        if not change:
            return {"volume_changed": 0}
        steps = min(abs(change), 20)
        generation = self._generation
        async with self._cmd_lock:
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
            self._require_connected()
            for _ in range(steps):
                if generation != self._generation or self._stopping:
                    raise RokuTVError("Roku configuration changed; try the command again")
                await self._keypress(VOLUME_KEYS["up" if change > 0 else "down"])
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
        return {"volume_changed": steps if change > 0 else -steps}

    async def set_mute(self, muted: bool) -> dict:
        raise RokuTVError("Roku ECP cannot report or set mute state reliably")

    async def refresh_apps(self) -> dict:
        generation = self._generation
        if generation != self._generation or self._stopping:
            raise RokuTVError("Roku configuration changed; try again")
        self._require_connected()
        apps = self._apps_from_xml(await self._get_xml("/query/apps"))
        if generation != self._generation or self._stopping:
            raise RokuTVError("Roku configuration changed; try again")
        self._apps = apps
        self._apps_fresh = True
        self._publish()
        return {"apps": len(self._apps)}

    def search_apps(self, query: str) -> dict:
        if not self.enabled or not self.paired:
            raise RokuTVError("the Roku isn't linked yet; link it from the Devices page")
        q = " ".join(str(query).lower().split())
        return {"apps": [a for a in self._apps if not q or q in a["title"].lower()], "stale": not self._connected}

    async def launch_app(self, value: str) -> dict:
        generation = self._generation
        candidate = str(value).strip()
        app = next((a for a in self._apps if a["id"] == candidate), None)
        if app is None:
            matches = [a for a in self._apps if a["title"].lower() == candidate.lower()]
            if len(matches) == 1:
                app = matches[0]
        if app is None:
            close = difflib.get_close_matches(candidate, [a["title"] for a in self._apps], n=1, cutoff=.75)
            hint = f" Try '{close[0]}'." if close else ""
            raise RokuTVError("that app isn't installed on the Roku." + hint)
        async with self._cmd_lock:
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
            self._require_connected()
            status, _body = await self._http("POST", f"/launch/{app['id']}")
            if status not in (200, 204):
                raise RokuTVError("the Roku did not accept that app launch")
            if generation != self._generation or self._stopping:
                raise RokuTVError("Roku configuration changed; try the command again")
        return {"launched": app["title"]}

    async def set_input(self, value: str) -> dict:
        # ECP identifies a Roku TV but never enumerates installed physical
        # inputs. Sending a guessed InputHDMI<n> key would be a false promise,
        # so this adapter deliberately does not expose an input picker.
        raise RokuTVError("Roku ECP does not enumerate available TV inputs")

    async def power_on(self) -> dict:
        raise RokuTVError("Roku ECP does not support turning the TV on")

    async def power_off(self) -> dict:
        raise RokuTVError("Roku ECP does not support turning the TV off")

    async def type_text(self, *_args, **_kwargs) -> dict:
        raise RokuTVError("Roku ECP does not support typing text into TV fields")

    async def search_content(self, *_args, **_kwargs) -> dict:
        raise RokuTVError("Roku content search is not enabled because ECP cannot safely type a query")

    async def play_youtube_video(self, *_args, **_kwargs) -> dict:
        raise RokuTVError("Roku ECP cannot safely launch arbitrary YouTube content URLs")

    def status(self) -> dict:
        return self.snapshot()

    def snapshot(self) -> dict:
        configured = bool(self.host)
        return {
            "enabled": self.enabled, "configured": configured, "host": self.host, "name": self.name,
            "paired": self.paired, "connected": self._connected, "lifecycle": (
                "disabled" if not self.enabled else "unpaired" if not self.paired else self._lifecycle
            ),
            "can_command": self.enabled and self.paired and self._connected,
            "power": None, "power_confirmed": False, "volume": None, "muted": None,
            "app": self._app, "model": self._model, "app_count": len(self._apps),
            "apps_stale": not self._apps_fresh or not self._connected, "inputs": [],
            "wol_ready": False, "last_error": self._last_error, "last_seen_at": self._last_seen_at,
            "pairing": {"status": "linked" if self.paired else "idle", "error": ""},
            "seq": self._seq, "keyboard": {"focused": False},
            "capabilities": {
                "power": False, "volume_set": False, "volume_delta": True, "mute": False,
                "media": True, "buttons": True, "apps": True, "input": False,
                "text": False, "pairing": False,
            },
            "media_actions": sorted(MEDIA_KEYS),
            "button_actions": sorted(BUTTONS),
        }

    async def _persist(self) -> None:
        await self.db.execute(
            "INSERT INTO roku_ecp_devices (id, name, host, enabled, linked, last_seen_at, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET "
            "name=excluded.name, host=excluded.host, enabled=excluded.enabled, linked=excluded.linked, "
            "last_seen_at=excluded.last_seen_at, updated_at=excluded.updated_at",
            (DEVICE_ID, self.name, self.host, int(self.enabled), int(self.paired), self._last_seen_at, _now_iso(), _now_iso()),
        )

    def _publish(self) -> None:
        self._seq += 1
        with contextlib.suppress(Exception):
            self.bus.publish("tv", **self.snapshot())
