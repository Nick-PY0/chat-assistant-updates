"""Bounded SSDP discovery for Roku ECP devices."""

from __future__ import annotations

import asyncio
import contextlib
import ipaddress
import socket
from urllib.parse import urlsplit

from .protocol import ECP_PORT, valid_host

SSDP_ADDR = "239.255.255.250"
SSDP_PORT = 1900
SEARCH_TARGET = "roku:ecp"
DISCOVER_WINDOW = 3.0
MAX_DATAGRAM = 4096


def parse_ssdp_response(data: bytes, sender_ip: str) -> dict | None:
    """Accept only a Roku ECP reply from the exact private IPv4 sender."""
    if len(data) > MAX_DATAGRAM or not valid_host(sender_ip):
        return None
    lines = data.decode("latin-1", "ignore").splitlines()
    if not lines or not (
        lines[0].upper().startswith("HTTP/1.1 200") or lines[0].upper().startswith("NOTIFY")
    ):
        return None
    headers: dict[str, str] = {}
    for line in lines[1:80]:
        if ":" in line:
            key, value = line.split(":", 1)
            headers[key.strip().lower()] = value.strip()
    target = headers.get("st", headers.get("nt", "")).lower()
    if target != SEARCH_TARGET:
        return None
    # LOCATION is never fetched: it is merely checked to ensure that the
    # responder did not advertise a different ECP host/port.
    location = headers.get("location", "")
    if location:
        try:
            parts = urlsplit(location)
            advertised = ipaddress.ip_address(parts.hostname or "")
            port = parts.port
        except ValueError:
            return None
        if (
            parts.scheme != "http" or "@" in parts.netloc
            or advertised != ipaddress.ip_address(sender_ip)
            or port not in (None, ECP_PORT)
        ):
            return None
    return {"host": sender_ip, "name": "Roku TV"}


class _Collector(asyncio.DatagramProtocol):
    def __init__(self) -> None:
        self.responses: list[tuple[bytes, str]] = []

    def datagram_received(self, data: bytes, addr) -> None:  # type: ignore[override]
        if len(data) <= MAX_DATAGRAM:
            self.responses.append((data, addr[0]))


async def discover(window: float = DISCOVER_WINDOW) -> list[dict]:
    """Find ECP responders without following their attacker-controlled URLs."""
    loop = asyncio.get_running_loop()
    try:
        transport, collector = await loop.create_datagram_endpoint(
            _Collector, family=socket.AF_INET, proto=socket.IPPROTO_UDP
        )
    except OSError:
        return []
    try:
        packet = (
            "M-SEARCH * HTTP/1.1\r\n"
            f"HOST: {SSDP_ADDR}:{SSDP_PORT}\r\n"
            'MAN: "ssdp:discover"\r\n'
            "MX: 2\r\n"
            f"ST: {SEARCH_TARGET}\r\n\r\n"
        ).encode("ascii")
        for _ in range(3):
            with contextlib.suppress(OSError):
                transport.sendto(packet, (SSDP_ADDR, SSDP_PORT))
            await asyncio.sleep(0.25)
        await asyncio.sleep(max(0.5, window - 0.75))
    finally:
        transport.close()
    found: dict[str, dict] = {}
    for data, sender in collector.responses:
        parsed = parse_ssdp_response(data, sender)
        if parsed is not None:
            found.setdefault(parsed["host"], parsed)
    return list(found.values())