"""Minimal Nexa customer connector entrypoint.

Unlike ``run_chat.py`` this process has no dashboard, browser tunnel, owner
database, provider key, microphone, speaker, audio task, shell, or arbitrary
HTTP proxy.  It is an explicitly enrolled LAN worker only.
"""

from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path
import sys

from customer.installation import PrivateStorageError, secure_directory
from customer.locking import LockError, acquire
from customer.supervisor import RESTART_EXIT_CODE, external_working_directory, run_child_supervisor


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Nexa customer LAN connector")
    parser.add_argument(
        "--data-dir",
        required=True,
        help="private customer state directory (must be separate from the install)",
    )
    parser.add_argument(
        "--server",
        required=True,
        help="Nexa HTTPS origin (plain HTTP is accepted only for loopback fixtures)",
    )
    parser.add_argument("--pair-token", default=None, help="single-use 10-minute pairing token")
    parser.add_argument("--name", default="Nexa customer connector", help="installation label")
    parser.add_argument("--once", action="store_true", help="poll once and exit (diagnostics/tests)")
    parser.add_argument("--poll-wait", type=int, default=25, help="bounded long-poll seconds")
    parser.add_argument(
        "--customer-child",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--update-worker",
        default=None,
        help=argparse.SUPPRESS,
    )
    return parser.parse_args(argv)


async def _run(args: argparse.Namespace) -> int:
    from customer.runtime import CustomerRuntime, _platform_name

    runtime = CustomerRuntime(
        server=args.server,
        data_dir=Path(args.data_dir).expanduser(),
        pairing_token=args.pair_token,
        name=args.name,
        platform=_platform_name(),
        install_root=Path(__file__).resolve().parent,
        worker_nonce=args.update_worker,
    )
    try:
        await runtime.start()
        if args.once:
            await runtime.poll_once(wait_seconds=args.poll_wait)
        else:
            await runtime.run()
        return RESTART_EXIT_CODE if runtime.restart_requested else 0
    finally:
        await runtime.stop()


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.poll_wait < 0 or args.poll_wait > 30:
        raise SystemExit("--poll-wait must be between 0 and 30 seconds")
    data_dir = Path(args.data_dir).expanduser()
    if args.customer_child:
        try:
            data_dir = secure_directory(data_dir)
            external_working_directory(data_dir)
            # The external parent owns the instance lock.  This child is
            # deliberately started with an external CWD and exits after a
            # durable source swap.
            return asyncio.run(_run(args))
        except PrivateStorageError as exc:
            print(f"Customer connector private storage is unavailable: {exc}")
            return 1
        except KeyboardInterrupt:
            return 0
    try:
        data_dir = secure_directory(data_dir)
        external_working_directory(data_dir)
        lock = acquire(data_dir / ".nexa-instance.lock")
    except PrivateStorageError as exc:
        print(f"Customer connector private storage is unavailable: {exc}")
        return 1
    except LockError as exc:
        print(f"Customer connector could not lock its private data directory: {exc}")
        return 1
    if lock is None:
        print("Customer connector is already running for this data directory.")
        return 0
    try:
        script = Path(__file__).absolute()
        child_argv = list(argv if argv is not None else sys.argv[1:])
        child_argv = [
            item
            for index, item in enumerate(child_argv)
            if item not in {"--customer-child", "--update-worker"}
            and (index == 0 or child_argv[index - 1] != "--update-worker")
        ]

        def pending_readiness() -> bool:
            try:
                from customer.updater import CustomerUpdater
                from customer.runtime import _architecture_name, _platform_name
                from customer.version import APP_VERSION

                updater = CustomerUpdater(
                    script.parent,
                    data_dir,
                    platform=_platform_name(),
                    arch=_architecture_name(),
                    current_version=APP_VERSION,
                )
                # A ready source with an uncertain running receipt is safe:
                # keep the source and replay the exact terminal receipt.
                # Only a process that never proved readiness may roll back.
                return updater.state().get("phase") == "restarting"
            except Exception:
                try:
                    state = json.loads(
                        (data_dir / "updates" / "state.json").read_text(encoding="utf-8")
                    )
                    return isinstance(state, dict) and state.get("phase") == "restarting"
                except (OSError, ValueError, TypeError):
                    return False

        def reconcile_rollback(journal: dict, updater: object) -> None:
            """Replay a durable rollback receipt without minting a lease."""

            from customer.credentials import CredentialStore
            from customer.transport import RuntimeTransport

            stored = CredentialStore(data_dir).load()
            previous = str(journal.get("previousVersion") or "")
            if not (
                stored
                and previous
                and journal.get("assignmentId")
                and journal.get("assignmentEpoch")
                and journal.get("generation")
                and journal.get("leaseToken")
            ):
                return

            async def reconcile() -> None:
                transport = RuntimeTransport(
                    args.server,
                    credential=str(stored["credential"]),
                    worker_nonce=str(journal.get("workerNonce") or ""),
                )
                transport.installation_id = str(stored["installationId"])
                transport.workspace_id = str(stored.get("workspaceId") or "")
                try:
                    await transport.open()
                    for attempt in range(3):
                        try:
                            await transport.ack_update(
                                assignment_id=str(journal["assignmentId"]),
                                assignment_epoch=int(journal["assignmentEpoch"]),
                                generation=int(journal["generation"]),
                                lease_token=str(journal["leaseToken"]),
                                state="rolled_back",
                                version=previous,
                            )
                            break
                        except Exception:
                            if attempt == 2:
                                raise
                            await asyncio.sleep(0.5 * (attempt + 1))
                    updater.commit_rollback_reconciliation()  # type: ignore[attr-defined]
                finally:
                    await transport.close()

            asyncio.run(reconcile())

        def rollback() -> None:
            from customer.updater import CustomerUpdater
            from customer.runtime import _architecture_name, _platform_name
            from customer.version import APP_VERSION

            updater = CustomerUpdater(
                script.parent,
                data_dir,
                platform=_platform_name(),
                arch=_architecture_name(),
                current_version=APP_VERSION,
                validate_install_root=False,
            )
            journal = updater.recover_interrupted()
            # Source recovery is the safety boundary.  Reconciliation uses
            # only the recovered journal's lease and worker identity.
            try:
                reconcile_rollback(journal, updater)
            except Exception:
                # Keep reconciliationPending in the journal for the next
                # supervisor start if the network is still unavailable.
                pass

        # A supervisor restart after a successful local recovery must not
        # lose the terminal receipt.  Replay it before starting a child; a
        # dropped/offline attempt remains in this same journal for the next
        # process start.
        try:
            from customer.updater import CustomerUpdater
            from customer.runtime import _architecture_name, _platform_name
            from customer.version import APP_VERSION

            startup_updater = CustomerUpdater(
                script.parent,
                data_dir,
                platform=_platform_name(),
                arch=_architecture_name(),
                current_version=APP_VERSION,
                validate_install_root=False,
            )
            startup_journal = startup_updater.state()
            if (
                startup_journal.get("phase") == "rolled_back"
                and startup_journal.get("reconciliationPending") is not False
            ):
                reconcile_rollback(startup_journal, startup_updater)
        except Exception:
            pass

        return run_child_supervisor(
            script=script,
            data_dir=data_dir,
            argv=child_argv,
            pending_readiness=pending_readiness,
            rollback=rollback,
        )
    except KeyboardInterrupt:
        return 0
    finally:
        lock.release()


if __name__ == "__main__":
    raise SystemExit(main())